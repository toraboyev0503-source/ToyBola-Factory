# 0.1.0: release shrinking is disabled. Rules will be expanded before 1.0.0.
