package uz.toybola.factory.core.preferences

import android.content.Context
import uz.toybola.factory.core.security.PinHasher
import uz.toybola.factory.ui.model.AppLanguage
import uz.toybola.factory.ui.model.AppSettings
import uz.toybola.factory.ui.model.AppThemePreset
import uz.toybola.factory.ui.model.UserSetup

class AppPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("toy_bola_prefs", Context.MODE_PRIVATE)

    fun hasSetup(): Boolean = prefs.contains(KEY_DEVICE_CODE) &&
        prefs.contains(KEY_USER_CODE) &&
        prefs.contains(KEY_PIN_HASH)

    fun saveSetup(deviceCode: String, userCode: String, pin: String) {
        prefs.edit()
            .putString(KEY_DEVICE_CODE, deviceCode.trim())
            .putString(KEY_USER_CODE, userCode.trim())
            .putString(KEY_PIN_HASH, PinHasher.sha256(pin))
            .apply()
    }

    fun setup(): UserSetup? {
        if (!hasSetup()) return null
        return UserSetup(
            deviceCode = prefs.getString(KEY_DEVICE_CODE, "").orEmpty(),
            userCode = prefs.getString(KEY_USER_CODE, "").orEmpty(),
            pinHash = prefs.getString(KEY_PIN_HASH, "").orEmpty()
        )
    }

    fun validateLogin(deviceCode: String, userCode: String, pin: String): Boolean {
        val setup = setup() ?: return false
        return setup.deviceCode.equals(deviceCode.trim(), ignoreCase = true) &&
            setup.userCode.equals(userCode.trim(), ignoreCase = true) &&
            setup.pinHash == PinHasher.sha256(pin)
    }

    fun loadSettings(): AppSettings {
        val language = runCatching {
            AppLanguage.valueOf(prefs.getString(KEY_LANGUAGE, AppLanguage.UZ.name).orEmpty())
        }.getOrDefault(AppLanguage.UZ)
        val preset = runCatching {
            AppThemePreset.valueOf(prefs.getString(KEY_THEME, AppThemePreset.BRAND.name).orEmpty())
        }.getOrDefault(AppThemePreset.BRAND)
        return AppSettings(
            language = language,
            darkMode = prefs.getBoolean(KEY_DARK, false),
            themePreset = preset,
            autoLockMinutes = prefs.getInt(KEY_LOCK_MINUTES, 5)
        )
    }

    fun saveSettings(settings: AppSettings) {
        prefs.edit()
            .putString(KEY_LANGUAGE, settings.language.name)
            .putBoolean(KEY_DARK, settings.darkMode)
            .putString(KEY_THEME, settings.themePreset.name)
            .putInt(KEY_LOCK_MINUTES, settings.autoLockMinutes)
            .apply()
    }

    companion object {
        private const val KEY_DEVICE_CODE = "device_code"
        private const val KEY_USER_CODE = "user_code"
        private const val KEY_PIN_HASH = "pin_hash"
        private const val KEY_LANGUAGE = "language"
        private const val KEY_DARK = "dark_mode"
        private const val KEY_THEME = "theme"
        private const val KEY_LOCK_MINUTES = "lock_minutes"
    }
}
