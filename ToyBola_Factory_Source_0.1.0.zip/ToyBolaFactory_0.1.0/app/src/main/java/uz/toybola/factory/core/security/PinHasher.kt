package uz.toybola.factory.core.security

import java.security.MessageDigest

object PinHasher {
    fun sha256(value: String): String {
        return MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }
}
