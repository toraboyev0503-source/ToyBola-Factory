package uz.toybola.factory.ui.model

class AppStrings(private val language: AppLanguage) {
    private fun value(uz: String, ru: String, en: String): String = when (language) {
        AppLanguage.UZ -> uz
        AppLanguage.RU -> ru
        AppLanguage.EN -> en
    }

    val appName = "TOY BOLA"
    val systemName = value("Zavod boshqaruv tizimi", "Система управления заводом", "Factory management system")
    val loading = value("Yuklanmoqda...", "Загрузка...", "Loading...")
    val firstSetup = value("Qurilmani sozlash", "Настройка устройства", "Device setup")
    val deviceCode = value("Qurilma kodi", "Код устройства", "Device code")
    val userCode = value("Foydalanuvchi kodi", "Код пользователя", "User code")
    val pin = "PIN"
    val repeatPin = value("PINni takrorlang", "Повторите PIN", "Repeat PIN")
    val save = value("Saqlash", "Сохранить", "Save")
    val login = value("Kirish", "Войти", "Sign in")
    val wrongLogin = value("Kod yoki PIN noto‘g‘ri", "Неверный код или PIN", "Invalid code or PIN")
    val setupHint = value(
        "0.1.0 test versiyasi: ushbu qurilma uchun kod va PIN yarating.",
        "Тестовая версия 0.1.0: создайте код устройства и PIN.",
        "0.1.0 test build: create a device code and PIN for this device."
    )
    val pinMismatch = value("PINlar bir xil emas", "PIN-коды не совпадают", "PIN values do not match")
    val required = value("Barcha maydonlarni to‘ldiring", "Заполните все поля", "Complete all fields")
    val menu = value("Sozlamalar", "Настройки", "Settings")
    val theme = value("Tema", "Тема", "Theme")
    val languageTitle = value("Til", "Язык", "Language")
    val darkMode = value("Tun rejimi", "Тёмный режим", "Dark mode")
    val autoLock = value("Avtomatik bloklash", "Автоблокировка", "Auto lock")
    val minutes = value("daqiqa", "мин", "min")
    val logout = value("Qulflash", "Заблокировать", "Lock")
    val notLaunched = value("Bu bo‘lim hali ishga tushirilmagan", "Раздел ещё не запущен", "This section is not active yet")
    val back = value("Orqaga", "Назад", "Back")

    val molding = value("Seryo va quyish", "Сырьё и литьё", "Raw material & molding")
    val moldingDesc = value("Stanokdan mahsulot detallari quyish", "Литьё деталей изделия на станках", "Molding product parts on machines")
    val ytmWarehouse = value("YTM sklad", "Склад YTM", "YTM warehouse")
    val ytmWarehouseDesc = value("Quyilgan detallar ombori", "Склад отлитых деталей", "Warehouse for molded parts")
    val sparePartsWarehouse = value("Zapchast sklad", "Склад запчастей", "Spare parts warehouse")
    val sparePartsWarehouseDesc = value("Yig‘ish uchun boshqa detallar ombori", "Склад дополнительных деталей для сборки", "Warehouse for additional assembly parts")
    val assemblyAndHome = value("Sborka va Xonadon", "Сборка и надомники", "Assembly and home work")
    val assemblyAndHomeDesc = value("Sex va xonadon yig‘ish jarayonlari", "Сборка в цехе и у надомников", "Workshop and home assembly processes")
    val finishedGoods = value("TM va EXP sklad", "Склад TM и EXP", "TM & EXP warehouse")
    val finishedGoodsDesc = value("Tayyor mahsulot va yuklash", "Готовая продукция и отгрузка", "Finished goods and shipping")
    val managementControl = value("Rahbariyat nazorati", "Контроль руководства", "Management control")
    val managementControlDesc = value("Zavod bo‘limlari bo‘yicha nazorat", "Контроль по подразделениям завода", "Factory-wide department monitoring")
    val globalMasterData = value("Ma’lumotlar", "Данные", "Master data")
    val globalMasterDataDesc = value("Zavod bo‘yicha asosiy ma’lumotlar", "Основные данные по заводу", "Factory-wide master data")

    val assembly = value("Sborka", "Сборка", "Assembly")
    val homeWork = value("Xonadon", "Надомники", "Home work")
    val homeWorkDesc = value("Xonadonlarda yig‘iladigan mahsulotlar", "Продукция, собираемая надомниками", "Products assembled by home workers")
    val assemblyDesc = value("Sexdagi sborka jarayonini boshqarish", "Управление сборкой в цехе", "Manage workshop assembly")
    val brigadir = value("Brigadir", "Бригадир", "Brigadier")
    val brigadirDesc = value("Ishchilar va kunlik ishlab chiqarish", "Работники и дневное производство", "Workers and daily production")
    val quality = value("Sifat", "Качество", "Quality")
    val qualityDesc = value("3 raundli sifat nazorati", "Контроль качества в 3 раунда", "Three-round quality control")
    val dailyIssue = value("Kun muammosi", "Проблемы дня", "Daily issues")
    val dailyIssueDesc = value("Mahsulot va yig‘uv bosqichi muammolari", "Проблемы изделий и этапов сборки", "Product and assembly-stage issues")
    val monitoring = value("Monitoring", "Мониторинг", "Monitoring")
    val monitoringDesc = value("Natijalar va nazorat", "Результаты и контроль", "Results and oversight")
    val masterData = value("Ma’lumot", "Данные", "Data")
    val masterDataDesc = value("Sborkaga tegishli ma’lumotlar", "Данные, относящиеся к сборке", "Assembly-specific master data")

    val brandTheme = value("Toy Bola", "Toy Bola", "Toy Bola")
    val calmTheme = value("Sokin", "Спокойная", "Calm")
    val neutralTheme = value("Neytral", "Нейтральная", "Neutral")

    val skeletonReady = value(
        "0.1.0 karkasi tayyor. Funksiyalar keyingi versiyada ulanadi.",
        "Каркас 0.1.0 готов. Функции будут подключены в следующей версии.",
        "The 0.1.0 foundation is ready. Features will be connected in the next version."
    )
}
