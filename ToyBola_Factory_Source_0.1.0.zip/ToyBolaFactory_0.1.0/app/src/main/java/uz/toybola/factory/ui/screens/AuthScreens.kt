package uz.toybola.factory.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import uz.toybola.factory.ui.model.AppStrings

@Composable
fun SetupScreen(strings: AppStrings, onSave: (String, String, String) -> Unit) {
    var deviceCode by remember { mutableStateOf("") }
    var userCode by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AuthContainer(title = strings.firstSetup, subtitle = strings.setupHint) {
        OutlinedTextField(deviceCode, { deviceCode = it.uppercase() }, Modifier.fillMaxWidth(), label = { Text(strings.deviceCode) }, singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(userCode, { userCode = it.uppercase() }, Modifier.fillMaxWidth(), label = { Text(strings.userCode) }, singleLine = true)
        Spacer(Modifier.height(10.dp))
        PinField(pin, { pin = it.filter(Char::isDigit).take(8) }, strings.pin)
        Spacer(Modifier.height(10.dp))
        PinField(pin2, { pin2 = it.filter(Char::isDigit).take(8) }, strings.repeatPin)
        if (error != null) {
            Spacer(Modifier.height(8.dp))
            Text(error.orEmpty(), color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(18.dp))
        Button(
            onClick = {
                error = when {
                    deviceCode.isBlank() || userCode.isBlank() || pin.length < 4 -> strings.required
                    pin != pin2 -> strings.pinMismatch
                    else -> null
                }
                if (error == null) onSave(deviceCode, userCode, pin)
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(strings.save) }
    }
}

@Composable
fun LoginScreen(strings: AppStrings, onLogin: (String, String, String) -> Boolean) {
    var deviceCode by remember { mutableStateOf("") }
    var userCode by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    AuthContainer(title = strings.login, subtitle = strings.systemName) {
        OutlinedTextField(deviceCode, { deviceCode = it.uppercase() }, Modifier.fillMaxWidth(), label = { Text(strings.deviceCode) }, singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(userCode, { userCode = it.uppercase() }, Modifier.fillMaxWidth(), label = { Text(strings.userCode) }, singleLine = true)
        Spacer(Modifier.height(10.dp))
        PinField(pin, { pin = it.filter(Char::isDigit).take(8) }, strings.pin)
        if (error) {
            Spacer(Modifier.height(8.dp))
            Text(strings.wrongLogin, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(18.dp))
        Button(
            onClick = { error = !onLogin(deviceCode, userCode, pin) },
            modifier = Modifier.fillMaxWidth()
        ) { Text(strings.login) }
    }
}

@Composable
private fun PinField(value: String, onValueChange: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        visualTransformation = PasswordVisualTransformation(),
        singleLine = true
    )
}

@Composable
private fun AuthContainer(title: String, subtitle: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("TOY BOLA", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(6.dp))
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.65f))
        Spacer(Modifier.height(24.dp))
        Surface(shape = RoundedCornerShape(28.dp), tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), content = { content() })
        }
    }
}
