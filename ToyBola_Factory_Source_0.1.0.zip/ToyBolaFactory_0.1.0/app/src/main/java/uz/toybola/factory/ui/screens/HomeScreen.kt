package uz.toybola.factory.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.components.SectionCard
import uz.toybola.factory.ui.model.AppStrings

private data class HomeSection(val id: Int, val title: String, val description: String)

@Composable
fun HomeScreen(strings: AppStrings, onMenu: () -> Unit, onAssembly: () -> Unit) {
    var disabledMessage by remember { mutableStateOf(false) }
    val sections = listOf(
        HomeSection(1, strings.molding, strings.moldingDesc),
        HomeSection(2, strings.ytmWarehouse, strings.ytmWarehouseDesc),
        HomeSection(3, strings.sparePartsWarehouse, strings.sparePartsWarehouseDesc),
        HomeSection(4, strings.assemblyAndHome, strings.assemblyAndHomeDesc),
        HomeSection(5, strings.finishedGoods, strings.finishedGoodsDesc),
        HomeSection(6, strings.managementControl, strings.managementControlDesc)
    )

    Column(Modifier.fillMaxSize()) {
        AppTopBar(title = strings.appName, canGoBack = false, onMenu = onMenu, onBack = {})
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(strings.systemName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(14.dp))
            sections.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { section ->
                        SectionCard(
                            number = section.id,
                            title = section.title,
                            description = section.description,
                            enabled = section.id == 4,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                if (section.id == 4) onAssembly() else disabledMessage = true
                            }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            SectionCard(
                number = 7,
                title = strings.globalMasterData,
                description = strings.globalMasterDataDesc,
                enabled = false,
                modifier = Modifier.fillMaxWidth(),
                onClick = { disabledMessage = true }
            )
            Spacer(Modifier.height(24.dp))
        }
    }

    if (disabledMessage) {
        AlertDialog(
            onDismissRequest = { disabledMessage = false },
            confirmButton = { TextButton(onClick = { disabledMessage = false }) { Text("OK") } },
            text = { Text(strings.notLaunched) }
        )
    }
}
