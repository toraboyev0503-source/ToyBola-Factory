package uz.toybola.factory.core.security

import org.junit.Assert.assertEquals
import org.junit.Test

class PinHasherTest {
    @Test
    fun sha256_isStable() {
        assertEquals(
            "03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4",
            PinHasher.sha256("1234")
        )
    }
}
