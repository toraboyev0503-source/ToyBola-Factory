# Toy Bola Factory Management System — Android 0.1.0

Birinchi ishlaydigan karkas: brend ikon/splash, lokal qurilma+foydalanuvchi kodi+PIN kirishi, avtomatik lock, bosh ekran, 4-bo‘lim navigatsiyasi va Sborka ichidagi 5 bo‘lim skeleti.

## GitHub build
Repositoryda loyiha ochilgan holatda bo‘lsa `.github/workflows/main.yml` to‘g‘ridan-to‘g‘ri build qiladi.
Agar repositoryga faqat `ToyBola_Factory_Source_0.1.0.zip` yuklansa, workflow ZIPni tekshiradi, ochadi va build qiladi.

Workflow: Java 17 → Android SDK 37 → Gradle 9.5.0 → unit test → lint → assembleDebug → APK Artifact.

Build konfiguratsiyasi AGP 9.3.1 built-in Kotlin bilan ishlaydi; `org.jetbrains.kotlin.android` plugin ataylab qo‘llanmaydi. Compose Compiler plugin 2.3.21 va Compose BOM 2026.06.01 ishlatiladi.

## Birinchi kirish
Birinchi ishga tushishda test qurilma kodi, foydalanuvchi kodi va PIN yaratiladi. Keyingi har bir to‘liq kirishda uchalasi ham talab qilinadi. Server/Firebase autentifikatsiyasi keyingi versiyada ushbu lokal test qatlamini almashtiradi.
