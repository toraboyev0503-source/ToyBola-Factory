# 0.1.0 holati

- App icon: integratsiya qilingan, adaptive icon safe-area bilan.
- Custom splash: 9:16 rasm + ekranga nisbatan moslashuvchi native animatsion progress.
- Auth foundation: lokal device code + user code + hashed PIN.
- Auto-lock: 1/3/5/10/30 daqiqa.
- Global settings: tema, til, tun/kunduz, auto-lock.
- Home: 1–6 ikki ustun, 7 to‘liq kenglik; faqat 4 faol.
- 4-bo‘lim: Xonadon disabled, Sborka faol.
- Sborka: Brigadir / Sifat / Kun muammosi / Monitoring / Ma’lumot navigatsiyasi.
- Android Back: ichki ekranda orqaga qaytadi, bosh ekranda tizimning normal Back harakati saqlanadi.
- GitHub Actions: source ZIP validation + test + lint + debug APK.
- Build setup: AGP 9.3.1 built-in Kotlin, Gradle 9.5.0, JDK 17, compileSdk 36, targetSdk 36.

Firebase/Room/real sync bu buildda ataylab ulanmagan; birinchi APK karkasini barqaror test qilishdan keyin qo‘shiladi.
