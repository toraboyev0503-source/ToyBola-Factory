package uz.toybola.factory.core.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import uz.toybola.factory.core.firebase.FirebaseSyncScheduler
import uz.toybola.factory.core.firebase.TpAccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.firebase.TpSyncOutbox
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.Locale
import java.util.UUID
import kotlin.math.roundToLong

class TpDataRepository(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val accessGuard = TpAccessGuard(appContext)
    private val outbox = TpSyncOutbox(appContext)

    @Synchronized
    fun load(): TpData {
        val raw = prefs.getString(KEY_DATA, null) ?: return defaultData().also(::saveLocal)
        return runCatching { decode(JSONObject(raw)) }.getOrElse { defaultData().also(::saveLocal) }
    }

    @Synchronized
    fun addShop(name: String): Result<Unit> = mutate { data ->
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Sex nomini kiriting" }
        require(data.shops.none { !it.archived && it.name.equals(clean, true) }) { "Bunday sex mavjud" }
        data.copy(shops = data.shops + TpShop(UUID.randomUUID().toString(), clean))
            .audit("TP_SHOP_ADD", details = clean)
    }

    @Synchronized
    fun updateShift(id: String, name: String, startTime: String, endTime: String, roundTimes: List<String>): Result<Unit> = mutate { data ->
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Smena nomini kiriting" }
        LocalTime.parse(startTime)
        LocalTime.parse(endTime)
        require(roundTimes.isNotEmpty()) { "Kamida bitta sifat raundi bo‘lsin" }
        roundTimes.forEach(LocalTime::parse)
        val updated = data.shifts.map { if (it.id == id) it.copy(name = clean, startTime = startTime, endTime = endTime, roundTimes = roundTimes) else it }
        require(updated.any { it.id == id }) { "Smena topilmadi" }
        data.copy(shifts = updated).audit("TP_SHIFT_UPDATE", details = "$clean $startTime–$endTime / ${roundTimes.joinToString()}")
    }

    @Synchronized
    fun addBrigade(shopId: String, shiftId: String, name: String): Result<Unit> = mutate { data ->
        require(data.shops.any { it.id == shopId && !it.archived }) { "Sexni tanlang" }
        require(data.shifts.any { it.id == shiftId && !it.archived }) { "Smenani tanlang" }
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Brigada nomini kiriting" }
        val brigade = TpBrigade(UUID.randomUUID().toString(), shopId, shiftId, clean)
        data.copy(brigades = data.brigades + brigade).audit("TP_BRIGADE_ADD", brigade.id, details = clean)
    }

    @Synchronized
    fun updateBrigade(id: String, shopId: String, shiftId: String, name: String): Result<Unit> = mutate { data ->
        require(data.shops.any { it.id == shopId && !it.archived }) { "Sexni tanlang" }
        require(data.shifts.any { it.id == shiftId && !it.archived }) { "Smenani tanlang" }
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Brigada nomini kiriting" }
        require(data.brigades.any { it.id == id }) { "Brigada topilmadi" }
        data.copy(brigades = data.brigades.map { if (it.id == id) it.copy(shopId = shopId, shiftId = shiftId, name = clean) else it })
            .audit("TP_BRIGADE_UPDATE", id, details = clean)
    }

    @Synchronized
    fun addMachine(shopId: String, number: Int, name: String): Result<Unit> = mutate { data ->
        require(data.shops.any { it.id == shopId && !it.archived }) { "Sexni tanlang" }
        require(number > 0) { "Stanok raqami 0 dan katta bo‘lsin" }
        require(data.machines.none { !it.archived && it.number == number }) { "Bu stanok raqami mavjud" }
        val machine = TpMachine(UUID.randomUUID().toString(), shopId, number, name.cleanText())
        data.copy(machines = data.machines + machine).audit("TP_MACHINE_ADD", details = number.toString())
    }

    @Synchronized
    fun updateMachine(id: String, shopId: String, number: Int, name: String): Result<Unit> = mutate { data ->
        require(data.shops.any { it.id == shopId && !it.archived }) { "Sexni tanlang" }
        require(number > 0) { "Stanok raqami 0 dan katta bo‘lsin" }
        require(data.machines.none { it.id != id && !it.archived && it.number == number }) { "Bu stanok raqami mavjud" }
        require(data.machines.any { it.id == id }) { "Stanok topilmadi" }
        data.copy(machines = data.machines.map { if (it.id == id) it.copy(shopId = shopId, number = number, name = name.cleanText()) else it })
            .audit("TP_MACHINE_UPDATE", details = number.toString())
    }

    @Synchronized
    fun addWorker(brigadeId: String, name: String, dailyTargetAmount: Long, defaultWorkMinutes: Int): Result<Unit> = mutate { data ->
        require(data.brigades.any { it.id == brigadeId && !it.archived }) { "Brigadani tanlang" }
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Ishchi ismini kiriting" }
        require(dailyTargetAmount > 0) { "Kunlik norma 0 dan katta bo‘lsin" }
        require(defaultWorkMinutes in 1..1440) { "Ish vaqtini to‘g‘ri kiriting" }
        val worker = TpWorker(UUID.randomUUID().toString(), brigadeId, clean, dailyTargetAmount, defaultWorkMinutes)
        data.copy(workers = data.workers + worker).audit("TP_WORKER_ADD", brigadeId, details = clean)
    }

    @Synchronized
    fun updateWorker(id: String, brigadeId: String, name: String, dailyTargetAmount: Long, defaultWorkMinutes: Int): Result<Unit> = mutate { data ->
        require(data.brigades.any { it.id == brigadeId && !it.archived }) { "Brigadani tanlang" }
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Ishchi ismini kiriting" }
        require(dailyTargetAmount > 0) { "Kunlik norma 0 dan katta bo‘lsin" }
        require(defaultWorkMinutes in 1..1440) { "Ish vaqtini to‘g‘ri kiriting" }
        require(data.workers.any { it.id == id }) { "Ishchi topilmadi" }
        data.copy(workers = data.workers.map {
            if (it.id == id) it.copy(brigadeId = brigadeId, name = clean, dailyTargetAmount = dailyTargetAmount, defaultWorkMinutes = defaultWorkMinutes) else it
        }).audit("TP_WORKER_UPDATE", brigadeId, details = clean)
    }

    @Synchronized
    fun addProduct(article: String, name: String): Result<Unit> = mutate { data ->
        val code = article.trim().uppercase(Locale.ROOT)
        val clean = name.cleanText()
        require(code.isNotBlank() && clean.isNotBlank()) { "Artikul va mahsulot nomini kiriting" }
        require(data.products.none { !it.archived && it.article.equals(code, true) }) { "Bu artikul mavjud" }
        data.copy(products = data.products + TpProduct(UUID.randomUUID().toString(), code, clean))
            .audit("TP_PRODUCT_ADD", details = "$code $clean")
    }

    @Synchronized
    fun updateProduct(id: String, article: String, name: String): Result<Unit> = mutate { data ->
        val code = article.trim().uppercase(Locale.ROOT)
        val clean = name.cleanText()
        require(code.isNotBlank() && clean.isNotBlank()) { "Artikul va mahsulot nomini kiriting" }
        require(data.products.none { it.id != id && !it.archived && it.article.equals(code, true) }) { "Bu artikul mavjud" }
        require(data.products.any { it.id == id }) { "Mahsulot topilmadi" }
        data.copy(products = data.products.map { if (it.id == id) it.copy(article = code, name = clean) else it })
            .audit("TP_PRODUCT_UPDATE", details = "$code $clean")
    }

    @Synchronized
    fun saveDetail(productId: String, detail: TpDetail): Result<Unit> = mutate { data ->
        validateDetail(data, detail)
        val product = data.products.firstOrNull { it.id == productId } ?: error("Mahsulot topilmadi")
        val clean = detail.copy(
            name = detail.name.cleanText(),
            moldCode = detail.moldCode.trim().uppercase(Locale.ROOT),
            resinCode = detail.resinCode.trim().uppercase(Locale.ROOT),
            colors = detail.colors.map { it.copy(colorCode = it.colorCode.trim().uppercase(Locale.ROOT)) }
        )
        val details = if (product.details.any { it.id == clean.id }) {
            product.details.map { if (it.id == clean.id) clean else it }
        } else product.details + clean
        data.copy(products = data.products.map { if (it.id == productId) it.copy(details = details) else it })
            .audit("TP_DETAIL_SAVE", details = "${product.article} / ${clean.name}")
    }

    @Synchronized
    fun archiveDetail(productId: String, detailId: String, archived: Boolean): Result<Unit> = mutate { data ->
        val product = data.products.firstOrNull { it.id == productId } ?: error("Mahsulot topilmadi")
        require(product.details.any { it.id == detailId }) { "Detal topilmadi" }
        data.copy(products = data.products.map { item ->
            if (item.id == productId) item.copy(details = item.details.map { if (it.id == detailId) it.copy(archived = archived) else it }) else item
        }).audit("TP_DETAIL_ARCHIVE", details = "$detailId=$archived")
    }

    @Synchronized
    fun setMaterial(code: String, name: String, type: TpMaterialType, availableAmount: Double): Result<Unit> = mutate { data ->
        val normalized = code.trim().uppercase(Locale.ROOT)
        require(normalized.isNotBlank() && name.cleanText().isNotBlank()) { "Kod va nomni kiriting" }
        require(availableAmount >= 0.0 && availableAmount.isFinite()) { "Qoldiq noto‘g‘ri" }
        val current = data.materials.firstOrNull { it.code.equals(normalized, true) && it.type == type }
        val item = current?.copy(name = name.cleanText(), availableAmount = availableAmount)
            ?: TpMaterial(UUID.randomUUID().toString(), normalized, name.cleanText(), type, availableAmount)
        val materials = if (current == null) data.materials + item else data.materials.map { if (it.id == current.id) item else it }
        data.copy(materials = materials).audit("TP_MATERIAL_SAVE", details = "$normalized ${formatTpNumber(availableAmount)}")
    }

    @Synchronized
    fun increaseAllDetailPrices(percent: Double): Result<Unit> = mutate { data ->
        require(percent.isFinite() && percent > -100.0 && percent <= 1000.0) { "Foizni to‘g‘ri kiriting" }
        val factor = 1.0 + percent / 100.0
        val products = data.products.map { product ->
            product.copy(details = product.details.map { detail ->
                detail.copy(unitPrice = (detail.unitPrice * factor).roundToLong().coerceAtLeast(0L))
            })
        }
        data.copy(products = products, settings = data.settings.copy(priceRevision = data.settings.priceRevision + 1))
            .audit("TP_PRICE_BULK", details = "$percent%")
    }

    @Synchronized
    fun createOrder(
        firstBatchNumber: String,
        productId: String,
        quantity: Int,
        priority: Int,
        requestedDate: String,
        note: String
    ): Result<Unit> = mutate { data ->
        val product = data.products.firstOrNull { it.id == productId && !it.archived } ?: error("Mahsulotni tanlang")
        require(quantity > 0) { "Zakaz soni 0 dan katta bo‘lsin" }
        require(priority in 1..99) { "Ustuvorlik 1–99 oralig‘ida bo‘lsin" }
        LocalDate.parse(requestedDate)
        val batch = if (data.orders.isEmpty()) {
            firstBatchNumber.trim().also { require(it.isNotBlank()) { "Birinchi partiya raqamini kiriting" } }
        } else {
            nextBatchNumber(data.orders.maxByOrNull { it.createdAt }!!.batchNumber)
        }
        require(data.orders.none { it.batchNumber.equals(batch, true) }) { "Bu partiya raqami mavjud" }
        val now = LocalDateTime.now().toString()
        val order = TpOrder(
            id = UUID.randomUUID().toString(), batchNumber = batch, productId = product.id,
            articleSnapshot = product.article, productNameSnapshot = product.name, quantity = quantity,
            priority = priority, requestedDate = requestedDate, note = note.cleanText(),
            status = TpOrderStatus.NEW, createdAt = now
        )
        data.copy(orders = data.orders + order, settings = data.settings.copy(firstBatchEntered = true))
            .audit("TP_ORDER_ADD", recordDate = requestedDate, details = "$batch ${product.article} × $quantity")
    }

    @Synchronized
    fun generateOrderPlan(orderId: String): Result<Unit> = mutate { data ->
        val order = data.orders.firstOrNull { it.id == orderId } ?: error("Zakaz topilmadi")
        require(data.jobs.none { it.orderId == orderId }) { "Bu zakaz uchun plan yaratilgan" }
        val jobs = buildPlanJobs(data, order) { UUID.randomUUID().toString() }
        require(jobs.isNotEmpty()) { "Plan vazifalari hosil bo‘lmadi" }
        data.copy(
            jobs = data.jobs + jobs,
            orders = data.orders.map { if (it.id == orderId) it.copy(status = TpOrderStatus.PLANNING) else it }
        ).audit("TP_PLAN_GENERATE", recordDate = order.requestedDate, details = "${order.batchNumber}: ${jobs.size} vazifa")
    }

    @Synchronized
    fun assignJob(jobId: String, machineId: String, brigadeId: String, priority: Int): Result<Unit> = mutate { data ->
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        val machine = data.machines.firstOrNull { it.id == machineId && !it.archived } ?: error("Stanok topilmadi")
        val brigade = data.brigades.firstOrNull { it.id == brigadeId && !it.archived } ?: error("Brigada topilmadi")
        require(machine.shopId == brigade.shopId) { "Stanok va brigada bir sexda bo‘lsin" }
        require(job.compatibleMachineIds.isEmpty() || machineId in job.compatibleMachineIds) { "Bu stanok ushbu qolipni quya olmaydi" }
        require(priority in 1..9999) { "Ustuvorlik noto‘g‘ri" }
        val updatedJobs = data.jobs.map {
            if (it.id == jobId) it.copy(
                machineId = machineId, brigadeId = brigadeId, shiftId = brigade.shiftId,
                priority = priority, status = TpJobStatus.QUEUED
            ) else it
        }
        val orderReady = updatedJobs.filter { it.orderId == job.orderId }.all { it.machineId != null }
        data.copy(
            jobs = updatedJobs,
            orders = data.orders.map { if (it.id == job.orderId && orderReady) it.copy(status = TpOrderStatus.READY) else it }
        ).audit("TP_JOB_ASSIGN", brigadeId, details = "Stanok ${machine.number} / ${job.moldCode}")
    }

    @Synchronized
    fun setJobPriority(jobId: String, priority: Int): Result<Unit> = mutate { data ->
        require(priority in 1..9999) { "Ustuvorlik noto‘g‘ri" }
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        data.copy(jobs = data.jobs.map { if (it.id == jobId) it.copy(priority = priority) else it })
            .audit("TP_JOB_PRIORITY", job.brigadeId, details = "${job.moldCode}: $priority")
    }

    @Synchronized
    fun setJobStatus(jobId: String, status: TpJobStatus): Result<Unit> = mutate { data ->
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        require(job.machineId != null || status == TpJobStatus.HOLD || status == TpJobStatus.UNASSIGNED) { "Avval stanok belgilang" }
        if (status == TpJobStatus.COMPLETE) {
            val unfinished = job.outputs.filter { output ->
                data.receipts.filter { it.jobId == jobId && it.detailId == output.detailId }
                    .sumOf { it.creditedPieces } < output.requiredPieces
            }
            require(unfinished.isEmpty()) {
                "Vazifa faqat qabul qilingan barcha detallar reja soniga yetganda yakunlanadi"
            }
        }
        var updated = data.copy(jobs = data.jobs.map { if (it.id == jobId) it.copy(status = status) else it })
        updated = updated.refreshOrderStatus(job.orderId)
        updated.audit("TP_JOB_STATUS", job.brigadeId, details = "${job.moldCode}: ${status.name}")
    }

    @Synchronized
    fun confirmMaterial(jobId: String, delivered: Boolean): Result<Unit> = mutate { data ->
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        require(job.machineId != null) { "Vazifa stanokka biriktirilmagan" }
        val now = LocalDateTime.now().toString()
        val status = if (delivered) TpMaterialStatus.DELIVERED else TpMaterialStatus.CONFIRMED
        val updated = job.copy(
            materialStatus = status,
            materialConfirmedAt = job.materialConfirmedAt ?: now,
            materialDeliveredAt = if (delivered) now else job.materialDeliveredAt
        )
        data.copy(jobs = data.jobs.map { if (it.id == jobId) updated else it })
            .audit(if (delivered) "TP_MATERIAL_DELIVER" else "TP_MATERIAL_CONFIRM", job.brigadeId, details = job.moldCode)
    }

    @Synchronized
    fun setAttendance(workerId: String, date: String, present: Boolean, workMinutes: Int): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val worker = data.workers.firstOrNull { it.id == workerId && !it.archived } ?: error("Ishchi topilmadi")
        val brigade = data.brigades.firstOrNull { it.id == worker.brigadeId } ?: error("Brigada topilmadi")
        require(workMinutes in 0..1440 && (present || workMinutes == 0)) { "Ish vaqtini to‘g‘ri kiriting" }
        val id = "${workerId}_$date"
        val attendance = TpAttendance(id, worker.id, worker.brigadeId, brigade.shiftId, date, present, workMinutes, LocalDateTime.now().toString())
        val values = data.attendance.filterNot { it.id == id } + attendance
        data.copy(attendance = values).audit("TP_ATTENDANCE", worker.brigadeId, date, "${worker.name}: $present / $workMinutes")
    }

    @Synchronized
    fun addReceipt(
        jobId: String,
        detailId: String,
        workerId: String,
        date: String,
        completedBags: Int,
        remainderAfter: Int,
        receiverName: String
    ): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        val output = job.outputs.firstOrNull { it.detailId == detailId } ?: error("Detal topilmadi")
        val worker = data.workers.firstOrNull { it.id == workerId && !it.archived } ?: error("Ishchi topilmadi")
        val machineId = job.machineId ?: error("Stanok belgilanmagan")
        val brigadeId = job.brigadeId ?: error("Brigada belgilanmagan")
        val shiftId = job.shiftId ?: error("Smena belgilanmagan")
        require(worker.brigadeId == brigadeId) { "Ishchi boshqa brigadaga tegishli" }
        require(receiverName.cleanText().isNotBlank()) { "Qabul qiluvchi ismini kiriting" }
        val carry = data.openRemainder(jobId, detailId)
        val credited = calculateReceiptCredit(output.bagCapacity, carry, completedBags, remainderAfter)
        val now = LocalDateTime.now().toString()
        val receipt = TpReceipt(
            id = UUID.randomUUID().toString(), jobId = job.id, orderId = job.orderId,
            detailId = output.detailId, detailNameSnapshot = output.detailName,
            machineId = machineId, workerId = worker.id, workerNameSnapshot = worker.name,
            brigadeId = brigadeId, shiftId = shiftId, date = date, colorCode = job.colorCode,
            completedBags = completedBags, bagCapacity = output.bagCapacity,
            carryInPieces = carry, remainderAfter = remainderAfter, creditedPieces = credited,
            unitPriceSnapshot = output.unitPrice, receiverName = receiverName.cleanText(), createdAt = now
        )
        var updated = data.copy(
            receipts = data.receipts + receipt,
            jobs = data.jobs.map { if (it.id == jobId && it.status == TpJobStatus.QUEUED) it.copy(status = TpJobStatus.IN_PROGRESS) else it }
        )
        val produced = updated.receipts.filter { it.jobId == jobId && it.detailId == detailId }.sumOf { it.creditedPieces }
        val allDone = job.outputs.all { planned ->
            updated.receipts.filter { it.jobId == jobId && it.detailId == planned.detailId }.sumOf { it.creditedPieces } >= planned.requiredPieces
        }
        if (allDone) updated = updated.copy(jobs = updated.jobs.map { if (it.id == jobId) it.copy(status = TpJobStatus.COMPLETE) else it })
        updated = updated.refreshOrderStatus(job.orderId)
        updated.audit("TP_RECEIPT", brigadeId, date, "${output.detailName}: +$credited (jami $produced), qoldiq $remainderAfter")
    }

    @Synchronized
    fun saveQualityRound(
        jobId: String,
        workerId: String,
        date: String,
        round: Int,
        score: Int,
        issue: String,
        checkedBy: String
    ): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        val brigadeId = job.brigadeId ?: error("Brigada belgilanmagan")
        val shiftId = job.shiftId ?: error("Smena belgilanmagan")
        val machineId = job.machineId ?: error("Stanok belgilanmagan")
        require(data.workers.any { it.id == workerId && it.brigadeId == brigadeId }) { "Ishchini tanlang" }
        require(score in 0..100) { "Baho 0–100 oralig‘ida bo‘lsin" }
        val shift = data.shifts.firstOrNull { it.id == shiftId } ?: error("Smena topilmadi")
        require(round in 1..shift.roundTimes.size) { "Raund raqami noto‘g‘ri" }
        require(checkedBy.cleanText().isNotBlank()) { "Tekshiruvchi ismini kiriting" }
        val id = "${jobId}_${workerId}_${date}_$round"
        val record = TpQualityRound(
            id, brigadeId, shiftId, machineId, workerId, jobId, date, round,
            shift.roundTimes[round - 1], score, issue.cleanText(), checkedBy.cleanText(), LocalDateTime.now().toString()
        )
        data.copy(qualityRounds = data.qualityRounds.filterNot { it.id == id } + record)
            .audit("TP_QUALITY", brigadeId, date, "${machineId}: $round / $score")
    }

    @Synchronized
    fun addDailyIssue(brigadeId: String, date: String, machineId: String?, orderId: String?, title: String, note: String): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val cleanTitle = title.cleanText()
        val cleanNote = note.cleanText()
        require(cleanTitle.isNotBlank() && cleanNote.isNotBlank()) { "Muammo nomi va izohini kiriting" }
        require(data.brigades.any { it.id == brigadeId }) { "Brigadani tanlang" }
        val issue = TpDailyIssue(UUID.randomUUID().toString(), brigadeId, date, machineId, orderId, cleanTitle, cleanNote, LocalDateTime.now().toString())
        data.copy(dailyIssues = data.dailyIssues + issue).audit("TP_DAILY_ISSUE", brigadeId, date, cleanTitle)
    }

    @Synchronized
    fun replaceFromServer(data: TpData) {
        saveLocal(normalize(data))
        TpDataEvents.notifyChanged()
    }

    fun encodeForSync(data: TpData): String = encode(data).toString()
    fun decodeForSync(raw: String): TpData = normalize(decode(JSONObject(raw)))

    private fun validateDetail(data: TpData, detail: TpDetail) {
        require(detail.name.cleanText().isNotBlank()) { "Detal nomini kiriting" }
        require(detail.moldCode.trim().isNotBlank()) { "Qolip kodini kiriting" }
        require(detail.requiredPerProduct > 0 && detail.piecesPerShot > 0) { "Detal va jim sonlari 0 dan katta bo‘lsin" }
        require(detail.bagCapacity > 0) { "Qop sig‘imini kiriting" }
        require(detail.cycleSeconds > 0) { "Sikl vaqtini kiriting" }
        require(detail.grossShotWeightGrams > 0.0 && detail.unusableShotWeightGrams in 0.0..detail.grossShotWeightGrams) { "Og‘irlikni to‘g‘ri kiriting" }
        require(detail.resinCode.trim().isNotBlank()) { "Seryo kodini kiriting" }
        require(detail.unitPrice >= 0) { "Narx manfiy bo‘lmasin" }
        require(detail.compatibleMachineIds.all { id -> data.machines.any { it.id == id && !it.archived } }) { "Mos stanoklar noto‘g‘ri" }
        require(detail.colors.isNotEmpty()) { "Kamida bitta rang kiriting" }
        require(detail.colors.all { it.colorCode.isNotBlank() && it.share > 0.0 && it.gramsPer25Kg >= 0.0 }) { "Rang taqsimoti noto‘g‘ri" }
        require(detail.colors.map { it.colorCode.trim().uppercase(Locale.ROOT) }.distinct().size == detail.colors.size) { "Bir detalda rang kodi takrorlanmasin" }
    }

    private fun TpData.refreshOrderStatus(orderId: String): TpData {
        val orderJobs = jobs.filter { it.orderId == orderId }
        val status = when {
            orderJobs.isNotEmpty() && orderJobs.all { it.status == TpJobStatus.COMPLETE } -> TpOrderStatus.COMPLETE
            orderJobs.any { it.status == TpJobStatus.IN_PROGRESS || it.status == TpJobStatus.COMPLETE } -> TpOrderStatus.IN_PROGRESS
            orderJobs.isNotEmpty() && orderJobs.all { it.machineId != null } -> TpOrderStatus.READY
            orderJobs.isNotEmpty() -> TpOrderStatus.PLANNING
            else -> TpOrderStatus.NEW
        }
        val now = if (status == TpOrderStatus.COMPLETE) LocalDateTime.now().toString() else null
        return copy(orders = orders.map { if (it.id == orderId) it.copy(status = status, completedAt = now ?: it.completedAt) else it })
    }

    private fun TpData.audit(action: String, brigadeId: String? = null, recordDate: String? = null, details: String): TpData = copy(
        auditLog = (auditLog + TpAuditEntry(UUID.randomUUID().toString(), action, brigadeId, recordDate, details, LocalDateTime.now().toString())).takeLast(3000)
    )

    private fun mutate(block: (TpData) -> TpData): Result<Unit> = runCatching {
        val before = load()
        val after = normalize(block(before))
        accessGuard.validate(before, after)
        saveLocal(after)
        outbox.recordDiff(before, after)
        TpDataEvents.notifyChanged()
        FirebaseSyncScheduler.enqueue(appContext)
    }

    private fun saveLocal(data: TpData) {
        prefs.edit().putString(KEY_DATA, encode(data).toString()).commit()
    }

    private fun normalize(data: TpData): TpData = data.copy(
        shops = data.shops.distinctBy { it.id }, shifts = data.shifts.distinctBy { it.id },
        brigades = data.brigades.distinctBy { it.id }, machines = data.machines.distinctBy { it.id },
        workers = data.workers.distinctBy { it.id }, products = data.products.distinctBy { it.id },
        materials = data.materials.distinctBy { it.id }, orders = data.orders.distinctBy { it.id },
        jobs = data.jobs.distinctBy { it.id }, attendance = data.attendance.distinctBy { it.id },
        receipts = data.receipts.distinctBy { it.id }, qualityRounds = data.qualityRounds.distinctBy { it.id },
        dailyIssues = data.dailyIssues.distinctBy { it.id }, auditLog = data.auditLog.distinctBy { it.id }.takeLast(3000)
    )

    private fun defaultData(): TpData {
        val shops = (1..3).map { TpShop("tp-shop-$it", "$it-sex") }
        val shifts = listOf(
            TpShift("tp-shift-day", "Kunduzgi", "07:40", "19:00", listOf("10:00", "13:00", "16:00")),
            TpShift("tp-shift-night", "Tungi", "19:00", "07:00", listOf("22:00", "02:00"))
        )
        val brigades = shops.flatMapIndexed { index, shop ->
            listOf(
                TpBrigade("tp-brigade-${index + 1}-day", shop.id, shifts[0].id, "${index + 1}-sex kunduzgi"),
                TpBrigade("tp-brigade-${index + 1}-night", shop.id, shifts[1].id, "${index + 1}-sex tungi")
            )
        }
        val machines = (1..45).map { number ->
            val shopIndex = ((number - 1) / 15).coerceAtMost(2)
            TpMachine("tp-machine-$number", shops[shopIndex].id, number)
        }
        return TpData(shops = shops, shifts = shifts, brigades = brigades, machines = machines)
    }

    private fun encode(data: TpData): JSONObject = JSONObject().apply {
        put("shops", array(data.shops) { o, item -> o.put("id", item.id).put("name", item.name).put("archived", item.archived) })
        put("shifts", array(data.shifts) { o, item -> o.put("id", item.id).put("name", item.name).put("startTime", item.startTime).put("endTime", item.endTime).put("roundTimes", strings(item.roundTimes)).put("archived", item.archived) })
        put("brigades", array(data.brigades) { o, item -> o.put("id", item.id).put("shopId", item.shopId).put("shiftId", item.shiftId).put("name", item.name).put("archived", item.archived) })
        put("machines", array(data.machines) { o, item -> o.put("id", item.id).put("shopId", item.shopId).put("number", item.number).put("name", item.name).put("archived", item.archived) })
        put("workers", array(data.workers) { o, item -> o.put("id", item.id).put("brigadeId", item.brigadeId).put("name", item.name).put("dailyTargetAmount", item.dailyTargetAmount).put("defaultWorkMinutes", item.defaultWorkMinutes).put("archived", item.archived) })
        put("products", array(data.products) { o, product ->
            o.put("id", product.id).put("article", product.article).put("name", product.name).put("archived", product.archived)
                .put("details", array(product.details) { d, detail ->
                    d.put("id", detail.id).put("name", detail.name).put("moldCode", detail.moldCode)
                        .put("requiredPerProduct", detail.requiredPerProduct).put("piecesPerShot", detail.piecesPerShot)
                        .put("bagCapacity", detail.bagCapacity).put("cycleSeconds", detail.cycleSeconds)
                        .put("grossShotWeightGrams", detail.grossShotWeightGrams).put("unusableShotWeightGrams", detail.unusableShotWeightGrams)
                        .put("resinCode", detail.resinCode).put("unitPrice", detail.unitPrice)
                        .put("compatibleMachineIds", strings(detail.compatibleMachineIds))
                        .put("colors", array(detail.colors) { c, color -> c.put("colorCode", color.colorCode).put("share", color.share).put("gramsPer25Kg", color.gramsPer25Kg) })
                        .put("archived", detail.archived)
                })
        })
        put("materials", array(data.materials) { o, item -> o.put("id", item.id).put("code", item.code).put("name", item.name).put("type", item.type.name).put("availableAmount", item.availableAmount).put("archived", item.archived) })
        put("orders", array(data.orders) { o, order ->
            o.put("id", order.id).put("batchNumber", order.batchNumber).put("productId", order.productId)
                .put("articleSnapshot", order.articleSnapshot).put("productNameSnapshot", order.productNameSnapshot)
                .put("quantity", order.quantity).put("priority", order.priority).put("requestedDate", order.requestedDate)
                .put("note", order.note).put("status", order.status.name).put("createdAt", order.createdAt)
            if (order.completedAt == null) o.put("completedAt", JSONObject.NULL) else o.put("completedAt", order.completedAt)
        })
        put("jobs", array(data.jobs) { o, job ->
            o.put("id", job.id).put("orderId", job.orderId).put("moldCode", job.moldCode).put("colorCode", job.colorCode)
                .put("outputs", array(job.outputs) { d, output -> d.put("detailId", output.detailId).put("detailName", output.detailName).put("requiredPieces", output.requiredPieces).put("plannedPieces", output.plannedPieces).put("piecesPerShot", output.piecesPerShot).put("bagCapacity", output.bagCapacity).put("unitPrice", output.unitPrice) })
                .put("requiredShots", job.requiredShots).put("cycleSeconds", job.cycleSeconds).put("estimatedMinutes", job.estimatedMinutes)
                .put("resinCode", job.resinCode).put("requiredResinKg", job.requiredResinKg).put("requiredColorGrams", job.requiredColorGrams)
                .put("compatibleMachineIds", strings(job.compatibleMachineIds)).putNullable("machineId", job.machineId)
                .putNullable("brigadeId", job.brigadeId).putNullable("shiftId", job.shiftId).put("priority", job.priority)
                .put("status", job.status.name).put("materialStatus", job.materialStatus.name)
                .putNullable("materialConfirmedAt", job.materialConfirmedAt).putNullable("materialDeliveredAt", job.materialDeliveredAt)
        })
        put("attendance", array(data.attendance) { o, item -> o.put("id", item.id).put("workerId", item.workerId).put("brigadeId", item.brigadeId).put("shiftId", item.shiftId).put("date", item.date).put("present", item.present).put("workMinutes", item.workMinutes).put("updatedAt", item.updatedAt) })
        put("receipts", array(data.receipts) { o, receipt ->
            o.put("id", receipt.id).put("jobId", receipt.jobId).put("orderId", receipt.orderId).put("detailId", receipt.detailId)
                .put("detailNameSnapshot", receipt.detailNameSnapshot).put("machineId", receipt.machineId).put("workerId", receipt.workerId)
                .put("workerNameSnapshot", receipt.workerNameSnapshot).put("brigadeId", receipt.brigadeId).put("shiftId", receipt.shiftId)
                .put("date", receipt.date).put("colorCode", receipt.colorCode).put("completedBags", receipt.completedBags)
                .put("bagCapacity", receipt.bagCapacity).put("carryInPieces", receipt.carryInPieces).put("remainderAfter", receipt.remainderAfter)
                .put("creditedPieces", receipt.creditedPieces).put("unitPriceSnapshot", receipt.unitPriceSnapshot)
                .put("receiverName", receipt.receiverName).put("createdAt", receipt.createdAt)
        })
        put("qualityRounds", array(data.qualityRounds) { o, item -> o.put("id", item.id).put("brigadeId", item.brigadeId).put("shiftId", item.shiftId).put("machineId", item.machineId).put("workerId", item.workerId).put("jobId", item.jobId).put("date", item.date).put("round", item.round).put("scheduledTime", item.scheduledTime).put("score", item.score).put("issue", item.issue).put("checkedBy", item.checkedBy).put("checkedAt", item.checkedAt) })
        put("dailyIssues", array(data.dailyIssues) { o, item -> o.put("id", item.id).put("brigadeId", item.brigadeId).put("date", item.date).putNullable("machineId", item.machineId).putNullable("orderId", item.orderId).put("title", item.title).put("note", item.note).put("createdAt", item.createdAt) })
        put("auditLog", array(data.auditLog) { o, item -> o.put("id", item.id).put("action", item.action).putNullable("brigadeId", item.brigadeId).putNullable("recordDate", item.recordDate).put("details", item.details).put("createdAt", item.createdAt) })
        put("settings", JSONObject().put("firstBatchEntered", data.settings.firstBatchEntered).put("priceRevision", data.settings.priceRevision))
    }

    private fun decode(root: JSONObject): TpData = TpData(
        shops = root.arr("shops").objects().map { TpShop(it.text("id"), it.text("name"), it.optBoolean("archived")) },
        shifts = root.arr("shifts").objects().map { TpShift(it.text("id"), it.text("name"), it.text("startTime", "07:40"), it.text("endTime", "19:00"), it.arr("roundTimes").stringValues(), it.optBoolean("archived")) },
        brigades = root.arr("brigades").objects().map { TpBrigade(it.text("id"), it.text("shopId"), it.text("shiftId"), it.text("name"), it.optBoolean("archived")) },
        machines = root.arr("machines").objects().map { TpMachine(it.text("id"), it.text("shopId"), it.optInt("number"), it.text("name"), it.optBoolean("archived")) },
        workers = root.arr("workers").objects().map { TpWorker(it.text("id"), it.text("brigadeId"), it.text("name"), it.optLong("dailyTargetAmount"), it.optInt("defaultWorkMinutes"), it.optBoolean("archived")) },
        products = root.arr("products").objects().map { product ->
            TpProduct(product.text("id"), product.text("article"), product.text("name"), product.arr("details").objects().map { detail ->
                TpDetail(
                    id = detail.text("id"), name = detail.text("name"), moldCode = detail.text("moldCode"),
                    requiredPerProduct = detail.optInt("requiredPerProduct"), piecesPerShot = detail.optInt("piecesPerShot"),
                    bagCapacity = detail.optInt("bagCapacity"), cycleSeconds = detail.optInt("cycleSeconds"),
                    grossShotWeightGrams = detail.optDouble("grossShotWeightGrams"), unusableShotWeightGrams = detail.optDouble("unusableShotWeightGrams"),
                    resinCode = detail.text("resinCode"), unitPrice = detail.optLong("unitPrice"),
                    compatibleMachineIds = detail.arr("compatibleMachineIds").stringValues().toSet(),
                    colors = detail.arr("colors").objects().map { TpColorRule(it.text("colorCode"), it.optDouble("share"), it.optDouble("gramsPer25Kg")) },
                    archived = detail.optBoolean("archived")
                )
            }, product.optBoolean("archived"))
        },
        materials = root.arr("materials").objects().map { TpMaterial(it.text("id"), it.text("code"), it.text("name"), it.enum("type", TpMaterialType.RESIN), it.optDouble("availableAmount"), it.optBoolean("archived")) },
        orders = root.arr("orders").objects().map { TpOrder(it.text("id"), it.text("batchNumber"), it.text("productId"), it.text("articleSnapshot"), it.text("productNameSnapshot"), it.optInt("quantity"), it.optInt("priority", 1), it.text("requestedDate", isoToday()), it.text("note"), it.enum("status", TpOrderStatus.NEW), it.text("createdAt"), it.nullableText("completedAt")) },
        jobs = root.arr("jobs").objects().map { job ->
            TpPlanJob(
                id = job.text("id"), orderId = job.text("orderId"), moldCode = job.text("moldCode"), colorCode = job.text("colorCode"),
                outputs = job.arr("outputs").objects().map { TpJobOutput(it.text("detailId"), it.text("detailName"), it.optInt("requiredPieces"), it.optInt("plannedPieces"), it.optInt("piecesPerShot"), it.optInt("bagCapacity"), it.optLong("unitPrice")) },
                requiredShots = job.optInt("requiredShots"), cycleSeconds = job.optInt("cycleSeconds"), estimatedMinutes = job.optInt("estimatedMinutes"),
                resinCode = job.text("resinCode"), requiredResinKg = job.optDouble("requiredResinKg"), requiredColorGrams = job.optDouble("requiredColorGrams"),
                compatibleMachineIds = job.arr("compatibleMachineIds").stringValues().toSet(), machineId = job.nullableText("machineId"),
                brigadeId = job.nullableText("brigadeId"), shiftId = job.nullableText("shiftId"), priority = job.optInt("priority"),
                status = job.enum("status", TpJobStatus.UNASSIGNED), materialStatus = job.enum("materialStatus", TpMaterialStatus.PLANNED),
                materialConfirmedAt = job.nullableText("materialConfirmedAt"), materialDeliveredAt = job.nullableText("materialDeliveredAt")
            )
        },
        attendance = root.arr("attendance").objects().map { TpAttendance(it.text("id"), it.text("workerId"), it.text("brigadeId"), it.text("shiftId"), it.text("date"), it.optBoolean("present"), it.optInt("workMinutes"), it.text("updatedAt")) },
        receipts = root.arr("receipts").objects().map { TpReceipt(it.text("id"), it.text("jobId"), it.text("orderId"), it.text("detailId"), it.text("detailNameSnapshot"), it.text("machineId"), it.text("workerId"), it.text("workerNameSnapshot"), it.text("brigadeId"), it.text("shiftId"), it.text("date"), it.text("colorCode"), it.optInt("completedBags"), it.optInt("bagCapacity"), it.optInt("carryInPieces"), it.optInt("remainderAfter"), it.optInt("creditedPieces"), it.optLong("unitPriceSnapshot"), it.text("receiverName"), it.text("createdAt")) },
        qualityRounds = root.arr("qualityRounds").objects().map { TpQualityRound(it.text("id"), it.text("brigadeId"), it.text("shiftId"), it.text("machineId"), it.text("workerId"), it.text("jobId"), it.text("date"), it.optInt("round"), it.text("scheduledTime"), it.optInt("score"), it.text("issue"), it.text("checkedBy"), it.text("checkedAt")) },
        dailyIssues = root.arr("dailyIssues").objects().map { TpDailyIssue(it.text("id"), it.text("brigadeId"), it.text("date"), it.nullableText("machineId"), it.nullableText("orderId"), it.text("title"), it.text("note"), it.text("createdAt")) },
        auditLog = root.arr("auditLog").objects().map { TpAuditEntry(it.text("id"), it.text("action"), it.nullableText("brigadeId"), it.nullableText("recordDate"), it.text("details"), it.text("createdAt")) },
        settings = root.optJSONObject("settings")?.let { TpSettings(it.optBoolean("firstBatchEntered"), it.optInt("priceRevision")) } ?: TpSettings()
    )

    private fun <T> array(values: Iterable<T>, block: (JSONObject, T) -> Unit): JSONArray = JSONArray().apply {
        values.forEach { value -> put(JSONObject().also { block(it, value) }) }
    }

    private fun strings(values: Iterable<String>): JSONArray = JSONArray().apply { values.forEach { value -> put(value) } }
    private fun JSONObject.putNullable(key: String, value: String?): JSONObject = put(key, value ?: JSONObject.NULL)

    companion object {
        private const val PREFS_NAME = "toy_bola_tp_data_v1"
        private const val KEY_DATA = "tp_data"
    }
}

private fun String.cleanText(): String = trim().replace(Regex("\\s+"), " ")
private fun JSONObject.arr(key: String): JSONArray = optJSONArray(key) ?: JSONArray()
private fun JSONArray.objects(): List<JSONObject> = buildList {
    repeat(length()) { index -> optJSONObject(index)?.let(::add) }
}
private fun JSONArray.stringValues(): List<String> = buildList {
    repeat(length()) { index -> optString(index, "").trim().takeIf { it.isNotBlank() }?.let(::add) }
}
private fun JSONObject.text(key: String, fallback: String = ""): String = optString(key, fallback).takeUnless { it == "null" } ?: fallback
private fun JSONObject.nullableText(key: String): String? = if (isNull(key)) null else optString(key).takeIf { it.isNotBlank() }
private inline fun <reified T : Enum<T>> JSONObject.enum(key: String, fallback: T): T = runCatching { enumValueOf<T>(optString(key)) }.getOrDefault(fallback)
