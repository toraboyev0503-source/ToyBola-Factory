package uz.toybola.factory.core.data

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.util.Locale
import kotlin.math.ceil

enum class TpMaterialType { RESIN, COLOR }
enum class TpOrderStatus { NEW, PLANNING, READY, IN_PROGRESS, COMPLETE, CANCELLED }
enum class TpJobStatus { UNASSIGNED, QUEUED, IN_PROGRESS, COMPLETE, HOLD }
enum class TpMaterialStatus { PLANNED, CONFIRMED, DELIVERED }

data class TpShop(
    val id: String,
    val name: String,
    val archived: Boolean = false
)

data class TpShift(
    val id: String,
    val name: String,
    val startTime: String,
    val endTime: String,
    val roundTimes: List<String>,
    val archived: Boolean = false
) {
    fun durationMinutes(): Int {
        val start = LocalTime.parse(startTime)
        val end = LocalTime.parse(endTime)
        val raw = Duration.between(start, end).toMinutes()
        return (if (raw <= 0) raw + 24 * 60 else raw).toInt()
    }
}

data class TpBrigade(
    val id: String,
    val shopId: String,
    val shiftId: String,
    val name: String,
    val archived: Boolean = false
)

data class TpMachine(
    val id: String,
    val shopId: String,
    val number: Int,
    val name: String = "",
    val archived: Boolean = false
)

data class TpWorker(
    val id: String,
    val brigadeId: String,
    val name: String,
    val dailyTargetAmount: Long,
    val defaultWorkMinutes: Int,
    val archived: Boolean = false
)

data class TpColorRule(
    val colorCode: String,
    val share: Double,
    val gramsPer25Kg: Double
)

/**
 * A detail is one required component of a finished toy. Details that come from the same mould
 * share [moldCode]. Each detail still keeps its own output-per-shot and product requirement.
 */
data class TpDetail(
    val id: String,
    val name: String,
    val moldCode: String,
    val requiredPerProduct: Int,
    val piecesPerShot: Int,
    val bagCapacity: Int,
    val cycleSeconds: Int,
    val grossShotWeightGrams: Double,
    val unusableShotWeightGrams: Double,
    val resinCode: String,
    val unitPrice: Long,
    val compatibleMachineIds: Set<String>,
    val colors: List<TpColorRule>,
    val archived: Boolean = false
) {
    fun estimatedPiecesIn12Hours(): Int = if (cycleSeconds > 0) (12 * 60 * 60 / cycleSeconds) * piecesPerShot else 0
}

data class TpProduct(
    val id: String,
    val article: String,
    val name: String,
    val details: List<TpDetail> = emptyList(),
    val archived: Boolean = false
)

data class TpMaterial(
    val id: String,
    val code: String,
    val name: String,
    val type: TpMaterialType,
    /** Resin is stored in kilograms, color in grams. */
    val availableAmount: Double,
    val archived: Boolean = false
)

data class TpOrder(
    val id: String,
    val batchNumber: String,
    val productId: String,
    val articleSnapshot: String,
    val productNameSnapshot: String,
    val quantity: Int,
    val priority: Int,
    val requestedDate: String,
    val note: String,
    val status: TpOrderStatus,
    val createdAt: String,
    val completedAt: String? = null
)

data class TpJobOutput(
    val detailId: String,
    val detailName: String,
    val requiredPieces: Int,
    val plannedPieces: Int,
    val piecesPerShot: Int,
    val bagCapacity: Int,
    val unitPrice: Long
) {
    val extraPieces: Int get() = (plannedPieces - requiredPieces).coerceAtLeast(0)
}

data class TpPlanJob(
    val id: String,
    val orderId: String,
    val moldCode: String,
    val colorCode: String,
    val outputs: List<TpJobOutput>,
    val requiredShots: Int,
    val cycleSeconds: Int,
    val estimatedMinutes: Int,
    val resinCode: String,
    val requiredResinKg: Double,
    val requiredColorGrams: Double,
    val compatibleMachineIds: Set<String>,
    val machineId: String? = null,
    val brigadeId: String? = null,
    val shiftId: String? = null,
    val priority: Int,
    val status: TpJobStatus = TpJobStatus.UNASSIGNED,
    val materialStatus: TpMaterialStatus = TpMaterialStatus.PLANNED,
    val materialConfirmedAt: String? = null,
    val materialDeliveredAt: String? = null
)

data class TpAttendance(
    val id: String,
    val workerId: String,
    val brigadeId: String,
    val shiftId: String,
    val date: String,
    val present: Boolean,
    val workMinutes: Int,
    val updatedAt: String
)

/**
 * [completedBags] is the number of physically closed bags. [creditedPieces] excludes the pieces
 * already credited to the previous shift's open bag, preventing a 30 + 70 bag becoming 30 + 100.
 */
data class TpReceipt(
    val id: String,
    val jobId: String,
    val orderId: String,
    val detailId: String,
    val detailNameSnapshot: String,
    val machineId: String,
    val workerId: String,
    val workerNameSnapshot: String,
    val brigadeId: String,
    val shiftId: String,
    val date: String,
    val colorCode: String,
    val completedBags: Int,
    val bagCapacity: Int,
    val carryInPieces: Int,
    val remainderAfter: Int,
    val creditedPieces: Int,
    val unitPriceSnapshot: Long,
    val receiverName: String,
    val createdAt: String
) {
    val earnedAmount: Long get() = creditedPieces.toLong() * unitPriceSnapshot
}

data class TpQualityRound(
    val id: String,
    val brigadeId: String,
    val shiftId: String,
    val machineId: String,
    val workerId: String,
    val jobId: String,
    val date: String,
    val round: Int,
    val scheduledTime: String,
    val score: Int,
    val issue: String,
    val checkedBy: String,
    val checkedAt: String
)

data class TpDailyIssue(
    val id: String,
    val brigadeId: String,
    val date: String,
    val machineId: String?,
    val orderId: String?,
    val title: String,
    val note: String,
    val createdAt: String
)

data class TpAuditEntry(
    val id: String,
    val action: String,
    val brigadeId: String? = null,
    val recordDate: String? = null,
    val details: String,
    val createdAt: String
)

data class TpSettings(
    val firstBatchEntered: Boolean = false,
    val priceRevision: Int = 0
)

data class TpData(
    val shops: List<TpShop> = emptyList(),
    val shifts: List<TpShift> = emptyList(),
    val brigades: List<TpBrigade> = emptyList(),
    val machines: List<TpMachine> = emptyList(),
    val workers: List<TpWorker> = emptyList(),
    val products: List<TpProduct> = emptyList(),
    val materials: List<TpMaterial> = emptyList(),
    val orders: List<TpOrder> = emptyList(),
    val jobs: List<TpPlanJob> = emptyList(),
    val attendance: List<TpAttendance> = emptyList(),
    val receipts: List<TpReceipt> = emptyList(),
    val qualityRounds: List<TpQualityRound> = emptyList(),
    val dailyIssues: List<TpDailyIssue> = emptyList(),
    val auditLog: List<TpAuditEntry> = emptyList(),
    val settings: TpSettings = TpSettings()
) {
    fun orderProgress(orderId: String): Double {
        val orderJobs = jobs.filter { it.orderId == orderId }
        val required = orderJobs.sumOf { job -> job.outputs.sumOf { it.requiredPieces } }
        if (required <= 0) return 0.0
        val received = orderJobs.sumOf { job ->
            job.outputs.sumOf { output ->
                receipts.filter { it.jobId == job.id && it.detailId == output.detailId }
                    .sumOf { it.creditedPieces }
                    .coerceAtMost(output.requiredPieces)
            }
        }
        return received * 100.0 / required
    }

    fun openRemainder(jobId: String, detailId: String): Int = receipts
        .filter { it.jobId == jobId && it.detailId == detailId }
        .maxByOrNull { it.createdAt }
        ?.remainderAfter
        ?: 0

    fun workerEarned(workerId: String, date: String): Long = receipts
        .filter { it.workerId == workerId && it.date == date }
        .sumOf { it.earnedAmount }

    fun workerQuality(workerId: String, date: String): Double? = qualityRounds
        .filter { it.workerId == workerId && it.date == date }
        .map { it.score }
        .takeIf { it.isNotEmpty() }
        ?.average()

    fun workerEfficiency(workerId: String, date: String): Double? {
        val worker = workers.firstOrNull { it.id == workerId } ?: return null
        val day = attendance.firstOrNull { it.workerId == workerId && it.date == date } ?: return null
        if (!day.present || day.workMinutes <= 0 || worker.dailyTargetAmount <= 0 || worker.defaultWorkMinutes <= 0) return null
        val target = worker.dailyTargetAmount.toDouble() * day.workMinutes / worker.defaultWorkMinutes
        return if (target > 0) workerEarned(workerId, date) * 100.0 / target else null
    }

    fun workerUsefulness(workerId: String, date: String): Double? {
        val efficiency = workerEfficiency(workerId, date) ?: return null
        val quality = workerQuality(workerId, date) ?: return null
        return (efficiency + quality) / 2.0
    }

    fun activeJobsForMachine(machineId: String): List<TpPlanJob> = jobs
        .filter { it.machineId == machineId && it.status != TpJobStatus.COMPLETE }
        .sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id })
}

fun allocateByColor(total: Int, colors: List<TpColorRule>): Map<String, Int> {
    if (total <= 0) return emptyMap()
    val valid = colors.filter { it.colorCode.isNotBlank() && it.share > 0.0 }
    if (valid.isEmpty()) return mapOf("000" to total)
    val sum = valid.sumOf { it.share }
    val raw = valid.map { rule -> rule to total * rule.share / sum }
    val base = raw.associate { (rule, value) -> rule.colorCode to value.toInt() }.toMutableMap()
    var remaining = total - base.values.sum()
    raw.sortedByDescending { (_, value) -> value - value.toInt() }.forEach { (rule, _) ->
        if (remaining > 0) {
            base[rule.colorCode] = base.getValue(rule.colorCode) + 1
            remaining--
        }
    }
    return base
}

fun nextBatchNumber(previous: String): String {
    val match = Regex("^(.*?)(\\d+)$").matchEntire(previous.trim())
    if (match != null) {
        val prefix = match.groupValues[1]
        val digits = match.groupValues[2]
        val next = digits.toLongOrNull()?.plus(1) ?: return "${previous.trim()}-2"
        return prefix + next.toString().padStart(digits.length, '0')
    }
    return "${previous.trim()}-2"
}

fun calculateReceiptCredit(
    bagCapacity: Int,
    carryInPieces: Int,
    completedBags: Int,
    remainderAfter: Int
): Int {
    require(bagCapacity > 0) { "Qop sig‘imi 0 dan katta bo‘lsin" }
    require(carryInPieces in 0 until bagCapacity) { "Oldingi qoldiq noto‘g‘ri" }
    require(completedBags >= 0) { "Qop soni manfiy bo‘lmasin" }
    require(remainderAfter in 0 until bagCapacity) { "Yangi qoldiq qop sig‘imidan kam bo‘lsin" }
    val credited = completedBags * bagCapacity - carryInPieces + remainderAfter
    require(credited > 0) { "Yangi ishlab chiqarilgan son 0 dan katta bo‘lsin" }
    return credited
}

fun buildPlanJobs(data: TpData, order: TpOrder, idFactory: () -> String): List<TpPlanJob> {
    val product = data.products.firstOrNull { it.id == order.productId } ?: error("Mahsulot topilmadi")
    require(product.details.any { !it.archived }) { "Mahsulot detallari kiritilmagan" }
    var sequence = 0
    return product.details.filterNot { it.archived }.groupBy { it.moldCode.ifBlank { it.id } }.flatMap { (moldCode, details) ->
        require(details.map { it.resinCode.trim().uppercase(Locale.ROOT) }.distinct().size == 1) {
            "$moldCode qolipida birga chiqadigan detallar seryosi bir xil bo‘lsin"
        }
        val colorSignatures = details.map { detail ->
            detail.colors.sortedBy { it.colorCode.uppercase(Locale.ROOT) }
                .map { Triple(it.colorCode.trim().uppercase(Locale.ROOT), it.share, it.gramsPer25Kg) }
        }
        require(colorSignatures.distinct().size == 1) {
            "$moldCode qolipida birga chiqadigan detallar rang taqsimoti bir xil bo‘lsin"
        }
        val allocations = details.associateWith { detail ->
            allocateByColor(order.quantity * detail.requiredPerProduct, detail.colors)
        }
        val colorCodes = allocations.values.flatMap { it.keys }.distinct()
        colorCodes.mapNotNull { colorCode ->
            val requiredByDetail = details.mapNotNull { detail ->
                val required = allocations.getValue(detail)[colorCode] ?: 0
                if (required > 0) detail to required else null
            }
            if (requiredByDetail.isEmpty()) return@mapNotNull null
            val shots = requiredByDetail.maxOf { (detail, required) ->
                ceil(required.toDouble() / detail.piecesPerShot.coerceAtLeast(1)).toInt()
            }
            val outputs = requiredByDetail.map { (detail, required) ->
                TpJobOutput(
                    detailId = detail.id,
                    detailName = detail.name,
                    requiredPieces = required,
                    plannedPieces = shots * detail.piecesPerShot,
                    piecesPerShot = detail.piecesPerShot,
                    bagCapacity = detail.bagCapacity,
                    unitPrice = detail.unitPrice
                )
            }
            val reference = requiredByDetail.first().first
            val cycleSeconds = details.maxOf { it.cycleSeconds }
            val grossGrams = details.maxOf { it.grossShotWeightGrams }
            val resinKg = shots * grossGrams / 1000.0
            val colorRule = reference.colors.firstOrNull { it.colorCode == colorCode }
            val colorGrams = resinKg / 25.0 * (colorRule?.gramsPer25Kg ?: 0.0)
            val compatibleSets = details.map { it.compatibleMachineIds }.filter { it.isNotEmpty() }
            val intersection = compatibleSets.drop(1).fold(compatibleSets.firstOrNull().orEmpty()) { result, set -> result intersect set }
            require(compatibleSets.size < 2 || intersection.isNotEmpty()) {
                "$moldCode qolipidagi detallar uchun umumiy mos stanok topilmadi"
            }
            val compatible = intersection
            sequence++
            TpPlanJob(
                id = idFactory(),
                orderId = order.id,
                moldCode = moldCode,
                colorCode = colorCode,
                outputs = outputs,
                requiredShots = shots,
                cycleSeconds = cycleSeconds,
                estimatedMinutes = ceil(shots * cycleSeconds / 60.0).toInt(),
                resinCode = reference.resinCode,
                requiredResinKg = roundMaterial(resinKg),
                requiredColorGrams = roundMaterial(colorGrams),
                compatibleMachineIds = compatible,
                priority = order.priority * 100 + sequence
            )
        }
    }
}

fun formatTpNumber(value: Double): String = BigDecimal.valueOf(value).stripTrailingZeros().toPlainString()

private fun roundMaterial(value: Double): Double = BigDecimal.valueOf(value)
    .setScale(3, RoundingMode.HALF_UP)
    .toDouble()

fun isoToday(): String = LocalDate.now().toString()
