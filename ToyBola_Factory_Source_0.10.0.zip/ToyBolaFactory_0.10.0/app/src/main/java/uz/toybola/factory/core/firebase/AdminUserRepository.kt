package uz.toybola.factory.core.firebase

import android.content.Context
import com.google.firebase.functions.FirebaseFunctions

data class AdminManagedUser(
    val uid: String,
    val userCode: String,
    val displayName: String,
    val role: String,
    val enabled: Boolean,
    val allBrigades: Boolean,
    val allowedBrigadeIds: Set<String>,
    val permissions: Map<String, Boolean>,
    val revision: Long
)

data class GeneratedUserCredentials(
    val userCode: String,
    val deviceCode: String
)

data class AdminUserDraft(
    val displayName: String,
    val role: String,
    val enabled: Boolean = true,
    val allBrigades: Boolean = false,
    val allowedBrigadeIds: Set<String> = emptySet(),
    val permissions: Map<String, Boolean> = emptyMap()
)

class AdminUserRepository(context: Context) {
    private val functions = FirebaseFunctions.getInstance("europe-west1")

    suspend fun listUsers(): Result<List<AdminManagedUser>> = runCatching {
        val result = functions.getHttpsCallable("adminListUsers").call().awaitResult()
        val root = result.data as? Map<*, *> ?: error("Server javobi noto‘g‘ri")
        (root["users"] as? List<*>).orEmpty()
            .mapNotNull { parseUser(it as? Map<*, *> ?: return@mapNotNull null) }
            .sortedWith(compareByDescending<AdminManagedUser> { it.enabled }.thenBy { it.displayName.lowercase() })
    }

    suspend fun createUser(draft: AdminUserDraft): Result<Pair<AdminManagedUser, GeneratedUserCredentials>> = runCatching {
        val result = functions.getHttpsCallable("adminCreateUser").call(draft.toPayload()).awaitResult()
        val root = result.data as? Map<*, *> ?: error("Server javobi noto‘g‘ri")
        val user = parseUser(root["user"] as? Map<*, *> ?: error("Foydalanuvchi javobi yo‘q"))
            ?: error("Foydalanuvchi javobi noto‘g‘ri")
        val credentials = root["credentials"] as? Map<*, *> ?: error("Kirish kodlari olinmadi")
        user to GeneratedUserCredentials(
            userCode = credentials["userCode"]?.toString().orEmpty(),
            deviceCode = credentials["deviceCode"]?.toString().orEmpty()
        )
    }

    suspend fun updateUser(uid: String, draft: AdminUserDraft): Result<AdminManagedUser> = runCatching {
        val payload = draft.toPayload().toMutableMap().apply { put("uid", uid) }
        val result = functions.getHttpsCallable("adminUpdateUser").call(payload).awaitResult()
        val root = result.data as? Map<*, *> ?: error("Server javobi noto‘g‘ri")
        parseUser(root) ?: error("Foydalanuvchi javobi noto‘g‘ri")
    }

    suspend fun resetDeviceCode(uid: String): Result<String> = runCatching {
        val result = functions.getHttpsCallable("adminResetDeviceCode")
            .call(mapOf("uid" to uid))
            .awaitResult()
        val root = result.data as? Map<*, *> ?: error("Server javobi noto‘g‘ri")
        root["deviceCode"]?.toString()?.takeIf { it.isNotBlank() }
            ?: error("Yangi qurilma kodi olinmadi")
    }

    private fun AdminUserDraft.toPayload(): Map<String, Any> = mapOf(
        "displayName" to displayName.trim(),
        "role" to role.trim().uppercase(),
        "enabled" to enabled,
        "allBrigades" to allBrigades,
        "allowedBrigadeIds" to allowedBrigadeIds.toList(),
        "permissions" to permissions
    )

    private fun parseUser(raw: Map<*, *>): AdminManagedUser? {
        val uid = raw["uid"]?.toString().orEmpty()
        if (uid.isBlank()) return null
        val permissions = (raw["permissions"] as? Map<*, *>).orEmpty()
            .mapNotNull { (key, value) -> key?.toString()?.let { it to (value == true) } }
            .toMap()
        return AdminManagedUser(
            uid = uid,
            userCode = raw["userCode"]?.toString().orEmpty(),
            displayName = raw["displayName"]?.toString().orEmpty(),
            role = raw["role"]?.toString().orEmpty(),
            enabled = raw["enabled"] as? Boolean == true,
            allBrigades = raw["allBrigades"] as? Boolean == true,
            allowedBrigadeIds = (raw["allowedBrigadeIds"] as? List<*>)
                .orEmpty().mapNotNull { item -> item?.toString()?.takeIf { text -> text.isNotBlank() } }.toSet(),
            permissions = permissions,
            revision = (raw["revision"] as? Number)?.toLong() ?: 0L
        )
    }
}
