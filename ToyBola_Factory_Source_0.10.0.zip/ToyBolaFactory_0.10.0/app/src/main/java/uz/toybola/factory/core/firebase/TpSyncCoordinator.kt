package uz.toybola.factory.core.firebase

import android.content.Context
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.security.UserAccessPolicy

class TpSyncCoordinator(context: Context) {
    private val appContext = context.applicationContext
    private val repository = TpDataRepository(appContext)
    private val outbox = TpSyncOutbox(appContext)
    private val db = FirebaseFirestore.getInstance()

    suspend fun sync(policy: UserAccessPolicy, uid: String) {
        flushOutbox(uid)
        val snapshot = ServerTpSnapshotRepository(appContext).download().getOrThrow()
        if (!snapshot.hasData && policy.isAdmin()) {
            outbox.markAll(repository.load())
            flushOutbox(uid)
            return
        }
        repository.replaceFromServer(merge(repository.load(), snapshot.data, snapshot.hasSettings))
    }

    private suspend fun flushOutbox(uid: String) {
        val keys = outbox.pending().sorted()
        if (keys.isEmpty()) return
        val local = repository.load()
        keys.chunked(300).forEach { chunk ->
            val batch = db.batch()
            val applied = mutableListOf<String>()
            chunk.forEach { key ->
                if (apply(batch, key, local, uid)) applied += key else applied += key
            }
            if (applied.isNotEmpty()) {
                batch.commit().awaitResult()
                applied.forEach(outbox::remove)
            }
        }
    }

    private fun apply(
        batch: com.google.firebase.firestore.WriteBatch,
        key: String,
        data: TpData,
        uid: String
    ): Boolean {
        val type = key.substringBefore(':')
        val id = key.substringAfter(':', "")
        fun common(payload: String, brigadeId: String? = null): MutableMap<String, Any> = mutableMapOf(
            "payload" to payload,
            "updatedAt" to FieldValue.serverTimestamp(),
            "updatedBy" to uid
        ).apply { brigadeId?.let { put("brigadeId", it) } }
        fun set(collection: String, documentId: String, payloadData: TpData, fields: Map<String, Any> = emptyMap(), brigadeId: String? = null) {
            batch.set(
                db.collection(collection).document(documentId),
                common(repository.encodeForSync(payloadData), brigadeId).apply { putAll(fields) },
                SetOptions.merge()
            )
        }

        when (type) {
            "TP_SHOP" -> data.shops.firstOrNull { it.id == id }?.let {
                set("tpShops", it.id, TpData(shops = listOf(it)), mapOf("name" to it.name, "archived" to it.archived))
            } ?: return false
            "TP_SHIFT" -> data.shifts.firstOrNull { it.id == id }?.let {
                set("tpShifts", it.id, TpData(shifts = listOf(it)), mapOf("name" to it.name, "archived" to it.archived))
            } ?: return false
            "TP_BRIGADE" -> data.brigades.firstOrNull { it.id == id }?.let {
                set("tpBrigades", it.id, TpData(brigades = listOf(it)), mapOf("name" to it.name, "shopId" to it.shopId, "shiftId" to it.shiftId, "archived" to it.archived), it.id)
            } ?: return false
            "TP_MACHINE" -> data.machines.firstOrNull { it.id == id }?.let {
                set("tpMachines", it.id, TpData(machines = listOf(it)), mapOf("number" to it.number, "shopId" to it.shopId, "archived" to it.archived))
            } ?: return false
            "TP_WORKER" -> data.workers.firstOrNull { it.id == id }?.let {
                set("tpWorkers", it.id, TpData(workers = listOf(it)), mapOf("name" to it.name, "archived" to it.archived), it.brigadeId)
            } ?: return false
            "TP_PRODUCT" -> data.products.firstOrNull { it.id == id }?.let {
                set("tpProducts", it.id, TpData(products = listOf(it)), mapOf("article" to it.article, "name" to it.name, "archived" to it.archived))
            } ?: return false
            "TP_MATERIAL" -> data.materials.firstOrNull { it.id == id }?.let {
                set("tpMaterials", it.id, TpData(materials = listOf(it)), mapOf("code" to it.code, "type" to it.type.name, "availableAmount" to it.availableAmount, "archived" to it.archived))
            } ?: return false
            "TP_ORDER" -> data.orders.firstOrNull { it.id == id }?.let {
                set("tpOrders", it.id, TpData(orders = listOf(it)), mapOf("batchNumber" to it.batchNumber, "productId" to it.productId, "status" to it.status.name, "requestedDate" to it.requestedDate))
            } ?: return false
            "TP_JOB" -> data.jobs.firstOrNull { it.id == id }?.let {
                set("tpJobs", it.id, TpData(jobs = listOf(it)), mapOf("orderId" to it.orderId, "machineId" to it.machineId.orEmpty(), "status" to it.status.name, "materialStatus" to it.materialStatus.name), it.brigadeId.orEmpty())
            } ?: return false
            "TP_ATTENDANCE" -> data.attendance.firstOrNull { it.id == id }?.let {
                set("tpAttendance", it.id, TpData(attendance = listOf(it)), mapOf("workerId" to it.workerId, "date" to it.date), it.brigadeId)
            } ?: return false
            "TP_RECEIPT" -> data.receipts.firstOrNull { it.id == id }?.let {
                set("tpReceipts", it.id, TpData(receipts = listOf(it)), mapOf("jobId" to it.jobId, "orderId" to it.orderId, "workerId" to it.workerId, "date" to it.date, "creditedPieces" to it.creditedPieces), it.brigadeId)
            } ?: return false
            "TP_QUALITY" -> data.qualityRounds.firstOrNull { it.id == id }?.let {
                set("tpQualityRounds", it.id, TpData(qualityRounds = listOf(it)), mapOf("jobId" to it.jobId, "workerId" to it.workerId, "date" to it.date, "round" to it.round, "score" to it.score), it.brigadeId)
            } ?: return false
            "TP_ISSUE" -> data.dailyIssues.firstOrNull { it.id == id }?.let {
                set("tpDailyIssues", it.id, TpData(dailyIssues = listOf(it)), mapOf("date" to it.date, "title" to it.title), it.brigadeId)
            } ?: return false
            "TP_AUDIT" -> data.auditLog.firstOrNull { it.id == id }?.let {
                set("tpAuditLog", it.id, TpData(auditLog = listOf(it)), mapOf("action" to it.action, "recordDate" to it.recordDate.orEmpty()), it.brigadeId.orEmpty())
            } ?: return false
            "TP_SETTINGS" -> set("settings", "tp", TpData(settings = data.settings))
            else -> return false
        }
        return true
    }

    private fun merge(local: TpData, remote: TpData, hasSettings: Boolean): TpData = local.copy(
        shops = mergeById(local.shops, remote.shops) { it.id },
        shifts = mergeById(local.shifts, remote.shifts) { it.id },
        brigades = mergeById(local.brigades, remote.brigades) { it.id },
        machines = mergeById(local.machines, remote.machines) { it.id },
        workers = mergeById(local.workers, remote.workers) { it.id },
        products = mergeById(local.products, remote.products) { it.id },
        materials = mergeById(local.materials, remote.materials) { it.id },
        orders = mergeById(local.orders, remote.orders) { it.id },
        jobs = mergeById(local.jobs, remote.jobs) { it.id },
        attendance = mergeById(local.attendance, remote.attendance) { it.id },
        receipts = mergeById(local.receipts, remote.receipts) { it.id },
        qualityRounds = mergeById(local.qualityRounds, remote.qualityRounds) { it.id },
        dailyIssues = mergeById(local.dailyIssues, remote.dailyIssues) { it.id },
        auditLog = mergeById(local.auditLog, remote.auditLog) { it.id }.takeLast(3000),
        settings = if (hasSettings) remote.settings else local.settings
    )

    private fun <T, K> mergeById(local: List<T>, remote: List<T>, id: (T) -> K): List<T> {
        val values = LinkedHashMap<K, T>()
        local.forEach { values[id(it)] = it }
        remote.forEach { values[id(it)] = it }
        return values.values.toList()
    }
}
