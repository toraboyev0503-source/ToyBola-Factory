package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.components.SectionCard
import uz.toybola.factory.ui.model.AppScreen
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate

@Composable
fun TpMainScreen(
    strings: AppStrings,
    onBack: () -> Unit,
    canOpen: (AppScreen) -> Boolean,
    onOpen: (AppScreen) -> Unit
) {
    val items = listOf(
        Triple("Plan", "Zakaz, rejalash, stanok vazifalari va davomat", AppScreen.TP_PLAN),
        Triple("Seryo", "Qorishma hisobi, qoldiq va stanokka yetkazish", AppScreen.TP_SERYO),
        Triple("Qabul qilish", "Qop, qoldiq va ishchilar ishlab chiqarishi", AppScreen.TP_RECEIVING),
        Triple("Sifat", "Smena raundlari va kun muammosi", AppScreen.TP_QUALITY),
        Triple("Monitoring", "Partiya, stanok, brigada va xomashyo nazorati", AppScreen.TP_MONITORING)
    )
    Column(Modifier.fillMaxSize()) {
        AppTopBar("TP va Seryo", canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp)) {
            items.chunked(2).forEachIndexed { rowIndex, row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEachIndexed { index, item ->
                        SectionCard(
                            number = rowIndex * 2 + index + 1,
                            title = item.first,
                            description = item.second,
                            enabled = canOpen(item.third),
                            modifier = if (row.size == 1) Modifier.fillMaxWidth() else Modifier.weight(1f),
                            onClick = { onOpen(item.third) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

private enum class TpPlanPage { ROOT, ORDERS, PLANNING, MACHINES, ATTENDANCE, MASTER }

@Composable
fun TpPlanScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val eventRevision by TpDataEvents.revision.collectAsState()
    var localRevision by remember { mutableIntStateOf(0) }
    val policy = remember(eventRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(eventRevision, localRevision, policy.revision) { repository.load().scopedFor(policy) }
    var page by remember { mutableStateOf(TpPlanPage.ROOT) }
    fun refresh() { localRevision++ }
    fun back() { if (page == TpPlanPage.ROOT) onBack() else page = TpPlanPage.ROOT }
    BackHandler(enabled = page != TpPlanPage.ROOT) { page = TpPlanPage.ROOT }

    val title = when (page) {
        TpPlanPage.ROOT -> "Plan"
        TpPlanPage.ORDERS -> "Nachalnik zakazlari"
        TpPlanPage.PLANNING -> "Plan beruvchi"
        TpPlanPage.MACHINES -> "Stanok vazifalari"
        TpPlanPage.ATTENDANCE -> "Davomat"
        TpPlanPage.MASTER -> "TP ma’lumotlari"
    }
    Column(Modifier.fillMaxSize()) {
        AppTopBar(title, canGoBack = true, onMenu = {}, onBack = ::back)
        when (page) {
            TpPlanPage.ROOT -> TpPlanRoot(policy) { page = it }
            TpPlanPage.ORDERS -> TpOrdersPage(data, repository, policy, ::refresh)
            TpPlanPage.PLANNING -> TpPlanningPage(data, repository, policy, ::refresh)
            TpPlanPage.MACHINES -> TpMachineQueuePage(data, repository, policy, ::refresh)
            TpPlanPage.ATTENDANCE -> TpAttendancePage(data, repository, policy, ::refresh)
            TpPlanPage.MASTER -> TpMasterDataPage(data, repository, policy, ::refresh)
        }
    }
}

@Composable
private fun TpPlanRoot(policy: UserAccessPolicy, onOpen: (TpPlanPage) -> Unit) {
    val items = buildList {
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_ORDER)) add(TpPlanPage.ORDERS to "Nachalnik — zakazlar")
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_PLANNING)) add(TpPlanPage.PLANNING to "Plan beruvchi — hisob va taqsimot")
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_MACHINE)) add(TpPlanPage.MACHINES to "TP brigadir — stanok vazifalari")
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_ATTENDANCE)) add(TpPlanPage.ATTENDANCE to "Plan beruvchi — davomat")
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_MASTER_DATA)) add(TpPlanPage.MASTER to "Mahsulot, qolip, stanok va normativlar")
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Kerakli vazifani tanlang. Ruxsatsiz bo‘limlar ko‘rsatilmaydi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        items.forEach { (page, title) -> TpNavRow(title) { onOpen(page) } }
    }
}

@Composable
private fun TpOrdersPage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_ORDER)
    val canPlan = policy.isAdmin() || policy.canWrite(AssemblySection.TP_PLANNING)
    var showAdd by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (canWrite) Button(onClick = { showAdd = true }, Modifier.fillMaxWidth()) { Text("+ Yangi zakaz") }
        if (data.orders.isEmpty()) Text("Hali zakaz kiritilmagan.")
        data.orders.sortedWith(compareBy<TpOrder> { it.status == TpOrderStatus.COMPLETE }.thenBy { it.priority }.thenByDescending { it.createdAt }).forEach { order ->
            val progress = data.orderProgress(order.id)
            TpCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${order.batchNumber} • ${order.articleSnapshot}", fontWeight = FontWeight.Bold)
                        Text("${order.productNameSnapshot} — ${order.quantity} dona")
                    }
                    Text("${progress.toInt()}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
                Text("Holat: ${orderStatusLabel(order.status)} • Ustuvorlik: ${order.priority}", style = MaterialTheme.typography.bodySmall)
                Text("Kerakli sana: ${order.requestedDate}", style = MaterialTheme.typography.bodySmall)
                if (order.completedAt != null) Text("Yakunlandi: ${order.completedAt.take(16).replace('T', ' ')}", style = MaterialTheme.typography.bodySmall)
                if (canPlan && order.status == TpOrderStatus.NEW) {
                    OutlinedButton(onClick = {
                        error = repo.generateOrderPlan(order.id).exceptionOrNull()?.message
                        if (error == null) refresh()
                    }, Modifier.fillMaxWidth()) { Text("Avtomatik plan hisoblash") }
                }
            }
        }
        TpError(error)
    }
    if (showAdd) TpOrderDialog(data, onDismiss = { showAdd = false }, onSave = { batch, productId, quantity, priority, date, note ->
        val result = repo.createOrder(batch, productId, quantity, priority, date, note)
        error = result.exceptionOrNull()?.message
        if (result.isSuccess) { showAdd = false; refresh() }
        result.isSuccess
    })
}

@Composable
private fun TpOrderDialog(
    data: TpData,
    onDismiss: () -> Unit,
    onSave: (String, String, Int, Int, String, String) -> Boolean
) {
    val products = data.products.filter { !it.archived && it.details.any { detail -> !detail.archived } }.sortedBy { it.article }
    var productId by remember { mutableStateOf(products.firstOrNull()?.id.orEmpty()) }
    var batch by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("1") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var note by remember { mutableStateOf("") }
    var validation by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Yangi zakaz") },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (products.isEmpty()) Text("Avval mahsulot va uning detallarini kiriting.", color = MaterialTheme.colorScheme.error)
                TpChoice("Mahsulot", productId, products, { it.id }, { "${it.article} — ${it.name}" }) { productId = it }
                if (data.orders.isEmpty()) TpField(batch, { batch = it }, "Birinchi partiya raqami")
                else Text("Keyingi partiya raqami avtomatik beriladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                TpField(quantity, { quantity = digitsOnly(it) }, "Zakaz soni", KeyboardType.Number)
                TpField(priority, { priority = digitsOnly(it) }, "Ustuvorlik (1 — eng yuqori)", KeyboardType.Number)
                TpField(date, { date = it }, "Kerakli sana (YYYY-MM-DD)")
                TpField(note, { note = it }, "Izoh", singleLine = false)
                TpError(validation)
            }
        },
        confirmButton = { TextButton(enabled = products.isNotEmpty(), onClick = {
            val qty = quantity.toIntOrNull()
            val pr = priority.toIntOrNull()
            validation = when {
                productId.isBlank() || qty == null || pr == null -> "Majburiy maydonlarni to‘ldiring"
                else -> null
            }
            if (validation == null && onSave(batch, productId, qty!!, pr!!, date, note)) onDismiss()
        }) { Text("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

@Composable
private fun TpPlanningPage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_PLANNING)
    var assignJob by remember { mutableStateOf<TpPlanJob?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val jobs = data.jobs.filter { it.status != TpJobStatus.COMPLETE }
        .sortedWith(compareBy<TpPlanJob> { it.machineId != null }.thenBy { it.priority })
    val activeJobs = data.jobs.filter { it.status != TpJobStatus.COMPLETE }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Qolip, rang, jim, xomashyo va vaqt avtomatik hisoblangan. Mos stanokni tanlang.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (jobs.isEmpty()) Text("Plan vazifasi yo‘q. Zakaz ichidan “Avtomatik plan hisoblash”ni bosing.")
        jobs.forEach { job ->
            val order = data.orders.firstOrNull { it.id == job.orderId }
            val machine = data.machines.firstOrNull { it.id == job.machineId }
            TpCard {
                Text("${order?.batchNumber.orEmpty()} • ${job.moldCode} • rang ${job.colorCode}", fontWeight = FontWeight.Bold)
                job.outputs.forEach { output ->
                    val fullBags = output.requiredPieces / output.bagCapacity
                    val remainder = output.requiredPieces % output.bagCapacity
                    val bags = if (remainder == 0) "$fullBags qop" else "$fullBags qop + $remainder dona"
                    Text("${output.detailName}: ${output.requiredPieces} dona ($bags) • ${job.requiredShots} jim • ortiqcha ${output.extraPieces}")
                }
                Text("${formatTpNumber(job.requiredResinKg)} kg ${job.resinCode} + ${formatTpNumber(job.requiredColorGrams)} g rang", color = MaterialTheme.colorScheme.primary)
                Text("Taxminiy vaqt: ${minutesLabel(job.estimatedMinutes)}", style = MaterialTheme.typography.bodySmall)
                Text(if (machine == null) "Stanok belgilanmagan" else "Stanok ${machine.number} • navbat ${job.priority}", fontWeight = FontWeight.SemiBold)
                val resin = data.materials.firstOrNull { it.type == TpMaterialType.RESIN && it.code.equals(job.resinCode, true) }
                val color = data.materials.firstOrNull { it.type == TpMaterialType.COLOR && it.code.equals(job.colorCode, true) }
                val totalResinNeed = activeJobs.filter { it.resinCode.equals(job.resinCode, true) }.sumOf { it.requiredResinKg }
                val totalColorNeed = activeJobs.filter { it.colorCode.equals(job.colorCode, true) }.sumOf { it.requiredColorGrams }
                val enough = (resin?.availableAmount ?: 0.0) >= totalResinNeed && (color?.availableAmount ?: 0.0) >= totalColorNeed
                Text(if (enough) "Barcha faol zakazlarga xomashyo yetadi" else "Barcha faol zakazlarga xomashyo yetmaydi yoki qoldiq kiritilmagan", color = if (enough) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                if (canWrite) OutlinedButton(onClick = { assignJob = job }, Modifier.fillMaxWidth()) {
                    Text(if (machine == null) "Stanok va brigada belgilash" else "Taqsimotni o‘zgartirish")
                }
            }
        }
        TpError(error)
    }
    assignJob?.let { job ->
        TpAssignDialog(data, job, onDismiss = { assignJob = null }, onSave = { machineId, brigadeId, priority ->
            val result = repo.assignJob(job.id, machineId, brigadeId, priority)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { assignJob = null; refresh() }
            result.isSuccess
        })
    }
}

@Composable
private fun TpAssignDialog(data: TpData, job: TpPlanJob, onDismiss: () -> Unit, onSave: (String, String, Int) -> Boolean) {
    val machines = data.machines.filter { !it.archived && (job.compatibleMachineIds.isEmpty() || it.id in job.compatibleMachineIds) }.sortedBy { it.number }
    var machineId by remember { mutableStateOf(job.machineId ?: machines.firstOrNull()?.id.orEmpty()) }
    val selectedMachine = machines.firstOrNull { it.id == machineId }
    val brigades = data.brigades.filter { !it.archived && (selectedMachine == null || it.shopId == selectedMachine.shopId) }.sortedBy { it.name }
    var brigadeId by remember(machineId) { mutableStateOf(job.brigadeId?.takeIf { id -> brigades.any { it.id == id } } ?: brigades.firstOrNull()?.id.orEmpty()) }
    var priority by remember { mutableStateOf(job.priority.toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Vazifani stanokka rejalash") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (machines.isEmpty()) Text("Bu qolipga mos stanok kiritilmagan.", color = MaterialTheme.colorScheme.error)
            TpChoice("Stanok", machineId, machines, { it.id }, { "${it.number}-stanok" }) { machineId = it }
            TpChoice("Brigada", brigadeId, brigades, { it.id }, { it.name }) { brigadeId = it }
            TpField(priority, { priority = digitsOnly(it) }, "Navbat raqami", KeyboardType.Number)
        } },
        confirmButton = { TextButton(enabled = machineId.isNotBlank() && brigadeId.isNotBlank(), onClick = {
            priority.toIntOrNull()?.let { if (onSave(machineId, brigadeId, it)) onDismiss() }
        }) { Text("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

@Composable
private fun TpMachineQueuePage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_MACHINE)
    var error by remember { mutableStateOf<String?>(null) }
    val assigned = data.jobs.filter { it.machineId != null && it.status != TpJobStatus.COMPLETE }.groupBy { it.machineId!! }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (assigned.isEmpty()) Text("Stanokka biriktirilgan vazifa yo‘q.")
        assigned.entries.sortedBy { (machineId, _) -> data.machines.firstOrNull { it.id == machineId }?.number }.forEach { (machineId, jobs) ->
            val machine = data.machines.firstOrNull { it.id == machineId }
            Text("${machine?.number ?: 0}-stanok", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            jobs.sortedBy { it.priority }.forEachIndexed { index, job ->
                val order = data.orders.firstOrNull { it.id == job.orderId }
                TpCard {
                    Text("${index + 1}. ${order?.batchNumber.orEmpty()} • ${job.moldCode} • ${job.colorCode}", fontWeight = FontWeight.Bold)
                    job.outputs.forEach { output ->
                        val fullBags = output.requiredPieces / output.bagCapacity
                        val remainder = output.requiredPieces % output.bagCapacity
                        Text("${output.detailName}: ${output.requiredPieces} dona • $fullBags qop${if (remainder > 0) " + $remainder dona" else ""}")
                    }
                    Text("Seryo: ${materialStatusLabel(job.materialStatus)}")
                    Text("Vazifa: ${jobStatusLabel(job.status)}")
                    if (canWrite) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (job.status == TpJobStatus.QUEUED) OutlinedButton(onClick = {
                            error = repo.setJobStatus(job.id, TpJobStatus.IN_PROGRESS).exceptionOrNull()?.message
                            if (error == null) refresh()
                        }, Modifier.weight(1f)) { Text("Boshlash") }
                        val completeReady = job.outputs.all { output ->
                            data.receipts.filter { it.jobId == job.id && it.detailId == output.detailId }
                                .sumOf { it.creditedPieces } >= output.requiredPieces
                        }
                        if (job.status == TpJobStatus.IN_PROGRESS && completeReady) OutlinedButton(onClick = {
                            error = repo.setJobStatus(job.id, TpJobStatus.COMPLETE).exceptionOrNull()?.message
                            if (error == null) refresh()
                        }, Modifier.weight(1f)) { Text("Yakunlash") }
                        OutlinedButton(onClick = {
                            error = repo.setJobStatus(job.id, if (job.status == TpJobStatus.HOLD) TpJobStatus.QUEUED else TpJobStatus.HOLD).exceptionOrNull()?.message
                            if (error == null) refresh()
                        }, Modifier.weight(1f)) { Text(if (job.status == TpJobStatus.HOLD) "Qaytarish" else "Kutish") }
                    }
                }
            }
        }
        TpError(error)
    }
}

@Composable
private fun TpAttendancePage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_ATTENDANCE)
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    val brigades = data.brigades.filterNot { it.archived }.sortedBy { it.name }
    var brigadeId by remember { mutableStateOf(brigades.firstOrNull()?.id.orEmpty()) }
    var editWorker by remember { mutableStateOf<TpWorker?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val workers = data.workers.filter { !it.archived && it.brigadeId == brigadeId }.sortedBy { it.name }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Davomatni TP plan beruvchi kiritadi. Ish vaqti normativ hisobiga avtomatik ta’sir qiladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        TpField(date, { date = it }, "Sana (YYYY-MM-DD)")
        TpChoice("Brigada", brigadeId, brigades, { it.id }, { it.name }) { brigadeId = it }
        if (workers.isEmpty()) Text("Bu brigadada ishchi yo‘q.")
        workers.forEach { worker ->
            val day = data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }
            TpCard(Modifier.clickable(enabled = canWrite) { editWorker = worker }) {
                Text(worker.name, fontWeight = FontWeight.Bold)
                Text(if (day == null) "Kiritilmagan • avtomatik ${worker.defaultWorkMinutes} daqiqa" else if (day.present) "Ishda • ${day.workMinutes} daqiqa" else "Ishlamadi")
                Text("Kunlik norma: ${worker.dailyTargetAmount} so‘m", style = MaterialTheme.typography.bodySmall)
            }
        }
        TpError(error)
    }
    editWorker?.let { worker ->
        val existing = data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }
        var present by remember(worker.id, date) { mutableStateOf(existing?.present ?: true) }
        var minutes by remember(worker.id, date) { mutableStateOf((existing?.workMinutes ?: worker.defaultWorkMinutes).toString()) }
        AlertDialog(
            onDismissRequest = { editWorker = null },
            title = { Text(worker.name) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Ishda", Modifier.weight(1f)); Switch(present, { present = it; if (!it) minutes = "0" }) }
                TpField(minutes, { minutes = digitsOnly(it) }, "Ishlagan daqiqa", KeyboardType.Number, enabled = present)
            } },
            confirmButton = { TextButton(onClick = {
                val result = repo.setAttendance(worker.id, date, present, minutes.toIntOrNull() ?: 0)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { editWorker = null; refresh() }
            }) { Text("Saqlash") } },
            dismissButton = { TextButton(onClick = { editWorker = null }) { Text("Bekor qilish") } }
        )
    }
}

@Composable
internal fun TpNavRow(title: String, onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            Text("›", style = MaterialTheme.typography.headlineSmall)
        }
    }
}

@Composable
internal fun TpCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp), content = content)
    }
}

@Composable
internal fun TpField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    enabled: Boolean = true
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType), singleLine = singleLine, enabled = enabled
    )
}

@Composable
internal fun <T> TpChoice(
    label: String,
    selectedId: String,
    options: List<T>,
    id: (T) -> String,
    text: (T) -> String,
    onSelect: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val selected = options.firstOrNull { id(it) == selectedId }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: ${selected?.let(text) ?: "Tanlang"}", Modifier.weight(1f))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(text(option)) }, onClick = { open = false; onSelect(id(option)) }) }
        }
    }
}

@Composable
internal fun TpError(message: String?) {
    if (!message.isNullOrBlank()) Text(message, color = MaterialTheme.colorScheme.error)
}

internal fun digitsOnly(value: String): String = value.filter(Char::isDigit)
internal fun decimalInput(value: String): String {
    var separator = false
    return buildString {
        value.forEach { char ->
            if (char.isDigit()) append(char)
            else if ((char == '.' || char == ',') && !separator) { append('.'); separator = true }
        }
    }
}
internal fun minutesLabel(minutes: Int): String = "${minutes / 60} soat ${minutes % 60} daqiqa"
internal fun orderStatusLabel(status: TpOrderStatus): String = when (status) {
    TpOrderStatus.NEW -> "Yangi"; TpOrderStatus.PLANNING -> "Rejalanmoqda"; TpOrderStatus.READY -> "Tayyor"
    TpOrderStatus.IN_PROGRESS -> "Quyilmoqda"; TpOrderStatus.COMPLETE -> "Yakunlangan"; TpOrderStatus.CANCELLED -> "Bekor qilingan"
}
internal fun jobStatusLabel(status: TpJobStatus): String = when (status) {
    TpJobStatus.UNASSIGNED -> "Taqsimlanmagan"; TpJobStatus.QUEUED -> "Navbatda"; TpJobStatus.IN_PROGRESS -> "Ishda"
    TpJobStatus.COMPLETE -> "Yakunlangan"; TpJobStatus.HOLD -> "Kutilmoqda"
}
internal fun materialStatusLabel(status: TpMaterialStatus): String = when (status) {
    TpMaterialStatus.PLANNED -> "Tayyorlanmagan"; TpMaterialStatus.CONFIRMED -> "Tayyor"; TpMaterialStatus.DELIVERED -> "Stanokka chiqarilgan"
}
