package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import java.util.UUID

private enum class TpMasterPage { ROOT, PRODUCTS, STRUCTURE, WORKERS, MATERIALS, PRICES }
private data class ColorDraft(val code: String = "", val share: String = "", val grams: String = "")

@Composable
fun TpMasterDataPage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    var page by remember { mutableStateOf(TpMasterPage.ROOT) }
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_MASTER_DATA)
    BackHandler(enabled = page != TpMasterPage.ROOT) { page = TpMasterPage.ROOT }
    when (page) {
        TpMasterPage.ROOT -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("200 ga yaqin mahsulot va qoliplar shu yerda tartibli saqlanadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            TpNavRow("Mahsulotlar va detallar") { page = TpMasterPage.PRODUCTS }
            TpNavRow("Sex, smena, brigada va stanoklar") { page = TpMasterPage.STRUCTURE }
            TpNavRow("Xodimlar va kunlik norma") { page = TpMasterPage.WORKERS }
            TpNavRow("Seryo va krasitel qoldig‘i") { page = TpMasterPage.MATERIALS }
            TpNavRow("Barcha detal narxlarini foizda o‘zgartirish") { page = TpMasterPage.PRICES }
        }
        else -> Column(Modifier.fillMaxSize()) {
            TextButton(onClick = { page = TpMasterPage.ROOT }, modifier = Modifier.padding(horizontal = 8.dp)) { Text("‹ TP ma’lumotlari") }
            when (page) {
                TpMasterPage.PRODUCTS -> TpProductsMaster(data, repo, canWrite, refresh)
                TpMasterPage.STRUCTURE -> TpStructureMaster(data, repo, canWrite, refresh)
                TpMasterPage.WORKERS -> TpWorkersMaster(data, repo, canWrite, refresh)
                TpMasterPage.MATERIALS -> TpMaterialsMaster(data, repo, canWrite, refresh)
                TpMasterPage.PRICES -> TpPricesMaster(data, repo, canWrite, refresh)
                else -> Unit
            }
        }
    }
}

@Composable
private fun TpProductsMaster(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var selectedId by remember { mutableStateOf<String?>(null) }
    var productDialog by remember { mutableStateOf<TpProduct?>(null) }
    var addProduct by remember { mutableStateOf(false) }
    var detailDialog by remember { mutableStateOf<TpDetail?>(null) }
    var addDetail by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val selected = data.products.firstOrNull { it.id == selectedId }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (selected == null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Mahsulotlar", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                if (canWrite) Button(onClick = { addProduct = true }) { Text("+ Mahsulot") }
            }
            if (data.products.none { !it.archived }) Text("Mahsulot kiritilmagan.")
            data.products.filterNot { it.archived }.sortedBy { it.article }.forEach { product ->
                TpCard(Modifier.clickable { selectedId = product.id }) {
                    Text("${product.article} — ${product.name}", fontWeight = FontWeight.Bold)
                    Text("${product.details.count { !it.archived }} detal/qolip yozuvi")
                }
            }
        } else {
            TextButton(onClick = { selectedId = null }) { Text("‹ Mahsulotlar") }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(selected.article, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(selected.name)
                }
                if (canWrite) OutlinedButton(onClick = { productDialog = selected }) { Text("Tahrirlash") }
            }
            if (canWrite) Button(onClick = { addDetail = true }, Modifier.fillMaxWidth()) { Text("+ Detal/qolip ma’lumoti") }
            selected.details.filterNot { it.archived }.forEach { detail ->
                TpCard(Modifier.clickable(enabled = canWrite) { detailDialog = detail }) {
                    Text("${detail.name} • qolip ${detail.moldCode}", fontWeight = FontWeight.Bold)
                    Text("1 mahsulotga ${detail.requiredPerProduct} • 1 jimda ${detail.piecesPerShot} • qopda ${detail.bagCapacity}")
                    Text("${detail.cycleSeconds} sek/jim • ${formatTpNumber(detail.grossShotWeightGrams)} g • ${detail.resinCode}")
                    Text("12 soat taxmin: ${detail.estimatedPiecesIn12Hours()} dona")
                    Text("Rang: ${detail.colors.joinToString { "${it.colorCode} (${formatTpNumber(it.share)})" }}")
                    Text("Mos sig‘im: ${detail.compatibleCapacities.sorted().joinToString("/").ifBlank { "cheklanmagan" }}")
                    Text("Mos stanok: ${data.machines.filter { detail.acceptsMachine(it) }.sortedBy { it.number }.joinToString { "${it.number}${if (it.capacity > 0) " (${it.capacity})" else ""}" }.ifBlank { "kiritilmagan" }}")
                }
            }
        }
        TpError(error)
    }
    if (addProduct || productDialog != null) TpProductDialog(productDialog, onDismiss = { addProduct = false; productDialog = null }) { article, name ->
        val result = productDialog?.let { repo.updateProduct(it.id, article, name) } ?: repo.addProduct(article, name)
        error = result.exceptionOrNull()?.message
        if (result.isSuccess) { addProduct = false; productDialog = null; refresh() }
        result.isSuccess
    }
    if (selected != null && (addDetail || detailDialog != null)) TpDetailDialog(data, detailDialog, onDismiss = { addDetail = false; detailDialog = null }) { detail ->
        val result = repo.saveDetail(selected.id, detail)
        error = result.exceptionOrNull()?.message
        if (result.isSuccess) { addDetail = false; detailDialog = null; refresh() }
        result.isSuccess
    }
}

@Composable
private fun TpProductDialog(initial: TpProduct?, onDismiss: () -> Unit, onSave: (String, String) -> Boolean) {
    var article by remember(initial?.id) { mutableStateOf(initial?.article.orEmpty()) }
    var name by remember(initial?.id) { mutableStateOf(initial?.name.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(if (initial == null) "Mahsulot qo‘shish" else "Mahsulotni tahrirlash") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { TpField(article, { article = it }, "Artikul (TB-...)"); TpField(name, { name = it }, "Mahsulot nomi") } },
        confirmButton = { TextButton(onClick = { if (onSave(article, name)) onDismiss() }) { Text("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

@Composable
private fun TpDetailDialog(data: TpData, initial: TpDetail?, onDismiss: () -> Unit, onSave: (TpDetail) -> Boolean) {
    var name by remember(initial?.id) { mutableStateOf(initial?.name.orEmpty()) }
    var mold by remember(initial?.id) { mutableStateOf(initial?.moldCode.orEmpty()) }
    var required by remember(initial?.id) { mutableStateOf(initial?.requiredPerProduct?.toString() ?: "1") }
    var perShot by remember(initial?.id) { mutableStateOf(initial?.piecesPerShot?.toString() ?: "1") }
    var bag by remember(initial?.id) { mutableStateOf(initial?.bagCapacity?.toString() ?: "100") }
    var cycle by remember(initial?.id) { mutableStateOf(initial?.cycleSeconds?.toString() ?: "60") }
    var gross by remember(initial?.id) { mutableStateOf(initial?.grossShotWeightGrams?.let(::formatTpNumber).orEmpty()) }
    var unusable by remember(initial?.id) { mutableStateOf(initial?.unusableShotWeightGrams?.let(::formatTpNumber) ?: "0") }
    var resin by remember(initial?.id) { mutableStateOf(initial?.resinCode.orEmpty()) }
    var price by remember(initial?.id) { mutableStateOf(initial?.unitPrice?.toString() ?: "0") }
    var machines by remember(initial?.id) { mutableStateOf(initial?.compatibleMachineIds ?: emptySet()) }
    var capacities by remember(initial?.id) { mutableStateOf(initial?.compatibleCapacities?.sorted()?.joinToString(",") ?: "") }
    val colors = remember(initial?.id) { mutableStateListOf<ColorDraft>().apply {
        val source = initial?.colors.orEmpty()
        if (source.isEmpty()) add(ColorDraft()) else source.forEach { add(ColorDraft(it.colorCode, formatTpNumber(it.share), formatTpNumber(it.gramsPer25Kg))) }
    } }
    var validation by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Detal/qolip qo‘shish" else "Detal/qolipni tahrirlash") },
        text = { Column(Modifier.heightIn(max = 600.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            TpField(name, { name = it }, "Detal nomi")
            TpField(mold, { mold = it }, "Qolip kodi (bir qolipdagi detallar uchun bir xil)")
            TpField(required, { required = digitsOnly(it) }, "1 mahsulotga nechta", KeyboardType.Number)
            TpField(perShot, { perShot = digitsOnly(it) }, "1 jimda nechta", KeyboardType.Number)
            TpField(bag, { bag = digitsOnly(it) }, "1 qopda nechta", KeyboardType.Number)
            TpField(cycle, { cycle = digitsOnly(it) }, "1 jim vaqti (sekund)", KeyboardType.Number)
            TpField(gross, { gross = decimalInput(it) }, "1 jim umumiy og‘irligi (gram)", KeyboardType.Decimal)
            TpField(unusable, { unusable = decimalInput(it) }, "Shundan yaroqsiz qism og‘irligi (gram)", KeyboardType.Decimal)
            TpField(resin, { resin = it }, "Seryo kodi")
            TpField(price, { price = digitsOnly(it) }, "Detal donasi narxi", KeyboardType.Number)
            Text("Rang taqsimoti", fontWeight = FontWeight.Bold)
            colors.forEachIndexed { index, color ->
                TpCard {
                    TpField(color.code, { value -> colors[index] = color.copy(code = value) }, "Rang kodi")
                    TpField(color.share, { value -> colors[index] = color.copy(share = decimalInput(value)) }, "Taqsimot ulushi", KeyboardType.Decimal)
                    TpField(color.grams, { value -> colors[index] = color.copy(grams = decimalInput(value)) }, "25 kg ga krasitel (gram)", KeyboardType.Decimal)
                    if (colors.size > 1) TextButton(onClick = { colors.removeAt(index) }) { Text("Rangni olib tashlash") }
                }
            }
            OutlinedButton(onClick = { colors.add(ColorDraft()) }, Modifier.fillMaxWidth()) { Text("+ Rang") }
            TpField(capacities, { value -> capacities = value.filter { it.isDigit() || it == ',' || it == '/' || it == ' ' } }, "Mos stanok sig‘imlari (masalan 60,90,120)")
            Text("Mos stanoklar (ixtiyoriy qo‘shimcha cheklov)", fontWeight = FontWeight.Bold)
            data.machines.filterNot { it.archived }.sortedBy { it.number }.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth()) {
                    row.forEach { machine ->
                        Row(Modifier.weight(1f).clickable { machines = if (machine.id in machines) machines - machine.id else machines + machine.id }, verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(machine.id in machines, { checked -> machines = if (checked) machines + machine.id else machines - machine.id })
                            Text("${machine.number}${if (machine.capacity > 0) " (${machine.capacity})" else ""}")
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            TpError(validation)
        } },
        confirmButton = { TextButton(onClick = {
            val parsedColors = colors.mapNotNull { row ->
                val share = row.share.toDoubleOrNull(); val grams = row.grams.toDoubleOrNull()
                if (row.code.isBlank() || share == null || grams == null) null else TpColorRule(row.code, share, grams)
            }
            val detail = runCatching {
                val parsedCapacities = capacities.split(',', '/', ' ').mapNotNull { it.trim().toIntOrNull() }.filter { it > 0 }.toSet()
                TpDetail(
                    id = initial?.id ?: UUID.randomUUID().toString(), name = name, moldCode = mold,
                    requiredPerProduct = required.toInt(), piecesPerShot = perShot.toInt(), bagCapacity = bag.toInt(),
                    cycleSeconds = cycle.toInt(), grossShotWeightGrams = gross.toDouble(), unusableShotWeightGrams = unusable.toDouble(),
                    resinCode = resin, unitPrice = price.toLong(), compatibleMachineIds = machines, compatibleCapacities = parsedCapacities, colors = parsedColors,
                    archived = initial?.archived ?: false
                )
            }.getOrNull()
            validation = if (detail == null || parsedColors.size != colors.size) "Maydonlarni to‘g‘ri to‘ldiring" else null
            if (detail != null && validation == null && onSave(detail)) onDismiss()
        }) { Text("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

@Composable
private fun TpStructureMaster(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var mode by remember { mutableStateOf("BRIGADE") }
    var brigadeDialog by remember { mutableStateOf<TpBrigade?>(null) }
    var addBrigade by remember { mutableStateOf(false) }
    var machineDialog by remember { mutableStateOf<TpMachine?>(null) }
    var addMachine by remember { mutableStateOf(false) }
    var shiftDialog by remember { mutableStateOf<TpShift?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            listOf("BRIGADE" to "Brigada", "MACHINE" to "Stanok", "SHIFT" to "Smena").forEachIndexed { index, item ->
                SegmentedButton(selected = mode == item.first, onClick = { mode = item.first }, shape = SegmentedButtonDefaults.itemShape(index, 3)) { Text(item.second) }
            }
        }
        when (mode) {
            "BRIGADE" -> {
                if (canWrite) Button(onClick = { addBrigade = true }, Modifier.fillMaxWidth()) { Text("+ Brigada") }
                data.brigades.filterNot { it.archived }.sortedBy { it.name }.forEach { brigade ->
                    val shop = data.shops.firstOrNull { it.id == brigade.shopId }?.name.orEmpty()
                    val shift = data.shifts.firstOrNull { it.id == brigade.shiftId }?.name.orEmpty()
                    TpCard(Modifier.clickable(enabled = canWrite) { brigadeDialog = brigade }) { Text(brigade.name, fontWeight = FontWeight.Bold); Text("$shop • $shift") }
                }
            }
            "MACHINE" -> {
                if (canWrite) Button(onClick = { addMachine = true }, Modifier.fillMaxWidth()) { Text("+ Stanok") }
                data.machines.filterNot { it.archived }.sortedBy { it.number }.forEach { machine ->
                    TpCard(Modifier.clickable(enabled = canWrite) { machineDialog = machine }) {
                        Text("${machine.number}-stanok", fontWeight = FontWeight.Bold)
                        Text("${data.shops.firstOrNull { it.id == machine.shopId }?.name.orEmpty()} • sig‘im: ${if (machine.capacity > 0) machine.capacity else "kiritilmagan"}")
                    }
                }
            }
            else -> data.shifts.filterNot { it.archived }.forEach { shift ->
                TpCard(Modifier.clickable(enabled = canWrite) { shiftDialog = shift }) {
                    Text(shift.name, fontWeight = FontWeight.Bold)
                    Text("${shift.startTime}–${shift.endTime} • ${shift.roundTimes.size} raund: ${shift.roundTimes.joinToString()}")
                }
            }
        }
        TpError(error)
    }
    if (addBrigade || brigadeDialog != null) TpBrigadeDialog(data, brigadeDialog, { addBrigade = false; brigadeDialog = null }) { shop, shift, name ->
        val result = brigadeDialog?.let { repo.updateBrigade(it.id, shop, shift, name) } ?: repo.addBrigade(shop, shift, name)
        error = result.exceptionOrNull()?.message; if (result.isSuccess) { addBrigade = false; brigadeDialog = null; refresh() }; result.isSuccess
    }
    if (addMachine || machineDialog != null) TpMachineDialog(data, machineDialog, { addMachine = false; machineDialog = null }) { shop, number, name, capacity ->
        val result = machineDialog?.let { repo.updateMachine(it.id, shop, number, name, capacity) } ?: repo.addMachine(shop, number, name, capacity)
        error = result.exceptionOrNull()?.message; if (result.isSuccess) { addMachine = false; machineDialog = null; refresh() }; result.isSuccess
    }
    shiftDialog?.let { shift -> TpShiftDialog(shift, { shiftDialog = null }) { name, start, end, rounds ->
        val result = repo.updateShift(shift.id, name, start, end, rounds)
        error = result.exceptionOrNull()?.message; if (result.isSuccess) { shiftDialog = null; refresh() }; result.isSuccess
    } }
}

@Composable
private fun TpBrigadeDialog(data: TpData, initial: TpBrigade?, onDismiss: () -> Unit, onSave: (String, String, String) -> Boolean) {
    var shop by remember { mutableStateOf(initial?.shopId ?: data.shops.firstOrNull()?.id.orEmpty()) }
    var shift by remember { mutableStateOf(initial?.shiftId ?: data.shifts.firstOrNull()?.id.orEmpty()) }
    var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Brigada") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TpChoice("Sex", shop, data.shops.filterNot { it.archived }, { it.id }, { it.name }) { shop = it }
        TpChoice("Smena", shift, data.shifts.filterNot { it.archived }, { it.id }, { it.name }) { shift = it }
        TpField(name, { name = it }, "Brigada nomi")
    } }, confirmButton = { TextButton(onClick = { if (onSave(shop, shift, name)) onDismiss() }) { Text("Saqlash") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } })
}

@Composable
private fun TpMachineDialog(data: TpData, initial: TpMachine?, onDismiss: () -> Unit, onSave: (String, Int, String, Int) -> Boolean) {
    var shop by remember { mutableStateOf(initial?.shopId ?: data.shops.firstOrNull()?.id.orEmpty()) }
    var number by remember { mutableStateOf(initial?.number?.toString().orEmpty()) }
    var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    var capacity by remember { mutableStateOf(initial?.capacity?.takeIf { it > 0 }?.toString().orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Stanok") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TpChoice("Sex", shop, data.shops.filterNot { it.archived }, { it.id }, { it.name }) { shop = it }
        TpField(number, { number = digitsOnly(it) }, "Zavod bo‘yicha stanok raqami", KeyboardType.Number)
        TpField(capacity, { capacity = digitsOnly(it) }, "Stanok sig‘imi (masalan 60/90/120)", KeyboardType.Number)
        TpField(name, { name = it }, "Qo‘shimcha nom (ixtiyoriy)")
    } }, confirmButton = { TextButton(onClick = {
        val parsedNumber = number.toIntOrNull(); val parsedCapacity = capacity.toIntOrNull()
        if (parsedNumber != null && parsedCapacity != null && onSave(shop, parsedNumber, name, parsedCapacity)) onDismiss()
    }) { Text("Saqlash") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } })
}

@Composable
private fun TpShiftDialog(initial: TpShift, onDismiss: () -> Unit, onSave: (String, String, String, List<String>) -> Boolean) {
    var name by remember { mutableStateOf(initial.name) }; var start by remember { mutableStateOf(initial.startTime) }; var end by remember { mutableStateOf(initial.endTime) }
    var rounds by remember { mutableStateOf(initial.roundTimes.joinToString(", ")) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Smena va raundlar") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TpField(name, { name = it }, "Smena nomi"); TpField(start, { start = it }, "Boshlanish HH:MM"); TpField(end, { end = it }, "Tugash HH:MM")
        TpField(rounds, { rounds = it }, "Raund vaqtlari (vergul bilan)")
    } }, confirmButton = { TextButton(onClick = { if (onSave(name, start, end, rounds.split(',').map { it.trim() }.filter { it.isNotBlank() })) onDismiss() }) { Text("Saqlash") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } })
}

@Composable
private fun TpWorkersMaster(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var dialog by remember { mutableStateOf<TpWorker?>(null) }; var add by remember { mutableStateOf(false) }; var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Alohida ishchi bo‘limi yo‘q. Bu faqat norma va davomat uchun ma’lumot.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (canWrite) Button(onClick = { add = true }, Modifier.fillMaxWidth()) { Text("+ Xodim") }
        data.workers.filterNot { it.archived }.sortedBy { it.name }.forEach { worker ->
            TpCard(Modifier.clickable(enabled = canWrite) { dialog = worker }) {
                Text(worker.name, fontWeight = FontWeight.Bold); Text(data.brigades.firstOrNull { it.id == worker.brigadeId }?.name.orEmpty())
                Text("Norma ${worker.dailyTargetAmount} so‘m • ${worker.defaultWorkMinutes} daqiqa")
            }
        }
        TpError(error)
    }
    if (add || dialog != null) TpWorkerDialog(data, dialog, { add = false; dialog = null }) { brigade, name, target, minutes ->
        val result = dialog?.let { repo.updateWorker(it.id, brigade, name, target, minutes) } ?: repo.addWorker(brigade, name, target, minutes)
        error = result.exceptionOrNull()?.message; if (result.isSuccess) { add = false; dialog = null; refresh() }; result.isSuccess
    }
}

@Composable
private fun TpWorkerDialog(data: TpData, initial: TpWorker?, onDismiss: () -> Unit, onSave: (String, String, Long, Int) -> Boolean) {
    var brigade by remember { mutableStateOf(initial?.brigadeId ?: data.brigades.firstOrNull()?.id.orEmpty()) }; var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    var target by remember { mutableStateOf(initial?.dailyTargetAmount?.toString().orEmpty()) }; var minutes by remember { mutableStateOf(initial?.defaultWorkMinutes?.toString() ?: "680") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Xodim normasi") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TpChoice("Brigada", brigade, data.brigades.filterNot { it.archived }, { it.id }, { it.name }) { brigade = it }
        TpField(name, { name = it }, "Ism"); TpField(target, { target = digitsOnly(it) }, "Kunlik normal summa", KeyboardType.Number)
        TpField(minutes, { minutes = digitsOnly(it) }, "Standart ish daqiqasi", KeyboardType.Number)
    } }, confirmButton = { TextButton(onClick = { val t = target.toLongOrNull(); val m = minutes.toIntOrNull(); if (t != null && m != null && onSave(brigade, name, t, m)) onDismiss() }) { Text("Saqlash") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } })
}

@Composable
private fun TpMaterialsMaster(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var show by remember { mutableStateOf(false) }; var initial by remember { mutableStateOf<TpMaterial?>(null) }; var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (canWrite) Button(onClick = { show = true }, Modifier.fillMaxWidth()) { Text("+ Seryo/krasitel qoldig‘i") }
        data.materials.filterNot { it.archived }.sortedBy { it.code }.forEach { item ->
            TpCard(Modifier.clickable(enabled = canWrite) { initial = item; show = true }) {
                Text("${item.code} — ${item.name}", fontWeight = FontWeight.Bold)
                Text("${formatTpNumber(item.availableAmount)} ${if (item.type == TpMaterialType.RESIN) "kg" else "gram"}")
            }
        }
        TpError(error)
    }
    if (show) TpMaterialDialog(initial, { show = false; initial = null }) { code, name, type, amount ->
        val result = repo.setMaterial(code, name, type, amount); error = result.exceptionOrNull()?.message
        if (result.isSuccess) { show = false; initial = null; refresh() }; result.isSuccess
    }
}

@Composable
private fun TpMaterialDialog(initial: TpMaterial?, onDismiss: () -> Unit, onSave: (String, String, TpMaterialType, Double) -> Boolean) {
    var code by remember { mutableStateOf(initial?.code.orEmpty()) }; var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    var type by remember { mutableStateOf(initial?.type ?: TpMaterialType.RESIN) }; var amount by remember { mutableStateOf(initial?.availableAmount?.let(::formatTpNumber).orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Xomashyo qoldig‘i") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TpField(code, { code = it }, "Kod"); TpField(name, { name = it }, "Nomi")
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) { TpMaterialType.entries.forEachIndexed { index, option -> SegmentedButton(type == option, { type = option }, SegmentedButtonDefaults.itemShape(index, 2)) { Text(if (option == TpMaterialType.RESIN) "Seryo (kg)" else "Krasitel (g)") } } }
        TpField(amount, { amount = decimalInput(it) }, "Mavjud qoldiq", KeyboardType.Decimal)
    } }, confirmButton = { TextButton(onClick = { amount.toDoubleOrNull()?.let { if (onSave(code, name, type, it)) onDismiss() } }) { Text("Saqlash") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } })
}

@Composable
private fun TpPricesMaster(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var percent by remember { mutableStateOf("") }; var message by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Barcha ${data.products.sumOf { it.details.size }} ta detal narxini bitta harakat bilan o‘zgartirish.", fontWeight = FontWeight.Bold)
        Text("Masalan 10 yozilsa barcha narx 10% oshadi. -5 yozilsa 5% kamayadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        TpField(percent, { raw -> percent = raw.filter { it.isDigit() || it == '-' || it == '.' || it == ',' }.replace(',', '.') }, "Foiz", KeyboardType.Decimal, enabled = canWrite)
        Button(enabled = canWrite, onClick = {
            val result = percent.toDoubleOrNull()?.let(repo::increaseAllDetailPrices) ?: Result.failure(IllegalArgumentException("Foizni kiriting"))
            message = result.exceptionOrNull()?.message ?: "Narxlar yangilandi"
            if (result.isSuccess) { percent = ""; refresh() }
        }, modifier = Modifier.fillMaxWidth()) { Text("Barcha narxni o‘zgartirish") }
        if (!message.isNullOrBlank()) Text(message!!, color = if (message == "Narxlar yangilandi") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
    }
}
