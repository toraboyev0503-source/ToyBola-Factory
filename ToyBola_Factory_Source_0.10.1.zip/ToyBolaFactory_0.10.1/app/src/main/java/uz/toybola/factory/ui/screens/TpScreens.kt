package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.components.SectionCard
import uz.toybola.factory.ui.model.AppScreen
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate

@Composable
fun TpMainScreen(
    strings: AppStrings,
    onBack: () -> Unit,
    canOpen: (AppScreen) -> Boolean,
    onOpen: (AppScreen) -> Unit
) {
    val items = listOf(
        Triple("Plan", "Zakaz, rejalash, stanok vazifalari va davomat", AppScreen.TP_PLAN),
        Triple("Seryo", "Qorishma hisobi, qoldiq va stanokka yetkazish", AppScreen.TP_SERYO),
        Triple("Qabul qilish", "Qop, qoldiq va ishchilar ishlab chiqarishi", AppScreen.TP_RECEIVING),
        Triple("Sifat", "Smena raundlari va kun muammosi", AppScreen.TP_QUALITY),
        Triple("Monitoring", "Partiya, stanok, brigada va xomashyo nazorati", AppScreen.TP_MONITORING)
    )
    Column(Modifier.fillMaxSize()) {
        AppTopBar("TP va Seryo", canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp)) {
            items.chunked(2).forEachIndexed { rowIndex, row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEachIndexed { index, item ->
                        SectionCard(
                            number = rowIndex * 2 + index + 1,
                            title = item.first,
                            description = item.second,
                            enabled = canOpen(item.third),
                            modifier = if (row.size == 1) Modifier.fillMaxWidth() else Modifier.weight(1f),
                            onClick = { onOpen(item.third) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

private enum class TpPlanPage { ROOT, ORDERS, PLANNING, MACHINES, ATTENDANCE, MASTER }

@Composable
fun TpPlanScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val eventRevision by TpDataEvents.revision.collectAsState()
    var localRevision by remember { mutableIntStateOf(0) }
    val policy = remember(eventRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(eventRevision, localRevision, policy.revision) { repository.load().scopedFor(policy) }
    var page by remember { mutableStateOf(TpPlanPage.ROOT) }
    fun refresh() { localRevision++ }
    fun back() { if (page == TpPlanPage.ROOT) onBack() else page = TpPlanPage.ROOT }
    BackHandler(enabled = page != TpPlanPage.ROOT) { page = TpPlanPage.ROOT }

    val title = when (page) {
        TpPlanPage.ROOT -> "Plan"
        TpPlanPage.ORDERS -> "Nachalnik zakazlari"
        TpPlanPage.PLANNING -> "Plan beruvchi"
        TpPlanPage.MACHINES -> "Stanok vazifalari"
        TpPlanPage.ATTENDANCE -> "Davomat"
        TpPlanPage.MASTER -> "TP ma’lumotlari"
    }
    Column(Modifier.fillMaxSize()) {
        AppTopBar(title, canGoBack = true, onMenu = {}, onBack = ::back)
        when (page) {
            TpPlanPage.ROOT -> TpPlanRoot(policy) { page = it }
            TpPlanPage.ORDERS -> TpOrdersPage(data, repository, policy, ::refresh)
            TpPlanPage.PLANNING -> TpPlanningPage(data, repository, policy, ::refresh)
            TpPlanPage.MACHINES -> TpMachineQueuePage(data, repository, policy, ::refresh)
            TpPlanPage.ATTENDANCE -> TpAttendancePage(data, repository, policy, ::refresh)
            TpPlanPage.MASTER -> TpMasterDataPage(data, repository, policy, ::refresh)
        }
    }
}

@Composable
private fun TpPlanRoot(policy: UserAccessPolicy, onOpen: (TpPlanPage) -> Unit) {
    val items = buildList {
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_ORDER)) add(TpPlanPage.ORDERS to "Nachalnik — zakazlar")
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_PLANNING)) add(TpPlanPage.PLANNING to "Plan beruvchi — hisob va taqsimot")
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_MACHINE)) add(TpPlanPage.MACHINES to "TP brigadir — stanok vazifalari")
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_ATTENDANCE)) add(TpPlanPage.ATTENDANCE to "Plan beruvchi — davomat")
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_MASTER_DATA)) add(TpPlanPage.MASTER to "Mahsulot, qolip, stanok va normativlar")
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Kerakli vazifani tanlang. Ruxsatsiz bo‘limlar ko‘rsatilmaydi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        items.forEach { (page, title) -> TpNavRow(title) { onOpen(page) } }
    }
}

@Composable
private fun TpOrdersPage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_ORDER)
    var showAdd by remember { mutableStateOf(false) }
    var editOrder by remember { mutableStateOf<TpOrder?>(null) }
    var deleteOrder by remember { mutableStateOf<TpOrder?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val orders = data.orders.sortedWith(
        compareBy<TpOrder> { it.status == TpOrderStatus.COMPLETE || it.status == TpOrderStatus.CANCELLED }
            .thenBy { it.priority }
            .thenByDescending { it.createdAt }
    )

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (canWrite) Button(onClick = { showAdd = true }, Modifier.fillMaxWidth()) { Text("+ Yangi zakaz") }
        if (orders.isEmpty()) Text("Hali zakaz kiritilmagan.")
        orders.forEach { order ->
            TpCard {
                TpOrderSummary(data, order)
                if (canWrite && order.status != TpOrderStatus.COMPLETE) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { editOrder = order }, Modifier.weight(1f)) { Text("Tahrirlash") }
                        OutlinedButton(onClick = { deleteOrder = order }, Modifier.weight(1f)) { Text("O‘chirish") }
                    }
                }
            }
        }
        TpError(error)
    }

    if (showAdd) {
        TpOrderDialog(data = data, initial = null, onDismiss = { showAdd = false }) { batch, productId, quantity, priority, note ->
            val result = repo.createOrder(batch, productId, quantity, priority, note)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { showAdd = false; refresh() }
            result.isSuccess
        }
    }

    editOrder?.let { order ->
        TpOrderDialog(data = data, initial = order, onDismiss = { editOrder = null }) { _, productId, quantity, priority, note ->
            val result = repo.updateOrder(order.id, productId, quantity, priority, note)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { editOrder = null; refresh() }
            result.isSuccess
        }
    }

    deleteOrder?.let { order ->
        AlertDialog(
            onDismissRequest = { deleteOrder = null },
            title = { Text("Zakazni o‘chirish") },
            text = { Text("${order.batchNumber} • ${order.articleSnapshot} zakazi o‘chirilsinmi? Quyish yoki qabul boshlangan zakaz o‘chirilmaydi.") },
            confirmButton = { TextButton(onClick = {
                val result = repo.deleteOrder(order.id)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { deleteOrder = null; refresh() }
            }) { Text("O‘chirish") } },
            dismissButton = { TextButton(onClick = { deleteOrder = null }) { Text("Bekor qilish") } }
        )
    }
}

@Composable
private fun TpOrderDialog(
    data: TpData,
    initial: TpOrder?,
    onDismiss: () -> Unit,
    onSave: (String, String, Int, Int, String) -> Boolean
) {
    val products = data.products.filter { !it.archived && it.details.any { detail -> !detail.archived } }.sortedBy { it.article }
    var productId by remember(initial?.id) { mutableStateOf(initial?.productId ?: products.firstOrNull()?.id.orEmpty()) }
    var batch by remember(initial?.id) { mutableStateOf(initial?.batchNumber.orEmpty()) }
    var quantity by remember(initial?.id) { mutableStateOf(initial?.quantity?.toString().orEmpty()) }
    var priority by remember(initial?.id) { mutableIntStateOf(initial?.priority?.coerceIn(1, 3) ?: 2) }
    var note by remember(initial?.id) { mutableStateOf(initial?.note.orEmpty()) }
    var validation by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Yangi zakaz" else "Zakazni tahrirlash") },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (products.isEmpty()) Text("Avval mahsulot va uning detallarini kiriting.", color = MaterialTheme.colorScheme.error)
                if (initial != null) {
                    Text("Partiya: ${initial.batchNumber}", fontWeight = FontWeight.Bold)
                } else if (data.orders.isEmpty()) {
                    TpField(batch, { batch = it }, "Birinchi partiya raqami")
                } else {
                    Text("Keyingi partiya raqami avtomatik beriladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TpChoice("Mahsulot", productId, products, { it.id }, { "${it.article} — ${it.name}" }) { productId = it }
                TpField(quantity, { quantity = digitsOnly(it) }, "Zakaz soni", KeyboardType.Number)
                Text("Ustuvorlik", fontWeight = FontWeight.Bold)
                TpPriorityButtons(priority) { priority = it }
                TpField(note, { note = it }, "Izoh", singleLine = false)
                TpError(validation)
            }
        },
        confirmButton = { TextButton(enabled = products.isNotEmpty(), onClick = {
            val qty = quantity.toIntOrNull()
            validation = when {
                productId.isBlank() || qty == null || qty <= 0 -> "Majburiy maydonlarni to‘ldiring"
                else -> null
            }
            if (validation == null && onSave(batch, productId, qty!!, priority, note)) onDismiss()
        }) { Text("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

@Composable
private fun TpPriorityButtons(selected: Int, onSelect: (Int) -> Unit) {
    val values = listOf(
        Triple(1, "Eng zaril", Color(0xFFC62828)),
        Triple(2, "Zaril", Color(0xFFFFC107)),
        Triple(3, "Keyinroq", Color(0xFF2E7D32))
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        values.forEach { (value, label, color) ->
            val content = if (value == 2) Color.Black else Color.White
            Button(
                onClick = { onSelect(value) },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = color.copy(alpha = if (selected == value) 1f else 0.45f),
                    contentColor = content
                )
            ) { Text(if (selected == value) "✓ $label" else label, style = MaterialTheme.typography.labelSmall) }
        }
    }
}

@Composable
private fun TpOrderSummary(data: TpData, order: TpOrder) {
    val progress = data.orderProgress(order.id)
    val forecast = data.orderForecastMinutes(order.id)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("${order.batchNumber} • ${order.articleSnapshot}", fontWeight = FontWeight.Bold)
            Text("${order.productNameSnapshot} — ${order.quantity} dona")
        }
        Text("${progress.toInt()}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = tpPriorityColor(order.priority).copy(alpha = 0.16f)
        ) {
            Text(tpPriorityLabel(order.priority), modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontWeight = FontWeight.SemiBold)
        }
        Text("Holat: ${orderStatusLabel(order.status)}", style = MaterialTheme.typography.bodySmall)
    }
    Text("Zakaz berildi: ${order.createdAt.take(16).replace('T', ' ')}", style = MaterialTheme.typography.bodySmall)
    Text(
        if (forecast > 0) "Taxminiy to‘liq quyish: ${minutesLabel(forecast)}" else "Taxminiy muddat: ma’lumot yetarli emas",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    if (order.note.isNotBlank()) Text("Izoh: ${order.note}", style = MaterialTheme.typography.bodySmall)
    if (order.completedAt != null) Text("Yakunlandi: ${order.completedAt.take(16).replace('T', ' ')}", style = MaterialTheme.typography.bodySmall)
}

private fun tpPriorityColor(priority: Int): Color = when (priority.coerceIn(1, 3)) {
    1 -> Color(0xFFC62828)
    2 -> Color(0xFFFFC107)
    else -> Color(0xFF2E7D32)
}

@Composable
private fun TpPlanningPage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_PLANNING)
    var selectedOrderId by remember { mutableStateOf<String?>(null) }
    var expandedDetails by remember { mutableStateOf<Set<String>>(emptySet()) }
    var assignMold by remember { mutableStateOf<String?>(null) }
    var openColorMenu by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val orders = data.orders
        .filter { it.status != TpOrderStatus.COMPLETE && it.status != TpOrderStatus.CANCELLED }
        .sortedWith(compareBy<TpOrder> { it.priority }.thenBy { it.createdAt })
    val selectedOrder = data.orders.firstOrNull { it.id == selectedOrderId }

    LaunchedEffect(selectedOrderId) {
        val orderId = selectedOrderId ?: return@LaunchedEffect
        if (canWrite && data.jobs.none { it.orderId == orderId }) {
            val result = repo.generateOrderPlan(orderId)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) refresh()
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (selectedOrder == null) {
            Text("Nachalnik bergan zakazni tanlang. Detal, rang, jim va xomashyo hisobi avtomatik tayyorlanadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (orders.isEmpty()) Text("Rejalashtiriladigan zakaz yo‘q.")
            orders.forEach { order ->
                TpCard(Modifier.clickable { selectedOrderId = order.id }) {
                    TpOrderSummary(data, order)
                    Text("Ustiga bosib detallarni rejalang", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            TextButton(onClick = { selectedOrderId = null; expandedDetails = emptySet() }) { Text("‹ Zakazlar") }
            TpCard { TpOrderSummary(data, selectedOrder) }
            val product = data.products.firstOrNull { it.id == selectedOrder.productId }
            val details = product?.details?.filterNot { it.archived }.orEmpty()
            if (details.isEmpty()) Text("Mahsulot detallari topilmadi.", color = MaterialTheme.colorScheme.error)
            details.forEach { detail ->
                val detailJobs = data.jobs.filter { job -> job.orderId == selectedOrder.id && job.outputs.any { it.detailId == detail.id } }
                    .sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id })
                val machineIds = detailJobs.mapNotNull { it.machineId }.distinct()
                val machineLabel = when {
                    detailJobs.isEmpty() -> "Stanok"
                    machineIds.size == 1 && detailJobs.all { it.machineId != null } -> data.machines.firstOrNull { it.id == machineIds.first() }?.number?.toString() ?: "Stanok"
                    machineIds.isEmpty() -> "Stanok"
                    else -> "Aralash"
                }
                val total = selectedOrder.quantity * detail.requiredPerProduct
                TpCard {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text("${detail.name} • qolip ${detail.moldCode}", fontWeight = FontWeight.Bold)
                            Text("Jami quyiladi: $total dona", color = MaterialTheme.colorScheme.primary)
                            if (detail.compatibleCapacities.isNotEmpty()) Text("Sig‘im: ${detail.compatibleCapacities.sorted().joinToString("/")}", style = MaterialTheme.typography.bodySmall)
                        }
                        Button(
                            enabled = canWrite && detailJobs.isNotEmpty(),
                            onClick = { assignMold = detail.moldCode }
                        ) { Text(machineLabel) }
                    }
                    val assignedMachineId = machineIds.singleOrNull()?.takeIf { detailJobs.all { job -> job.machineId == it } }
                    if (assignedMachineId != null) {
                        val targetIds = detailJobs.map { it.id }.toSet()
                        val wait = data.jobs.filter { it.machineId == assignedMachineId && it.status != TpJobStatus.COMPLETE && it.id !in targetIds }.sumOf { it.estimatedMinutes }
                        if (wait > 0) Text("Boshlanishi taxminan: ${minutesLabel(wait)} dan keyin", style = MaterialTheme.typography.bodySmall)
                        else Text("Stanok bo‘sh — boshlash mumkin", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                    TextButton(onClick = {
                        expandedDetails = if (detail.id in expandedDetails) expandedDetails - detail.id else expandedDetails + detail.id
                    }) { Text(if (detail.id in expandedDetails) "▲ Ranglarni yopish" else "▼ Ranglarni ko‘rish") }
                    if (detail.id in expandedDetails) {
                        if (detailJobs.isNotEmpty()) {
                            detailJobs.forEachIndexed { index, job ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text("${job.colorCode} — ${job.outputs.firstOrNull { it.detailId == detail.id }?.requiredPieces ?: 0} dona", Modifier.weight(1f))
                                    if (canWrite) Box {
                                        OutlinedButton(onClick = { openColorMenu = job.id }) { Text("${index + 1}") }
                                        DropdownMenu(expanded = openColorMenu == job.id, onDismissRequest = { openColorMenu = null }) {
                                            detailJobs.indices.forEach { pos ->
                                                DropdownMenuItem(
                                                    text = { Text("${pos + 1}-navbat") },
                                                    onClick = {
                                                        openColorMenu = null
                                                        val result = repo.setColorPosition(job.id, pos + 1)
                                                        error = result.exceptionOrNull()?.message
                                                        if (result.isSuccess) refresh()
                                                    }
                                                )
                                            }
                                        }
                                    } else Text("${index + 1}")
                                }
                            }
                        } else {
                            allocateByColor(total, detail.colors).entries.forEachIndexed { index, row ->
                                Text("${index + 1}. ${row.key} — ${row.value} dona")
                            }
                        }
                    }
                }
            }
        }
        TpError(error)
    }

    val order = selectedOrder
    val mold = assignMold
    if (order != null && mold != null) {
        TpMachinePickerDialog(
            data = data,
            order = order,
            moldCode = mold,
            onDismiss = { assignMold = null },
            onSave = { machineId, brigadeId ->
                val result = repo.assignMoldJobs(order.id, mold, machineId, brigadeId)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { assignMold = null; refresh() }
                result.isSuccess
            }
        )
    }
}

@Composable
private fun TpMachinePickerDialog(
    data: TpData,
    order: TpOrder,
    moldCode: String,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Boolean
) {
    val targetJobs = data.jobs.filter { it.orderId == order.id && it.moldCode == moldCode }
    val targetIds = targetJobs.map { it.id }.toSet()
    fun availability(machineId: String): Int = data.jobs
        .filter { it.machineId == machineId && it.status != TpJobStatus.COMPLETE && it.id !in targetIds }
        .sumOf { it.estimatedMinutes }
    val machines = data.machines
        .filter { machine -> !machine.archived && targetJobs.isNotEmpty() && targetJobs.all { it.acceptsMachine(machine, data) } }
        .sortedWith(compareBy<TpMachine> { availability(it.id) }.thenBy { it.number })
    val currentMachineId = targetJobs.mapNotNull { it.machineId }.distinct().singleOrNull()
    var machineId by remember(order.id, moldCode) { mutableStateOf(currentMachineId ?: machines.firstOrNull()?.id.orEmpty()) }
    val selectedMachine = machines.firstOrNull { it.id == machineId }
    val brigades = data.brigades.filter { !it.archived && (selectedMachine == null || it.shopId == selectedMachine.shopId) }.sortedBy { it.name }
    val currentBrigade = targetJobs.mapNotNull { it.brigadeId }.distinct().singleOrNull()
    var brigadeId by remember(machineId) {
        mutableStateOf(currentBrigade?.takeIf { id -> brigades.any { it.id == id } } ?: brigades.firstOrNull()?.id.orEmpty())
    }
    var infoMachine by remember { mutableStateOf<TpMachine?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Qolip $moldCode uchun stanok") },
        text = {
            Column(Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (machines.isEmpty()) {
                    Text("Bu detal/qolip sig‘imiga mos stanok topilmadi. Stanok va detal sig‘im ma’lumotlarini tekshiring.", color = MaterialTheme.colorScheme.error)
                } else {
                    Text("Bo‘sh stanoklar tepada. Band stanoklar eng tez bo‘shaydiganidan boshlab tartiblangan.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val freeMachines = machines.filter { availability(it.id) == 0 }
                    val busyMachines = machines.filter { availability(it.id) > 0 }
                    if (freeMachines.isNotEmpty()) Text("Bo‘sh stanoklar", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    (freeMachines + busyMachines).forEachIndexed { index, machine ->
                        if (index == freeMachines.size && busyMachines.isNotEmpty()) {
                            Text("Band stanoklar", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        val wait = availability(machine.id)
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable { machineId = machine.id },
                            shape = RoundedCornerShape(14.dp),
                            tonalElevation = if (machine.id == machineId) 4.dp else 1.dp
                        ) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                RadioButton(selected = machine.id == machineId, onClick = { machineId = machine.id })
                                Column(Modifier.weight(1f)) {
                                    Text("${machine.number}-stanok${if (machine.capacity > 0) " • sig‘im ${machine.capacity}" else ""}", fontWeight = FontWeight.Bold)
                                    Text(if (wait == 0) "Bo‘sh" else "Band • taxminan ${minutesLabel(wait)} dan keyin bo‘shaydi", color = if (wait == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                TextButton(onClick = { infoMachine = machine }) { Text("Ma’lumot") }
                            }
                        }
                    }
                    selectedMachine?.let { machine ->
                        val wait = availability(machine.id)
                        Text(if (wait == 0) "Tanlangan stanokda ishni darhol boshlash mumkin." else "Tanlangan stanokda boshlanish: taxminan ${minutesLabel(wait)} dan keyin.", fontWeight = FontWeight.SemiBold)
                        if (brigades.isNotEmpty()) TpChoice("Brigada", brigadeId, brigades, { it.id }, { it.name }) { brigadeId = it }
                        else Text("Bu sex uchun brigada kiritilmagan.", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = { TextButton(enabled = machineId.isNotBlank() && brigadeId.isNotBlank(), onClick = {
            if (onSave(machineId, brigadeId)) onDismiss()
        }) { Text("Tanlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )

    infoMachine?.let { machine ->
        val current = data.activeJobsForMachine(machine.id).firstOrNull { it.id !in targetIds }
        val currentOrder = current?.let { job -> data.orders.firstOrNull { it.id == job.orderId } }
        AlertDialog(
            onDismissRequest = { infoMachine = null },
            title = { Text("${machine.number}-stanok") },
            text = {
                if (current == null) Text("Hozir bo‘sh.") else Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Hozir: ${currentOrder?.batchNumber.orEmpty()} • ${current.moldCode}", fontWeight = FontWeight.Bold)
                    Text("Rang: ${current.colorCode}")
                    Text("Detal: ${current.outputs.joinToString { it.detailName }}")
                    Text("Vazifa vaqti: ${minutesLabel(current.estimatedMinutes)}")
                }
            },
            confirmButton = { TextButton(onClick = { infoMachine = null }) { Text("Yopish") } }
        )
    }
}

@Composable
private fun TpMachineQueuePage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_MACHINE)
    var error by remember { mutableStateOf<String?>(null) }
    val assigned = data.jobs.filter { it.machineId != null && it.status != TpJobStatus.COMPLETE }.groupBy { it.machineId!! }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (assigned.isEmpty()) Text("Stanokka biriktirilgan vazifa yo‘q.")
        assigned.entries.sortedBy { (machineId, _) -> data.machines.firstOrNull { it.id == machineId }?.number }.forEach { (machineId, jobs) ->
            val machine = data.machines.firstOrNull { it.id == machineId }
            Text("${machine?.number ?: 0}-stanok", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            jobs.sortedBy { it.priority }.forEachIndexed { index, job ->
                val order = data.orders.firstOrNull { it.id == job.orderId }
                TpCard {
                    Text("${index + 1}. ${order?.batchNumber.orEmpty()} • ${job.moldCode} • ${job.colorCode}", fontWeight = FontWeight.Bold)
                    job.outputs.forEach { output ->
                        val fullBags = output.requiredPieces / output.bagCapacity
                        val remainder = output.requiredPieces % output.bagCapacity
                        Text("${output.detailName}: ${output.requiredPieces} dona • $fullBags qop${if (remainder > 0) " + $remainder dona" else ""}")
                    }
                    Text("Seryo: ${materialStatusLabel(job.materialStatus)}")
                    Text("Vazifa: ${jobStatusLabel(job.status)}")
                    if (canWrite) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (job.status == TpJobStatus.QUEUED) OutlinedButton(onClick = {
                            error = repo.setJobStatus(job.id, TpJobStatus.IN_PROGRESS).exceptionOrNull()?.message
                            if (error == null) refresh()
                        }, Modifier.weight(1f)) { Text("Boshlash") }
                        val completeReady = job.outputs.all { output ->
                            data.receipts.filter { it.jobId == job.id && it.detailId == output.detailId }
                                .sumOf { it.creditedPieces } >= output.requiredPieces
                        }
                        if (job.status == TpJobStatus.IN_PROGRESS && completeReady) OutlinedButton(onClick = {
                            error = repo.setJobStatus(job.id, TpJobStatus.COMPLETE).exceptionOrNull()?.message
                            if (error == null) refresh()
                        }, Modifier.weight(1f)) { Text("Yakunlash") }
                        OutlinedButton(onClick = {
                            error = repo.setJobStatus(job.id, if (job.status == TpJobStatus.HOLD) TpJobStatus.QUEUED else TpJobStatus.HOLD).exceptionOrNull()?.message
                            if (error == null) refresh()
                        }, Modifier.weight(1f)) { Text(if (job.status == TpJobStatus.HOLD) "Qaytarish" else "Kutish") }
                    }
                }
            }
        }
        TpError(error)
    }
}

@Composable
private fun TpAttendancePage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_ATTENDANCE)
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    val brigades = data.brigades.filterNot { it.archived }.sortedBy { it.name }
    var brigadeId by remember { mutableStateOf(brigades.firstOrNull()?.id.orEmpty()) }
    var editWorker by remember { mutableStateOf<TpWorker?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val workers = data.workers.filter { !it.archived && it.brigadeId == brigadeId }.sortedBy { it.name }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Davomatni TP plan beruvchi kiritadi. Ish vaqti normativ hisobiga avtomatik ta’sir qiladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        TpField(date, { date = it }, "Sana (YYYY-MM-DD)")
        TpChoice("Brigada", brigadeId, brigades, { it.id }, { it.name }) { brigadeId = it }
        if (workers.isEmpty()) Text("Bu brigadada ishchi yo‘q.")
        workers.forEach { worker ->
            val day = data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }
            TpCard(Modifier.clickable(enabled = canWrite) { editWorker = worker }) {
                Text(worker.name, fontWeight = FontWeight.Bold)
                Text(if (day == null) "Kiritilmagan • avtomatik ${worker.defaultWorkMinutes} daqiqa" else if (day.present) "Ishda • ${day.workMinutes} daqiqa" else "Ishlamadi")
                Text("Kunlik norma: ${worker.dailyTargetAmount} so‘m", style = MaterialTheme.typography.bodySmall)
            }
        }
        TpError(error)
    }
    editWorker?.let { worker ->
        val existing = data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }
        var present by remember(worker.id, date) { mutableStateOf(existing?.present ?: true) }
        var minutes by remember(worker.id, date) { mutableStateOf((existing?.workMinutes ?: worker.defaultWorkMinutes).toString()) }
        AlertDialog(
            onDismissRequest = { editWorker = null },
            title = { Text(worker.name) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Ishda", Modifier.weight(1f)); Switch(present, { present = it; if (!it) minutes = "0" }) }
                TpField(minutes, { minutes = digitsOnly(it) }, "Ishlagan daqiqa", KeyboardType.Number, enabled = present)
            } },
            confirmButton = { TextButton(onClick = {
                val result = repo.setAttendance(worker.id, date, present, minutes.toIntOrNull() ?: 0)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { editWorker = null; refresh() }
            }) { Text("Saqlash") } },
            dismissButton = { TextButton(onClick = { editWorker = null }) { Text("Bekor qilish") } }
        )
    }
}

@Composable
internal fun TpNavRow(title: String, onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            Text("›", style = MaterialTheme.typography.headlineSmall)
        }
    }
}

@Composable
internal fun TpCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp), content = content)
    }
}

@Composable
internal fun TpField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    enabled: Boolean = true
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType), singleLine = singleLine, enabled = enabled
    )
}

@Composable
internal fun <T> TpChoice(
    label: String,
    selectedId: String,
    options: List<T>,
    id: (T) -> String,
    text: (T) -> String,
    onSelect: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val selected = options.firstOrNull { id(it) == selectedId }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: ${selected?.let(text) ?: "Tanlang"}", Modifier.weight(1f))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(text(option)) }, onClick = { open = false; onSelect(id(option)) }) }
        }
    }
}

@Composable
internal fun TpError(message: String?) {
    if (!message.isNullOrBlank()) Text(message, color = MaterialTheme.colorScheme.error)
}

internal fun digitsOnly(value: String): String = value.filter(Char::isDigit)
internal fun decimalInput(value: String): String {
    var separator = false
    return buildString {
        value.forEach { char ->
            if (char.isDigit()) append(char)
            else if ((char == '.' || char == ',') && !separator) { append('.'); separator = true }
        }
    }
}
internal fun minutesLabel(minutes: Int): String = "${minutes / 60} soat ${minutes % 60} daqiqa"
internal fun orderStatusLabel(status: TpOrderStatus): String = when (status) {
    TpOrderStatus.NEW -> "Yangi"; TpOrderStatus.PLANNING -> "Rejalanmoqda"; TpOrderStatus.READY -> "Tayyor"
    TpOrderStatus.IN_PROGRESS -> "Quyilmoqda"; TpOrderStatus.COMPLETE -> "Yakunlangan"; TpOrderStatus.CANCELLED -> "Bekor qilingan"
}
internal fun jobStatusLabel(status: TpJobStatus): String = when (status) {
    TpJobStatus.UNASSIGNED -> "Taqsimlanmagan"; TpJobStatus.QUEUED -> "Navbatda"; TpJobStatus.IN_PROGRESS -> "Ishda"
    TpJobStatus.COMPLETE -> "Yakunlangan"; TpJobStatus.HOLD -> "Kutilmoqda"
}
internal fun materialStatusLabel(status: TpMaterialStatus): String = when (status) {
    TpMaterialStatus.PLANNED -> "Tayyorlanmagan"; TpMaterialStatus.CONFIRMED -> "Tayyor"; TpMaterialStatus.DELIVERED -> "Stanokka chiqarilgan"
}
