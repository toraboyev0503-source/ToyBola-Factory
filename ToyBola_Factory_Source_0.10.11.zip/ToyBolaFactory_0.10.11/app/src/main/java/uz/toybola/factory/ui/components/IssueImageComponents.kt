package uz.toybola.factory.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import uz.toybola.factory.core.firebase.DailyIssueImageStorage
import java.time.LocalDateTime

@Composable
fun IssueImageBlock(imageUrl: String, imagePath: String, modifier: Modifier = Modifier) {
    if (imageUrl.isBlank()) return
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val storage = remember { DailyIssueImageStorage(context) }
    var viewer by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/jpeg")) { uri ->
        if (uri != null) scope.launch {
            message = runCatching { storage.download(imagePath, uri); "Rasm saqlandi" }
                .getOrElse { it.message ?: "Rasmni yuklab bo‘lmadi" }
        }
    }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        AsyncImage(
            model = imageUrl,
            contentDescription = "Kun muammosi rasmi",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(14.dp)).clickable { viewer = true }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { viewer = true }) { Text("Ko‘rish / yaqinlashtirish") }
            if (imagePath.isNotBlank()) OutlinedButton(onClick = {
                val suffix = LocalDateTime.now().toString().replace(':', '-').take(19)
                saveLauncher.launch("ToyBola_muammo_$suffix.jpg")
            }) { Text("Yuklab olish") }
        }
        message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
    }
    if (viewer) IssueImageViewer(imageUrl) { viewer = false }
}

@Composable
private fun IssueImageViewer(imageUrl: String, onDismiss: () -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    val transformState = rememberTransformableState { zoomChange, _, _ ->
        scale = (scale * zoomChange).coerceIn(1f, 5f)
    }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(18.dp), tonalElevation = 6.dp) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.fillMaxWidth().heightIn(min = 300.dp, max = 620.dp), contentAlignment = Alignment.Center) {
                    AsyncImage(
                        model = imageUrl,
                        contentDescription = "Kun muammosi rasmi",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize().graphicsLayer(scaleX = scale, scaleY = scale).transformable(transformState)
                    )
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { scale = (scale - 0.5f).coerceAtLeast(1f) }) { Text("−") }
                    Text("${(scale * 100).toInt()}%", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    OutlinedButton(onClick = { scale = (scale + 0.5f).coerceAtMost(5f) }) { Text("+") }
                    TextButton(onClick = onDismiss) { Text("Yopish") }
                }
            }
        }
    }
}

@Composable
fun IssueImagePickerButton(
    hasImage: Boolean,
    enabled: Boolean = true,
    onSelected: (android.net.Uri) -> Unit
) {
    val context = LocalContext.current
    var chooserOpen by remember { mutableStateOf(false) }
    var pendingCameraUri by remember { mutableStateOf<android.net.Uri?>(null) }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) onSelected(uri)
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) onSelected(uri)
        pendingCameraUri = null
    }
    OutlinedButton(
        onClick = { chooserOpen = true },
        enabled = enabled,
        modifier = Modifier.fillMaxWidth()
    ) { Text(if (hasImage) "Rasmni almashtirish" else "Rasm qo‘shish") }

    if (chooserOpen) {
        AlertDialog(
            onDismissRequest = { chooserOpen = false },
            title = { Text("Rasm manbasini tanlang") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        chooserOpen = false
                        val file = java.io.File.createTempFile("issue_", ".jpg", context.cacheDir)
                        val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                        pendingCameraUri = uri
                        camera.launch(uri)
                    }, modifier = Modifier.fillMaxWidth()) { Text("Kamera") }
                    OutlinedButton(onClick = {
                        chooserOpen = false
                        gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }, modifier = Modifier.fillMaxWidth()) { Text("Galereya") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { chooserOpen = false }) { Text("Bekor qilish") } }
        )
    }
}
