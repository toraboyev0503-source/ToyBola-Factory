@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package uz.toybola.factory.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.DailyIssueImageStorage
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.components.IssueImageBlock
import uz.toybola.factory.ui.components.IssueImagePickerButton
import uz.toybola.factory.ui.model.AppStrings
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneOffset
import java.util.UUID

private enum class TpSeryoPage { ROOT, ORDERS, PREPARATION, STOCK, MONITORING }
private enum class TpStockPage { ROOT, OUT, IN, BALANCE }

@Composable
fun TpSeryoScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val serverRevision by TpDataEvents.revision.collectAsState()
    var revision by remember { mutableIntStateOf(0) }
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(serverRevision, revision, policy.revision) { repository.load().scopedFor(policy) }
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_SERYO)
    var page by remember { mutableStateOf(TpSeryoPage.ROOT) }
    var stockPage by remember { mutableStateOf(TpStockPage.ROOT) }
    fun refresh() { revision++ }
    fun goBackOneLevel() {
        when {
            page == TpSeryoPage.STOCK && stockPage != TpStockPage.ROOT -> stockPage = TpStockPage.ROOT
            page != TpSeryoPage.ROOT -> page = TpSeryoPage.ROOT
            else -> onBack()
        }
    }
    BackHandler(enabled = page != TpSeryoPage.ROOT || stockPage != TpStockPage.ROOT) { goBackOneLevel() }

    Column(Modifier.fillMaxSize()) {
        AppTopBar("Seryo", canGoBack = true, onMenu = {}, onBack = ::goBackOneLevel)
        when (page) {
            TpSeryoPage.ROOT -> Column(
                Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpSeryo-root"))
                    .navigationBarsPadding().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TpNavRow("1. Buyurtma") { page = TpSeryoPage.ORDERS }
                TpNavRow("2. Tayyorlash va yetkazish") { page = TpSeryoPage.PREPARATION }
                TpNavRow("3. Ostatka") { page = TpSeryoPage.STOCK; stockPage = TpStockPage.ROOT }
                TpNavRow("4. Monitoring") { page = TpSeryoPage.MONITORING }
            }
            TpSeryoPage.ORDERS -> TpSeryoOrders(data, repository, canWrite, ::refresh)
            TpSeryoPage.PREPARATION -> TpMaterialPreparationPage(data, repository, canWrite, ::refresh)
            TpSeryoPage.STOCK -> when (stockPage) {
                TpStockPage.ROOT -> Column(
                    Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpSeryo-stock-root"))
                        .navigationBarsPadding().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Ostatka harakati", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    TpNavRow("Rasxod") { stockPage = TpStockPage.OUT }
                    TpNavRow("Prixod") { stockPage = TpStockPage.IN }
                    TpNavRow("Ostatka") { stockPage = TpStockPage.BALANCE }
                }
                TpStockPage.OUT -> TpMaterialMovementPage(data, repository, canWrite, incoming = false, refresh = ::refresh)
                TpStockPage.IN -> TpMaterialMovementPage(data, repository, canWrite, incoming = true, refresh = ::refresh)
                TpStockPage.BALANCE -> TpMaterialBalancePage(data)
            }
            TpSeryoPage.MONITORING -> TpSeryoMonitoring(data)
        }
    }
}

@Composable
private fun TpSeryoOrders(data: TpData, repository: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var selectedOrderId by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var shortageOrderId by remember { mutableStateOf<String?>(null) }
    val orders = data.orders.filter { it.planApprovedAt != null && it.status != TpOrderStatus.COMPLETE && it.status != TpOrderStatus.CANCELLED }
    val pending = orders.filter { order -> data.jobs.filter { it.orderId == order.id }.any { it.resinConfirmedAt == null } }
        .sortedWith(compareBy<TpOrder> { it.priority }.thenBy { it.planApprovedAt.orEmpty() })
    val confirmed = orders.filter { order -> data.jobs.filter { it.orderId == order.id }.all { it.resinConfirmedAt != null } }
        .sortedByDescending { order -> data.jobs.filter { it.orderId == order.id }.maxOfOrNull { it.resinConfirmedAt.orEmpty() }.orEmpty() }
    val selected = orders.firstOrNull { it.id == selectedOrderId }

    BackHandler(enabled = selected != null) { selectedOrderId = null }
    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState(if (selected == null) "TpSeryo-order-list" else "TpSeryo-order-${selected.id}"))
            .navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (selected == null) {
            Text("Seryo brigadiri", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Plan beruvchi tasdiqlagan zakazlar shu yerga tushadi. Seryo turi tanlanib tasdiqlanmaguncha yordamchilarga vazifa ko‘rinmaydi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Seryo tanlanmagan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (pending.isEmpty()) Text("Tanlashni kutayotgan zakaz yo‘q.")
            pending.forEach { order ->
                TpCard(Modifier.clickable { selectedOrderId = order.id }) { TpSeryoOrderSummary(data, order); Text("Seryoni tanlash", color = MaterialTheme.colorScheme.primary) }
            }
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Text("Tasdiqlangan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (confirmed.isEmpty()) Text("Hali seryosi tasdiqlangan zakaz yo‘q.")
            confirmed.forEach { order ->
                TpCard(Modifier.clickable { selectedOrderId = order.id }) { TpSeryoOrderSummary(data, order); Text("Yordamchilarga topshirilgan", color = MaterialTheme.colorScheme.primary) }
            }
        } else {
            TextButton(onClick = { selectedOrderId = null }) { Text("‹ Buyurtmalar") }
            TpCard { TpSeryoOrderSummary(data, selected) }
            val jobs = data.jobs.filter { it.orderId == selected.id }.sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id })
            jobs.forEach { job ->
                val machine = data.machines.firstOrNull { it.id == job.machineId }
                val shop = machine?.let { m -> data.shops.firstOrNull { it.id == m.shopId } }
                val options = seryoOptionsForJob(data, job)
                TpCard {
                    Text(job.outputs.joinToString { it.detailName }, fontWeight = FontWeight.Bold)
                    Text("Rang ${job.colorCode} • ${job.outputs.sumOf { it.requiredPieces }} dona")
                    Text("Stanok: ${machine?.number ?: 0} • ${shop?.name.orEmpty()}")
                    Text("Kerak: ${formatTpNumber(job.requiredResinKg)} kg seryo • ${formatTpNumber(job.requiredColorGrams)} g krasitel")
                    if (job.requiredResinKg > 0) Text("25 kg ga ${formatTpNumber(job.requiredColorGrams * 25.0 / job.requiredResinKg)} g krasitel", style = MaterialTheme.typography.bodySmall)
                    if (job.resinConfirmedAt == null && canWrite) {
                        TpChoice("Seryo turi", if (job.resinSelectedAt == null) "" else job.resinCode, options, { it }, { code ->
                            val stock = data.materialStock(TpMaterialType.RESIN, code)
                            "$code • ostatka ${formatTpNumber(stock)} kg"
                        }) { selectedCode ->
                            error = repository.setJobResin(job.id, selectedCode).exceptionOrNull()?.message
                            if (error == null) refresh()
                        }
                        if (job.resinSelectedAt != null && job.resinCode.isNotBlank()) {
                            val selectedStock = data.materialStock(TpMaterialType.RESIN, job.resinCode)
                            if (selectedStock + 1e-9 < job.requiredResinKg) {
                                Text(
                                    "⚠ ${job.resinCode} yetarli emas: kerak ${formatTpNumber(job.requiredResinKg)} kg, bor ${formatTpNumber(selectedStock)} kg",
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    } else Text("Seryo: ${job.resinCode}", color = MaterialTheme.colorScheme.primary)
                }
            }
            val allConfirmed = jobs.isNotEmpty() && jobs.all { it.resinConfirmedAt != null }
            val allSelected = jobs.isNotEmpty() && jobs.all { it.resinSelectedAt != null && it.resinCode.isNotBlank() }
            if (!allConfirmed) {
                if (!allSelected) {
                    Text("Har bir detal/rang uchun seryo turini tanlang. Shundan keyingina yordamchilarga yuborish ochiladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Button(enabled = canWrite && allSelected, onClick = {
                    val shortages = orderMaterialShortages(data, selected.id)
                    if (shortages.isEmpty()) {
                        error = repository.confirmOrderResins(selected.id, false).exceptionOrNull()?.message
                        if (error == null) refresh()
                    } else shortageOrderId = selected.id
                }, modifier = Modifier.fillMaxWidth()) { Text("✓ Seryoni tasdiqlash va yordamchilarga yuborish") }
            } else {
                Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(14.dp)) {
                    Text("✓ Seryo tanlangan va yordamchilarga topshirilgan", Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
                }
            }
        }
        TpError(error)
    }

    val warningOrder = shortageOrderId
    if (warningOrder != null) {
        val shortages = orderMaterialShortages(data, warningOrder)
        AlertDialog(
            onDismissRequest = { shortageOrderId = null },
            title = { Text("Ostatka yetarli emas") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Quyidagi materiallar kam yoki yo‘q:")
                shortages.forEach { Text("• $it", color = MaterialTheme.colorScheme.error) }
                Text("Baribir tasdiqlasangiz vazifa tayyorlovchilarga o‘tadi va yetishmovchilik monitoringda ko‘rinadi.")
            } },
            confirmButton = { TextButton(onClick = {
                error = repository.confirmOrderResins(warningOrder, true).exceptionOrNull()?.message
                if (error == null) refresh()
                shortageOrderId = null
            }) { Text("Baribir tasdiqlash") } },
            dismissButton = { TextButton(onClick = { shortageOrderId = null }) { Text("Bekor qilish") } }
        )
    }
}

@Composable
private fun TpSeryoOrderSummary(data: TpData, order: TpOrder) {
    val progress = data.orderProgress(order.id)
    Text("${order.batchNumber} • ${order.articleSnapshot}", fontWeight = FontWeight.Bold)
    Text(order.productNameSnapshot)
    Text("${order.quantity} dona • ${tpPriorityLabel(order.priority)}")
    Text("Plan tasdiq: ${order.planApprovedAt?.take(16)?.replace('T', ' ') ?: "—"}", style = MaterialTheme.typography.bodySmall)
    if (progress > 0) Text("Bajarilish: ${progress.toInt()}%", color = MaterialTheme.colorScheme.primary)
}

private fun seryoOptionsForJob(data: TpData, job: TpPlanJob): List<String> {
    val sets = job.outputs.mapNotNull { output ->
        data.products.asSequence().flatMap { it.details.asSequence() }.firstOrNull { it.id == output.detailId }?.resinOptions()?.toSet()
    }
    if (sets.isEmpty()) return listOfNotNull(job.resinCode.takeIf { it.isNotBlank() })
    return sets.drop(1).fold(sets.first()) { acc, set -> acc intersect set }.sorted()
}

private fun orderMaterialShortages(data: TpData, orderId: String): List<String> {
    val jobs = data.jobs.filter { it.orderId == orderId }
    val resin = jobs.groupBy { it.resinCode }.mapValues { (_, rows) -> rows.sumOf { it.requiredResinKg } }
    val color = jobs.groupBy { it.colorCode }.mapValues { (_, rows) -> rows.sumOf { it.requiredColorGrams } }
    return buildList {
        resin.forEach { (code, need) ->
            val stock = data.materialStock(TpMaterialType.RESIN, code)
            if (stock + 1e-9 < need) add("$code seryo — kerak ${formatTpNumber(need)} kg, bor ${formatTpNumber(stock)} kg")
        }
        color.forEach { (code, need) ->
            val stock = data.materialStock(TpMaterialType.COLOR, code)
            if (stock + 1e-9 < need) add("$code krasitel — kerak ${formatTpNumber(need)} g, bor ${formatTpNumber(stock)} g")
        }
    }
}

@Composable
private fun TpMaterialPreparationPage(data: TpData, repository: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var error by remember { mutableStateOf<String?>(null) }
    val today = LocalDate.now().toString()
    val approvedOrders = data.orders.filter { it.planApprovedAt != null && it.status != TpOrderStatus.CANCELLED }.map { it.id }.toSet()
    val pending = data.jobs.filter {
        it.orderId in approvedOrders && it.resinConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED && it.status != TpJobStatus.COMPLETE
    }.sortedWith(compareBy<TpPlanJob> { it.resinConfirmedAt.orEmpty() }.thenBy { it.priority })
    val done = data.jobs.filter {
        it.orderId in approvedOrders && it.materialStatus == TpMaterialStatus.DELIVERED && it.materialDeliveredAt?.take(10) == today
    }.sortedByDescending { it.materialDeliveredAt.orEmpty() }

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpSeryo-preparation"))
            .navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Tayyorlash kerak", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Eng oldin tushgan buyurtma tepada. Tayyorlanmagan vazifa bajarilguncha shu ro‘yxatda qoladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (pending.isEmpty()) Text("Tayyorlanadigan qorishma yo‘q.")
        pending.forEach { job -> PreparationCard(data, job, canWrite, onDelivered = {
            error = repository.confirmMaterial(job.id, delivered = true).exceptionOrNull()?.message
            if (error == null) refresh()
        }) }
        HorizontalDivider(Modifier.padding(vertical = 6.dp))
        Text("Tayyorlandi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Faqat bugungi yetkazilganlar ko‘rinadi. Birinchi tayyorlangan eng pastda, yangilari uning tepasiga qo‘shiladi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (done.isEmpty()) Text("Bugun hali yetkazilgan vazifa yo‘q.")
        done.forEach { job -> PreparationCard(data, job, false, onDelivered = {}) }
        TpError(error)
    }
}

@Composable
private fun PreparationCard(data: TpData, job: TpPlanJob, canDeliver: Boolean, onDelivered: () -> Unit) {
    val order = data.orders.firstOrNull { it.id == job.orderId }
    val machine = data.machines.firstOrNull { it.id == job.machineId }
    val shop = machine?.let { m -> data.shops.firstOrNull { it.id == m.shopId } }
    val resinStock = data.materialStock(TpMaterialType.RESIN, job.resinCode)
    val colorStock = data.materialStock(TpMaterialType.COLOR, job.colorCode)
    TpCard {
        Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.Bold)
        Text(job.outputs.joinToString { it.detailName })
        Text("${machine?.number ?: 0}-stanok • ${shop?.name.orEmpty()} • rang ${job.colorCode}")
        Text("${formatTpNumber(job.requiredResinKg)} kg ${job.resinCode} seryo", fontWeight = FontWeight.SemiBold)
        Text("${formatTpNumber(job.requiredColorGrams)} g ${job.colorCode} krasitel")
        if (job.requiredResinKg > 0) Text("25 kg ga ${formatTpNumber(job.requiredColorGrams * 25.0 / job.requiredResinKg)} g", style = MaterialTheme.typography.bodySmall)
        if (resinStock + 1e-9 < job.requiredResinKg || colorStock + 1e-9 < job.requiredColorGrams) {
            Text("⚠ Ostatka kam: seryo ${formatTpNumber(resinStock)} kg • krasitel ${formatTpNumber(colorStock)} g", color = MaterialTheme.colorScheme.error)
        }
        job.materialDeliveredAt?.let { Text("Yetkazildi: ${it.take(16).replace('T', ' ')}", color = MaterialTheme.colorScheme.primary) }
        if (canDeliver) Button(onClick = onDelivered, modifier = Modifier.fillMaxWidth()) { Text("Yetkazildi") }
    }
}

@Composable
private fun TpMaterialMovementPage(
    data: TpData,
    repository: TpDataRepository,
    canWrite: Boolean,
    incoming: Boolean,
    refresh: () -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val movements = data.materials.flatMap { material ->
        material.movements.filter { movement -> movement.kind == if (incoming) TpMaterialMovementKind.IN else TpMaterialMovementKind.OUT }
            .map { movement -> material to movement }
    }.sortedByDescending { it.second.createdAt }
    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState(if (incoming) "TpSeryo-prixod" else "TpSeryo-rasxod"))
            .navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(if (incoming) "Prixod" else "Rasxod", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Sana va vaqt avtomatik qayd etiladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (canWrite) Button(onClick = { showDialog = true }, Modifier.fillMaxWidth()) { Text(if (incoming) "+ Prixod kiritish" else "+ Rasxod kiritish") }
        if (!message.isNullOrBlank()) Text(message!!, color = if (message!!.startsWith("Saqlandi")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
        if (movements.isEmpty()) Text("Hali yozuv yo‘q.")
        movements.take(150).forEach { (material, movement) ->
            TpCard {
                Text("${material.code} • ${if (material.type == TpMaterialType.RESIN) "Seryo" else "Krasitel"}", fontWeight = FontWeight.Bold)
                Text("${formatTpNumber(movement.amount)} ${if (material.type == TpMaterialType.RESIN) "kg" else "g"}")
                Text(movement.createdAt.take(16).replace('T', ' '), style = MaterialTheme.typography.bodySmall)
                if (movement.sourceJobId != null) Text("Stanokka chiqarilgan", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (movement.note.isNotBlank()) Text(movement.note, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    if (showDialog) TpMaterialMovementDialog(data, incoming, onDismiss = { showDialog = false }) { code, type, amount, note ->
        val result = repository.addMaterialMovement(code, type, amount, incoming, note)
        message = result.exceptionOrNull()?.message ?: "Saqlandi"
        if (result.isSuccess) refresh()
        result.isSuccess
    }
}

@Composable
private fun TpMaterialMovementDialog(
    data: TpData,
    incoming: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, TpMaterialType, Double, String) -> Boolean
) {
    var type by remember { mutableStateOf(TpMaterialType.RESIN) }
    var code by remember { mutableStateOf(data.materials.firstOrNull { !it.archived && it.type == TpMaterialType.RESIN }?.code.orEmpty()) }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (incoming) "Prixod" else "Rasxod") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                TpMaterialType.entries.forEachIndexed { index, option ->
                    SegmentedButton(
                        selected = type == option,
                        onClick = {
                            type = option
                            if (!incoming) code = data.materials.firstOrNull { !it.archived && it.type == option }?.code.orEmpty()
                        },
                        shape = SegmentedButtonDefaults.itemShape(index, TpMaterialType.entries.size)
                    ) { Text(if (option == TpMaterialType.RESIN) "Seryo" else "Krasitel") }
                }
            }
            if (incoming) TpField(code, { code = it.uppercase() }, "Kod")
            else TpChoice(
                label = "Kod", selectedId = code,
                options = data.materials.filter { !it.archived && it.type == type }.sortedBy { it.code },
                id = { it.code }, text = { "${it.code} • ostatka ${formatTpNumber(it.currentStock())}" }
            ) { code = it }
            TpField(amount, { amount = decimalInput(it) }, if (type == TpMaterialType.RESIN) "Miqdor (kg)" else "Miqdor (gram)", KeyboardType.Decimal)
            TpField(note, { note = it }, "Izoh (ixtiyoriy)", singleLine = false)
        } },
        confirmButton = { TextButton(onClick = {
            val parsed = amount.toDoubleOrNull()
            if (parsed != null && onSave(code, type, parsed, note)) onDismiss()
        }) { Text("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

@Composable
private fun TpMaterialBalancePage(data: TpData) {
    val context = LocalContext.current
    val now = remember { LocalDate.now() }
    var type by remember { mutableStateOf(TpMaterialType.RESIN) }
    var year by remember { mutableIntStateOf(now.year) }
    var month by remember { mutableIntStateOf(now.monthValue) }
    var day by remember { mutableIntStateOf(now.dayOfMonth) }
    var search by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf("CODE") }
    var descending by remember { mutableStateOf(false) }
    var exportMessage by remember { mutableStateOf<String?>(null) }

    val safeDay = if (month > 0) day.coerceAtMost(YearMonth.of(year, month).lengthOfMonth()) else 0
    if (safeDay != day) day = safeDay
    val period = remember(year, month, safeDay) { tpStockPeriod(year, month.takeIf { it > 0 }, safeDay.takeIf { month > 0 && it > 0 }) }
    val materials = data.materials.filter { !it.archived && it.type == type && it.code.contains(search.trim(), ignoreCase = true) }
    val sortedMaterials = materials.let { source ->
        val comparator = when (sort) {
            "IN" -> compareBy<TpMaterial> { it.periodIncoming(period) }
            "OUT" -> compareBy<TpMaterial> { it.periodOutgoing(period) }
            "STOCK" -> compareBy<TpMaterial> { it.closingAt(period.to) }
            else -> compareBy<TpMaterial> { it.code }
        }
        if (descending) source.sortedWith(comparator.reversed()) else source.sortedWith(comparator)
    }
    val report = remember(data, type, period, search) { buildTpStockBalanceReport(data, type, period, search) }
    val xlsxLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) { uri ->
        if (uri != null) exportMessage = runCatching { context.contentResolver.openOutputStream(uri)?.use { TpXlsxExporter.write(it, report.asTable()) } ?: error("Fayl ochilmadi"); "Excel saqlandi" }.getOrElse { it.message ?: "Excel saqlanmadi" }
    }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) exportMessage = runCatching { context.contentResolver.openOutputStream(uri)?.use { TpStockPdfExporter.write(it, report) } ?: error("Fayl ochilmadi"); "PDF saqlandi" }.getOrElse { it.message ?: "PDF saqlanmadi" }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpSeryo-balance"))
            .navigationBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Text("Ostatka", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            TpMaterialType.entries.forEachIndexed { index, option ->
                SegmentedButton(type == option, { type = option }, SegmentedButtonDefaults.itemShape(index, TpMaterialType.entries.size)) { Text(if (option == TpMaterialType.RESIN) "Seryo" else "Krasitel") }
            }
        }
        TpStockPeriodSelector(year, month, safeDay, onChange = { y, m, d -> year = y; month = m; day = d })
        Text("Davr: ${period.label}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        TpField(search, { search = it }, "Kod bo‘yicha qidiruv")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(Modifier.weight(1f)) {
                TpChoice("Tartib", sort, listOf("CODE" to "Kod", "IN" to "Prixod", "OUT" to "Rasxod", "STOCK" to "Ostatka"), { it.first }, { it.second }) { sort = it }
            }
            OutlinedButton(onClick = { descending = !descending }) { Text(if (descending) "↓" else "↑") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { xlsxLauncher.launch("ToyBola_${if (type == TpMaterialType.RESIN) "Seryo" else "Krasitel"}_${period.label.replace('.', '-')}.xlsx") }, Modifier.weight(1f)) { Text("Excel") }
            OutlinedButton(onClick = { pdfLauncher.launch("ToyBola_${if (type == TpMaterialType.RESIN) "Seryo" else "Krasitel"}_${period.label.replace('.', '-')}.pdf") }, Modifier.weight(1f)) { Text("PDF") }
        }
        exportMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
        Text(if (type == TpMaterialType.RESIN) "Seryo oldi-berdi" else "Krasitel oldi-berdi", fontWeight = FontWeight.Bold)
        StockHeaderRow()
        sortedMaterials.forEachIndexed { index, material ->
            StockDataRow(index + 1, material.code, material.periodIncoming(period), material.periodOutgoing(period), material.closingAt(period.to))
            HorizontalDivider()
        }
        if (sortedMaterials.isEmpty()) Text("Mos yozuv topilmadi.")
        Text("Ostatka — tanlangan davrning yakuniy holati.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun TpStockPeriodSelector(year: Int, month: Int, day: Int, onChange: (Int, Int, Int) -> Unit) {
    val current = LocalDate.now()
    val years = (current.year - 5..current.year + 1).toList().reversed()
    val months = listOf(0 to "Barcha oylar") + (1..12).map { it to "%02d".format(it) }
    val days = if (month > 0) listOf(0 to "Barcha kunlar") + (1..YearMonth.of(year, month).lengthOfMonth()).map { it to it.toString() } else listOf(0 to "—")
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.weight(1f)) { TpChoice("Yil", year.toString(), years, { it.toString() }, { it.toString() }) { selected -> onChange(selected.toInt(), month, day) } }
        Box(Modifier.weight(1f)) { TpChoice("Oy", month.toString(), months, { it.first.toString() }, { it.second }) { selected -> val m = selected.toInt(); onChange(year, m, if (m == 0) 0 else day.coerceAtMost(YearMonth.of(year, m).lengthOfMonth())) } }
        Box(Modifier.weight(1f)) { TpChoice("Kun", day.toString(), days, { it.first.toString() }, { it.second }) { selected -> onChange(year, month, selected.toInt()) } }
    }
}

@Composable
private fun StockHeaderRow() {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("№", Modifier.weight(.34f), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text("Kod", Modifier.weight(1.08f), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text("Prixod", Modifier.weight(.92f), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text("Rasxod", Modifier.weight(.92f), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text("Ostatka", Modifier.weight(1.02f), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
    HorizontalDivider()
}

@Composable
private fun StockDataRow(index: Int, code: String, incoming: Double, outgoing: Double, stock: Double) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(index.toString(), Modifier.weight(.34f), fontSize = 10.sp, maxLines = 1)
        Text(code, Modifier.weight(1.08f), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Text(formatTpNumber(incoming), Modifier.weight(.92f), fontSize = 10.sp, maxLines = 1)
        Text(formatTpNumber(outgoing), Modifier.weight(.92f), fontSize = 10.sp, maxLines = 1)
        Text(formatTpNumber(stock), Modifier.weight(1.02f), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun TpSeryoMonitoring(data: TpData) {
    val today = LocalDate.now().toString()
    val approvedIds = data.orders.filter { it.planApprovedAt != null }.map { it.id }.toSet()
    val pendingJobs = data.jobs.filter { it.orderId in approvedIds && it.status != TpJobStatus.COMPLETE && it.materialStatus != TpMaterialStatus.DELIVERED }
    val resinNeeds = pendingJobs.groupBy { it.resinCode }.mapValues { it.value.sumOf(TpPlanJob::requiredResinKg) }
    val colorNeeds = pendingJobs.groupBy { it.colorCode }.mapValues { it.value.sumOf(TpPlanJob::requiredColorGrams) }
    val shortages = (resinNeeds.map { Triple(TpMaterialType.RESIN, it.key, it.value) } + colorNeeds.map { Triple(TpMaterialType.COLOR, it.key, it.value) })
        .filter { (type, code, need) -> data.materialStock(type, code) + 1e-9 < need }
    val todayInResin = data.materials.filter { it.type == TpMaterialType.RESIN }.sumOf { it.dayIncoming(today) }
    val todayOutResin = data.materials.filter { it.type == TpMaterialType.RESIN }.sumOf { it.dayOutgoing(today) }
    val todayInColor = data.materials.filter { it.type == TpMaterialType.COLOR }.sumOf { it.dayIncoming(today) }
    val todayOutColor = data.materials.filter { it.type == TpMaterialType.COLOR }.sumOf { it.dayOutgoing(today) }
    val recent = data.materials.flatMap { material -> material.movements.map { movement -> material to movement } }.sortedByDescending { it.second.createdAt }.take(20)
    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpSeryo-monitoring"))
            .navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Seryo monitoring", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TpCard(Modifier.weight(1f)) { Text("${pendingJobs.size}", fontWeight = FontWeight.Bold); Text("Faol vazifa") }
            TpCard(Modifier.weight(1f)) { Text("${shortages.size}", fontWeight = FontWeight.Bold); Text("Yetishmovchilik") }
        }
        TpCard { Text("Bugungi seryo", fontWeight = FontWeight.Bold); Text("Prixod ${formatTpNumber(todayInResin)} kg • Rasxod ${formatTpNumber(todayOutResin)} kg") }
        TpCard { Text("Bugungi krasitel", fontWeight = FontWeight.Bold); Text("Prixod ${formatTpNumber(todayInColor)} g • Rasxod ${formatTpNumber(todayOutColor)} g") }
        Text("Holat", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Seryosi tasdiqlanmagan: ${pendingJobs.count { it.resinConfirmedAt == null }} • Tayyorlashda: ${pendingJobs.count { it.resinConfirmedAt != null }}")
        if (shortages.isNotEmpty()) {
            Text("Yetishmayotganlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
            shortages.sortedByDescending { it.third - data.materialStock(it.first, it.second) }.forEach { (type, code, need) ->
                val stock = data.materialStock(type, code)
                TpCard { Text(code, fontWeight = FontWeight.Bold); Text("Kerak ${formatTpNumber(need)} ${if (type == TpMaterialType.RESIN) "kg" else "g"} • Bor ${formatTpNumber(stock)}"); Text("Yetmaydi ${formatTpNumber((need - stock).coerceAtLeast(0.0))}", color = MaterialTheme.colorScheme.error) }
            }
        }
        Text("Oxirgi harakatlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        recent.forEach { (material, movement) -> Text("${movement.createdAt.take(16).replace('T', ' ')} • ${material.code} • ${if (movement.kind == TpMaterialMovementKind.IN) "+" else "−"}${formatTpNumber(movement.amount)} ${if (material.type == TpMaterialType.RESIN) "kg" else "g"}", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
fun TpReceivingScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val serverRevision by TpDataEvents.revision.collectAsState()
    var revision by remember { mutableIntStateOf(0) }
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(serverRevision, revision, policy.revision) { repository.load().scopedFor(policy) }
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_RECEIVING)
    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    val shifts = data.shifts.filterNot { it.archived }.sortedBy { it.name }
    var shopId by remember(shops) { mutableStateOf(shops.firstOrNull()?.id.orEmpty()) }
    var shiftId by remember(shifts) { mutableStateOf(shifts.firstOrNull()?.id.orEmpty()) }
    var selectedMachineId by remember { mutableStateOf<String?>(null) }
    var expandedMachineId by remember { mutableStateOf<String?>(null) }
    var receiptJobId by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    val activeBrigadeIds = data.brigades.filter { !it.archived && it.shopId == shopId && it.shiftId == shiftId }.map { it.id }.toSet()
    val jobs = data.jobs.filter { it.brigadeId in activeBrigadeIds && it.machineId != null && it.status == TpJobStatus.IN_PROGRESS }
    val machines = data.machines.filter { !it.archived && it.shopId == shopId && jobs.any { job -> job.machineId == it.id } }.sortedBy { it.number }
    val listScroll = rememberScrollState()
    LaunchedEffect(listScroll.value) { if (expandedMachineId != null && listScroll.value > 0) expandedMachineId = null }

    BackHandler(enabled = selectedMachineId != null) { selectedMachineId = null }
    Column(Modifier.fillMaxSize()) {
        AppTopBar("Qabul qilish", canGoBack = true, onMenu = {}, onBack = { if (selectedMachineId != null) selectedMachineId = null else onBack() })
        if (selectedMachineId == null) {
            Column(Modifier.fillMaxSize().verticalScroll(listScroll).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Sex", fontWeight = FontWeight.Bold); TpFilterRow(shops, shopId, { it.id }, { it.name }) { shopId = it; expandedMachineId = null }
                Text("Smena", fontWeight = FontWeight.Bold); TpFilterRow(shifts, shiftId, { it.id }, { it.name }) { shiftId = it; expandedMachineId = null }
                if (machines.isEmpty()) Text("Tanlangan sex va smenada ishlab turgan stanok yo‘q.")
                machines.forEach { machine ->
                    val machineJobs = jobs.filter { it.machineId == machine.id }.sortedBy { it.startedAt.orEmpty() }
                    val current = machineJobs.firstOrNull()
                    val order = current?.let { job -> data.orders.firstOrNull { it.id == job.orderId } }
                    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
                        Column {
                            Row(Modifier.fillMaxWidth().clickable { selectedMachineId = machine.id }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("${machine.number}-stanok", fontWeight = FontWeight.Bold)
                                    Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}")
                                    current?.let { Text("${it.outputs.joinToString { out -> out.detailName }} • ${it.colorCode}", style = MaterialTheme.typography.bodySmall) }
                                }
                                TextButton(onClick = { expandedMachineId = if (expandedMachineId == machine.id) null else machine.id }) { Text(if (expandedMachineId == machine.id) "▲" else "▼") }
                            }
                            if (expandedMachineId == machine.id) {
                                HorizontalDivider()
                                val history = data.receipts.filter { it.machineId == machine.id }.sortedByDescending { it.createdAt }.take(20)
                                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Qabul tarixi", fontWeight = FontWeight.Bold)
                                    if (history.isEmpty()) Text("Hali qabul yozuvi yo‘q.")
                                    history.forEach { r -> Text("${r.date} • ${r.workerNameSnapshot} • ${r.detailNameSnapshot} • ${r.creditedPieces} dona", style = MaterialTheme.typography.bodySmall) }
                                }
                            }
                        }
                    }
                }
                message?.let { Text(it, color = if (it.startsWith("Qabul")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
            }
        } else {
            val machine = data.machines.firstOrNull { it.id == selectedMachineId }
            val machineJobs = jobs.filter { it.machineId == selectedMachineId }.sortedBy { it.startedAt.orEmpty() }
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                TextButton(onClick = { selectedMachineId = null }) { Text("‹ Stanoklar") }
                Text("${machine?.number ?: 0}-stanok", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                machineJobs.forEach { job ->
                    val order = data.orders.firstOrNull { it.id == job.orderId }
                    TpCard {
                        Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.Bold)
                        Text("${job.outputs.joinToString { it.detailName }} • rang ${job.colorCode}")
                        Text("Seryo ${job.resinCode} • ${materialStatusLabel(job.materialStatus)}")
                    }
                }
                if (canWrite && machineJobs.isNotEmpty()) {
                    FilledTonalButton(onClick = { receiptJobId = machineJobs.first().id }, modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp)) { Text("＋ Qabul kiritish", fontWeight = FontWeight.Bold) }
                }
                Text("Oxirgi qabullar", fontWeight = FontWeight.Bold)
                data.receipts.filter { it.machineId == selectedMachineId }.sortedByDescending { it.createdAt }.take(30).forEach { r ->
                    TpCard { Text("${r.workerNameSnapshot} • ${r.detailNameSnapshot} • ${r.creditedPieces} dona", fontWeight = FontWeight.Bold); Text("${r.date} • ${r.completedBags} to‘liq qop • chala ${r.remainderAfter}") }
                }
            }
        }
    }

    receiptJobId?.let { initialJobId ->
        TpReceiptDialog(data, jobs.filter { it.machineId == selectedMachineId }, initialJobId, policy.displayName, onDismiss = { receiptJobId = null }) { jobId, detailId, workerId, date, bags, remainder, receiver ->
            val result = repository.addReceipt(jobId, detailId, workerId, date, bags, remainder, receiver)
            message = result.exceptionOrNull()?.message ?: "Qabul saqlandi"
            if (result.isSuccess) { receiptJobId = null; revision++ }
            result.isSuccess
        }
    }
}

@Composable
private fun TpReceiptDialog(
    data: TpData,
    jobs: List<TpPlanJob>,
    initialJobId: String,
    receiverDisplayName: String,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, Int, Int, String) -> Boolean
) {
    var jobId by remember { mutableStateOf(initialJobId) }
    val job = jobs.firstOrNull { it.id == jobId } ?: jobs.firstOrNull()
    var detailId by remember(jobId) { mutableStateOf(job?.outputs?.firstOrNull()?.detailId.orEmpty()) }
    val output = job?.outputs?.firstOrNull { it.detailId == detailId }
    val workers = data.workers.filter { !it.archived && it.brigadeId == job?.brigadeId }.sortedBy { it.name }
    var workerId by remember(jobId, workers) { mutableStateOf(workers.firstOrNull()?.id.orEmpty()) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var bags by remember { mutableStateOf("0") }
    var remainder by remember(jobId, detailId) { mutableStateOf((job?.let { data.openRemainder(it.id, detailId) } ?: 0).toString()) }
    val carry = job?.let { data.openRemainder(it.id, detailId) } ?: 0
    val preview = if (output != null) runCatching { calculateReceiptCredit(output.bagCapacity, carry, bags.toIntOrNull() ?: 0, remainder.toIntOrNull() ?: 0) }.getOrNull() else null
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Qabul kiritish") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (jobs.size > 1) TpChoice("Vazifa", jobId, jobs, { it.id }, { row -> val order = data.orders.firstOrNull { it.id == row.orderId }; "${order?.articleSnapshot.orEmpty()} • ${row.outputs.joinToString { it.detailName }} • ${row.colorCode}" }) { jobId = it }
            if (job != null && job.outputs.size > 1) TpChoice("Detal", detailId, job.outputs, { it.detailId }, { it.detailName }) { detailId = it }
            TpChoice("Ishchi", workerId, workers, { it.id }, { it.name }) { workerId = it }
            TpDatePickerButton("Sana", date) { date = it }
            TpField(bags, { bags = digitsOnly(it) }, "To‘liq qop soni", KeyboardType.Number)
            TpField(remainder, { remainder = digitsOnly(it) }, "Chala qopdagi dona", KeyboardType.Number)
            output?.let {
                Text("Qop sig‘imi ${it.bagCapacity} dona • oldingi chala $carry dona", style = MaterialTheme.typography.bodySmall)
                if (preview != null) Text("Ishchiga yoziladi: $preview dona", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                else Text("Qop sonlarini tekshiring", color = MaterialTheme.colorScheme.error)
            }
        } },
        confirmButton = { TextButton(enabled = job != null && output != null && workerId.isNotBlank() && preview != null, onClick = {
            if (onSave(job!!.id, detailId, workerId, date, bags.toIntOrNull() ?: 0, remainder.toIntOrNull() ?: 0, receiverDisplayName.ifBlank { "Qabul qiluvchi" })) onDismiss()
        }) { Text("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

@Composable
fun TpQualityScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val serverRevision by TpDataEvents.revision.collectAsState()
    var revision by remember { mutableIntStateOf(0) }
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(serverRevision, revision, policy.revision) { repository.load().scopedFor(policy) }
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_QUALITY)
    var mode by remember { mutableStateOf("ROUND") }
    Column(Modifier.fillMaxSize()) {
        AppTopBar("TP sifat", canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpQuality-main")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(mode == "ROUND", { mode = "ROUND" }, SegmentedButtonDefaults.itemShape(0, 2)) { Text("Baholash") }
                SegmentedButton(mode == "ISSUE", { mode = "ISSUE" }, SegmentedButtonDefaults.itemShape(1, 2)) { Text("Kun muammosi") }
            }
            if (mode == "ROUND") TpQualityMachineBoard(data, repository, policy, canWrite) { revision++ }
            else TpDailyIssueForm(data, repository, canWrite) { revision++ }
        }
    }
}

@Composable
private fun TpQualityMachineBoard(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, canWrite: Boolean, refresh: () -> Unit) {
    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    val shifts = data.shifts.filterNot { it.archived }.sortedBy { it.name }
    var shopId by remember(shops) { mutableStateOf(shops.firstOrNull()?.id.orEmpty()) }
    var shiftId by remember(shifts) { mutableStateOf(shifts.firstOrNull()?.id.orEmpty()) }
    var selectedJobId by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    val brigadeIds = data.brigades.filter { !it.archived && it.shopId == shopId && it.shiftId == shiftId }.map { it.id }.toSet()
    val jobs = data.jobs.filter { it.brigadeId in brigadeIds && it.machineId != null && it.status == TpJobStatus.IN_PROGRESS }.sortedBy { data.machines.firstOrNull { m -> m.id == it.machineId }?.number ?: Int.MAX_VALUE }
    Text("Sex", fontWeight = FontWeight.Bold); TpFilterRow(shops, shopId, { it.id }, { it.name }) { shopId = it }
    Text("Smena", fontWeight = FontWeight.Bold); TpFilterRow(shifts, shiftId, { it.id }, { it.name }) { shiftId = it }
    Text("Stanoklar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    if (jobs.isEmpty()) Text("Tanlangan sex va smenada baholanadigan stanok yo‘q.")
    jobs.groupBy { it.machineId }.entries.sortedBy { (id, _) -> data.machines.firstOrNull { it.id == id }?.number }.forEach { (machineId, machineJobs) ->
        val machine = data.machines.firstOrNull { it.id == machineId }
        val job = machineJobs.first()
        val order = data.orders.firstOrNull { it.id == job.orderId }
        val todayScores = data.qualityRounds.filter { it.machineId == machineId && it.date == LocalDate.now().toString() }
        Surface(Modifier.fillMaxWidth().clickable(enabled = canWrite) { selectedJobId = job.id }, shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${machine?.number ?: 0}-stanok", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}")
                    Text("${job.outputs.joinToString { it.detailName }} • ${job.colorCode}", style = MaterialTheme.typography.bodySmall)
                    if (todayScores.isNotEmpty()) Text("Bugungi baholar: ${todayScores.sortedBy { it.round }.joinToString { scoreLabel(it.score) }}", color = MaterialTheme.colorScheme.primary)
                }
                Text("›", style = MaterialTheme.typography.headlineSmall)
            }
        }
    }
    message?.let { Text(it, color = if (it.startsWith("Baholash")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
    selectedJobId?.let { id ->
        val job = jobs.firstOrNull { it.id == id }
        if (job != null) TpQualityEvaluationDialog(data, job, policy.displayName, onDismiss = { selectedJobId = null }) { workerId, date, round, score, issue, checker ->
            val result = repo.saveQualityRound(job.id, workerId, date, round, score, issue, checker)
            message = result.exceptionOrNull()?.message ?: "Baholash saqlandi"
            if (result.isSuccess) { selectedJobId = null; refresh() }
            result.isSuccess
        }
    }
}

@Composable
private fun TpQualityEvaluationDialog(
    data: TpData,
    job: TpPlanJob,
    checkerDisplayName: String,
    onDismiss: () -> Unit,
    onSave: (String, String, Int, Int, String, String) -> Boolean
) {
    val machine = data.machines.firstOrNull { it.id == job.machineId }
    val order = data.orders.firstOrNull { it.id == job.orderId }
    val workers = data.workers.filter { !it.archived && it.brigadeId == job.brigadeId }.sortedBy { it.name }
    val shift = data.shifts.firstOrNull { it.id == job.shiftId }
    var workerId by remember { mutableStateOf(workers.firstOrNull()?.id.orEmpty()) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var round by remember { mutableIntStateOf(1) }
    var grade by remember { mutableIntStateOf(0) }
    var issue by remember { mutableStateOf("") }
    val score = when (grade) { 1 -> 100; 2 -> 75; 3 -> 50; 4 -> 0; else -> -1 }
    val valid = workerId.isNotBlank() && grade in 1..4 && round in 1..(shift?.roundTimes?.size ?: 0) && (grade <= 2 || issue.isNotBlank())
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${machine?.number ?: 0}-stanok • Baholash") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.Bold)
            Text("${job.outputs.joinToString { it.detailName }} • rang ${job.colorCode}")
            TpChoice("Ishchi", workerId, workers, { it.id }, { it.name }) { workerId = it }
            TpDatePickerButton("Sana", date) { date = it }
            TpChoice("Raund", round.toString(), shift?.roundTimes.orEmpty().mapIndexed { index, time -> index + 1 to time }, { it.first.toString() }, { "${it.first}-raund • ${it.second}" }) { round = it.toInt() }
            Text("Baho", fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (1..4).forEach { value -> FilterChip(selected = grade == value, onClick = { grade = value }, label = { Text(value.toString()) }, modifier = Modifier.weight(1f)) }
            }
            if (grade > 0) Text("${scoreLabel(score)} • $score%", color = if (grade <= 2) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            TpField(issue, { issue = it }, if (grade >= 3) "Muammo/izoh *" else "Muammo/izoh", singleLine = false)
            if (grade >= 3) Text("3 yoki 4 bahoda izoh majburiy.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        } },
        confirmButton = { TextButton(enabled = valid, onClick = { if (onSave(workerId, date, round, score, issue, checkerDisplayName.ifBlank { "Sifat nazoratchisi" })) onDismiss() }) { Text("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

private fun scoreLabel(score: Int): String = when { score >= 100 -> "1"; score >= 75 -> "2"; score >= 50 -> "3"; else -> "4" }

@Composable
private fun TpDailyIssueForm(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val imageStorage = remember { DailyIssueImageStorage(context) }
    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    val shifts = data.shifts.filterNot { it.archived }.sortedBy { it.name }
    var shopId by remember(shops) { mutableStateOf(shops.firstOrNull()?.id.orEmpty()) }
    var shiftId by remember(shifts) { mutableStateOf(shifts.firstOrNull()?.id.orEmpty()) }
    val brigades = data.brigades.filter { !it.archived && it.shopId == shopId && it.shiftId == shiftId }
    val brigadeIds = brigades.map { it.id }.toSet()
    val machines = data.machines.filter { !it.archived && it.shopId == shopId }.sortedBy { it.number }
    var machineId by remember(shopId) { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var title by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var issueId by remember { mutableStateOf(UUID.randomUUID().toString()) }
    var selectedImage by remember { mutableStateOf<Uri?>(null) }
    var saving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    Text("Sex", fontWeight = FontWeight.Bold); TpFilterRow(shops, shopId, { it.id }, { it.name }) { shopId = it; machineId = "" }
    Text("Smena", fontWeight = FontWeight.Bold); TpFilterRow(shifts, shiftId, { it.id }, { it.name }) { shiftId = it }
    TpChoice("Stanok (ixtiyoriy)", machineId, listOf<TpMachine?>(null) + machines, { it?.id.orEmpty() }, { it?.let { m -> "${m.number}-stanok" } ?: "Belgilanmagan" }) { machineId = it }
    TpDatePickerButton("Sana", date) { date = it }
    TpField(title, { title = it }, "Muammo nomi")
    TpField(note, { note = it }, "Batafsil izoh", singleLine = false)
    IssueImagePickerButton(hasImage = selectedImage != null, enabled = canWrite && !saving, onSelected = { selectedImage = it })
    selectedImage?.let { AsyncImage(model = it, contentDescription = "Tanlangan rasm", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(180.dp)) }
    val selectedJob = data.jobs.firstOrNull { it.machineId == machineId && it.status == TpJobStatus.IN_PROGRESS }
    val brigadeId = selectedJob?.brigadeId ?: brigades.firstOrNull()?.id.orEmpty()
    val orderId = selectedJob?.orderId
    Button(enabled = canWrite && brigadeId.isNotBlank() && title.isNotBlank() && note.isNotBlank() && !saving, onClick = {
        coroutineScope.launch {
            saving = true
            runCatching {
                val ref = selectedImage?.let { imageStorage.upload(it, "tp", issueId) }
                repo.addDailyIssue(brigadeId, date, machineId.ifBlank { null }, orderId, title, note, issueId, ref?.url.orEmpty(), ref?.path.orEmpty()).getOrThrow()
            }.onSuccess { message = "Kun muammosi saqlandi"; title = ""; note = ""; selectedImage = null; issueId = UUID.randomUUID().toString(); refresh() }
                .onFailure { message = it.message ?: "Muammoni saqlab bo‘lmadi" }
            saving = false
        }
    }, modifier = Modifier.fillMaxWidth()) { Text(if (saving) "Saqlanmoqda…" else "Muammoni saqlash") }
    message?.let { Text(it, color = if (it.startsWith("Kun")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
    HorizontalDivider()
    data.dailyIssues.filter { it.date == date && it.brigadeId in brigadeIds }.sortedByDescending { it.createdAt }.forEach { issue ->
        val machine = data.machines.firstOrNull { it.id == issue.machineId }
        TpCard {
            Text(issue.title, fontWeight = FontWeight.Bold)
            if (machine != null) Text("${machine.number}-stanok", color = MaterialTheme.colorScheme.primary)
            Text(issue.note)
            if (issue.imageUrl.isNotBlank()) IssueImageBlock(issue.imageUrl, issue.imagePath)
            Text(issue.createdAt.take(16).replace('T', ' '), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun <T> TpFilterRow(items: List<T>, selectedId: String, id: (T) -> String, label: (T) -> String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEach { item -> FilterChip(selected = id(item) == selectedId, onClick = { onSelect(id(item)) }, label = { Text(label(item), maxLines = 1) }, modifier = Modifier.weight(1f)) }
    }
}

@Composable
private fun TpDatePickerButton(label: String, value: String, onDate: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) { Text("$label: $value", Modifier.weight(1f)) }
    if (open) {
        val initial = runCatching { LocalDate.parse(value) }.getOrDefault(LocalDate.now())
        val state = rememberDatePickerState(initialSelectedDateMillis = initial.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
        DatePickerDialog(
            onDismissRequest = { open = false },
            confirmButton = { TextButton(onClick = {
                state.selectedDateMillis?.let { millis -> onDate(Instant.ofEpochMilli(millis).atZone(ZoneOffset.UTC).toLocalDate().toString()) }
                open = false
            }) { Text("Tanlash") } },
            dismissButton = { TextButton(onClick = { open = false }) { Text("Bekor qilish") } }
        ) { DatePicker(state = state) }
    }
}
