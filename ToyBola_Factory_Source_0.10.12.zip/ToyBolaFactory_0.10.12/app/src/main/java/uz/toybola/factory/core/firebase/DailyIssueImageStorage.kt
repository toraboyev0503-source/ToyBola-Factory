package uz.toybola.factory.core.firebase

import android.content.Context
import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import java.util.UUID

private const val MAX_ISSUE_IMAGE_BYTES = 12L * 1024L * 1024L

data class IssueImageRef(val url: String, val path: String)

class DailyIssueImageStorage(context: Context) {
    private val appContext = context.applicationContext
    private val storage = FirebaseStorage.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val functions = FirebaseFunctions.getInstance("europe-west1")

    fun validate(uri: Uri): Result<Unit> = runCatching {
        val mime = appContext.contentResolver.getType(uri).orEmpty()
        require(mime.startsWith("image/")) { "Faqat rasm faylini tanlang" }
        val length = appContext.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        require(length <= 0L || length <= MAX_ISSUE_IMAGE_BYTES) { "Rasm hajmi 12 MB dan oshmasin" }
    }

    suspend fun upload(uri: Uri, scope: String, issueId: String): IssueImageRef {
        validate(uri).getOrThrow()
        refreshStorageClaims()
        val mime = appContext.contentResolver.getType(uri).orEmpty().ifBlank { "image/jpeg" }
        val extension = when (mime.lowercase()) {
            "image/png" -> "png"
            "image/webp" -> "webp"
            else -> "jpg"
        }
        val path = "dailyIssues/$scope/$issueId/${UUID.randomUUID()}.$extension"
        val ref = storage.reference.child(path)
        val metadata = StorageMetadata.Builder().setContentType(mime).build()
        ref.putFile(uri, metadata).awaitResult()
        val url = ref.downloadUrl.awaitResult().toString()
        return IssueImageRef(url, path)
    }

    suspend fun download(path: String, destination: Uri) {
        require(path.isNotBlank()) { "Rasm manzili topilmadi" }
        refreshStorageClaims()
        val bytes = storage.reference.child(path).getBytes(MAX_ISSUE_IMAGE_BYTES).awaitResult()
        appContext.contentResolver.openOutputStream(destination)?.use { it.write(bytes) }
            ?: error("Faylni saqlab bo‘lmadi")
    }

    suspend fun delete(path: String) {
        if (path.isBlank()) return
        refreshStorageClaims()
        runCatching { storage.reference.child(path).delete().awaitResult() }
    }

    private suspend fun refreshStorageClaims() {
        val user = auth.currentUser ?: error("Server sessiyasi mavjud emas. Qayta kiring.")
        // The callable refreshes server-side custom claims used by Storage Rules.
        functions.getHttpsCallable("getMyPolicy").call().awaitResult()
        user.getIdToken(true).awaitResult()
    }
}
