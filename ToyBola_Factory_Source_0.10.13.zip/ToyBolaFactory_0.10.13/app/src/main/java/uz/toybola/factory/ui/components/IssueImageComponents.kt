package uz.toybola.factory.ui.components

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import uz.toybola.factory.core.firebase.DailyIssueImageStorage
import java.time.LocalDateTime

@Composable
fun IssueImageBlock(imageUrl: String, imagePath: String, modifier: Modifier = Modifier) {
    if (imageUrl.isBlank()) return
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val storage = remember { DailyIssueImageStorage(context) }
    var message by remember { mutableStateOf<String?>(null) }

    fun openInGallery() {
        if (imagePath.isBlank()) {
            message = "Rasm manzili topilmadi"
            return
        }
        scope.launch {
            runCatching {
                val uri = storage.cacheForExternalView(imagePath)
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "image/*")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Rasmni ochish"))
            }.onFailure { message = it.message ?: "Rasmni ochib bo‘lmadi" }
        }
    }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/jpeg")) { uri ->
        if (uri != null) scope.launch {
            message = runCatching { storage.download(imagePath, uri); "Rasm saqlandi" }
                .getOrElse { it.message ?: "Rasmni yuklab bo‘lmadi" }
        }
    }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        AsyncImage(
            model = imageUrl,
            contentDescription = "Kun muammosi rasmi",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(14.dp)).clickable { openInGallery() }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { openInGallery() }) { Text("Galereyada ochish") }
            if (imagePath.isNotBlank()) OutlinedButton(onClick = {
                val suffix = LocalDateTime.now().toString().replace(':', '-').take(19)
                saveLauncher.launch("ToyBola_muammo_$suffix.jpg")
            }) { Text("Yuklab olish") }
        }
        message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
    }
}

@Composable
fun IssueImageGallery(imageUrls: List<String>, imagePaths: List<String>, modifier: Modifier = Modifier) {
    val urls = imageUrls.filter { it.isNotBlank() }.distinct().take(10)
    if (urls.isEmpty()) return
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        urls.forEachIndexed { index, url ->
            val path = imagePaths.getOrNull(index).orEmpty()
            IssueImageBlock(url, path)
        }
    }
}

@Composable
fun IssueImagePickerButton(
    hasImage: Boolean,
    enabled: Boolean = true,
    onSelected: (android.net.Uri) -> Unit
) {
    val context = LocalContext.current
    var chooserOpen by remember { mutableStateOf(false) }
    var pendingCameraUri by remember { mutableStateOf<android.net.Uri?>(null) }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) onSelected(uri)
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) onSelected(uri)
        pendingCameraUri = null
    }
    OutlinedButton(
        onClick = { chooserOpen = true },
        enabled = enabled,
        modifier = Modifier.fillMaxWidth()
    ) { Text(if (hasImage) "Yana rasm qo‘shish" else "Rasm qo‘shish") }

    if (chooserOpen) {
        AlertDialog(
            onDismissRequest = { chooserOpen = false },
            title = { Text("Rasm manbasini tanlang") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        chooserOpen = false
                        val file = java.io.File.createTempFile("issue_", ".jpg", context.cacheDir)
                        val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                        pendingCameraUri = uri
                        camera.launch(uri)
                    }, modifier = Modifier.fillMaxWidth()) { Text("Kamera") }
                    OutlinedButton(onClick = {
                        chooserOpen = false
                        gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }, modifier = Modifier.fillMaxWidth()) { Text("Galereya") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { chooserOpen = false }) { Text("Bekor qilish") } }
        )
    }
}
