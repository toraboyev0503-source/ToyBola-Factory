package uz.toybola.factory.core.firebase

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.core.notifications.NotificationScheduler
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.canReadAnyTp

class FirebaseSyncCoordinator(context: Context) {
    private val appContext = context.applicationContext
    private val repository = AssemblyDataRepository(appContext)
    private val outbox = AssemblySyncOutbox(appContext)
    private val policyCache = ServerPolicyCache(appContext)
    private val preferences = AppPreferences(appContext)
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()
    private val functions = FirebaseFunctions.getInstance("europe-west1")
    private val syncStatus = SyncStatusStore(appContext)
    private val migrationState = ServerMigrationState(appContext)

    suspend fun syncNow(): Result<Unit> = syncMutex.withLock {
        syncStatus.markSyncing()
        val result = runCatching {
            val user = auth.currentUser ?: return@runCatching
            val setup = preferences.setup() ?: error("Qurilma sozlamasi topilmadi")
            val cachedBefore = policyCache.load(setup.userCode)
            val policy = ServerAuthRepository(appContext).refreshPolicy().getOrNull()
                ?: cachedBefore
                ?: error("Server ruxsati topilmadi")
            if (cachedBefore != null && policy.revision != cachedBefore.revision) ServerPolicyEvents.notifyChanged()
            require(policy.uid.isBlank() || policy.uid == user.uid) { "Server sessiyasi boshqa foydalanuvchiga tegishli" }

            flushOutbox(user.uid)
            // 0.9.4: authoritative reads come from a scoped server-side snapshot. Direct
            // Firestore client reads are kept below only as legacy code, but no longer drive
            // normal bootstrap/sync because one legacy document could reject the whole query.
            val snapshot = ServerSnapshotRepository(appContext).download().getOrThrow()
            val remote = Pulled(snapshot.data, snapshot.hasSettings)
            val merged = mergeIntoLocal(repository.load(), remote.data, remote.hasSettings, policy)
            repository.replaceFromServer(merged)
            // Existing Sborka-only users must keep syncing normally; the TP snapshot endpoint is
            // called only when the current server policy grants at least one TP section.
            if (policy.canReadAnyTp()) TpSyncCoordinator(appContext).sync(policy, user.uid)
            NotificationScheduler.scheduleUpcoming(appContext, repository)
        }
        result.onSuccess { syncStatus.markSuccess() }
            .onFailure { error -> syncStatus.markFailure(error.message ?: error.javaClass.simpleName) }
        result
    }

    private suspend fun flushOutbox(uid: String) {
        val keys = outbox.pending().sorted()
        if (keys.isEmpty()) return
        val local = repository.load()
        val payload = repository.encodeForSync(local)
        keys.chunked(180).forEach { chunk ->
            val response = functions.getHttpsCallable("applyAssemblyWrites")
                .call(mapOf("keys" to chunk, "payload" to payload, "clientVersion" to "0.10.14"))
                .awaitResult()
            @Suppress("UNCHECKED_CAST")
            val body = response.data as? Map<String, Any?> ?: error("Server sync javobi noto‘g‘ri")
            @Suppress("UNCHECKED_CAST")
            val applied = (body["applied"] as? List<*>)?.mapNotNull { it?.toString() }.orEmpty()
            if (applied.isEmpty() && chunk.isNotEmpty()) error("Server sync hech bir yozuvni qabul qilmadi")
            applied.forEach { outbox.remove(it) }
        }
    }

    private fun applyOutboxKey(
        batch: com.google.firebase.firestore.WriteBatch,
        key: String,
        data: AssemblyData,
        uid: String
    ): Boolean {
        val prefix = key.substringBefore(':')
        val id = key.substringAfter(':', "")
        fun common(payload: String, brigadeId: String? = null, date: String? = null): MutableMap<String, Any> = mutableMapOf<String, Any>(
            "payload" to payload,
            "updatedAt" to FieldValue.serverTimestamp(),
            "updatedBy" to uid
        ).apply {
            brigadeId?.let { put("brigadeId", it) }
            date?.let { put("date", it) }
        }

        when (prefix) {
            "BRIGADE" -> {
                val item = data.brigades.firstOrNull { it.id == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(brigades = listOf(item)))
                batch.set(db.collection("brigades").document(item.id), common(payload, item.id).apply {
                    put("name", item.name); put("archived", item.archived); put("deleted", item.deleted)
                }, SetOptions.merge())
            }
            "WORKER" -> {
                val item = data.workers.firstOrNull { it.id == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(workers = listOf(item)))
                batch.set(db.collection("workers").document(item.id), common(payload, item.brigadeId).apply {
                    put("name", item.name); put("archived", item.archived); put("startDate", item.startDate)
                }, SetOptions.merge())
            }
            "PRODUCT" -> {
                val item = data.products.firstOrNull { it.id == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(products = listOf(item)))
                batch.set(db.collection("products").document(item.id), common(payload, item.brigadeId).apply {
                    put("article", item.article); put("name", item.name); put("archived", item.archived)
                }, SetOptions.merge())
            }
            "BRIGADE_FK" -> {
                val item = data.brigadeFk.firstOrNull { it.brigadeId == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(brigadeFk = listOf(item)))
                batch.set(db.collection("brigadeFk").document(item.brigadeId), common(payload, item.brigadeId), SetOptions.merge())
            }
            "WORKER_DAY" -> {
                val parts = id.split('|')
                if (parts.size != 2) return false
                val item = data.workerDays.firstOrNull { it.workerId == parts[0] && it.date == parts[1] } ?: return false
                val payload = repository.encodeForSync(AssemblyData(workerDays = listOf(item)))
                batch.set(db.collection("workerDays").document("${item.workerId}_${item.date}"), common(payload, item.brigadeId, item.date).apply {
                    put("workerId", item.workerId); put("worked", item.worked); put("hours", item.hours); put("earned", item.earned)
                }, SetOptions.merge())
            }
            "BRIGADE_DAY" -> {
                val parts = id.split('|')
                if (parts.size != 2) return false
                val item = data.brigadeDays.firstOrNull { it.brigadeId == parts[0] && it.date == parts[1] } ?: return false
                // BrigadeDay is intentionally stored as structured fields instead of an opaque payload.
                // This lets Firestore Security Rules enforce Brigadir-vs-Quality field ownership.
                val document = mutableMapOf<String, Any>(
                    "brigadeId" to item.brigadeId,
                    "date" to item.date,
                    "worked" to item.worked,
                    "brigadirClosed" to item.brigadirClosed,
                    "brigadirClosedAt" to item.brigadirClosedAt.orEmpty(),
                    "brigadirLateReason" to item.brigadirLateReason,
                    "qualityClosed" to item.qualityClosed,
                    "qualityClosedAt" to item.qualityClosedAt.orEmpty(),
                    "qualityLateReason" to item.qualityLateReason,
                    "fullyClosed" to item.fullyClosed,
                    "closedAt" to item.closedAt.orEmpty(),
                    "reopenCount" to item.reopenCount,
                    "lastReopenedAt" to item.lastReopenedAt.orEmpty(),
                    "lastReopenReason" to item.lastReopenReason,
                    "updatedAt" to FieldValue.serverTimestamp(),
                    "updatedBy" to uid
                )
                batch.set(db.collection("brigadeDays").document("${item.brigadeId}_${item.date}"), document, SetOptions.merge())
            }
            "QUALITY_ROUND" -> {
                val parts = id.split('|')
                if (parts.size != 3) return false
                val item = data.qualityRounds.firstOrNull { it.workerId == parts[0] && it.date == parts[1] && it.round == parts[2].toIntOrNull() } ?: return false
                val payload = repository.encodeForSync(AssemblyData(qualityRounds = listOf(item)))
                batch.set(db.collection("qualityRounds").document("${item.workerId}_${item.date}_${item.round}"), common(payload, item.brigadeId, item.date).apply {
                    put("workerId", item.workerId)
                    put("round", item.round)
                    put("finished", item.isFinished)
                    put("absenceType", item.absenceType)
                    put("absenceReason", item.absenceReason)
                    put("absenceAt", item.absenceAt.orEmpty())
                    item.grade?.let { put("grade", it) }
                    item.score?.let { put("score", it) }
                }, SetOptions.merge())
            }
            "DAILY_ISSUE" -> {
                val item = data.dailyIssues.firstOrNull { it.id == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(dailyIssues = listOf(item)))
                batch.set(db.collection("dailyIssues").document(item.id), common(payload, item.brigadeId, item.date).apply {
                    put("productId", item.productId); put("article", item.articleSnapshot); put("productName", item.productNameSnapshot)
                    put("stageId", item.stageId); put("stageName", item.stageNameSnapshot); put("note", item.note); put("createdAtText", item.createdAt)
                    put("imageUrl", item.imageUrl); put("imagePath", item.imagePath)
                }, SetOptions.merge())
            }
            "DAILY_ISSUE_DELETE" -> batch.delete(db.collection("dailyIssues").document(id))
            "AUDIT" -> {
                val item = data.auditLog.firstOrNull { it.id == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(auditLog = listOf(item)))
                batch.set(db.collection("auditLog").document(item.id), common(payload, item.brigadeId, item.recordDate).apply {
                    put("action", item.action); put("dateTime", item.dateTime); put("details", item.details)
                }, SetOptions.merge())
            }
            "SETTINGS" -> {
                val payload = repository.encodeForSync(AssemblyData(
                    workHours = data.workHours,
                    efficiencyNorm = data.efficiencyNorm,
                    roundTimes = data.roundTimes,
                    monitoringWeights = data.monitoringWeights,
                    preparedYears = data.preparedYears
                ))
                batch.set(db.collection("settings").document("assembly"), common(payload), SetOptions.merge())
            }
            else -> return false
        }
        return true
    }

    private data class Pulled(val data: AssemblyData, val hasSettings: Boolean)

    private suspend fun pullRemote(policy: UserAccessPolicy): Pulled {
        val brigadeDocs = if (policy.allowedBrigadeIds == null) {
            db.collection("brigades").get().awaitResult().documents
        } else {
            policy.allowedBrigadeIds.mapNotNull { brigadeId ->
                val document = db.collection("brigades").document(brigadeId).get().awaitResult()
                if (document.exists()) document else null
            }
        }
        val brigades = brigadeDocs.mapNotNull { document ->
            decodePayload(document)?.brigades?.firstOrNull()
                ?: document.getString("name")?.let { name ->
                    Brigade(
                        id = document.id,
                        name = name,
                        archived = document.getBoolean("archived") ?: false,
                        deleted = document.getBoolean("deleted") ?: false
                    )
                }
        }

        // IMPORTANT: even Admin reads brigade-scoped collections one brigade at a time.
        // Firestore list queries are all-or-nothing against Security Rules. One old/legacy
        // document without a structured brigadeId can make an unrestricted collection get()
        // fail and leave a freshly installed Admin client completely empty. Querying each
        // known brigade explicitly also fixes the dailyIssues Admin-refresh regression while
        // keeping Brigadir/Quality limited to their allowed brigade IDs.
        val scopeBrigadeIds = (policy.allowedBrigadeIds ?: brigadeDocs.map { it.id }.toSet())
            .filter { it.isNotBlank() }
            .toSet()

        val workers = decodeScoped("workers", scopeBrigadeIds) { it.workers }
        val products = decodeScoped("products", scopeBrigadeIds) { it.products }
        val fk = decodeScoped("brigadeFk", scopeBrigadeIds) { it.brigadeFk }
        val workerDays = decodeScoped("workerDays", scopeBrigadeIds) { it.workerDays }
        val brigadeDays = pullBrigadeDays(scopeBrigadeIds)
        val qualityRounds = decodeScoped("qualityRounds", scopeBrigadeIds) { it.qualityRounds }
        val dailyIssues = decodeScoped("dailyIssues", scopeBrigadeIds) { it.dailyIssues }
        val audit = if (policy.isAdmin()) {
            // Audit is useful but must never block a full bootstrap. Legacy audit rows can have
            // an older schema that makes an unrestricted Rules query fail.
            val docs = runCatching {
                db.collection("auditLog").limit(1000).get().awaitResult().documents
            }.getOrDefault(emptyList())
            decodeDocs(docs) { it.auditLog }
        } else {
            decodeScoped("auditLog", scopeBrigadeIds) { it.auditLog }
        }
        val settingsDoc = db.collection("settings").document("assembly").get().awaitResult()
        val settings = if (settingsDoc.exists()) decodePayload(settingsDoc) else null

        return Pulled(
            AssemblyData(
                brigades = brigades,
                workers = workers,
                products = products,
                brigadeFk = fk,
                workHours = settings?.workHours.orEmpty(),
                efficiencyNorm = settings?.efficiencyNorm.orEmpty(),
                roundTimes = settings?.roundTimes.orEmpty(),
                monitoringWeights = settings?.monitoringWeights.orEmpty(),
                preparedYears = settings?.preparedYears.orEmpty(),
                workerDays = workerDays,
                brigadeDays = brigadeDays,
                qualityRounds = qualityRounds,
                dailyIssues = dailyIssues,
                auditLog = audit
            ),
            settingsDoc.exists()
        )
    }


    private suspend fun pullBrigadeDays(brigadeIds: Set<String>): List<BrigadeDay> {
        val docs = buildList {
            brigadeIds.forEach { brigadeId ->
                addAll(db.collection("brigadeDays").whereEqualTo("brigadeId", brigadeId).get().awaitResult().documents)
            }
        }
        return docs.mapNotNull { doc ->
            val brigadeId = doc.getString("brigadeId") ?: return@mapNotNull null
            val date = doc.getString("date") ?: return@mapNotNull null
            BrigadeDay(
                brigadeId = brigadeId,
                date = date,
                worked = doc.getBoolean("worked") ?: true,
                brigadirClosedAt = doc.getString("brigadirClosedAt")?.ifBlank { null },
                brigadirLateReason = doc.getString("brigadirLateReason").orEmpty(),
                qualityClosedAt = doc.getString("qualityClosedAt")?.ifBlank { null },
                qualityLateReason = doc.getString("qualityLateReason").orEmpty(),
                closedAt = doc.getString("closedAt")?.ifBlank { null },
                reopenCount = (doc.getLong("reopenCount") ?: 0L).toInt(),
                lastReopenedAt = doc.getString("lastReopenedAt")?.ifBlank { null },
                lastReopenReason = doc.getString("lastReopenReason").orEmpty()
            )
        }
    }

    private suspend fun <T> decodeScoped(collection: String, brigadeIds: Set<String>, extract: (AssemblyData) -> List<T>): List<T> {
        if (brigadeIds.isEmpty()) return emptyList()
        val docs = buildList {
            brigadeIds.forEach { brigadeId ->
                addAll(db.collection(collection).whereEqualTo("brigadeId", brigadeId).get().awaitResult().documents)
            }
        }
        return decodeDocs(docs, extract)
    }

    private fun <T> decodeDocs(docs: List<DocumentSnapshot>, extract: (AssemblyData) -> List<T>): List<T> =
        docs.mapNotNull { document -> decodePayload(document) }.flatMap(extract)

    private fun decodePayload(doc: DocumentSnapshot): AssemblyData? {
        val payload = doc.getString("payload") ?: return null
        return runCatching { repository.decodeForSync(payload) }.getOrNull()
    }

    private fun mergeIntoLocal(local: AssemblyData, remote: AssemblyData, hasSettings: Boolean, policy: UserAccessPolicy): AssemblyData {
        // Most operational collections are archive/append based and are never hard-deleted by clients.
        // During the one-time legacy migration an empty remote collection must therefore NOT erase
        // real local data before it has been uploaded. Daily issues are the exception because they
        // support delete and must mirror the server exactly.
        fun <T> keepLocalIfRemoteEmpty(localItems: List<T>, remoteItems: List<T>): List<T> =
            if (remoteItems.isEmpty() && localItems.isNotEmpty()) localItems else remoteItems

        return local.copy(
            brigades = keepLocalIfRemoteEmpty(local.brigades, remote.brigades.distinctBy { it.id }),
            workers = keepLocalIfRemoteEmpty(local.workers, remote.workers.distinctBy { it.id }),
            products = keepLocalIfRemoteEmpty(local.products, remote.products.distinctBy { it.id }),
            brigadeFk = keepLocalIfRemoteEmpty(local.brigadeFk, remote.brigadeFk.distinctBy { it.brigadeId }),
            workHours = if (hasSettings) remote.workHours.ifEmpty { local.workHours } else local.workHours,
            efficiencyNorm = if (hasSettings) remote.efficiencyNorm.ifEmpty { local.efficiencyNorm } else local.efficiencyNorm,
            roundTimes = if (hasSettings) remote.roundTimes.ifEmpty { local.roundTimes } else local.roundTimes,
            monitoringWeights = if (hasSettings) remote.monitoringWeights.ifEmpty { local.monitoringWeights } else local.monitoringWeights,
            preparedYears = if (hasSettings) remote.preparedYears.ifEmpty { local.preparedYears } else local.preparedYears,
            workerDays = keepLocalIfRemoteEmpty(local.workerDays, remote.workerDays.distinctBy { "${it.workerId}|${it.date}" }),
            brigadeDays = keepLocalIfRemoteEmpty(local.brigadeDays, remote.brigadeDays.distinctBy { "${it.brigadeId}|${it.date}" }),
            qualityRounds = keepLocalIfRemoteEmpty(local.qualityRounds, remote.qualityRounds.distinctBy { "${it.workerId}|${it.date}|${it.round}" }),
            dailyIssues = if (migrationState.recoveryInProgress())
                keepLocalIfRemoteEmpty(local.dailyIssues, remote.dailyIssues.distinctBy { it.id })
            else remote.dailyIssues.distinctBy { it.id },
            auditLog = keepLocalIfRemoteEmpty(local.auditLog, remote.auditLog.distinctBy { it.id }.takeLast(2000))
        )
    }

    companion object {
        private val syncMutex = Mutex()
    }

}
