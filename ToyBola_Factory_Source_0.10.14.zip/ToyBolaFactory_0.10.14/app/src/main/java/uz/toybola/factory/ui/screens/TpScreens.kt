package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.components.SectionCard
import uz.toybola.factory.ui.model.AppScreen
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate

private data class TpMainItem(
    val title: String,
    val description: String,
    val screen: AppScreen,
    val badge: Int = 0
)

@Composable
fun TpMainScreen(
    strings: AppStrings,
    onBack: () -> Unit,
    canOpen: (AppScreen) -> Boolean,
    onOpen: (AppScreen) -> Unit
) {
    val context = LocalContext.current
    val revision by TpDataEvents.revision.collectAsState()
    val policy = remember(revision) { AccessGuard(context).currentPolicy() }
    val data = remember(revision, policy.revision) { TpDataRepository(context).load().scopedFor(policy) }
    val plannerPendingBadge = if (policy.isAdmin() || policy.canRead(AssemblySection.TP_PLANNING)) {
        data.orders.count { order ->
            if (order.status == TpOrderStatus.COMPLETE || order.status == TpOrderStatus.CANCELLED) false
            else {
                val jobs = data.jobs.filter { it.orderId == order.id }
                jobs.isEmpty() || jobs.any { it.planConfirmedAt == null }
            }
        }
    } else 0
    val machinePendingBadge = if (policy.isAdmin() || policy.canRead(AssemblySection.TP_MACHINE)) {
        data.jobs.filter { it.planConfirmedAt != null && it.materialStatus == TpMaterialStatus.DELIVERED && it.status == TpJobStatus.QUEUED }
            .groupBy { "${it.orderId}|${it.moldCode}|${it.machineId}" }.size
    } else 0
    val planBadge = plannerPendingBadge + machinePendingBadge
    val seryoBadge = if (policy.isAdmin() || policy.canRead(AssemblySection.TP_SERYO)) {
        val chooseResin = data.jobs.count { it.planConfirmedAt != null && it.resinConfirmedAt == null && it.status != TpJobStatus.COMPLETE }
        val prepareOrDeliver = data.jobs.count { it.resinConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED && it.status != TpJobStatus.COMPLETE }
        chooseResin + prepareOrDeliver
    } else 0
    val receivingBadge = if (policy.isAdmin() || policy.canRead(AssemblySection.TP_RECEIVING)) {
        data.jobs.count { it.status == TpJobStatus.IN_PROGRESS }
    } else 0
    val qualityBadge = if (policy.isAdmin() || policy.canRead(AssemblySection.TP_QUALITY)) {
        val today = LocalDate.now().toString()
        val now = java.time.LocalTime.now()
        data.jobs.filter { it.status == TpJobStatus.IN_PROGRESS && it.machineId != null }.groupBy { it.machineId }.count { (machineId, rows) ->
            val shift = rows.firstNotNullOfOrNull { job -> data.shifts.firstOrNull { it.id == job.shiftId } }
            shift?.roundTimes.orEmpty().mapIndexedNotNull { index, raw ->
                runCatching {
                    val time = java.time.LocalTime.parse(raw)
                    val distance = kotlin.math.abs(java.time.Duration.between(time, now).toMinutes())
                    val circular = minOf(distance, 24L * 60L - distance)
                    if (circular <= 60L) index + 1 else null
                }.getOrNull()
            }.any { roundNo -> data.qualityRounds.none { it.machineId == machineId && it.date == today && it.round == roundNo } }
        }
    } else 0
    val items = listOf(
        TpMainItem("Plan", "Zakaz va reja", AppScreen.TP_PLAN, planBadge),
        TpMainItem("Seryo", "Tayyorlash va qoldiq", AppScreen.TP_SERYO, seryoBadge),
        TpMainItem("Qabul qilish", "Detal qabuli", AppScreen.TP_RECEIVING, receivingBadge),
        TpMainItem("Sifat", "Raund va muammo", AppScreen.TP_QUALITY, qualityBadge),
        TpMainItem("Monitoring", "Natijalar", AppScreen.TP_MONITORING),
        TpMainItem("Ma’lumotlar", "Asosiy ma’lumotlar", AppScreen.TP_MASTER_DATA)
    )
    Column(Modifier.fillMaxSize()) {
        AppTopBar("TP va Seryo", canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-screen-1")).navigationBarsPadding().padding(16.dp)) {
            items.chunked(2).forEachIndexed { rowIndex, row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEachIndexed { index, item ->
                        SectionCard(
                            number = rowIndex * 2 + index + 1,
                            title = item.title,
                            description = item.description,
                            enabled = canOpen(item.screen),
                            badgeCount = item.badge,
                            modifier = if (row.size == 1) Modifier.fillMaxWidth() else Modifier.weight(1f),
                            onClick = { onOpen(item.screen) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

private enum class TpPlanPage { ROOT, ORDERS, PLANNING, MACHINES, ATTENDANCE, MASTER }

@Composable
fun TpPlanScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val eventRevision by TpDataEvents.revision.collectAsState()
    var localRevision by remember { mutableIntStateOf(0) }
    val policy = remember(eventRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(eventRevision, localRevision, policy.revision) { repository.load().scopedFor(policy) }
    var page by remember { mutableStateOf(TpPlanPage.ROOT) }
    var masterPage by remember { mutableStateOf(TpMasterPage.ROOT) }
    fun refresh() { localRevision++ }
    fun back() {
        when {
            page == TpPlanPage.MASTER && masterPage != TpMasterPage.ROOT -> masterPage = TpMasterPage.ROOT
            page == TpPlanPage.ROOT -> onBack()
            else -> { page = TpPlanPage.ROOT; masterPage = TpMasterPage.ROOT }
        }
    }
    BackHandler { back() }

    val title = when (page) {
        TpPlanPage.ROOT -> "Plan"
        TpPlanPage.ORDERS -> "Nachalnik zakazlari"
        TpPlanPage.PLANNING -> "Plan beruvchi"
        TpPlanPage.MACHINES -> "Stanok vazifalari"
        TpPlanPage.ATTENDANCE -> "Davomat"
        TpPlanPage.MASTER -> "TP ma’lumotlari"
    }
    Column(Modifier.fillMaxSize()) {
        AppTopBar(title, canGoBack = true, onMenu = {}, onBack = ::back)
        when (page) {
            TpPlanPage.ROOT -> TpPlanRoot(policy, data) { page = it }
            TpPlanPage.ORDERS -> TpOrdersPage(data, repository, policy, ::refresh)
            TpPlanPage.PLANNING -> TpPlanningPage(data, repository, policy, ::refresh)
            TpPlanPage.MACHINES -> TpMachineQueuePage(data, repository, policy, ::refresh)
            TpPlanPage.ATTENDANCE -> TpAttendancePage(data, repository, policy, ::refresh)
            TpPlanPage.MASTER -> TpMasterDataPage(data, repository, policy, ::refresh, masterPage) { masterPage = it }
        }
    }
}

@Composable
private fun TpPlanRoot(policy: UserAccessPolicy, data: TpData, onOpen: (TpPlanPage) -> Unit) {
    data class Item(val page: TpPlanPage, val title: String, val badge: Int = 0)
    val plannerBadge = data.orders.count { order ->
        order.status != TpOrderStatus.COMPLETE && order.status != TpOrderStatus.CANCELLED &&
            data.jobs.filter { it.orderId == order.id }.let { jobs -> jobs.isEmpty() || jobs.any { it.planConfirmedAt == null } }
    }
    val machineBadge = data.jobs.filter { it.planConfirmedAt != null && it.materialStatus == TpMaterialStatus.DELIVERED && it.status == TpJobStatus.QUEUED }
        .groupBy { "${it.orderId}|${it.moldCode}|${it.machineId}" }.size
    val items = buildList {
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_ORDER)) add(Item(TpPlanPage.ORDERS, "Nachalnik — zakazlar"))
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_PLANNING)) add(Item(TpPlanPage.PLANNING, "Plan beruvchi — rejalash", plannerBadge))
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_MACHINE)) add(Item(TpPlanPage.MACHINES, "TP brigadir — stanoklar", machineBadge))
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_ATTENDANCE)) add(Item(TpPlanPage.ATTENDANCE, "Davomat"))
    }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-screen-2")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Kerakli vazifani tanlang.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        items.forEach { item -> TpNavRow(item.title, item.badge) { onOpen(item.page) } }
    }
}

@Composable
private fun TpOrdersPage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_ORDER)
    var showAdd by remember { mutableStateOf(false) }
    var editOrder by remember { mutableStateOf<TpOrder?>(null) }
    var deleteOrder by remember { mutableStateOf<TpOrder?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val orders = data.orders.sortedWith(
        compareBy<TpOrder> { it.status == TpOrderStatus.COMPLETE || it.status == TpOrderStatus.CANCELLED }
            .thenBy { it.priority }
            .thenByDescending { it.createdAt }
    )

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-screen-3")).navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (canWrite) Button(onClick = { showAdd = true }, Modifier.fillMaxWidth()) { Text("+ Yangi zakaz") }
        if (orders.isEmpty()) Text("Hali zakaz kiritilmagan.")
        orders.forEach { order ->
            TpCard {
                TpOrderSummary(data, order)
                if (canWrite && order.status != TpOrderStatus.COMPLETE) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { editOrder = order }, Modifier.weight(1f)) { Text("Tahrirlash") }
                        OutlinedButton(onClick = { deleteOrder = order }, Modifier.weight(1f)) { Text("O‘chirish") }
                    }
                }
            }
        }
        TpError(error)
    }

    if (showAdd) {
        TpOrderDialog(data = data, initial = null, onDismiss = { showAdd = false }) { batch, productId, quantity, priority, note ->
            val result = repo.createOrder(batch, productId, quantity, priority, note)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { showAdd = false; refresh() }
            result.isSuccess
        }
    }

    editOrder?.let { order ->
        TpOrderDialog(data = data, initial = order, onDismiss = { editOrder = null }) { _, productId, quantity, priority, note ->
            val result = repo.updateOrder(order.id, productId, quantity, priority, note)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { editOrder = null; refresh() }
            result.isSuccess
        }
    }

    deleteOrder?.let { order ->
        AlertDialog(
            onDismissRequest = { deleteOrder = null },
            title = { Text("Zakazni o‘chirish") },
            text = { Text("${order.batchNumber} • ${order.articleSnapshot} zakazi o‘chirilsinmi? Zakaz o‘chirilgach plan vazifalari ham bekor qilinadi va bog‘liq TP/Seryo foydalanuvchilariga xabar boradi.") },
            confirmButton = { TextButton(onClick = {
                val result = repo.deleteOrder(order.id)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { deleteOrder = null; refresh() }
            }) { Text("O‘chirish") } },
            dismissButton = { TextButton(onClick = { deleteOrder = null }) { Text("Bekor qilish") } }
        )
    }
}

@Composable
private fun TpOrderDialog(
    data: TpData,
    initial: TpOrder?,
    onDismiss: () -> Unit,
    onSave: (String, String, Int, Int, String) -> Boolean
) {
    val products = data.products.filter { !it.archived && it.details.any { detail -> !detail.archived } }.sortedBy { it.article }
    var productId by remember(initial?.id) { mutableStateOf(initial?.productId ?: products.firstOrNull()?.id.orEmpty()) }
    var batch by remember(initial?.id) { mutableStateOf(initial?.batchNumber.orEmpty()) }
    var quantity by remember(initial?.id) { mutableStateOf(initial?.quantity?.toString().orEmpty()) }
    var priority by remember(initial?.id) { mutableIntStateOf(initial?.priority?.coerceIn(1, 3) ?: 2) }
    var note by remember(initial?.id) { mutableStateOf(initial?.note.orEmpty()) }
    var validation by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Yangi zakaz" else "Zakazni tahrirlash") },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (products.isEmpty()) Text("Avval mahsulot va uning detallarini kiriting.", color = MaterialTheme.colorScheme.error)
                if (initial != null) {
                    Text("Partiya: ${initial.batchNumber}", fontWeight = FontWeight.Bold)
                } else if (data.orders.isEmpty()) {
                    TpField(batch, { batch = it }, "Birinchi partiya raqami")
                } else {
                    Text("Keyingi partiya raqami avtomatik beriladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TpChoice("Mahsulot", productId, products, { it.id }, { "${it.article} — ${it.name}" }) { productId = it }
                TpField(quantity, { quantity = digitsOnly(it) }, "Zakaz soni", KeyboardType.Number)
                Text("Ustuvorlik", fontWeight = FontWeight.Bold)
                TpPriorityButtons(priority) { priority = it }
                TpField(note, { note = it }, "Izoh", singleLine = false)
                TpError(validation)
            }
        },
        confirmButton = { TextButton(enabled = products.isNotEmpty(), onClick = {
            val qty = quantity.toIntOrNull()
            validation = when {
                productId.isBlank() || qty == null || qty <= 0 -> "Majburiy maydonlarni to‘ldiring"
                else -> null
            }
            if (validation == null && onSave(batch, productId, qty!!, priority, note)) onDismiss()
        }) { Text("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

@Composable
private fun TpPriorityButtons(selected: Int, onSelect: (Int) -> Unit) {
    val values = listOf(
        Triple(1, "Eng zaril", Color(0xFFC62828)),
        Triple(2, "Zaril", Color(0xFFFFC107)),
        Triple(3, "Keyinroq", Color(0xFF2E7D32))
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        values.forEach { (value, label, color) ->
            val content = if (value == 2) Color.Black else Color.White
            Button(
                onClick = { onSelect(value) },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = color.copy(alpha = if (selected == value) 1f else 0.45f),
                    contentColor = content
                )
            ) { Text(if (selected == value) "✓ $label" else label, style = MaterialTheme.typography.labelSmall) }
        }
    }
}

@Composable
private fun TpOrderSummary(data: TpData, order: TpOrder) {
    val progress = data.orderProgress(order.id)
    val forecast = data.orderForecastMinutes(order.id)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("${order.batchNumber} • ${order.articleSnapshot}", fontWeight = FontWeight.Bold)
            Text("${order.productNameSnapshot} — ${order.quantity} dona")
        }
        Text("${progress.toInt()}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = tpPriorityColor(order.priority).copy(alpha = 0.16f)
        ) {
            Text(tpPriorityLabel(order.priority), modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontWeight = FontWeight.SemiBold)
        }
        Text("Holat: ${orderStatusLabel(order.status)}", style = MaterialTheme.typography.bodySmall)
    }
    Text("Zakaz berildi: ${order.createdAt.take(16).replace('T', ' ')}", style = MaterialTheme.typography.bodySmall)
    Text(
        if (forecast > 0) "Taxminiy to‘liq quyish: ${minutesLabel(forecast)}" else "Taxminiy muddat: ma’lumot yetarli emas",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    if (order.note.isNotBlank()) Text("Izoh: ${order.note}", style = MaterialTheme.typography.bodySmall)
    if (order.completedAt != null) Text("Yakunlandi: ${order.completedAt.take(16).replace('T', ' ')}", style = MaterialTheme.typography.bodySmall)
}

private fun tpPriorityColor(priority: Int): Color = when (priority.coerceIn(1, 3)) {
    1 -> Color(0xFFC62828)
    2 -> Color(0xFFFFC107)
    else -> Color(0xFF2E7D32)
}

private enum class TpPlannerMode { ORDERS, MACHINES }

@Composable
private fun TpPlanningPage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_PLANNING)
    var mode by remember { mutableStateOf(TpPlannerMode.ORDERS) }
    var selectedOrderId by remember { mutableStateOf<String?>(null) }
    var expandedDetails by remember { mutableStateOf<Set<String>>(emptySet()) }
    var assignMold by remember { mutableStateOf<String?>(null) }
    var openColorMenu by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    val visibleOrders = data.orders.filter { it.status != TpOrderStatus.COMPLETE && it.status != TpOrderStatus.CANCELLED }
    fun orderPlanDone(order: TpOrder): Boolean {
        val jobs = data.jobs.filter { it.orderId == order.id }
        return jobs.isNotEmpty() && jobs.all { it.planConfirmedAt != null }
    }
    val pendingOrders = visibleOrders.filterNot(::orderPlanDone)
        .sortedWith(compareBy<TpOrder> { it.priority }.thenBy { it.createdAt })
    val approvedOrders = visibleOrders.filter(::orderPlanDone)
        .sortedWith(compareBy<TpOrder> { it.planApprovedAt.orEmpty() }.thenBy { it.createdAt })
    val selectedOrder = data.orders.firstOrNull { it.id == selectedOrderId }

    BackHandler(enabled = selectedOrder != null || mode == TpPlannerMode.MACHINES) {
        if (selectedOrder != null) {
            selectedOrderId = null; expandedDetails = emptySet(); assignMold = null; openColorMenu = null
        } else mode = TpPlannerMode.ORDERS
    }

    LaunchedEffect(selectedOrderId) {
        val orderId = selectedOrderId ?: return@LaunchedEffect
        val order = data.orders.firstOrNull { it.id == orderId } ?: return@LaunchedEffect
        if (canWrite && order.status != TpOrderStatus.COMPLETE && data.jobs.none { it.orderId == orderId }) {
            val result = repo.generateOrderPlan(orderId)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) refresh()
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == TpPlannerMode.ORDERS, onClick = { mode = TpPlannerMode.ORDERS }, label = { Text("Zakazlar bo‘yicha") }, modifier = Modifier.weight(1f))
            FilterChip(selected = mode == TpPlannerMode.MACHINES, onClick = { mode = TpPlannerMode.MACHINES; selectedOrderId = null }, label = { Text("Stanoklar bo‘yicha") }, modifier = Modifier.weight(1f))
        }
        if (mode == TpPlannerMode.MACHINES) {
            TpPlannerMachinesView(data, repo, canWrite, refresh)
            return@Column
        }

        val scrollKey = selectedOrder?.let { "tp-planning-order-${it.id}" } ?: "tp-planning-list"
        Column(
            Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState(scrollKey)).navigationBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (selectedOrder == null) {
                Text("Zakazlarni detalma-detal rejalang. Tasdiqlangan detal darhol Seryo brigadiriga o‘tadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Tasdiqlanmagan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (pendingOrders.isEmpty()) Text("Ko‘rib chiqilishi kerak bo‘lgan zakaz yo‘q.")
                pendingOrders.forEach { order ->
                    val jobs = data.jobs.filter { it.orderId == order.id }
                    val remaining = if (jobs.isEmpty()) data.products.firstOrNull { it.id == order.productId }?.details?.count { !it.archived } ?: 0
                    else jobs.groupBy { it.moldCode }.count { (_, rows) -> rows.any { it.planConfirmedAt == null } }
                    TpCard(Modifier.clickable { selectedOrderId = order.id }) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f)) { TpOrderSummary(data, order) }
                            if (remaining > 0) Surface(shape = RoundedCornerShape(999.dp), color = Color(0xFFD32F2F)) {
                                Text(remaining.toString(), Modifier.padding(horizontal = 8.dp, vertical = 3.dp), color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text("Tasdiqlanmagan detal: $remaining", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                Text("Tasdiqlangan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (approvedOrders.isEmpty()) Text("Hali barcha detallari tasdiqlangan zakaz yo‘q.")
                approvedOrders.forEach { order -> TpCard(Modifier.clickable { selectedOrderId = order.id }) { TpOrderSummary(data, order) } }
            } else {
                TextButton(onClick = { selectedOrderId = null; expandedDetails = emptySet() }) { Text("‹ Zakazlar") }
                TpCard { TpOrderSummary(data, selectedOrder) }
                val product = data.products.firstOrNull { it.id == selectedOrder.productId }
                val details = product?.details?.filterNot { it.archived }.orEmpty().sortedWith(compareBy<TpDetail> { detail ->
                    val rows = data.jobs.filter { it.orderId == selectedOrder.id && it.outputs.any { out -> out.detailId == detail.id } }
                    rows.isNotEmpty() && rows.all { it.planConfirmedAt != null }
                }.thenBy { it.name })
                if (details.isEmpty()) Text("Mahsulot detallari topilmadi.", color = MaterialTheme.colorScheme.error)
                details.forEach { detail ->
                    val detailJobs = data.jobs.filter { job -> job.orderId == selectedOrder.id && job.outputs.any { it.detailId == detail.id } }
                        .sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id })
                    val confirmed = detailJobs.isNotEmpty() && detailJobs.all { it.planConfirmedAt != null }
                    val machineIds = detailJobs.mapNotNull { it.machineId }.distinct()
                    val machineLabel = when {
                        detailJobs.isEmpty() -> "Stanok"
                        machineIds.size == 1 -> {
                            val machine = data.machines.firstOrNull { it.id == machineIds.first() }
                            val shop = machine?.let { m -> data.shops.firstOrNull { it.id == m.shopId }?.name }.orEmpty()
                            if (machine == null) "Stanok" else "${machine.number} • ${shop.ifBlank { "Sex" }}"
                        }
                        machineIds.isEmpty() -> "Stanok"
                        else -> "Aralash"
                    }
                    val total = selectedOrder.quantity * detail.requiredPerProduct
                    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp,
                        color = if (confirmed) MaterialTheme.colorScheme.primaryContainer.copy(alpha = .55f) else MaterialTheme.colorScheme.surface) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Column(Modifier.weight(1f)) {
                                    Text(detail.name, fontWeight = FontWeight.Bold)
                                    Text("Jami: $total dona", color = MaterialTheme.colorScheme.primary)
                                    if (confirmed) Text("✓ Rejalangan va tasdiqlangan", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                                }
                                Button(enabled = canWrite && detailJobs.isNotEmpty(), onClick = { assignMold = detail.moldCode }) {
                                    Text(if (confirmed) "Tahrirlash • $machineLabel" else machineLabel)
                                }
                            }
                            val assignedMachineId = machineIds.singleOrNull()?.takeIf { id -> detailJobs.all { it.machineId == id } }
                            if (assignedMachineId != null) {
                                val targetIds = detailJobs.map { it.id }.toSet()
                                val wait = data.jobs.filter { it.machineId == assignedMachineId && it.status != TpJobStatus.COMPLETE && it.id !in targetIds && it.planConfirmedAt != null }.sumOf { it.estimatedMinutes }
                                Text(if (wait > 0) "Boshlanishi taxminan ${minutesLabel(wait)} dan keyin" else "Stanok bo‘sh — boshlash mumkin", style = MaterialTheme.typography.bodySmall)
                            }
                            if (!confirmed && detailJobs.isNotEmpty() && detailJobs.all { it.machineId != null && it.brigadeId != null && it.shiftId != null }) {
                                Button(enabled = canWrite, onClick = {
                                    val result = repo.confirmPlannedMold(selectedOrder.id, detail.moldCode)
                                    error = result.exceptionOrNull()?.message
                                    if (result.isSuccess) refresh()
                                }, Modifier.fillMaxWidth()) { Text("✓ Shu detalni tasdiqlash") }
                            }
                            TextButton(onClick = { expandedDetails = if (detail.id in expandedDetails) expandedDetails - detail.id else expandedDetails + detail.id }) {
                                Text(if (detail.id in expandedDetails) "▲ Ranglarni yopish" else "▼ Ranglarni ko‘rish")
                            }
                            if (detail.id in expandedDetails) {
                                detailJobs.forEachIndexed { index, job ->
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Text("${job.colorCode} — ${job.outputs.firstOrNull { it.detailId == detail.id }?.requiredPieces ?: 0} dona", Modifier.weight(1f))
                                        if (!confirmed && canWrite) Box {
                                            OutlinedButton(onClick = { openColorMenu = job.id }) { Text("${index + 1}") }
                                            DropdownMenu(expanded = openColorMenu == job.id, onDismissRequest = { openColorMenu = null }) {
                                                detailJobs.indices.forEach { pos -> DropdownMenuItem(text = { Text("${pos + 1}-navbat") }, onClick = {
                                                    openColorMenu = null
                                                    val result = repo.setColorPosition(job.id, pos + 1)
                                                    error = result.exceptionOrNull()?.message
                                                    if (result.isSuccess) refresh()
                                                }) }
                                            }
                                        } else Text("${index + 1}")
                                    }
                                }
                            }
                        }
                    }
                }
                val remaining = data.jobs.filter { it.orderId == selectedOrder.id }.groupBy { it.moldCode }.count { (_, rows) -> rows.any { it.planConfirmedAt == null } }
                if (remaining > 0) Text("Tasdiqlanmagan detal: $remaining. Har bir detal tasdiqlangach Seryoga alohida yuboriladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                else Text("✓ Barcha detallar rejalandi. Zakaz avtomatik tasdiqlanganlar ro‘yxatiga o‘tdi.", color = MaterialTheme.colorScheme.primary)
            }
            TpError(error)
        }
    }

    val order = selectedOrder
    val mold = assignMold
    if (order != null && mold != null) {
        val target = data.jobs.filter { it.orderId == order.id && it.moldCode == mold }
        val editing = target.any { it.planConfirmedAt != null }
        TpMachinePickerDialog(
            data = data, order = order, moldCode = mold, editing = editing,
            onDismiss = { assignMold = null },
            onSave = { machineId, brigadeId, reason ->
                val result = repo.assignMoldJobs(order.id, mold, machineId, brigadeId, reason)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { assignMold = null; refresh() }
                result.isSuccess
            }
        )
    }
}

@Composable
private fun TpPlannerMachinesView(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    var shopId by remember(shops) { mutableStateOf(shops.firstOrNull()?.id.orEmpty()) }
    var selectedMachineId by remember { mutableStateOf<String?>(null) }
    var showMachineOrders by remember { mutableStateOf(false) }
    var selectedOrderId by remember { mutableStateOf<String?>(null) }
    var assignMold by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val machines = data.machines.filter { !it.archived && (shopId.isBlank() || it.shopId == shopId) }
    fun remaining(machineId: String): Int = data.jobs.filter { it.machineId == machineId && it.planConfirmedAt != null && it.status != TpJobStatus.COMPLETE }.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
    fun lastActivity(machineId: String): String = data.jobs.filter { it.machineId == machineId }.mapNotNull { it.startedAt ?: it.materialDeliveredAt ?: it.planEditedAt ?: it.planConfirmedAt }.maxOrNull().orEmpty()
    val idle = machines.filter { remaining(it.id) == 0 }.sortedWith(compareBy<TpMachine> { lastActivity(it.id) }.thenBy { it.number })
    val busy = machines.filter { remaining(it.id) > 0 }.sortedWith(compareBy<TpMachine> { remaining(it.id) }.thenBy { it.number })
    val selectedMachine = machines.firstOrNull { it.id == selectedMachineId }

    BackHandler(enabled = selectedMachineId != null) { selectedMachineId = null; showMachineOrders = false; selectedOrderId = null; assignMold = null }
    LaunchedEffect(selectedOrderId) {
        val id = selectedOrderId ?: return@LaunchedEffect
        if (data.jobs.none { it.orderId == id } && canWrite) {
            val result = repo.generateOrderPlan(id); error = result.exceptionOrNull()?.message; if (result.isSuccess) refresh()
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("tp-planner-machines")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (selectedMachine == null) {
            Text("Sex", fontWeight = FontWeight.Bold)
            TpFilterRow(shops, shopId, { it.id }, { it.name }) { shopId = it }
            Text("Ishsiz stanoklar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (idle.isEmpty()) Text("Ishsiz stanok yo‘q.")
            idle.forEach { machine -> TpCard(Modifier.clickable { selectedMachineId = machine.id; showMachineOrders = false }) { Text("${machine.number}-stanok", fontWeight = FontWeight.Bold); Text("Ishsiz • eng oxirgi faoliyat: ${lastActivity(machine.id).take(16).replace('T',' ').ifBlank { "noma’lum" }}") } }
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Text("Ishi bor stanoklar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            busy.forEach { machine ->
                val mins = remaining(machine.id)
                TpCard(Modifier.clickable { selectedMachineId = machine.id; showMachineOrders = false }) {
                    Text("${machine.number}-stanok", fontWeight = FontWeight.Bold)
                    Text("Ishi: ${minutesLabel(mins)}", color = if (mins <= 1080) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                    if (mins <= 1080) Text("⚠ 18 soat yoki undan kam ish qolgan", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            TextButton(onClick = { selectedMachineId = null; showMachineOrders = false; selectedOrderId = null }) { Text("‹ Stanoklar") }
            TpCard {
                Text("${selectedMachine.number}-stanok", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Jami rejalangan ish: ${minutesLabel(remaining(selectedMachine.id))}")
                val queue = data.jobs.filter { it.machineId == selectedMachine.id && it.planConfirmedAt != null && it.status != TpJobStatus.COMPLETE }.sortedBy { it.priority }
                queue.take(5).forEach { job ->
                    val order = data.orders.firstOrNull { it.id == job.orderId }
                    Text("• ${order?.articleSnapshot.orEmpty()} • ${job.outputs.joinToString { it.detailName }} • ${job.colorCode}", style = MaterialTheme.typography.bodySmall)
                }
            }
            FilledTonalButton(onClick = { showMachineOrders = !showMachineOrders; if (!showMachineOrders) selectedOrderId = null }, modifier = Modifier.fillMaxWidth()) {
                Text(if (showMachineOrders) "Zakazlarni yopish" else "Zakazlar")
            }
            if (showMachineOrders) {
            Text("Zakazlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            val orders = data.orders.filter { it.status != TpOrderStatus.COMPLETE && it.status != TpOrderStatus.CANCELLED }.sortedWith(compareBy<TpOrder> { it.priority }.thenBy { it.createdAt })
            if (selectedOrderId == null) {
                orders.forEach { order ->
                    val jobs = data.jobs.filter { it.orderId == order.id && it.status != TpJobStatus.COMPLETE }
                    val candidates = if (jobs.isNotEmpty()) jobs else run {
                        var previewIndex = 0
                        buildPlanJobs(data, order) { "preview-${order.id}-${previewIndex++}" }
                    }
                    val compatible = candidates.any { it.acceptsMachine(selectedMachine, data) }
                    if (compatible) TpCard(Modifier.clickable { selectedOrderId = order.id }) { TpOrderSummary(data, order); Text("Shu stanokka mos detallarni ko‘rish", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
                }
            } else {
                val order = data.orders.firstOrNull { it.id == selectedOrderId }
                TextButton(onClick = { selectedOrderId = null }) { Text("‹ Zakazlar") }
                if (order != null) {
                    TpCard { TpOrderSummary(data, order) }
                    val groups = data.jobs.filter { it.orderId == order.id && it.status != TpJobStatus.COMPLETE }.groupBy { it.moldCode }
                    val compatible = groups.filterValues { rows -> rows.all { it.acceptsMachine(selectedMachine, data) } }
                    val incompatible = groups.filterKeys { it !in compatible.keys }
                    compatible.forEach { (mold, rows) ->
                        val names = rows.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString()
                        val plannedMachine = rows.mapNotNull { it.machineId }.distinct().singleOrNull()
                        val plannedNumber = data.machines.firstOrNull { it.id == plannedMachine }?.number
                        val confirmed = rows.all { it.planConfirmedAt != null }
                        TpCard {
                            Text(names.ifBlank { mold }, fontWeight = FontWeight.Bold)
                            Text(if (plannedMachine == selectedMachine.id) "Shu stanokka rejalangan${if (confirmed) " • tasdiqlangan" else ""}" else if (plannedMachine != null) "Rejalangan: ${plannedNumber ?: "?"}-stanok" else "Rejalanmagan")
                            if (canWrite) Button(onClick = { assignMold = mold }, Modifier.fillMaxWidth()) { Text(if (plannedMachine == null) "Shu stanokka rejalash" else "Planni tahrirlash") }
                            if (!confirmed && plannedMachine == selectedMachine.id && rows.all { it.brigadeId != null }) Button(onClick = { val r=repo.confirmPlannedMold(order.id,mold); error=r.exceptionOrNull()?.message; if(r.isSuccess) refresh() }, Modifier.fillMaxWidth()) { Text("✓ Tasdiqlash") }
                        }
                    }
                    if (incompatible.isNotEmpty()) {
                        HorizontalDivider(); Text("⚠ Bu stanokka tushmaydigan detallar", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                        incompatible.forEach { (_, rows) -> Text("• ${rows.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString()}", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            }
            TpError(error)
        }
    }
    val order = data.orders.firstOrNull { it.id == selectedOrderId }
    val mold = assignMold
    if (selectedMachine != null && order != null && mold != null) {
        val target = data.jobs.filter { it.orderId == order.id && it.moldCode == mold }
        TpFixedMachineAssignDialog(data, order, target, selectedMachine, target.any { it.machineId != null }, onDismiss = { assignMold = null }) { brigadeId, reason ->
            val r = repo.assignMoldJobs(order.id, mold, selectedMachine.id, brigadeId, reason); error = r.exceptionOrNull()?.message
            if (r.isSuccess) { assignMold = null; refresh() }; r.isSuccess
        }
    }
}

private fun commonJobResinOptions(data: TpData, job: TpPlanJob): List<String> {
    val sets = job.outputs.mapNotNull { output ->
        data.products.asSequence().flatMap { it.details.asSequence() }
            .firstOrNull { it.id == output.detailId }?.resinOptions()?.toSet()
    }
    if (sets.isEmpty()) return listOfNotNull(job.resinCode.takeIf { it.isNotBlank() })
    return sets.drop(1).fold(sets.first()) { acc, set -> acc intersect set }.sorted()
}

@Composable
private fun TpMachinePickerDialog(
    data: TpData,
    order: TpOrder,
    moldCode: String,
    editing: Boolean = false,
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Boolean
) {
    val targetJobs = data.jobs.filter { it.orderId == order.id && it.moldCode == moldCode }
    val targetIds = targetJobs.map { it.id }.toSet()
    fun availability(machineId: String): Int = data.jobs
        .filter { it.machineId == machineId && it.status != TpJobStatus.COMPLETE && it.id !in targetIds }
        .sumOf { it.estimatedMinutes }
    val machines = data.machines
        .filter { machine -> !machine.archived && targetJobs.isNotEmpty() && targetJobs.all { it.acceptsMachine(machine, data) } }
        .sortedWith(compareBy<TpMachine> { availability(it.id) }.thenBy { it.number })
    val currentMachineId = targetJobs.mapNotNull { it.machineId }.distinct().singleOrNull()
    var machineId by remember(order.id, moldCode) { mutableStateOf(currentMachineId ?: machines.firstOrNull()?.id.orEmpty()) }
    val selectedMachine = machines.firstOrNull { it.id == machineId }
    val brigades = data.brigades.filter { !it.archived && (selectedMachine == null || it.shopId == selectedMachine.shopId) }.sortedBy { it.name }
    val currentBrigade = targetJobs.mapNotNull { it.brigadeId }.distinct().singleOrNull()
    var brigadeId by remember(machineId) {
        mutableStateOf(currentBrigade?.takeIf { id -> brigades.any { it.id == id } } ?: brigades.firstOrNull()?.id.orEmpty())
    }
    var infoMachine by remember { mutableStateOf<TpMachine?>(null) }
    var editReason by remember(order.id, moldCode, editing) { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Stanok tanlash") },
        text = {
            Column(Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val detailNames = targetJobs.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString()
                if (detailNames.isNotBlank()) Text("Detal: $detailNames", fontWeight = FontWeight.Bold)
                if (machines.isEmpty()) {
                    Text("Bu detal/qolip sig‘imiga mos stanok topilmadi. Stanok va detal sig‘im ma’lumotlarini tekshiring.", color = MaterialTheme.colorScheme.error)
                } else {
                    Text("Bo‘sh stanoklar tepada. Band stanoklar eng tez bo‘shaydiganidan boshlab tartiblangan.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val freeMachines = machines.filter { availability(it.id) == 0 }
                    val busyMachines = machines.filter { availability(it.id) > 0 }
                    if (freeMachines.isNotEmpty()) Text("Bo‘sh stanoklar", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    (freeMachines + busyMachines).forEachIndexed { index, machine ->
                        if (index == freeMachines.size && busyMachines.isNotEmpty()) {
                            Text("Band stanoklar", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        val wait = availability(machine.id)
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable { machineId = machine.id },
                            shape = RoundedCornerShape(14.dp),
                            tonalElevation = if (machine.id == machineId) 4.dp else 1.dp
                        ) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                RadioButton(selected = machine.id == machineId, onClick = { machineId = machine.id })
                                Column(Modifier.weight(1f)) {
                                    val shopName = data.shops.firstOrNull { it.id == machine.shopId }?.name.orEmpty()
                                    Text("${machine.number}-stanok • ${shopName.ifBlank { "Sex" }}${if (machine.capacity > 0) " • sig‘im ${machine.capacity}" else ""}", fontWeight = FontWeight.Bold)
                                    Text(if (wait == 0) "Bo‘sh" else "Band • taxminan ${minutesLabel(wait)} dan keyin bo‘shaydi", color = if (wait == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                TextButton(onClick = { infoMachine = machine }) { Text("Ma’lumot") }
                            }
                        }
                    }
                    selectedMachine?.let { machine ->
                        val wait = availability(machine.id)
                        Text(if (wait == 0) "Tanlangan stanokda ishni darhol boshlash mumkin." else "Tanlangan stanokda boshlanish: taxminan ${minutesLabel(wait)} dan keyin.", fontWeight = FontWeight.SemiBold)
                        if (brigades.isNotEmpty()) TpChoice("Brigada", brigadeId, brigades, { it.id }, { it.name }) { brigadeId = it }
                        else Text("Bu sex uchun brigada kiritilmagan.", color = MaterialTheme.colorScheme.error)
                        if (editing) {
                            TpField(editReason, { editReason = it }, "Tahrirlash sharhi *", singleLine = false)
                            Text("Tasdiqlangan/rejalangan detalni o‘zgartirish sababi majburiy.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(enabled = machineId.isNotBlank() && brigadeId.isNotBlank() && (!editing || editReason.isNotBlank()), onClick = {
            if (onSave(machineId, brigadeId, editReason)) onDismiss()
        }) { Text(if (editing) "Tahrirlash" else "Tanlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )

    infoMachine?.let { machine ->
        val current = data.activeJobsForMachine(machine.id).firstOrNull { it.id !in targetIds }
        val currentOrder = current?.let { job -> data.orders.firstOrNull { it.id == job.orderId } }
        AlertDialog(
            onDismissRequest = { infoMachine = null },
            title = { Text("${machine.number}-stanok") },
            text = {
                if (current == null) Text("Hozir bo‘sh.") else Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Hozir band", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                    Text("Partiya: ${currentOrder?.batchNumber.orEmpty()}")
                    Text("Artikul: ${currentOrder?.articleSnapshot.orEmpty()}")
                    Text("Mahsulot: ${currentOrder?.productNameSnapshot.orEmpty()}")
                    Text("Detal: ${current.outputs.joinToString { it.detailName }}")
                    Text("Rang: ${current.colorCode}")
                    if (current.resinCode.isNotBlank()) Text("Seryo: ${current.resinCode}")
                    Text("Holat: ${jobStatusLabel(current.status)}")
                    Text("Taxminiy vazifa vaqti: ${minutesLabel(current.estimatedMinutes)}")
                }
            },
            confirmButton = { TextButton(onClick = { infoMachine = null }) { Text("Yopish") } }
        )
    }
}

@Composable
private fun TpFixedMachineAssignDialog(
    data: TpData,
    order: TpOrder,
    targetJobs: List<TpPlanJob>,
    machine: TpMachine,
    editing: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Boolean
) {
    val brigades = data.brigades.filter { !it.archived && it.shopId == machine.shopId }.sortedBy { it.name }
    val currentBrigade = targetJobs.mapNotNull { it.brigadeId }.distinct().singleOrNull()
    var brigadeId by remember(machine.id, order.id) { mutableStateOf(currentBrigade?.takeIf { id -> brigades.any { it.id == id } } ?: brigades.firstOrNull()?.id.orEmpty()) }
    var reason by remember(machine.id, order.id, editing) { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${machine.number}-stanokka rejalash") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${order.articleSnapshot} • ${order.productNameSnapshot}", fontWeight = FontWeight.Bold)
            Text(targetJobs.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString())
            if (brigades.isNotEmpty()) TpChoice("Brigada", brigadeId, brigades, { it.id }, { it.name }) { brigadeId = it }
            else Text("Bu sexda brigada yo‘q.", color = MaterialTheme.colorScheme.error)
            if (editing) TpField(reason, { reason = it }, "Tahrirlash sharhi *", singleLine = false)
        } },
        confirmButton = { TextButton(enabled = brigadeId.isNotBlank() && (!editing || reason.isNotBlank()), onClick = { if (onSave(brigadeId, reason)) onDismiss() }) { Text("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

@Composable
private fun TpMachineQueuePage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_MACHINE)
    var error by remember { mutableStateOf<String?>(null) }
    var expandedKey by remember { mutableStateOf<String?>(null) }
    val allowed = policy.allowedBrigadeIds
    val jobs = data.jobs.filter {
        it.planConfirmedAt != null && it.machineId != null && it.status != TpJobStatus.COMPLETE &&
            (policy.isAdmin() || allowed == null || it.brigadeId in allowed)
    }
    val grouped = jobs.groupBy { "${it.orderId}|${it.moldCode}|${it.machineId}" }
    val pendingGroups = grouped.values.filter { rows -> rows.any { it.status != TpJobStatus.IN_PROGRESS } }
        .sortedBy { rows -> rows.minOfOrNull { it.planConfirmedAt.orEmpty() } }
    val startedGroups = grouped.values.filter { rows -> rows.any { it.status == TpJobStatus.IN_PROGRESS } }
        .sortedByDescending { rows -> rows.maxOfOrNull { it.startedAt.orEmpty() }.orEmpty() }

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-machine-queue"))
            .navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Boshlash kerak", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (pendingGroups.isEmpty()) Text("Boshlashni kutayotgan vazifa yo‘q.")
        pendingGroups.forEach { rows ->
            val sample = rows.first()
            val key = "${sample.orderId}|${sample.moldCode}|${sample.machineId}"
            val machine = data.machines.firstOrNull { it.id == sample.machineId }
            val shop = machine?.let { m -> data.shops.firstOrNull { it.id == m.shopId } }
            val order = data.orders.firstOrNull { it.id == sample.orderId }
            val detailNames = rows.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString()
            TpCard {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${machine?.number ?: 0}-stanok • ${shop?.name.orEmpty()}", fontWeight = FontWeight.Bold)
                        Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}")
                        Text(detailNames)
                        Text("Detal bo‘yicha jami taxminiy: ${minutesLabel(rows.sumOf { it.estimatedMinutes.coerceAtLeast(0) })}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Ranglar: ${rows.map { it.colorCode }.distinct().joinToString()}", style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick = { expandedKey = if (expandedKey == key) null else key }) { Text(if (expandedKey == key) "▲" else "▼") }
                }
                if (expandedKey == key) {
                    HorizontalDivider(Modifier.padding(vertical = 5.dp))
                    rows.sortedBy { it.priority }.forEach { job ->
                        val delivered = job.materialStatus == TpMaterialStatus.DELIVERED
                        val started = job.status == TpJobStatus.IN_PROGRESS
                        Surface(
                            Modifier.fillMaxWidth().padding(vertical = 3.dp),
                            shape = RoundedCornerShape(12.dp),
                            color = if (started) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .45f)
                        ) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Rang ${job.colorCode} • Seryo ${job.resinCode}", fontWeight = FontWeight.SemiBold)
                                Text(tpBrigadirTimingLabel(job), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(if (delivered) "✓ Seryo yetkazilgan" else "Seryo yetkazilmagan", color = if (delivered) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                                if (canWrite && !started) Button(
                                    enabled = job.status == TpJobStatus.QUEUED && delivered,
                                    onClick = {
                                        error = repo.setJobStatus(job.id, TpJobStatus.IN_PROGRESS).exceptionOrNull()?.message
                                        if (error == null) refresh()
                                    }, modifier = Modifier.fillMaxWidth()
                                ) { Text("Boshlash") }
                                if (started) Text("Boshlangan: ${job.startedAt?.take(16)?.replace('T', ' ') ?: "—"}")
                            }
                        }
                    }
                }
            }
        }

        HorizontalDivider(Modifier.padding(vertical = 6.dp))
        Text("Boshlangan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (startedGroups.isEmpty()) Text("Hozir ishda turgan vazifa yo‘q.")
        startedGroups.forEach { rows ->
            val sample = rows.first()
            val machine = data.machines.firstOrNull { it.id == sample.machineId }
            val shop = machine?.let { m -> data.shops.firstOrNull { it.id == m.shopId } }
            val order = data.orders.firstOrNull { it.id == sample.orderId }
            val detailNames = rows.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString()
            Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("${machine?.number ?: 0}-stanok • ${shop?.name.orEmpty()}", fontWeight = FontWeight.Bold)
                    Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}")
                    Text(detailNames)
                    Text("Detal bo‘yicha jami taxminiy: ${minutesLabel(rows.sumOf { it.estimatedMinutes.coerceAtLeast(0) })}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    rows.filter { it.status == TpJobStatus.IN_PROGRESS }.sortedBy { it.priority }.forEach { job ->
                        Text("• ${job.colorCode} • boshlangan ${job.startedAt?.take(16)?.replace('T', ' ') ?: "—"}")
                        Text(tpBrigadirTimingLabel(job), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        val completeReady = job.outputs.all { output ->
                            data.receipts.filter { it.jobId == job.id && it.detailId == output.detailId }.sumOf { it.creditedPieces } >= output.requiredPieces
                        }
                        if (canWrite && completeReady) Button(onClick = {
                            error = repo.setJobStatus(job.id, TpJobStatus.COMPLETE).exceptionOrNull()?.message
                            if (error == null) refresh()
                        }, Modifier.fillMaxWidth()) { Text("${job.colorCode} ni yakunlash") }
                    }
                }
            }
        }
        TpError(error)
    }
}

@Composable
private fun TpAttendancePage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_ATTENDANCE)
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    var shopId by remember { mutableStateOf("") }
    val brigades = data.brigades.filterNot { it.archived }.filter { shopId.isBlank() || it.shopId == shopId }.sortedBy { it.name }
    var brigadeId by remember(shopId) { mutableStateOf("") }
    var editWorker by remember { mutableStateOf<TpWorker?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val visibleBrigadeIds = brigades.map { it.id }.toSet()
    val workers = data.workers.filter { !it.archived && it.brigadeId in visibleBrigadeIds && (brigadeId.isBlank() || it.brigadeId == brigadeId) }.sortedBy { it.name }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-screen-6")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Davomatni TP plan beruvchi kiritadi. Ish vaqti smena davomiyligidan minus soatni ayirish orqali avtomatik hisoblanadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        TpField(date, { date = it }, "Sana (YYYY-MM-DD)")
        TpChoice("Bo‘lim", shopId, listOf(TpShop("", "Barcha bo‘limlar")) + shops, { it.id }, { it.name }) { shopId = it }
        TpChoice("Brigada", brigadeId, listOf(TpBrigade("", "", "", "Barcha brigadalar")) + brigades, { it.id }, { it.name }) { brigadeId = it }
        if (workers.isEmpty()) Text("Tanlangan filtrda ishchi yo‘q.")
        val fullWorkers = workers.filter { worker -> data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }.let { day -> day == null || (day.present && day.minusHours <= 0.0) } }
        val minusWorkers = workers.filter { worker -> data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }?.let { it.present && it.minusHours > 0.0 } == true }
        val absentWorkers = workers.filter { worker -> data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }?.present == false }
        val groups = listOf("To‘liq ishlagan" to fullWorkers, "Minus soati bor" to minusWorkers, "Ishlamagan" to absentWorkers)
        groups.forEachIndexed { groupIndex, (groupTitle, groupWorkers) ->
            if (groupIndex > 0) HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Text(groupTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (groupWorkers.isEmpty()) Text("—", color = MaterialTheme.colorScheme.onSurfaceVariant)
            groupWorkers.forEach { worker ->
                val day = data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }
                val actualMinutes = if (day == null) data.workerStandardMinutes(worker.id) else data.attendanceWorkMinutes(worker.id, date)
                TpCard(Modifier.clickable(enabled = canWrite) { editWorker = worker }) {
                    Text(worker.name, fontWeight = FontWeight.Bold)
                    Text(data.brigades.firstOrNull { it.id == worker.brigadeId }?.name.orEmpty(), style = MaterialTheme.typography.bodySmall)
                    Text(when {
                        day == null -> "To‘liq ishlagan (standart) • ${data.workerStandardMinutes(worker.id)} daqiqa"
                        !day.present -> "Ishlamadi"
                        day.minusHours > 0.0 -> "Minus ${formatTpNumber(day.minusHours)} soat • hisobdagi ish vaqti $actualMinutes daqiqa"
                        else -> "To‘liq ishlagan • $actualMinutes daqiqa"
                    })
                    Text("Umumiy kunlik norma: ${data.globalDailyTargetAmount()} so‘m", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        TpError(error)
    }
    editWorker?.let { worker ->
        val existing = data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }
        var present by remember(worker.id, date) { mutableStateOf(existing?.present ?: true) }
        var minusHours by remember(worker.id, date) { mutableStateOf(existing?.minusHours?.takeIf { it > 0.0 }?.let(::formatTpNumber) ?: "") }
        val standardMinutes = data.workerStandardMinutes(worker.id)
        val parsedMinus = minusHours.toDoubleOrNull() ?: 0.0
        val calculated = if (present) (standardMinutes - kotlin.math.round(parsedMinus * 60.0).toInt()).coerceAtLeast(0) else 0
        AlertDialog(
            onDismissRequest = { editWorker = null },
            title = { Text(worker.name) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Smena bo‘yicha standart: ${minutesLabel(standardMinutes)}")
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Ishda", Modifier.weight(1f)); Switch(present, { present = it; if (!it) minusHours = "" }) }
                TpField(minusHours, { minusHours = decimalInput(it) }, "Minus soat", KeyboardType.Decimal, enabled = present)
                Text("Hisoblanadigan ish vaqti: ${minutesLabel(calculated)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Masalan 1 soat = 60 daqiqa, 1.5 soat = 90 daqiqa.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } },
            confirmButton = { TextButton(onClick = {
                val result = repo.setAttendance(worker.id, date, present, minusHours.toDoubleOrNull() ?: 0.0)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { editWorker = null; refresh() }
            }) { Text("Saqlash") } },
            dismissButton = { TextButton(onClick = { editWorker = null }) { Text("Bekor qilish") } }
        )
    }
}

@Composable
internal fun TpNavRow(title: String, badgeCount: Int = 0, onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            if (badgeCount > 0) {
                Surface(shape = RoundedCornerShape(999.dp), color = Color(0xFFD32F2F)) {
                    Text(badgeCount.coerceAtMost(999).toString(), Modifier.padding(horizontal = 8.dp, vertical = 2.dp), color = Color.White, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(8.dp))
            }
            Text("›", style = MaterialTheme.typography.headlineSmall)
        }
    }
}

@Composable
internal fun TpCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp), content = content)
    }
}

@Composable
internal fun TpField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    enabled: Boolean = true
) {
    val numeric = keyboardType == KeyboardType.Number || keyboardType == KeyboardType.Decimal
    var focusedBefore by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        modifier = Modifier.fillMaxWidth().onFocusChanged { state ->
            if (numeric && state.isFocused && !focusedBefore && value.trim() in setOf("0", "0.0", "0.00")) onChange("")
            focusedBefore = state.isFocused
        },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType), singleLine = singleLine, enabled = enabled
    )
}

@Composable
internal fun <T> TpChoice(
    label: String,
    selectedId: String,
    options: List<T>,
    id: (T) -> String,
    text: (T) -> String,
    onSelect: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val selected = options.firstOrNull { id(it) == selectedId }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: ${selected?.let(text) ?: "Tanlang"}", Modifier.weight(1f))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(text(option)) }, onClick = { open = false; onSelect(id(option)) }) }
        }
    }
}

@Composable
internal fun TpError(message: String?) {
    if (!message.isNullOrBlank()) Text(message, color = MaterialTheme.colorScheme.error)
}

internal fun digitsOnly(value: String): String = value.filter(Char::isDigit)
internal fun decimalInput(value: String): String {
    var separator = false
    return buildString {
        value.forEach { char ->
            if (char.isDigit()) append(char)
            else if ((char == '.' || char == ',') && !separator) { append('.'); separator = true }
        }
    }
}
private fun tpBrigadirTimingLabel(job: TpPlanJob): String {
    val planned = minutesLabel(job.estimatedMinutes.coerceAtLeast(0))
    val started = job.startedAt?.let { runCatching { java.time.LocalDateTime.parse(it) }.getOrNull() }
        ?: return "Taxminiy davomiylik: $planned"
    val finish = started.plusMinutes(job.estimatedMinutes.coerceAtLeast(0).toLong())
    val remaining = java.time.Duration.between(java.time.LocalDateTime.now(), finish).toMinutes().coerceAtLeast(0L).toInt()
    val finishTime = finish.format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"))
    return "Taxminiy tugash: $finishTime • qolgan ${minutesLabel(remaining)}"
}

internal fun minutesLabel(minutes: Int): String = "${minutes / 60} soat ${minutes % 60} daqiqa"
internal fun orderStatusLabel(status: TpOrderStatus): String = when (status) {
    TpOrderStatus.NEW -> "Yangi"; TpOrderStatus.PLANNING -> "Rejalanmoqda"; TpOrderStatus.READY -> "Tayyor"
    TpOrderStatus.APPROVED -> "Tasdiqlangan"; TpOrderStatus.IN_PROGRESS -> "Quyilmoqda"
    TpOrderStatus.COMPLETE -> "Yakunlangan"; TpOrderStatus.CANCELLED -> "Bekor qilingan"
}
internal fun jobStatusLabel(status: TpJobStatus): String = when (status) {
    TpJobStatus.UNASSIGNED -> "Taqsimlanmagan"; TpJobStatus.QUEUED -> "Navbatda"; TpJobStatus.IN_PROGRESS -> "Ishda"
    TpJobStatus.COMPLETE -> "Yakunlangan"; TpJobStatus.HOLD -> "Kutilmoqda"
}
internal fun materialStatusLabel(status: TpMaterialStatus): String = when (status) {
    TpMaterialStatus.PLANNED -> "Tayyorlanmagan"; TpMaterialStatus.CONFIRMED -> "Tayyor"; TpMaterialStatus.DELIVERED -> "Stanokka chiqarilgan"
}
