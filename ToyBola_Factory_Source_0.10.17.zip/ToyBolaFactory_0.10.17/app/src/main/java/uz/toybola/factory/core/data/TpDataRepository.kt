package uz.toybola.factory.core.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import uz.toybola.factory.core.firebase.FirebaseSyncScheduler
import uz.toybola.factory.core.firebase.TpAccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.firebase.TpSyncOutbox
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.Locale
import java.util.UUID
import kotlin.math.round

class TpDataRepository(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val accessGuard = TpAccessGuard(appContext)
    private val outbox = TpSyncOutbox(appContext)

    @Synchronized
    fun load(): TpData {
        val raw = prefs.getString(KEY_DATA, null) ?: return defaultData().also(::saveLocal)
        return runCatching { decode(JSONObject(raw)) }.getOrElse { defaultData().also(::saveLocal) }
    }

    @Synchronized
    fun addShop(name: String): Result<Unit> = mutate { data ->
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Sex nomini kiriting" }
        require(data.shops.none { !it.archived && it.name.equals(clean, true) }) { "Bunday sex mavjud" }
        data.copy(shops = data.shops + TpShop(UUID.randomUUID().toString(), clean))
            .audit("TP_SHOP_ADD", details = clean)
    }

    @Synchronized
    fun updateShift(id: String, name: String, startTime: String, endTime: String, roundTimes: List<String>): Result<Unit> = mutate { data ->
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Smena nomini kiriting" }
        LocalTime.parse(startTime)
        LocalTime.parse(endTime)
        require(roundTimes.isNotEmpty()) { "Kamida bitta sifat raundi bo‘lsin" }
        roundTimes.forEach(LocalTime::parse)
        val updated = data.shifts.map { if (it.id == id) it.copy(name = clean, startTime = startTime, endTime = endTime, roundTimes = roundTimes) else it }
        require(updated.any { it.id == id }) { "Smena topilmadi" }
        data.copy(shifts = updated).audit("TP_SHIFT_UPDATE", details = "$clean $startTime–$endTime / ${roundTimes.joinToString()}")
    }

    @Synchronized
    fun addBrigade(shopId: String, shiftId: String, name: String): Result<Unit> = mutate { data ->
        require(data.shops.any { it.id == shopId && !it.archived }) { "Sexni tanlang" }
        require(data.shifts.any { it.id == shiftId && !it.archived }) { "Smenani tanlang" }
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Brigada nomini kiriting" }
        val brigade = TpBrigade(UUID.randomUUID().toString(), shopId, shiftId, clean)
        data.copy(brigades = data.brigades + brigade).audit("TP_BRIGADE_ADD", brigade.id, details = clean)
    }

    @Synchronized
    fun updateBrigade(id: String, shopId: String, shiftId: String, name: String): Result<Unit> = mutate { data ->
        require(data.shops.any { it.id == shopId && !it.archived }) { "Sexni tanlang" }
        require(data.shifts.any { it.id == shiftId && !it.archived }) { "Smenani tanlang" }
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Brigada nomini kiriting" }
        require(data.brigades.any { it.id == id }) { "Brigada topilmadi" }
        data.copy(brigades = data.brigades.map { if (it.id == id) it.copy(shopId = shopId, shiftId = shiftId, name = clean) else it })
            .audit("TP_BRIGADE_UPDATE", id, details = clean)
    }

    @Synchronized
    fun addMachine(shopId: String, number: Int, name: String, capacity: Int): Result<Unit> = mutate { data ->
        require(data.shops.any { it.id == shopId && !it.archived }) { "Sexni tanlang" }
        require(number > 0) { "Stanok raqami 0 dan katta bo‘lsin" }
        require(capacity > 0) { "Stanok sig‘imini kiriting" }
        require(data.machines.none { !it.archived && it.number == number }) { "Bu stanok raqami mavjud" }
        val machine = TpMachine(UUID.randomUUID().toString(), shopId, number, name.cleanText(), capacity = capacity)
        data.copy(machines = data.machines + machine).audit("TP_MACHINE_ADD", details = "$number / sig‘im $capacity")
    }

    @Synchronized
    fun updateMachine(id: String, shopId: String, number: Int, name: String, capacity: Int): Result<Unit> = mutate { data ->
        require(data.shops.any { it.id == shopId && !it.archived }) { "Sexni tanlang" }
        require(number > 0) { "Stanok raqami 0 dan katta bo‘lsin" }
        require(capacity > 0) { "Stanok sig‘imini kiriting" }
        require(data.machines.none { it.id != id && !it.archived && it.number == number }) { "Bu stanok raqami mavjud" }
        require(data.machines.any { it.id == id }) { "Stanok topilmadi" }
        data.copy(machines = data.machines.map { if (it.id == id) it.copy(shopId = shopId, number = number, name = name.cleanText(), capacity = capacity) else it })
            .audit("TP_MACHINE_UPDATE", details = "$number / sig‘im $capacity")
    }

    @Synchronized
    fun addWorker(brigadeId: String, name: String): Result<Unit> = mutate { data ->
        require(data.brigades.any { it.id == brigadeId && !it.archived }) { "Brigadani tanlang" }
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Ishchi ismini kiriting" }
        val worker = TpWorker(UUID.randomUUID().toString(), brigadeId, clean, 0L)
        data.copy(workers = data.workers + worker).audit("TP_WORKER_ADD", brigadeId, details = clean)
    }

    @Synchronized
    fun updateWorker(id: String, brigadeId: String, name: String): Result<Unit> = mutate { data ->
        require(data.brigades.any { it.id == brigadeId && !it.archived }) { "Brigadani tanlang" }
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Ishchi ismini kiriting" }
        require(data.workers.any { it.id == id }) { "Ishchi topilmadi" }
        data.copy(workers = data.workers.map {
            if (it.id == id) it.copy(brigadeId = brigadeId, name = clean, dailyTargetAmount = 0L) else it
        }).audit("TP_WORKER_UPDATE", brigadeId, details = clean)
    }

    @Synchronized
    fun updateDailyTargetAmount(value: Long): Result<Unit> = mutate { data ->
        require(value > 0L) { "Kunlik norma 0 dan katta bo‘lsin" }
        data.copy(settings = data.settings.copy(dailyTargetAmount = value))
            .audit("TP_DAILY_TARGET_UPDATE", details = "$value so‘m")
    }

    @Synchronized
    fun addProduct(article: String, name: String): Result<Unit> = mutate { data ->
        val code = article.trim().uppercase(Locale.ROOT)
        val clean = name.cleanText()
        require(code.isNotBlank() && clean.isNotBlank()) { "Artikul va mahsulot nomini kiriting" }
        require(data.products.none { !it.archived && it.article.equals(code, true) }) { "Bu artikul mavjud" }
        data.copy(products = data.products + TpProduct(UUID.randomUUID().toString(), code, clean))
            .audit("TP_PRODUCT_ADD", details = "$code $clean")
    }

    @Synchronized
    fun updateProduct(id: String, article: String, name: String): Result<Unit> = mutate { data ->
        val code = article.trim().uppercase(Locale.ROOT)
        val clean = name.cleanText()
        require(code.isNotBlank() && clean.isNotBlank()) { "Artikul va mahsulot nomini kiriting" }
        require(data.products.none { it.id != id && !it.archived && it.article.equals(code, true) }) { "Bu artikul mavjud" }
        require(data.products.any { it.id == id }) { "Mahsulot topilmadi" }
        data.copy(products = data.products.map { if (it.id == id) it.copy(article = code, name = clean) else it })
            .audit("TP_PRODUCT_UPDATE", details = "$code $clean")
    }

    @Synchronized
    fun saveDetail(productId: String, detail: TpDetail): Result<Unit> = mutate { data ->
        validateDetail(data, detail)
        val product = data.products.firstOrNull { it.id == productId } ?: error("Mahsulot topilmadi")
        val resins = detail.resinOptions()
        val clean = detail.copy(
            name = detail.name.cleanText(),
            moldCode = detail.moldCode.trim().ifBlank { detail.name.cleanText() }.uppercase(Locale.ROOT),
            resinCode = resins.first(),
            resinCodes = resins,
            compatibleMachineIds = emptySet(),
            colors = detail.colors.map { it.copy(colorCode = it.colorCode.trim().uppercase(Locale.ROOT)) }
        )
        val details = if (product.details.any { it.id == clean.id }) {
            product.details.map { if (it.id == clean.id) clean else it }
        } else product.details + clean
        data.copy(products = data.products.map { if (it.id == productId) it.copy(details = details) else it })
            .audit("TP_DETAIL_SAVE", details = "${product.article} / ${clean.name}")
    }

    fun validateImportPayload(payload: TpExcelImportPayload): List<String> {
        val data = load()
        val errors = mutableListOf<String>()
        val shopNames = data.shops.filterNot { it.archived }.associateBy { it.name.trim().lowercase(Locale.ROOT) }
        val shiftNames = data.shifts.filterNot { it.archived }.associateBy { it.name.trim().lowercase(Locale.ROOT) }
        payload.brigades.forEachIndexed { index, row ->
            if (shopNames[row.shopName.trim().lowercase(Locale.ROOT)] == null) errors += "Brigadalar ${index + 2}-qator: '${row.shopName}' sex topilmadi"
            if (shiftNames[row.shiftName.trim().lowercase(Locale.ROOT)] == null) errors += "Brigadalar ${index + 2}-qator: '${row.shiftName}' smena topilmadi"
        }
        payload.machines.forEachIndexed { index, row ->
            if (shopNames[row.shopName.trim().lowercase(Locale.ROOT)] == null) errors += "Stanoklar ${index + 2}-qator: '${row.shopName}' sex topilmadi"
        }
        val brigadeNames = (data.brigades.filterNot { it.archived }.map { it.name } + payload.brigades.map { it.name })
            .map { it.trim().lowercase(Locale.ROOT) }.toSet()
        payload.workers.forEachIndexed { index, row ->
            if (row.brigadeName.trim().lowercase(Locale.ROOT) !in brigadeNames) errors += "Ishchilar ${index + 2}-qator: '${row.brigadeName}' brigada topilmadi"
        }
        return errors.distinct()
    }

    @Synchronized
    fun importProductWorkbook(payload: TpExcelImportPayload): Result<Unit> = mutate { data ->
        require(payload.details.isNotEmpty()) { "Import uchun mahsulot/detal topilmadi" }
        val validationErrors = validateImportPayload(payload)
        require(validationErrors.isEmpty()) { validationErrors.joinToString("\n") }

        val colorsByDetail = payload.colors.groupBy {
            it.article.trim().uppercase(Locale.ROOT) + "|" + it.detailName.trim().lowercase(Locale.ROOT)
        }
        var products = data.products
        payload.details.groupBy { it.article.trim().uppercase(Locale.ROOT) }.forEach { (article, rows) ->
            val productName = rows.first().productName.cleanText()
            val existingProduct = products.firstOrNull { it.article.equals(article, true) }
            val productId = existingProduct?.id ?: UUID.randomUUID().toString()
            var details = existingProduct?.details.orEmpty()

            rows.forEach { row ->
                val existingDetail = details.firstOrNull { it.name.equals(row.detailName, true) }
                val colors = colorsByDetail[article + "|" + row.detailName.trim().lowercase(Locale.ROOT)].orEmpty().map {
                    TpColorRule(it.colorCode.trim().uppercase(Locale.ROOT), it.share, it.gramsPer25Kg)
                }
                val detailId = existingDetail?.id ?: UUID.randomUUID().toString()
                val detail = TpDetail(
                    id = detailId,
                    name = row.detailName.cleanText(),
                    moldCode = existingDetail?.moldCode?.takeIf { it.isNotBlank() }
                        ?: row.detailName.cleanText().uppercase(Locale.ROOT),
                    requiredPerProduct = row.requiredPerProduct,
                    piecesPerShot = row.piecesPerShot,
                    bagCapacity = row.bagCapacity,
                    cycleSeconds = row.cycleSeconds,
                    grossShotWeightGrams = row.grossShotWeightGrams,
                    unusableShotWeightGrams = row.unusableShotWeightGrams,
                    resinCode = row.resinCodes.first(),
                    unitPrice = row.unitPrice,
                    compatibleMachineIds = emptySet(),
                    compatibleCapacities = row.compatibleCapacities,
                    colors = colors,
                    archived = false,
                    resinCodes = row.resinCodes
                )
                validateDetail(data, detail)
                details = if (existingDetail == null) details + detail
                else details.map { if (it.id == existingDetail.id) detail else it }
            }

            val product = TpProduct(productId, article, productName, details, archived = false)
            products = if (existingProduct == null) products + product
            else products.map { if (it.id == existingProduct.id) product else it }
        }

        var brigades = data.brigades
        val shopsByName = data.shops.filterNot { it.archived }.associateBy { it.name.trim().lowercase(Locale.ROOT) }
        val shiftsByName = data.shifts.filterNot { it.archived }.associateBy { it.name.trim().lowercase(Locale.ROOT) }
        payload.brigades.forEach { row ->
            val shop = shopsByName.getValue(row.shopName.trim().lowercase(Locale.ROOT))
            val shift = shiftsByName.getValue(row.shiftName.trim().lowercase(Locale.ROOT))
            val existing = brigades.firstOrNull { it.name.equals(row.name, true) }
            val item = existing?.copy(shopId = shop.id, shiftId = shift.id, name = row.name.cleanText(), archived = false)
                ?: TpBrigade(UUID.randomUUID().toString(), shop.id, shift.id, row.name.cleanText())
            brigades = if (existing == null) brigades + item else brigades.map { if (it.id == existing.id) item else it }
        }

        var machines = data.machines
        payload.machines.forEach { row ->
            val shop = shopsByName.getValue(row.shopName.trim().lowercase(Locale.ROOT))
            val existing = machines.firstOrNull { it.number == row.number }
            val item = existing?.copy(shopId = shop.id, number = row.number, name = row.name.cleanText(), capacity = row.capacity, archived = false)
                ?: TpMachine(UUID.randomUUID().toString(), shop.id, row.number, row.name.cleanText(), capacity = row.capacity)
            machines = if (existing == null) machines + item else machines.map { if (it.id == existing.id) item else it }
        }

        var workers = data.workers
        val brigadesByName = brigades.filterNot { it.archived }.associateBy { it.name.trim().lowercase(Locale.ROOT) }
        payload.workers.forEach { row ->
            val brigade = brigadesByName.getValue(row.brigadeName.trim().lowercase(Locale.ROOT))
            val existing = workers.firstOrNull { it.brigadeId == brigade.id && it.name.equals(row.name, true) }
            val item = existing?.copy(name = row.name.cleanText(), dailyTargetAmount = 0L, archived = false)
                ?: TpWorker(UUID.randomUUID().toString(), brigade.id, row.name.cleanText(), 0L)
            workers = if (existing == null) workers + item else workers.map { if (it.id == existing.id) item else it }
        }

        data.copy(products = products, brigades = brigades, machines = machines, workers = workers).audit(
            "TP_EXCEL_IMPORT",
            details = "${payload.productCount} mahsulot / ${payload.detailCount} detal / ${payload.colorCount} rang / ${payload.brigadeCount} brigada / ${payload.machineCount} stanok / ${payload.workerCount} ishchi"
        )
    }

    @Synchronized
    fun deleteProduct(id: String): Result<Unit> = mutate { data ->
        val product = data.products.firstOrNull { it.id == id && !it.archived } ?: error("Mahsulot topilmadi")
        val hasActiveOrder = data.orders.any { it.productId == id && it.status != TpOrderStatus.COMPLETE && it.status != TpOrderStatus.CANCELLED }
        require(!hasActiveOrder) { "Bu mahsulot bo‘yicha faol zakaz bor. Avval zakazni yakunlang yoki bekor qiling." }
        data.copy(products = data.products.map { if (it.id == id) it.copy(archived = true) else it })
            .audit("TP_PRODUCT_DELETE", details = "${product.article} ${product.name}")
    }

    @Synchronized
    fun deleteMachine(id: String): Result<Unit> = mutate { data ->
        val machine = data.machines.firstOrNull { it.id == id && !it.archived } ?: error("Stanok topilmadi")
        val activeJob = data.jobs.any { it.machineId == id && it.status != TpJobStatus.COMPLETE }
        require(!activeJob) { "Bu stanokda faol vazifa bor. Avval vazifani yakunlang yoki boshqa stanokka o‘tkazing." }
        data.copy(machines = data.machines.map { if (it.id == id) it.copy(archived = true) else it })
            .audit("TP_MACHINE_DELETE", details = "${machine.number}-stanok")
    }

    @Synchronized
    fun archiveDetail(productId: String, detailId: String, archived: Boolean): Result<Unit> = mutate { data ->
        val product = data.products.firstOrNull { it.id == productId } ?: error("Mahsulot topilmadi")
        require(product.details.any { it.id == detailId }) { "Detal topilmadi" }
        data.copy(products = data.products.map { item ->
            if (item.id == productId) item.copy(details = item.details.map { if (it.id == detailId) it.copy(archived = archived) else it }) else item
        }).audit("TP_DETAIL_ARCHIVE", details = "$detailId=$archived")
    }

    @Synchronized
    fun setMaterial(code: String, name: String, type: TpMaterialType, availableAmount: Double): Result<Unit> = mutate { data ->
        val normalized = code.trim().uppercase(Locale.ROOT)
        require(normalized.isNotBlank() && name.cleanText().isNotBlank()) { "Kod va nomni kiriting" }
        require(availableAmount >= 0.0 && availableAmount.isFinite()) { "Qoldiq noto‘g‘ri" }
        val current = data.materials.firstOrNull { it.code.equals(normalized, true) && it.type == type }
        val item = current?.copy(name = name.cleanText(), availableAmount = availableAmount)
            ?: TpMaterial(UUID.randomUUID().toString(), normalized, name.cleanText(), type, availableAmount)
        val materials = if (current == null) data.materials + item else data.materials.map { if (it.id == current.id) item else it }
        data.copy(materials = materials).audit("TP_MATERIAL_SAVE", details = "$normalized ${formatTpNumber(availableAmount)}")
    }

    @Synchronized
    fun addMaterialMovement(
        code: String,
        type: TpMaterialType,
        amount: Double,
        incoming: Boolean,
        note: String = ""
    ): Result<Unit> = mutate { data ->
        val normalized = code.trim().uppercase(Locale.ROOT)
        require(normalized.isNotBlank()) { "Seryo/krasitel kodini kiriting" }
        require(amount > 0.0 && amount.isFinite()) { "Miqdorni to‘g‘ri kiriting" }
        val existing = data.materials.firstOrNull { !it.archived && it.code.equals(normalized, true) && it.type == type }
        if (!incoming) {
            require(existing != null) { "Bu kod bo‘yicha qoldiq topilmadi" }
            require(existing.currentStock() + 1e-9 >= amount) {
                "Ostatka yetarli emas: ${formatTpNumber(existing.currentStock())}"
            }
        }
        val movement = TpMaterialMovement(
            id = UUID.randomUUID().toString(),
            kind = if (incoming) TpMaterialMovementKind.IN else TpMaterialMovementKind.OUT,
            amount = amount,
            createdAt = LocalDateTime.now().toString(),
            note = note.cleanText()
        )
        val material = existing?.copy(movements = existing.movements + movement)
            ?: TpMaterial(
                id = UUID.randomUUID().toString(), code = normalized, name = normalized, type = type,
                availableAmount = 0.0, movements = listOf(movement)
            )
        val materials = if (existing == null) data.materials + material
        else data.materials.map { if (it.id == existing.id) material else it }
        data.copy(materials = materials).audit(
            if (incoming) "TP_MATERIAL_IN" else "TP_MATERIAL_OUT",
            recordDate = movement.createdAt.take(10),
            details = "$normalized ${formatTpNumber(amount)} ${if (type == TpMaterialType.RESIN) "kg" else "g"}${movement.note.takeIf { it.isNotBlank() }?.let { ": $it" }.orEmpty()}"
        )
    }

    @Synchronized
    fun increaseAllDetailPrices(percent: Double): Result<Unit> = mutate { data ->
        require(percent.isFinite() && percent > -100.0 && percent <= 1000.0) { "Foizni to‘g‘ri kiriting" }
        val factor = 1.0 + percent / 100.0
        val products = data.products.map { product ->
            product.copy(details = product.details.map { detail ->
                detail.copy(unitPrice = (round(detail.unitPrice * factor * 100.0) / 100.0).coerceAtLeast(0.0))
            })
        }
        data.copy(products = products, settings = data.settings.copy(priceRevision = data.settings.priceRevision + 1))
            .audit("TP_PRICE_BULK", details = "$percent%")
    }

    @Synchronized
    fun createOrder(
        firstBatchNumber: String,
        productId: String,
        quantity: Int,
        priority: Int,
        note: String
    ): Result<Unit> = mutate { data ->
        val product = data.products.firstOrNull { it.id == productId && !it.archived } ?: error("Mahsulotni tanlang")
        require(quantity > 0) { "Zakaz soni 0 dan katta bo‘lsin" }
        require(priority in 1..3) { "Ustuvorlikni tanlang" }
        val batch = if (data.orders.isEmpty()) {
            firstBatchNumber.trim().also { require(it.isNotBlank()) { "Birinchi partiya raqamini kiriting" } }
        } else {
            nextBatchNumber(data.orders.maxByOrNull { it.createdAt }!!.batchNumber)
        }
        require(data.orders.none { it.batchNumber.equals(batch, true) }) { "Bu partiya raqami mavjud" }
        val now = LocalDateTime.now().toString()
        val orderDate = now.take(10)
        val order = TpOrder(
            id = UUID.randomUUID().toString(), batchNumber = batch, productId = product.id,
            articleSnapshot = product.article, productNameSnapshot = product.name, quantity = quantity,
            priority = priority, requestedDate = orderDate, note = note.cleanText(),
            status = TpOrderStatus.NEW, createdAt = now
        )
        data.copy(orders = data.orders + order, settings = data.settings.copy(firstBatchEntered = true))
            .audit("TP_ORDER_ADD", recordDate = orderDate, details = "$batch ${product.article} × $quantity / ${tpPriorityLabel(priority)}")
    }

    @Synchronized
    fun updateOrder(orderId: String, productId: String, quantity: Int, priority: Int, note: String): Result<Unit> = mutate { data ->
        val old = data.orders.firstOrNull { it.id == orderId } ?: error("Zakaz topilmadi")
        val product = data.products.firstOrNull { it.id == productId && !it.archived } ?: error("Mahsulotni tanlang")
        require(quantity > 0) { "Zakaz soni 0 dan katta bo‘lsin" }
        require(priority in 1..3) { "Ustuvorlikni tanlang" }
        val orderJobs = data.jobs.filter { it.orderId == orderId }
        val hasStartedWork = data.receipts.any { it.orderId == orderId } || orderJobs.any {
            it.status == TpJobStatus.IN_PROGRESS || it.status == TpJobStatus.COMPLETE || it.materialStatus != TpMaterialStatus.PLANNED
        }
        val structureChanged = old.productId != productId || old.quantity != quantity
        require(!structureChanged || (old.planApprovedAt == null && !hasStartedWork)) {
            "Jarayonga topshirilgan yoki quyish boshlangan zakazda mahsulot/miqdorni o‘zgartirib bo‘lmaydi. Ustuvorlik va izohni o‘zgartiring."
        }
        val updated = old.copy(
            productId = product.id,
            articleSnapshot = product.article,
            productNameSnapshot = product.name,
            quantity = quantity,
            priority = priority,
            note = note.cleanText()
        )
        var result = data.copy(orders = data.orders.map { if (it.id == orderId) updated else it })
        if (structureChanged && orderJobs.isNotEmpty()) {
            val oldByKey = orderJobs.associateBy { it.moldCode.uppercase(Locale.ROOT) to it.colorCode.uppercase(Locale.ROOT) }
            val rebuilt = buildPlanJobs(result, updated) { UUID.randomUUID().toString() }.map { fresh ->
                val previous = oldByKey[fresh.moldCode.uppercase(Locale.ROOT) to fresh.colorCode.uppercase(Locale.ROOT)]
                val machine = previous?.machineId?.let { id -> result.machines.firstOrNull { it.id == id } }
                val keepAssignment = machine != null && fresh.acceptsMachine(machine, result)
                fresh.copy(
                    id = previous?.id ?: fresh.id,
                    machineId = previous?.machineId?.takeIf { keepAssignment },
                    brigadeId = previous?.brigadeId?.takeIf { keepAssignment },
                    shiftId = previous?.shiftId?.takeIf { keepAssignment },
                    status = if (keepAssignment) TpJobStatus.QUEUED else TpJobStatus.UNASSIGNED
                )
            }
            result = result.copy(jobs = data.jobs.filterNot { it.orderId == orderId } + rebuilt)
        } else if (orderJobs.isNotEmpty() && old.priority != priority) {
            val slots = orderJobs.sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id })
            val base = priority * 100
            val reprioritized = slots.mapIndexed { index, job -> job.id to (base + index + 1) }.toMap()
            result = result.copy(jobs = result.jobs.map { job -> reprioritized[job.id]?.let { job.copy(priority = it) } ?: job })
        }
        result.refreshOrderStatus(orderId)
            .audit("TP_ORDER_UPDATE", recordDate = old.createdAt.take(10), details = "${old.batchNumber}: ${product.article} × $quantity / ${tpPriorityLabel(priority)}")
    }

    @Synchronized
    fun deleteOrder(orderId: String): Result<Unit> = mutate { data ->
        val order = data.orders.firstOrNull { it.id == orderId } ?: error("Zakaz topilmadi")
        val orderJobs = data.jobs.filter { it.orderId == orderId }
        require(order.status != TpOrderStatus.COMPLETE) { "Yakunlangan zakazni o‘chirib bo‘lmaydi" }
        require(data.receipts.none { it.orderId == orderId }) { "Qabul yozuvi bor zakazni o‘chirib bo‘lmaydi" }
        data.copy(
            orders = data.orders.filterNot { it.id == orderId },
            jobs = data.jobs.filterNot { it.orderId == orderId }
        ).audit("TP_ORDER_DELETE", recordDate = order.createdAt.take(10), details = "${order.batchNumber} ${order.articleSnapshot}")
    }

    @Synchronized
    fun generateOrderPlan(orderId: String): Result<Unit> = mutate { data ->
        val order = data.orders.firstOrNull { it.id == orderId } ?: error("Zakaz topilmadi")
        require(order.planApprovedAt == null) { "Bu zakaz jarayonga topshirilgan" }
        require(data.jobs.none { it.orderId == orderId }) { "Bu zakaz uchun plan yaratilgan" }
        val jobs = buildPlanJobs(data, order) { UUID.randomUUID().toString() }
        require(jobs.isNotEmpty()) { "Plan vazifalari hosil bo‘lmadi" }
        data.copy(
            jobs = data.jobs + jobs,
            orders = data.orders.map { if (it.id == orderId) it.copy(status = TpOrderStatus.PLANNING) else it }
        ).audit("TP_PLAN_GENERATE", recordDate = order.requestedDate, details = "${order.batchNumber}: ${jobs.size} vazifa")
    }

    @Synchronized
    fun assignJob(jobId: String, machineId: String, brigadeId: String, priority: Int): Result<Unit> = mutate { data ->
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        val order = data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        require(order.planApprovedAt == null) { "Tasdiqlangan planda stanokni o‘zgartirib bo‘lmaydi" }
        val machine = data.machines.firstOrNull { it.id == machineId && !it.archived } ?: error("Stanok topilmadi")
        val brigade = data.brigades.firstOrNull { it.id == brigadeId && !it.archived } ?: error("Brigada topilmadi")
        require(machine.shopId == brigade.shopId) { "Stanok va brigada bir sexda bo‘lsin" }
        require(job.acceptsMachine(machine, data)) { "Bu stanok ushbu qolip/sig‘imga mos emas" }
        require(priority in 1..9999) { "Ustuvorlik noto‘g‘ri" }
        val updatedJobs = data.jobs.map {
            if (it.id == jobId) it.copy(
                machineId = machineId, brigadeId = brigadeId, shiftId = brigade.shiftId,
                priority = priority, status = TpJobStatus.QUEUED
            ) else it
        }
        val orderReady = updatedJobs.filter { it.orderId == job.orderId }.all { it.machineId != null }
        data.copy(
            jobs = updatedJobs,
            orders = data.orders.map { if (it.id == job.orderId && orderReady) it.copy(status = TpOrderStatus.READY) else it }
        ).audit("TP_JOB_ASSIGN", brigadeId, details = "Stanok ${machine.number} / ${job.moldCode}")
    }

    @Synchronized
    fun assignMoldJobs(
        orderId: String,
        moldCode: String,
        machineId: String,
        editReason: String = ""
    ): Result<Unit> = mutate { data ->
        val order = data.orders.firstOrNull { it.id == orderId } ?: error("Zakaz topilmadi")
        val machine = data.machines.firstOrNull { it.id == machineId && !it.archived } ?: error("Stanok topilmadi")
        val target = data.jobs.filter { it.orderId == orderId && it.moldCode == moldCode }
        val targetIds = target.map { it.id }.toSet()
        val waitMinutes = data.jobs.filter { it.machineId == machineId && it.status != TpJobStatus.COMPLETE && it.id !in targetIds }
            .sumOf { it.estimatedMinutes.coerceAtLeast(0) }
        val brigade = data.autoBrigadeForMachine(machineId, waitMinutes)
            ?: error("Bu stanok sexi uchun smenaga mos brigada topilmadi")
        require(target.isNotEmpty()) { "Detal/qolip vazifalari topilmadi" }
        require(target.all { it.acceptsMachine(machine, data) }) { "Bu stanok ushbu detal sig‘imiga mos emas" }
        val editingConfirmedPlan = target.any { it.planConfirmedAt != null } || order.planApprovedAt != null
        if (editingConfirmedPlan) {
            val reason = editReason.cleanText()
            require(reason.isNotBlank()) { "Tasdiqlangan planni tahrirlash uchun sharh majburiy" }
            require(target.none { it.status == TpJobStatus.IN_PROGRESS || it.status == TpJobStatus.COMPLETE }) { "Boshlangan yoki tugagan detal rejasini tahrirlab bo‘lmaydi" }
            require(data.receipts.none { receipt -> receipt.orderId == orderId && target.any { job -> receipt.jobId == job.id } }) { "Qabul yozuvi bor detal rejasini tahrirlab bo‘lmaydi" }
        }
        val ids = targetIds
        val now = LocalDateTime.now().toString()
        val reason = editReason.cleanText()
        val updatedJobs = data.jobs.map { job ->
            if (job.id in ids) job.copy(
                machineId = machineId,
                brigadeId = brigade.id,
                shiftId = brigade.shiftId,
                status = TpJobStatus.QUEUED,
                planConfirmedAt = if (editingConfirmedPlan) null else job.planConfirmedAt,
                planEditedAt = if (editingConfirmedPlan) now else job.planEditedAt,
                planEditReason = if (editingConfirmedPlan) reason else job.planEditReason,
                resinSelectedAt = if (editingConfirmedPlan) null else job.resinSelectedAt,
                resinConfirmedAt = if (editingConfirmedPlan) null else job.resinConfirmedAt,
                materialShortageOverride = if (editingConfirmedPlan) false else job.materialShortageOverride,
                materialStatus = if (editingConfirmedPlan) TpMaterialStatus.PLANNED else job.materialStatus,
                materialConfirmedAt = if (editingConfirmedPlan) null else job.materialConfirmedAt,
                materialDeliveredAt = if (editingConfirmedPlan) null else job.materialDeliveredAt,
                startedAt = if (editingConfirmedPlan) null else job.startedAt
            ) else job
        }
        val orderReady = updatedJobs.filter { it.orderId == orderId }.all { it.machineId != null }
        val updatedOrder = if (editingConfirmedPlan) {
            order.copy(status = TpOrderStatus.PLANNING, planApprovedAt = null)
        } else if (orderReady) order.copy(status = TpOrderStatus.READY) else order.copy(status = TpOrderStatus.PLANNING)
        data.copy(
            jobs = updatedJobs,
            orders = data.orders.map { if (it.id == orderId) updatedOrder else it }
        ).audit(
            if (editingConfirmedPlan) "TP_PLAN_EDIT" else "TP_MOLD_ASSIGN", brigade.id, order.requestedDate,
            "$moldCode → stanok ${machine.number}${if (editingConfirmedPlan) "; sabab: $reason" else ""}"
        )
    }

    @Synchronized
    fun confirmPlannedMold(orderId: String, moldCode: String): Result<Unit> = mutate { data ->
        val order = data.orders.firstOrNull { it.id == orderId } ?: error("Zakaz topilmadi")
        val target = data.jobs.filter { it.orderId == orderId && it.moldCode == moldCode }
        require(target.isNotEmpty()) { "Detal/qolip vazifalari topilmadi" }
        require(target.all { it.machineId != null && it.brigadeId != null && it.shiftId != null }) { "Avval ushbu detal uchun stanokni rejalang" }
        require(target.none { it.planConfirmedAt != null }) { "Bu detal rejasi allaqachon tasdiqlangan" }
        val now = LocalDateTime.now().toString()
        val targetIds = target.map { it.id }.toSet()
        val jobs = data.jobs.map { if (it.id in targetIds) it.copy(planConfirmedAt = now) else it }
        val allConfirmed = jobs.filter { it.orderId == orderId }.isNotEmpty() && jobs.filter { it.orderId == orderId }.all { it.planConfirmedAt != null }
        val updatedOrder = order.copy(
            status = if (allConfirmed) TpOrderStatus.APPROVED else TpOrderStatus.PLANNING,
            planApprovedAt = if (allConfirmed) now else null
        )
        data.copy(jobs = jobs, orders = data.orders.map { if (it.id == orderId) updatedOrder else it })
            .audit("TP_PLAN_DETAIL_APPROVE", target.firstOrNull()?.brigadeId, order.requestedDate, "$moldCode tasdiqlandi${if (allConfirmed) "; zakaz to‘liq tasdiqlandi" else ""}")
    }

    @Synchronized
    fun setColorPosition(jobId: String, position: Int): Result<Unit> = mutate { data ->
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Rang vazifasi topilmadi")
        data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        require(data.jobs.filter { it.orderId == job.orderId && it.moldCode == job.moldCode }.none { it.planConfirmedAt != null }) { "Tasdiqlangan detal rejasida rang navbatini o‘zgartirish uchun avval rejani tahrirlang" }
        val siblings = data.jobs.filter { it.orderId == job.orderId && it.moldCode == job.moldCode }
            .sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id })
        require(position in 1..siblings.size) { "Tartib raqami noto‘g‘ri" }
        val reordered = siblings.toMutableList().apply {
            val currentIndex = indexOfFirst { it.id == jobId }
            val moving = removeAt(currentIndex)
            add(position - 1, moving)
        }
        val slots = siblings.map { it.priority }.sorted()
        val newPriority = reordered.mapIndexed { index, item -> item.id to slots[index] }.toMap()
        data.copy(jobs = data.jobs.map { item -> newPriority[item.id]?.let { item.copy(priority = it) } ?: item })
            .audit("TP_COLOR_ORDER", job.brigadeId, details = "${job.moldCode}/${job.colorCode} → $position")
    }

    @Synchronized
    fun setJobResin(jobId: String, resinCode: String): Result<Unit> = mutate { data ->
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Rang vazifasi topilmadi")
        data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        require(job.planConfirmedAt != null) { "Plan beruvchi avval shu detal rejasini tasdiqlasin" }
        require(job.resinConfirmedAt == null) { "Seryo buyurtmasi allaqachon tasdiqlangan" }
        val detailOptions = job.outputs.mapNotNull { output ->
            data.products.asSequence().flatMap { it.details.asSequence() }.firstOrNull { it.id == output.detailId }?.resinOptions()?.toSet()
        }
        require(detailOptions.isNotEmpty()) { "Detal seryo ma’lumoti topilmadi" }
        val allowed = detailOptions.drop(1).fold(detailOptions.first()) { acc, set -> acc intersect set }
        val selected = resinCode.trim().uppercase(Locale.ROOT)
        require(selected in allowed) { "Bu seryo ushbu detal/qolip uchun ruxsat etilmagan" }
        val now = LocalDateTime.now().toString()
        data.copy(jobs = data.jobs.map { if (it.id == jobId) it.copy(resinCode = selected, resinSelectedAt = now) else it })
            .audit("TP_JOB_RESIN", job.brigadeId, details = "${job.moldCode}/${job.colorCode}: $selected")
    }

    @Synchronized
    fun confirmJobResin(jobId: String, acceptShortage: Boolean): Result<Unit> = mutate { data ->
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        val order = data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        require(job.planConfirmedAt != null) { "Plan beruvchi avval shu detal rejasini tasdiqlasin" }
        require(job.resinSelectedAt != null && job.resinCode.isNotBlank()) { "Avval seryo turini tanlang" }
        require(job.resinConfirmedAt == null) { "Bu detal/rang seryosi allaqachon tasdiqlangan" }
        val resinStock = data.materialStock(TpMaterialType.RESIN, job.resinCode)
        val colorStock = data.materialStock(TpMaterialType.COLOR, job.colorCode)
        val shortages = buildList {
            if (resinStock + 1e-9 < job.requiredResinKg) add("${job.resinCode} seryo: kerak ${formatTpNumber(job.requiredResinKg)} kg / bor ${formatTpNumber(resinStock)} kg")
            if (colorStock + 1e-9 < job.requiredColorGrams) add("${job.colorCode} krasitel: kerak ${formatTpNumber(job.requiredColorGrams)} g / bor ${formatTpNumber(colorStock)} g")
        }
        require(shortages.isEmpty() || acceptShortage) { "OSTATKA_YETMAYDI\n" + shortages.joinToString("\n") }
        val now = LocalDateTime.now().toString()
        data.copy(jobs = data.jobs.map { row ->
            if (row.id == jobId) row.copy(
                resinConfirmedAt = now,
                materialShortageOverride = shortages.isNotEmpty() && acceptShortage
            ) else row
        }).audit(
            "TP_RESIN_JOB_APPROVE", job.brigadeId, order.requestedDate,
            "${order.batchNumber}: ${job.outputs.joinToString { it.detailName }}/${job.colorCode} ${job.resinCode} tasdiqlandi${if (shortages.isNotEmpty()) " / qoldiq ogohlantirishi qabul qilindi" else ""}"
        )
    }

    @Synchronized
    fun confirmOrderResins(orderId: String, acceptShortage: Boolean): Result<Unit> = mutate { data ->
        val order = data.orders.firstOrNull { it.id == orderId } ?: error("Zakaz topilmadi")
        val orderJobs = data.jobs.filter { it.orderId == orderId }
        require(orderJobs.isNotEmpty() && orderJobs.all { it.planConfirmedAt != null }) { "Plan beruvchi avval barcha detal rejalarini tasdiqlasin" }
        require(orderJobs.isNotEmpty()) { "Seryo uchun vazifalar topilmadi" }
        require(orderJobs.all { it.resinCode.isNotBlank() && it.resinSelectedAt != null }) { "Har bir detal/rang uchun seryo turini tanlang" }
        val resinNeed = orderJobs.groupBy { it.resinCode.uppercase(Locale.ROOT) }.mapValues { (_, rows) -> rows.sumOf { it.requiredResinKg } }
        val colorNeed = orderJobs.groupBy { it.colorCode.uppercase(Locale.ROOT) }.mapValues { (_, rows) -> rows.sumOf { it.requiredColorGrams } }
        val shortages = buildList {
            resinNeed.forEach { (code, need) ->
                val stock = data.materialStock(TpMaterialType.RESIN, code)
                if (stock + 1e-9 < need) add("$code seryo: kerak ${formatTpNumber(need)} kg / bor ${formatTpNumber(stock)} kg")
            }
            colorNeed.forEach { (code, need) ->
                val stock = data.materialStock(TpMaterialType.COLOR, code)
                if (stock + 1e-9 < need) add("$code krasitel: kerak ${formatTpNumber(need)} g / bor ${formatTpNumber(stock)} g")
            }
        }
        require(shortages.isEmpty() || acceptShortage) { "OSTATKA_YETMAYDI\n" + shortages.joinToString("\n") }
        val now = LocalDateTime.now().toString()
        data.copy(jobs = data.jobs.map { job ->
            if (job.orderId == orderId) job.copy(
                resinConfirmedAt = now,
                materialShortageOverride = shortages.isNotEmpty() && acceptShortage
            ) else job
        }).audit("TP_RESIN_APPROVE", recordDate = order.requestedDate, details = "${order.batchNumber}: seryo tasdiqlandi${if (shortages.isNotEmpty()) " / qoldiq ogohlantirishi qabul qilindi" else ""}")
    }

    @Synchronized
    fun approveOrderPlan(orderId: String): Result<Unit> = mutate { data ->
        val order = data.orders.firstOrNull { it.id == orderId } ?: error("Zakaz topilmadi")
        require(order.planApprovedAt == null) { "Plan allaqachon jarayonga topshirilgan" }
        val orderJobs = data.jobs.filter { it.orderId == orderId }
        require(orderJobs.isNotEmpty()) { "Avval plan hisobini yarating" }
        require(orderJobs.all { it.machineId != null && it.brigadeId != null && it.shiftId != null }) {
            "Jarayonni boshlashdan oldin barcha detal/ranglarga stanok va brigada tanlang"
        }
        val now = LocalDateTime.now().toString()
        data.copy(
            jobs = data.jobs.map { if (it.orderId == orderId) it.copy(planConfirmedAt = it.planConfirmedAt ?: now) else it },
            orders = data.orders.map { if (it.id == orderId) it.copy(status = TpOrderStatus.APPROVED, planApprovedAt = now) else it }
        ).audit("TP_PLAN_APPROVE", recordDate = order.requestedDate, details = "${order.batchNumber}: ${orderJobs.size} vazifa jarayonga topshirildi")
    }

    @Synchronized
    fun setJobPriority(jobId: String, priority: Int): Result<Unit> = mutate { data ->
        require(priority in 1..9999) { "Ustuvorlik noto‘g‘ri" }
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        data.copy(jobs = data.jobs.map { if (it.id == jobId) it.copy(priority = priority) else it })
            .audit("TP_JOB_PRIORITY", job.brigadeId, details = "${job.moldCode}: $priority")
    }

    @Synchronized
    fun setJobStatus(jobId: String, status: TpJobStatus): Result<Unit> = mutate { data ->
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        val order = data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        if (status == TpJobStatus.IN_PROGRESS || status == TpJobStatus.COMPLETE) {
            require(job.planConfirmedAt != null) { "Plan beruvchi avval shu detal rejasini tasdiqlasin" }
        }
        if (status == TpJobStatus.IN_PROGRESS) {
            require(job.materialStatus == TpMaterialStatus.DELIVERED) { "Seryo stanokka yetkazilmaguncha ishni boshlab bo‘lmaydi" }
        }
        require(job.machineId != null || status == TpJobStatus.HOLD || status == TpJobStatus.UNASSIGNED) { "Avval stanok belgilang" }
        if (status == TpJobStatus.COMPLETE) {
            val unfinished = job.outputs.filter { output ->
                data.receipts.filter { it.jobId == jobId && it.detailId == output.detailId }
                    .sumOf { it.creditedPieces } < output.requiredPieces
            }
            require(unfinished.isEmpty()) {
                "Vazifa faqat qabul qilingan barcha detallar reja soniga yetganda yakunlanadi"
            }
        }
        val now = LocalDateTime.now().toString()
        var updated = data.copy(jobs = data.jobs.map {
            if (it.id == jobId) it.copy(status = status, startedAt = if (status == TpJobStatus.IN_PROGRESS) (it.startedAt ?: now) else it.startedAt) else it
        })
        updated = updated.refreshOrderStatus(job.orderId)
        updated.audit("TP_JOB_STATUS", job.brigadeId, details = "${job.moldCode}: ${status.name}")
    }

    @Synchronized
    fun confirmMaterial(jobId: String, delivered: Boolean): Result<Unit> = mutate { data ->
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        val order = data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        require(job.planConfirmedAt != null) { "Plan beruvchi avval shu detal rejasini tasdiqlasin" }
        require(job.resinConfirmedAt != null) { "Seryo brigadiri avval seryo turini tanlab tasdiqlasin" }
        require(job.machineId != null) { "Vazifa stanokka biriktirilmagan" }
        if (delivered && job.materialStatus == TpMaterialStatus.DELIVERED) return@mutate data

        val now = LocalDateTime.now().toString()
        val status = if (delivered) TpMaterialStatus.DELIVERED else TpMaterialStatus.CONFIRMED
        val updated = job.copy(
            materialStatus = status,
            materialConfirmedAt = job.materialConfirmedAt ?: now,
            materialDeliveredAt = if (delivered) now else job.materialDeliveredAt
        )
        var materials = data.materials
        if (delivered) {
            fun consume(code: String, type: TpMaterialType, amount: Double) {
                if (amount <= 0.0) return
                val existing = materials.firstOrNull { !it.archived && it.type == type && it.code.equals(code, true) }
                val material = if (existing != null) {
                    existing
                } else {
                    require(job.materialShortageOverride) { "$code bo‘yicha ostatka topilmadi" }
                    TpMaterial(
                        id = UUID.randomUUID().toString(),
                        code = code.uppercase(Locale.ROOT),
                        name = code.uppercase(Locale.ROOT),
                        type = type,
                        availableAmount = 0.0
                    ).also { created -> materials = materials + created }
                }
                if (!job.materialShortageOverride) {
                    require(material.currentStock() + 1e-9 >= amount) {
                        "$code ostatkasi yetarli emas: ${formatTpNumber(material.currentStock())}"
                    }
                }
                val movement = TpMaterialMovement(
                    id = UUID.randomUUID().toString(), kind = TpMaterialMovementKind.OUT, amount = amount,
                    createdAt = now, note = "${order.batchNumber} • ${job.moldCode} • stanokka chiqdi", sourceJobId = job.id
                )
                materials = materials.map { item ->
                    if (item.id == material.id) material.copy(movements = material.movements + movement) else item
                }
            }
            consume(job.resinCode, TpMaterialType.RESIN, job.requiredResinKg)
            consume(job.colorCode, TpMaterialType.COLOR, job.requiredColorGrams)
        }
        data.copy(
            jobs = data.jobs.map { if (it.id == jobId) updated else it },
            materials = materials
        ).audit(if (delivered) "TP_MATERIAL_DELIVER" else "TP_MATERIAL_CONFIRM", job.brigadeId, details = job.moldCode)
    }

    @Synchronized
    fun setAttendance(workerId: String, date: String, present: Boolean, minusHours: Double): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val worker = data.workers.firstOrNull { it.id == workerId && !it.archived } ?: error("Ishchi topilmadi")
        val brigade = data.brigades.firstOrNull { it.id == worker.brigadeId } ?: error("Brigada topilmadi")
        val shift = data.shifts.firstOrNull { it.id == brigade.shiftId } ?: error("Brigada smenasi topilmadi")
        require(minusHours.isFinite() && minusHours >= 0.0) { "Minus soatni to‘g‘ri kiriting" }
        val standardMinutes = shift.durationMinutes()
        val minusMinutes = kotlin.math.round(minusHours * 60.0).toInt()
        require(minusMinutes <= standardMinutes) { "Minus soat smena davomiyligidan katta bo‘lishi mumkin emas" }
        val workMinutes = if (present) (standardMinutes - minusMinutes).coerceAtLeast(0) else 0
        val normalizedMinus = if (present) minusHours else 0.0
        val id = "${workerId}_$date"
        val attendance = TpAttendance(id, worker.id, worker.brigadeId, brigade.shiftId, date, present, workMinutes, LocalDateTime.now().toString(), normalizedMinus)
        val values = data.attendance.filterNot { it.id == id } + attendance
        data.copy(attendance = values).audit("TP_ATTENDANCE", worker.brigadeId, date, "${worker.name}: $present / minus ${formatTpNumber(normalizedMinus)} soat / $workMinutes daqiqa")
    }

    @Synchronized
    fun saveOvertimeType(typeId: String?, name: String, hourlyRate: Long): Result<Unit> = mutate { data ->
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Qo‘shimcha soat turi nomini kiriting" }
        require(hourlyRate >= 0L) { "Soat narxi manfiy bo‘lmasin" }
        val id = typeId?.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
        val row = TpOvertimeType(id, clean, hourlyRate, archived = false)
        val updated = data.settings.overtimeTypes.filterNot { it.id == id } + row
        data.copy(settings = data.settings.copy(overtimeTypes = updated.sortedBy { it.name.lowercase(Locale.ROOT) }))
            .audit("TP_OVERTIME_TYPE_SAVE", details = "$clean / $hourlyRate so‘m/soat")
    }

    @Synchronized
    fun addWorkerOvertime(workerId: String, date: String, typeId: String, hours: Double): Result<Unit> = mutate { data ->
        val worker = data.workers.firstOrNull { it.id == workerId && !it.archived } ?: error("Ishchi topilmadi")
        LocalDate.parse(date)
        require(hours > 0.0 && hours <= 24.0 && hours.isFinite()) { "Qo‘shimcha soatni to‘g‘ri kiriting" }
        val type = data.settings.overtimeTypes.firstOrNull { it.id == typeId && !it.archived } ?: error("Qo‘shimcha soat turini tanlang")
        val entry = TpWorkerOvertime(
            id = UUID.randomUUID().toString(), typeId = type.id, typeNameSnapshot = type.name,
            date = date, hours = hours, hourlyRateSnapshot = type.hourlyRate, createdAt = LocalDateTime.now().toString()
        )
        data.copy(workers = data.workers.map { if (it.id == worker.id) it.copy(overtimeEntries = it.overtimeEntries + entry) else it })
            .audit("TP_WORKER_OVERTIME", worker.brigadeId, date, "${worker.name}: ${formatTpNumber(hours)} soat • ${type.name} • ${entry.earnedAmount} so‘m")
    }

    @Synchronized
    fun addMachineDowntime(machineId: String, brigadeId: String, stoppedAt: String, restartedAt: String, note: String): Result<Unit> = mutate { data ->
        val machine = data.machines.firstOrNull { it.id == machineId && !it.archived } ?: error("Stanok topilmadi")
        val cleanNote = note.cleanText()
        require(cleanNote.isNotBlank()) { "Stanok o‘chish sababini yozing" }
        val start = LocalDateTime.parse(stoppedAt)
        val end = LocalDateTime.parse(restartedAt)
        require(end.isAfter(start)) { "Yongan vaqt o‘chgan vaqtdan keyin bo‘lsin" }
        require(java.time.Duration.between(start, end).toHours() <= 48) { "Vaqt oralig‘ini tekshiring" }
        val row = TpMachineDowntime(
            id = UUID.randomUUID().toString(), brigadeId = brigadeId, date = start.toLocalDate().toString(),
            stoppedAt = start.toString(), restartedAt = end.toString(), note = cleanNote, createdAt = LocalDateTime.now().toString()
        )
        data.copy(machines = data.machines.map { if (it.id == machine.id) it.copy(downtimes = it.downtimes + row) else it })
            .audit("TP_MACHINE_DOWNTIME", brigadeId.takeIf { it.isNotBlank() }, row.date, "${machine.number}-stanok • ${row.durationMinutes()} daqiqa • $cleanNote")
    }

    @Synchronized
    fun addReceipt(
        jobId: String,
        detailId: String,
        workerId: String,
        date: String,
        completedBags: Int,
        remainderAfter: Int,
        receiverName: String
    ): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        val order = data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        require(job.planConfirmedAt != null) { "Plan beruvchi avval shu detal rejasini tasdiqlasin" }
        val output = job.outputs.firstOrNull { it.detailId == detailId } ?: error("Detal topilmadi")
        val worker = data.workers.firstOrNull { it.id == workerId && !it.archived } ?: error("Ishchi topilmadi")
        val machineId = job.machineId ?: error("Stanok belgilanmagan")
        val brigadeId = job.brigadeId ?: error("Brigada belgilanmagan")
        val shiftId = job.shiftId ?: error("Smena belgilanmagan")
        require(worker.brigadeId == brigadeId) { "Ishchi boshqa brigadaga tegishli" }
        require(receiverName.cleanText().isNotBlank()) { "Qabul qiluvchi ismini kiriting" }
        val carry = data.openRemainder(jobId, detailId)
        val credited = calculateReceiptCredit(output.bagCapacity, carry, completedBags, remainderAfter)
        val now = LocalDateTime.now().toString()
        val receipt = TpReceipt(
            id = UUID.randomUUID().toString(), jobId = job.id, orderId = job.orderId,
            detailId = output.detailId, detailNameSnapshot = output.detailName,
            machineId = machineId, workerId = worker.id, workerNameSnapshot = worker.name,
            brigadeId = brigadeId, shiftId = shiftId, date = date, colorCode = job.colorCode,
            completedBags = completedBags, bagCapacity = output.bagCapacity,
            carryInPieces = carry, remainderAfter = remainderAfter, creditedPieces = credited,
            unitPriceSnapshot = output.unitPrice, receiverName = receiverName.cleanText(), createdAt = now,
            piecesPerShotSnapshot = output.piecesPerShot
        )
        var updated = data.copy(
            receipts = data.receipts + receipt,
            jobs = data.jobs.map { if (it.id == jobId && it.status == TpJobStatus.QUEUED) it.copy(status = TpJobStatus.IN_PROGRESS) else it }
        )
        val produced = updated.receipts.filter { it.jobId == jobId && it.detailId == detailId }.sumOf { it.creditedPieces }
        val allDone = job.outputs.all { planned ->
            updated.receipts.filter { it.jobId == jobId && it.detailId == planned.detailId }.sumOf { it.creditedPieces } >= planned.requiredPieces
        }
        if (allDone) updated = updated.copy(jobs = updated.jobs.map { if (it.id == jobId) it.copy(status = TpJobStatus.COMPLETE) else it })
        updated = updated.refreshOrderStatus(job.orderId)
        updated.audit("TP_RECEIPT", brigadeId, date, "${output.detailName}: +$credited (jami $produced), qoldiq $remainderAfter")
    }

    @Synchronized
    fun updateReceipt(
        receiptId: String,
        workerId: String,
        date: String,
        completedBags: Int,
        remainderAfter: Int,
        editorName: String,
        reason: String
    ): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val current = data.receipts.firstOrNull { it.id == receiptId } ?: error("Qabul yozuvi topilmadi")
        val job = data.jobs.firstOrNull { it.id == current.jobId } ?: error("Vazifa topilmadi")
        val output = job.outputs.firstOrNull { it.detailId == current.detailId } ?: error("Detal topilmadi")
        val worker = data.workers.firstOrNull { it.id == workerId && !it.archived } ?: error("Ishchi topilmadi")
        require(worker.brigadeId == current.brigadeId) { "Ishchi boshqa brigadaga tegishli" }
        val cleanEditor = editorName.cleanText()
        val cleanReason = reason.cleanText()
        require(cleanEditor.isNotBlank()) { "Tahrir qiluvchi aniqlanmadi" }
        require(current.receiverName.equals(cleanEditor, true)) { "Faqat o‘zingiz qabul qilgan yozuvni tahrirlashingiz mumkin" }
        require(cleanReason.isNotBlank()) { "Tahrirlash izohi majburiy" }
        val now = LocalDateTime.now().toString()
        val baseUpdated = current.copy(
            workerId = worker.id, workerNameSnapshot = worker.name, date = date,
            completedBags = completedBags, remainderAfter = remainderAfter,
            updatedAt = now, updatedBy = cleanEditor, editReason = cleanReason
        )
        val chain = data.receipts.filter { it.jobId == current.jobId && it.detailId == current.detailId }
            .map { if (it.id == receiptId) baseUpdated else it }
            .sortedBy { it.createdAt }
        var carry = 0
        val recalculated = chain.map { row ->
            val credited = calculateReceiptCredit(output.bagCapacity, carry, row.completedBags, row.remainderAfter)
            val fixed = row.copy(carryInPieces = carry, creditedPieces = credited)
            carry = row.remainderAfter
            fixed
        }
        val byId = recalculated.associateBy { it.id }
        val finalEdited = byId.getValue(receiptId)
        data.copy(receipts = data.receipts.map { byId[it.id] ?: it })
            .audit(
                "TP_RECEIPT_EDIT", current.brigadeId, date,
                "${current.detailNameSnapshot}: ${current.creditedPieces}→${finalEdited.creditedPieces} dona; ${current.workerNameSnapshot}→${worker.name}; sabab: $cleanReason"
            )
    }

    @Synchronized
    fun deleteReceipt(receiptId: String, editorName: String): Result<Unit> = mutate { data ->
        val current = data.receipts.firstOrNull { it.id == receiptId } ?: error("Qabul yozuvi topilmadi")
        val cleanEditor = editorName.cleanText()
        require(cleanEditor.isNotBlank()) { "O‘chiruvchi aniqlanmadi" }
        require(current.receiverName.equals(cleanEditor, true)) { "Faqat o‘zingiz qabul qilgan yozuvni o‘chirishingiz mumkin" }
        val job = data.jobs.firstOrNull { it.id == current.jobId } ?: error("Vazifa topilmadi")
        val output = job.outputs.firstOrNull { it.detailId == current.detailId } ?: error("Detal topilmadi")

        val remainingChain = data.receipts.filter { it.jobId == current.jobId && it.detailId == current.detailId && it.id != receiptId }
            .sortedBy { it.createdAt }
        var carry = 0
        val recalculated = remainingChain.map { row ->
            val credited = calculateReceiptCredit(output.bagCapacity, carry, row.completedBags, row.remainderAfter)
            val fixed = row.copy(carryInPieces = carry, creditedPieces = credited)
            carry = row.remainderAfter
            fixed
        }
        val recalculatedById = recalculated.associateBy { it.id }
        var updated = data.copy(receipts = data.receipts.filterNot { it.id == receiptId }.map { recalculatedById[it.id] ?: it })
        val allDone = job.outputs.all { planned ->
            updated.receipts.filter { it.jobId == job.id && it.detailId == planned.detailId }.sumOf { it.creditedPieces } >= planned.requiredPieces
        }
        if (!allDone && job.status == TpJobStatus.COMPLETE) {
            updated = updated.copy(jobs = updated.jobs.map { if (it.id == job.id) it.copy(status = TpJobStatus.IN_PROGRESS) else it })
        }
        updated = updated.refreshOrderStatus(job.orderId)
        updated.audit(
            "TP_RECEIPT_DELETE", current.brigadeId, current.date,
            "${current.detailNameSnapshot}: ${current.creditedPieces} dona o‘chirildi; qabul qiluvchi: $cleanEditor"
        )
    }

    @Synchronized
    fun saveQualityRound(
        jobId: String,
        workerId: String,
        date: String,
        round: Int,
        score: Int,
        issue: String,
        checkedBy: String
    ): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        val order = data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        require(job.planConfirmedAt != null) { "Plan beruvchi avval shu detal rejasini tasdiqlasin" }
        val brigadeId = job.brigadeId ?: error("Brigada belgilanmagan")
        val shiftId = job.shiftId ?: error("Smena belgilanmagan")
        val machineId = job.machineId ?: error("Stanok belgilanmagan")
        require(data.workers.any { it.id == workerId && it.brigadeId == brigadeId }) { "Ishchini tanlang" }
        require(score in 0..100) { "Baho 0–100 oralig‘ida bo‘lsin" }
        val shift = data.shifts.firstOrNull { it.id == shiftId } ?: error("Smena topilmadi")
        require(round in 1..shift.roundTimes.size) { "Raund raqami noto‘g‘ri" }
        val scheduled = LocalTime.parse(shift.roundTimes[round - 1])
        val selectedDate = LocalDate.parse(date)
        val nowDate = LocalDate.now()
        val nowTime = LocalTime.now()
        require(selectedDate == nowDate) { "Sifat raundi faqat amaldagi kunda baholanadi" }
        val rawDelta = kotlin.math.abs(java.time.Duration.between(scheduled, nowTime).toMinutes())
        val deltaMinutes = minOf(rawDelta, 24L * 60L - rawDelta)
        require(deltaMinutes <= 60L) { "Bu raundni faqat belgilangan vaqtdan ±1 soat oralig‘ida baholash mumkin" }
        require(checkedBy.cleanText().isNotBlank()) { "Tekshiruvchi ismini kiriting" }
        val id = "${jobId}_${workerId}_${date}_$round"
        val record = TpQualityRound(
            id, brigadeId, shiftId, machineId, workerId, jobId, date, round,
            shift.roundTimes[round - 1], score, issue.cleanText(), checkedBy.cleanText(), LocalDateTime.now().toString()
        )
        data.copy(qualityRounds = data.qualityRounds.filterNot { it.id == id } + record)
            .audit("TP_QUALITY", brigadeId, date, "${machineId}: $round / $score")
    }

    @Synchronized
    fun addDailyIssue(
        brigadeId: String, date: String, machineId: String?, orderId: String?, title: String, note: String,
        issueId: String = UUID.randomUUID().toString(), imageUrls: List<String> = emptyList(), imagePaths: List<String> = emptyList()
    ): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val cleanTitle = title.cleanText()
        val cleanNote = note.cleanText()
        require(cleanTitle.isNotBlank() && cleanNote.isNotBlank()) { "Muammo nomi va izohini kiriting" }
        require(data.brigades.any { it.id == brigadeId }) { "Brigadani tanlang" }
        val urls = imageUrls.filter { it.isNotBlank() }.distinct().take(10)
        val paths = imagePaths.filter { it.isNotBlank() }.distinct().take(10)
        require(urls.size <= 10 && paths.size <= 10) { "Bitta muammoga ko‘pi bilan 10 ta rasm qo‘shiladi" }
        val issue = TpDailyIssue(
            issueId, brigadeId, date, machineId, orderId, cleanTitle, cleanNote, LocalDateTime.now().toString(),
            urls.firstOrNull().orEmpty(), paths.firstOrNull().orEmpty(), urls, paths
        )
        data.copy(dailyIssues = data.dailyIssues + issue).audit("TP_DAILY_ISSUE", brigadeId, date, cleanTitle)
    }

    @Synchronized
    fun replaceFromServer(data: TpData) {
        saveLocal(normalize(data))
        TpDataEvents.notifyChanged()
    }

    fun encodeForSync(data: TpData): String = encode(data).toString()
    fun decodeForSync(raw: String): TpData = normalize(decode(JSONObject(raw)))

    private fun validateDetail(data: TpData, detail: TpDetail) {
        require(detail.name.cleanText().isNotBlank()) { "Detal nomini kiriting" }
        require(detail.requiredPerProduct > 0 && detail.piecesPerShot > 0) { "Detal va jim sonlari 0 dan katta bo‘lsin" }
        require(detail.bagCapacity > 0) { "Qop sig‘imini kiriting" }
        require(detail.cycleSeconds > 0) { "Sikl vaqtini kiriting" }
        require(detail.grossShotWeightGrams > 0.0 && detail.unusableShotWeightGrams in 0.0..detail.grossShotWeightGrams) { "Og‘irlikni to‘g‘ri kiriting" }
        require(detail.resinOptions().isNotEmpty()) { "Kamida bitta seryo turini kiriting" }
        require(detail.unitPrice.isFinite() && detail.unitPrice >= 0.0) { "1 jim narxini to‘g‘ri kiriting" }
        require(detail.compatibleCapacities.isNotEmpty() && detail.compatibleCapacities.all { it > 0 }) { "Detal tushadigan stanok sig‘imlarini kiriting" }
        require(detail.colors.isNotEmpty()) { "Kamida bitta rang kiriting" }
        require(detail.colors.all { it.colorCode.isNotBlank() && it.share > 0.0 && it.gramsPer25Kg >= 0.0 }) { "Rang taqsimoti noto‘g‘ri" }
        require(detail.colors.map { it.colorCode.trim().uppercase(Locale.ROOT) }.distinct().size == detail.colors.size) { "Bir detalda rang kodi takrorlanmasin" }
    }

    private fun TpData.refreshOrderStatus(orderId: String): TpData {
        val orderJobs = jobs.filter { it.orderId == orderId }
        val order = orders.firstOrNull { it.id == orderId }
        val status = when {
            orderJobs.isNotEmpty() && orderJobs.all { it.status == TpJobStatus.COMPLETE } -> TpOrderStatus.COMPLETE
            orderJobs.any { it.status == TpJobStatus.IN_PROGRESS || it.status == TpJobStatus.COMPLETE } -> TpOrderStatus.IN_PROGRESS
            order?.planApprovedAt != null -> TpOrderStatus.APPROVED
            orderJobs.isNotEmpty() && orderJobs.all { it.machineId != null } -> TpOrderStatus.READY
            orderJobs.isNotEmpty() -> TpOrderStatus.PLANNING
            else -> TpOrderStatus.NEW
        }
        val now = if (status == TpOrderStatus.COMPLETE) LocalDateTime.now().toString() else null
        return copy(orders = orders.map { if (it.id == orderId) it.copy(status = status, completedAt = now ?: it.completedAt) else it })
    }

    private fun TpData.audit(action: String, brigadeId: String? = null, recordDate: String? = null, details: String): TpData = copy(
        auditLog = (auditLog + TpAuditEntry(UUID.randomUUID().toString(), action, brigadeId, recordDate, details, LocalDateTime.now().toString())).takeLast(3000)
    )

    @Synchronized
    fun resetTpForFreshImportLocal() {
        val current = load()
        val currentTarget = current.globalDailyTargetAmount()
        val clean = defaultData().copy(
            brigades = current.brigades.map { it.copy(archived = true) },
            settings = TpSettings(dailyTargetAmount = currentTarget, overtimeTypes = current.settings.overtimeTypes)
        )
        saveLocal(clean)
        outbox.clear()
        outbox.markAll(clean)
        TpDataEvents.notifyChanged()
        FirebaseSyncScheduler.enqueue(appContext)
    }

    private fun mutate(block: (TpData) -> TpData): Result<Unit> = runCatching {
        val before = load()
        val after = normalize(block(before))
        accessGuard.validate(before, after)
        saveLocal(after)
        outbox.recordDiff(before, after)
        TpDataEvents.notifyChanged()
        FirebaseSyncScheduler.enqueue(appContext)
    }

    private fun saveLocal(data: TpData) {
        prefs.edit().putString(KEY_DATA, encode(data).toString()).commit()
    }

    private fun normalize(data: TpData): TpData {
        val resolvedDailyTarget = data.settings.dailyTargetAmount.takeIf { it > 0L }
            ?: data.workers.firstOrNull { it.dailyTargetAmount > 0L }?.dailyTargetAmount
            ?: 100_000L
        return data.copy(
        shops = data.shops.distinctBy { it.id }, shifts = data.shifts.distinctBy { it.id },
        brigades = data.brigades.distinctBy { it.id }, machines = data.machines.distinctBy { it.id }.map { it.copy(downtimes = it.downtimes.distinctBy { row -> row.id }) },
        products = data.products.distinctBy { it.id },
        materials = data.materials.distinctBy { it.id }.map { it.copy(movements = it.movements.distinctBy { movement -> movement.id }) }, orders = data.orders.distinctBy { it.id },
        jobs = data.jobs.distinctBy { it.id }, attendance = data.attendance.distinctBy { it.id },
        receipts = data.receipts.distinctBy { it.id }, qualityRounds = data.qualityRounds.distinctBy { it.id },
        dailyIssues = data.dailyIssues.distinctBy { it.id }, auditLog = data.auditLog.distinctBy { it.id }.takeLast(3000),
        workers = data.workers.distinctBy { it.id }.map { it.copy(dailyTargetAmount = 0L, defaultWorkMinutes = 0, overtimeEntries = it.overtimeEntries.distinctBy { row -> row.id }) },
        settings = data.settings.copy(dailyTargetAmount = resolvedDailyTarget, overtimeTypes = data.settings.overtimeTypes.distinctBy { it.id })
    )
    }

    private fun defaultData(): TpData {
        val shops = (1..3).map { TpShop("tp-shop-$it", "$it-sex") }
        val shifts = listOf(
            TpShift("tp-shift-day", "Kunduzgi", "07:40", "19:00", listOf("10:00", "13:00", "16:00")),
            TpShift("tp-shift-night", "Tungi", "19:00", "07:00", listOf("22:00", "02:00"))
        )
        return TpData(shops = shops, shifts = shifts, settings = TpSettings(dailyTargetAmount = 100_000L))
    }

    private fun encode(data: TpData): JSONObject = JSONObject().apply {
        put("shops", array(data.shops) { o, item -> o.put("id", item.id).put("name", item.name).put("archived", item.archived) })
        put("shifts", array(data.shifts) { o, item -> o.put("id", item.id).put("name", item.name).put("startTime", item.startTime).put("endTime", item.endTime).put("roundTimes", strings(item.roundTimes)).put("archived", item.archived) })
        put("brigades", array(data.brigades) { o, item -> o.put("id", item.id).put("shopId", item.shopId).put("shiftId", item.shiftId).put("name", item.name).put("archived", item.archived) })
        put("machines", array(data.machines) { o, item ->
            o.put("id", item.id).put("shopId", item.shopId).put("number", item.number).put("name", item.name).put("archived", item.archived).put("capacity", item.capacity)
                .put("downtimes", array(item.downtimes) { d, row ->
                    d.put("id", row.id).put("brigadeId", row.brigadeId).put("date", row.date).put("stoppedAt", row.stoppedAt)
                        .put("restartedAt", row.restartedAt).put("note", row.note).put("createdAt", row.createdAt)
                })
        })
        put("workers", array(data.workers) { o, item ->
            o.put("id", item.id).put("brigadeId", item.brigadeId).put("name", item.name).put("dailyTargetAmount", item.dailyTargetAmount).put("archived", item.archived)
                .put("overtimeEntries", array(item.overtimeEntries) { e, row ->
                    e.put("id", row.id).put("typeId", row.typeId).put("typeNameSnapshot", row.typeNameSnapshot).put("date", row.date)
                        .put("hours", row.hours).put("hourlyRateSnapshot", row.hourlyRateSnapshot).put("createdAt", row.createdAt)
                })
        })
        put("products", array(data.products) { o, product ->
            o.put("id", product.id).put("article", product.article).put("name", product.name).put("archived", product.archived)
                .put("details", array(product.details) { d, detail ->
                    d.put("id", detail.id).put("name", detail.name).put("moldCode", detail.moldCode)
                        .put("requiredPerProduct", detail.requiredPerProduct).put("piecesPerShot", detail.piecesPerShot)
                        .put("bagCapacity", detail.bagCapacity).put("cycleSeconds", detail.cycleSeconds)
                        .put("grossShotWeightGrams", detail.grossShotWeightGrams).put("unusableShotWeightGrams", detail.unusableShotWeightGrams)
                        .put("resinCode", detail.resinCode).put("resinCodes", strings(detail.resinOptions())).put("unitPrice", detail.unitPrice)
                        .put("compatibleMachineIds", strings(emptySet<String>()))
                        .put("compatibleCapacities", JSONArray().apply { detail.compatibleCapacities.sorted().forEach { value -> put(value) } })
                        .put("colors", array(detail.colors) { c, color -> c.put("colorCode", color.colorCode).put("share", color.share).put("gramsPer25Kg", color.gramsPer25Kg) })
                        .put("archived", detail.archived)
                })
        })
        put("materials", array(data.materials) { o, item ->
            o.put("id", item.id).put("code", item.code).put("name", item.name).put("type", item.type.name)
                .put("availableAmount", item.availableAmount).put("archived", item.archived)
                .put("movements", array(item.movements) { m, movement ->
                    m.put("id", movement.id).put("kind", movement.kind.name).put("amount", movement.amount)
                        .put("createdAt", movement.createdAt).put("note", movement.note).putNullable("sourceJobId", movement.sourceJobId)
                })
        })
        put("orders", array(data.orders) { o, order ->
            o.put("id", order.id).put("batchNumber", order.batchNumber).put("productId", order.productId)
                .put("articleSnapshot", order.articleSnapshot).put("productNameSnapshot", order.productNameSnapshot)
                .put("quantity", order.quantity).put("priority", order.priority).put("requestedDate", order.requestedDate)
                .put("note", order.note).put("status", order.status.name).put("createdAt", order.createdAt)
            if (order.completedAt == null) o.put("completedAt", JSONObject.NULL) else o.put("completedAt", order.completedAt)
            if (order.planApprovedAt == null) o.put("planApprovedAt", JSONObject.NULL) else o.put("planApprovedAt", order.planApprovedAt)
        })
        put("jobs", array(data.jobs) { o, job ->
            o.put("id", job.id).put("orderId", job.orderId).put("moldCode", job.moldCode).put("colorCode", job.colorCode)
                .put("outputs", array(job.outputs) { d, output -> d.put("detailId", output.detailId).put("detailName", output.detailName).put("requiredPieces", output.requiredPieces).put("plannedPieces", output.plannedPieces).put("piecesPerShot", output.piecesPerShot).put("bagCapacity", output.bagCapacity).put("unitPrice", output.unitPrice) })
                .put("requiredShots", job.requiredShots).put("cycleSeconds", job.cycleSeconds).put("estimatedMinutes", job.estimatedMinutes)
                .put("resinCode", job.resinCode).put("requiredResinKg", job.requiredResinKg).put("requiredColorGrams", job.requiredColorGrams)
                .put("compatibleMachineIds", strings(job.compatibleMachineIds)).putNullable("machineId", job.machineId)
                .putNullable("brigadeId", job.brigadeId).putNullable("shiftId", job.shiftId).put("priority", job.priority)
                .put("status", job.status.name).put("materialStatus", job.materialStatus.name)
                .putNullable("planConfirmedAt", job.planConfirmedAt).putNullable("planEditedAt", job.planEditedAt).put("planEditReason", job.planEditReason)
                .putNullable("resinSelectedAt", job.resinSelectedAt).putNullable("resinConfirmedAt", job.resinConfirmedAt).put("materialShortageOverride", job.materialShortageOverride)
                .putNullable("materialConfirmedAt", job.materialConfirmedAt).putNullable("materialDeliveredAt", job.materialDeliveredAt)
                .putNullable("startedAt", job.startedAt)
        })
        put("attendance", array(data.attendance) { o, item -> o.put("id", item.id).put("workerId", item.workerId).put("brigadeId", item.brigadeId).put("shiftId", item.shiftId).put("date", item.date).put("present", item.present).put("workMinutes", item.workMinutes).put("updatedAt", item.updatedAt).put("minusHours", item.minusHours) })
        put("receipts", array(data.receipts) { o, receipt ->
            o.put("id", receipt.id).put("jobId", receipt.jobId).put("orderId", receipt.orderId).put("detailId", receipt.detailId)
                .put("detailNameSnapshot", receipt.detailNameSnapshot).put("machineId", receipt.machineId).put("workerId", receipt.workerId)
                .put("workerNameSnapshot", receipt.workerNameSnapshot).put("brigadeId", receipt.brigadeId).put("shiftId", receipt.shiftId)
                .put("date", receipt.date).put("colorCode", receipt.colorCode).put("completedBags", receipt.completedBags)
                .put("bagCapacity", receipt.bagCapacity).put("carryInPieces", receipt.carryInPieces).put("remainderAfter", receipt.remainderAfter)
                .put("creditedPieces", receipt.creditedPieces).put("unitPriceSnapshot", receipt.unitPriceSnapshot)
                .put("receiverName", receipt.receiverName).put("createdAt", receipt.createdAt)
                .put("piecesPerShotSnapshot", receipt.piecesPerShotSnapshot)
                .putNullable("updatedAt", receipt.updatedAt).put("updatedBy", receipt.updatedBy).put("editReason", receipt.editReason)
        })
        put("qualityRounds", array(data.qualityRounds) { o, item -> o.put("id", item.id).put("brigadeId", item.brigadeId).put("shiftId", item.shiftId).put("machineId", item.machineId).put("workerId", item.workerId).put("jobId", item.jobId).put("date", item.date).put("round", item.round).put("scheduledTime", item.scheduledTime).put("score", item.score).put("issue", item.issue).put("checkedBy", item.checkedBy).put("checkedAt", item.checkedAt) })
        put("dailyIssues", array(data.dailyIssues) { o, item ->
            o.put("id", item.id).put("brigadeId", item.brigadeId).put("date", item.date).putNullable("machineId", item.machineId).putNullable("orderId", item.orderId)
                .put("title", item.title).put("note", item.note).put("createdAt", item.createdAt)
                .put("imageUrl", item.imageUrl).put("imagePath", item.imagePath)
                .put("imageUrls", strings(item.allImageUrls())).put("imagePaths", strings(item.allImagePaths()))
        })
        put("auditLog", array(data.auditLog) { o, item -> o.put("id", item.id).put("action", item.action).putNullable("brigadeId", item.brigadeId).putNullable("recordDate", item.recordDate).put("details", item.details).put("createdAt", item.createdAt) })
        put("settings", JSONObject().put("firstBatchEntered", data.settings.firstBatchEntered).put("priceRevision", data.settings.priceRevision).put("dailyTargetAmount", data.globalDailyTargetAmount())
            .put("overtimeTypes", array(data.settings.overtimeTypes) { o, row -> o.put("id", row.id).put("name", row.name).put("hourlyRate", row.hourlyRate).put("archived", row.archived) }))
    }

    private fun decode(root: JSONObject): TpData = TpData(
        shops = root.arr("shops").objects().map { TpShop(it.text("id"), it.text("name"), it.optBoolean("archived")) },
        shifts = root.arr("shifts").objects().map { TpShift(it.text("id"), it.text("name"), it.text("startTime", "07:40"), it.text("endTime", "19:00"), it.arr("roundTimes").stringValues(), it.optBoolean("archived")) },
        brigades = root.arr("brigades").objects().map { TpBrigade(it.text("id"), it.text("shopId"), it.text("shiftId"), it.text("name"), it.optBoolean("archived")) },
        machines = root.arr("machines").objects().map { machine -> TpMachine(
            id = machine.text("id"), shopId = machine.text("shopId"), number = machine.optInt("number"), name = machine.text("name"),
            archived = machine.optBoolean("archived"), capacity = machine.optInt("capacity", 0),
            downtimes = machine.arr("downtimes").objects().map { row -> TpMachineDowntime(
                row.text("id"), row.text("brigadeId"), row.text("date"), row.text("stoppedAt"), row.text("restartedAt"), row.text("note"), row.text("createdAt")
            ) }
        ) },
        workers = root.arr("workers").objects().map { worker -> TpWorker(
            id = worker.text("id"), brigadeId = worker.text("brigadeId"), name = worker.text("name"), dailyTargetAmount = worker.optLong("dailyTargetAmount"),
            defaultWorkMinutes = worker.optInt("defaultWorkMinutes", 0), archived = worker.optBoolean("archived"),
            overtimeEntries = worker.arr("overtimeEntries").objects().map { row -> TpWorkerOvertime(
                row.text("id"), row.text("typeId"), row.text("typeNameSnapshot"), row.text("date"), row.optDouble("hours"), row.optLong("hourlyRateSnapshot"), row.text("createdAt")
            ) }
        ) },
        products = root.arr("products").objects().map { product ->
            TpProduct(product.text("id"), product.text("article"), product.text("name"), product.arr("details").objects().map { detail ->
                TpDetail(
                    id = detail.text("id"), name = detail.text("name"), moldCode = detail.text("moldCode"),
                    requiredPerProduct = detail.optInt("requiredPerProduct"), piecesPerShot = detail.optInt("piecesPerShot"),
                    bagCapacity = detail.optInt("bagCapacity"), cycleSeconds = detail.optInt("cycleSeconds"),
                    grossShotWeightGrams = detail.optDouble("grossShotWeightGrams"), unusableShotWeightGrams = detail.optDouble("unusableShotWeightGrams"),
                    resinCode = detail.text("resinCode"), unitPrice = detail.optDouble("unitPrice"),
                    compatibleMachineIds = emptySet(),
                    compatibleCapacities = detail.arr("compatibleCapacities").intValues().filter { it > 0 }.toSet(),
                    colors = detail.arr("colors").objects().map { TpColorRule(it.text("colorCode"), it.optDouble("share"), it.optDouble("gramsPer25Kg")) },
                    archived = detail.optBoolean("archived"),
                    resinCodes = detail.arr("resinCodes").stringValues().ifEmpty { listOf(detail.text("resinCode")) }
                )
            }, product.optBoolean("archived"))
        },
        materials = root.arr("materials").objects().map { material ->
            TpMaterial(
                id = material.text("id"), code = material.text("code"), name = material.text("name", material.text("code")),
                type = material.enum("type", TpMaterialType.RESIN), availableAmount = material.optDouble("availableAmount"),
                archived = material.optBoolean("archived"), movements = material.arr("movements").objects().map { movement ->
                    TpMaterialMovement(
                        id = movement.text("id"), kind = movement.enum("kind", TpMaterialMovementKind.IN),
                        amount = movement.optDouble("amount"), createdAt = movement.text("createdAt"),
                        note = movement.text("note"), sourceJobId = movement.nullableText("sourceJobId")
                    )
                }
            )
        },
        orders = root.arr("orders").objects().map { TpOrder(it.text("id"), it.text("batchNumber"), it.text("productId"), it.text("articleSnapshot"), it.text("productNameSnapshot"), it.optInt("quantity"), it.optInt("priority", 1), it.text("requestedDate", isoToday()), it.text("note"), it.enum("status", TpOrderStatus.NEW), it.text("createdAt"), it.nullableText("completedAt"), it.nullableText("planApprovedAt")) },
        jobs = root.arr("jobs").objects().map { job ->
            TpPlanJob(
                id = job.text("id"), orderId = job.text("orderId"), moldCode = job.text("moldCode"), colorCode = job.text("colorCode"),
                outputs = job.arr("outputs").objects().map { TpJobOutput(it.text("detailId"), it.text("detailName"), it.optInt("requiredPieces"), it.optInt("plannedPieces"), it.optInt("piecesPerShot"), it.optInt("bagCapacity"), it.optDouble("unitPrice")) },
                requiredShots = job.optInt("requiredShots"), cycleSeconds = job.optInt("cycleSeconds"), estimatedMinutes = job.optInt("estimatedMinutes"),
                resinCode = job.text("resinCode"), requiredResinKg = job.optDouble("requiredResinKg"), requiredColorGrams = job.optDouble("requiredColorGrams"),
                compatibleMachineIds = job.arr("compatibleMachineIds").stringValues().toSet(), machineId = job.nullableText("machineId"),
                brigadeId = job.nullableText("brigadeId"), shiftId = job.nullableText("shiftId"), priority = job.optInt("priority"),
                status = job.enum("status", TpJobStatus.UNASSIGNED), materialStatus = job.enum("materialStatus", TpMaterialStatus.PLANNED),
                planConfirmedAt = job.nullableText("planConfirmedAt"), planEditedAt = job.nullableText("planEditedAt"), planEditReason = job.text("planEditReason"),
                resinSelectedAt = job.nullableText("resinSelectedAt"), resinConfirmedAt = job.nullableText("resinConfirmedAt"), materialShortageOverride = job.optBoolean("materialShortageOverride", false),
                materialConfirmedAt = job.nullableText("materialConfirmedAt"), materialDeliveredAt = job.nullableText("materialDeliveredAt"),
                startedAt = job.nullableText("startedAt")
            )
        },
        attendance = root.arr("attendance").objects().map { TpAttendance(it.text("id"), it.text("workerId"), it.text("brigadeId"), it.text("shiftId"), it.text("date"), it.optBoolean("present"), it.optInt("workMinutes"), it.text("updatedAt"), if (it.has("minusHours")) it.optDouble("minusHours") else -1.0) },
        receipts = root.arr("receipts").objects().map { TpReceipt(
            it.text("id"), it.text("jobId"), it.text("orderId"), it.text("detailId"), it.text("detailNameSnapshot"), it.text("machineId"),
            it.text("workerId"), it.text("workerNameSnapshot"), it.text("brigadeId"), it.text("shiftId"), it.text("date"), it.text("colorCode"),
            it.optInt("completedBags"), it.optInt("bagCapacity"), it.optInt("carryInPieces"), it.optInt("remainderAfter"), it.optInt("creditedPieces"),
            it.optDouble("unitPriceSnapshot"), it.text("receiverName"), it.text("createdAt"), it.optInt("piecesPerShotSnapshot", 1).coerceAtLeast(1),
            it.nullableText("updatedAt"), it.text("updatedBy"), it.text("editReason")
        ) },
        qualityRounds = root.arr("qualityRounds").objects().map { TpQualityRound(it.text("id"), it.text("brigadeId"), it.text("shiftId"), it.text("machineId"), it.text("workerId"), it.text("jobId"), it.text("date"), it.optInt("round"), it.text("scheduledTime"), it.optInt("score"), it.text("issue"), it.text("checkedBy"), it.text("checkedAt")) },
        dailyIssues = root.arr("dailyIssues").objects().map { issue ->
            val legacyUrl = issue.text("imageUrl")
            val legacyPath = issue.text("imagePath")
            val urls = issue.arr("imageUrls").stringValues().ifEmpty { listOfNotNull(legacyUrl.takeIf { it.isNotBlank() }) }
            val paths = issue.arr("imagePaths").stringValues().ifEmpty { listOfNotNull(legacyPath.takeIf { it.isNotBlank() }) }
            TpDailyIssue(issue.text("id"), issue.text("brigadeId"), issue.text("date"), issue.nullableText("machineId"), issue.nullableText("orderId"), issue.text("title"), issue.text("note"), issue.text("createdAt"), legacyUrl, legacyPath, urls, paths)
        },
        auditLog = root.arr("auditLog").objects().map { TpAuditEntry(it.text("id"), it.text("action"), it.nullableText("brigadeId"), it.nullableText("recordDate"), it.text("details"), it.text("createdAt")) },
        settings = root.optJSONObject("settings")?.let { settings -> TpSettings(
            firstBatchEntered = settings.optBoolean("firstBatchEntered"),
            priceRevision = settings.optInt("priceRevision"),
            dailyTargetAmount = settings.optLong("dailyTargetAmount"),
            overtimeTypes = settings.arr("overtimeTypes").objects().map { row -> TpOvertimeType(row.text("id"), row.text("name"), row.optLong("hourlyRate"), row.optBoolean("archived")) }
        ) } ?: TpSettings()
    )

    private fun <T> array(values: Iterable<T>, block: (JSONObject, T) -> Unit): JSONArray = JSONArray().apply {
        values.forEach { value -> put(JSONObject().also { block(it, value) }) }
    }

    private fun strings(values: Iterable<String>): JSONArray = JSONArray().apply { values.forEach { value -> put(value) } }
    private fun JSONArray.intValues(): List<Int> = (0 until length()).mapNotNull { index -> optInt(index).takeIf { it > 0 } }
    private fun JSONObject.putNullable(key: String, value: String?): JSONObject = put(key, value ?: JSONObject.NULL)

    companion object {
        private const val PREFS_NAME = "toy_bola_tp_data_v1"
        private const val KEY_DATA = "tp_data"
    }
}

private fun String.cleanText(): String = trim().replace(Regex("\\s+"), " ")
private fun JSONObject.arr(key: String): JSONArray = optJSONArray(key) ?: JSONArray()
private fun JSONArray.objects(): List<JSONObject> = buildList {
    repeat(length()) { index -> optJSONObject(index)?.let(::add) }
}
private fun JSONArray.stringValues(): List<String> = buildList {
    repeat(length()) { index -> optString(index, "").trim().takeIf { it.isNotBlank() }?.let(::add) }
}
private fun JSONObject.text(key: String, fallback: String = ""): String = optString(key, fallback).takeUnless { it == "null" } ?: fallback
private fun JSONObject.nullableText(key: String): String? = if (isNull(key)) null else optString(key).takeIf { it.isNotBlank() }
private inline fun <reified T : Enum<T>> JSONObject.enum(key: String, fallback: T): T = runCatching { enumValueOf<T>(optString(key)) }.getOrDefault(fallback)
