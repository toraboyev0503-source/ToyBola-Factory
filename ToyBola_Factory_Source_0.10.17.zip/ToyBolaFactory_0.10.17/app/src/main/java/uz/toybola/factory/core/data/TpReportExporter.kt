package uz.toybola.factory.core.data

import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class TpReportTable(
    val title: String,
    val metadata: List<String>,
    val headers: List<String>,
    val rows: List<List<String>>
)

fun buildTpReport(data: TpData, from: String, to: String, brigadeId: String?): TpReportTable {
    val brigadeName = brigadeId?.let { id -> data.brigades.firstOrNull { it.id == id }?.name } ?: "Barcha brigadalar"
    val scopedJobs = data.jobs.filter { job -> brigadeId == null || job.brigadeId == brigadeId }
    val scopedOrderIds = scopedJobs.map { it.orderId }.toSet()
    val orders = data.orders.filter { it.requestedDate in from..to && (brigadeId == null || it.id in scopedOrderIds) }
    val receipts = data.receipts.filter { it.date in from..to && (brigadeId == null || it.brigadeId == brigadeId) }
    val quality = data.qualityRounds.filter { it.date in from..to && (brigadeId == null || it.brigadeId == brigadeId) }
    val issues = data.dailyIssues.filter { it.date in from..to && (brigadeId == null || it.brigadeId == brigadeId) }
    val attendanceRecords = data.attendance.filter { it.date in from..to && (brigadeId == null || it.brigadeId == brigadeId) }
    val orderIds = orders.map { it.id }.toSet()
    val receiptJobIds = receipts.map { it.jobId }.toSet()
    val jobs = scopedJobs.filter { job ->
        job.orderId in orderIds || job.id in receiptJobIds ||
            (job.materialDeliveredAt ?: job.materialConfirmedAt)?.take(10)?.let { it in from..to } == true
    }
    val materialJobs = scopedJobs.filter { job ->
        job.materialStatus != TpMaterialStatus.PLANNED &&
            (job.materialDeliveredAt ?: job.materialConfirmedAt)?.take(10)?.let { it in from..to } == true
    }
    val rows = buildList {
        orders.sortedBy { it.requestedDate }.forEach { order ->
            add(listOf("PARTIYA", order.requestedDate, order.batchNumber, "${order.articleSnapshot} — ${order.productNameSnapshot}", order.quantity.toString(), "${data.orderProgress(order.id).toInt()}%", orderStatusReport(order.status)))
        }
        val overtimeWorkerIds = data.workers.filter { worker -> worker.overtimeEntries.any { it.date in from..to } }.map { it.id }
        val workerIds = (receipts.map { it.workerId } + attendanceRecords.map { it.workerId } + overtimeWorkerIds).toSet()
        data.workers.filter { it.id in workerIds }.sortedBy { it.name }.forEach { worker ->
            val workerId = worker.id
            val values = receipts.filter { it.workerId == workerId }
            val earned = data.workerEarned(workerId, from, to)
            val qualityAverage = quality.filter { it.workerId == workerId }.map { it.score }.takeIf { it.isNotEmpty() }?.average()
            val attendance = attendanceRecords.filter { it.workerId == workerId && it.present }
            val target = attendance.sumOf { data.globalDailyTargetAmount().toDouble() * data.attendanceWorkMinutes(worker.id, it.date) / data.workerStandardMinutes(worker.id).coerceAtLeast(1) }
            val efficiency = if (target > 0) earned * 100.0 / target else null
            val usefulness = if (efficiency != null && qualityAverage != null) (efficiency + qualityAverage) / 2 else null
            add(listOf("ISHCHI", from, worker.name, "Topdi: $earned so‘m", "Samaradorlik: ${efficiency?.toInt()?.let { "$it%" } ?: "—"}", "Sifat: ${qualityAverage?.toInt()?.let { "$it%" } ?: "—"}", "Foydalilik: ${usefulness?.toInt()?.let { "$it%" } ?: "—"}"))
        }
        data.brigades.filter { brigadeId == null || it.id == brigadeId }.sortedBy { it.name }.forEach { brigade ->
            val brigadeReceipts = receipts.filter { it.brigadeId == brigade.id }
            val brigadeQuality = quality.filter { it.brigadeId == brigade.id }
            val brigadeJobs = jobs.filter { it.brigadeId == brigade.id }
            if (brigadeReceipts.isNotEmpty() || brigadeQuality.isNotEmpty() || brigadeJobs.isNotEmpty()) {
                add(listOf("BRIGADA", from, brigade.name, "${brigadeJobs.size} vazifa", "${brigadeReceipts.sumOf { it.creditedPieces }} dona", "Sifat: ${brigadeQuality.map { it.score }.takeIf { it.isNotEmpty() }?.average()?.toInt()?.let { "$it%" } ?: "—"}", ""))
            }
        }
        jobs.groupBy { it.machineId }.forEach { (machineId, values) ->
            val machine = data.machines.firstOrNull { it.id == machineId }
            val produced = receipts.filter { it.machineId == machineId }.sumOf { it.creditedPieces }
            add(listOf("STANOK", from, "${machine?.number ?: 0}-stanok", "${values.size} vazifa", "${values.count { it.status == TpJobStatus.COMPLETE }} yakunlangan", "$produced dona", "${values.sumOf { it.estimatedMinutes }} daqiqa plan"))
        }
        materialJobs.groupBy { it.resinCode }.forEach { (code, values) ->
            add(listOf("SERYO", from, code, "", formatTpNumber(values.sumOf { it.requiredResinKg }), "kg", ""))
        }
        materialJobs.groupBy { it.colorCode }.forEach { (code, values) ->
            add(listOf("KRASITEL", from, code, "", formatTpNumber(values.sumOf { it.requiredColorGrams }), "gram", ""))
        }
        if (quality.isNotEmpty()) add(listOf("SIFAT", from, brigadeName, "${quality.size} raund", "O‘rtacha ${quality.map { it.score }.average().toInt()}%", "${quality.count { it.issue.isNotBlank() }} muammoli", "${issues.size} kun muammosi"))
    }
    return TpReportTable(
        title = "ToyBola TP va Seryo hisoboti",
        metadata = listOf("Davr: $from — $to", "Brigada: $brigadeName"),
        headers = listOf("Turi", "Sana/davr", "Nomi", "Ko‘rsatkich 1", "Ko‘rsatkich 2", "Ko‘rsatkich 3", "Natija"),
        rows = rows
    )
}

object TpXlsxExporter {
    fun write(output: OutputStream, report: TpReportTable) {
        val rows = buildList {
            add(listOf(report.title))
            report.metadata.forEach { add(listOf(it)) }
            add(emptyList())
            add(report.headers)
            addAll(report.rows)
        }
        ZipOutputStream(output).use { zip ->
            zip.putText("[Content_Types].xml", CONTENT_TYPES)
            zip.putText("_rels/.rels", ROOT_RELS)
            zip.putText("xl/workbook.xml", WORKBOOK)
            zip.putText("xl/_rels/workbook.xml.rels", WORKBOOK_RELS)
            zip.putText("xl/worksheets/sheet1.xml", worksheet(rows))
        }
    }

    private fun worksheet(rows: List<List<String>>): String = buildString {
        append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
        rows.forEachIndexed { rowIndex, values ->
            append("<row r=\"${rowIndex + 1}\">")
            values.forEachIndexed { columnIndex, value ->
                append("<c r=\"${columnName(columnIndex)}${rowIndex + 1}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">")
                append(xml(value))
                append("</t></is></c>")
            }
            append("</row>")
        }
        append("</sheetData></worksheet>")
    }

    private fun columnName(index: Int): String {
        var value = index + 1
        return buildString {
            while (value > 0) {
                insert(0, ('A'.code + (value - 1) % 26).toChar())
                value = (value - 1) / 26
            }
        }
    }

    private fun xml(value: String): String = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
    private fun ZipOutputStream.putText(path: String, text: String) { putNextEntry(ZipEntry(path)); write(text.toByteArray(Charsets.UTF_8)); closeEntry() }

    private const val CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>"""
    private const val ROOT_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""
    private const val WORKBOOK = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="TP hisobot" sheetId="1" r:id="rId1"/></sheets></workbook>"""
    private const val WORKBOOK_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>"""
}

private fun orderStatusReport(status: TpOrderStatus): String = when (status) {
    TpOrderStatus.NEW -> "Yangi"; TpOrderStatus.PLANNING -> "Rejada"; TpOrderStatus.READY -> "Tayyor"
    TpOrderStatus.APPROVED -> "Tasdiqlangan"; TpOrderStatus.IN_PROGRESS -> "Quyilmoqda"
    TpOrderStatus.COMPLETE -> "Yakunlangan"; TpOrderStatus.CANCELLED -> "Bekor qilingan"
}
