package uz.toybola.factory.core.firebase

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import uz.toybola.factory.core.data.*

object SyncOutboxEvents {
    private val _revision = MutableStateFlow(0L)
    val revision: StateFlow<Long> = _revision.asStateFlow()

    internal fun notifyChanged() {
        _revision.value = _revision.value + 1L
    }
}

/** Assembly/Sborka outbox with generation-safe acknowledgement. */
class AssemblySyncOutbox(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun recordDiff(before: AssemblyData, after: AssemblyData) {
        val changed = linkedSetOf<String>()
        addChanged(changed, before.brigades, after.brigades, { it.id }) { "BRIGADE:${it.id}" }
        addChanged(changed, before.workers, after.workers, { it.id }) { "WORKER:${it.id}" }
        addChanged(changed, before.products, after.products, { it.id }) { "PRODUCT:${it.id}" }
        addChanged(changed, before.brigadeFk, after.brigadeFk, { it.brigadeId }) { "BRIGADE_FK:${it.brigadeId}" }
        addChanged(changed, before.workerDays, after.workerDays, { "${it.workerId}|${it.date}" }) { "WORKER_DAY:${it.workerId}|${it.date}" }
        addChanged(changed, before.brigadeDays, after.brigadeDays, { "${it.brigadeId}|${it.date}" }) { "BRIGADE_DAY:${it.brigadeId}|${it.date}" }
        addChanged(changed, before.qualityRounds, after.qualityRounds, { "${it.workerId}|${it.date}|${it.round}" }) { "QUALITY_ROUND:${it.workerId}|${it.date}|${it.round}" }
        addChanged(changed, before.dailyIssues, after.dailyIssues, { it.id }) { "DAILY_ISSUE:${it.id}" }
        val afterIssues = after.dailyIssues.associateBy { it.id }
        before.dailyIssues.filter { afterIssues[it.id] == null }.forEach { changed += "DAILY_ISSUE_DELETE:${it.id}" }
        val oldAudit = before.auditLog.associateBy { it.id }
        after.auditLog.filter { oldAudit[it.id] != it }.forEach { changed += "AUDIT:${it.id}" }
        if (before.workHours != after.workHours || before.efficiencyNorm != after.efficiencyNorm ||
            before.roundTimes != after.roundTimes || before.monitoringWeights != after.monitoringWeights ||
            before.preparedYears != after.preparedYears
        ) changed += "SETTINGS:assembly"
        touch(changed)
    }

    @Synchronized
    fun markAll(data: AssemblyData) {
        val changed = linkedSetOf<String>()
        data.brigades.forEach { changed += "BRIGADE:${it.id}" }
        data.workers.forEach { changed += "WORKER:${it.id}" }
        data.products.forEach { changed += "PRODUCT:${it.id}" }
        data.brigadeFk.forEach { changed += "BRIGADE_FK:${it.brigadeId}" }
        data.workerDays.forEach { changed += "WORKER_DAY:${it.workerId}|${it.date}" }
        data.brigadeDays.forEach { changed += "BRIGADE_DAY:${it.brigadeId}|${it.date}" }
        data.qualityRounds.forEach { changed += "QUALITY_ROUND:${it.workerId}|${it.date}|${it.round}" }
        data.dailyIssues.forEach { changed += "DAILY_ISSUE:${it.id}" }
        data.auditLog.forEach { changed += "AUDIT:${it.id}" }
        changed += "SETTINGS:assembly"
        touch(changed)
    }

    @Synchronized fun pending(): Set<String> = prefs.getStringSet(KEY_PENDING, emptySet()).orEmpty().toSet()
    @Synchronized fun snapshot(): Map<String, Long> {
        val revisions = revisions()
        return pending().associateWith { revisions[it] ?: 0L }
    }
    @Synchronized fun removeIfUnchanged(key: String, expectedRevision: Long) {
        val revisions = revisions().toMutableMap()
        if ((revisions[key] ?: 0L) != expectedRevision) return
        val keys = pending().toMutableSet().apply { remove(key) }
        revisions.remove(key)
        save(keys, revisions)
    }
    @Synchronized fun remove(key: String) {
        val keys = pending().toMutableSet().apply { remove(key) }
        val revisions = revisions().toMutableMap().apply { remove(key) }
        save(keys, revisions)
    }
    @Synchronized fun isEmpty(): Boolean = pending().isEmpty()
    @Synchronized fun clear() = save(emptySet(), emptyMap())

    private fun touch(changed: Set<String>) {
        if (changed.isEmpty()) return
        val keys = pending().toMutableSet()
        val revisions = revisions().toMutableMap()
        var counter = prefs.getLong(KEY_COUNTER, 0L)
        changed.forEach { key -> counter += 1L; keys += key; revisions[key] = counter }
        prefs.edit().putLong(KEY_COUNTER, counter).apply()
        save(keys, revisions)
    }

    private fun revisions(): Map<String, Long> {
        val json = runCatching { JSONObject(prefs.getString(KEY_REVISIONS, "{}").orEmpty()) }.getOrElse { JSONObject() }
        return buildMap { json.keys().forEach { key -> put(key, json.optLong(key, 0L)) } }
    }

    private fun save(keys: Set<String>, revisions: Map<String, Long>) {
        val json = JSONObject().apply { revisions.forEach { (key, value) -> put(key, value) } }
        prefs.edit().putStringSet(KEY_PENDING, keys).putString(KEY_REVISIONS, json.toString()).commit()
        SyncOutboxEvents.notifyChanged()
    }

    private fun <T, K> addChanged(
        target: MutableSet<String>, before: List<T>, after: List<T>, key: (T) -> K, encode: (T) -> String
    ) {
        val old = before.associateBy(key)
        after.filter { old[key(it)] != it }.forEach { target += encode(it) }
    }

    companion object {
        private const val PREFS = "toy_bola_sync_outbox"
        private const val KEY_PENDING = "pending"
        private const val KEY_REVISIONS = "pending_revisions_v2"
        private const val KEY_COUNTER = "pending_revision_counter_v2"
    }
}
