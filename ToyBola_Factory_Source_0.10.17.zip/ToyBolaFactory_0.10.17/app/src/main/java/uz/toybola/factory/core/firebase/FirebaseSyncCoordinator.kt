package uz.toybola.factory.core.firebase

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.core.notifications.NotificationScheduler
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.canReadAnyTp

class FirebaseSyncCoordinator(context: Context) {
    private val appContext = context.applicationContext
    private val repository = AssemblyDataRepository(appContext)
    private val outbox = AssemblySyncOutbox(appContext)
    private val policyCache = ServerPolicyCache(appContext)
    private val preferences = AppPreferences(appContext)
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()
    private val functions = FirebaseFunctions.getInstance("europe-west1")
    private val syncStatus = SyncStatusStore(appContext)
    private val migrationState = ServerMigrationState(appContext)

    suspend fun syncNow(): Result<Unit> = syncMutex.withLock {
        syncStatus.markSyncing()
        val result = runCatching {
            val user = auth.currentUser ?: return@runCatching
            val setup = preferences.setup() ?: error("Qurilma sozlamasi topilmadi")
            val cachedBefore = policyCache.load(setup.userCode)
            val policy = ServerAuthRepository(appContext).refreshPolicy().getOrNull()
                ?: cachedBefore
                ?: error("Server ruxsati topilmadi")
            if (cachedBefore != null && policy.revision != cachedBefore.revision) ServerPolicyEvents.notifyChanged()
            require(policy.uid.isBlank() || policy.uid == user.uid) { "Server sessiyasi boshqa foydalanuvchiga tegishli" }

            val tpOutbox = TpSyncOutbox(appContext)
            pruneUnauthorizedAssemblyKeys(policy, repository.load())
            var firstSyncError: Throwable? = null
            // Assembly and TP are independent queues. A temporary problem in one area must not
            // block valid writes in the other area (this was another source of a permanently
            // growing Pending counter). Each manual/background sync drains up to three generations.
            for (pass in 0 until 3) {
                val assemblyPass = runCatching {
                    val dirtyBefore = outbox.snapshot()
                    flushOutbox(user.uid, dirtyBefore)
                    val snapshot = ServerSnapshotRepository(appContext).download().getOrThrow()
                    val remote = Pulled(snapshot.data, snapshot.hasSettings)
                    val protected = dirtyBefore.keys + outbox.pending()
                    val merged = mergeIntoLocal(repository.load(), remote.data, remote.hasSettings, policy, protected)
                    repository.replaceFromServer(merged)
                }
                if (assemblyPass.isFailure && firstSyncError == null) firstSyncError = assemblyPass.exceptionOrNull()

                val tpPass = if (policy.canReadAnyTp()) {
                    runCatching { TpSyncCoordinator(appContext).sync(policy, user.uid) }
                } else Result.success(Unit)
                if (tpPass.isFailure && firstSyncError == null) firstSyncError = tpPass.exceptionOrNull()

                if (outbox.isEmpty() && (!policy.canReadAnyTp() || tpOutbox.isEmpty())) break
                // If neither domain could make a network pass, let WorkManager backoff instead of
                // hammering the same failing endpoint three times in the same second.
                if (assemblyPass.isFailure && tpPass.isFailure) break
            }
            val stillPending = !outbox.isEmpty() || (policy.canReadAnyTp() && !tpOutbox.isEmpty())
            if (stillPending) FirebaseSyncScheduler.enqueue(appContext)
            NotificationScheduler.scheduleUpcoming(appContext, repository)
            if (firstSyncError != null && stillPending) throw firstSyncError!!
        }
        result.onSuccess { syncStatus.markSuccess() }
            .onFailure { error -> syncStatus.markFailure(error.message ?: error.javaClass.simpleName) }
        result
    }


    /**
     * Old app versions could leave a legacy key in Pending after the user's role/scope changed.
     * One permanently forbidden key must never block every valid write behind it. Keys that the
     * current server policy is not allowed to write are discarded from the upload queue; the
     * subsequent authoritative pull restores the server value for that record.
     */
    private fun pruneUnauthorizedAssemblyKeys(policy: UserAccessPolicy, data: AssemblyData) {
        if (policy.isAdmin()) return
        val snapshot = outbox.snapshot()
        snapshot.forEach { (key, revision) ->
            val prefix = key.substringBefore(':')
            val id = key.substringAfter(':', "")
            val permitted = when (prefix) {
                "BRIGADE", "WORKER", "PRODUCT", "BRIGADE_FK", "SETTINGS" -> policy.canWrite(AssemblySection.MASTER_DATA)
                "WORKER_DAY" -> policy.canWrite(AssemblySection.BRIGADIR)
                "BRIGADE_DAY" -> policy.canWrite(AssemblySection.BRIGADIR) || policy.canWrite(AssemblySection.QUALITY)
                "QUALITY_ROUND" -> policy.canWrite(AssemblySection.QUALITY)
                "DAILY_ISSUE", "DAILY_ISSUE_DELETE" -> policy.canWrite(AssemblySection.DAILY_ISSUE)
                "AUDIT" -> policy.canWrite(AssemblySection.BRIGADIR) || policy.canWrite(AssemblySection.QUALITY) ||
                    policy.canWrite(AssemblySection.DAILY_ISSUE) || policy.canWrite(AssemblySection.MASTER_DATA)
                else -> false
            }
            val brigadeId: String? = when (prefix) {
                "BRIGADE", "BRIGADE_FK" -> id.ifBlank { null }
                "WORKER" -> data.workers.firstOrNull { it.id == id }?.brigadeId
                "PRODUCT" -> data.products.firstOrNull { it.id == id }?.brigadeId
                "WORKER_DAY" -> {
                    val parts = id.split('|'); data.workerDays.firstOrNull { parts.size == 2 && it.workerId == parts[0] && it.date == parts[1] }?.brigadeId
                }
                "BRIGADE_DAY" -> id.substringBefore('|').ifBlank { null }
                "QUALITY_ROUND" -> data.qualityRounds.firstOrNull { row ->
                    val parts = id.split('|'); parts.size == 3 && row.workerId == parts[0] && row.date == parts[1] && row.round == parts[2].toIntOrNull()
                }?.brigadeId
                "DAILY_ISSUE" -> data.dailyIssues.firstOrNull { it.id == id }?.brigadeId
                "AUDIT" -> data.auditLog.firstOrNull { it.id == id }?.brigadeId
                else -> null
            }
            if (!permitted || (brigadeId != null && !policy.canAccessBrigade(brigadeId))) {
                outbox.removeIfUnchanged(key, revision)
            }
        }
    }

    private suspend fun flushOutbox(uid: String, snapshot: Map<String, Long>) {
        val keys = snapshot.keys.sorted()
        if (keys.isEmpty()) return
        val payload = repository.encodeForSync(repository.load())
        keys.chunked(180).forEach { chunk ->
            val response = functions.getHttpsCallable("applyAssemblyWrites")
                .call(mapOf("keys" to chunk, "payload" to payload, "clientVersion" to "0.10.17"))
                .awaitResult()
            @Suppress("UNCHECKED_CAST")
            val body = response.data as? Map<String, Any?> ?: error("Server sync javobi noto‘g‘ri")
            @Suppress("UNCHECKED_CAST")
            val applied = (body["applied"] as? List<*>)?.mapNotNull { it?.toString() }.orEmpty()
            if (applied.isEmpty() && chunk.isNotEmpty()) error("Server sync hech bir yozuvni qabul qilmadi")
            applied.forEach { key -> outbox.removeIfUnchanged(key, snapshot[key] ?: 0L) }
        }
    }

    private fun applyOutboxKey(
        batch: com.google.firebase.firestore.WriteBatch,
        key: String,
        data: AssemblyData,
        uid: String
    ): Boolean {
        val prefix = key.substringBefore(':')
        val id = key.substringAfter(':', "")
        fun common(payload: String, brigadeId: String? = null, date: String? = null): MutableMap<String, Any> = mutableMapOf<String, Any>(
            "payload" to payload,
            "updatedAt" to FieldValue.serverTimestamp(),
            "updatedBy" to uid
        ).apply {
            brigadeId?.let { put("brigadeId", it) }
            date?.let { put("date", it) }
        }

        when (prefix) {
            "BRIGADE" -> {
                val item = data.brigades.firstOrNull { it.id == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(brigades = listOf(item)))
                batch.set(db.collection("brigades").document(item.id), common(payload, item.id).apply {
                    put("name", item.name); put("archived", item.archived); put("deleted", item.deleted)
                }, SetOptions.merge())
            }
            "WORKER" -> {
                val item = data.workers.firstOrNull { it.id == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(workers = listOf(item)))
                batch.set(db.collection("workers").document(item.id), common(payload, item.brigadeId).apply {
                    put("name", item.name); put("archived", item.archived); put("startDate", item.startDate)
                }, SetOptions.merge())
            }
            "PRODUCT" -> {
                val item = data.products.firstOrNull { it.id == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(products = listOf(item)))
                batch.set(db.collection("products").document(item.id), common(payload, item.brigadeId).apply {
                    put("article", item.article); put("name", item.name); put("archived", item.archived)
                }, SetOptions.merge())
            }
            "BRIGADE_FK" -> {
                val item = data.brigadeFk.firstOrNull { it.brigadeId == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(brigadeFk = listOf(item)))
                batch.set(db.collection("brigadeFk").document(item.brigadeId), common(payload, item.brigadeId), SetOptions.merge())
            }
            "WORKER_DAY" -> {
                val parts = id.split('|')
                if (parts.size != 2) return false
                val item = data.workerDays.firstOrNull { it.workerId == parts[0] && it.date == parts[1] } ?: return false
                val payload = repository.encodeForSync(AssemblyData(workerDays = listOf(item)))
                batch.set(db.collection("workerDays").document("${item.workerId}_${item.date}"), common(payload, item.brigadeId, item.date).apply {
                    put("workerId", item.workerId); put("worked", item.worked); put("hours", item.hours); put("earned", item.earned)
                }, SetOptions.merge())
            }
            "BRIGADE_DAY" -> {
                val parts = id.split('|')
                if (parts.size != 2) return false
                val item = data.brigadeDays.firstOrNull { it.brigadeId == parts[0] && it.date == parts[1] } ?: return false
                // BrigadeDay is intentionally stored as structured fields instead of an opaque payload.
                // This lets Firestore Security Rules enforce Brigadir-vs-Quality field ownership.
                val document = mutableMapOf<String, Any>(
                    "brigadeId" to item.brigadeId,
                    "date" to item.date,
                    "worked" to item.worked,
                    "brigadirClosed" to item.brigadirClosed,
                    "brigadirClosedAt" to item.brigadirClosedAt.orEmpty(),
                    "brigadirLateReason" to item.brigadirLateReason,
                    "qualityClosed" to item.qualityClosed,
                    "qualityClosedAt" to item.qualityClosedAt.orEmpty(),
                    "qualityLateReason" to item.qualityLateReason,
                    "fullyClosed" to item.fullyClosed,
                    "closedAt" to item.closedAt.orEmpty(),
                    "reopenCount" to item.reopenCount,
                    "lastReopenedAt" to item.lastReopenedAt.orEmpty(),
                    "lastReopenReason" to item.lastReopenReason,
                    "updatedAt" to FieldValue.serverTimestamp(),
                    "updatedBy" to uid
                )
                batch.set(db.collection("brigadeDays").document("${item.brigadeId}_${item.date}"), document, SetOptions.merge())
            }
            "QUALITY_ROUND" -> {
                val parts = id.split('|')
                if (parts.size != 3) return false
                val item = data.qualityRounds.firstOrNull { it.workerId == parts[0] && it.date == parts[1] && it.round == parts[2].toIntOrNull() } ?: return false
                val payload = repository.encodeForSync(AssemblyData(qualityRounds = listOf(item)))
                batch.set(db.collection("qualityRounds").document("${item.workerId}_${item.date}_${item.round}"), common(payload, item.brigadeId, item.date).apply {
                    put("workerId", item.workerId)
                    put("round", item.round)
                    put("finished", item.isFinished)
                    put("absenceType", item.absenceType)
                    put("absenceReason", item.absenceReason)
                    put("absenceAt", item.absenceAt.orEmpty())
                    item.grade?.let { put("grade", it) }
                    item.score?.let { put("score", it) }
                }, SetOptions.merge())
            }
            "DAILY_ISSUE" -> {
                val item = data.dailyIssues.firstOrNull { it.id == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(dailyIssues = listOf(item)))
                batch.set(db.collection("dailyIssues").document(item.id), common(payload, item.brigadeId, item.date).apply {
                    put("productId", item.productId); put("article", item.articleSnapshot); put("productName", item.productNameSnapshot)
                    put("stageId", item.stageId); put("stageName", item.stageNameSnapshot); put("note", item.note); put("createdAtText", item.createdAt)
                    put("imageUrl", item.imageUrl); put("imagePath", item.imagePath)
                }, SetOptions.merge())
            }
            "DAILY_ISSUE_DELETE" -> batch.delete(db.collection("dailyIssues").document(id))
            "AUDIT" -> {
                val item = data.auditLog.firstOrNull { it.id == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(auditLog = listOf(item)))
                batch.set(db.collection("auditLog").document(item.id), common(payload, item.brigadeId, item.recordDate).apply {
                    put("action", item.action); put("dateTime", item.dateTime); put("details", item.details)
                }, SetOptions.merge())
            }
            "SETTINGS" -> {
                val payload = repository.encodeForSync(AssemblyData(
                    workHours = data.workHours,
                    efficiencyNorm = data.efficiencyNorm,
                    roundTimes = data.roundTimes,
                    monitoringWeights = data.monitoringWeights,
                    preparedYears = data.preparedYears
                ))
                batch.set(db.collection("settings").document("assembly"), common(payload), SetOptions.merge())
            }
            else -> return false
        }
        return true
    }

    private data class Pulled(val data: AssemblyData, val hasSettings: Boolean)

    private suspend fun pullRemote(policy: UserAccessPolicy): Pulled {
        val brigadeDocs = if (policy.allowedBrigadeIds == null) {
            db.collection("brigades").get().awaitResult().documents
        } else {
            policy.allowedBrigadeIds.mapNotNull { brigadeId ->
                val document = db.collection("brigades").document(brigadeId).get().awaitResult()
                if (document.exists()) document else null
            }
        }
        val brigades = brigadeDocs.mapNotNull { document ->
            decodePayload(document)?.brigades?.firstOrNull()
                ?: document.getString("name")?.let { name ->
                    Brigade(
                        id = document.id,
                        name = name,
                        archived = document.getBoolean("archived") ?: false,
                        deleted = document.getBoolean("deleted") ?: false
                    )
                }
        }

        // IMPORTANT: even Admin reads brigade-scoped collections one brigade at a time.
        // Firestore list queries are all-or-nothing against Security Rules. One old/legacy
        // document without a structured brigadeId can make an unrestricted collection get()
        // fail and leave a freshly installed Admin client completely empty. Querying each
        // known brigade explicitly also fixes the dailyIssues Admin-refresh regression while
        // keeping Brigadir/Quality limited to their allowed brigade IDs.
        val scopeBrigadeIds = (policy.allowedBrigadeIds ?: brigadeDocs.map { it.id }.toSet())
            .filter { it.isNotBlank() }
            .toSet()

        val workers = decodeScoped("workers", scopeBrigadeIds) { it.workers }
        val products = decodeScoped("products", scopeBrigadeIds) { it.products }
        val fk = decodeScoped("brigadeFk", scopeBrigadeIds) { it.brigadeFk }
        val workerDays = decodeScoped("workerDays", scopeBrigadeIds) { it.workerDays }
        val brigadeDays = pullBrigadeDays(scopeBrigadeIds)
        val qualityRounds = decodeScoped("qualityRounds", scopeBrigadeIds) { it.qualityRounds }
        val dailyIssues = decodeScoped("dailyIssues", scopeBrigadeIds) { it.dailyIssues }
        val audit = if (policy.isAdmin()) {
            // Audit is useful but must never block a full bootstrap. Legacy audit rows can have
            // an older schema that makes an unrestricted Rules query fail.
            val docs = runCatching {
                db.collection("auditLog").limit(1000).get().awaitResult().documents
            }.getOrDefault(emptyList())
            decodeDocs(docs) { it.auditLog }
        } else {
            decodeScoped("auditLog", scopeBrigadeIds) { it.auditLog }
        }
        val settingsDoc = db.collection("settings").document("assembly").get().awaitResult()
        val settings = if (settingsDoc.exists()) decodePayload(settingsDoc) else null

        return Pulled(
            AssemblyData(
                brigades = brigades,
                workers = workers,
                products = products,
                brigadeFk = fk,
                workHours = settings?.workHours.orEmpty(),
                efficiencyNorm = settings?.efficiencyNorm.orEmpty(),
                roundTimes = settings?.roundTimes.orEmpty(),
                monitoringWeights = settings?.monitoringWeights.orEmpty(),
                preparedYears = settings?.preparedYears.orEmpty(),
                workerDays = workerDays,
                brigadeDays = brigadeDays,
                qualityRounds = qualityRounds,
                dailyIssues = dailyIssues,
                auditLog = audit
            ),
            settingsDoc.exists()
        )
    }


    private suspend fun pullBrigadeDays(brigadeIds: Set<String>): List<BrigadeDay> {
        val docs = buildList {
            brigadeIds.forEach { brigadeId ->
                addAll(db.collection("brigadeDays").whereEqualTo("brigadeId", brigadeId).get().awaitResult().documents)
            }
        }
        return docs.mapNotNull { doc ->
            val brigadeId = doc.getString("brigadeId") ?: return@mapNotNull null
            val date = doc.getString("date") ?: return@mapNotNull null
            BrigadeDay(
                brigadeId = brigadeId,
                date = date,
                worked = doc.getBoolean("worked") ?: true,
                brigadirClosedAt = doc.getString("brigadirClosedAt")?.ifBlank { null },
                brigadirLateReason = doc.getString("brigadirLateReason").orEmpty(),
                qualityClosedAt = doc.getString("qualityClosedAt")?.ifBlank { null },
                qualityLateReason = doc.getString("qualityLateReason").orEmpty(),
                closedAt = doc.getString("closedAt")?.ifBlank { null },
                reopenCount = (doc.getLong("reopenCount") ?: 0L).toInt(),
                lastReopenedAt = doc.getString("lastReopenedAt")?.ifBlank { null },
                lastReopenReason = doc.getString("lastReopenReason").orEmpty()
            )
        }
    }

    private suspend fun <T> decodeScoped(collection: String, brigadeIds: Set<String>, extract: (AssemblyData) -> List<T>): List<T> {
        if (brigadeIds.isEmpty()) return emptyList()
        val docs = buildList {
            brigadeIds.forEach { brigadeId ->
                addAll(db.collection(collection).whereEqualTo("brigadeId", brigadeId).get().awaitResult().documents)
            }
        }
        return decodeDocs(docs, extract)
    }

    private fun <T> decodeDocs(docs: List<DocumentSnapshot>, extract: (AssemblyData) -> List<T>): List<T> =
        docs.mapNotNull { document -> decodePayload(document) }.flatMap(extract)

    private fun decodePayload(doc: DocumentSnapshot): AssemblyData? {
        val payload = doc.getString("payload") ?: return null
        return runCatching { repository.decodeForSync(payload) }.getOrNull()
    }

    private fun mergeIntoLocal(
        local: AssemblyData,
        remote: AssemblyData,
        hasSettings: Boolean,
        policy: UserAccessPolicy,
        localDirtyKeys: Set<String>
    ): AssemblyData {
        fun dirty(prefix: String): Set<String> = localDirtyKeys.filter { it.startsWith("$prefix:") }.map { it.substringAfter(':') }.toSet()
        fun <T> mergeById(localItems: List<T>, remoteItems: List<T>, id: (T) -> String, localWins: Set<String> = emptySet(), deleted: Set<String> = emptySet()): List<T> {
            if (remoteItems.isEmpty() && localItems.isNotEmpty()) return localItems.filter { id(it) !in deleted }
            val map = LinkedHashMap<String, T>()
            localItems.forEach { if (id(it) !in deleted) map[id(it)] = it }
            remoteItems.forEach { item -> val key = id(item); if (key !in localWins && key !in deleted) map[key] = item }
            return map.values.toList()
        }
        val issueDeletes = dirty("DAILY_ISSUE_DELETE")
        return local.copy(
            brigades = mergeById(local.brigades, remote.brigades, { it.id }, dirty("BRIGADE")),
            workers = mergeById(local.workers, remote.workers, { it.id }, dirty("WORKER")),
            products = mergeById(local.products, remote.products, { it.id }, dirty("PRODUCT")),
            brigadeFk = mergeById(local.brigadeFk, remote.brigadeFk, { it.brigadeId }, dirty("BRIGADE_FK")),
            workHours = if (hasSettings && "SETTINGS:assembly" !in localDirtyKeys) remote.workHours.ifEmpty { local.workHours } else local.workHours,
            efficiencyNorm = if (hasSettings && "SETTINGS:assembly" !in localDirtyKeys) remote.efficiencyNorm.ifEmpty { local.efficiencyNorm } else local.efficiencyNorm,
            roundTimes = if (hasSettings && "SETTINGS:assembly" !in localDirtyKeys) remote.roundTimes.ifEmpty { local.roundTimes } else local.roundTimes,
            monitoringWeights = if (hasSettings && "SETTINGS:assembly" !in localDirtyKeys) remote.monitoringWeights.ifEmpty { local.monitoringWeights } else local.monitoringWeights,
            preparedYears = if (hasSettings && "SETTINGS:assembly" !in localDirtyKeys) remote.preparedYears.ifEmpty { local.preparedYears } else local.preparedYears,
            workerDays = mergeById(local.workerDays, remote.workerDays, { "${it.workerId}|${it.date}" }, dirty("WORKER_DAY")),
            brigadeDays = mergeById(local.brigadeDays, remote.brigadeDays, { "${it.brigadeId}|${it.date}" }, dirty("BRIGADE_DAY")),
            qualityRounds = mergeById(local.qualityRounds, remote.qualityRounds, { "${it.workerId}|${it.date}|${it.round}" }, dirty("QUALITY_ROUND")),
            dailyIssues = if (migrationState.recoveryInProgress())
                mergeById(local.dailyIssues, remote.dailyIssues, { it.id }, dirty("DAILY_ISSUE"), issueDeletes)
            else mergeById(local.dailyIssues, remote.dailyIssues, { it.id }, dirty("DAILY_ISSUE"), issueDeletes),
            auditLog = mergeById(local.auditLog, remote.auditLog, { it.id }, dirty("AUDIT")).takeLast(2000)
        )
    }

    companion object {
        private val syncMutex = Mutex()
    }

}
