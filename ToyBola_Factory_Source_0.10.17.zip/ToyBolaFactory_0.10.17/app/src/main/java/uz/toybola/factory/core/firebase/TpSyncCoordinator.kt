package uz.toybola.factory.core.firebase

import android.content.Context
import com.google.firebase.functions.FirebaseFunctions
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy

class TpSyncCoordinator(context: Context) {
    private val appContext = context.applicationContext
    private val repository = TpDataRepository(appContext)
    private val outbox = TpSyncOutbox(appContext)
    private val functions = FirebaseFunctions.getInstance("europe-west1")

    suspend fun sync(policy: UserAccessPolicy, uid: String) {
        pruneUnauthorizedKeys(policy, repository.load())
        // Capture exact generations before upload. New edits that happen while this pass is running
        // receive a newer generation and therefore cannot be acknowledged/erased by this pass.
        val dirtyBefore = outbox.snapshot()
        flushOutbox(dirtyBefore)

        val snapshot = ServerTpSnapshotRepository(appContext).download().getOrThrow()
        if (!snapshot.hasData && policy.isAdmin()) {
            outbox.markAll(repository.load())
            flushOutbox(outbox.snapshot())
            return
        }

        // Protect both the values uploaded by this pass and any newer edits created while the
        // server call/snapshot was in flight. This is the key fix for "tasdiqlash ortga qaytdi".
        val protectedKeys = dirtyBefore.keys + outbox.pending()
        repository.replaceFromServer(merge(repository.load(), snapshot.data, snapshot.hasSettings, protectedKeys))
    }


    private fun pruneUnauthorizedKeys(policy: UserAccessPolicy, data: TpData) {
        if (policy.isAdmin()) return
        val snapshot = outbox.snapshot()
        fun any(vararg section: AssemblySection) = section.any { policy.canWrite(it) }
        snapshot.forEach { (key, revision) ->
            val prefix = key.substringBefore(':')
            val id = key.substringAfter(':', "")
            val permitted = when (prefix) {
                "TP_SHOP", "TP_SHIFT", "TP_BRIGADE", "TP_MACHINE", "TP_WORKER", "TP_PRODUCT", "TP_SETTINGS" -> any(AssemblySection.TP_MASTER_DATA)
                "TP_MATERIAL" -> any(AssemblySection.TP_MASTER_DATA, AssemblySection.TP_SERYO)
                "TP_ORDER" -> any(AssemblySection.TP_ORDER, AssemblySection.TP_PLANNING, AssemblySection.TP_MACHINE, AssemblySection.TP_RECEIVING)
                "TP_ORDER_DELETE" -> any(AssemblySection.TP_ORDER)
                "TP_JOB" -> any(AssemblySection.TP_PLANNING, AssemblySection.TP_MACHINE, AssemblySection.TP_SERYO, AssemblySection.TP_RECEIVING)
                "TP_JOB_DELETE" -> any(AssemblySection.TP_ORDER, AssemblySection.TP_PLANNING)
                "TP_ATTENDANCE" -> any(AssemblySection.TP_ATTENDANCE)
                "TP_RECEIPT", "TP_RECEIPT_DELETE" -> any(AssemblySection.TP_RECEIVING)
                "TP_QUALITY", "TP_ISSUE" -> any(AssemblySection.TP_QUALITY)
                "TP_DOWNTIME" -> any(AssemblySection.TP_MACHINE)
                "TP_AUDIT" -> any(
                    AssemblySection.TP_ORDER, AssemblySection.TP_PLANNING, AssemblySection.TP_MACHINE,
                    AssemblySection.TP_ATTENDANCE, AssemblySection.TP_SERYO, AssemblySection.TP_RECEIVING,
                    AssemblySection.TP_QUALITY, AssemblySection.TP_MASTER_DATA
                )
                else -> false
            }
            val brigadeId: String? = when (prefix) {
                "TP_BRIGADE" -> id.ifBlank { null }
                "TP_WORKER" -> data.workers.firstOrNull { it.id == id }?.brigadeId
                "TP_JOB" -> data.jobs.firstOrNull { it.id == id }?.brigadeId
                "TP_ATTENDANCE" -> data.attendance.firstOrNull { it.id == id }?.brigadeId
                "TP_RECEIPT" -> data.receipts.firstOrNull { it.id == id }?.brigadeId
                "TP_QUALITY" -> data.qualityRounds.firstOrNull { it.id == id }?.brigadeId
                "TP_ISSUE" -> data.dailyIssues.firstOrNull { it.id == id }?.brigadeId
                "TP_DOWNTIME" -> data.machineDowntimes.firstOrNull { it.id == id }?.brigadeId
                "TP_AUDIT" -> data.auditLog.firstOrNull { it.id == id }?.brigadeId
                else -> null
            }
            if (!permitted || (brigadeId != null && !policy.canAccessBrigade(brigadeId))) {
                outbox.removeIfUnchanged(key, revision)
            }
        }
    }

    private suspend fun flushOutbox(snapshot: Map<String, Long>) {
        val keys = snapshot.keys.sorted()
        if (keys.isEmpty()) return
        // The server receives one consistent local payload for this upload generation.
        val payload = repository.encodeForSync(repository.load())
        keys.chunked(180).forEach { chunk ->
            val response = functions.getHttpsCallable("applyTpWrites")
                .call(mapOf("keys" to chunk, "payload" to payload, "clientVersion" to "0.10.17"))
                .awaitResult()
            @Suppress("UNCHECKED_CAST")
            val body = response.data as? Map<String, Any?> ?: error("TP server sync javobi noto‘g‘ri")
            @Suppress("UNCHECKED_CAST")
            val applied = (body["applied"] as? List<*>)?.mapNotNull { it?.toString() }.orEmpty()
            if (applied.isEmpty() && chunk.isNotEmpty()) error("TP server sync hech bir yozuvni qabul qilmadi")
            applied.forEach { key -> outbox.removeIfUnchanged(key, snapshot[key] ?: 0L) }
        }
    }

    private fun merge(local: TpData, remote: TpData, hasSettings: Boolean, localDirtyKeys: Set<String>): TpData {
        fun dirty(prefix: String): Set<String> = localDirtyKeys.filter { it.startsWith("$prefix:") }.map { it.substringAfter(':') }.toSet()
        fun deleted(prefix: String): Set<String> = dirty("${prefix}_DELETE")
        return local.copy(
            shops = mergeById(local.shops, remote.shops, { it.id }, dirty("TP_SHOP")),
            shifts = mergeById(local.shifts, remote.shifts, { it.id }, dirty("TP_SHIFT")),
            brigades = mergeById(local.brigades, remote.brigades, { it.id }, dirty("TP_BRIGADE")),
            machines = mergeById(local.machines, remote.machines, { it.id }, dirty("TP_MACHINE")),
            workers = mergeById(local.workers, remote.workers, { it.id }, dirty("TP_WORKER")),
            products = mergeById(local.products, remote.products, { it.id }, dirty("TP_PRODUCT")),
            materials = mergeById(local.materials, remote.materials, { it.id }, dirty("TP_MATERIAL")),
            orders = mergeById(local.orders, remote.orders, { it.id }, dirty("TP_ORDER"), deleted("TP_ORDER")),
            jobs = mergeById(local.jobs, remote.jobs, { it.id }, dirty("TP_JOB"), deleted("TP_JOB")),
            attendance = mergeById(local.attendance, remote.attendance, { it.id }, dirty("TP_ATTENDANCE")),
            receipts = mergeById(local.receipts, remote.receipts, { it.id }, dirty("TP_RECEIPT"), deleted("TP_RECEIPT")),
            qualityRounds = mergeById(local.qualityRounds, remote.qualityRounds, { it.id }, dirty("TP_QUALITY")),
            dailyIssues = mergeById(local.dailyIssues, remote.dailyIssues, { it.id }, dirty("TP_ISSUE")),
            machineDowntimes = mergeById(local.machineDowntimes, remote.machineDowntimes, { it.id }, dirty("TP_DOWNTIME")),
            auditLog = mergeById(local.auditLog, remote.auditLog, { it.id }, dirty("TP_AUDIT")).takeLast(3000),
            settings = if (hasSettings && "TP_SETTINGS:tp" !in localDirtyKeys) remote.settings else local.settings
        )
    }

    private fun <T> mergeById(
        local: List<T>,
        remote: List<T>,
        id: (T) -> String,
        localWins: Set<String> = emptySet(),
        deletedIds: Set<String> = emptySet()
    ): List<T> {
        val values = LinkedHashMap<String, T>()
        local.forEach { if (id(it) !in deletedIds) values[id(it)] = it }
        remote.forEach { item ->
            val key = id(item)
            if (key !in deletedIds && key !in localWins) values[key] = item
        }
        return values.values.toList()
    }
}
