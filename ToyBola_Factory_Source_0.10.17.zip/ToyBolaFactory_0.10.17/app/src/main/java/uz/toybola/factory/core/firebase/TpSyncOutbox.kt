package uz.toybola.factory.core.firebase

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import uz.toybola.factory.core.data.TpData

object TpDataEvents {
    private val _revision = MutableStateFlow(0L)
    val revision: StateFlow<Long> = _revision.asStateFlow()
    fun notifyChanged() { _revision.value = _revision.value + 1L }
}

/**
 * Durable TP outbox with per-key generations.
 *
 * The old implementation stored only a Set<String>. If the same record was edited while a sync
 * was uploading its previous value, the running sync could remove that key after upload and then
 * pull an older server snapshot over the newer local edit. The result looked like the user's
 * selection/confirmation "went back" a few seconds later.
 *
 * Every local change now bumps that key's generation. A sync removes only the exact generation it
 * uploaded. A newer edit therefore stays pending and is protected from the server pull.
 */
class TpSyncOutbox(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun recordDiff(before: TpData, after: TpData) {
        val changed = linkedSetOf<String>()
        addChanged(changed, before.shops, after.shops, { it.id }) { "TP_SHOP:${it.id}" }
        addChanged(changed, before.shifts, after.shifts, { it.id }) { "TP_SHIFT:${it.id}" }
        addChanged(changed, before.brigades, after.brigades, { it.id }) { "TP_BRIGADE:${it.id}" }
        addChanged(changed, before.machines, after.machines, { it.id }) { "TP_MACHINE:${it.id}" }
        addChanged(changed, before.workers, after.workers, { it.id }) { "TP_WORKER:${it.id}" }
        addChanged(changed, before.products, after.products, { it.id }) { "TP_PRODUCT:${it.id}" }
        addChanged(changed, before.materials, after.materials, { it.id }) { "TP_MATERIAL:${it.id}" }
        addChanged(changed, before.orders, after.orders, { it.id }) { "TP_ORDER:${it.id}" }
        val afterOrders = after.orders.associateBy { it.id }
        before.orders.filter { afterOrders[it.id] == null }.forEach { changed += "TP_ORDER_DELETE:${it.id}" }
        addChanged(changed, before.jobs, after.jobs, { it.id }) { "TP_JOB:${it.id}" }
        val afterJobs = after.jobs.associateBy { it.id }
        before.jobs.filter { afterJobs[it.id] == null }.forEach { changed += "TP_JOB_DELETE:${it.id}" }
        addChanged(changed, before.attendance, after.attendance, { it.id }) { "TP_ATTENDANCE:${it.id}" }
        addChanged(changed, before.receipts, after.receipts, { it.id }) { "TP_RECEIPT:${it.id}" }
        val afterReceipts = after.receipts.associateBy { it.id }
        before.receipts.filter { afterReceipts[it.id] == null }.forEach { changed += "TP_RECEIPT_DELETE:${it.id}" }
        addChanged(changed, before.qualityRounds, after.qualityRounds, { it.id }) { "TP_QUALITY:${it.id}" }
        addChanged(changed, before.dailyIssues, after.dailyIssues, { it.id }) { "TP_ISSUE:${it.id}" }
        addChanged(changed, before.machineDowntimes, after.machineDowntimes, { it.id }) { "TP_DOWNTIME:${it.id}" }
        addChanged(changed, before.auditLog, after.auditLog, { it.id }) { "TP_AUDIT:${it.id}" }
        if (before.settings != after.settings) changed += "TP_SETTINGS:tp"
        touch(changed)
    }

    @Synchronized
    fun markAll(data: TpData) {
        val changed = linkedSetOf<String>()
        data.shops.forEach { changed += "TP_SHOP:${it.id}" }
        data.shifts.forEach { changed += "TP_SHIFT:${it.id}" }
        data.brigades.forEach { changed += "TP_BRIGADE:${it.id}" }
        data.machines.forEach { changed += "TP_MACHINE:${it.id}" }
        data.workers.forEach { changed += "TP_WORKER:${it.id}" }
        data.products.forEach { changed += "TP_PRODUCT:${it.id}" }
        data.materials.forEach { changed += "TP_MATERIAL:${it.id}" }
        data.orders.forEach { changed += "TP_ORDER:${it.id}" }
        data.jobs.forEach { changed += "TP_JOB:${it.id}" }
        data.attendance.forEach { changed += "TP_ATTENDANCE:${it.id}" }
        data.receipts.forEach { changed += "TP_RECEIPT:${it.id}" }
        data.qualityRounds.forEach { changed += "TP_QUALITY:${it.id}" }
        data.dailyIssues.forEach { changed += "TP_ISSUE:${it.id}" }
        data.machineDowntimes.forEach { changed += "TP_DOWNTIME:${it.id}" }
        data.auditLog.forEach { changed += "TP_AUDIT:${it.id}" }
        changed += "TP_SETTINGS:tp"
        touch(changed)
    }

    @Synchronized fun pending(): Set<String> = prefs.getStringSet(KEY, emptySet()).orEmpty().toSet()

    /** Stable key -> generation snapshot captured at the beginning of a sync pass. */
    @Synchronized
    fun snapshot(): Map<String, Long> {
        val pending = pending()
        val revisions = revisions()
        return pending.associateWith { revisions[it] ?: 0L }
    }

    /** Remove only if the key has not been edited since [expectedRevision] was captured. */
    @Synchronized
    fun removeIfUnchanged(key: String, expectedRevision: Long) {
        val revisions = revisions().toMutableMap()
        if ((revisions[key] ?: 0L) != expectedRevision) return
        val keys = pending().toMutableSet().apply { remove(key) }
        revisions.remove(key)
        save(keys, revisions)
    }

    @Synchronized fun remove(key: String) {
        val keys = pending().toMutableSet().apply { remove(key) }
        val revisions = revisions().toMutableMap().apply { remove(key) }
        save(keys, revisions)
    }
    @Synchronized fun isEmpty(): Boolean = pending().isEmpty()
    @Synchronized fun clear() = save(emptySet(), emptyMap())

    private fun touch(changed: Set<String>) {
        if (changed.isEmpty()) return
        val keys = pending().toMutableSet()
        val revisions = revisions().toMutableMap()
        var counter = prefs.getLong(KEY_COUNTER, 0L)
        changed.forEach { key ->
            counter += 1L
            keys += key
            revisions[key] = counter
        }
        prefs.edit().putLong(KEY_COUNTER, counter).apply()
        save(keys, revisions)
    }

    private fun revisions(): Map<String, Long> {
        val raw = prefs.getString(KEY_REVISIONS, "{}").orEmpty()
        val json = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
        return buildMap {
            json.keys().forEach { key -> put(key, json.optLong(key, 0L)) }
        }
    }

    private fun save(keys: Set<String>, revisions: Map<String, Long>) {
        val json = JSONObject().apply { revisions.forEach { (key, value) -> put(key, value) } }
        prefs.edit().putStringSet(KEY, keys).putString(KEY_REVISIONS, json.toString()).commit()
        SyncOutboxEvents.notifyChanged()
    }

    private fun <T, K> addChanged(
        target: MutableSet<String>, before: List<T>, after: List<T>, key: (T) -> K, encode: (T) -> String
    ) {
        val old = before.associateBy(key)
        after.filter { old[key(it)] != it }.forEach { target += encode(it) }
    }

    companion object {
        private const val PREFS = "toy_bola_tp_sync_outbox"
        private const val KEY = "pending"
        private const val KEY_REVISIONS = "pending_revisions_v2"
        private const val KEY_COUNTER = "pending_revision_counter_v2"
    }
}
