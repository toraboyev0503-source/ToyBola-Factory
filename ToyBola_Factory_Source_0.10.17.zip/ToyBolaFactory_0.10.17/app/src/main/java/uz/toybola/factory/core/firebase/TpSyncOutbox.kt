package uz.toybola.factory.core.firebase

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import uz.toybola.factory.core.data.TpData

object TpDataEvents {
    private val _revision = MutableStateFlow(0L)
    val revision: StateFlow<Long> = _revision.asStateFlow()
    fun notifyChanged() { _revision.value = _revision.value + 1L }
}

class TpSyncOutbox(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun recordDiff(before: TpData, after: TpData) {
        val keys = pending().toMutableSet()
        addChanged(keys, before.shops, after.shops, { it.id }) { "TP_SHOP:${it.id}" }
        addChanged(keys, before.shifts, after.shifts, { it.id }) { "TP_SHIFT:${it.id}" }
        addChanged(keys, before.brigades, after.brigades, { it.id }) { "TP_BRIGADE:${it.id}" }
        addChanged(keys, before.machines, after.machines, { it.id }) { "TP_MACHINE:${it.id}" }
        addChanged(keys, before.workers, after.workers, { it.id }) { "TP_WORKER:${it.id}" }
        addChanged(keys, before.products, after.products, { it.id }) { "TP_PRODUCT:${it.id}" }
        addChanged(keys, before.materials, after.materials, { it.id }) { "TP_MATERIAL:${it.id}" }
        addChanged(keys, before.orders, after.orders, { it.id }) { "TP_ORDER:${it.id}" }
        val afterOrders = after.orders.associateBy { it.id }
        before.orders.filter { afterOrders[it.id] == null }.forEach { keys += "TP_ORDER_DELETE:${it.id}" }
        addChanged(keys, before.jobs, after.jobs, { it.id }) { "TP_JOB:${it.id}" }
        val afterJobs = after.jobs.associateBy { it.id }
        before.jobs.filter { afterJobs[it.id] == null }.forEach { keys += "TP_JOB_DELETE:${it.id}" }
        addChanged(keys, before.attendance, after.attendance, { it.id }) { "TP_ATTENDANCE:${it.id}" }
        addChanged(keys, before.overtimeTypes, after.overtimeTypes, { it.id }) { "TP_OVERTIME_TYPE:${it.id}" }
        addChanged(keys, before.overtimeEntries, after.overtimeEntries, { it.id }) { "TP_OVERTIME:${it.id}" }
        val afterOvertime = after.overtimeEntries.associateBy { it.id }
        before.overtimeEntries.filter { afterOvertime[it.id] == null }.forEach { keys += "TP_OVERTIME_DELETE:${it.id}" }
        addChanged(keys, before.machineDowntimes, after.machineDowntimes, { it.id }) { "TP_DOWNTIME:${it.id}" }
        addChanged(keys, before.receipts, after.receipts, { it.id }) { "TP_RECEIPT:${it.id}" }
        val afterReceipts = after.receipts.associateBy { it.id }
        before.receipts.filter { afterReceipts[it.id] == null }.forEach { keys += "TP_RECEIPT_DELETE:${it.id}" }
        addChanged(keys, before.qualityRounds, after.qualityRounds, { it.id }) { "TP_QUALITY:${it.id}" }
        addChanged(keys, before.dailyIssues, after.dailyIssues, { it.id }) { "TP_ISSUE:${it.id}" }
        addChanged(keys, before.auditLog, after.auditLog, { it.id }) { "TP_AUDIT:${it.id}" }
        if (before.settings != after.settings) keys += "TP_SETTINGS:tp"
        save(keys)
    }

    @Synchronized
    fun markAll(data: TpData) {
        val keys = pending().toMutableSet()
        data.shops.forEach { keys += "TP_SHOP:${it.id}" }
        data.shifts.forEach { keys += "TP_SHIFT:${it.id}" }
        data.brigades.forEach { keys += "TP_BRIGADE:${it.id}" }
        data.machines.forEach { keys += "TP_MACHINE:${it.id}" }
        data.workers.forEach { keys += "TP_WORKER:${it.id}" }
        data.products.forEach { keys += "TP_PRODUCT:${it.id}" }
        data.materials.forEach { keys += "TP_MATERIAL:${it.id}" }
        data.orders.forEach { keys += "TP_ORDER:${it.id}" }
        data.jobs.forEach { keys += "TP_JOB:${it.id}" }
        data.attendance.forEach { keys += "TP_ATTENDANCE:${it.id}" }
        data.overtimeTypes.forEach { keys += "TP_OVERTIME_TYPE:${it.id}" }
        data.overtimeEntries.forEach { keys += "TP_OVERTIME:${it.id}" }
        data.machineDowntimes.forEach { keys += "TP_DOWNTIME:${it.id}" }
        data.receipts.forEach { keys += "TP_RECEIPT:${it.id}" }
        data.qualityRounds.forEach { keys += "TP_QUALITY:${it.id}" }
        data.dailyIssues.forEach { keys += "TP_ISSUE:${it.id}" }
        data.auditLog.forEach { keys += "TP_AUDIT:${it.id}" }
        keys += "TP_SETTINGS:tp"
        save(keys)
    }

    @Synchronized fun pending(): Set<String> = prefs.getStringSet(KEY, emptySet()).orEmpty().toSet()
    @Synchronized fun remove(key: String) = save(pending() - key)
    @Synchronized fun isEmpty(): Boolean = pending().isEmpty()
    @Synchronized fun clear() = save(emptySet())

    private fun save(keys: Set<String>) {
        prefs.edit().putStringSet(KEY, keys).apply()
        SyncOutboxEvents.notifyChanged()
    }

    private fun <T, K> addChanged(
        target: MutableSet<String>, before: List<T>, after: List<T>, key: (T) -> K, encode: (T) -> String
    ) {
        val old = before.associateBy(key)
        after.filter { old[key(it)] != it }.forEach { target += encode(it) }
    }

    companion object {
        private const val PREFS = "toy_bola_tp_sync_outbox"
        private const val KEY = "pending"
    }
}
