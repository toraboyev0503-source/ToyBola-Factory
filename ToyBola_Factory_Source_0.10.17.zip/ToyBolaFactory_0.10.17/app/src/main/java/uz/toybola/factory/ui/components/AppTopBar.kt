package uz.toybola.factory.ui.components

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import uz.toybola.factory.core.data.AssemblyDataRepository
import uz.toybola.factory.core.data.TpDataRepository
import uz.toybola.factory.core.firebase.AssemblyDataEvents
import uz.toybola.factory.core.firebase.AssemblySyncOutbox
import uz.toybola.factory.core.firebase.TpSyncOutbox
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.firebase.FirebaseSyncCoordinator
import uz.toybola.factory.core.firebase.FirebaseSyncScheduler
import uz.toybola.factory.core.firebase.SyncOutboxEvents
import uz.toybola.factory.core.firebase.SyncStatusEvents
import uz.toybola.factory.core.firebase.SyncStatusStore
import uz.toybola.factory.core.firebase.syncableRecordCount
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.ui.model.AppStrings
import uz.toybola.factory.ui.screens.SmartText

@Composable
fun AppTopBar(title: String, canGoBack: Boolean, onMenu: () -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repository = remember(context) { AssemblyDataRepository(context) }
    val tpRepository = remember(context) { TpDataRepository(context) }
    val outbox = remember(context) { AssemblySyncOutbox(context) }
    val tpOutbox = remember(context) { TpSyncOutbox(context) }
    val syncStatusStore = remember(context) { SyncStatusStore(context) }
    val dataRevision by AssemblyDataEvents.revision.collectAsState()
    val tpDataRevision by TpDataEvents.revision.collectAsState()
    val outboxRevision by SyncOutboxEvents.revision.collectAsState()
    val runtime by SyncStatusEvents.state.collectAsState()
    val syncStrings = AppStrings(AppPreferences(context).loadSettings().language)

    val localData = remember(dataRevision) { repository.load() }
    val localTpData = remember(tpDataRevision, outboxRevision) { tpRepository.load() }
    val pendingCount = remember(outboxRevision, dataRevision, tpDataRevision) { outbox.pending().size + tpOutbox.pending().size }
    val syncedCount = remember(localData, localTpData, pendingCount) {
        (localData.syncableRecordCount() + localTpData.syncableRecordCount() - pendingCount).coerceAtLeast(0)
    }

    // Opening any authenticated screen requests a fresh server pull. If the phone is offline,
    // WorkManager keeps the request until connectivity returns.
    LaunchedEffect(title) {
        FirebaseSyncScheduler.enqueue(context)
    }

    fun requestManualSync() {
        if (runtime.syncing) return
        if (!context.hasValidatedNetwork()) {
            syncStatusStore.markWaitingForNetwork()
            FirebaseSyncScheduler.enqueue(context)
            return
        }
        scope.launch { FirebaseSyncCoordinator(context).syncNow() }
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(shape = CircleShape, tonalElevation = 2.dp) {
                IconButton(onClick = if (canGoBack) onBack else onMenu) {
                    if (canGoBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = null
                        )
                    } else {
                        TwoLineMenuIcon()
                    }
                }
            }
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                SmartText(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.size(48.dp))
        }

        Box(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            contentAlignment = Alignment.CenterEnd
        ) {
            Surface(
                modifier = Modifier.clickable(enabled = !runtime.syncing, onClick = ::requestManualSync),
                shape = RoundedCornerShape(12.dp),
                tonalElevation = 1.dp
            ) {
                val text = when {
                    runtime.syncing -> "↻ ${syncStrings.syncing}"
                    runtime.waitingForNetwork -> "⌛ ${syncStrings.waitingNetwork} • ${syncStrings.pendingShort}: $pendingCount"
                    runtime.lastError.isNotBlank() -> "⚠ ${syncStrings.pendingShort}: $pendingCount"
                    else -> "✓ ${syncStrings.syncedShort}: $syncedCount  •  ↑ ${syncStrings.pendingShort}: $pendingCount"
                }
                SmartText(
                    text = text,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (runtime.lastError.isNotBlank()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.height(4.dp))
    }
}

private fun Context.hasValidatedNetwork(): Boolean {
    val manager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val network = manager.activeNetwork ?: return false
    val capabilities = manager.getNetworkCapabilities(network) ?: return false
    return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
}

@Composable
private fun TwoLineMenuIcon() {
    Column(
        modifier = Modifier.size(width = 22.dp, height = 14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        repeat(2) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .background(
                        color = MaterialTheme.colorScheme.onSurface,
                        shape = RoundedCornerShape(2.dp)
                    )
            )
        }
    }
}
