package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.AssemblyDataEvents
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate
import kotlin.math.roundToLong

@Composable
fun BrigadirScreen(
    strings: AppStrings,
    repository: AssemblyDataRepository,
    onBack: () -> Unit
) {
    var revision by remember { mutableIntStateOf(0) }
    val serverRevision by AssemblyDataEvents.revision.collectAsState()
    val context = LocalContext.current
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(revision, serverRevision, policy.revision) { repository.load().scopedFor(policy) }
    val today = remember { LocalDate.now().toString() }
    var date by remember { mutableStateOf(today) }
    val brigades = data.brigades.filterNot { it.archived }.sortedBy { it.name.lowercase() }
    var brigadeId by remember(brigades) { mutableStateOf(brigades.firstOrNull()?.id.orEmpty()) }
    var workerId by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var closeReasonOpen by remember { mutableStateOf(false) }
    var delayReasonOpen by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }

    fun refresh() { revision++ }
    BackHandler { if (workerId != null) workerId = null else onBack() }

    workerId?.let { id ->
        val worker = data.workers.firstOrNull { it.id == id }
        if (worker != null) {
            WorkerDayScreen(
                strings = strings,
                data = data,
                repository = repository,
                worker = worker,
                date = date,
                readOnly = data.brigadeDay(worker.brigadeId, date)?.brigadirClosed == true,
                onBack = { workerId = null },
                onChanged = ::refresh
            )
            return
        }
    }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(strings.brigadir, canGoBack = true, onMenu = {}, onBack = onBack)
        Column(
            Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("BrigadirScreen-screen-1")).navigationBarsPadding().padding(16.dp)
        ) {
            if (brigades.isEmpty()) {
                SmartText(strings.createBrigadeFirst, style = MaterialTheme.typography.bodyLarge)
                return@Column
            }
            BrigadeDropdown(strings, brigades, brigadeId) { brigadeId = it; date = today }
            Spacer(Modifier.height(10.dp))
            val outstanding = data.openBrigadirDates(brigadeId, today)
            if (outstanding.isNotEmpty()) {
                Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        SmartText("⚠ ${strings.unclosedDays}", fontWeight = FontWeight.Bold)
                        outstanding.takeLast(3).forEach { oldDate ->
                            TextButton(onClick = { date = oldDate }) { SmartText("$oldDate — ${strings.open}") }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                SmartText(if (date == today) "${strings.today}: $date" else date, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (date != today) TextButton(onClick = { date = today }) { SmartText(strings.today) }
            }
            Spacer(Modifier.height(10.dp))

            val closure = data.brigadeDay(brigadeId, date)
            val brigadirClosed = closure?.brigadirClosed == true
            val brigadeWorked = closure?.worked ?: true
            val deadlinePassed = runCatching { java.time.LocalDateTime.now().isAfter(LocalDate.parse(date).plusDays(1).atTime(9, 0)) }.getOrDefault(false)
            if (!brigadirClosed && deadlinePassed) {
                Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        SmartText("⚠ ${strings.brigadirDeadlinePassed}", fontWeight = FontWeight.Bold)
                        if (closure?.brigadirLateReason.isNullOrBlank()) {
                            TextButton(onClick = { delayReasonOpen = true }) { SmartText(strings.writeReason) }
                        } else {
                            SmartText("${strings.reason}: ${closure?.brigadirLateReason}")
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = brigadeWorked,
                    enabled = !brigadirClosed,
                    onClick = {
                        error = repository.setBrigadeWorked(brigadeId, date, true).exceptionOrNull()?.message
                        if (error == null) refresh()
                    },
                    label = { SmartText(strings.brigadeWorked) }
                )
                FilterChip(
                    selected = !brigadeWorked,
                    enabled = !brigadirClosed,
                    onClick = {
                        error = repository.setBrigadeWorked(brigadeId, date, false).exceptionOrNull()?.message
                        if (error == null) refresh()
                    },
                    label = { SmartText(strings.brigadeDidNotWork) }
                )
            }
            if (!error.isNullOrBlank()) SmartText(error!!, color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(14.dp))

            if (brigadeWorked) {
                OutlinedTextField(
                    value = search, onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(), label = { SmartText(strings.searchWorker) }, singleLine = true
                )
                Spacer(Modifier.height(10.dp))
            }

            if (!brigadeWorked) {
                Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
                    SmartText(strings.brigadeDidNotWork, Modifier.padding(18.dp), fontWeight = FontWeight.SemiBold)
                }
            } else {
                val workers = data.workers.filter { !it.archived && it.brigadeId == brigadeId && (search.isBlank() || it.name.contains(search, true)) }
                if (workers.isEmpty()) {
                    SmartText(strings.noWorkersForBrigade)
                } else {
                    val ordered = workers.sortedWith(compareBy<Worker> { data.workerDay(it.id, date)?.isComplete == true }.thenBy { it.name.lowercase() })
                    val incomplete = ordered.filterNot { data.workerDay(it.id, date)?.isComplete == true }
                    val complete = ordered.filter { data.workerDay(it.id, date)?.isComplete == true }

                    WorkerSectionTitle(strings.unfinished, incomplete.size)
                    incomplete.forEach { worker ->
                        WorkerDayRow(strings, data, worker, date) { workerId = worker.id }
                    }
                    if (complete.isNotEmpty()) {
                        HorizontalDivider(Modifier.padding(vertical = 14.dp))
                        WorkerSectionTitle(strings.completed, complete.size)
                        complete.forEach { worker ->
                            WorkerDayRow(strings, data, worker, date) { workerId = worker.id }
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            val missing = data.brigadirMissing(brigadeId, date)
            if (brigadirClosed) {
                Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        SmartText("✓ ${strings.brigadirDayClosed}", fontWeight = FontWeight.Bold)
                        SmartText(closure?.brigadirClosedAt?.take(16)?.replace('T', ' ') ?: "")
                        if (!closure?.brigadirLateReason.isNullOrBlank()) SmartText("${strings.reason}: ${closure?.brigadirLateReason}")
                    }
                }
            } else {
                if (missing.isNotEmpty()) {
                    Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            SmartText("⚠ ${strings.cannotCloseDay}", fontWeight = FontWeight.Bold)
                            missing.take(6).forEach { SmartText("• $it", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                Button(
                    onClick = {
                        val late = runCatching { java.time.LocalDateTime.now().isAfter(LocalDate.parse(date).plusDays(1).atTime(9, 0)) }.getOrDefault(false)
                        if (late) closeReasonOpen = true
                        else {
                            val result = repository.closeBrigadirDay(brigadeId, date)
                            error = result.exceptionOrNull()?.message
                            if (result.isSuccess) refresh()
                        }
                    },
                    enabled = missing.isEmpty(),
                    modifier = Modifier.fillMaxWidth()
                ) { SmartText(strings.closeBrigadirDay) }
            }
        }
    }

    if (delayReasonOpen) {
        CloseReasonDialog(
            title = strings.lateCloseReason,
            strings = strings,
            onDismiss = { delayReasonOpen = false },
            onSave = { reason ->
                val result = repository.saveBrigadirLateReason(brigadeId, date, reason)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { delayReasonOpen = false; refresh() }
                result.isSuccess
            }
        )
    }

    if (closeReasonOpen) {
        CloseReasonDialog(
            title = strings.lateCloseReason,
            strings = strings,
            onDismiss = { closeReasonOpen = false },
            onSave = { reason ->
                val result = repository.closeBrigadirDay(brigadeId, date, reason)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { closeReasonOpen = false; refresh() }
                result.isSuccess
            }
        )
    }
}

@Composable
private fun WorkerSectionTitle(title: String, count: Int) {
    SmartText("$title ($count)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
}

@Composable
private fun WorkerDayRow(strings: AppStrings, data: AssemblyData, worker: Worker, date: String, onClick: () -> Unit) {
    val day = data.workerDay(worker.id, date)
    val hours = day?.hours ?: data.workHoursAt(date)
    val worked = day?.worked ?: true
    val earned = day?.earned ?: 0L
    Surface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                SmartText(worker.name, fontWeight = FontWeight.SemiBold)
                SmartText(if (worked) "$hours ${strings.hours} • ${formatMoneyBrigadir(earned)} ${strings.som}" else strings.didNotWork,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (day?.isComplete == true) SmartText("✓", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun WorkerDayScreen(
    strings: AppStrings,
    data: AssemblyData,
    repository: AssemblyDataRepository,
    worker: Worker,
    date: String,
    readOnly: Boolean,
    onBack: () -> Unit,
    onChanged: () -> Unit
) {
    val day = data.workerDay(worker.id, date)
    val worked = day?.worked ?: true
    val hours = day?.hours ?: data.workHoursAt(date)
    val entries = day?.entries.orEmpty()
    val products = data.products.filter { !it.archived && it.brigadeId == worker.brigadeId }.sortedBy { it.article }
    val fk = data.brigadeFkAt(worker.brigadeId, date)
    val required = if (fk != null) fk.toDouble() * hours / data.workHoursAt(date) else null
    val earned = entries.sumOf { it.amount }
    val efficiency = if (required != null && required > 0) earned * 100.0 / required else null
    var hoursOpen by remember { mutableStateOf(false) }
    var editEntry by remember { mutableStateOf<ProductionEntry?>(null) }
    var deleteEntry by remember { mutableStateOf<ProductionEntry?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(worker.name, canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("BrigadirScreen-screen-2")).navigationBarsPadding().padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                SmartText(date, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                AssistChip(onClick = { if (!readOnly) hoursOpen = true }, label = { SmartText("$hours ${strings.hours}") }, enabled = !readOnly)
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = worked, enabled = !readOnly, onClick = {
                    error = repository.setWorkerWorked(worker.id, date, true).exceptionOrNull()?.message
                    if (error == null) onChanged()
                }, label = { SmartText(strings.worked) })
                FilterChip(selected = !worked, enabled = !readOnly, onClick = {
                    error = repository.setWorkerWorked(worker.id, date, false).exceptionOrNull()?.message
                    if (error == null) onChanged()
                }, label = { SmartText(strings.didNotWork) })
            }
            Spacer(Modifier.height(12.dp))

            if (worked) {
                entries.forEach { entry ->
                    Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(14.dp), tonalElevation = 1.dp) {
                        Column(Modifier.padding(12.dp)) {
                            SmartText("${entry.articleSnapshot} — ${entry.productNameSnapshot}", fontWeight = FontWeight.SemiBold)
                            SmartText("${formatProductionQuantity(entry.quantity)} × ${formatMoneyBrigadir(entry.unitPriceSnapshot)} = ${formatMoneyBrigadir(entry.amount)} ${strings.som}")
                            if (!readOnly) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                    TextButton(onClick = { editEntry = entry }) { SmartText(strings.edit) }
                                    TextButton(onClick = { deleteEntry = entry }) { SmartText(strings.delete) }
                                }
                            }
                        }
                    }
                }
                if (products.isEmpty()) {
                    SmartText(strings.noProductsForBrigade, Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.error)
                } else {
                    ProductionEntryForm(
                        strings = strings,
                        products = products,
                        existing = entries,
                        resetKey = entries.joinToString("|") { "${it.id}:${formatProductionQuantity(it.quantity)}" },
                        enabled = !readOnly,
                        onSave = { productId, quantity, merge ->
                            val result = repository.addProductionEntry(worker.id, date, productId, quantity, merge)
                            error = result.exceptionOrNull()?.message
                            if (result.isSuccess) onChanged()
                            result.isSuccess
                        }
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), tonalElevation = 2.dp) {
                Column(Modifier.padding(16.dp)) {
                    MetricLine(strings.totalAmount, "${formatMoneyBrigadir(earned)} ${strings.som}")
                    MetricLine(strings.requiredAmount, required?.let { "${formatMoneyBrigadir(it.roundToLong())} ${strings.som}" } ?: "—")
                    MetricLine(strings.efficiency, efficiency?.let { String.format("%.1f%%", it) } ?: "—")
                    if (fk == null && worked) SmartText(strings.fkMissing, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
                }
            }
            if (!error.isNullOrBlank()) SmartText(error!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
        }
    }

    if (hoursOpen) HoursDialog(strings, hours, onDismiss = { hoursOpen = false }) { value ->
        val result = repository.setWorkerHours(worker.id, date, value)
        error = result.exceptionOrNull()?.message
        if (result.isSuccess) { hoursOpen = false; onChanged() }
        result.isSuccess
    }

    editEntry?.let { entry ->
        QuantityDialog(strings, entry.quantity, onDismiss = { editEntry = null }) { quantity ->
            val result = repository.updateProductionQuantity(worker.id, date, entry.id, quantity)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { editEntry = null; onChanged() }
            result.isSuccess
        }
    }

    deleteEntry?.let { entry ->
        AlertDialog(
            onDismissRequest = { deleteEntry = null },
            title = { SmartText(strings.delete) },
            text = { SmartText("${entry.articleSnapshot} — ${entry.productNameSnapshot}") },
            confirmButton = { TextButton(onClick = {
                error = repository.removeProductionEntry(worker.id, date, entry.id).exceptionOrNull()?.message
                deleteEntry = null
                if (error == null) onChanged()
            }) { SmartText(strings.delete) } },
            dismissButton = { TextButton(onClick = { deleteEntry = null }) { SmartText(strings.cancel) } }
        )
    }
}

@Composable
private fun MetricLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        SmartText(label, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
        SmartText(value, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun HoursDialog(strings: AppStrings, initial: Int, onDismiss: () -> Unit, onSave: (Int) -> Boolean) {
    var value by remember { mutableStateOf(initial.toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText(strings.changeHours) },
        text = { OutlinedTextField(value, { value = it.filter(Char::isDigit) }, label = { SmartText(strings.hours) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true) },
        confirmButton = { TextButton(onClick = { value.toIntOrNull()?.let { if (onSave(it)) onDismiss() } }) { SmartText(strings.save) } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText(strings.cancel) } }
    )
}

@Composable
private fun QuantityDialog(strings: AppStrings, initial: Double, onDismiss: () -> Unit, onSave: (Double) -> Boolean) {
    var value by remember { mutableStateOf(formatProductionQuantity(initial)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText(strings.editQuantity) },
        text = { OutlinedTextField(value, { value = normalizeProductionQuantityInput(it) }, label = { SmartText(strings.quantity) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true) },
        confirmButton = { TextButton(onClick = { parseProductionQuantity(value)?.let { if (onSave(it)) onDismiss() } }) { SmartText(strings.save) } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText(strings.cancel) } }
    )
}

@Composable
private fun ProductionEntryForm(
    strings: AppStrings,
    products: List<Product>,
    existing: List<ProductionEntry>,
    resetKey: String,
    enabled: Boolean = true,
    onSave: (String, Double, Boolean) -> Boolean
) {
    var selectedId by remember(resetKey) { mutableStateOf<String?>(null) }
    var quantity by remember(resetKey) { mutableStateOf("") }
    var duplicateConfirm by remember { mutableStateOf(false) }
    var pickerOpen by remember { mutableStateOf(false) }
    val selected = products.firstOrNull { it.id == selectedId }
    val qty = parseProductionQuantity(quantity) ?: 0.0

    Surface(Modifier.fillMaxWidth().padding(top = 8.dp), shape = RoundedCornerShape(14.dp), tonalElevation = 1.dp) {
        Column(Modifier.padding(12.dp)) {
            SmartText(strings.addProduction, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(7.dp))
            OutlinedButton(onClick = { pickerOpen = true }, modifier = Modifier.fillMaxWidth(), enabled = enabled) {
                SmartText(selected?.let { "${it.article} — ${it.name}" } ?: strings.selectProduct)
            }
            selected?.let { product ->
                SmartText(
                    "${strings.article}: ${product.article} • ${strings.price}: ${formatMoneyBrigadir(product.currentPrice)} ${strings.som}",
                    Modifier.padding(top = 6.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(7.dp))
            OutlinedTextField(
                quantity, { quantity = normalizeProductionQuantityInput(it) }, Modifier.fillMaxWidth(),
                label = { SmartText(strings.quantity) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true
            )
            selected?.let { product ->
                val amount = productionAmount(qty, product.currentPrice)
                SmartText("${strings.amount}: ${formatMoneyBrigadir(amount)} ${strings.som}", Modifier.padding(top = 6.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(
                enabled = enabled && selected != null && qty > 0.0,
                onClick = {
                    val product = selected ?: return@TextButton
                    if (existing.any { it.productId == product.id }) duplicateConfirm = true
                    else onSave(product.id, qty, false)
                },
                modifier = Modifier.align(Alignment.End)
            ) { SmartText(strings.save) }
        }
    }

    if (pickerOpen) {
        ProductPickerDialog(
            strings = strings,
            products = products,
            onDismiss = { pickerOpen = false },
            onSelect = { product -> selectedId = product.id; pickerOpen = false }
        )
    }

    if (duplicateConfirm && selected != null) {
        AlertDialog(
            onDismissRequest = { duplicateConfirm = false },
            title = { SmartText(strings.duplicateProduct) },
            confirmButton = { TextButton(onClick = {
                if (onSave(selected.id, qty, true)) duplicateConfirm = false
            }) { SmartText(strings.merge) } },
            dismissButton = { TextButton(onClick = { duplicateConfirm = false }) { SmartText(strings.cancel) } }
        )
    }
}

@Composable
private fun ProductPickerDialog(
    strings: AppStrings,
    products: List<Product>,
    onDismiss: () -> Unit,
    onSelect: (Product) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query, products) {
        products.filter { query.isBlank() || it.article.contains(query, true) || it.name.contains(query, true) }
            .sortedWith(compareBy<Product> { it.article.lowercase() }.thenBy { it.name.lowercase() })
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText(strings.selectProduct) },
        text = {
            Column(Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { SmartText("${strings.article} / ${strings.productName}") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                    filtered.forEach { product ->
                        Surface(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { onSelect(product) },
                            shape = RoundedCornerShape(12.dp),
                            tonalElevation = 1.dp
                        ) {
                            Column(Modifier.padding(11.dp)) {
                                SmartText("${product.article} — ${product.name}", fontWeight = FontWeight.SemiBold)
                                SmartText("${formatMoneyBrigadir(product.currentPrice)} ${strings.som}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    if (filtered.isEmpty()) SmartText(strings.noProductsForBrigade, Modifier.padding(12.dp))
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { SmartText(strings.cancel) } }
    )
}


@Composable
private fun BrigadeDropdown(strings: AppStrings, brigades: List<Brigade>, selectedId: String, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val selected = brigades.firstOrNull { it.id == selectedId }
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            SmartText(selected?.name ?: strings.chooseBrigade)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            brigades.forEach { brigade -> DropdownMenuItem(text = { SmartText(brigade.name) }, onClick = { onSelect(brigade.id); open = false }) }
        }
    }
}

@Composable
private fun CloseReasonDialog(
    title: String,
    strings: AppStrings,
    onDismiss: () -> Unit,
    onSave: (String) -> Boolean
) {
    var reason by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText(title) },
        text = { OutlinedTextField(reason, { reason = it }, modifier = Modifier.fillMaxWidth(), label = { SmartText(strings.reason) }, minLines = 3) },
        confirmButton = { TextButton(onClick = { if (reason.isNotBlank()) onSave(reason) }, enabled = reason.isNotBlank()) { SmartText(strings.save) } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText(strings.cancel) } }
    )
}

private fun formatMoneyBrigadir(value: Long): String = String.format("%,d", value).replace(',', '\'')
