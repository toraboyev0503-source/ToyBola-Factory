package uz.toybola.factory.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.AssemblyDataEvents
import uz.toybola.factory.core.firebase.DailyIssueImageStorage
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.components.IssueImageBlock
import uz.toybola.factory.ui.components.IssueImageGallery
import uz.toybola.factory.ui.components.IssueImagePickerButton
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate
import java.util.UUID

@Composable
fun DailyIssueScreen(strings: AppStrings, repository: AssemblyDataRepository, onBack: () -> Unit) {
    var revision by remember { mutableIntStateOf(0) }
    val serverRevision by AssemblyDataEvents.revision.collectAsState()
    val context = LocalContext.current
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(revision, serverRevision, policy.revision) { repository.load().scopedFor(policy) }
    val canWrite = policy.canWriteDailyIssue()
    val date = remember { LocalDate.now().toString() }
    val brigades = data.brigades.filter { !it.archived && !it.deleted && policy.canAccessBrigade(it.id) }.sortedBy { it.name.lowercase() }
    var brigadeId by remember(brigades) { mutableStateOf(brigades.firstOrNull()?.id.orEmpty()) }
    var editorIssueId by remember { mutableStateOf<String?>(null) }
    var showNewEditor by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    fun refresh() { revision++ }

    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize()) {
        AppTopBar(strings.dailyIssue, canGoBack = true, onMenu = {}, onBack = onBack)
        Column(
            Modifier.fillMaxSize()
                .verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("DailyIssueScreen-main"))
                .navigationBarsPadding().padding(16.dp)
        ) {
            if (brigades.isEmpty()) { SmartText(strings.createBrigadeFirst); return@Column }
            IssueBrigadeDropdown(strings, brigades, brigadeId) { brigadeId = it }
            Spacer(Modifier.height(8.dp)); SmartText("${strings.today}: $date", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(14.dp))
            if (canWrite) Button(
                onClick = { showNewEditor = true }, modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp), shape = RoundedCornerShape(18.dp)
            ) { SmartText("+ ${strings.addIssue}", fontWeight = FontWeight.Bold) }
            if (!message.isNullOrBlank()) { Spacer(Modifier.height(10.dp)); SmartText(message!!, color = MaterialTheme.colorScheme.error) }
            Spacer(Modifier.height(18.dp))
            val issues = data.dailyIssues.filter { it.date == date && it.brigadeId == brigadeId }.sortedByDescending { it.createdAt }
            if (issues.isEmpty()) SmartText(strings.noIssuesToday, color = MaterialTheme.colorScheme.onSurfaceVariant)
            else issues.forEach { issue ->
                IssueCard(strings, issue, canWrite, { editorIssueId = issue.id }, {
                    val result = repository.removeDailyIssue(issue.id)
                    message = result.exceptionOrNull()?.message
                    if (result.isSuccess) refresh()
                })
                Spacer(Modifier.height(10.dp))
            }
        }
    }

    if (showNewEditor && canWrite) DailyIssueEditorDialog(
        strings = strings, brigadeId = brigadeId,
        products = data.products.filter { !it.archived && it.brigadeId == brigadeId }, initial = null,
        onDismiss = { showNewEditor = false },
        onSave = { issueId, productId, stageId, note, imageUrls, imagePaths ->
            val result = repository.addDailyIssue(brigadeId, date, productId, stageId, note, issueId, imageUrls, imagePaths)
            message = result.exceptionOrNull()?.message
            if (result.isSuccess) { showNewEditor = false; refresh() }
            result.isSuccess
        }
    )

    if (canWrite) editorIssueId?.let { issueId ->
        data.dailyIssues.firstOrNull { it.id == issueId }?.let { issue ->
            DailyIssueEditorDialog(
                strings = strings, brigadeId = issue.brigadeId,
                products = data.products.filter { !it.archived && it.brigadeId == issue.brigadeId }, initial = issue,
                onDismiss = { editorIssueId = null },
                onSave = { _, productId, stageId, note, imageUrls, imagePaths ->
                    val result = repository.updateDailyIssue(issue.id, productId, stageId, note, imageUrls, imagePaths)
                    message = result.exceptionOrNull()?.message
                    if (result.isSuccess) { editorIssueId = null; refresh() }
                    result.isSuccess
                }
            )
        }
    }
}

@Composable
private fun IssueBrigadeDropdown(strings: AppStrings, brigades: List<Brigade>, selectedId: String, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val selected = brigades.firstOrNull { it.id == selectedId }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { SmartText(selected?.name ?: strings.chooseBrigade, modifier = Modifier.weight(1f)) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            brigades.forEach { brigade -> DropdownMenuItem(text = { SmartText(brigade.name) }, onClick = { expanded = false; onSelected(brigade.id) }) }
        }
    }
}

@Composable
private fun IssueCard(strings: AppStrings, issue: DailyIssueRecord, canWrite: Boolean, onEdit: () -> Unit, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            SmartText("${issue.articleSnapshot} — ${issue.productNameSnapshot}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            SmartText(issue.stageNameSnapshot, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(7.dp)); SmartText(issue.note)
            if (issue.allImageUrls().isNotEmpty()) { Spacer(Modifier.height(10.dp)); IssueImageGallery(issue.allImageUrls(), issue.allImagePaths()) }
            Spacer(Modifier.height(7.dp)); SmartText(issue.createdAt.take(16).replace('T', ' '), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (canWrite) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onEdit) { SmartText(strings.edit) }
                TextButton(onClick = onDelete) { SmartText(strings.delete, color = MaterialTheme.colorScheme.error) }
            }
        }
    }
}

@Composable
private fun DailyIssueEditorDialog(
    strings: AppStrings,
    brigadeId: String,
    products: List<Product>,
    initial: DailyIssueRecord?,
    onDismiss: () -> Unit,
    onSave: (issueId: String, productId: String, stageId: String, note: String, imageUrls: List<String>, imagePaths: List<String>) -> Boolean
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val imageStorage = remember { DailyIssueImageStorage(context) }
    val issueId = remember(initial?.id) { initial?.id ?: UUID.randomUUID().toString() }
    var productId by remember(initial) { mutableStateOf(initial?.productId.orEmpty()) }
    var stageId by remember(initial) { mutableStateOf(initial?.stageId.orEmpty()) }
    var note by remember(initial) { mutableStateOf(initial?.note.orEmpty()) }
    val selectedImages = remember(initial?.id) { mutableStateListOf<Uri>() }
    var productMenu by remember { mutableStateOf(false) }
    var stageMenu by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }
    val product = products.firstOrNull { it.id == productId }
    val stages = product?.activeStages().orEmpty()
    val stage = stages.firstOrNull { it.id == stageId }

    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { SmartText(if (initial == null) strings.addIssue else strings.editIssue) },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) {
            Box(Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { productMenu = true }, modifier = Modifier.fillMaxWidth()) { SmartText(product?.let { "${it.article} — ${it.name}" } ?: strings.selectProduct, modifier = Modifier.weight(1f)) }
                DropdownMenu(expanded = productMenu, onDismissRequest = { productMenu = false }) {
                    products.sortedBy { it.article.lowercase() }.forEach { item -> DropdownMenuItem(text = { SmartText("${item.article} — ${item.name}") }, onClick = {
                        productMenu = false; productId = item.id; if (item.activeStages().none { it.id == stageId }) stageId = ""
                    }) }
                }
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { if (product != null) stageMenu = true else error = strings.chooseProductFirst }, modifier = Modifier.fillMaxWidth()) { SmartText(stage?.name ?: strings.selectAssemblyStage, modifier = Modifier.weight(1f)) }
                DropdownMenu(expanded = stageMenu, onDismissRequest = { stageMenu = false }) { stages.forEach { item -> DropdownMenuItem(text = { SmartText(item.name) }, onClick = { stageMenu = false; stageId = item.id }) } }
            }
            if (product != null && stages.isEmpty()) SmartText(strings.productHasNoStages, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = note, onValueChange = { note = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp), label = { SmartText(strings.issueText) }, keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences), minLines = 4)
            Spacer(Modifier.height(10.dp))
            val existingUrls = initial?.allImageUrls().orEmpty()
            val existingPaths = initial?.allImagePaths().orEmpty()
            val totalImages = existingUrls.size + selectedImages.size
            IssueImagePickerButton(
                hasImage = totalImages > 0,
                enabled = !saving && totalImages < 10,
                onSelected = { uri ->
                    if (existingUrls.size + selectedImages.size < 10) selectedImages.add(uri)
                    else error = "Bitta muammoga ko‘pi bilan 10 ta rasm qo‘shiladi"
                }
            )
            if (totalImages > 0) SmartText("Rasmlar: $totalImages / 10", style = MaterialTheme.typography.bodySmall)
            if (existingUrls.isNotEmpty()) { Spacer(Modifier.height(8.dp)); IssueImageGallery(existingUrls, existingPaths) }
            selectedImages.forEachIndexed { index, uri ->
                Card(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Column(Modifier.padding(8.dp)) {
                        AsyncImage(model = uri, contentDescription = "Tanlangan rasm", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(150.dp))
                        TextButton(onClick = { selectedImages.removeAt(index) }, enabled = !saving) { SmartText("Olib tashlash") }
                    }
                }
            }
            if (saving) { Spacer(Modifier.height(8.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()); SmartText("Rasm yuklanmoqda va muammo saqlanmoqda…", style = MaterialTheme.typography.bodySmall) }
            if (!error.isNullOrBlank()) SmartText(error!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 6.dp))
        } },
        confirmButton = { TextButton(enabled = !saving, onClick = {
            error = when { brigadeId.isBlank() -> strings.chooseBrigade; productId.isBlank() -> strings.selectProduct; stageId.isBlank() -> strings.selectAssemblyStage; note.isBlank() -> strings.required; else -> null }
            if (error == null) coroutineScope.launch {
                saving = true
                runCatching {
                    val existingUrls = initial?.allImageUrls().orEmpty()
                    val existingPaths = initial?.allImagePaths().orEmpty()
                    val uploaded = selectedImages.map { imageStorage.upload(it, "assembly", issueId) }
                    val imageUrls = (existingUrls + uploaded.map { it.url }).distinct().take(10)
                    val imagePaths = (existingPaths + uploaded.map { it.path }).distinct().take(10)
                    if (!onSave(issueId, productId, stageId, note, imageUrls, imagePaths)) error = "Muammoni saqlab bo‘lmadi"
                }.onFailure { error = it.message ?: "Rasmni yuklab bo‘lmadi" }
                saving = false
            }
        }) { SmartText(if (saving) "Saqlanmoqda…" else strings.save) } },
        dismissButton = { TextButton(enabled = !saving, onClick = onDismiss) { SmartText(strings.cancel) } }
    )
}
