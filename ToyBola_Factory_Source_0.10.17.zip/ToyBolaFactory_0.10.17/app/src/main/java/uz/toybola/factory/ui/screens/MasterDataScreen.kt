package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.AssemblyDataEvents
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate
import java.time.Year
import java.time.format.DateTimeParseException
import java.util.Locale

private enum class MasterPage {
    ROOT, BRIGADES, WORKERS, PRODUCTS, FK, WORK_HOURS, ROUND_TIMES,
    EFFICIENCY, MONITORING_WEIGHTS, ARCHIVE, YEAR_COPY, AUDIT
}

@Composable
fun MasterDataScreen(
    strings: AppStrings,
    repository: AssemblyDataRepository,
    onBack: () -> Unit
) {
    var page by remember { mutableStateOf(MasterPage.ROOT) }
    var revision by remember { mutableIntStateOf(0) }
    val serverRevision by AssemblyDataEvents.revision.collectAsState()
    val context = LocalContext.current
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(revision, serverRevision, policy.revision) { repository.load().scopedFor(policy) }

    fun refresh() { revision++ }
    fun back() {
        if (page == MasterPage.ROOT) onBack() else page = MasterPage.ROOT
    }

    BackHandler { back() }

    val title = when (page) {
        MasterPage.ROOT -> strings.masterData
        MasterPage.BRIGADES -> strings.brigades
        MasterPage.WORKERS -> strings.workers
        MasterPage.PRODUCTS -> strings.products
        MasterPage.FK -> strings.fk
        MasterPage.WORK_HOURS -> strings.workHours
        MasterPage.ROUND_TIMES -> strings.roundTimes
        MasterPage.EFFICIENCY -> strings.efficiencyNorm
        MasterPage.MONITORING_WEIGHTS -> strings.monitoringCriteria
        MasterPage.ARCHIVE -> strings.archive
        MasterPage.YEAR_COPY -> strings.yearCopy
        MasterPage.AUDIT -> strings.auditLog
    }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(title, canGoBack = true, onMenu = {}, onBack = ::back)
        when (page) {
            MasterPage.ROOT -> MasterRoot(strings) { page = it }
            MasterPage.BRIGADES -> BrigadesPage(strings, data, repository, ::refresh)
            MasterPage.WORKERS -> WorkersPage(strings, data, repository, ::refresh)
            MasterPage.PRODUCTS -> ProductsPage(strings, data, repository, ::refresh)
            MasterPage.FK -> FkPage(strings, data, repository, ::refresh)
            MasterPage.WORK_HOURS -> WorkHoursPage(strings, data, repository, ::refresh)
            MasterPage.ROUND_TIMES -> RoundTimesPage(strings, data, repository, ::refresh)
            MasterPage.EFFICIENCY -> EfficiencyPage(strings, data, repository, ::refresh)
            MasterPage.MONITORING_WEIGHTS -> MonitoringWeightsPage(strings, data, repository, ::refresh)
            MasterPage.ARCHIVE -> ArchivePage(strings, data, repository, ::refresh)
            MasterPage.YEAR_COPY -> YearCopyPage(strings, data, repository, ::refresh)
            MasterPage.AUDIT -> AuditPage(strings, data)
        }
    }
}

@Composable
private fun MasterRoot(strings: AppStrings, onOpen: (MasterPage) -> Unit) {
    val items = listOf(
        MasterPage.BRIGADES to strings.brigades,
        MasterPage.WORKERS to strings.workers,
        MasterPage.PRODUCTS to strings.products,
        MasterPage.FK to strings.fk,
        MasterPage.WORK_HOURS to strings.workHours,
        MasterPage.ROUND_TIMES to strings.roundTimes,
        MasterPage.EFFICIENCY to strings.efficiencyNorm,
        MasterPage.MONITORING_WEIGHTS to strings.monitoringCriteria,
        MasterPage.ARCHIVE to strings.archive,
        MasterPage.YEAR_COPY to strings.yearCopy,
        MasterPage.AUDIT to strings.auditLog
    )
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("MasterDataScreen-screen-9"))
            .navigationBarsPadding()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SmartText(strings.masterDataIntro, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(2.dp))
        items.forEach { (page, title) ->
            Surface(
                modifier = Modifier.fillMaxWidth().clickable { onOpen(page) },
                shape = RoundedCornerShape(18.dp),
                tonalElevation = 1.dp
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SmartText(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    SmartText("›", style = MaterialTheme.typography.headlineSmall)
                }
            }
        }
    }
}

@Composable
private fun AuditPage(strings: AppStrings, data: AssemblyData) {
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("MasterDataScreen-screen-1")).navigationBarsPadding().padding(16.dp)) {
        SmartText(strings.auditHelp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        if (data.auditLog.isEmpty()) {
            SmartText(strings.noAudit)
        } else {
            data.auditLog.sortedByDescending { it.dateTime }.take(300).forEach { entry ->
                val brigade = entry.brigadeId?.let { id -> data.brigades.firstOrNull { it.id == id }?.name }
                Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(12.dp), tonalElevation = 1.dp) {
                    Column(Modifier.padding(12.dp)) {
                        SmartText(entry.action, fontWeight = FontWeight.Bold)
                        SmartText(entry.dateTime.take(19).replace('T', ' '), style = MaterialTheme.typography.bodySmall)
                        if (!brigade.isNullOrBlank()) SmartText(brigade)
                        if (!entry.recordDate.isNullOrBlank()) SmartText(entry.recordDate!!)
                        if (entry.details.isNotBlank()) SmartText(entry.details, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun BrigadesPage(strings: AppStrings, data: AssemblyData, repo: AssemblyDataRepository, refresh: () -> Unit) {
    var editing by remember { mutableStateOf<Brigade?>(null) }
    var addOpen by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val active = data.brigades.filter { !it.archived && !it.deleted }.sortedBy { it.name.lowercase() }

    SimpleListPage(
        emptyText = strings.noBrigades,
        addLabel = strings.addBrigade,
        onAdd = { addOpen = true }
    ) {
        if (active.isEmpty()) EmptySmartText(strings.noBrigades)
        active.forEach { brigade ->
            DataRow(
                title = brigade.name,
                subtitle = strings.brigadeRowSubtitle(
                    data.workers.count { it.brigadeId == brigade.id && !it.archived },
                    data.products.count { it.brigadeId == brigade.id && !it.archived }
                ),
                onClick = { editing = brigade },
                actions = {
                    TextButton(onClick = {
                        error = repo.archiveBrigade(brigade.id, true).exceptionOrNull()?.message
                        if (error == null) refresh()
                    }) { SmartText(strings.toArchive) }
                }
            )
        }
        InlineError(error)
    }

    if (addOpen || editing != null) {
        NameDialog(
            strings = strings,
            title = if (editing == null) strings.addBrigade else strings.editBrigade,
            initial = editing?.name.orEmpty(),
            label = strings.brigadeName,
            onDismiss = { addOpen = false; editing = null },
            onSave = { value ->
                val result = editing?.let { repo.renameBrigade(it.id, value) } ?: repo.addBrigade(value)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { addOpen = false; editing = null; refresh() }
                result.isSuccess
            }
        )
    }
}

@Composable
private fun WorkersPage(strings: AppStrings, data: AssemblyData, repo: AssemblyDataRepository, refresh: () -> Unit) {
    var editing by remember { mutableStateOf<Worker?>(null) }
    var addOpen by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val brigades = data.brigades.filter { !it.archived && !it.deleted }.sortedBy { it.name.lowercase() }
    val activeBrigadeIds = brigades.map { it.id }.toSet()
    val workers = data.workers.filter { !it.archived && it.brigadeId in activeBrigadeIds }.sortedBy { it.name.lowercase() }

    SimpleListPage(
        emptyText = if (brigades.isEmpty()) strings.createBrigadeFirst else strings.noWorkers,
        addLabel = strings.addWorker,
        addEnabled = brigades.isNotEmpty(),
        onAdd = { addOpen = true }
    ) {
        if (workers.isEmpty() && brigades.isNotEmpty()) EmptySmartText(strings.noWorkers)
        workers.forEach { worker ->
            val brigade = data.brigades.firstOrNull { it.id == worker.brigadeId }
            DataRow(
                title = worker.name,
                subtitle = "${brigade?.name.orEmpty()} • ${strings.started}: ${worker.startDate}",
                onClick = { editing = worker },
                actions = {
                    TextButton(onClick = {
                        error = repo.archiveWorker(worker.id, true).exceptionOrNull()?.message
                        if (error == null) refresh()
                    }) { SmartText(strings.toArchive) }
                }
            )
        }
        InlineError(error)
    }

    if (addOpen || editing != null) {
        WorkerDialog(
            strings = strings,
            brigades = brigades,
            initial = editing,
            onDismiss = { addOpen = false; editing = null },
            onSave = { brigadeId, name, startDate ->
                val result = editing?.let { repo.updateWorker(it.id, brigadeId, name, startDate) }
                    ?: repo.addWorker(brigadeId, name, startDate)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { addOpen = false; editing = null; refresh() }
                result.isSuccess
            }
        )
    }
}

@Composable
private fun ProductsPage(strings: AppStrings, data: AssemblyData, repo: AssemblyDataRepository, refresh: () -> Unit) {
    var editing by remember { mutableStateOf<Product?>(null) }
    var viewingId by remember { mutableStateOf<String?>(null) }
    var stagesForId by remember { mutableStateOf<String?>(null) }
    var priceForId by remember { mutableStateOf<String?>(null) }
    var addOpen by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val brigades = data.brigades.filter { !it.archived && !it.deleted }.sortedBy { it.name.lowercase() }
    val activeBrigadeIds = brigades.map { it.id }.toSet()
    val products = data.products.filter { !it.archived && it.brigadeId in activeBrigadeIds }.sortedBy { it.article }

    SimpleListPage(
        emptyText = if (brigades.isEmpty()) strings.createBrigadeFirst else strings.noProducts,
        addLabel = strings.addProduct,
        addEnabled = brigades.isNotEmpty(),
        onAdd = { addOpen = true }
    ) {
        if (products.isEmpty() && brigades.isNotEmpty()) EmptySmartText(strings.noProducts)
        products.forEach { product ->
            val brigade = data.brigades.firstOrNull { it.id == product.brigadeId }
            DataRow(
                title = "${product.article} — ${product.name}",
                subtitle = "${brigade?.name.orEmpty()} • ${formatMoney(product.currentPrice)} ${strings.som}",
                onClick = { viewingId = product.id },
                actions = {
                    TextButton(onClick = {
                        error = repo.archiveProduct(product.id, true).exceptionOrNull()?.message
                        if (error == null) refresh()
                    }) { SmartText(strings.toArchive) }
                }
            )
        }
        InlineError(error)
    }

    if (addOpen || editing != null) {
        ProductDialog(
            strings = strings,
            brigades = brigades,
            initial = editing,
            onDismiss = { addOpen = false; editing = null },
            onSave = { brigadeId, article, name, price ->
                val result = editing?.let { repo.updateProduct(it.id, brigadeId, article, name, price) }
                    ?: repo.addProduct(brigadeId, article, name, price)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { addOpen = false; editing = null; refresh() }
                result.isSuccess
            }
        )
    }

    viewingId?.let { id ->
        data.products.firstOrNull { it.id == id }?.let { product ->
            ProductDetailDialog(
                strings = strings,
                product = product,
                brigadeName = data.brigades.firstOrNull { it.id == product.brigadeId }?.name.orEmpty(),
                onDismiss = { viewingId = null },
                onEdit = { viewingId = null; editing = product },
                onStages = { viewingId = null; stagesForId = product.id },
                onNewPrice = { viewingId = null; priceForId = product.id }
            )
        }
    }

    stagesForId?.let { id ->
        data.products.firstOrNull { it.id == id }?.let { product ->
            ProductStagesDialog(strings, product, repo, onDismiss = { stagesForId = null }, onChanged = refresh)
        }
    }

    priceForId?.let { id ->
        data.products.firstOrNull { it.id == id }?.let { product ->
            NumberVersionDialog(
                strings = strings,
                title = strings.newValue,
                valueLabel = strings.price,
                initialValue = product.currentPrice.toString(),
                suffix = strings.som,
                onDismiss = { priceForId = null },
                onSave = { value, date ->
                    val result = repo.setProductPrice(product.id, value.toLongOrNull() ?: 0L, date)
                    error = result.exceptionOrNull()?.message
                    if (result.isSuccess) { priceForId = null; refresh() }
                    result.isSuccess
                }
            )
        }
    }
}

@Composable
private fun FkPage(strings: AppStrings, data: AssemblyData, repo: AssemblyDataRepository, refresh: () -> Unit) {
    var selectedId by remember { mutableStateOf<String?>(null) }
    var addValue by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val brigades = data.brigades.filter { !it.archived && !it.deleted }.sortedBy { it.name.lowercase() }

    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("MasterDataScreen-screen-2")).navigationBarsPadding().padding(16.dp)) {
        SmartText(strings.fkHelp, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))
        if (brigades.isEmpty()) EmptySmartText(strings.createBrigadeFirst)
        brigades.forEach { brigade ->
            val history = data.brigadeFk.firstOrNull { it.brigadeId == brigade.id }
            DataRow(
                title = brigade.name,
                subtitle = history?.current?.let { "${formatMoney(it)} ${strings.som}" } ?: strings.notEntered,
                onClick = { selectedId = brigade.id }
            )
        }
        InlineError(error)
    }

    selectedId?.let { brigadeId ->
        val brigade = data.brigades.firstOrNull { it.id == brigadeId }
        if (brigade != null) {
            val history = data.brigadeFk.firstOrNull { it.brigadeId == brigadeId }
            AlertDialog(
                onDismissRequest = { selectedId = null },
                title = { SmartText("${strings.fk} — ${brigade.name}") },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        SummaryCard(strings.currentValue, history?.current?.let { "${formatMoney(it)} ${strings.som}" } ?: strings.notEntered)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { addValue = true }) { SmartText("+ ${strings.newValue}") }
                        Spacer(Modifier.height(16.dp))
                        SmartText(strings.history, fontWeight = FontWeight.Bold)
                        if (history == null || history.versions.isEmpty()) SmartText(strings.noHistory)
                        history?.versions?.sortedByDescending { it.effectiveFrom }?.forEach { v ->
                            SmartText("${displayVersionDate(strings, v.effectiveFrom)} — ${formatMoney(v.value)} ${strings.som}", Modifier.padding(vertical = 4.dp))
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { selectedId = null }) { SmartText(strings.close) } }
            )
            if (addValue) {
                NumberVersionDialog(
                    strings = strings,
                    title = "${strings.newValue} — ${brigade.name}",
                    valueLabel = strings.amount,
                    initialValue = history?.current?.toString().orEmpty(),
                    suffix = strings.som,
                    onDismiss = { addValue = false },
                    onSave = { value, date ->
                        val result = repo.setBrigadeFk(brigade.id, value.toLongOrNull() ?: 0L, date)
                        error = result.exceptionOrNull()?.message
                        if (result.isSuccess) { addValue = false; refresh() }
                        result.isSuccess
                    }
                )
            }
        }
    }
}

@Composable
private fun WorkHoursPage(strings: AppStrings, data: AssemblyData, repo: AssemblyDataRepository, refresh: () -> Unit) {
    var edit by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    VersionSummaryPage(
        strings = strings,
        currentText = "${data.currentWorkHours()} ${strings.hours}",
        history = data.workHours.sortedByDescending { it.effectiveFrom }.map { "${displayVersionDate(strings, it.effectiveFrom)} — ${it.value} ${strings.hours}" },
        editLabel = strings.change,
        onEdit = { edit = true },
        error = error
    )
    if (edit) NumberVersionDialog(
        strings = strings,
        title = strings.workHours,
        valueLabel = strings.hours,
        initialValue = data.currentWorkHours().toString(),
        suffix = strings.hours,
        onDismiss = { edit = false },
        onSave = { value, date ->
            val result = repo.setWorkHours(value.toIntOrNull() ?: 0, date)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { edit = false; refresh() }
            result.isSuccess
        }
    )
}

@Composable
private fun EfficiencyPage(strings: AppStrings, data: AssemblyData, repo: AssemblyDataRepository, refresh: () -> Unit) {
    var edit by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    VersionSummaryPage(
        strings = strings,
        currentText = "${data.currentEfficiencyNorm()}%",
        history = data.efficiencyNorm.sortedByDescending { it.effectiveFrom }.map { "${displayVersionDate(strings, it.effectiveFrom)} — ${it.value}%" },
        editLabel = strings.change,
        onEdit = { edit = true },
        error = error
    )
    if (edit) NumberVersionDialog(
        strings = strings,
        title = strings.efficiencyNorm,
        valueLabel = strings.percent,
        initialValue = data.currentEfficiencyNorm().toString(),
        suffix = "%",
        onDismiss = { edit = false },
        onSave = { value, date ->
            val result = repo.setEfficiencyNorm(value.toIntOrNull() ?: 0, date)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { edit = false; refresh() }
            result.isSuccess
        }
    )
}

@Composable
private fun RoundTimesPage(strings: AppStrings, data: AssemblyData, repo: AssemblyDataRepository, refresh: () -> Unit) {
    var edit by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val current = data.currentRoundTimes()
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("MasterDataScreen-screen-3")).navigationBarsPadding().padding(16.dp)) {
        SmartText(strings.roundTimeHelp)
        Spacer(Modifier.height(14.dp))
        SummaryCard(strings.currentValue, "1: ${current.first}   •   2: ${current.second}   •   3: ${current.third}")
        Spacer(Modifier.height(12.dp))
        Button(onClick = { edit = true }) { SmartText(strings.change) }
        Spacer(Modifier.height(18.dp))
        SmartText(strings.history, fontWeight = FontWeight.Bold)
        data.roundTimes.sortedByDescending { it.effectiveFrom }.forEach {
            SmartText("${displayVersionDate(strings, it.effectiveFrom)} — ${it.first} / ${it.second} / ${it.third}", modifier = Modifier.padding(vertical = 5.dp))
        }
        InlineError(error)
    }

    if (edit) RoundTimesDialog(strings, current, onDismiss = { edit = false }) { a, b, c, date ->
        val result = repo.setRoundTimes(a, b, c, date)
        error = result.exceptionOrNull()?.message
        if (result.isSuccess) { edit = false; refresh() }
        result.isSuccess
    }
}

@Composable
private fun MonitoringWeightsPage(strings: AppStrings, data: AssemblyData, repo: AssemblyDataRepository, refresh: () -> Unit) {
    var edit by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val current = data.currentMonitoringWeights()
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("MasterDataScreen-screen-4")).navigationBarsPadding().padding(16.dp)) {
        SmartText(strings.monitoringCriteriaHelp)
        Spacer(Modifier.height(14.dp))
        SmartText(strings.brigadir, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        WeightLine(strings.onTimeClose, current.brigadir.onTimeClose)
        WeightLine(strings.noReopen, current.brigadir.noReopen)
        WeightLine(strings.brigadeResult, current.brigadir.brigadeResult)
        Spacer(Modifier.height(14.dp))
        SmartText(strings.quality, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        WeightLine(strings.roundsOnTime, current.quality.roundsOnTime)
        WeightLine(strings.rechecks, current.quality.rechecks)
        WeightLine(strings.onTimeClose, current.quality.onTimeClose)
        WeightLine(strings.dataDiscipline, current.quality.dataDiscipline)
        Spacer(Modifier.height(16.dp))
        Button(onClick = { edit = true }) { SmartText("+ ${strings.newValue}") }
        Spacer(Modifier.height(22.dp))
        SmartText(strings.history, fontWeight = FontWeight.Bold)
        data.monitoringWeights.sortedByDescending { it.effectiveFrom }.forEach { v ->
            Surface(Modifier.fillMaxWidth().padding(top = 8.dp), shape = RoundedCornerShape(14.dp), tonalElevation = 1.dp) {
                Column(Modifier.padding(14.dp)) {
                    SmartText(displayVersionDate(strings, v.effectiveFrom), fontWeight = FontWeight.SemiBold)
                    SmartText("${strings.brigadir}: ${v.brigadir.onTimeClose}/${v.brigadir.noReopen}/${v.brigadir.brigadeResult}")
                    SmartText("${strings.quality}: ${v.quality.roundsOnTime}/${v.quality.rechecks}/${v.quality.onTimeClose}/${v.quality.dataDiscipline}")
                }
            }
        }
        InlineError(error)
    }

    if (edit) MonitoringWeightsDialog(strings, current, onDismiss = { edit = false }) { b, q, date ->
        val result = repo.setMonitoringWeights(b, q, date)
        error = result.exceptionOrNull()?.message
        if (result.isSuccess) { edit = false; refresh() }
        result.isSuccess
    }
}

@Composable
private fun ArchivePage(strings: AppStrings, data: AssemblyData, repo: AssemblyDataRepository, refresh: () -> Unit) {
    var error by remember { mutableStateOf<String?>(null) }
    var deleteCandidate by remember { mutableStateOf<Brigade?>(null) }
    val brigades = data.brigades.filter { it.archived && !it.deleted }
    val workers = data.workers.filter { it.archived }
    val products = data.products.filter { it.archived }

    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("MasterDataScreen-screen-5")).navigationBarsPadding().padding(16.dp)) {
        if (brigades.isEmpty() && workers.isEmpty() && products.isEmpty()) EmptySmartText(strings.archiveEmpty)
        if (brigades.isNotEmpty()) {
            ArchiveHeader(strings.brigades)
            brigades.forEach { item ->
                val emptyBrigade = data.workers.none { it.brigadeId == item.id }
                RestoreRow(
                    strings = strings,
                    title = item.name,
                    onRestore = {
                        error = repo.archiveBrigade(item.id, false).exceptionOrNull()?.message
                        if (error == null) refresh()
                    },
                    onDelete = if (emptyBrigade) ({ deleteCandidate = item }) else null
                )
            }
        }
        if (workers.isNotEmpty()) {
            ArchiveHeader(strings.workers)
            workers.forEach { item ->
                RestoreRow(
                    strings = strings,
                    title = item.name,
                    onRestore = {
                        error = repo.archiveWorker(item.id, false).exceptionOrNull()?.message
                        if (error == null) refresh()
                    }
                )
            }
        }
        if (products.isNotEmpty()) {
            ArchiveHeader(strings.products)
            products.forEach { item ->
                RestoreRow(
                    strings = strings,
                    title = "${item.article} — ${item.name}",
                    onRestore = {
                        error = repo.archiveProduct(item.id, false).exceptionOrNull()?.message
                        if (error == null) refresh()
                    }
                )
            }
        }
        InlineError(error)
    }

    deleteCandidate?.let { brigade ->
        AlertDialog(
            onDismissRequest = { deleteCandidate = null },
            title = { SmartText(strings.deleteBrigadeTitle) },
            text = { SmartText(strings.deleteBrigadeConfirm) },
            confirmButton = {
                TextButton(onClick = {
                    val result = repo.deleteArchivedBrigade(brigade.id)
                    error = result.exceptionOrNull()?.message
                    if (result.isSuccess) { deleteCandidate = null; refresh() }
                }) { SmartText(strings.deletePermanently, color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleteCandidate = null }) { SmartText(strings.cancel) } }
        )
    }
}

@Composable
private fun YearCopyPage(strings: AppStrings, data: AssemblyData, repo: AssemblyDataRepository, refresh: () -> Unit) {
    var message by remember { mutableStateOf<String?>(null) }
    val current = Year.now().value
    val next = current + 1
    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("MasterDataScreen-screen-6")).navigationBarsPadding().padding(20.dp),
        horizontalAlignment = Alignment.Start
    ) {
        SmartText("$current → $next", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        SmartText(strings.yearCopyHelp)
        Spacer(Modifier.height(16.dp))
        SmartText(strings.yearCopyMastersCarry, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(18.dp))
        Button(onClick = {
            val result = repo.prepareNextYear()
            message = result.fold(
                onSuccess = { strings.yearPrepared(it) },
                onFailure = { it.message ?: strings.errorGeneric }
            )
            if (result.isSuccess) refresh()
        }) { SmartText(if (next in data.preparedYears) strings.prepared else strings.prepareNextYear) }
        message?.let { SmartText(it, modifier = Modifier.padding(top = 12.dp), color = MaterialTheme.colorScheme.primary) }
    }
}

@Composable
private fun SimpleListPage(
    emptyText: String,
    addLabel: String,
    addEnabled: Boolean = true,
    onAdd: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("MasterDataScreen-screen-7")).navigationBarsPadding().padding(16.dp)
    ) {
        Button(onClick = onAdd, enabled = addEnabled, modifier = Modifier.fillMaxWidth()) { SmartText("+ $addLabel") }
        Spacer(Modifier.height(12.dp))
        Box {
            Column(content = content)
        }
        // If content has no rows, caller's empty state cannot be inferred; a light hint stays useful.
        if (!addEnabled) EmptySmartText(emptyText)
    }
}

@Composable
private fun DataRow(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        tonalElevation = 1.dp
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 13.dp)) {
            SmartText(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            if (subtitle.isNotBlank()) SmartText(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, content = actions)
        }
    }
}

@Composable
private fun NameDialog(
    strings: AppStrings,
    title: String,
    initial: String,
    label: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Boolean
) {
    var value by remember(initial) { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText(title) },
        text = { OutlinedTextField(value, { value = it }, label = { SmartText(label) }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (onSave(value)) onDismiss() }) { SmartText(strings.save) } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText(strings.cancel) } }
    )
}

@Composable
private fun WorkerDialog(
    strings: AppStrings,
    brigades: List<Brigade>,
    initial: Worker?,
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Boolean
) {
    var brigadeId by remember(initial, brigades) { mutableStateOf(initial?.brigadeId ?: brigades.firstOrNull()?.id.orEmpty()) }
    var name by remember(initial) { mutableStateOf(initial?.name.orEmpty()) }
    var startDate by remember(initial) { mutableStateOf(initial?.startDate ?: LocalDate.now().toString()) }
    var localError by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText(if (initial == null) strings.addWorker else strings.editWorker) },
        text = {
            Column(Modifier.imePadding()) {
                BrigadePicker(strings, brigades, brigadeId) { brigadeId = it }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { SmartText(strings.workerName) }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(startDate, { startDate = it }, Modifier.fillMaxWidth(), label = { SmartText(strings.startDate) }, singleLine = true)
                SmartText(strings.dateFormatHint, style = MaterialTheme.typography.bodySmall)
                InlineError(localError)
            }
        },
        confirmButton = { TextButton(onClick = {
            localError = try { LocalDate.parse(startDate); null } catch (_: DateTimeParseException) { strings.invalidDate }
            if (localError == null) onSave(brigadeId, name, startDate)
        }) { SmartText(strings.save) } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText(strings.cancel) } }
    )
}

@Composable
private fun ProductDialog(
    strings: AppStrings,
    brigades: List<Brigade>,
    initial: Product?,
    onDismiss: () -> Unit,
    onSave: (String, String, String, Long) -> Boolean
) {
    var brigadeId by remember(initial, brigades) { mutableStateOf(initial?.brigadeId ?: brigades.firstOrNull()?.id.orEmpty()) }
    var article by remember(initial) { mutableStateOf(initial?.article.orEmpty()) }
    var name by remember(initial) { mutableStateOf(initial?.name.orEmpty()) }
    var price by remember(initial) { mutableStateOf(initial?.currentPrice?.toString().orEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText(if (initial == null) strings.addProduct else strings.editProduct) },
        text = {
            Column(Modifier.imePadding().verticalScroll(rememberScrollState())) {
                BrigadePicker(strings, brigades, brigadeId) { brigadeId = it }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(article, { article = it.uppercase(Locale.ROOT) }, Modifier.fillMaxWidth(), label = { SmartText(strings.article) }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { SmartText(strings.productName) }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    price, { price = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(),
                    label = { SmartText(strings.price) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true
                )
                if (initial != null) {
                    Spacer(Modifier.height(10.dp))
                    SmartText(strings.stagesEditHint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                InlineError(error)
            }
        },
        confirmButton = { TextButton(onClick = {
            val numeric = price.toLongOrNull()
            error = if (numeric == null || numeric <= 0) strings.invalidPrice else null
            if (error == null) onSave(brigadeId, article, name, numeric!!)
        }) { SmartText(strings.save) } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText(strings.cancel) } }
    )
}

@Composable
private fun ProductDetailDialog(
    strings: AppStrings,
    product: Product,
    brigadeName: String,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onStages: () -> Unit,
    onNewPrice: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText("${product.article} — ${product.name}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                DetailLine(strings.brigade, brigadeName)
                DetailLine(strings.price, "${formatMoney(product.currentPrice)} ${strings.som}")
                Spacer(Modifier.height(12.dp))
                Button(onClick = onStages, modifier = Modifier.fillMaxWidth()) { SmartText(strings.manageStages) }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onNewPrice, modifier = Modifier.fillMaxWidth()) { SmartText("+ ${strings.newPrice}") }
                Spacer(Modifier.height(14.dp))
                SmartText(strings.assemblyStages, fontWeight = FontWeight.Bold)
                if (product.activeStages().isEmpty()) SmartText(strings.noStages) else product.activeStages().forEachIndexed { index, stage -> SmartText("${index + 1}. ${stage.name}") }
                Spacer(Modifier.height(12.dp))
                SmartText(strings.priceHistory, fontWeight = FontWeight.Bold)
                product.priceHistory.sortedByDescending { it.effectiveFrom }.forEach {
                    SmartText("${displayVersionDate(strings, it.effectiveFrom)} — ${formatMoney(it.price)} ${strings.som}")
                }
            }
        },
        confirmButton = { TextButton(onClick = onEdit) { SmartText(strings.edit) } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText(strings.close) } }
    )
}

@Composable
private fun ProductStagesDialog(
    strings: AppStrings,
    product: Product,
    repo: AssemblyDataRepository,
    onDismiss: () -> Unit,
    onChanged: () -> Unit
) {
    var addOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<ProductStage?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText("${strings.assemblyStages} — ${product.article}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Button(onClick = { addOpen = true }, modifier = Modifier.fillMaxWidth()) { SmartText("+ ${strings.addStage}") }
                Spacer(Modifier.height(10.dp))
                if (product.activeStages().isEmpty()) SmartText(strings.noStages)
                product.activeStages().forEachIndexed { index, stage ->
                    Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(12.dp), tonalElevation = 1.dp) {
                        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            SmartText("${index + 1}. ${stage.name}", Modifier.weight(1f))
                            TextButton(onClick = { editing = stage }) { SmartText(strings.edit) }
                            TextButton(onClick = {
                                error = repo.archiveProductStage(product.id, stage.id, true).exceptionOrNull()?.message
                                if (error == null) onChanged()
                            }) { SmartText(strings.toArchive) }
                        }
                    }
                }
                val archivedStages = product.stages.filter { it.archived }
                if (archivedStages.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    SmartText(strings.archive, fontWeight = FontWeight.Bold)
                    archivedStages.forEach { stage ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            SmartText(stage.name, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            TextButton(onClick = {
                                error = repo.archiveProductStage(product.id, stage.id, false).exceptionOrNull()?.message
                                if (error == null) onChanged()
                            }) { SmartText(strings.restore) }
                        }
                    }
                }
                InlineError(error)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { SmartText(strings.close) } }
    )
    if (addOpen || editing != null) {
        NameDialog(
            strings = strings,
            title = if (editing == null) strings.addStage else strings.editStage,
            initial = editing?.name.orEmpty(),
            label = strings.stageName,
            onDismiss = { addOpen = false; editing = null },
            onSave = { value ->
                val result = editing?.let { repo.renameProductStage(product.id, it.id, value) } ?: repo.addProductStage(product.id, value)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { addOpen = false; editing = null; onChanged() }
                result.isSuccess
            }
        )
    }
}

@Composable
private fun NumberVersionDialog(
    strings: AppStrings,
    title: String,
    valueLabel: String,
    initialValue: String,
    suffix: String,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Boolean
) {
    var value by remember(initialValue) { mutableStateOf(initialValue) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText(title) },
        text = {
            Column(Modifier.imePadding()) {
                OutlinedTextField(value, { value = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { SmartText("$valueLabel ($suffix)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(date, { date = it }, Modifier.fillMaxWidth(), label = { SmartText(strings.effectiveDate) }, singleLine = true)
                SmartText("YYYY-MM-DD", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = { if (runCatching { LocalDate.parse(date) }.isSuccess && onSave(value, date)) onDismiss() }) { SmartText(strings.save) } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText(strings.cancel) } }
    )
}

@Composable
private fun RoundTimesDialog(
    strings: AppStrings,
    current: RoundTimesVersion,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String) -> Boolean
) {
    var a by remember { mutableStateOf(current.first) }
    var b by remember { mutableStateOf(current.second) }
    var c by remember { mutableStateOf(current.third) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText(strings.roundTimes) },
        text = {
            Column(Modifier.imePadding()) {
                listOf(strings.round1 to a, strings.round2 to b, strings.round3 to c).forEachIndexed { index, pair ->
                    OutlinedTextField(pair.second, { if (index == 0) a = it else if (index == 1) b = it else c = it }, Modifier.fillMaxWidth(), label = { SmartText(pair.first) }, singleLine = true)
                    Spacer(Modifier.height(7.dp))
                }
                OutlinedTextField(date, { date = it }, Modifier.fillMaxWidth(), label = { SmartText(strings.effectiveDate) }, singleLine = true)
                SmartText("Vaqt: HH:mm • Sana: YYYY-MM-DD", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = { if (onSave(a, b, c, date)) onDismiss() }) { SmartText(strings.save) } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText(strings.cancel) } }
    )
}

@Composable
private fun MonitoringWeightsDialog(
    strings: AppStrings,
    current: MonitoringWeightsVersion,
    onDismiss: () -> Unit,
    onSave: (BrigadirWeights, QualityWeights, String) -> Boolean
) {
    var b1 by remember { mutableStateOf(current.brigadir.onTimeClose.toString()) }
    var b2 by remember { mutableStateOf(current.brigadir.noReopen.toString()) }
    var b3 by remember { mutableStateOf(current.brigadir.brigadeResult.toString()) }
    var q1 by remember { mutableStateOf(current.quality.roundsOnTime.toString()) }
    var q2 by remember { mutableStateOf(current.quality.rechecks.toString()) }
    var q3 by remember { mutableStateOf(current.quality.onTimeClose.toString()) }
    var q4 by remember { mutableStateOf(current.quality.dataDiscipline.toString()) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText(strings.monitoringCriteria) },
        text = {
            Column(Modifier.imePadding().verticalScroll(rememberScrollState())) {
                SmartText(strings.brigadir, fontWeight = FontWeight.Bold)
                PercentField(strings.onTimeClose, b1) { b1 = it }
                PercentField(strings.noReopen, b2) { b2 = it }
                PercentField(strings.brigadeResult, b3) { b3 = it }
                Spacer(Modifier.height(10.dp))
                SmartText(strings.quality, fontWeight = FontWeight.Bold)
                PercentField(strings.roundsOnTime, q1) { q1 = it }
                PercentField(strings.rechecks, q2) { q2 = it }
                PercentField(strings.onTimeClose, q3) { q3 = it }
                PercentField(strings.dataDiscipline, q4) { q4 = it }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(date, { date = it }, Modifier.fillMaxWidth(), label = { SmartText(strings.effectiveDate) }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = {
            val b = BrigadirWeights(b1.toIntOrNull() ?: -1, b2.toIntOrNull() ?: -1, b3.toIntOrNull() ?: -1)
            val q = QualityWeights(q1.toIntOrNull() ?: -1, q2.toIntOrNull() ?: -1, q3.toIntOrNull() ?: -1, q4.toIntOrNull() ?: -1)
            if (onSave(b, q, date)) onDismiss()
        }) { SmartText(strings.save) } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText(strings.cancel) } }
    )
}

@Composable
private fun PercentField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(value, { onValueChange(it.filter(Char::isDigit)) }, Modifier.fillMaxWidth().padding(top = 6.dp), label = { SmartText("$label (%)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
}

@Composable
private fun BrigadePicker(strings: AppStrings, brigades: List<Brigade>, selectedId: String, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val selected = brigades.firstOrNull { it.id == selectedId }
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            SmartText(selected?.name ?: strings.selectBrigade)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            brigades.forEach { brigade ->
                DropdownMenuItem(text = { SmartText(brigade.name) }, onClick = { onSelect(brigade.id); open = false })
            }
        }
    }
}

@Composable
private fun VersionSummaryPage(strings: AppStrings, currentText: String, history: List<String>, editLabel: String, onEdit: () -> Unit, error: String?) {
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("MasterDataScreen-screen-8")).navigationBarsPadding().padding(16.dp)) {
        SummaryCard(strings.currentValue, currentText)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onEdit) { SmartText(editLabel) }
        Spacer(Modifier.height(18.dp))
        SmartText(strings.history, fontWeight = FontWeight.Bold)
        history.forEach { SmartText(it, modifier = Modifier.padding(vertical = 5.dp)) }
        InlineError(error)
    }
}

@Composable
private fun SummaryCard(label: String, value: String) {
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), tonalElevation = 1.dp) {
        Column(Modifier.padding(18.dp)) {
            SmartText(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            SmartText(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun WeightLine(label: String, value: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        SmartText(label, modifier = Modifier.weight(1f))
        SmartText("$value%", fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        SmartText(label, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
        SmartText(value, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun RestoreRow(strings: AppStrings, title: String, onRestore: () -> Unit, onDelete: (() -> Unit)? = null) {
    Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(14.dp), tonalElevation = 1.dp) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            SmartText(title, modifier = Modifier.weight(1f))
            TextButton(onClick = onRestore) { SmartText(strings.restore) }
            onDelete?.let { deleteAction ->
                TextButton(onClick = deleteAction) { SmartText(strings.deletePermanently, color = MaterialTheme.colorScheme.error) }
            }
        }
    }
}

@Composable
private fun ArchiveHeader(title: String) {
    SmartText(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
}

@Composable
private fun EmptySmartText(text: String) {
    SmartText(text, modifier = Modifier.fillMaxWidth().padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun InlineError(error: String?) {
    if (!error.isNullOrBlank()) SmartText(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp))
}

private fun displayVersionDate(strings: AppStrings, date: String): String = if (date == "2000-01-01") strings.initialValue else date

private fun formatMoney(value: Long): String = String.format("%,d", value).replace(',', '\'')
