package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.AssemblyDataEvents
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter

private enum class QualityWindowState { TOO_EARLY, OPEN, MISSED }

@Composable
fun QualityScreen(
    strings: AppStrings,
    repository: AssemblyDataRepository,
    onBack: () -> Unit
) {
    var revision by remember { mutableIntStateOf(0) }
    val serverRevision by AssemblyDataEvents.revision.collectAsState()
    val context = LocalContext.current
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(revision, serverRevision, policy.revision) { repository.load().scopedFor(policy) }
    val today = remember { LocalDate.now().toString() }
    var date by remember { mutableStateOf(today) }
    val brigades = data.brigades.filterNot { it.archived }.sortedBy { it.name.lowercase() }
    var brigadeId by remember(brigades) { mutableStateOf(brigades.firstOrNull()?.id.orEmpty()) }
    var selectedRound by remember { mutableIntStateOf(recommendedRound(data, date)) }
    var evaluatingWorkerId by remember { mutableStateOf<String?>(null) }
    var absentWorkerId by remember { mutableStateOf<String?>(null) }
    var missedWorkerId by remember { mutableStateOf<String?>(null) }
    var recheckWorkerId by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var closeReasonOpen by remember { mutableStateOf(false) }
    var delayReasonOpen by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }

    fun refresh() { revision++ }

    LaunchedEffect(date) { selectedRound = recommendedRound(data, date) }
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize()) {
        AppTopBar(strings.quality, canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("QualityScreen-screen-1")).navigationBarsPadding().padding(16.dp)) {
            if (brigades.isEmpty()) {
                SmartText(strings.createBrigadeFirst)
                return@Column
            }
            QualityBrigadeDropdown(strings, brigades, brigadeId) { brigadeId = it; date = today }
            Spacer(Modifier.height(10.dp))
            val outstanding = data.openQualityDates(brigadeId, today)
            if (outstanding.isNotEmpty()) {
                Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        SmartText("⚠ ${strings.unclosedQualityDays}", fontWeight = FontWeight.Bold)
                        outstanding.takeLast(3).forEach { oldDate ->
                            TextButton(onClick = { date = oldDate }) { SmartText("$oldDate — ${strings.open}") }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                SmartText(if (date == today) "${strings.today}: $date" else date, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (date != today) TextButton(onClick = { date = today }) { SmartText(strings.today) }
            }
            Spacer(Modifier.height(12.dp))

            val closure = data.brigadeDay(brigadeId, date)
            val qualityClosed = closure?.qualityClosed == true
            val brigadeWorked = closure?.worked ?: true
            val qualityDeadlinePassed = runCatching { LocalDateTime.now().isAfter(LocalDate.parse(date).atTime(17, 50)) }.getOrDefault(false)
            if (!qualityClosed && qualityDeadlinePassed) {
                Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        SmartText("⚠ ${strings.qualityDeadlinePassed}", fontWeight = FontWeight.Bold)
                        if (closure?.qualityLateReason.isNullOrBlank()) {
                            TextButton(onClick = { delayReasonOpen = true }) { SmartText(strings.writeReason) }
                        } else {
                            SmartText("${strings.reason}: ${closure?.qualityLateReason}")
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            if (!brigadeWorked) {
                Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), tonalElevation = 1.dp) {
                    SmartText(strings.brigadeDidNotWork, Modifier.padding(14.dp), fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(12.dp))
            }

            val times = data.roundTimesAt(date)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf(times.first, times.second, times.third).forEachIndexed { index, time ->
                    FilterChip(
                        selected = selectedRound == index + 1,
                        enabled = !qualityClosed,
                        onClick = { selectedRound = index + 1 },
                        label = { SmartText("${index + 1} • $time") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            val scheduledTime = qualityRoundTime(times, selectedRound)
            val window = qualityWindow(date, scheduledTime)
            SmartText(
                qualityWindowLabel(strings, scheduledTime, window),
                modifier = Modifier.padding(top = 7.dp),
                color = when (window) {
                    QualityWindowState.OPEN -> MaterialTheme.colorScheme.primary
                    QualityWindowState.MISSED -> MaterialTheme.colorScheme.error
                    QualityWindowState.TOO_EARLY -> MaterialTheme.colorScheme.onSurfaceVariant
                }
            )
            if (!message.isNullOrBlank()) {
                SmartText(message!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 7.dp))
            }
            Spacer(Modifier.height(12.dp))

            if (brigadeWorked) {
                OutlinedTextField(
                    value = search, onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(), label = { SmartText(strings.searchWorker) }, singleLine = true
                )
                Spacer(Modifier.height(10.dp))
                val workers = data.workers.filter { worker ->
                    !worker.archived && worker.brigadeId == brigadeId && data.workerDay(worker.id, date)?.worked != false &&
                        (search.isBlank() || worker.name.contains(search, true))
                }
                if (workers.isEmpty()) {
                    SmartText(strings.noWorkersForBrigade)
                } else {
                    val incomplete = workers.filterNot { data.qualityRound(it.id, date, selectedRound)?.isFinished == true }
                        .sortedBy { it.name.lowercase() }
                    val complete = workers.filter { data.qualityRound(it.id, date, selectedRound)?.isFinished == true }
                        .sortedBy { it.name.lowercase() }

                    QualitySectionTitle(strings.qualityPending, incomplete.size)
                    incomplete.forEach { worker ->
                        QualityWorkerRow(strings, data, worker, date, selectedRound) {
                            if (!qualityClosed) {
                                message = null
                                when (window) {
                                    QualityWindowState.OPEN -> evaluatingWorkerId = worker.id
                                    QualityWindowState.MISSED -> missedWorkerId = worker.id
                                    QualityWindowState.TOO_EARLY -> message = strings.qualityTooEarly
                                }
                            }
                        }
                    }
                    if (complete.isNotEmpty()) {
                        HorizontalDivider(Modifier.padding(vertical = 14.dp))
                        QualitySectionTitle(strings.qualityDone, complete.size)
                        complete.forEach { worker ->
                            QualityWorkerRow(strings, data, worker, date, selectedRound) {
                                if (!qualityClosed) {
                                    val record = data.qualityRound(worker.id, date, selectedRound)
                                    if (record?.needsRecheck == true && record.recheck == null) recheckWorkerId = worker.id
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            val missing = data.qualityMissing(brigadeId, date)
            if (qualityClosed) {
                Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        SmartText("✓ ${strings.qualityDayClosed}", fontWeight = FontWeight.Bold)
                        SmartText(closure?.qualityClosedAt?.take(16)?.replace('T', ' ') ?: "")
                        if (!closure?.qualityLateReason.isNullOrBlank()) SmartText("${strings.reason}: ${closure?.qualityLateReason}")
                    }
                }
            } else {
                if (missing.isNotEmpty()) {
                    Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            SmartText("⚠ ${strings.cannotCloseQuality}", fontWeight = FontWeight.Bold)
                            missing.take(6).forEach { SmartText("• $it", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                Button(
                    onClick = {
                        val late = runCatching { LocalDateTime.now().isAfter(LocalDate.parse(date).atTime(17, 50)) }.getOrDefault(false)
                        if (late) closeReasonOpen = true
                        else {
                            val result = repository.closeQualityDay(brigadeId, date)
                            message = result.exceptionOrNull()?.message
                            if (result.isSuccess) refresh()
                        }
                    },
                    enabled = missing.isEmpty(),
                    modifier = Modifier.fillMaxWidth()
                ) { SmartText(strings.closeQualityDay) }
            }
        }
    }

    if (delayReasonOpen) {
        QualityCloseReasonDialog(strings, onDismiss = { delayReasonOpen = false }) { reason ->
            val result = repository.saveQualityLateReason(brigadeId, date, reason)
            message = result.exceptionOrNull()?.message
            if (result.isSuccess) { delayReasonOpen = false; refresh() }
            result.isSuccess
        }
    }

    if (closeReasonOpen) {
        QualityCloseReasonDialog(strings, onDismiss = { closeReasonOpen = false }) { reason ->
            val result = repository.closeQualityDay(brigadeId, date, reason)
            message = result.exceptionOrNull()?.message
            if (result.isSuccess) { closeReasonOpen = false; refresh() }
            result.isSuccess
        }
    }

    evaluatingWorkerId?.let { workerId ->
        val worker = data.workers.firstOrNull { it.id == workerId }
        if (worker != null) {
            QualityEvaluationDialog(
                strings = strings,
                worker = worker,
                products = data.products.filter { !it.archived && it.brigadeId == worker.brigadeId },
                round = selectedRound,
                scheduledTime = qualityRoundTime(data.roundTimesAt(date), selectedRound),
                onDismiss = { evaluatingWorkerId = null },
                onAbsent = {
                    evaluatingWorkerId = null
                    absentWorkerId = worker.id
                },
                onSave = { grade, productId, stageId, note ->
                    val result = repository.saveQualityRound(worker.id, date, selectedRound, qualityRoundTime(data.roundTimesAt(date), selectedRound), grade, productId, stageId, note)
                    message = result.exceptionOrNull()?.message
                    if (result.isSuccess) { evaluatingWorkerId = null; refresh() }
                    result.isSuccess
                }
            )
        }
    }

    absentWorkerId?.let { workerId ->
        val worker = data.workers.firstOrNull { it.id == workerId }
        if (worker != null) {
            WorkerAbsenceDialog(
                strings = strings,
                workerName = worker.name,
                onDismiss = { absentWorkerId = null }
            ) { excused, reason ->
                val result = repository.markWorkerAbsent(
                    workerId = worker.id,
                    date = date,
                    round = selectedRound,
                    scheduledTime = qualityRoundTime(data.roundTimesAt(date), selectedRound),
                    excused = excused,
                    reason = reason
                )
                message = result.exceptionOrNull()?.message
                if (result.isSuccess) { absentWorkerId = null; refresh() }
                result.isSuccess
            }
        }
    }

    missedWorkerId?.let { workerId ->
        val worker = data.workers.firstOrNull { it.id == workerId }
        if (worker != null) {
            MissedReasonDialog(strings, worker.name, onDismiss = { missedWorkerId = null }) { reason ->
                val result = repository.markQualityRoundMissed(worker.id, date, selectedRound, qualityRoundTime(data.roundTimesAt(date), selectedRound), reason)
                message = result.exceptionOrNull()?.message
                if (result.isSuccess) { missedWorkerId = null; refresh() }
                result.isSuccess
            }
        }
    }

    recheckWorkerId?.let { workerId ->
        val worker = data.workers.firstOrNull { it.id == workerId }
        val record = data.qualityRound(workerId, date, selectedRound)
        if (worker != null && record != null) {
            RecheckDialog(strings, worker.name, record, onDismiss = { recheckWorkerId = null }) { grade, note ->
                val result = repository.saveQualityRecheck(worker.id, date, selectedRound, grade, note)
                message = result.exceptionOrNull()?.message
                if (result.isSuccess) { recheckWorkerId = null; refresh() }
                result.isSuccess
            }
        }
    }
}

@Composable
private fun QualityCloseReasonDialog(
    strings: AppStrings,
    onDismiss: () -> Unit,
    onSave: (String) -> Boolean
) {
    var reason by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText(strings.lateCloseReason) },
        text = { OutlinedTextField(reason, { reason = it }, modifier = Modifier.fillMaxWidth(), label = { SmartText(strings.reason) }, minLines = 3) },
        confirmButton = { TextButton(onClick = { if (reason.isNotBlank()) onSave(reason) }, enabled = reason.isNotBlank()) { SmartText(strings.save) } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText(strings.cancel) } }
    )
}

@Composable
private fun QualitySectionTitle(title: String, count: Int) {
    SmartText("$title ($count)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 7.dp))
}

@Composable
private fun QualityWorkerRow(strings: AppStrings, data: AssemblyData, worker: Worker, date: String, round: Int, onClick: () -> Unit) {
    val record = data.qualityRound(worker.id, date, round)
    val average = data.qualityAverage(worker.id, date)
    Surface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                SmartText(worker.name, fontWeight = FontWeight.SemiBold)
                val detail = when {
                    record?.isEvaluated == true -> "${strings.grade}: ${record.grade} • ${record.score}% • ${record.evaluatedAt?.let(::timeOnly) ?: "—"}"
                    record?.isExcusedAbsence == true -> "${strings.excused} • ${record.absenceReason}"
                    record?.isUnexcusedAbsence == true -> "${strings.unexcused} • 0%"
                    record?.isMissed == true -> strings.qualityMissed
                    else -> strings.qualityNotChecked
                }
                SmartText(
                    detail,
                    color = if (record?.isMissed == true || record?.isUnexcusedAbsence == true) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
                average?.let { SmartText("${strings.qualityResult}: ${String.format("%.1f%%", it)}", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                if (record?.needsRecheck == true && record.recheck == null) {
                    SmartText(strings.recheckRequired, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
                }
                record?.recheck?.let { SmartText("${strings.rechecked}: ${it.grade} • ${timeOnly(it.checkedAt)}", color = MaterialTheme.colorScheme.primary) }
            }
            if (record?.isFinished == true) SmartText("✓", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun QualityEvaluationDialog(
    strings: AppStrings,
    worker: Worker,
    products: List<Product>,
    round: Int,
    scheduledTime: String,
    onDismiss: () -> Unit,
    onAbsent: () -> Unit,
    onSave: (Int, String, String, String) -> Boolean
) {
    var grade by remember { mutableIntStateOf(0) }
    var selectedProductId by remember { mutableStateOf<String?>(null) }
    var selectedStageId by remember { mutableStateOf<String?>(null) }
    var note by remember { mutableStateOf("") }
    var productOpen by remember { mutableStateOf(false) }
    var stageOpen by remember { mutableStateOf(false) }
    val product = products.firstOrNull { it.id == selectedProductId }
    val stages = product?.activeStages().orEmpty()
    val valid = grade in 1..4 && product != null && selectedStageId != null && (grade <= 2 || note.isNotBlank())

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText("${worker.name} • $round-${strings.roundShort}") },
        text = {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                SmartText("${strings.scheduled}: $scheduledTime", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = onAbsent,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    SmartText(strings.workerUnavailable)
                }
                SmartText(
                    strings.absenceChoiceHelp,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
                HorizontalDivider(Modifier.padding(vertical = 10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (1..4).forEach { value ->
                        FilterChip(selected = grade == value, onClick = { grade = value }, label = { SmartText(value.toString()) }, modifier = Modifier.weight(1f))
                    }
                }
                if (grade > 0) {
                    SmartText(qualityGradeLabel(strings, grade), Modifier.padding(top = 6.dp), fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(10.dp))
                Box {
                    OutlinedButton(onClick = { productOpen = true }, modifier = Modifier.fillMaxWidth()) {
                        SmartText(product?.let { "${it.article} — ${it.name}" } ?: strings.selectProduct)
                    }
                    DropdownMenu(expanded = productOpen, onDismissRequest = { productOpen = false }) {
                        products.forEach { item ->
                            DropdownMenuItem(text = { SmartText("${item.article} — ${item.name}") }, onClick = {
                                selectedProductId = item.id; selectedStageId = null; productOpen = false
                            })
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Box {
                    OutlinedButton(enabled = product != null && stages.isNotEmpty(), onClick = { stageOpen = true }, modifier = Modifier.fillMaxWidth()) {
                        SmartText(stages.firstOrNull { it.id == selectedStageId }?.name ?: strings.selectAssemblyStage)
                    }
                    DropdownMenu(expanded = stageOpen, onDismissRequest = { stageOpen = false }) {
                        stages.forEach { stage ->
                            DropdownMenuItem(text = { SmartText(stage.name) }, onClick = { selectedStageId = stage.id; stageOpen = false })
                        }
                    }
                }
                if (product != null && stages.isEmpty()) SmartText(strings.productHasNoStages, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 5.dp))
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { SmartText(if (grade >= 3) "${strings.note} *" else strings.note) },
                    minLines = 2,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
                )
                if (grade >= 3) SmartText(strings.noteRequiredForBadGrade, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 4.dp))
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = {
                onSave(grade, selectedProductId!!, selectedStageId!!, note)
            }) { SmartText(strings.save) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText(strings.cancel) } }
    )
}

@Composable
private fun WorkerAbsenceDialog(
    strings: AppStrings,
    workerName: String,
    onDismiss: () -> Unit,
    onSave: (Boolean, String) -> Boolean
) {
    var excused by remember { mutableStateOf<Boolean?>(null) }
    var reason by remember { mutableStateOf("") }
    val valid = excused != null && (excused == false || reason.isNotBlank())

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText("$workerName — ${strings.workerUnavailable}") },
        text = {
            Column {
                SmartText(strings.absenceChoiceHelp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = excused == true,
                        onClick = { excused = true },
                        label = { SmartText(strings.excused) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = excused == false,
                        onClick = { excused = false; reason = "" },
                        label = { SmartText(strings.unexcused) },
                        modifier = Modifier.weight(1f)
                    )
                }
                if (excused == true) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { SmartText("${strings.reason} *") },
                        minLines = 3,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
                    )
                    SmartText(
                        strings.excusedReasonRequired,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = valid,
                onClick = { excused?.let { onSave(it, reason) } }
            ) { SmartText(strings.save) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText(strings.cancel) } }
    )
}

@Composable
private fun MissedReasonDialog(strings: AppStrings, workerName: String, onDismiss: () -> Unit, onSave: (String) -> Boolean) {
    var reason by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText("$workerName — ${strings.qualityMissed}") },
        text = {
            Column {
                SmartText(strings.missedReasonRequired)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(reason, { reason = it }, modifier = Modifier.fillMaxWidth(), label = { SmartText(strings.reason) }, minLines = 3,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences))
            }
        },
        confirmButton = { TextButton(enabled = reason.isNotBlank(), onClick = { onSave(reason) }) { SmartText(strings.save) } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText(strings.cancel) } }
    )
}

@Composable
private fun RecheckDialog(strings: AppStrings, workerName: String, record: QualityRoundRecord, onDismiss: () -> Unit, onSave: (Int, String) -> Boolean) {
    var grade by remember { mutableIntStateOf(0) }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText("$workerName — ${strings.recheck}") },
        text = {
            Column {
                SmartText("${record.articleSnapshot} • ${record.stageNameSnapshot}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                SmartText("${strings.originalGrade}: ${record.grade} (${record.score}%)", color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (1..4).forEach { value ->
                        FilterChip(selected = grade == value, onClick = { grade = value }, label = { SmartText(value.toString()) }, modifier = Modifier.weight(1f))
                    }
                }
                OutlinedTextField(note, { note = it }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), label = { SmartText(strings.note) }, minLines = 2,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences))
                SmartText(strings.recheckKeepsOriginal, Modifier.padding(top = 6.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton(enabled = grade in 1..4, onClick = { onSave(grade, note) }) { SmartText(strings.save) } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText(strings.cancel) } }
    )
}

@Composable
private fun QualityBrigadeDropdown(strings: AppStrings, brigades: List<Brigade>, selectedId: String, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val selected = brigades.firstOrNull { it.id == selectedId }
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) { SmartText(selected?.name ?: strings.chooseBrigade) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            brigades.forEach { brigade -> DropdownMenuItem(text = { SmartText(brigade.name) }, onClick = { onSelect(brigade.id); open = false }) }
        }
    }
}

private fun qualityRoundTime(times: RoundTimesVersion, round: Int): String = when (round) { 1 -> times.first; 2 -> times.second; else -> times.third }

private fun qualityWindow(date: String, time: String, now: LocalDateTime = LocalDateTime.now()): QualityWindowState {
    val scheduled = LocalDateTime.of(LocalDate.parse(date), LocalTime.parse(time))
    return when {
        now.isBefore(scheduled.minusHours(1)) -> QualityWindowState.TOO_EARLY
        now.isAfter(scheduled.plusHours(1)) -> QualityWindowState.MISSED
        else -> QualityWindowState.OPEN
    }
}

private fun recommendedRound(data: AssemblyData, date: String): Int {
    val times = data.roundTimesAt(date)
    val now = LocalTime.now()
    val values = listOf(times.first, times.second, times.third).map(LocalTime::parse)
    return values.indices.minByOrNull { kotlin.math.abs(java.time.Duration.between(values[it], now).toMinutes()) }?.plus(1) ?: 1
}

private fun qualityWindowLabel(strings: AppStrings, time: String, state: QualityWindowState): String {
    val scheduled = LocalTime.parse(time)
    val from = scheduled.minusHours(1).format(DateTimeFormatter.ofPattern("HH:mm"))
    val to = scheduled.plusHours(1).format(DateTimeFormatter.ofPattern("HH:mm"))
    return when (state) {
        QualityWindowState.OPEN -> "${strings.qualityWindow}: $from–$to • ${strings.availableNow}"
        QualityWindowState.TOO_EARLY -> "${strings.qualityWindow}: $from–$to • ${strings.notStartedYet}"
        QualityWindowState.MISSED -> "${strings.qualityWindow}: $from–$to • ${strings.windowPassed}"
    }
}

private fun qualityGradeLabel(strings: AppStrings, grade: Int): String = when (grade) {
    1 -> "1 — ${strings.excellent} — 100%"
    2 -> "2 — ${strings.good} — 75%"
    3 -> "3 — ${strings.unsatisfactory} — 50%"
    else -> "4 — ${strings.bad} — 0%"
}

private fun timeOnly(iso: String): String = runCatching { LocalDateTime.parse(iso).format(DateTimeFormatter.ofPattern("HH:mm")) }.getOrDefault("—")
