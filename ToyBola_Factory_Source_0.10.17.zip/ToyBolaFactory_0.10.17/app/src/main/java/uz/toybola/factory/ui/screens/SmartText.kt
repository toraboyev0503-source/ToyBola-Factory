package uz.toybola.factory.ui.screens

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp

/**
 * Display-only number normalization used across app screens.
 * - negative numeric tokens are red;
 * - 1000 -> 1 000, 12500.5 -> 12 500.5;
 * - dates, times, versions and article-like codes are left untouched.
 */
@Composable
internal fun SmartText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontWeight: FontWeight? = null,
    maxLines: Int = Int.MAX_VALUE,
    style: TextStyle = androidx.compose.material3.LocalTextStyle.current
) {
    val errorColor = MaterialTheme.colorScheme.error
    val annotated = rememberFormattedUiText(text, errorColor)
    androidx.compose.material3.Text(
        text = annotated,
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontWeight = fontWeight,
        maxLines = maxLines,
        style = style
    )
}

@Composable
private fun rememberFormattedUiText(source: String, errorColor: Color): AnnotatedString {
    // Cheap enough for short UI labels and values; avoids changing stored data.
    return buildAnnotatedString {
        val regex = Regex("(?<![\\p{L}\\p{N}])[-−]?(?:\\d{1,3}(?: \\d{3})+|\\d+)(?:[.,]\\d+)?(?![\\p{L}\\p{N}])")
        var cursor = 0
        regex.findAll(source).forEach { match ->
            append(source.substring(cursor, match.range.first))
            val raw = match.value
            val before = source.getOrNull(match.range.first - 1)
            val after = source.getOrNull(match.range.last + 1)
            val skipStructured = before in listOf('-', '/', ':', '.') || after in listOf('-', '/', ':', '.')
            val normalized = if (skipStructured) raw else groupNumberToken(raw)
            val start = length
            append(normalized)
            if (!skipStructured && (raw.startsWith('-') || raw.startsWith('−'))) {
                addStyle(SpanStyle(color = errorColor), start, length)
            }
            cursor = match.range.last + 1
        }
        if (cursor < source.length) append(source.substring(cursor))
    }
}

private fun groupNumberToken(raw: String): String {
    val sign = when {
        raw.startsWith('-') -> "-"
        raw.startsWith('−') -> "−"
        else -> ""
    }
    val unsigned = raw.removePrefix("-").removePrefix("−")
    // Already grouped display text only needs negative-color styling, not regrouping.
    if (' ' in unsigned) return raw
    val separatorIndex = unsigned.indexOfFirst { it == '.' || it == ',' }
    val integerPart = if (separatorIndex >= 0) unsigned.substring(0, separatorIndex) else unsigned
    val fraction = if (separatorIndex >= 0) unsigned.substring(separatorIndex) else ""
    // Codes such as 003 / 0760 are identifiers, not quantities. Never group a leading-zero token.
    if (integerPart.length > 1 && integerPart.startsWith('0')) return raw
    if (integerPart.length < 4) return raw
    val intValue = integerPart.toLongOrNull()
    // Do not turn a standalone year into 2 026.
    if (fraction.isEmpty() && intValue != null && intValue in 1900L..2100L) return raw
    val grouped = integerPart.reversed().chunked(3).joinToString(" ").reversed()
    return sign + grouped + fraction
}
