package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.firebase.TpAdminRepository
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class TpMasterPage { ROOT, PRODUCTS, STRUCTURE, WORKERS, PRICES }
private data class ColorDraft(val code: String = "", val share: String = "", val grams: String = "")

@Composable
fun TpMasterDataScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val eventRevision by TpDataEvents.revision.collectAsState()
    var localRevision by remember { mutableIntStateOf(0) }
    val policy = remember(eventRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(eventRevision, localRevision, policy.revision) { repository.load().scopedFor(policy) }
    var page by remember { mutableStateOf(TpMasterPage.ROOT) }
    fun refresh() { localRevision++ }
    fun back() { if (page == TpMasterPage.ROOT) onBack() else page = TpMasterPage.ROOT }
    BackHandler { back() }
    Column(Modifier.fillMaxSize()) {
        AppTopBar(if (page == TpMasterPage.ROOT) "Ma’lumotlar" else "TP ma’lumotlari", canGoBack = true, onMenu = {}, onBack = ::back)
        TpMasterDataPage(data, repository, policy, ::refresh, page) { page = it }
    }
}

@Composable
fun TpMasterDataPage(
    data: TpData,
    repo: TpDataRepository,
    policy: UserAccessPolicy,
    refresh: () -> Unit,
    page: TpMasterPage,
    onPageChange: (TpMasterPage) -> Unit
) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_MASTER_DATA)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var importing by remember { mutableStateOf(false) }
    var importMessage by remember { mutableStateOf<String?>(null) }
    var importOk by remember { mutableStateOf(false) }
    var importErrors by remember { mutableStateOf<List<String>>(emptyList()) }
    var showImportErrors by remember { mutableStateOf(false) }
    var showResetConfirm by remember { mutableStateOf(false) }
    var resetting by remember { mutableStateOf(false) }
    val excelLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                importing = true
                importMessage = null
                importErrors = emptyList()
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val inspection = context.contentResolver.openInputStream(uri)?.use(TpExcelImporter::inspect)
                            ?: error("Excel faylini ochib bo‘lmadi")
                        val allErrors = (inspection.errors + repo.validateImportPayload(inspection.payload)).distinct()
                        if (allErrors.isNotEmpty()) return@runCatching inspection.payload to allErrors
                        repo.importProductWorkbook(inspection.payload).getOrThrow()
                        inspection.payload to emptyList<String>()
                    }
                }
                importing = false
                if (result.isSuccess) {
                    val (payload, errors) = result.getOrThrow()
                    if (errors.isEmpty()) {
                        importOk = true
                        importMessage = "Import tayyor: ${payload.productCount} mahsulot, ${payload.detailCount} detal, ${payload.colorCount} rang, ${payload.brigadeCount} brigada, ${payload.machineCount} stanok, ${payload.workerCount} ishchi. Sync navbatiga qo‘shildi."
                        refresh()
                    } else {
                        importOk = false
                        importErrors = errors
                        importMessage = "${errors.size} ta muammo topildi. Barchasini ko‘rish uchun ‘Tekshirish’ni bosing."
                    }
                } else {
                    importOk = false
                    importMessage = result.exceptionOrNull()?.message ?: "Excel importda xato"
                }
            }
        }
    }
    when (page) {
        TpMasterPage.ROOT -> Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMasterDataScreen-screen-1")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SmartText("200 ga yaqin mahsulot va detallar shu yerda tartibli saqlanadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (canWrite) {
                Button(
                    enabled = !importing,
                    onClick = { excelLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) },
                    modifier = Modifier.fillMaxWidth()
                ) { SmartText(if (importing) "Excel o‘qilmoqda..." else "Excel’dan import") }
                SmartText("Standart TP Excel faylidagi mahsulot, rang, brigada, stanok va ishchilar bir martada tekshiriladi. Xato bo‘lsa barcha muammolar ro‘yxati birga ko‘rsatiladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            importMessage?.let { SmartText(it, color = if (importOk) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
            if (importErrors.isNotEmpty()) {
                OutlinedButton(onClick = { showImportErrors = true }, modifier = Modifier.fillMaxWidth()) { SmartText("Tekshirish (${importErrors.size})") }
            }
            TpNavRow("Mahsulotlar va detallar") { onPageChange(TpMasterPage.PRODUCTS) }
            TpNavRow("Sex, smena, brigada va stanoklar") { onPageChange(TpMasterPage.STRUCTURE) }
            TpNavRow("Xodimlar va umumiy kunlik norma") { onPageChange(TpMasterPage.WORKERS) }
            TpNavRow("Barcha jim narxlarini foizda o‘zgartirish") { onPageChange(TpMasterPage.PRICES) }
            if (policy.isAdmin()) {
                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                OutlinedButton(
                    onClick = { showResetConfirm = true },
                    enabled = !resetting,
                    modifier = Modifier.fillMaxWidth()
                ) { SmartText("TP/Seryo test ma’lumotlarini tozalash", color = MaterialTheme.colorScheme.error) }
                SmartText("Sex va smena sozlamalari hamda umumiy kunlik norma saqlanadi. Mahsulot, detal, brigada, stanok, ishchi, seryo qoldig‘i, zakaz va operatsion TP ma’lumotlari o‘chiriladi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        else -> Column(Modifier.fillMaxSize()) {
            TextButton(onClick = { onPageChange(TpMasterPage.ROOT) }, modifier = Modifier.padding(horizontal = 8.dp)) { SmartText("‹ TP ma’lumotlari") }
            when (page) {
                TpMasterPage.PRODUCTS -> TpProductsMaster(data, repo, canWrite, refresh)
                TpMasterPage.STRUCTURE -> TpStructureMaster(data, repo, canWrite, refresh)
                TpMasterPage.WORKERS -> TpWorkersMaster(data, repo, canWrite, refresh)
                TpMasterPage.PRICES -> TpPricesMaster(data, repo, canWrite, refresh)
                else -> Unit
            }
        }
    }
    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { if (!resetting) showResetConfirm = false },
            title = { SmartText("TP/Seryo ma’lumotlarini tozalash") },
            text = { SmartText("Bu amal server va ushbu telefondagi TP/Seryo test ma’lumotlarini o‘chiradi. Sborka, foydalanuvchilar, sex/smena sozlamalari va umumiy kunlik normaga tegilmaydi. Davom etasizmi?") },
            confirmButton = { TextButton(enabled = !resetting, onClick = {
                resetting = true
                scope.launch {
                    TpAdminRepository(context).resetTpForFreshImport()
                        .onSuccess { count ->
                            importOk = true
                            importMessage = "TP/Seryo ma’lumotlari tozalandi ($count ta server yozuvi). Endi Excel import qilishingiz mumkin."
                            showResetConfirm = false
                            refresh()
                        }
                        .onFailure { error ->
                            importOk = false
                            importMessage = error.message ?: "TP/Seryo ma’lumotlarini tozalashda xato"
                        }
                    resetting = false
                }
            }) { SmartText(if (resetting) "Tozalanmoqda..." else "Tozalash", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(enabled = !resetting, onClick = { showResetConfirm = false }) { SmartText("Bekor qilish") } }
        )
    }
    if (showImportErrors) {
        AlertDialog(
            onDismissRequest = { showImportErrors = false },
            title = { SmartText("Excel tekshiruvi — ${importErrors.size} ta muammo") },
            text = {
                Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    importErrors.forEachIndexed { index, item -> SmartText("${index + 1}. $item") }
                }
            },
            confirmButton = { TextButton(onClick = { showImportErrors = false }) { SmartText("Yopish") } }
        )
    }
}

@Composable
private fun TpProductsMaster(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var selectedId by remember { mutableStateOf<String?>(null) }
    var productDialog by remember { mutableStateOf<TpProduct?>(null) }
    var addProduct by remember { mutableStateOf(false) }
    var detailDialog by remember { mutableStateOf<TpDetail?>(null) }
    var addDetail by remember { mutableStateOf(false) }
    var deleteProduct by remember { mutableStateOf<TpProduct?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val selected = data.products.firstOrNull { it.id == selectedId }
    BackHandler(enabled = selected != null) { selectedId = null }
    val scrollKey = selected?.let { "tp-product-${it.id}" } ?: "tp-products-list"
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState(scrollKey)).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (selected == null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SmartText("Mahsulotlar", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                if (canWrite) Button(onClick = { addProduct = true }) { SmartText("+ Mahsulot") }
            }
            if (data.products.none { !it.archived }) SmartText("Mahsulot kiritilmagan.")
            data.products.filterNot { it.archived }.sortedBy { it.article }.forEach { product ->
                TpCard(Modifier.clickable { selectedId = product.id }) {
                    SmartText("${product.article} — ${product.name}", fontWeight = FontWeight.Bold)
                    SmartText("${product.details.count { !it.archived }} detal/qolip yozuvi")
                }
            }
        } else {
            TextButton(onClick = { selectedId = null }) { SmartText("‹ Mahsulotlar") }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    SmartText(selected.article, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    SmartText(selected.name)
                }
                if (canWrite) {
                    Column(horizontalAlignment = Alignment.End) {
                        OutlinedButton(onClick = { productDialog = selected }) { SmartText("Tahrirlash") }
                        TextButton(onClick = { deleteProduct = selected }) { SmartText("O‘chirish", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            if (canWrite) Button(onClick = { addDetail = true }, Modifier.fillMaxWidth()) { SmartText("+ Detal/qolip ma’lumoti") }
            selected.details.filterNot { it.archived }.forEach { detail ->
                TpCard(Modifier.clickable(enabled = canWrite) { detailDialog = detail }) {
                    SmartText(detail.name, fontWeight = FontWeight.Bold)
                    SmartText("1 mahsulotga ${detail.requiredPerProduct} • 1 jimda ${detail.piecesPerShot} • qopda ${detail.bagCapacity}")
                    SmartText("${detail.cycleSeconds} sek/jim • ${formatTpNumber(detail.grossShotWeightGrams)} g • seryo: ${detail.resinOptions().joinToString("/")}")
                    SmartText("1 jim narxi: ${formatTpNumber(detail.unitPrice)} so‘m")
                    SmartText("12 soat taxmin: ${detail.estimatedPiecesIn12Hours()} dona")
                    SmartText("Rang: ${detail.colors.joinToString { "${it.colorCode} (${formatTpNumber(it.share)})" }}")
                    SmartText("Mos sig‘im: ${detail.compatibleCapacities.sorted().joinToString("/").ifBlank { "cheklanmagan" }}")
                    SmartText("Avtomatik mos stanok: ${data.machines.filter { detail.acceptsMachine(it) }.sortedBy { it.number }.joinToString { "${it.number}${if (it.capacity > 0) " (${it.capacity})" else ""}" }.ifBlank { "sig‘im ma’lumoti yetarli emas" }}")
                }
            }
        }
        TpError(error)
    }
    if (addProduct || productDialog != null) TpProductDialog(productDialog, onDismiss = { addProduct = false; productDialog = null }) { article, name ->
        val result = productDialog?.let { repo.updateProduct(it.id, article, name) } ?: repo.addProduct(article, name)
        error = result.exceptionOrNull()?.message
        if (result.isSuccess) { addProduct = false; productDialog = null; refresh() }
        result.isSuccess
    }
    deleteProduct?.let { product ->
        AlertDialog(
            onDismissRequest = { deleteProduct = null },
            title = { SmartText("Mahsulotni o‘chirish") },
            text = { SmartText("${product.article} — ${product.name} ro‘yxatdan olib tashlanadi. Faol zakaz bo‘lsa tizim o‘chirishga ruxsat bermaydi.") },
            confirmButton = { TextButton(onClick = {
                val result = repo.deleteProduct(product.id)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { deleteProduct = null; selectedId = null; refresh() }
            }) { SmartText("O‘chirish", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { deleteProduct = null }) { SmartText("Bekor qilish") } }
        )
    }
    if (selected != null && (addDetail || detailDialog != null)) TpDetailDialog(data, detailDialog, onDismiss = { addDetail = false; detailDialog = null }) { detail ->
        val result = repo.saveDetail(selected.id, detail)
        error = result.exceptionOrNull()?.message
        if (result.isSuccess) { addDetail = false; detailDialog = null; refresh() }
        result.isSuccess
    }
}

@Composable
private fun TpProductDialog(initial: TpProduct?, onDismiss: () -> Unit, onSave: (String, String) -> Boolean) {
    var article by remember(initial?.id) { mutableStateOf(initial?.article.orEmpty()) }
    var name by remember(initial?.id) { mutableStateOf(initial?.name.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { SmartText(if (initial == null) "Mahsulot qo‘shish" else "Mahsulotni tahrirlash") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { TpField(article, { article = it }, "Artikul (TB-...)"); TpField(name, { name = it }, "Mahsulot nomi") } },
        confirmButton = { TextButton(onClick = { if (onSave(article, name)) onDismiss() }) { SmartText("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText("Bekor qilish") } }
    )
}

@Composable
private fun TpDetailDialog(data: TpData, initial: TpDetail?, onDismiss: () -> Unit, onSave: (TpDetail) -> Boolean) {
    var name by remember(initial?.id) { mutableStateOf(initial?.name.orEmpty()) }
    var required by remember(initial?.id) { mutableStateOf(initial?.requiredPerProduct?.toString() ?: "1") }
    var perShot by remember(initial?.id) { mutableStateOf(initial?.piecesPerShot?.toString() ?: "1") }
    var bag by remember(initial?.id) { mutableStateOf(initial?.bagCapacity?.toString() ?: "100") }
    var cycle by remember(initial?.id) { mutableStateOf(initial?.cycleSeconds?.toString() ?: "60") }
    var gross by remember(initial?.id) { mutableStateOf(initial?.grossShotWeightGrams?.let(::formatTpNumber).orEmpty()) }
    var unusable by remember(initial?.id) { mutableStateOf(initial?.unusableShotWeightGrams?.let(::formatTpNumber) ?: "0") }
    var resins by remember(initial?.id) { mutableStateOf(initial?.resinOptions()?.joinToString(",").orEmpty()) }
    var price by remember(initial?.id) { mutableStateOf(initial?.unitPrice?.let(::formatTpNumber) ?: "0") }
    var capacities by remember(initial?.id) { mutableStateOf(initial?.compatibleCapacities?.sorted()?.joinToString(",") ?: "") }
    val colors = remember(initial?.id) { mutableStateListOf<ColorDraft>().apply {
        val source = initial?.colors.orEmpty()
        if (source.isEmpty()) add(ColorDraft()) else source.forEach { add(ColorDraft(it.colorCode, formatTpNumber(it.share), formatTpNumber(it.gramsPer25Kg))) }
    } }
    var validation by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText(if (initial == null) "Detal/qolip qo‘shish" else "Detal/qolipni tahrirlash") },
        text = { Column(Modifier.heightIn(max = 600.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            TpField(name, { name = it }, "Detal nomi")
            TpField(required, { required = digitsOnly(it) }, "1 mahsulotga nechta", KeyboardType.Number)
            TpField(perShot, { perShot = digitsOnly(it) }, "1 jimda nechta", KeyboardType.Number)
            TpField(bag, { bag = digitsOnly(it) }, "1 qopda nechta", KeyboardType.Number)
            TpField(cycle, { cycle = digitsOnly(it) }, "1 jim vaqti (sekund)", KeyboardType.Number)
            TpField(gross, { gross = decimalInput(it) }, "1 jim umumiy og‘irligi (gram)", KeyboardType.Decimal)
            TpField(unusable, { unusable = decimalInput(it) }, "Shundan yaroqsiz qism og‘irligi (gram)", KeyboardType.Decimal)
            TpField(resins, { resins = it }, "Seryo turlari (masalan PP,PE,ABS)")
            TpField(price, { price = decimalInput(it) }, "1 jim narxi", KeyboardType.Decimal)
            SmartText("Rang taqsimoti", fontWeight = FontWeight.Bold)
            colors.forEachIndexed { index, color ->
                TpCard {
                    TpField(color.code, { value -> colors[index] = color.copy(code = value) }, "Rang kodi")
                    TpField(color.share, { value -> colors[index] = color.copy(share = decimalInput(value)) }, "Taqsimot ulushi", KeyboardType.Decimal)
                    TpField(color.grams, { value -> colors[index] = color.copy(grams = decimalInput(value)) }, "25 kg ga krasitel (gram)", KeyboardType.Decimal)
                    if (colors.size > 1) TextButton(onClick = { colors.removeAt(index) }) { SmartText("Rangni olib tashlash") }
                }
            }
            OutlinedButton(onClick = { colors.add(ColorDraft()) }, Modifier.fillMaxWidth()) { SmartText("+ Rang") }
            TpField(capacities, { value -> capacities = value.filter { it.isDigit() || it == ',' || it == '/' || it == ' ' } }, "Detal tushadigan stanok sig‘imlari (masalan 60,90,120)")
            SmartText("Mos stanoklar alohida tanlanmaydi. Dastur shu sig‘imlar bo‘yicha avtomatik topadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            TpError(validation)
        } },
        confirmButton = { TextButton(onClick = {
            val parsedColors = colors.mapNotNull { row ->
                val share = row.share.toDoubleOrNull(); val grams = row.grams.toDoubleOrNull()
                if (row.code.isBlank() || share == null || grams == null) null else TpColorRule(row.code, share, grams)
            }
            val detail = runCatching {
                val parsedCapacities = capacities.split(',', '/', ' ').mapNotNull { it.trim().toIntOrNull() }.filter { it > 0 }.toSet()
                val parsedResins = resins.split(',', '/', ';').map { it.trim().uppercase() }.filter { it.isNotBlank() }.distinct()
                val detailId = initial?.id ?: UUID.randomUUID().toString()
                val internalMoldCode = initial?.moldCode?.takeIf { it.isNotBlank() } ?: name.trim().ifBlank { detailId }
                TpDetail(
                    id = detailId, name = name, moldCode = internalMoldCode,
                    requiredPerProduct = required.toInt(), piecesPerShot = perShot.toInt(), bagCapacity = bag.toInt(),
                    cycleSeconds = cycle.toInt(), grossShotWeightGrams = gross.toDouble(), unusableShotWeightGrams = unusable.toDouble(),
                    resinCode = parsedResins.firstOrNull().orEmpty(), unitPrice = price.toDouble(), compatibleMachineIds = emptySet(), compatibleCapacities = parsedCapacities, colors = parsedColors,
                    archived = initial?.archived ?: false, resinCodes = parsedResins
                )
            }.getOrNull()
            validation = if (detail == null || parsedColors.size != colors.size) "Maydonlarni to‘g‘ri to‘ldiring" else null
            if (detail != null && validation == null && onSave(detail)) onDismiss()
        }) { SmartText("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText("Bekor qilish") } }
    )
}

@Composable
private fun TpStructureMaster(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var mode by remember { mutableStateOf("BRIGADE") }
    var brigadeDialog by remember { mutableStateOf<TpBrigade?>(null) }
    var addBrigade by remember { mutableStateOf(false) }
    var machineDialog by remember { mutableStateOf<TpMachine?>(null) }
    var addMachine by remember { mutableStateOf(false) }
    var deleteMachine by remember { mutableStateOf<TpMachine?>(null) }
    var shiftDialog by remember { mutableStateOf<TpShift?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMasterDataScreen-screen-3")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            listOf("BRIGADE" to "Brigada", "MACHINE" to "Stanok", "SHIFT" to "Smena").forEachIndexed { index, item ->
                SegmentedButton(selected = mode == item.first, onClick = { mode = item.first }, shape = SegmentedButtonDefaults.itemShape(index, 3)) { SmartText(item.second) }
            }
        }
        when (mode) {
            "BRIGADE" -> {
                if (canWrite) Button(onClick = { addBrigade = true }, Modifier.fillMaxWidth()) { SmartText("+ Brigada") }
                data.brigades.filterNot { it.archived }.sortedBy { it.name }.forEach { brigade ->
                    val shop = data.shops.firstOrNull { it.id == brigade.shopId }?.name.orEmpty()
                    val shift = data.shifts.firstOrNull { it.id == brigade.shiftId }?.name.orEmpty()
                    TpCard(Modifier.clickable(enabled = canWrite) { brigadeDialog = brigade }) { SmartText(brigade.name, fontWeight = FontWeight.Bold); SmartText("$shop • $shift") }
                }
            }
            "MACHINE" -> {
                if (canWrite) Button(onClick = { addMachine = true }, Modifier.fillMaxWidth()) { SmartText("+ Stanok") }
                data.machines.filterNot { it.archived }.sortedBy { it.number }.forEach { machine ->
                    TpCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f).clickable(enabled = canWrite) { machineDialog = machine }) {
                                SmartText("${machine.number}-stanok", fontWeight = FontWeight.Bold)
                                SmartText("${data.shops.firstOrNull { it.id == machine.shopId }?.name.orEmpty()} • sig‘im: ${if (machine.capacity > 0) machine.capacity else "kiritilmagan"}")
                            }
                            if (canWrite) TextButton(onClick = { deleteMachine = machine }) { SmartText("O‘chirish", color = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
            }
            else -> data.shifts.filterNot { it.archived }.forEach { shift ->
                TpCard(Modifier.clickable(enabled = canWrite) { shiftDialog = shift }) {
                    SmartText(shift.name, fontWeight = FontWeight.Bold)
                    SmartText("${shift.startTime}–${shift.endTime} • ${shift.roundTimes.size} raund: ${shift.roundTimes.joinToString()}")
                }
            }
        }
        TpError(error)
    }
    if (addBrigade || brigadeDialog != null) TpBrigadeDialog(data, brigadeDialog, { addBrigade = false; brigadeDialog = null }) { shop, shift, name ->
        val result = brigadeDialog?.let { repo.updateBrigade(it.id, shop, shift, name) } ?: repo.addBrigade(shop, shift, name)
        error = result.exceptionOrNull()?.message; if (result.isSuccess) { addBrigade = false; brigadeDialog = null; refresh() }; result.isSuccess
    }
    deleteMachine?.let { machine ->
        AlertDialog(
            onDismissRequest = { deleteMachine = null },
            title = { SmartText("Stanokni o‘chirish") },
            text = { SmartText("${machine.number}-stanok ro‘yxatdan olib tashlanadi. Faol vazifa bo‘lsa tizim o‘chirishga ruxsat bermaydi.") },
            confirmButton = { TextButton(onClick = {
                val result = repo.deleteMachine(machine.id)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { deleteMachine = null; refresh() }
            }) { SmartText("O‘chirish", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { deleteMachine = null }) { SmartText("Bekor qilish") } }
        )
    }
    if (addMachine || machineDialog != null) TpMachineDialog(data, machineDialog, { addMachine = false; machineDialog = null }) { shop, number, name, capacity ->
        val result = machineDialog?.let { repo.updateMachine(it.id, shop, number, name, capacity) } ?: repo.addMachine(shop, number, name, capacity)
        error = result.exceptionOrNull()?.message; if (result.isSuccess) { addMachine = false; machineDialog = null; refresh() }; result.isSuccess
    }
    shiftDialog?.let { shift -> TpShiftDialog(shift, { shiftDialog = null }) { name, start, end, rounds ->
        val result = repo.updateShift(shift.id, name, start, end, rounds)
        error = result.exceptionOrNull()?.message; if (result.isSuccess) { shiftDialog = null; refresh() }; result.isSuccess
    } }
}

@Composable
private fun TpBrigadeDialog(data: TpData, initial: TpBrigade?, onDismiss: () -> Unit, onSave: (String, String, String) -> Boolean) {
    var shop by remember { mutableStateOf(initial?.shopId ?: data.shops.firstOrNull()?.id.orEmpty()) }
    var shift by remember { mutableStateOf(initial?.shiftId ?: data.shifts.firstOrNull()?.id.orEmpty()) }
    var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { SmartText("Brigada") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TpChoice("Sex", shop, data.shops.filterNot { it.archived }, { it.id }, { it.name }) { shop = it }
        TpChoice("Smena", shift, data.shifts.filterNot { it.archived }, { it.id }, { it.name }) { shift = it }
        TpField(name, { name = it }, "Brigada nomi")
    } }, confirmButton = { TextButton(onClick = { if (onSave(shop, shift, name)) onDismiss() }) { SmartText("Saqlash") } }, dismissButton = { TextButton(onClick = onDismiss) { SmartText("Bekor qilish") } })
}

@Composable
private fun TpMachineDialog(data: TpData, initial: TpMachine?, onDismiss: () -> Unit, onSave: (String, Int, String, Int) -> Boolean) {
    var shop by remember { mutableStateOf(initial?.shopId ?: data.shops.firstOrNull()?.id.orEmpty()) }
    var number by remember { mutableStateOf(initial?.number?.toString().orEmpty()) }
    var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    var capacity by remember { mutableStateOf(initial?.capacity?.takeIf { it > 0 }?.toString().orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { SmartText("Stanok") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TpChoice("Sex", shop, data.shops.filterNot { it.archived }, { it.id }, { it.name }) { shop = it }
        TpField(number, { number = digitsOnly(it) }, "Zavod bo‘yicha stanok raqami", KeyboardType.Number)
        TpField(capacity, { capacity = digitsOnly(it) }, "Stanok sig‘imi (masalan 60/90/120)", KeyboardType.Number)
        TpField(name, { name = it }, "Qo‘shimcha nom (ixtiyoriy)")
    } }, confirmButton = { TextButton(onClick = {
        val parsedNumber = number.toIntOrNull(); val parsedCapacity = capacity.toIntOrNull()
        if (parsedNumber != null && parsedCapacity != null && onSave(shop, parsedNumber, name, parsedCapacity)) onDismiss()
    }) { SmartText("Saqlash") } }, dismissButton = { TextButton(onClick = onDismiss) { SmartText("Bekor qilish") } })
}

@Composable
private fun TpShiftDialog(initial: TpShift, onDismiss: () -> Unit, onSave: (String, String, String, List<String>) -> Boolean) {
    var name by remember { mutableStateOf(initial.name) }; var start by remember { mutableStateOf(initial.startTime) }; var end by remember { mutableStateOf(initial.endTime) }
    var rounds by remember { mutableStateOf(initial.roundTimes.joinToString(", ")) }
    AlertDialog(onDismissRequest = onDismiss, title = { SmartText("Smena va raundlar") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TpField(name, { name = it }, "Smena nomi"); TpField(start, { start = it }, "Boshlanish HH:MM"); TpField(end, { end = it }, "Tugash HH:MM")
        TpField(rounds, { rounds = it }, "Raund vaqtlari (vergul bilan)")
    } }, confirmButton = { TextButton(onClick = { if (onSave(name, start, end, rounds.split(',').map { it.trim() }.filter { it.isNotBlank() })) onDismiss() }) { SmartText("Saqlash") } }, dismissButton = { TextButton(onClick = onDismiss) { SmartText("Bekor qilish") } })
}

@Composable
private fun TpWorkersMaster(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var dialog by remember { mutableStateOf<TpWorker?>(null) }
    var add by remember { mutableStateOf(false) }
    var editTarget by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMasterDataScreen-screen-4")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TpCard {
            SmartText("Umumiy kunlik norma", fontWeight = FontWeight.Bold)
            SmartText("${data.globalDailyTargetAmount()} so‘m — barcha TP/Seryo ishchilariga bir xil qo‘llanadi")
            SmartText("Ish vaqti har bir brigadaning smena boshlanish/tugash vaqtidan avtomatik olinadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (canWrite) OutlinedButton(onClick = { editTarget = true }, Modifier.fillMaxWidth()) { SmartText("Normani o‘zgartirish") }
        }
        if (canWrite) Button(onClick = { add = true }, Modifier.fillMaxWidth()) { SmartText("+ Xodim") }
        data.workers.filterNot { it.archived }.sortedBy { it.name }.forEach { worker ->
            TpCard(Modifier.clickable(enabled = canWrite) { dialog = worker }) {
                SmartText(worker.name, fontWeight = FontWeight.Bold)
                SmartText(data.brigades.firstOrNull { it.id == worker.brigadeId }?.name.orEmpty())
                SmartText("Smena normasi ${data.workerStandardMinutes(worker.id)} daqiqa • umumiy kunlik norma ${data.globalDailyTargetAmount()} so‘m")
            }
        }
        TpError(error)
    }
    if (add || dialog != null) TpWorkerDialog(data, dialog, { add = false; dialog = null }) { brigade, name ->
        val result = dialog?.let { repo.updateWorker(it.id, brigade, name) } ?: repo.addWorker(brigade, name)
        error = result.exceptionOrNull()?.message
        if (result.isSuccess) { add = false; dialog = null; refresh() }
        result.isSuccess
    }
    if (editTarget) {
        var value by remember { mutableStateOf(data.globalDailyTargetAmount().toString()) }
        AlertDialog(
            onDismissRequest = { editTarget = false },
            title = { SmartText("Umumiy kunlik norma") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TpField(value, { value = digitsOnly(it) }, "Kunlik norma (so‘m)", KeyboardType.Number)
                SmartText("Bu qiymat barcha TP/Seryo ishchilariga bir xil qo‘llanadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } },
            confirmButton = { TextButton(onClick = {
                val parsed = value.toLongOrNull()
                val result: Result<Unit> = if (parsed != null) repo.updateDailyTargetAmount(parsed)
                else Result.failure(IllegalArgumentException("Kunlik normani kiriting"))
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { editTarget = false; refresh() }
            }) { SmartText("Saqlash") } },
            dismissButton = { TextButton(onClick = { editTarget = false }) { SmartText("Bekor qilish") } }
        )
    }
}

@Composable
private fun TpWorkerDialog(data: TpData, initial: TpWorker?, onDismiss: () -> Unit, onSave: (String, String) -> Boolean) {
    var brigade by remember { mutableStateOf(initial?.brigadeId ?: data.brigades.firstOrNull()?.id.orEmpty()) }
    var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    val selectedBrigade = data.brigades.firstOrNull { it.id == brigade }
    val shift = data.shifts.firstOrNull { it.id == selectedBrigade?.shiftId }
    AlertDialog(onDismissRequest = onDismiss, title = { SmartText("Xodim") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TpChoice("Brigada", brigade, data.brigades.filterNot { it.archived }, { it.id }, { it.name }) { brigade = it }
        TpField(name, { name = it }, "Ism")
        SmartText("Standart ish vaqti brigada smenasidan avtomatik olinadi: ${shift?.startTime ?: "—"}–${shift?.endTime ?: "—"} (${shift?.durationMinutes() ?: 0} daqiqa)", color = MaterialTheme.colorScheme.onSurfaceVariant)
        SmartText("Kunlik norma ishchida alohida saqlanmaydi: ${data.globalDailyTargetAmount()} so‘m umumiy norma ishlatiladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    } }, confirmButton = { TextButton(onClick = { if (onSave(brigade, name)) onDismiss() }) { SmartText("Saqlash") } }, dismissButton = { TextButton(onClick = onDismiss) { SmartText("Bekor qilish") } })
}

@Composable
private fun TpPricesMaster(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var percent by remember { mutableStateOf("") }; var message by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMasterDataScreen-screen-6")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SmartText("Barcha ${data.products.sumOf { it.details.size }} ta detalning jim narxini bitta harakat bilan o‘zgartirish.", fontWeight = FontWeight.Bold)
        SmartText("Masalan 10 yozilsa barcha narx 10% oshadi. -5 yozilsa 5% kamayadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        TpField(percent, { raw -> percent = raw.filter { it.isDigit() || it == '-' || it == '.' || it == ',' }.replace(',', '.') }, "Foiz", KeyboardType.Decimal, enabled = canWrite)
        Button(enabled = canWrite, onClick = {
            val result = percent.toDoubleOrNull()?.let(repo::increaseAllDetailPrices) ?: Result.failure(IllegalArgumentException("Foizni kiriting"))
            message = result.exceptionOrNull()?.message ?: "Narxlar yangilandi"
            if (result.isSuccess) { percent = ""; refresh() }
        }, modifier = Modifier.fillMaxWidth()) { SmartText("Barcha narxni o‘zgartirish") }
        if (!message.isNullOrBlank()) SmartText(message!!, color = if (message == "Narxlar yangilandi") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
    }
}
