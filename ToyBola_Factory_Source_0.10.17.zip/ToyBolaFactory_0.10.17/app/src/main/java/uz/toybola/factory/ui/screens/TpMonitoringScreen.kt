package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate

private enum class TpMonitorPage { ROOT, WORKERS, MACHINES, MATERIALS }

/**
 * Rahbariyat monitoringi: umumiy xulosa -> guruh -> aniq obyekt.
 * Bosh ekranda faqat qaror uchun kerakli signal, ichkarida esa sabab va tarix ko‘rinadi.
 */
@Composable
fun TpMonitoringScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val revision by TpDataEvents.revision.collectAsState()
    val policy = remember(revision) { AccessGuard(context).currentPolicy() }
    val data = remember(revision, policy.revision) { repository.load().scopedFor(policy) }
    val today = LocalDate.now().toString()

    var page by remember { mutableStateOf(TpMonitorPage.ROOT) }
    var selectedBrigadeId by remember { mutableStateOf<String?>(null) }
    var selectedWorkerId by remember { mutableStateOf<String?>(null) }
    var selectedShopId by remember { mutableStateOf<String?>(null) }
    var selectedMachineId by remember { mutableStateOf<String?>(null) }
    var selectedMaterialId by remember { mutableStateOf<String?>(null) }

    fun backOne() {
        when {
            selectedWorkerId != null -> selectedWorkerId = null
            selectedBrigadeId != null -> selectedBrigadeId = null
            selectedMachineId != null -> selectedMachineId = null
            selectedShopId != null -> selectedShopId = null
            selectedMaterialId != null -> selectedMaterialId = null
            page != TpMonitorPage.ROOT -> page = TpMonitorPage.ROOT
            else -> onBack()
        }
    }
    BackHandler { backOne() }

    val title = when (page) {
        TpMonitorPage.ROOT -> "Monitoring"
        TpMonitorPage.WORKERS -> "Monitoring • Ishchilar"
        TpMonitorPage.MACHINES -> "Monitoring • Stanoklar"
        TpMonitorPage.MATERIALS -> "Monitoring • Seryo"
    }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(title, canGoBack = true, onMenu = {}, onBack = ::backOne)
        Column(
            Modifier.fillMaxSize()
                .verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-${page.name}-${selectedBrigadeId}-${selectedWorkerId}-${selectedShopId}-${selectedMachineId}-${selectedMaterialId}"))
                .navigationBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when (page) {
                TpMonitorPage.ROOT -> TpMonitoringRoot(data, today, onWorkers = { page = TpMonitorPage.WORKERS }, onMachines = { page = TpMonitorPage.MACHINES }, onMaterials = { page = TpMonitorPage.MATERIALS })
                TpMonitorPage.WORKERS -> TpWorkersMonitoring(data, today, selectedBrigadeId, selectedWorkerId,
                    onBrigade = { selectedBrigadeId = it }, onWorker = { selectedWorkerId = it })
                TpMonitorPage.MACHINES -> TpMachinesMonitoring(data, today, selectedShopId, selectedMachineId,
                    onShop = { selectedShopId = it }, onMachine = { selectedMachineId = it })
                TpMonitorPage.MATERIALS -> TpMaterialsMonitoring(data, today, selectedMaterialId, onMaterial = { selectedMaterialId = it })
            }
        }
    }
}

@Composable
private fun TpMonitoringRoot(data: TpData, today: String, onWorkers: () -> Unit, onMachines: () -> Unit, onMaterials: () -> Unit) {
    val attendanceToday = data.attendance.filter { it.date == today }
    val absent = attendanceToday.count { !it.present }
    val minus = attendanceToday.count { it.present && it.minusHours > 0 }
    val activeJobs = data.jobs.count { it.status == TpJobStatus.IN_PROGRESS }
    val idleMachines = data.machines.count { machine -> !machine.archived && data.activeJobsForMachine(machine.id).isEmpty() }
    val downtimeMinutes = data.machineDowntimes.filter { it.date == today }.sumOf { it.durationMinutes() }
    val pendingMaterial = data.jobs.count { it.resinConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED && it.status != TpJobStatus.COMPLETE }
    val shortageCount = data.jobs.count { job ->
        job.resinConfirmedAt != null && job.status != TpJobStatus.COMPLETE && data.materialStock(TpMaterialType.RESIN, job.resinCode) < job.requiredResinKg
    }

    SmartText("Bugungi umumiy holat", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    val attention = buildList {
        if (absent > 0) add("$absent ishchi ishlamadi")
        if (downtimeMinutes > 0) add("Stanok to‘xtashi ${minutesLabel(downtimeMinutes)}")
        if (shortageCount > 0) add("$shortageCount seryoda yetishmovchilik")
        if (pendingMaterial > 0) add("$pendingMaterial qorishma/yetkazish kutilmoqda")
    }
    if (attention.isNotEmpty()) {
        Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.errorContainer) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                SmartText("E’tibor talab qiladi", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                attention.forEach { SmartText("• $it", color = MaterialTheme.colorScheme.onErrorContainer) }
            }
        }
    }

    MonitorSectionCard("1. Ishchilar", "${data.workers.count { !it.archived }} ishchi • $absent ishlamadi • $minus minus-soat", onWorkers)
    MonitorSectionCard("2. Stanoklar", "${data.machines.count { !it.archived }} stanok • $activeJobs ishda • $idleMachines bo‘sh", onMachines)
    MonitorSectionCard("3. Seryo bo‘limi", "$pendingMaterial tayyorlash/yetkazish • $shortageCount yetishmovchilik", onMaterials)
}

@Composable
private fun MonitorSectionCard(title: String, summary: String, onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                SmartText(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                SmartText(summary, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            SmartText("›", style = MaterialTheme.typography.headlineSmall)
        }
    }
}

@Composable
private fun TpWorkersMonitoring(
    data: TpData, today: String, brigadeId: String?, workerId: String?,
    onBrigade: (String) -> Unit, onWorker: (String) -> Unit
) {
    if (workerId != null) {
        val worker = data.workers.firstOrNull { it.id == workerId } ?: return
        val day = data.attendance.firstOrNull { it.workerId == worker.id && it.date == today }
        val receipts = data.receipts.filter { it.workerId == worker.id && it.date == today }
        val rounds = data.qualityRounds.filter { it.workerId == worker.id && it.date == today }
        val earned = receipts.sumOf { it.earnedAmount }
        val quality = rounds.map { it.score }.takeIf { it.isNotEmpty() }?.average()
        val efficiency = data.workerEfficiency(worker.id, today)
        SmartText(worker.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        TpCard {
            SmartText("Davomat: ${when { day == null -> "Belgilanmagan"; !day.present -> "Ishlamadi"; day.minusHours > 0 -> "Minus ${formatTpNumber(day.minusHours)} soat"; else -> "To‘liq ishladi" }}")
            SmartText("Hisobdagi vaqt: ${minutesLabel(data.attendanceWorkMinutes(worker.id, today))}")
            SmartText("Topgan summa: $earned so‘m")
            SmartText("Samaradorlik: ${efficiency?.toInt()?.let { "$it%" } ?: "—"}")
            SmartText("Sifat: ${quality?.toInt()?.let { "$it%" } ?: "—"}")
        }
        SmartText("Bugungi qabul", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (receipts.isEmpty()) SmartText("Qabul yozuvi yo‘q.")
        receipts.sortedByDescending { it.createdAt }.forEach { row ->
            val machine = data.machines.firstOrNull { it.id == row.machineId }
            TpCard { SmartText("${machine?.number ?: 0}-stanok • ${row.detailNameSnapshot}", fontWeight = FontWeight.Bold); SmartText("${row.creditedPieces} dona • ${row.earnedAmount} so‘m") }
        }
        return
    }

    if (brigadeId != null) {
        val brigade = data.brigades.firstOrNull { it.id == brigadeId } ?: return
        val workers = data.workers.filter { !it.archived && it.brigadeId == brigade.id }.sortedBy { it.name }
        SmartText(brigade.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        workers.forEach { worker ->
            val day = data.attendance.firstOrNull { it.workerId == worker.id && it.date == today }
            val efficiency = data.workerEfficiency(worker.id, today)
            val quality = data.workerQuality(worker.id, today)
            MonitorSectionCard(worker.name, "${if (day?.present == false) "Ishlamadi" else "${data.attendanceWorkMinutes(worker.id, today)} daq"} • Samaradorlik ${efficiency?.toInt()?.let { "$it%" } ?: "—"} • Sifat ${quality?.toInt()?.let { "$it%" } ?: "—"}") { onWorker(worker.id) }
        }
        return
    }

    val workers = data.workers.filterNot { it.archived }
    val present = workers.count { worker -> data.attendance.firstOrNull { it.workerId == worker.id && it.date == today }?.present != false }
    val absent = workers.size - present
    val effs = workers.mapNotNull { data.workerEfficiency(it.id, today) }
    val qualities = workers.mapNotNull { data.workerQuality(it.id, today) }
    SmartText("Umumiy xulosa", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    TpCard {
        SmartText("Jami ${workers.size} • Ishda $present • Ishlamadi $absent")
        SmartText("O‘rtacha samaradorlik: ${if (effs.isEmpty()) "—" else "${effs.average().toInt()}%"}")
        SmartText("O‘rtacha sifat: ${if (qualities.isEmpty()) "—" else "${qualities.average().toInt()}%"}")
    }
    SmartText("Brigadalar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    data.brigades.filterNot { it.archived }.sortedBy { it.name }.forEach { brigade ->
        val rows = workers.filter { it.brigadeId == brigade.id }
        val a = rows.count { w -> data.attendance.firstOrNull { it.workerId == w.id && it.date == today }?.present == false }
        val e = rows.mapNotNull { data.workerEfficiency(it.id, today) }
        MonitorSectionCard(brigade.name, "${rows.size} ishchi • $a ishlamadi • Samaradorlik ${if (e.isEmpty()) "—" else "${e.average().toInt()}%"}") { onBrigade(brigade.id) }
    }
}

@Composable
private fun TpMachinesMonitoring(
    data: TpData, today: String, shopId: String?, machineId: String?,
    onShop: (String) -> Unit, onMachine: (String) -> Unit
) {
    if (machineId != null) {
        val machine = data.machines.firstOrNull { it.id == machineId } ?: return
        val shop = data.shops.firstOrNull { it.id == machine.shopId }
        val jobs = data.activeJobsForMachine(machine.id)
        val downtimes = data.machineDowntimes.filter { it.machineId == machine.id }.sortedWith(compareByDescending<TpMachineDowntime> { it.date }.thenByDescending { it.stoppedAt })
        SmartText("${machine.number}-stanok • ${shop?.name.orEmpty()}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        if (jobs.isEmpty()) TpCard { SmartText("Holat: Bo‘sh", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }
        else jobs.forEach { job ->
            val order = data.orders.firstOrNull { it.id == job.orderId }
            TpCard {
                SmartText("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.Bold)
                SmartText("${job.outputs.joinToString { it.detailName }} • rang ${job.colorCode}")
                SmartText("Qolgan reja vaqti: ${minutesLabel(job.estimatedMinutes)}")
                SmartText("Seryo: ${job.resinCode} • ${materialStatusLabel(job.materialStatus)}")
            }
        }
        SmartText("O‘chishlar tarixi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (downtimes.isEmpty()) SmartText("O‘chish qaydi yo‘q.")
        downtimes.take(30).forEach { row -> TpCard { SmartText("${row.date} • ${row.stoppedAt}–${row.resumedAt}", fontWeight = FontWeight.Bold); SmartText("${minutesLabel(row.durationMinutes())} • ${row.note}") } }
        return
    }

    if (shopId != null) {
        val shop = data.shops.firstOrNull { it.id == shopId } ?: return
        val machines = data.machines.filter { !it.archived && it.shopId == shop.id }
        val ordered = machines.sortedWith(compareBy<TpMachine> { if (data.activeJobsForMachine(it.id).isEmpty()) 1 else 0 }.thenBy { it.number })
        SmartText(shop.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        ordered.forEach { machine ->
            val jobs = data.activeJobsForMachine(machine.id)
            val downtimeToday = data.machineDowntimes.filter { it.machineId == machine.id && it.date == today }.sumOf { it.durationMinutes() }
            val summary = if (jobs.isEmpty()) "Bo‘sh" else "${jobs.size} vazifa • ${minutesLabel(jobs.sumOf { it.estimatedMinutes })} ish"
            MonitorSectionCard("${machine.number}-stanok", "$summary${if (downtimeToday > 0) " • To‘xtash ${minutesLabel(downtimeToday)}" else ""}") { onMachine(machine.id) }
        }
        return
    }

    val machines = data.machines.filterNot { it.archived }
    val active = machines.count { data.activeJobsForMachine(it.id).isNotEmpty() }
    val idle = machines.size - active
    val downtime = data.machineDowntimes.filter { it.date == today }.sumOf { it.durationMinutes() }
    val lowQueue = machines.count { machine -> data.activeJobsForMachine(machine.id).sumOf { it.estimatedMinutes } in 1..(18 * 60) }
    TpCard { SmartText("Jami ${machines.size} • Ishda $active • Bo‘sh $idle"); SmartText("Bugungi to‘xtash: ${minutesLabel(downtime)} • 18 soatdan kam ishli: $lowQueue") }
    SmartText("Sexlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    data.shops.filterNot { it.archived }.sortedBy { it.name }.forEach { shop ->
        val rows = machines.filter { it.shopId == shop.id }
        val a = rows.count { data.activeJobsForMachine(it.id).isNotEmpty() }
        MonitorSectionCard(shop.name, "${rows.size} stanok • $a ishda • ${rows.size - a} bo‘sh") { onShop(shop.id) }
    }
}

@Composable
private fun TpMaterialsMonitoring(data: TpData, today: String, materialId: String?, onMaterial: (String) -> Unit) {
    if (materialId != null) {
        val material = data.materials.firstOrNull { it.id == materialId } ?: return
        SmartText("${material.code} • ${material.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        TpCard {
            SmartText("Hozirgi ostatka: ${formatTpNumber(material.currentStock())}")
            SmartText("Bugungi prixod: ${formatTpNumber(material.dayIncoming(today))}")
            SmartText("Bugungi rasxod: ${formatTpNumber(material.dayOutgoing(today))}")
        }
        SmartText("Oxirgi harakatlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        material.movements.sortedByDescending { it.createdAt }.take(40).forEach { row ->
            TpCard { SmartText("${row.createdAt.take(16).replace('T', ' ')} • ${if (row.kind == TpMaterialMovementKind.IN) "Prixod" else "Rasxod"}", fontWeight = FontWeight.Bold); SmartText("${if (row.kind == TpMaterialMovementKind.IN) "+" else "-"}${formatTpNumber(row.amount)} • ${row.note}") }
        }
        return
    }

    val materials = data.materials.filterNot { it.archived }
    val pending = data.jobs.count { it.resinConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED && it.status != TpJobStatus.COMPLETE }
    val shortages = data.jobs.filter { it.resinConfirmedAt != null && it.status != TpJobStatus.COMPLETE }
        .count { data.materialStock(TpMaterialType.RESIN, it.resinCode) < it.requiredResinKg }
    val incoming = materials.sumOf { it.dayIncoming(today) }
    val outgoing = materials.sumOf { it.dayOutgoing(today) }
    TpCard { SmartText("Tayyorlash/yetkazish: $pending • Yetishmovchilik: $shortages"); SmartText("Bugungi prixod ${formatTpNumber(incoming)} • rasxod ${formatTpNumber(outgoing)}") }
    SmartText("Seryo va krasitel", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    materials.sortedWith(compareBy<TpMaterial> { it.type.name }.thenBy { it.code }).forEach { material ->
        val type = if (material.type == TpMaterialType.RESIN) "Seryo" else "Krasitel"
        MonitorSectionCard("${material.code} • $type", "Ostatka ${formatTpNumber(material.currentStock())} • Bugun -${formatTpNumber(material.dayOutgoing(today))}") { onMaterial(material.id) }
    }
}
