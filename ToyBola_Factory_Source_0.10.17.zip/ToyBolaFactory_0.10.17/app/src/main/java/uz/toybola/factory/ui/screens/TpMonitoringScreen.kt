package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate

private enum class TpMonitoringPage { ROOT, WORKERS, MACHINES, MATERIALS }

@Composable
fun TpMonitoringScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val revision by TpDataEvents.revision.collectAsState()
    val policy = remember(revision) { AccessGuard(context).currentPolicy() }
    val data = remember(revision, policy.revision) { repository.load().scopedFor(policy) }
    var page by remember { mutableStateOf(TpMonitoringPage.ROOT) }
    var from by remember { mutableStateOf(LocalDate.now().withDayOfMonth(1).toString()) }
    var to by remember { mutableStateOf(LocalDate.now().toString()) }
    var brigadeId by remember { mutableStateOf("") }
    var workerId by remember { mutableStateOf("") }
    var shopId by remember { mutableStateOf("") }
    var machineId by remember { mutableStateOf("") }
    var materialType by remember { mutableStateOf(TpMaterialType.RESIN) }
    var materialCode by remember { mutableStateOf("") }

    fun goBack() {
        when {
            workerId.isNotBlank() -> workerId = ""
            page == TpMonitoringPage.WORKERS && brigadeId.isNotBlank() -> brigadeId = ""
            machineId.isNotBlank() -> machineId = ""
            page == TpMonitoringPage.MACHINES && shopId.isNotBlank() -> shopId = ""
            page == TpMonitoringPage.MATERIALS && materialCode.isNotBlank() -> materialCode = ""
            page != TpMonitoringPage.ROOT -> page = TpMonitoringPage.ROOT
            else -> onBack()
        }
    }
    BackHandler { goBack() }

    val title = when (page) {
        TpMonitoringPage.ROOT -> "Monitoring"
        TpMonitoringPage.WORKERS -> "Monitoring • Ishchilar"
        TpMonitoringPage.MACHINES -> "Monitoring • Stanoklar"
        TpMonitoringPage.MATERIALS -> "Monitoring • Seryo bo‘limi"
    }
    Column(Modifier.fillMaxSize()) {
        AppTopBar(title, canGoBack = true, onMenu = {}, onBack = ::goBack)
        when (page) {
            TpMonitoringPage.ROOT -> TpMonitoringRoot(data) { page = it }
            TpMonitoringPage.WORKERS -> TpWorkersMonitoring(data, from, to, { from = it }, { to = it }, brigadeId, { brigadeId = it; workerId = "" }, workerId, { workerId = it })
            TpMonitoringPage.MACHINES -> TpMachinesMonitoring(data, from, to, { from = it }, { to = it }, shopId, { shopId = it; machineId = "" }, machineId, { machineId = it })
            TpMonitoringPage.MATERIALS -> TpMaterialsMonitoring(data, from, to, { from = it }, { to = it }, materialType, { materialType = it; materialCode = "" }, materialCode, { materialCode = it })
        }
    }
}

@Composable
private fun TpMonitoringRoot(data: TpData, onOpen: (TpMonitoringPage) -> Unit) {
    val today = LocalDate.now().toString()
    val activeJobs = data.jobs.filter { it.status == TpJobStatus.IN_PROGRESS }
    val idleMachines = data.machines.count { !it.archived && data.activeJobsForMachine(it.id).isEmpty() }
    val stoppedToday = data.machines.sumOf { machine -> machine.downtimes.count { it.date == today } }
    val absent = data.attendance.count { it.date == today && !it.present }
    val minus = data.attendance.count { it.date == today && it.present && it.minusHours > 0.0 }
    val lowMaterials = data.materials.count { !it.archived && it.currentStock() <= 0.0 }
    val pendingMaterial = data.jobs.count { it.resinConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED && it.status != TpJobStatus.COMPLETE }

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-root"))
            .navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (stoppedToday + absent + lowMaterials > 0) {
            Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.errorContainer.copy(alpha = .55f)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("E’tibor talab qiladi", fontWeight = FontWeight.Bold)
                    if (stoppedToday > 0) Text("• Bugun $stoppedToday ta stanok o‘chish holati kiritilgan")
                    if (absent > 0) Text("• $absent ishchi ishlamadi")
                    if (lowMaterials > 0) Text("• $lowMaterials seryo/krasitel qoldig‘i 0 yoki manfiy")
                }
            }
        }
        TpMonitorSectionCard(
            title = "1. Ishchilar",
            summary = "${data.workers.count { !it.archived }} ishchi • bugun $absent ishlamadi • $minus minus soat",
            onClick = { onOpen(TpMonitoringPage.WORKERS) }
        )
        TpMonitorSectionCard(
            title = "2. Stanoklar",
            summary = "${activeJobs.mapNotNull { it.machineId }.distinct().size} ishlayapti • $idleMachines ishsiz • bugun $stoppedToday o‘chish",
            onClick = { onOpen(TpMonitoringPage.MACHINES) }
        )
        TpMonitorSectionCard(
            title = "3. Seryo bo‘limi",
            summary = "$pendingMaterial tayyorlash/yetkazish kutilmoqda • $lowMaterials kritik qoldiq",
            onClick = { onOpen(TpMonitoringPage.MATERIALS) }
        )
        Text("Har bir bo‘limda umumiy natijadan brigada/sex va aniq ishchi, stanok yoki seryo kodigacha bosqichma-bosqich kirib boriladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun TpMonitorSectionCard(title: String, summary: String, onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(18.dp), tonalElevation = 2.dp) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(summary, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("›", style = MaterialTheme.typography.headlineMedium)
        }
    }
}

@Composable
private fun TpMonitorDateRange(from: String, to: String, onFrom: (String) -> Unit, onTo: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.weight(1f)) { TpField(from, onFrom, "Boshlanish") }
        Box(Modifier.weight(1f)) { TpField(to, onTo, "Tugash") }
    }
}

@Composable
private fun TpWorkersMonitoring(
    data: TpData, from: String, to: String, onFrom: (String) -> Unit, onTo: (String) -> Unit,
    brigadeId: String, onBrigade: (String) -> Unit, workerId: String, onWorker: (String) -> Unit
) {
    val brigades = data.brigades.filterNot { it.archived }.sortedBy { it.name }
    val selectedBrigade = brigades.firstOrNull { it.id == brigadeId }
    val selectedWorker = data.workers.firstOrNull { it.id == workerId }
    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-workers-$brigadeId-$workerId"))
            .navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        TpMonitorDateRange(from, to, onFrom, onTo)
        when {
            selectedWorker != null -> {
                val attendance = data.attendance.filter { it.workerId == selectedWorker.id && it.date in from..to }
                val quality = data.qualityRounds.filter { it.workerId == selectedWorker.id && it.date in from..to }
                val piece = data.receipts.filter { it.workerId == selectedWorker.id && it.date in from..to }.sumOf { it.earnedAmount }
                val overtime = selectedWorker.overtimeEntries.filter { it.date in from..to }.sumOf { it.earnedAmount }
                Text(selectedWorker.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                TpCard { Text("Jami topdi: ${piece + overtime} so‘m", fontWeight = FontWeight.Bold); Text("Mahsulot: $piece so‘m • Qo‘shimcha soat: $overtime so‘m") }
                TpCard { Text("Davomat", fontWeight = FontWeight.Bold); Text("Ishlagan kun: ${attendance.count { it.present }} • Ishlamagan: ${attendance.count { !it.present }} • Minus soatli: ${attendance.count { it.present && it.minusHours > 0 }}") }
                TpCard { Text("Sifat", fontWeight = FontWeight.Bold); Text(if (quality.isEmpty()) "Baholash yo‘q" else "O‘rtacha ${quality.map { it.score }.average().toInt()}% • ${quality.size} raund") }
                selectedWorker.overtimeEntries.filter { it.date in from..to }.sortedByDescending { it.date }.forEach { row ->
                    Text("${row.date} • ${row.typeNameSnapshot} • ${formatTpNumber(row.hours)} soat • ${row.earnedAmount} so‘m", style = MaterialTheme.typography.bodySmall)
                }
            }
            selectedBrigade != null -> {
                Text(selectedBrigade.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                val workers = data.workers.filter { !it.archived && it.brigadeId == selectedBrigade.id }.sortedBy { it.name }
                workers.forEach { worker ->
                    val earned = data.workerEarned(worker.id, from, to)
                    val quality = data.qualityRounds.filter { it.workerId == worker.id && it.date in from..to }.map { it.score }
                    TpCard(Modifier.clickable { onWorker(worker.id) }) {
                        Text(worker.name, fontWeight = FontWeight.Bold)
                        Text("Topdi: $earned so‘m • Sifat: ${if (quality.isEmpty()) "—" else "${quality.average().toInt()}%"}")
                    }
                }
            }
            else -> {
                Text("Brigadalar", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                brigades.forEach { brigade ->
                    val workers = data.workers.filter { !it.archived && it.brigadeId == brigade.id }
                    val earned = workers.sumOf { data.workerEarned(it.id, from, to) }
                    val absent = data.attendance.count { it.brigadeId == brigade.id && it.date in from..to && !it.present }
                    TpCard(Modifier.clickable { onBrigade(brigade.id) }) {
                        Text(brigade.name, fontWeight = FontWeight.Bold)
                        Text("${workers.size} ishchi • $earned so‘m • ishlamagan yozuvlar: $absent")
                    }
                }
            }
        }
    }
}

@Composable
private fun TpMachinesMonitoring(
    data: TpData, from: String, to: String, onFrom: (String) -> Unit, onTo: (String) -> Unit,
    shopId: String, onShop: (String) -> Unit, machineId: String, onMachine: (String) -> Unit
) {
    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    val selectedShop = shops.firstOrNull { it.id == shopId }
    val selectedMachine = data.machines.firstOrNull { it.id == machineId }
    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-machines-$shopId-$machineId"))
            .navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        TpMonitorDateRange(from, to, onFrom, onTo)
        when {
            selectedMachine != null -> {
                val jobs = data.activeJobsForMachine(selectedMachine.id)
                val stops = selectedMachine.downtimes.filter { it.date in from..to }.sortedByDescending { it.stoppedAt }
                Text("${selectedMachine.number}-stanok", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                TpCard { Text(if (jobs.isEmpty()) "Hozir ishsiz" else "Faol vazifalar: ${jobs.size}", fontWeight = FontWeight.Bold); Text("Davrdagi o‘chish: ${stops.size} marta • ${stops.sumOf { it.durationMinutes() }} daqiqa") }
                jobs.forEach { job ->
                    val order = data.orders.firstOrNull { it.id == job.orderId }
                    TpCard { Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.Bold); Text("${job.outputs.map { it.detailName }.distinct().joinToString()} • ${job.colorCode} • ${minutesLabel(job.estimatedMinutes)}") }
                }
                if (stops.isNotEmpty()) Text("O‘chish sabablari", fontWeight = FontWeight.Bold)
                stops.forEach { stop -> Text("${stop.stoppedAt.take(16).replace('T',' ')} → ${stop.restartedAt.take(16).replace('T',' ')} • ${stop.durationMinutes()} daq. • ${stop.note}") }
            }
            selectedShop != null -> {
                Text(selectedShop.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                data.machines.filter { !it.archived && it.shopId == selectedShop.id }.sortedBy { it.number }.forEach { machine ->
                    val jobs = data.activeJobsForMachine(machine.id)
                    val stopMinutes = data.machineDowntimeMinutes(machine.id, from, to)
                    TpCard(Modifier.clickable { onMachine(machine.id) }) {
                        Text("${machine.number}-stanok", fontWeight = FontWeight.Bold)
                        Text(if (jobs.isEmpty()) "Ishsiz" else "${jobs.size} vazifa • qolgan ${minutesLabel(jobs.sumOf { it.estimatedMinutes })}")
                        if (stopMinutes > 0) Text("O‘chish: $stopMinutes daqiqa", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
            else -> {
                Text("Sexlar", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                shops.forEach { shop ->
                    val machines = data.machines.filter { !it.archived && it.shopId == shop.id }
                    val working = machines.count { data.activeJobsForMachine(it.id).isNotEmpty() }
                    val stopped = machines.sumOf { data.machineDowntimeMinutes(it.id, from, to) }
                    TpCard(Modifier.clickable { onShop(shop.id) }) {
                        Text(shop.name, fontWeight = FontWeight.Bold)
                        Text("${machines.size} stanok • $working zakazli • ${machines.size - working} ishsiz • o‘chish $stopped daqiqa")
                    }
                }
            }
        }
    }
}

@Composable
private fun TpMaterialsMonitoring(
    data: TpData, from: String, to: String, onFrom: (String) -> Unit, onTo: (String) -> Unit,
    type: TpMaterialType, onType: (TpMaterialType) -> Unit, code: String, onCode: (String) -> Unit
) {
    val selected = data.materials.firstOrNull { it.code == code && it.type == type }
    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-materials-${type.name}-$code"))
            .navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        TpMonitorDateRange(from, to, onFrom, onTo)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = type == TpMaterialType.RESIN, onClick = { onType(TpMaterialType.RESIN) }, label = { Text("Seryo") }, modifier = Modifier.weight(1f))
            FilterChip(selected = type == TpMaterialType.COLOR, onClick = { onType(TpMaterialType.COLOR) }, label = { Text("Krasitel") }, modifier = Modifier.weight(1f))
        }
        if (selected != null) {
            val movements = selected.movements.filter { it.createdAt.take(10) in from..to }.sortedByDescending { it.createdAt }
            val incoming = movements.filter { it.kind == TpMaterialMovementKind.IN }.sumOf { it.amount }
            val outgoing = movements.filter { it.kind == TpMaterialMovementKind.OUT }.sumOf { it.amount }
            Text(selected.code, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            TpCard { Text("Hozirgi ostatka: ${formatTpNumber(selected.currentStock())}", fontWeight = FontWeight.Bold); Text("Davr prixod: ${formatTpNumber(incoming)} • rasxod: ${formatTpNumber(outgoing)}") }
            movements.forEach { row -> Text("${row.createdAt.take(16).replace('T',' ')} • ${if (row.kind == TpMaterialMovementKind.IN) "Prixod" else "Rasxod"} ${formatTpNumber(row.amount)}${row.note.takeIf { it.isNotBlank() }?.let { " • $it" }.orEmpty()}") }
        } else {
            val rows = data.materials.filter { !it.archived && it.type == type }.sortedBy { it.code }
            if (rows.isEmpty()) Text("Ma’lumot yo‘q.")
            rows.forEach { material ->
                val movements = material.movements.filter { it.createdAt.take(10) in from..to }
                val incoming = movements.filter { it.kind == TpMaterialMovementKind.IN }.sumOf { it.amount }
                val outgoing = movements.filter { it.kind == TpMaterialMovementKind.OUT }.sumOf { it.amount }
                TpCard(Modifier.clickable { onCode(material.code) }) {
                    Text(material.code, fontWeight = FontWeight.Bold)
                    Text("Ostatka ${formatTpNumber(material.currentStock())} • prixod ${formatTpNumber(incoming)} • rasxod ${formatTpNumber(outgoing)}")
                    if (material.currentStock() <= 0.0) Text("Qoldiq yetarli emas", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}
