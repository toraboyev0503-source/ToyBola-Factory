package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate

private enum class TpMonitoringPage { ROOT, WORKERS, MACHINES, MATERIALS }

@Composable
fun TpMonitoringScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val revision by TpDataEvents.revision.collectAsState()
    val policy = remember(revision) { AccessGuard(context).currentPolicy() }
    val data = remember(revision, policy.revision) { repository.load().scopedFor(policy) }

    var page by remember { mutableStateOf(TpMonitoringPage.ROOT) }
    var from by remember { mutableStateOf(LocalDate.now().toString()) }
    var to by remember { mutableStateOf(LocalDate.now().toString()) }
    var shopFilter by remember { mutableStateOf("") }
    var shiftFilter by remember { mutableStateOf("") }
    var brigadeFilter by remember { mutableStateOf("") }
    var selectedWorkerBrigade by remember { mutableStateOf<String?>(null) }
    var selectedWorker by remember { mutableStateOf<String?>(null) }
    var selectedMachineShop by remember { mutableStateOf<String?>(null) }
    var selectedMachine by remember { mutableStateOf<String?>(null) }
    var selectedMaterial by remember { mutableStateOf<String?>(null) }
    var exportMessage by remember { mutableStateOf<String?>(null) }
    var pendingReport by remember { mutableStateOf<TpReportTable?>(null) }

    fun resetDrill() {
        selectedWorkerBrigade = null
        selectedWorker = null
        selectedMachineShop = null
        selectedMachine = null
        selectedMaterial = null
    }

    fun goBack() {
        when {
            selectedWorker != null -> selectedWorker = null
            selectedWorkerBrigade != null -> selectedWorkerBrigade = null
            selectedMachine != null -> selectedMachine = null
            selectedMachineShop != null -> selectedMachineShop = null
            selectedMaterial != null -> selectedMaterial = null
            page != TpMonitoringPage.ROOT -> { page = TpMonitoringPage.ROOT; resetDrill() }
            else -> onBack()
        }
    }
    BackHandler { goBack() }

    val word = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) { uri ->
        val report = pendingReport
        if (uri != null && report != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { output ->
                MonitoringDocxExporter.write(output, report.title, report.metadata, report.headers, report.rows)
            } ?: error("Fayl ochilmadi")
        }.onSuccess { exportMessage = "Word hisoboti saqlandi" }.onFailure { exportMessage = it.message ?: "Eksport xatosi" }
        pendingReport = null
    }
    val excel = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) { uri ->
        val report = pendingReport
        if (uri != null && report != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { output -> TpXlsxExporter.write(output, report) } ?: error("Fayl ochilmadi")
        }.onSuccess { exportMessage = "Excel hisoboti saqlandi" }.onFailure { exportMessage = it.message ?: "Eksport xatosi" }
        pendingReport = null
    }

    val activeShops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    val activeShifts = data.shifts.filterNot { it.archived }.sortedBy { it.name }
    val filteredBrigades = data.brigades.filter { brigade ->
        !brigade.archived && (shopFilter.isBlank() || brigade.shopId == shopFilter) && (shiftFilter.isBlank() || brigade.shiftId == shiftFilter)
    }.sortedBy { it.name }
    val filteredBrigadeIds = filteredBrigades.filter { brigadeFilter.isBlank() || it.id == brigadeFilter }.map { it.id }.toSet()
    val filteredWorkers = data.workers.filter { !it.archived && it.brigadeId in filteredBrigadeIds }
    val filteredJobs = data.jobs.filter { job -> job.brigadeId == null || job.brigadeId in filteredBrigadeIds }
    val filteredMachineIds = if (shopFilter.isBlank()) {
        val shopIds = filteredBrigades.map { it.shopId }.toSet()
        data.machines.filter { !it.archived && (shopIds.isEmpty() || it.shopId in shopIds) }.map { it.id }.toSet()
    } else data.machines.filter { !it.archived && it.shopId == shopFilter }.map { it.id }.toSet()
    val filteredReceipts = data.receipts.filter { it.date in from..to && it.brigadeId in filteredBrigadeIds }
    val filteredRounds = data.qualityRounds.filter { it.date in from..to && it.brigadeId in filteredBrigadeIds }
    val filteredAttendance = data.attendance.filter { it.date in from..to && it.brigadeId in filteredBrigadeIds }
    val filteredDowntime = data.machineDowntimes.filter { it.date in from..to && it.machineId in filteredMachineIds }
    val reportData = data.copy(
        brigades = filteredBrigades.filter { brigadeFilter.isBlank() || it.id == brigadeFilter },
        workers = filteredWorkers, jobs = filteredJobs, receipts = filteredReceipts, qualityRounds = filteredRounds,
        attendance = filteredAttendance, overtimeEntries = data.overtimeEntries.filter { it.date in from..to && it.brigadeId in filteredBrigadeIds },
        machineDowntimes = filteredDowntime, dailyIssues = data.dailyIssues.filter { it.date in from..to && it.brigadeId in filteredBrigadeIds }
    )
    val report = remember(reportData, from, to) { buildTpReport(reportData, from, to, null) }

    val today = LocalDate.now().toString()
    val focusDate = to.takeIf { runCatching { LocalDate.parse(it) }.isSuccess } ?: today
    val todayAttendance = filteredAttendance.filter { it.date == focusDate }
    val todayFull = filteredWorkers.count { worker -> todayAttendance.firstOrNull { it.workerId == worker.id }.let { day -> day == null || (day.present && day.minusHours <= 0.0) } }
    val todayMinus = filteredWorkers.count { worker -> todayAttendance.firstOrNull { it.workerId == worker.id }?.let { it.present && it.minusHours > 0.0 } == true }
    val todayAbsent = filteredWorkers.count { worker -> todayAttendance.firstOrNull { it.workerId == worker.id }?.present == false }
    val workerEfficiencies = filteredWorkers.mapNotNull { worker -> data.workerEfficiency(worker.id, focusDate) }
    val workerQuality = filteredRounds.filter { it.date == focusDate }.map { it.score }

    val activeMachineJobs = filteredJobs.filter { it.machineId != null && it.machineId in filteredMachineIds && it.status != TpJobStatus.COMPLETE }
    val busyMachineIds = activeMachineJobs.mapNotNull { it.machineId }.toSet()
    val visibleMachines = data.machines.filter { !it.archived && it.id in filteredMachineIds }
    val idleMachineCount = visibleMachines.count { it.id !in busyMachineIds }
    val inProgressMachineCount = visibleMachines.count { machine -> activeMachineJobs.any { it.machineId == machine.id && it.status == TpJobStatus.IN_PROGRESS } }
    val lowQueueMachines = visibleMachines.filter { machine -> activeMachineJobs.filter { it.machineId == machine.id }.sumOf { it.estimatedMinutes.coerceAtLeast(0) } in 1..(18 * 60) }
    val stoppedMachineCount = filteredDowntime.filter { it.date == focusDate }.map { it.machineId }.distinct().size

    val pendingMaterialJobs = filteredJobs.filter { it.planConfirmedAt != null && it.status != TpJobStatus.COMPLETE && it.materialStatus != TpMaterialStatus.DELIVERED }
    val resinNeeds = pendingMaterialJobs.filter { it.resinCode.isNotBlank() }.groupBy { it.resinCode }.mapValues { (_, rows) -> rows.sumOf { it.requiredResinKg } }
    val colorNeeds = pendingMaterialJobs.filter { it.colorCode.isNotBlank() }.groupBy { it.colorCode }.mapValues { (_, rows) -> rows.sumOf { it.requiredColorGrams } }
    val shortageCount = resinNeeds.count { (code, need) -> data.materialStock(TpMaterialType.RESIN, code) + 1e-9 < need } +
        colorNeeds.count { (code, need) -> data.materialStock(TpMaterialType.COLOR, code) + 1e-9 < need }
    val pendingPrepCount = pendingMaterialJobs.count { it.resinConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED }
    val pendingSelectionCount = pendingMaterialJobs.count { it.resinConfirmedAt == null }
    val resinTodayIncoming = data.materials.filter { it.type == TpMaterialType.RESIN }.sumOf { material -> material.movements.filter { it.kind == TpMaterialMovementKind.IN && it.createdAt.take(10) == focusDate }.sumOf { it.amount } }
    val resinTodayOutgoing = data.materials.filter { it.type == TpMaterialType.RESIN }.sumOf { material -> material.movements.filter { it.kind == TpMaterialMovementKind.OUT && it.createdAt.take(10) == focusDate }.sumOf { it.amount } }
    val colorTodayIncoming = data.materials.filter { it.type == TpMaterialType.COLOR }.sumOf { material -> material.movements.filter { it.kind == TpMaterialMovementKind.IN && it.createdAt.take(10) == focusDate }.sumOf { it.amount } }
    val colorTodayOutgoing = data.materials.filter { it.type == TpMaterialType.COLOR }.sumOf { material -> material.movements.filter { it.kind == TpMaterialMovementKind.OUT && it.createdAt.take(10) == focusDate }.sumOf { it.amount } }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(when (page) {
            TpMonitoringPage.ROOT -> "TP monitoring"
            TpMonitoringPage.WORKERS -> "Monitoring • Ishchilar"
            TpMonitoringPage.MACHINES -> "Monitoring • Stanoklar"
            TpMonitoringPage.MATERIALS -> "Monitoring • Seryo"
        }, canGoBack = true, onMenu = {}, onBack = ::goBack)

        Column(
            Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-v2-${page.name}"))
                .navigationBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MonitoringFilters(
                data = data,
                from = from, to = to, shopId = shopFilter, shiftId = shiftFilter, brigadeId = brigadeFilter,
                onFrom = { from = it }, onTo = { to = it }, onShop = { shopFilter = it; brigadeFilter = "" },
                onShift = { shiftFilter = it; brigadeFilter = "" }, onBrigade = { brigadeFilter = it }
            )

            when (page) {
                TpMonitoringPage.ROOT -> {
                    val alerts = buildList {
                        if (stoppedMachineCount > 0) add("$stoppedMachineCount ta stanokda $focusDate kuni o‘chish qayd etilgan")
                        if (shortageCount > 0) add("$shortageCount ta seryo/krasitel yetishmovchiligi")
                        if (lowQueueMachines.isNotEmpty()) add("${lowQueueMachines.size} ta stanokda 18 soat yoki kam ish qolgan")
                        if (todayAbsent > 0) add("$todayAbsent ta ishchi ishlamadi")
                        if (pendingPrepCount > 0) add("$pendingPrepCount ta qorishma tayyorlash/yetkazish kutilmoqda")
                    }
                    if (alerts.isNotEmpty()) {
                        TpCard {
                            Text("E’tibor talab qiladi", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                            alerts.forEach { Text("• $it") }
                        }
                    }

                    MonitoringRootCard(
                        title = "1. Ishchilar",
                        summary = "${filteredWorkers.size} ishchi • to‘liq $todayFull • minus $todayMinus • ishlamadi $todayAbsent",
                        detail = "Samaradorlik ${workerEfficiencies.takeIf { it.isNotEmpty() }?.average()?.toInt()?.let { "$it%" } ?: "—"} • Sifat ${workerQuality.takeIf { it.isNotEmpty() }?.average()?.toInt()?.let { "$it%" } ?: "—"}"
                    ) { page = TpMonitoringPage.WORKERS; resetDrill() }
                    MonitoringRootCard(
                        title = "2. Stanoklar",
                        summary = "${visibleMachines.size} stanok • ishda $inProgressMachineCount • bo‘sh $idleMachineCount",
                        detail = "Bugun o‘chish $stoppedMachineCount • ≤18 soat ish ${lowQueueMachines.size}"
                    ) { page = TpMonitoringPage.MACHINES; resetDrill() }
                    MonitoringRootCard(
                        title = "3. Seryo bo‘limi",
                        summary = "Tanlanmagan $pendingSelectionCount • tayyorlash/yetkazish $pendingPrepCount",
                        detail = "Yetishmovchilik $shortageCount • Seryo: +${formatTpNumber(resinTodayIncoming)}/−${formatTpNumber(resinTodayOutgoing)} kg • Krasitel: +${formatTpNumber(colorTodayIncoming)}/−${formatTpNumber(colorTodayOutgoing)} g"
                    ) { page = TpMonitoringPage.MATERIALS; resetDrill() }

                    HorizontalDivider(Modifier.padding(top = 4.dp))
                    Text("Hisobot", fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { pendingReport = report; word.launch("ToyBola_TP_${from}_${to}.docx") }, Modifier.weight(1f)) { Text("Word") }
                        OutlinedButton(onClick = { pendingReport = report; excel.launch("ToyBola_TP_${from}_${to}.xlsx") }, Modifier.weight(1f)) { Text("Excel") }
                    }
                    if (!exportMessage.isNullOrBlank()) Text(exportMessage!!, color = MaterialTheme.colorScheme.primary)
                }

                TpMonitoringPage.WORKERS -> WorkersMonitoringLayer(
                    data = data, workers = filteredWorkers, brigades = filteredBrigades.filter { brigadeFilter.isBlank() || it.id == brigadeFilter },
                    from = from, to = to, selectedBrigadeId = selectedWorkerBrigade, selectedWorkerId = selectedWorker,
                    onBrigade = { selectedWorkerBrigade = it; selectedWorker = null }, onWorker = { selectedWorker = it }
                )

                TpMonitoringPage.MACHINES -> MachinesMonitoringLayer(
                    data = data, machines = visibleMachines, jobs = activeMachineJobs, receipts = filteredReceipts, downtimes = filteredDowntime,
                    from = from, to = to, selectedShopId = selectedMachineShop, selectedMachineId = selectedMachine,
                    onShop = { selectedMachineShop = it; selectedMachine = null }, onMachine = { selectedMachine = it }
                )

                TpMonitoringPage.MATERIALS -> MaterialsMonitoringLayer(data, pendingMaterialJobs, from, to, selectedMaterial) { selectedMaterial = it }
            }
        }
    }
}

@Composable
private fun MonitoringFilters(
    data: TpData,
    from: String, to: String, shopId: String, shiftId: String, brigadeId: String,
    onFrom: (String) -> Unit, onTo: (String) -> Unit, onShop: (String) -> Unit, onShift: (String) -> Unit, onBrigade: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { open = !open }, modifier = Modifier.fillMaxWidth()) { Text(if (open) "Filtrlarni yopish ▲" else "Filtrlar ▼") }
    if (!open) return
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.weight(1f)) { TpDatePickerButton("Dan", from, onFrom) }
        Box(Modifier.weight(1f)) { TpDatePickerButton("Gacha", to, onTo) }
    }
    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    val shifts = data.shifts.filterNot { it.archived }.sortedBy { it.name }
    val brigades = data.brigades.filter { !it.archived && (shopId.isBlank() || it.shopId == shopId) && (shiftId.isBlank() || it.shiftId == shiftId) }.sortedBy { it.name }
    TpChoice("Sex", shopId, listOf(TpShop("", "Barchasi")) + shops, { it.id }, { it.name }, onShop)
    TpChoice("Smena", shiftId, listOf(TpShift("", "Barchasi", "00:00", "00:00", emptyList())) + shifts, { it.id }, { it.name }, onShift)
    TpChoice("Brigada", brigadeId, listOf(TpBrigade("", "", "", "Barchasi")) + brigades, { it.id }, { it.name }, onBrigade)
}

@Composable
private fun MonitoringRootCard(title: String, summary: String, detail: String, onClick: () -> Unit) {
    TpCard(Modifier.clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Text("›", style = MaterialTheme.typography.headlineSmall)
        }
        Text(summary)
        Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun WorkersMonitoringLayer(
    data: TpData,
    workers: List<TpWorker>,
    brigades: List<TpBrigade>,
    from: String,
    to: String,
    selectedBrigadeId: String?,
    selectedWorkerId: String?,
    onBrigade: (String) -> Unit,
    onWorker: (String) -> Unit
) {
    val worker = selectedWorkerId?.let { id -> workers.firstOrNull { it.id == id } }
    if (worker != null) {
        val attendance = data.attendance.filter { it.workerId == worker.id && it.date in from..to }
        val earned = data.workerEarned(worker.id, from, to)
        val overtime = data.workerOvertimeEarned(worker.id, from, to)
        val quality = data.qualityRounds.filter { it.workerId == worker.id && it.date in from..to }.map { it.score }
        val totalMinutes = attendance.sumOf { data.attendanceWorkMinutes(worker.id, it.date) }
        val target = attendance.filter { it.present }.sumOf { row ->
            data.globalDailyTargetAmount().toDouble() * data.attendanceWorkMinutes(worker.id, row.date) / data.workerStandardMinutes(worker.id).coerceAtLeast(1)
        }
        val efficiency = if (target > 0.0) earned * 100.0 / target else null
        val machineIds = data.receipts.filter { it.workerId == worker.id && it.date in from..to }.map { it.machineId }.distinct()
        TpCard {
            Text(worker.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Topgan summa: $earned so‘m${if (overtime > 0) " • qo‘shimcha soat $overtime so‘m" else ""}")
            Text("Ishlagan vaqt: ${minutesLabel(totalMinutes)} • Norma: ${target.toLong()} so‘m")
            Text("Samaradorlik: ${efficiency?.toInt()?.let { "$it%" } ?: "—"} • Sifat: ${quality.takeIf { it.isNotEmpty() }?.average()?.toInt()?.let { "$it%" } ?: "—"}")
            Text("Ishlagan stanoklar: ${machineIds.mapNotNull { id -> data.machines.firstOrNull { it.id == id }?.number }.joinToString().ifBlank { "—" }}")
        }
        Text("Kunlar", fontWeight = FontWeight.Bold)
        dateSequence(from, to).sortedDescending().take(31).forEach { date ->
            val day = data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }
            val dayEarned = data.workerEarned(worker.id, date)
            val dayQuality = data.workerQuality(worker.id, date)
            if (day != null || dayEarned > 0 || dayQuality != null) {
                TpCard {
                    Text(date, fontWeight = FontWeight.SemiBold)
                    Text("${if (day?.present == false) "Ishlamadi" else "${data.attendanceWorkMinutes(worker.id, date)} daqiqa"} • $dayEarned so‘m")
                    Text("Samaradorlik ${data.workerEfficiency(worker.id, date)?.toInt()?.let { "$it%" } ?: "—"} • Sifat ${dayQuality?.toInt()?.let { "$it%" } ?: "—"}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        return
    }

    if (selectedBrigadeId != null) {
        val brigade = brigades.firstOrNull { it.id == selectedBrigadeId }
        Text(brigade?.name ?: "Brigada", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        val groupWorkers = workers.filter { it.brigadeId == selectedBrigadeId }.sortedBy { it.name }
        if (groupWorkers.isEmpty()) Text("Ishchi yo‘q.")
        groupWorkers.forEach { row ->
            val earned = data.workerEarned(row.id, from, to)
            val quality = data.qualityRounds.filter { it.workerId == row.id && it.date in from..to }.map { it.score }
            TpCard(Modifier.clickable { onWorker(row.id) }) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(row.name, fontWeight = FontWeight.Bold)
                        Text("Topdi $earned so‘m • Sifat ${quality.takeIf { it.isNotEmpty() }?.average()?.toInt()?.let { "$it%" } ?: "—"}")
                    }
                    Text("›", style = MaterialTheme.typography.headlineSmall)
                }
            }
        }
        return
    }

    Text("Brigadalar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    brigades.forEach { brigade ->
        val groupWorkers = workers.filter { it.brigadeId == brigade.id }
        val earnings = groupWorkers.sumOf { data.workerEarned(it.id, from, to) }
        val quality = data.qualityRounds.filter { it.brigadeId == brigade.id && it.date in from..to }.map { it.score }
        val absent = groupWorkers.count { worker -> data.attendance.any { it.workerId == worker.id && it.date == to && !it.present } }
        TpCard(Modifier.clickable { onBrigade(brigade.id) }) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(brigade.name, fontWeight = FontWeight.Bold)
                    Text("${groupWorkers.size} ishchi • Topdi $earnings so‘m • Ishlamadi $absent")
                    Text("Sifat ${quality.takeIf { it.isNotEmpty() }?.average()?.toInt()?.let { "$it%" } ?: "—"}", style = MaterialTheme.typography.bodySmall)
                }
                Text("›", style = MaterialTheme.typography.headlineSmall)
            }
        }
    }
}

@Composable
private fun MachinesMonitoringLayer(
    data: TpData,
    machines: List<TpMachine>,
    jobs: List<TpPlanJob>,
    receipts: List<TpReceipt>,
    downtimes: List<TpMachineDowntime>,
    from: String,
    to: String,
    selectedShopId: String?,
    selectedMachineId: String?,
    onShop: (String) -> Unit,
    onMachine: (String) -> Unit
) {
    val machine = selectedMachineId?.let { id -> machines.firstOrNull { it.id == id } }
    if (machine != null) {
        val machineJobs = jobs.filter { it.machineId == machine.id }
        val current = machineJobs.firstOrNull { it.status == TpJobStatus.IN_PROGRESS } ?: machineJobs.firstOrNull()
        val order = current?.let { job -> data.orders.firstOrNull { it.id == job.orderId } }
        val produced = receipts.filter { it.machineId == machine.id }.sumOf { it.creditedPieces }
        val stops = downtimes.filter { it.machineId == machine.id }.sortedByDescending { it.date + it.createdAt }
        val remaining = machineJobs.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
        TpCard {
            Text("${machine.number}-stanok", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(if (current == null) "Hozir bo‘sh" else "${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}")
            current?.let { Text("Detal: ${it.outputs.joinToString { out -> out.detailName }} • Rang ${it.colorCode}") }
            Text("Navbatdagi ish: ${minutesLabel(remaining)} • Davr qabul: $produced dona")
            Text("O‘chish: ${stops.size} marta • ${minutesLabel(stops.sumOf { it.durationMinutes() })}")
        }
        if (machineJobs.isNotEmpty()) {
            Text("Vazifalar", fontWeight = FontWeight.Bold)
            machineJobs.sortedBy { it.priority }.forEach { job ->
                val jobOrder = data.orders.firstOrNull { it.id == job.orderId }
                TpCard {
                    Text("${jobOrder?.articleSnapshot.orEmpty()} • ${job.outputs.joinToString { it.detailName }} • ${job.colorCode}", fontWeight = FontWeight.SemiBold)
                    Text("${jobStatusLabel(job.status)} • ${minutesLabel(job.estimatedMinutes)}")
                    Text(if (job.materialStatus == TpMaterialStatus.DELIVERED) "✓ Seryo yetkazilgan" else "Seryo kutilmoqda", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        if (stops.isNotEmpty()) {
            Text("O‘chishlar tarixi", fontWeight = FontWeight.Bold)
            stops.take(50).forEach { stop ->
                TpCard {
                    Text("${stop.date} • ${stop.offTime}–${stop.onTime} • ${minutesLabel(stop.durationMinutes())}", fontWeight = FontWeight.SemiBold)
                    Text(stop.note)
                }
            }
        }
        return
    }

    if (selectedShopId != null) {
        val shop = data.shops.firstOrNull { it.id == selectedShopId }
        Text(shop?.name ?: "Sex", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        val shopMachines = machines.filter { it.shopId == selectedShopId }.sortedBy { it.number }
        shopMachines.forEach { row ->
            val rowJobs = jobs.filter { it.machineId == row.id }
            val remaining = rowJobs.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
            val stopMinutes = downtimes.filter { it.machineId == row.id }.sumOf { it.durationMinutes() }
            TpCard(Modifier.clickable { onMachine(row.id) }) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${row.number}-stanok", fontWeight = FontWeight.Bold)
                        Text(if (rowJobs.isEmpty()) "Bo‘sh" else "${rowJobs.size} vazifa • ${minutesLabel(remaining)} ish")
                        Text("Davr o‘chish: ${minutesLabel(stopMinutes)}", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("›", style = MaterialTheme.typography.headlineSmall)
                }
            }
        }
        return
    }

    Text("Sexlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    val shopIds = machines.map { it.shopId }.toSet()
    data.shops.filter { !it.archived && it.id in shopIds }.sortedBy { it.name }.forEach { shop ->
        val shopMachines = machines.filter { it.shopId == shop.id }
        val busy = shopMachines.count { machine -> jobs.any { it.machineId == machine.id } }
        val stopped = shopMachines.count { machine -> downtimes.any { it.machineId == machine.id } }
        TpCard(Modifier.clickable { onShop(shop.id) }) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(shop.name, fontWeight = FontWeight.Bold)
                    Text("${shopMachines.size} stanok • ishli $busy • bo‘sh ${shopMachines.size - busy} • o‘chish qaydi $stopped")
                }
                Text("›", style = MaterialTheme.typography.headlineSmall)
            }
        }
    }
}

@Composable
private fun MaterialsMonitoringLayer(
    data: TpData,
    pendingJobs: List<TpPlanJob>,
    from: String,
    to: String,
    selectedMaterialId: String?,
    onMaterial: (String) -> Unit
) {
    val material = selectedMaterialId?.let { id -> data.materials.firstOrNull { it.id == id } }
    if (material != null) {
        val unit = if (material.type == TpMaterialType.RESIN) "kg" else "g"
        val movements = material.movements.filter { it.createdAt.take(10) in from..to }
        val incoming = movements.filter { it.kind == TpMaterialMovementKind.IN }.sumOf { it.amount }
        val outgoing = movements.filter { it.kind == TpMaterialMovementKind.OUT }.sumOf { it.amount }
        val need = if (material.type == TpMaterialType.RESIN) pendingJobs.filter { it.resinCode == material.code }.sumOf { it.requiredResinKg }
        else pendingJobs.filter { it.colorCode == material.code }.sumOf { it.requiredColorGrams }
        val stock = material.currentStock()
        val free = stock - need
        TpCard {
            Text("${material.code} • ${material.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Ostatka: ${formatTpNumber(stock)} $unit")
            Text("Faol zakazlarga kerak: ${formatTpNumber(need)} $unit • Erkin: ${formatTpNumber(free)} $unit", color = if (free < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            Text("Davr prixod: ${formatTpNumber(incoming)} $unit • Rasxod: ${formatTpNumber(outgoing)} $unit")
            Text(if (free < 0) "⚠ Faol zakazlarga yetmaydi" else "✓ Faol zakazlarga yetadi", fontWeight = FontWeight.SemiBold)
        }
        val linkedJobs = if (material.type == TpMaterialType.RESIN) pendingJobs.filter { it.resinCode == material.code } else pendingJobs.filter { it.colorCode == material.code }
        if (linkedJobs.isNotEmpty()) {
            Text("Qayerga kerak", fontWeight = FontWeight.Bold)
            linkedJobs.groupBy { it.orderId }.forEach { (orderId, rows) ->
                val order = data.orders.firstOrNull { it.id == orderId }
                TpCard {
                    Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.SemiBold)
                    Text(rows.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString())
                    val amount = if (material.type == TpMaterialType.RESIN) rows.sumOf { it.requiredResinKg } else rows.sumOf { it.requiredColorGrams }
                    Text("Kerak: ${formatTpNumber(amount)} $unit")
                }
            }
        }
        return
    }

    Text("Seryo va krasitel", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    val visible = data.materials.filterNot { it.archived }.sortedWith(compareBy<TpMaterial> { it.type.name }.thenBy { it.code })
    visible.forEach { row ->
        val need = if (row.type == TpMaterialType.RESIN) pendingJobs.filter { it.resinCode == row.code }.sumOf { it.requiredResinKg }
        else pendingJobs.filter { it.colorCode == row.code }.sumOf { it.requiredColorGrams }
        val stock = row.currentStock()
        val unit = if (row.type == TpMaterialType.RESIN) "kg" else "g"
        TpCard(Modifier.clickable { onMaterial(row.id) }) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${row.code} • ${row.name}", fontWeight = FontWeight.Bold)
                    Text("Ostatka ${formatTpNumber(stock)} $unit • Faol ehtiyoj ${formatTpNumber(need)} $unit")
                    if (stock + 1e-9 < need) Text("⚠ Yetishmaydi ${formatTpNumber(need - stock)} $unit", color = MaterialTheme.colorScheme.error)
                }
                Text("›", style = MaterialTheme.typography.headlineSmall)
            }
        }
    }
}

private fun dateSequence(from: String, to: String): List<String> = runCatching {
    val start = LocalDate.parse(from)
    val end = LocalDate.parse(to)
    if (end.isBefore(start)) emptyList() else buildList {
        var day = start
        var guard = 0
        while (!day.isAfter(end) && guard < 3700) {
            add(day.toString())
            day = day.plusDays(1)
            guard++
        }
    }
}.getOrDefault(emptyList())
