package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate

private enum class TpMonitoringPage { ROOT, WORKERS, WORKER_DETAIL, MACHINES, MACHINE_DETAIL, MATERIALS, MATERIAL_DETAIL }

@Composable
fun TpMonitoringScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val revision by TpDataEvents.revision.collectAsState()
    val policy = remember(revision) { AccessGuard(context).currentPolicy() }
    val data = remember(revision, policy.revision) { repository.load().scopedFor(policy) }
    var page by remember { mutableStateOf(TpMonitoringPage.ROOT) }
    var selectedBrigadeId by remember { mutableStateOf("") }
    var selectedWorkerId by remember { mutableStateOf("") }
    var selectedShopId by remember { mutableStateOf("") }
    var selectedMachineId by remember { mutableStateOf("") }
    var selectedMaterialId by remember { mutableStateOf("") }
    var periodDays by remember { mutableIntStateOf(1) }

    val toDate = LocalDate.now()
    val fromDate = toDate.minusDays((periodDays - 1).coerceAtLeast(0).toLong())
    val from = fromDate.toString()
    val to = toDate.toString()

    fun back() {
        when (page) {
            TpMonitoringPage.ROOT -> onBack()
            TpMonitoringPage.WORKER_DETAIL -> { page = TpMonitoringPage.WORKERS; selectedWorkerId = "" }
            TpMonitoringPage.MACHINE_DETAIL -> { page = TpMonitoringPage.MACHINES; selectedMachineId = "" }
            TpMonitoringPage.MATERIAL_DETAIL -> { page = TpMonitoringPage.MATERIALS; selectedMaterialId = "" }
            TpMonitoringPage.WORKERS -> if (selectedBrigadeId.isNotBlank()) selectedBrigadeId = "" else page = TpMonitoringPage.ROOT
            TpMonitoringPage.MACHINES -> if (selectedShopId.isNotBlank()) selectedShopId = "" else page = TpMonitoringPage.ROOT
            TpMonitoringPage.MATERIALS -> page = TpMonitoringPage.ROOT
        }
    }
    BackHandler(enabled = page != TpMonitoringPage.ROOT || selectedBrigadeId.isNotBlank() || selectedShopId.isNotBlank()) { back() }

    val title = when (page) {
        TpMonitoringPage.ROOT -> "Monitoring"
        TpMonitoringPage.WORKERS -> if (selectedBrigadeId.isBlank()) "Ishchilar" else data.brigades.firstOrNull { it.id == selectedBrigadeId }?.name ?: "Ishchilar"
        TpMonitoringPage.WORKER_DETAIL -> data.workers.firstOrNull { it.id == selectedWorkerId }?.name ?: "Ishchi"
        TpMonitoringPage.MACHINES -> if (selectedShopId.isBlank()) "Stanoklar" else data.shops.firstOrNull { it.id == selectedShopId }?.name ?: "Stanoklar"
        TpMonitoringPage.MACHINE_DETAIL -> data.machines.firstOrNull { it.id == selectedMachineId }?.let { "${it.number}-stanok" } ?: "Stanok"
        TpMonitoringPage.MATERIALS -> "Seryo bo‘limi"
        TpMonitoringPage.MATERIAL_DETAIL -> data.materials.firstOrNull { it.id == selectedMaterialId }?.code ?: "Material"
    }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(title, canGoBack = true, onMenu = {}, onBack = ::back)
        when (page) {
            TpMonitoringPage.ROOT -> TpMonitoringRoot(data, from, to, periodDays, { periodDays = it }) { selected -> page = selected }
            TpMonitoringPage.WORKERS -> TpWorkerMonitoring(data, from, to, selectedBrigadeId,
                onBrigade = { selectedBrigadeId = it },
                onWorker = { selectedWorkerId = it; page = TpMonitoringPage.WORKER_DETAIL })
            TpMonitoringPage.WORKER_DETAIL -> TpWorkerMonitoringDetail(data, from, to, selectedWorkerId)
            TpMonitoringPage.MACHINES -> TpMachineMonitoring(data, from, to, selectedShopId,
                onShop = { selectedShopId = it },
                onMachine = { selectedMachineId = it; page = TpMonitoringPage.MACHINE_DETAIL })
            TpMonitoringPage.MACHINE_DETAIL -> TpMachineMonitoringDetail(data, from, to, selectedMachineId)
            TpMonitoringPage.MATERIALS -> TpMaterialMonitoring(data, from, to) { selectedMaterialId = it; page = TpMonitoringPage.MATERIAL_DETAIL }
            TpMonitoringPage.MATERIAL_DETAIL -> TpMaterialMonitoringDetail(data, from, to, selectedMaterialId)
        }
    }
}

@Composable
private fun TpMonitoringRoot(
    data: TpData,
    from: String,
    to: String,
    periodDays: Int,
    onPeriod: (Int) -> Unit,
    onOpen: (TpMonitoringPage) -> Unit
) {
    val today = LocalDate.now().toString()
    val workers = data.workers.filterNot { it.archived }
    val attendanceToday = data.attendance.filter { it.date == today }
    val absentToday = attendanceToday.count { !it.present }
    val minusToday = attendanceToday.count { it.present && it.minusHours > 0.0 }
    val receipts = data.receipts.filter { it.date in from..to }
    val rounds = data.qualityRounds.filter { it.date in from..to }
    val activeJobs = data.jobs.filter { it.planConfirmedAt != null && it.machineId != null && it.status != TpJobStatus.COMPLETE }
    val runningMachines = activeJobs.filter { it.status == TpJobStatus.IN_PROGRESS }.mapNotNull { it.machineId }.toSet()
    val busyMachines = activeJobs.mapNotNull { it.machineId }.toSet()
    val machines = data.machines.filterNot { it.archived }
    val downtimes = data.machineDowntimes.filter { it.date in from..to }
    val shortMachines = machines.count { machine ->
        val mins = activeJobs.filter { it.machineId == machine.id }.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
        mins in 1..1080
    }
    val pendingMaterial = data.jobs.count { it.resinConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED && it.status != TpJobStatus.COMPLETE }
    val shortageJobs = data.jobs.count { job ->
        if (job.resinConfirmedAt == null || job.materialStatus == TpMaterialStatus.DELIVERED || job.status == TpJobStatus.COMPLETE) false
        else {
            val resinStock = data.materials.firstOrNull { !it.archived && it.type == TpMaterialType.RESIN && it.code.equals(job.resinCode, true) }?.currentStock() ?: 0.0
            val colorStock = data.materials.firstOrNull { !it.archived && it.type == TpMaterialType.COLOR && it.code.equals(job.colorCode, true) }?.currentStock() ?: 0.0
            resinStock + 1e-9 < job.requiredResinKg || colorStock + 1e-9 < job.requiredColorGrams
        }
    }
    val avgQuality = rounds.map { it.score }.takeIf { it.isNotEmpty() }?.average()?.toInt()
    val periodLabel = if (periodDays == 1) "Bugun" else "Oxirgi $periodDays kun"

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-root"))
            .navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            listOf(1 to "Bugun", 7 to "7 kun", 30 to "30 kun").forEachIndexed { index, option ->
                SegmentedButton(selected = periodDays == option.first, onClick = { onPeriod(option.first) }, shape = SegmentedButtonDefaults.itemShape(index, 3)) { Text(option.second) }
            }
        }

        Text("E’tibor talab qiladi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (absentToday == 0 && minusToday == 0 && downtimes.isEmpty() && shortMachines == 0 && shortageJobs == 0) {
            TpCard { Text("Hozir kritik ogohlantirish yo‘q.", color = MaterialTheme.colorScheme.primary) }
        } else {
            TpCard {
                if (absentToday > 0) Text("• $absentToday ishchi bugun ishlamadi", color = MaterialTheme.colorScheme.error)
                if (minusToday > 0) Text("• $minusToday ishchida minus soat bor", color = MaterialTheme.colorScheme.tertiary)
                if (downtimes.isNotEmpty()) Text("• $periodLabel: ${downtimes.size} ta stanok o‘chish qaydi • ${minutesLabel(downtimes.sumOf { it.durationMinutes() })}", color = MaterialTheme.colorScheme.error)
                if (shortMachines > 0) Text("• $shortMachines stanokda 18 soat yoki kam ish qolgan", color = MaterialTheme.colorScheme.tertiary)
                if (shortageJobs > 0) Text("• $shortageJobs vazifada seryo qoldig‘i yetishmasligi mumkin", color = MaterialTheme.colorScheme.error)
            }
        }

        MonitoringSectionCard(
            title = "1. Ishchilar",
            primary = "${workers.size} ishchi",
            lines = listOf(
                "Bugun: ${workers.size - absentToday - minusToday} to‘liq • $minusToday minus • $absentToday ishlamadi",
                "${periodLabel}: ${receipts.sumOf { it.earnedAmount }} so‘m • Sifat ${avgQuality?.let { "$it%" } ?: "—"}"
            ),
            onClick = { onOpen(TpMonitoringPage.WORKERS) }
        )
        MonitoringSectionCard(
            title = "2. Stanoklar",
            primary = "${machines.size} stanok",
            lines = listOf(
                "Ishda ${runningMachines.size} • Zakazli ${busyMachines.size} • Bo‘sh ${(machines.size - busyMachines.size).coerceAtLeast(0)}",
                "$periodLabel: ${downtimes.size} o‘chish • ${minutesLabel(downtimes.sumOf { it.durationMinutes() })} yo‘qotish"
            ),
            onClick = { onOpen(TpMonitoringPage.MACHINES) }
        )
        MonitoringSectionCard(
            title = "3. Seryo bo‘limi",
            primary = "$pendingMaterial vazifa kutilmoqda",
            lines = listOf(
                "Yetishmasligi mumkin: $shortageJobs",
                "Seryo ${data.materials.count { !it.archived && it.type == TpMaterialType.RESIN }} tur • Krasitel ${data.materials.count { !it.archived && it.type == TpMaterialType.COLOR }} tur"
            ),
            onClick = { onOpen(TpMonitoringPage.MATERIALS) }
        )
    }
}

@Composable
private fun MonitoringSectionCard(title: String, primary: String, lines: List<String>, onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, Modifier.weight(1f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("›", style = MaterialTheme.typography.headlineSmall)
            }
            Text(primary, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
            lines.forEach { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
private fun TpWorkerMonitoring(data: TpData, from: String, to: String, brigadeId: String, onBrigade: (String) -> Unit, onWorker: (String) -> Unit) {
    val receipts = data.receipts.filter { it.date in from..to }
    val rounds = data.qualityRounds.filter { it.date in from..to }
    val attendance = data.attendance.filter { it.date in from..to }
    val today = LocalDate.now().toString()
    val brigades = data.brigades.filterNot { it.archived }.sortedBy { it.name }

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-workers-$brigadeId"))
            .navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (brigadeId.isBlank()) {
            Text("Brigada → ishchi → aniq natija", color = MaterialTheme.colorScheme.onSurfaceVariant)
            brigades.forEach { brigade ->
                val workerIds = data.workers.filter { !it.archived && it.brigadeId == brigade.id }.map { it.id }.toSet()
                val earned = receipts.filter { it.workerId in workerIds }.sumOf { it.earnedAmount }
                val quality = rounds.filter { it.workerId in workerIds }.map { it.score }.takeIf { it.isNotEmpty() }?.average()?.toInt()
                val absent = attendance.count { it.date == today && it.brigadeId == brigade.id && !it.present }
                val minus = attendance.count { it.date == today && it.brigadeId == brigade.id && it.present && it.minusHours > 0.0 }
                TpCard(Modifier.clickable { onBrigade(brigade.id) }) {
                    Text(brigade.name, fontWeight = FontWeight.Bold)
                    Text("${workerIds.size} ishchi • bugun $absent ishlamadi • $minus minus soat")
                    Text("Topilgan: $earned so‘m • sifat ${quality?.let { "$it%" } ?: "—"}", style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            val workers = data.workers.filter { !it.archived && it.brigadeId == brigadeId }.sortedBy { it.name }
            workers.forEach { worker ->
                val earned = receipts.filter { it.workerId == worker.id }.sumOf { it.earnedAmount }
                val quality = rounds.filter { it.workerId == worker.id }.map { it.score }.takeIf { it.isNotEmpty() }?.average()
                val rows = attendance.filter { it.workerId == worker.id }
                val target = rows.filter { it.present }.sumOf { row ->
                    data.globalDailyTargetAmount().toDouble() * data.attendanceWorkMinutes(worker.id, row.date) / data.workerStandardMinutes(worker.id).coerceAtLeast(1)
                }
                val efficiency = if (target > 0) earned * 100.0 / target else null
                TpCard(Modifier.clickable { onWorker(worker.id) }) {
                    Text(worker.name, fontWeight = FontWeight.Bold)
                    Text("Topdi $earned so‘m • norma ${target.toLong()} so‘m")
                    Text("Samaradorlik ${efficiency?.toInt()?.let { "$it%" } ?: "—"} • sifat ${quality?.toInt()?.let { "$it%" } ?: "—"}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun TpWorkerMonitoringDetail(data: TpData, from: String, to: String, workerId: String) {
    val worker = data.workers.firstOrNull { it.id == workerId }
    if (worker == null) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Ishchi topilmadi") }; return }
    val brigade = data.brigades.firstOrNull { it.id == worker.brigadeId }
    val receipts = data.receipts.filter { it.workerId == worker.id && it.date in from..to }
    val rounds = data.qualityRounds.filter { it.workerId == worker.id && it.date in from..to }
    val attendance = data.attendance.filter { it.workerId == worker.id && it.date in from..to }.sortedByDescending { it.date }
    val earned = receipts.sumOf { it.earnedAmount }
    val target = attendance.filter { it.present }.sumOf { row -> data.globalDailyTargetAmount().toDouble() * data.attendanceWorkMinutes(worker.id, row.date) / data.workerStandardMinutes(worker.id).coerceAtLeast(1) }
    val quality = rounds.map { it.score }.takeIf { it.isNotEmpty() }?.average()
    val machineIds = receipts.map { it.machineId }.distinct()
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-worker-detail-$workerId")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(brigade?.name.orEmpty(), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TpMetric("Topdi", "$earned so‘m", Modifier.weight(1f)); TpMetric("Norma", "${target.toLong()} so‘m", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TpMetric("Samaradorlik", if (target > 0) "${(earned * 100.0 / target).toInt()}%" else "—", Modifier.weight(1f)); TpMetric("Sifat", quality?.toInt()?.let { "$it%" } ?: "—", Modifier.weight(1f))
        }
        Text("Ishlagan stanoklar", fontWeight = FontWeight.Bold)
        Text(machineIds.mapNotNull { id -> data.machines.firstOrNull { it.id == id }?.number }.sorted().joinToString { "$it-stanok" }.ifBlank { "—" })
        Text("Davomat", fontWeight = FontWeight.Bold)
        attendance.forEach { row ->
            Text("${row.date}: ${if (!row.present) "Ishlamadi" else if (row.minusHours > 0) "minus ${formatTpNumber(row.minusHours)} soat" else "to‘liq"} • ${data.attendanceWorkMinutes(worker.id, row.date)} daqiqa")
        }
        if (rounds.isNotEmpty()) {
            Text("Sifat baholari", fontWeight = FontWeight.Bold)
            rounds.sortedByDescending { it.checkedAt }.take(30).forEach { row -> Text("${row.date} • ${row.round}-raund • ${row.score}%${row.issue.takeIf { it.isNotBlank() }?.let { " • $it" }.orEmpty()}") }
        }
    }
}

@Composable
private fun TpMachineMonitoring(data: TpData, from: String, to: String, shopId: String, onShop: (String) -> Unit, onMachine: (String) -> Unit) {
    val machines = data.machines.filterNot { it.archived }
    val jobs = data.jobs.filter { it.planConfirmedAt != null && it.machineId != null && it.status != TpJobStatus.COMPLETE }
    val downtime = data.machineDowntimes.filter { it.date in from..to }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-machines-$shopId")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (shopId.isBlank()) {
            Text("Sex → stanok → navbat va yo‘qotish", color = MaterialTheme.colorScheme.onSurfaceVariant)
            data.shops.filterNot { it.archived }.sortedBy { it.name }.forEach { shop ->
                val shopMachines = machines.filter { it.shopId == shop.id }
                val ids = shopMachines.map { it.id }.toSet()
                val running = jobs.filter { it.machineId in ids && it.status == TpJobStatus.IN_PROGRESS }.mapNotNull { it.machineId }.distinct().size
                val busy = jobs.filter { it.machineId in ids }.mapNotNull { it.machineId }.distinct().size
                val stopRows = downtime.filter { it.machineId in ids }
                TpCard(Modifier.clickable { onShop(shop.id) }) {
                    Text(shop.name, fontWeight = FontWeight.Bold)
                    Text("${shopMachines.size} stanok • $running ishda • ${(shopMachines.size - busy).coerceAtLeast(0)} bo‘sh")
                    Text("O‘chish: ${stopRows.size} marta • ${minutesLabel(stopRows.sumOf { it.durationMinutes() })}", style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            val shopMachines = machines.filter { it.shopId == shopId }.sortedBy { it.number }
            val busy = shopMachines.filter { m -> jobs.any { it.machineId == m.id } }
            val idle = shopMachines.filter { m -> jobs.none { it.machineId == m.id } }
            Text("Ishi bor", fontWeight = FontWeight.Bold)
            busy.sortedBy { m -> jobs.filter { it.machineId == m.id }.sumOf { it.estimatedMinutes.coerceAtLeast(0) } }.forEach { machine ->
                val rows = jobs.filter { it.machineId == machine.id }
                val mins = rows.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
                val stops = downtime.filter { it.machineId == machine.id }
                TpCard(Modifier.clickable { onMachine(machine.id) }) {
                    Text("${machine.number}-stanok", fontWeight = FontWeight.Bold)
                    Text("${if (rows.any { it.status == TpJobStatus.IN_PROGRESS }) "Ishda" else "Navbatda"} • ${minutesLabel(mins)} ish")
                    if (stops.isNotEmpty()) Text("O‘chish ${stops.size} marta • ${minutesLabel(stops.sumOf { it.durationMinutes() })}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
            HorizontalDivider()
            Text("Ishsiz", fontWeight = FontWeight.Bold)
            idle.forEach { machine -> TpCard(Modifier.clickable { onMachine(machine.id) }) { Text("${machine.number}-stanok", fontWeight = FontWeight.Bold); Text("Zakaz yo‘q", color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        }
    }
}

@Composable
private fun TpMachineMonitoringDetail(data: TpData, from: String, to: String, machineId: String) {
    val machine = data.machines.firstOrNull { it.id == machineId }
    if (machine == null) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Stanok topilmadi") }; return }
    val shop = data.shops.firstOrNull { it.id == machine.shopId }
    val jobs = data.jobs.filter { it.machineId == machineId && it.status != TpJobStatus.COMPLETE }.sortedWith(compareBy<TpPlanJob> { it.status != TpJobStatus.IN_PROGRESS }.thenBy { it.priority })
    val receipts = data.receipts.filter { it.machineId == machineId && it.date in from..to }
    val stops = data.machineDowntimes.filter { it.machineId == machineId && it.date in from..to }.sortedWith(compareByDescending<TpMachineDowntime> { it.date }.thenByDescending { it.stoppedAt })
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-machine-detail-$machineId")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("${shop?.name.orEmpty()} • sig‘im ${machine.capacity}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TpMetric("Qabul", "${receipts.sumOf { it.creditedPieces }} dona", Modifier.weight(1f)); TpMetric("O‘chish", minutesLabel(stops.sumOf { it.durationMinutes() }), Modifier.weight(1f))
        }
        Text("Hozirgi va keyingi ishlar", fontWeight = FontWeight.Bold)
        if (jobs.isEmpty()) Text("Zakaz yo‘q")
        jobs.forEach { job ->
            val order = data.orders.firstOrNull { it.id == job.orderId }
            TpCard {
                Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.Bold)
                Text("${job.outputs.map { it.detailName }.distinct().joinToString()} • rang ${job.colorCode}")
                Text("${jobStatusLabel(job.status)} • ${minutesLabel(job.estimatedMinutes)} • ${materialStatusLabel(job.materialStatus)}", style = MaterialTheme.typography.bodySmall)
            }
        }
        Text("O‘chishlar tarixi", fontWeight = FontWeight.Bold)
        if (stops.isEmpty()) Text("Tanlangan davrda o‘chish qaydi yo‘q.")
        stops.forEach { row -> TpCard { Text("${row.date} • ${row.stoppedAt}–${row.resumedAt} • ${minutesLabel(row.durationMinutes())}", fontWeight = FontWeight.SemiBold); Text(row.reason); Text("Kiritdi: ${row.createdBy}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
    }
}

@Composable
private fun TpMaterialMonitoring(data: TpData, from: String, to: String, onMaterial: (String) -> Unit) {
    val pending = data.jobs.filter { it.resinConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED && it.status != TpJobStatus.COMPLETE }
    val materials = data.materials.filterNot { it.archived }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-materials")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TpMetric("Tayyorlash", pending.size.toString(), Modifier.weight(1f)); TpMetric("Yetkazilmagan", pending.count { it.materialStatus != TpMaterialStatus.DELIVERED }.toString(), Modifier.weight(1f))
        }
        TpMetric("Kritik qoldiq", materials.count { it.currentStock() <= 0.0 }.toString(), Modifier.fillMaxWidth())
        listOf(TpMaterialType.RESIN to "Seryo", TpMaterialType.COLOR to "Krasitel").forEach { (type, title) ->
            Text(title, fontWeight = FontWeight.Bold)
            materials.filter { it.type == type }.sortedBy { it.code }.forEach { material ->
                val periodMovements = material.movements.filter { it.createdAt.take(10) in from..to }
                val incoming = periodMovements.filter { it.kind == TpMaterialMovementKind.IN }.sumOf { it.amount }
                val outgoing = periodMovements.filter { it.kind == TpMaterialMovementKind.OUT }.sumOf { it.amount }
                val demand = pending.filter { if (type == TpMaterialType.RESIN) it.resinCode.equals(material.code, true) else it.colorCode.equals(material.code, true) }
                    .sumOf { if (type == TpMaterialType.RESIN) it.requiredResinKg else it.requiredColorGrams }
                TpCard(Modifier.clickable { onMaterial(material.id) }) {
                    Text(material.code, fontWeight = FontWeight.Bold)
                    Text("Ostatka ${formatTpNumber(material.currentStock())} • ehtiyoj ${formatTpNumber(demand)}")
                    Text("Davr: +${formatTpNumber(incoming)} / -${formatTpNumber(outgoing)}", style = MaterialTheme.typography.bodySmall)
                    if (demand > material.currentStock() + 1e-9) Text("Yetishmaydi: ${formatTpNumber(demand - material.currentStock())}", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
private fun TpMaterialMonitoringDetail(data: TpData, from: String, to: String, materialId: String) {
    val material = data.materials.firstOrNull { it.id == materialId }
    if (material == null) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Material topilmadi") }; return }
    val movements = material.movements.filter { it.createdAt.take(10) in from..to }.sortedByDescending { it.createdAt }
    val pending = data.jobs.filter { it.resinConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED && it.status != TpJobStatus.COMPLETE &&
        (if (material.type == TpMaterialType.RESIN) it.resinCode.equals(material.code, true) else it.colorCode.equals(material.code, true)) }
    val demand = pending.sumOf { if (material.type == TpMaterialType.RESIN) it.requiredResinKg else it.requiredColorGrams }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-material-detail-$materialId")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TpMetric("Ostatka", formatTpNumber(material.currentStock()), Modifier.weight(1f)); TpMetric("Rejadagi ehtiyoj", formatTpNumber(demand), Modifier.weight(1f))
        }
        if (demand > material.currentStock() + 1e-9) Text("Yetishmaydigan miqdor: ${formatTpNumber(demand - material.currentStock())}", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
        Text("Qaysi zakazlarga kerak", fontWeight = FontWeight.Bold)
        pending.forEach { job ->
            val order = data.orders.firstOrNull { it.id == job.orderId }
            val amount = if (material.type == TpMaterialType.RESIN) job.requiredResinKg else job.requiredColorGrams
            Text("• ${order?.articleSnapshot.orEmpty()} • ${job.outputs.map { it.detailName }.distinct().joinToString()} • ${formatTpNumber(amount)}")
        }
        Text("Harakatlar", fontWeight = FontWeight.Bold)
        if (movements.isEmpty()) Text("Tanlangan davrda harakat yo‘q.")
        movements.forEach { row -> Text("${row.createdAt.take(16).replace('T', ' ')} • ${if (row.kind == TpMaterialMovementKind.IN) "+" else "-"}${formatTpNumber(row.amount)} • ${row.note}") }
    }
}

@Composable
private fun TpMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, shape = MaterialTheme.shapes.medium, tonalElevation = 1.dp) {
        Column(Modifier.padding(10.dp)) { Text(value, fontWeight = FontWeight.Bold); Text(label, style = MaterialTheme.typography.bodySmall) }
    }
}
