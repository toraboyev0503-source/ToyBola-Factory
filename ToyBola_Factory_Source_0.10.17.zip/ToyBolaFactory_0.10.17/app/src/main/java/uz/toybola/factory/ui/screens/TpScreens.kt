package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.components.SectionCard
import uz.toybola.factory.ui.model.AppScreen
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate

private data class TpMainItem(
    val title: String,
    val description: String,
    val screen: AppScreen,
    val badge: Int = 0
)

@Composable
fun TpMainScreen(
    strings: AppStrings,
    onBack: () -> Unit,
    canOpen: (AppScreen) -> Boolean,
    onOpen: (AppScreen) -> Unit
) {
    val context = LocalContext.current
    val revision by TpDataEvents.revision.collectAsState()
    val policy = remember(revision) { AccessGuard(context).currentPolicy() }
    val data = remember(revision, policy.revision) { TpDataRepository(context).load().scopedFor(policy) }
    val plannerPendingBadge = if (policy.isAdmin() || policy.canRead(AssemblySection.TP_PLANNING)) {
        data.orders.count { order ->
            if (order.status == TpOrderStatus.COMPLETE || order.status == TpOrderStatus.CANCELLED) false
            else {
                val jobs = data.jobs.filter { it.orderId == order.id }
                jobs.isEmpty() || jobs.any { it.planConfirmedAt == null }
            }
        }
    } else 0
    val machinePendingBadge = if (policy.isAdmin() || policy.canRead(AssemblySection.TP_MACHINE)) {
        data.jobs.filter { it.planConfirmedAt != null && it.materialStatus == TpMaterialStatus.DELIVERED && it.status == TpJobStatus.QUEUED }
            .groupBy { "${it.orderId}|${it.moldCode}|${it.machineId}" }.size
    } else 0
    val planBadge = plannerPendingBadge + machinePendingBadge
    val seryoBadge = if (policy.isAdmin() || policy.canRead(AssemblySection.TP_SERYO)) {
        val chooseResin = data.jobs.count { it.planConfirmedAt != null && it.resinConfirmedAt == null && it.status != TpJobStatus.COMPLETE }
        val prepareOrDeliver = data.jobs.count { it.resinConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED && it.status != TpJobStatus.COMPLETE }
        chooseResin + prepareOrDeliver
    } else 0
    val items = listOf(
        TpMainItem("Plan", "Zakaz va reja", AppScreen.TP_PLAN, planBadge),
        TpMainItem("Seryo", "Tayyorlash va qoldiq", AppScreen.TP_SERYO, seryoBadge),
        TpMainItem("Qabul qilish", "Detal qabuli", AppScreen.TP_RECEIVING),
        TpMainItem("Sifat", "Raund va muammo", AppScreen.TP_QUALITY),
        TpMainItem("Monitoring", "Natijalar", AppScreen.TP_MONITORING),
        TpMainItem("Ma’lumotlar", "Asosiy ma’lumotlar", AppScreen.TP_MASTER_DATA)
    )
    Column(Modifier.fillMaxSize()) {
        AppTopBar("TP va Seryo", canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-screen-1")).navigationBarsPadding().padding(16.dp)) {
            items.chunked(2).forEachIndexed { rowIndex, row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEachIndexed { index, item ->
                        SectionCard(
                            number = rowIndex * 2 + index + 1,
                            title = item.title,
                            description = item.description,
                            enabled = canOpen(item.screen),
                            badgeCount = item.badge,
                            modifier = if (row.size == 1) Modifier.fillMaxWidth() else Modifier.weight(1f),
                            onClick = { onOpen(item.screen) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

private enum class TpPlanPage { ROOT, ORDERS, PLANNING, MACHINES, ATTENDANCE, MASTER }

@Composable
fun TpPlanScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val eventRevision by TpDataEvents.revision.collectAsState()
    var localRevision by remember { mutableIntStateOf(0) }
    val policy = remember(eventRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(eventRevision, localRevision, policy.revision) { repository.load().scopedFor(policy) }
    var page by remember { mutableStateOf(TpPlanPage.ROOT) }
    var masterPage by remember { mutableStateOf(TpMasterPage.ROOT) }
    fun refresh() { localRevision++ }
    fun back() {
        when {
            page == TpPlanPage.MASTER && masterPage != TpMasterPage.ROOT -> masterPage = TpMasterPage.ROOT
            page == TpPlanPage.ROOT -> onBack()
            else -> { page = TpPlanPage.ROOT; masterPage = TpMasterPage.ROOT }
        }
    }
    BackHandler { back() }

    val title = when (page) {
        TpPlanPage.ROOT -> "Plan"
        TpPlanPage.ORDERS -> "Nachalnik zakazlari"
        TpPlanPage.PLANNING -> "Plan beruvchi"
        TpPlanPage.MACHINES -> "Stanok vazifalari"
        TpPlanPage.ATTENDANCE -> "Davomat"
        TpPlanPage.MASTER -> "TP ma’lumotlari"
    }
    Column(Modifier.fillMaxSize()) {
        AppTopBar(title, canGoBack = true, onMenu = {}, onBack = ::back)
        when (page) {
            TpPlanPage.ROOT -> TpPlanRoot(policy, data) { page = it }
            TpPlanPage.ORDERS -> TpOrdersPage(data, repository, policy, ::refresh)
            TpPlanPage.PLANNING -> TpPlanningPage(data, repository, policy, ::refresh)
            TpPlanPage.MACHINES -> TpMachineQueuePage(data, repository, policy, ::refresh)
            TpPlanPage.ATTENDANCE -> TpAttendancePage(data, repository, policy, ::refresh)
            TpPlanPage.MASTER -> TpMasterDataPage(data, repository, policy, ::refresh, masterPage) { masterPage = it }
        }
    }
}

@Composable
private fun TpPlanRoot(policy: UserAccessPolicy, data: TpData, onOpen: (TpPlanPage) -> Unit) {
    data class Item(val page: TpPlanPage, val title: String, val badge: Int = 0)
    val plannerBadge = data.orders.count { order ->
        order.status != TpOrderStatus.COMPLETE && order.status != TpOrderStatus.CANCELLED &&
            data.jobs.filter { it.orderId == order.id }.let { jobs -> jobs.isEmpty() || jobs.any { it.planConfirmedAt == null } }
    }
    val machineBadge = data.jobs.filter { it.planConfirmedAt != null && it.materialStatus == TpMaterialStatus.DELIVERED && it.status == TpJobStatus.QUEUED }
        .groupBy { "${it.orderId}|${it.moldCode}|${it.machineId}" }.size
    val items = buildList {
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_ORDER)) add(Item(TpPlanPage.ORDERS, "Nachalnik — zakazlar"))
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_PLANNING)) add(Item(TpPlanPage.PLANNING, "Plan beruvchi — rejalash", plannerBadge))
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_MACHINE)) add(Item(TpPlanPage.MACHINES, "TP brigadir — stanoklar", machineBadge))
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_ATTENDANCE)) add(Item(TpPlanPage.ATTENDANCE, "Davomat"))
    }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-screen-2")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SmartText("Kerakli vazifani tanlang.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        items.forEach { item -> TpNavRow(item.title, item.badge) { onOpen(item.page) } }
    }
}

@Composable
private fun TpOrdersPage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_ORDER)
    var showAdd by remember { mutableStateOf(false) }
    var editOrder by remember { mutableStateOf<TpOrder?>(null) }
    var deleteOrder by remember { mutableStateOf<TpOrder?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val orders = data.orders.sortedWith(
        compareBy<TpOrder> { it.status == TpOrderStatus.COMPLETE || it.status == TpOrderStatus.CANCELLED }
            .thenBy { it.priority }
            .thenByDescending { it.createdAt }
    )

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-screen-3")).navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (canWrite) Button(onClick = { showAdd = true }, Modifier.fillMaxWidth()) { SmartText("+ Yangi zakaz") }
        if (orders.isEmpty()) SmartText("Hali zakaz kiritilmagan.")
        orders.forEach { order ->
            TpCard {
                TpOrderSummary(data, order)
                if (canWrite && order.status != TpOrderStatus.COMPLETE) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { editOrder = order }, Modifier.weight(1f)) { SmartText("Tahrirlash") }
                        OutlinedButton(onClick = { deleteOrder = order }, Modifier.weight(1f)) { SmartText("O‘chirish") }
                    }
                }
            }
        }
        TpError(error)
    }

    if (showAdd) {
        TpOrderDialog(data = data, initial = null, onDismiss = { showAdd = false }) { batch, productId, quantity, priority, note ->
            val result = repo.createOrder(batch, productId, quantity, priority, note)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { showAdd = false; refresh() }
            result.isSuccess
        }
    }

    editOrder?.let { order ->
        TpOrderDialog(data = data, initial = order, onDismiss = { editOrder = null }) { _, productId, quantity, priority, note ->
            val result = repo.updateOrder(order.id, productId, quantity, priority, note)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { editOrder = null; refresh() }
            result.isSuccess
        }
    }

    deleteOrder?.let { order ->
        AlertDialog(
            onDismissRequest = { deleteOrder = null },
            title = { SmartText("Zakazni o‘chirish") },
            text = { SmartText("${order.batchNumber} • ${order.articleSnapshot} zakazi o‘chirilsinmi? Zakaz o‘chirilgach plan vazifalari ham bekor qilinadi va bog‘liq TP/Seryo foydalanuvchilariga xabar boradi.") },
            confirmButton = { TextButton(onClick = {
                val result = repo.deleteOrder(order.id)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { deleteOrder = null; refresh() }
            }) { SmartText("O‘chirish") } },
            dismissButton = { TextButton(onClick = { deleteOrder = null }) { SmartText("Bekor qilish") } }
        )
    }
}

@Composable
private fun TpOrderDialog(
    data: TpData,
    initial: TpOrder?,
    onDismiss: () -> Unit,
    onSave: (String, String, Int, Int, String) -> Boolean
) {
    val products = data.products.filter { !it.archived && it.details.any { detail -> !detail.archived } }.sortedBy { it.article }
    var productId by remember(initial?.id) { mutableStateOf(initial?.productId ?: products.firstOrNull()?.id.orEmpty()) }
    var batch by remember(initial?.id) { mutableStateOf(initial?.batchNumber.orEmpty()) }
    var quantity by remember(initial?.id) { mutableStateOf(initial?.quantity?.toString().orEmpty()) }
    var priority by remember(initial?.id) { mutableIntStateOf(initial?.priority?.coerceIn(1, 3) ?: 2) }
    var note by remember(initial?.id) { mutableStateOf(initial?.note.orEmpty()) }
    var validation by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText(if (initial == null) "Yangi zakaz" else "Zakazni tahrirlash") },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (products.isEmpty()) SmartText("Avval mahsulot va uning detallarini kiriting.", color = MaterialTheme.colorScheme.error)
                if (initial != null) {
                    SmartText("Partiya: ${initial.batchNumber}", fontWeight = FontWeight.Bold)
                } else if (data.orders.isEmpty()) {
                    TpField(batch, { batch = it }, "Birinchi partiya raqami")
                } else {
                    SmartText("Keyingi partiya raqami avtomatik beriladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TpChoice("Mahsulot", productId, products, { it.id }, { "${it.article} — ${it.name}" }) { productId = it }
                TpField(quantity, { quantity = digitsOnly(it) }, "Zakaz soni", KeyboardType.Number)
                SmartText("Ustuvorlik", fontWeight = FontWeight.Bold)
                TpPriorityButtons(priority) { priority = it }
                TpField(note, { note = it }, "Izoh", singleLine = false)
                TpError(validation)
            }
        },
        confirmButton = { TextButton(enabled = products.isNotEmpty(), onClick = {
            val qty = quantity.toIntOrNull()
            validation = when {
                productId.isBlank() || qty == null || qty <= 0 -> "Majburiy maydonlarni to‘ldiring"
                else -> null
            }
            if (validation == null && onSave(batch, productId, qty!!, priority, note)) onDismiss()
        }) { SmartText("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText("Bekor qilish") } }
    )
}

@Composable
private fun TpPriorityButtons(selected: Int, onSelect: (Int) -> Unit) {
    val values = listOf(
        Triple(1, "Eng zaril", Color(0xFFC62828)),
        Triple(2, "Zaril", Color(0xFFFFC107)),
        Triple(3, "Keyinroq", Color(0xFF2E7D32))
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        values.forEach { (value, label, color) ->
            val content = if (value == 2) Color.Black else Color.White
            Button(
                onClick = { onSelect(value) },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = color.copy(alpha = if (selected == value) 1f else 0.45f),
                    contentColor = content
                )
            ) { SmartText(if (selected == value) "✓ $label" else label, style = MaterialTheme.typography.labelSmall) }
        }
    }
}

@Composable
private fun TpOrderSummary(data: TpData, order: TpOrder) {
    val progress = data.orderProgress(order.id)
    val forecast = data.orderForecastMinutes(order.id)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            SmartText("${order.batchNumber} • ${order.articleSnapshot}", fontWeight = FontWeight.Bold)
            SmartText("${order.productNameSnapshot} — ${order.quantity} dona")
        }
        SmartText("${progress.toInt()}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = tpPriorityColor(order.priority).copy(alpha = 0.16f)
        ) {
            SmartText(tpPriorityLabel(order.priority), modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontWeight = FontWeight.SemiBold)
        }
        SmartText("Holat: ${orderStatusLabel(order.status)}", style = MaterialTheme.typography.bodySmall)
    }
    SmartText("Zakaz berildi: ${order.createdAt.take(16).replace('T', ' ')}", style = MaterialTheme.typography.bodySmall)
    SmartText(
        if (forecast > 0) "Taxminiy to‘liq quyish: ${minutesLabel(forecast)}" else "Taxminiy muddat: ma’lumot yetarli emas",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    if (order.note.isNotBlank()) SmartText("Izoh: ${order.note}", style = MaterialTheme.typography.bodySmall)
    if (order.completedAt != null) SmartText("Yakunlandi: ${order.completedAt.take(16).replace('T', ' ')}", style = MaterialTheme.typography.bodySmall)
}

private fun tpPriorityColor(priority: Int): Color = when (priority.coerceIn(1, 3)) {
    1 -> Color(0xFFC62828)
    2 -> Color(0xFFFFC107)
    else -> Color(0xFF2E7D32)
}

private enum class TpPlannerMode { ORDERS, MACHINES }

@Composable
private fun TpPlanningPage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_PLANNING)
    var mode by remember { mutableStateOf(TpPlannerMode.ORDERS) }
    var selectedOrderId by remember { mutableStateOf<String?>(null) }
    var expandedDetails by remember { mutableStateOf<Set<String>>(emptySet()) }
    var assignMold by remember { mutableStateOf<String?>(null) }
    var openColorMenu by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    val visibleOrders = data.orders.filter { it.status != TpOrderStatus.COMPLETE && it.status != TpOrderStatus.CANCELLED }
    fun orderPlanDone(order: TpOrder): Boolean {
        val jobs = data.jobs.filter { it.orderId == order.id }
        return jobs.isNotEmpty() && jobs.all { it.planConfirmedAt != null }
    }
    val pendingOrders = visibleOrders.filterNot(::orderPlanDone)
        .sortedWith(compareBy<TpOrder> { it.priority }.thenBy { it.createdAt })
    val approvedOrders = visibleOrders.filter(::orderPlanDone)
        .sortedWith(compareBy<TpOrder> { it.planApprovedAt.orEmpty() }.thenBy { it.createdAt })
    val selectedOrder = data.orders.firstOrNull { it.id == selectedOrderId }

    BackHandler(enabled = selectedOrder != null || mode == TpPlannerMode.MACHINES) {
        if (selectedOrder != null) {
            selectedOrderId = null; expandedDetails = emptySet(); assignMold = null; openColorMenu = null
        } else mode = TpPlannerMode.ORDERS
    }

    LaunchedEffect(selectedOrderId) {
        val orderId = selectedOrderId ?: return@LaunchedEffect
        val order = data.orders.firstOrNull { it.id == orderId } ?: return@LaunchedEffect
        if (canWrite && order.status != TpOrderStatus.COMPLETE && data.jobs.none { it.orderId == orderId }) {
            val result = repo.generateOrderPlan(orderId)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) refresh()
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == TpPlannerMode.ORDERS, onClick = { mode = TpPlannerMode.ORDERS }, label = { SmartText("Zakazlar bo‘yicha") }, modifier = Modifier.weight(1f))
            FilterChip(selected = mode == TpPlannerMode.MACHINES, onClick = { mode = TpPlannerMode.MACHINES; selectedOrderId = null }, label = { SmartText("Stanoklar bo‘yicha") }, modifier = Modifier.weight(1f))
        }
        if (mode == TpPlannerMode.MACHINES) {
            TpPlannerMachinesView(data, repo, canWrite, refresh)
            return@Column
        }

        val scrollKey = selectedOrder?.let { "tp-planning-order-${it.id}" } ?: "tp-planning-list"
        Column(
            Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState(scrollKey)).navigationBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (selectedOrder == null) {
                SmartText("Zakazlarni detalma-detal rejalang. Tasdiqlangan detal darhol Seryo brigadiriga o‘tadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                SmartText("Tasdiqlanmagan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (pendingOrders.isEmpty()) SmartText("Ko‘rib chiqilishi kerak bo‘lgan zakaz yo‘q.")
                pendingOrders.forEach { order ->
                    val jobs = data.jobs.filter { it.orderId == order.id }
                    val remaining = if (jobs.isEmpty()) data.products.firstOrNull { it.id == order.productId }?.details?.count { !it.archived } ?: 0
                    else jobs.groupBy { it.moldCode }.count { (_, rows) -> rows.any { it.planConfirmedAt == null } }
                    TpCard(Modifier.clickable { selectedOrderId = order.id }) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f)) { TpOrderSummary(data, order) }
                            if (remaining > 0) Surface(shape = RoundedCornerShape(999.dp), color = Color(0xFFD32F2F)) {
                                SmartText(remaining.toString(), Modifier.padding(horizontal = 8.dp, vertical = 3.dp), color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                        SmartText("Tasdiqlanmagan detal: $remaining", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                SmartText("Tasdiqlangan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (approvedOrders.isEmpty()) SmartText("Hali barcha detallari tasdiqlangan zakaz yo‘q.")
                approvedOrders.forEach { order -> TpCard(Modifier.clickable { selectedOrderId = order.id }) { TpOrderSummary(data, order) } }
            } else {
                TextButton(onClick = { selectedOrderId = null; expandedDetails = emptySet() }) { SmartText("‹ Zakazlar") }
                TpCard { TpOrderSummary(data, selectedOrder) }
                val product = data.products.firstOrNull { it.id == selectedOrder.productId }
                val details = product?.details?.filterNot { it.archived }.orEmpty().sortedWith(compareBy<TpDetail> { detail ->
                    val rows = data.jobs.filter { it.orderId == selectedOrder.id && it.outputs.any { out -> out.detailId == detail.id } }
                    rows.isNotEmpty() && rows.all { it.planConfirmedAt != null }
                }.thenBy { it.name })
                if (details.isEmpty()) SmartText("Mahsulot detallari topilmadi.", color = MaterialTheme.colorScheme.error)
                details.forEach { detail ->
                    val detailJobs = data.jobs.filter { job -> job.orderId == selectedOrder.id && job.outputs.any { it.detailId == detail.id } }
                        .sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id })
                    val confirmed = detailJobs.isNotEmpty() && detailJobs.all { it.planConfirmedAt != null }
                    val machineIds = detailJobs.mapNotNull { it.machineId }.distinct()
                    val machineLabel = when {
                        detailJobs.isEmpty() -> "Stanok"
                        machineIds.size == 1 -> {
                            val machine = data.machines.firstOrNull { it.id == machineIds.first() }
                            val shop = machine?.let { m -> data.shops.firstOrNull { it.id == m.shopId }?.name }.orEmpty()
                            if (machine == null) "Stanok" else "${machine.number} • ${shop.ifBlank { "Sex" }}"
                        }
                        machineIds.isEmpty() -> "Stanok"
                        else -> "Aralash"
                    }
                    val total = selectedOrder.quantity * detail.requiredPerProduct
                    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp,
                        color = if (confirmed) MaterialTheme.colorScheme.primaryContainer.copy(alpha = .55f) else MaterialTheme.colorScheme.surface) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Column(Modifier.weight(1f)) {
                                    SmartText(detail.name, fontWeight = FontWeight.Bold)
                                    SmartText("Jami: $total dona", color = MaterialTheme.colorScheme.primary)
                                    if (confirmed) SmartText("✓ Rejalangan va tasdiqlangan", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                                }
                                Button(enabled = canWrite && detailJobs.isNotEmpty(), onClick = { assignMold = detail.moldCode }) {
                                    SmartText(if (confirmed) "Tahrirlash • $machineLabel" else machineLabel)
                                }
                            }
                            val assignedMachineId = machineIds.singleOrNull()?.takeIf { id -> detailJobs.all { it.machineId == id } }
                            if (assignedMachineId != null) {
                                val targetIds = detailJobs.map { it.id }.toSet()
                                val wait = data.jobs.filter { it.machineId == assignedMachineId && it.status != TpJobStatus.COMPLETE && it.id !in targetIds && it.planConfirmedAt != null }.sumOf { it.estimatedMinutes }
                                SmartText(if (wait > 0) "Boshlanishi taxminan ${minutesLabel(wait)} dan keyin" else "Stanok bo‘sh — boshlash mumkin", style = MaterialTheme.typography.bodySmall)
                            }
                            if (!confirmed && detailJobs.isNotEmpty() && detailJobs.all { it.machineId != null && it.brigadeId != null && it.shiftId != null }) {
                                Button(enabled = canWrite, onClick = {
                                    val result = repo.confirmPlannedMold(selectedOrder.id, detail.moldCode)
                                    error = result.exceptionOrNull()?.message
                                    if (result.isSuccess) refresh()
                                }, modifier = Modifier.fillMaxWidth()) { SmartText("✓ Shu detalni tasdiqlash") }
                            }
                            TextButton(onClick = { expandedDetails = if (detail.id in expandedDetails) expandedDetails - detail.id else expandedDetails + detail.id }) {
                                SmartText(if (detail.id in expandedDetails) "▲ Ranglarni yopish" else "▼ Ranglarni ko‘rish")
                            }
                            if (detail.id in expandedDetails) {
                                detailJobs.forEachIndexed { index, job ->
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        SmartText("${job.colorCode} — ${job.outputs.firstOrNull { it.detailId == detail.id }?.requiredPieces ?: 0} dona", Modifier.weight(1f))
                                        if (!confirmed && canWrite) Box {
                                            OutlinedButton(onClick = { openColorMenu = job.id }) { SmartText("${index + 1}") }
                                            DropdownMenu(expanded = openColorMenu == job.id, onDismissRequest = { openColorMenu = null }) {
                                                detailJobs.indices.forEach { pos -> DropdownMenuItem(text = { SmartText("${pos + 1}-navbat") }, onClick = {
                                                    openColorMenu = null
                                                    val result = repo.setColorPosition(job.id, pos + 1)
                                                    error = result.exceptionOrNull()?.message
                                                    if (result.isSuccess) refresh()
                                                }) }
                                            }
                                        } else SmartText("${index + 1}")
                                    }
                                }
                            }
                        }
                    }
                }
                val remaining = data.jobs.filter { it.orderId == selectedOrder.id }.groupBy { it.moldCode }.count { (_, rows) -> rows.any { it.planConfirmedAt == null } }
                if (remaining > 0) SmartText("Tasdiqlanmagan detal: $remaining. Har bir detal tasdiqlangach Seryoga alohida yuboriladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                else SmartText("✓ Barcha detallar rejalandi. Zakaz avtomatik tasdiqlanganlar ro‘yxatiga o‘tdi.", color = MaterialTheme.colorScheme.primary)
            }
            TpError(error)
        }
    }

    val order = selectedOrder
    val mold = assignMold
    if (order != null && mold != null) {
        val target = data.jobs.filter { it.orderId == order.id && it.moldCode == mold }
        val editing = target.any { it.planConfirmedAt != null }
        TpMachinePickerDialog(
            data = data, order = order, moldCode = mold, editing = editing,
            onDismiss = { assignMold = null },
            onSave = { machineId, reason ->
                val result = repo.assignMoldJobs(order.id, mold, machineId, reason)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { assignMold = null; refresh() }
                result.isSuccess
            }
        )
    }
}

@Composable
private fun TpPlannerMachinesView(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    var shopId by remember(shops) { mutableStateOf(shops.firstOrNull()?.id.orEmpty()) }
    var selectedMachineId by remember { mutableStateOf<String?>(null) }
    var showMachineOrders by remember { mutableStateOf(false) }
    var selectedOrderId by remember { mutableStateOf<String?>(null) }
    var assignMold by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val machines = data.machines.filter { !it.archived && (shopId.isBlank() || it.shopId == shopId) }
    fun remaining(machineId: String): Int = data.jobs.filter { it.machineId == machineId && it.planConfirmedAt != null && it.status != TpJobStatus.COMPLETE }.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
    fun lastActivity(machineId: String): String = data.jobs.filter { it.machineId == machineId }.mapNotNull { it.startedAt ?: it.materialDeliveredAt ?: it.planEditedAt ?: it.planConfirmedAt }.maxOrNull().orEmpty()
    val idle = machines.filter { remaining(it.id) == 0 }.sortedWith(compareBy<TpMachine> { lastActivity(it.id) }.thenBy { it.number })
    val busy = machines.filter { remaining(it.id) > 0 }.sortedWith(compareBy<TpMachine> { remaining(it.id) }.thenBy { it.number })
    val selectedMachine = machines.firstOrNull { it.id == selectedMachineId }

    BackHandler(enabled = selectedMachineId != null) { selectedMachineId = null; showMachineOrders = false; selectedOrderId = null; assignMold = null }
    LaunchedEffect(selectedOrderId) {
        val id = selectedOrderId ?: return@LaunchedEffect
        if (data.jobs.none { it.orderId == id } && canWrite) {
            val result = repo.generateOrderPlan(id); error = result.exceptionOrNull()?.message; if (result.isSuccess) refresh()
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("tp-planner-machines")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (selectedMachine == null) {
            SmartText("Sex", fontWeight = FontWeight.Bold)
            TpFilterRow(shops, shopId, { it.id }, { it.name }) { shopId = it }
            SmartText("Ishsiz stanoklar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (idle.isEmpty()) SmartText("Ishsiz stanok yo‘q.")
            idle.forEach { machine -> TpCard(Modifier.clickable { selectedMachineId = machine.id; showMachineOrders = false }) { SmartText("${machine.number}-stanok", fontWeight = FontWeight.Bold); SmartText("Ishsiz • eng oxirgi faoliyat: ${lastActivity(machine.id).take(16).replace('T',' ').ifBlank { "noma’lum" }}") } }
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            SmartText("Ishi bor stanoklar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            busy.forEach { machine ->
                val mins = remaining(machine.id)
                TpCard(Modifier.clickable { selectedMachineId = machine.id; showMachineOrders = false }) {
                    SmartText("${machine.number}-stanok", fontWeight = FontWeight.Bold)
                    SmartText("Ishi: ${minutesLabel(mins)}", color = if (mins <= 1080) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                    if (mins <= 1080) SmartText("⚠ 18 soat yoki undan kam ish qolgan", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            TextButton(onClick = { selectedMachineId = null; showMachineOrders = false; selectedOrderId = null }) { SmartText("‹ Stanoklar") }
            TpCard {
                SmartText("${selectedMachine.number}-stanok", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                SmartText("Jami rejalangan ish: ${minutesLabel(remaining(selectedMachine.id))}")
                val queue = data.jobs.filter { it.machineId == selectedMachine.id && it.planConfirmedAt != null && it.status != TpJobStatus.COMPLETE }.sortedBy { it.priority }
                queue.take(5).forEach { job ->
                    val order = data.orders.firstOrNull { it.id == job.orderId }
                    SmartText("• ${order?.articleSnapshot.orEmpty()} • ${job.outputs.joinToString { it.detailName }} • ${job.colorCode}", style = MaterialTheme.typography.bodySmall)
                }
            }
            FilledTonalButton(onClick = { showMachineOrders = !showMachineOrders; if (!showMachineOrders) selectedOrderId = null }, modifier = Modifier.fillMaxWidth()) {
                SmartText(if (showMachineOrders) "Zakazlarni yopish" else "Zakazlar")
            }
            if (showMachineOrders) {
            SmartText("Zakazlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            val orders = data.orders.filter { it.status != TpOrderStatus.COMPLETE && it.status != TpOrderStatus.CANCELLED }.sortedWith(compareBy<TpOrder> { it.priority }.thenBy { it.createdAt })
            if (selectedOrderId == null) {
                orders.forEach { order ->
                    val jobs = data.jobs.filter { it.orderId == order.id && it.status != TpJobStatus.COMPLETE }
                    val candidates = if (jobs.isNotEmpty()) jobs else run {
                        var previewIndex = 0
                        buildPlanJobs(data, order) { "preview-${order.id}-${previewIndex++}" }
                    }
                    val compatible = candidates.any { it.acceptsMachine(selectedMachine, data) }
                    if (compatible) TpCard(Modifier.clickable { selectedOrderId = order.id }) { TpOrderSummary(data, order); SmartText("Shu stanokka mos detallarni ko‘rish", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
                }
            } else {
                val order = data.orders.firstOrNull { it.id == selectedOrderId }
                TextButton(onClick = { selectedOrderId = null }) { SmartText("‹ Zakazlar") }
                if (order != null) {
                    TpCard { TpOrderSummary(data, order) }
                    val groups = data.jobs.filter { it.orderId == order.id && it.status != TpJobStatus.COMPLETE }.groupBy { it.moldCode }
                    val compatible = groups.filterValues { rows -> rows.all { it.acceptsMachine(selectedMachine, data) } }
                    val incompatible = groups.filterKeys { it !in compatible.keys }
                    compatible.forEach { (mold, rows) ->
                        val names = rows.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString()
                        val plannedMachine = rows.mapNotNull { it.machineId }.distinct().singleOrNull()
                        val plannedNumber = data.machines.firstOrNull { it.id == plannedMachine }?.number
                        val confirmed = rows.all { it.planConfirmedAt != null }
                        TpCard {
                            SmartText(names.ifBlank { mold }, fontWeight = FontWeight.Bold)
                            SmartText(if (plannedMachine == selectedMachine.id) "Shu stanokka rejalangan${if (confirmed) " • tasdiqlangan" else ""}" else if (plannedMachine != null) "Rejalangan: ${plannedNumber ?: "?"}-stanok" else "Rejalanmagan")
                            if (canWrite) Button(onClick = { assignMold = mold }, Modifier.fillMaxWidth()) { SmartText(if (plannedMachine == null) "Shu stanokka rejalash" else "Planni tahrirlash") }
                            if (!confirmed && plannedMachine == selectedMachine.id && rows.all { it.brigadeId != null }) Button(onClick = { val r=repo.confirmPlannedMold(order.id,mold); error=r.exceptionOrNull()?.message; if(r.isSuccess) refresh() }, Modifier.fillMaxWidth()) { SmartText("✓ Tasdiqlash") }
                        }
                    }
                    if (incompatible.isNotEmpty()) {
                        HorizontalDivider(); SmartText("⚠ Bu stanokka tushmaydigan detallar", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                        incompatible.forEach { (_, rows) -> SmartText("• ${rows.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString()}", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            }
            TpError(error)
        }
    }
    val order = data.orders.firstOrNull { it.id == selectedOrderId }
    val mold = assignMold
    if (selectedMachine != null && order != null && mold != null) {
        val target = data.jobs.filter { it.orderId == order.id && it.moldCode == mold }
        TpFixedMachineAssignDialog(data, order, target, selectedMachine, target.any { it.machineId != null }, onDismiss = { assignMold = null }) { reason ->
            val r = repo.assignMoldJobs(order.id, mold, selectedMachine.id, reason); error = r.exceptionOrNull()?.message
            if (r.isSuccess) { assignMold = null; refresh() }; r.isSuccess
        }
    }
}

private fun commonJobResinOptions(data: TpData, job: TpPlanJob): List<String> {
    val sets = job.outputs.mapNotNull { output ->
        data.products.asSequence().flatMap { it.details.asSequence() }
            .firstOrNull { it.id == output.detailId }?.resinOptions()?.toSet()
    }
    if (sets.isEmpty()) return listOfNotNull(job.resinCode.takeIf { it.isNotBlank() })
    return sets.drop(1).fold(sets.first()) { acc, set -> acc intersect set }.sorted()
}

@Composable
private fun TpMachinePickerDialog(
    data: TpData,
    order: TpOrder,
    moldCode: String,
    editing: Boolean = false,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Boolean
) {
    val targetJobs = data.jobs.filter { it.orderId == order.id && it.moldCode == moldCode }
    val targetIds = targetJobs.map { it.id }.toSet()
    fun availability(machineId: String): Int = data.jobs
        .filter { it.machineId == machineId && it.status != TpJobStatus.COMPLETE && it.id !in targetIds }
        .sumOf { it.estimatedMinutes }
    val machines = data.machines
        .filter { machine -> !machine.archived && targetJobs.isNotEmpty() && targetJobs.all { it.acceptsMachine(machine, data) } }
        .sortedWith(compareBy<TpMachine> { availability(it.id) }.thenBy { it.number })
    val currentMachineId = targetJobs.mapNotNull { it.machineId }.distinct().singleOrNull()
    var machineId by remember(order.id, moldCode) { mutableStateOf(currentMachineId ?: machines.firstOrNull()?.id.orEmpty()) }
    val selectedMachine = machines.firstOrNull { it.id == machineId }
    var infoMachine by remember { mutableStateOf<TpMachine?>(null) }
    var editReason by remember(order.id, moldCode, editing) { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText("Stanok tanlash") },
        text = {
            Column(Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val detailNames = targetJobs.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString()
                if (detailNames.isNotBlank()) SmartText("Detal: $detailNames", fontWeight = FontWeight.Bold)
                if (machines.isEmpty()) {
                    SmartText("Bu detal/qolip sig‘imiga mos stanok topilmadi. Stanok va detal sig‘im ma’lumotlarini tekshiring.", color = MaterialTheme.colorScheme.error)
                } else {
                    SmartText("Bo‘sh stanoklar tepada. Band stanoklar eng tez bo‘shaydiganidan boshlab tartiblangan.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val freeMachines = machines.filter { availability(it.id) == 0 }
                    val busyMachines = machines.filter { availability(it.id) > 0 }
                    if (freeMachines.isNotEmpty()) SmartText("Bo‘sh stanoklar", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    (freeMachines + busyMachines).forEachIndexed { index, machine ->
                        if (index == freeMachines.size && busyMachines.isNotEmpty()) {
                            SmartText("Band stanoklar", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        val wait = availability(machine.id)
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable { machineId = machine.id },
                            shape = RoundedCornerShape(14.dp),
                            tonalElevation = if (machine.id == machineId) 4.dp else 1.dp
                        ) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                RadioButton(selected = machine.id == machineId, onClick = { machineId = machine.id })
                                Column(Modifier.weight(1f)) {
                                    val shopName = data.shops.firstOrNull { it.id == machine.shopId }?.name.orEmpty()
                                    SmartText("${machine.number}-stanok • ${shopName.ifBlank { "Sex" }}${if (machine.capacity > 0) " • sig‘im ${machine.capacity}" else ""}", fontWeight = FontWeight.Bold)
                                    SmartText(if (wait == 0) "Bo‘sh" else "Band • taxminan ${minutesLabel(wait)} dan keyin bo‘shaydi", color = if (wait == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                TextButton(onClick = { infoMachine = machine }) { SmartText("Ma’lumot") }
                            }
                        }
                    }
                    selectedMachine?.let { machine ->
                        val wait = availability(machine.id)
                        SmartText(if (wait == 0) "Tanlangan stanokda ishni darhol boshlash mumkin." else "Tanlangan stanokda boshlanish: taxminan ${minutesLabel(wait)} dan keyin.", fontWeight = FontWeight.SemiBold)
                        val targetIdsForAuto = targetJobs.map { it.id }.toSet()
                        val waitForAuto = data.jobs.filter { it.machineId == machine.id && it.status != TpJobStatus.COMPLETE && it.id !in targetIdsForAuto }.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
                        val autoBrigade = data.autoBrigadeForMachine(machine.id, waitForAuto)
                        if (autoBrigade != null) {
                            val shift = data.shifts.firstOrNull { it.id == autoBrigade.shiftId }
                            SmartText("Brigada avtomatik: ${autoBrigade.name}${shift?.name?.let { " • $it" }.orEmpty()}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        } else SmartText("Bu sex uchun smenaga mos brigada topilmadi.", color = MaterialTheme.colorScheme.error)
                        if (editing) {
                            TpField(editReason, { editReason = it }, "Tahrirlash sharhi *", singleLine = false)
                            SmartText("Tasdiqlangan/rejalangan detalni o‘zgartirish sababi majburiy.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(enabled = machineId.isNotBlank() && selectedMachine?.let { machine ->
            val ids = targetJobs.map { it.id }.toSet()
            val wait = data.jobs.filter { it.machineId == machine.id && it.status != TpJobStatus.COMPLETE && it.id !in ids }.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
            data.autoBrigadeForMachine(machine.id, wait) != null
        } == true && (!editing || editReason.isNotBlank()), onClick = {
            if (onSave(machineId, editReason)) onDismiss()
        }) { SmartText(if (editing) "Tahrirlash" else "Tanlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText("Bekor qilish") } }
    )

    infoMachine?.let { machine ->
        val current = data.activeJobsForMachine(machine.id).firstOrNull { it.id !in targetIds }
        val currentOrder = current?.let { job -> data.orders.firstOrNull { it.id == job.orderId } }
        AlertDialog(
            onDismissRequest = { infoMachine = null },
            title = { SmartText("${machine.number}-stanok") },
            text = {
                if (current == null) SmartText("Hozir bo‘sh.") else Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    SmartText("Hozir band", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                    SmartText("Partiya: ${currentOrder?.batchNumber.orEmpty()}")
                    SmartText("Artikul: ${currentOrder?.articleSnapshot.orEmpty()}")
                    SmartText("Mahsulot: ${currentOrder?.productNameSnapshot.orEmpty()}")
                    SmartText("Detal: ${current.outputs.joinToString { it.detailName }}")
                    SmartText("Rang: ${current.colorCode}")
                    if (current.resinCode.isNotBlank()) SmartText("Seryo: ${current.resinCode}")
                    SmartText("Holat: ${jobStatusLabel(current.status)}")
                    SmartText("Taxminiy vazifa vaqti: ${minutesLabel(current.estimatedMinutes)}")
                }
            },
            confirmButton = { TextButton(onClick = { infoMachine = null }) { SmartText("Yopish") } }
        )
    }
}

@Composable
private fun TpFixedMachineAssignDialog(
    data: TpData,
    order: TpOrder,
    targetJobs: List<TpPlanJob>,
    machine: TpMachine,
    editing: Boolean,
    onDismiss: () -> Unit,
    onSave: (String) -> Boolean
) {
    val targetIds = targetJobs.map { it.id }.toSet()
    val waitMinutes = data.jobs.filter { it.machineId == machine.id && it.status != TpJobStatus.COMPLETE && it.id !in targetIds }.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
    val autoBrigade = data.autoBrigadeForMachine(machine.id, waitMinutes)
    var reason by remember(machine.id, order.id, editing) { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { SmartText("${machine.number}-stanokka rejalash") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SmartText("${order.articleSnapshot} • ${order.productNameSnapshot}", fontWeight = FontWeight.Bold)
            SmartText(targetJobs.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString())
            if (autoBrigade != null) {
                val shift = data.shifts.firstOrNull { it.id == autoBrigade.shiftId }
                SmartText("Brigada avtomatik: ${autoBrigade.name}${shift?.name?.let { " • $it" }.orEmpty()}", color = MaterialTheme.colorScheme.primary)
            } else SmartText("Bu sex uchun smenaga mos brigada topilmadi.", color = MaterialTheme.colorScheme.error)
            SmartText(if (waitMinutes <= 0) "Stanok bo‘sh — reja hozirgi smenadan boshlanadi." else "Stanok band — navbatdagi ish taxminan ${minutesLabel(waitMinutes)} dan keyin boshlanadi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (editing) TpField(reason, { reason = it }, "Tahrirlash sharhi *", singleLine = false)
        } },
        confirmButton = { TextButton(enabled = autoBrigade != null && (!editing || reason.isNotBlank()), onClick = { if (onSave(reason)) onDismiss() }) { SmartText("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { SmartText("Bekor qilish") } }
    )
}

@Composable
private fun TpMachineQueuePage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_MACHINE)
    var error by remember { mutableStateOf<String?>(null) }
    var expandedMachineId by remember { mutableStateOf<String?>(null) }
    var downtimeMachine by remember { mutableStateOf<TpMachine?>(null) }

    val allowedBrigadeIds = policy.allowedBrigadeIds
    val visibleBrigades = data.brigades.filter { !it.archived && (policy.isAdmin() || allowedBrigadeIds == null || it.id in allowedBrigadeIds) }
    val visibleShopIds = visibleBrigades.map { it.shopId }.toSet()
    val machines = data.machines.filter { !it.archived && (policy.isAdmin() || visibleShopIds.isEmpty() || it.shopId in visibleShopIds) }
    val jobsByMachine = machines.associate { machine ->
        machine.id to data.jobs.filter { job ->
            job.machineId == machine.id && job.planConfirmedAt != null && job.status != TpJobStatus.COMPLETE &&
                (policy.isAdmin() || allowedBrigadeIds == null || job.brigadeId in allowedBrigadeIds)
        }
    }
    val withOrders = machines.filter { jobsByMachine[it.id].orEmpty().isNotEmpty() }.sortedBy { machine ->
        jobsByMachine[machine.id].orEmpty().minOfOrNull { it.planConfirmedAt.orEmpty() }.orEmpty()
    }
    val withoutOrders = machines.filter { jobsByMachine[it.id].orEmpty().isEmpty() }.sortedBy { it.number }

    fun machineBrigadeId(machine: TpMachine): String? {
        val active = jobsByMachine[machine.id].orEmpty().firstOrNull()?.brigadeId
        if (!active.isNullOrBlank()) return active
        return visibleBrigades.firstOrNull { it.shopId == machine.shopId }?.id
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-machine-queue-all"))
            .navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SmartText("Zakazi bor stanoklar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (withOrders.isEmpty()) SmartText("Hozir zakazli stanok yo‘q.")

        @Composable
        fun machineCard(machine: TpMachine, rows: List<TpPlanJob>, hasOrder: Boolean) {
            val shop = data.shops.firstOrNull { it.id == machine.shopId }
            val today = LocalDate.now().toString()
            val todayDowntimes = data.machineDowntimes.filter { it.machineId == machine.id && it.date == today }
            val expanded = expandedMachineId == machine.id
            TpCard {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        SmartText("${machine.number}-stanok • ${shop?.name.orEmpty()}", fontWeight = FontWeight.Bold)
                        if (!hasOrder) {
                            SmartText("Zakaz yo‘q", color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold)
                        } else {
                            val orders = rows.mapNotNull { job -> data.orders.firstOrNull { it.id == job.orderId } }.distinctBy { it.id }
                            SmartText(orders.joinToString(" • ") { "${it.articleSnapshot} ${it.productNameSnapshot}" }.ifBlank { "Zakaz mavjud" })
                            val delivered = rows.count { it.materialStatus == TpMaterialStatus.DELIVERED }
                            if (delivered > 0) SmartText("✓ Seryo yetkazilgan: $delivered/${rows.size}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                            SmartText("Jami ish: ${minutesLabel(rows.sumOf { it.estimatedMinutes.coerceAtLeast(0) })}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (todayDowntimes.isNotEmpty()) {
                            SmartText("Bugun o‘chish: ${todayDowntimes.size} marta • ${minutesLabel(todayDowntimes.sumOf { it.durationMinutes() })}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    if (hasOrder) TextButton(onClick = { expandedMachineId = if (expanded) null else machine.id }) { SmartText(if (expanded) "▲" else "▼") }
                }
                if (canWrite) {
                    OutlinedButton(onClick = { downtimeMachine = machine }, modifier = Modifier.fillMaxWidth()) { SmartText("+ Stanok o‘chishini qo‘shish") }
                }
                if (expanded) {
                    HorizontalDivider(Modifier.padding(vertical = 4.dp))
                    rows.groupBy { "${it.orderId}|${it.moldCode}" }.values.forEach { group ->
                        val order = data.orders.firstOrNull { it.id == group.first().orderId }
                        val details = group.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString()
                        SmartText("${order?.articleSnapshot.orEmpty()} • $details", fontWeight = FontWeight.Bold)
                        group.sortedBy { it.priority }.forEach { job ->
                            val delivered = job.materialStatus == TpMaterialStatus.DELIVERED
                            val started = job.status == TpJobStatus.IN_PROGRESS
                            Surface(
                                Modifier.fillMaxWidth().padding(vertical = 3.dp),
                                shape = RoundedCornerShape(12.dp),
                                color = if (started) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .45f)
                            ) {
                                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    SmartText("Rang ${job.colorCode} • Seryo ${job.resinCode}", fontWeight = FontWeight.SemiBold)
                                    SmartText(tpBrigadirTimingLabel(job), style = MaterialTheme.typography.bodySmall)
                                    SmartText(if (delivered) "✓ Seryo yetkazilgan" else "Seryo yetkazilmagan", color = if (delivered) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                                    if (canWrite && !started) Button(
                                        enabled = job.status == TpJobStatus.QUEUED && delivered,
                                        onClick = {
                                            error = repo.setJobStatus(job.id, TpJobStatus.IN_PROGRESS).exceptionOrNull()?.message
                                            if (error == null) refresh()
                                        }, modifier = Modifier.fillMaxWidth()
                                    ) { SmartText("Boshlash") }
                                    if (started) {
                                        val completeReady = job.outputs.all { output ->
                                            data.receipts.filter { it.jobId == job.id && it.detailId == output.detailId }.sumOf { it.creditedPieces } >= output.requiredPieces
                                        }
                                        SmartText("Boshlangan: ${job.startedAt?.take(16)?.replace('T', ' ') ?: "—"}")
                                        if (canWrite && completeReady) Button(onClick = {
                                            error = repo.setJobStatus(job.id, TpJobStatus.COMPLETE).exceptionOrNull()?.message
                                            if (error == null) refresh()
                                        }, Modifier.fillMaxWidth()) { SmartText("Tugadi") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        withOrders.forEach { machine -> machineCard(machine, jobsByMachine[machine.id].orEmpty(), true) }
        HorizontalDivider(Modifier.padding(vertical = 6.dp))
        SmartText("Zakazi yo‘q stanoklar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (withoutOrders.isEmpty()) SmartText("Barcha stanokda zakaz bor.")
        withoutOrders.forEach { machine -> machineCard(machine, emptyList(), false) }
        TpError(error)
    }

    downtimeMachine?.let { machine ->
        val brigadeId = machineBrigadeId(machine)
        var date by remember(machine.id) { mutableStateOf(LocalDate.now().toString()) }
        var stoppedAt by remember(machine.id) { mutableStateOf(java.time.LocalTime.now().minusMinutes(30).withSecond(0).withNano(0).toString().take(5)) }
        var resumedAt by remember(machine.id) { mutableStateOf(java.time.LocalTime.now().withSecond(0).withNano(0).toString().take(5)) }
        var note by remember(machine.id) { mutableStateOf("") }
        val context = LocalContext.current
        AlertDialog(
            onDismissRequest = { downtimeMachine = null },
            title = { SmartText("${machine.number}-stanok • o‘chish") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SmartText("Bir kunda bir necha marta o‘chish qo‘shish mumkin. Vaqtni brigadir amaldagi holatga moslab o‘zi belgilaydi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TpDatePickerButton("Sana", date) { date = it }
                TpTimePickerButton("O‘chgan vaqt", stoppedAt) { stoppedAt = it }
                TpTimePickerButton("Yongan vaqt", resumedAt) { resumedAt = it }
                TpField(note, { note = it }, "Sabab / izoh *", singleLine = false)
            } },
            confirmButton = { TextButton(enabled = brigadeId != null && note.isNotBlank(), onClick = {
                val result = repo.addMachineDowntime(machine.id, brigadeId.orEmpty(), date, stoppedAt, resumedAt, note, policy.displayName)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { downtimeMachine = null; refresh() }
            }) { SmartText("Saqlash") } },
            dismissButton = { TextButton(onClick = { downtimeMachine = null }) { SmartText("Bekor qilish") } }
        )
    }
}

@Composable
private fun TpTimePickerButton(label: String, value: String, onTime: (String) -> Unit) {
    val context = LocalContext.current
    val initial = remember(value) { runCatching { java.time.LocalTime.parse(value) }.getOrDefault(java.time.LocalTime.now()) }
    OutlinedButton(
        onClick = {
            android.app.TimePickerDialog(context, { _, hour, minute -> onTime(String.format(java.util.Locale.US, "%02d:%02d", hour, minute)) }, initial.hour, initial.minute, true).show()
        },
        modifier = Modifier.fillMaxWidth()
    ) { SmartText("$label: $value", Modifier.weight(1f)) }
}

@Composable
private fun TpAttendancePage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_ATTENDANCE)
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    var shopId by remember { mutableStateOf("") }
    val brigades = data.brigades.filterNot { it.archived }.filter { shopId.isBlank() || it.shopId == shopId }.sortedBy { it.name }
    var brigadeId by remember(shopId) { mutableStateOf("") }
    var editWorker by remember { mutableStateOf<TpWorker?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val visibleBrigadeIds = brigades.map { it.id }.toSet()
    val workers = data.workers.filter { !it.archived && it.brigadeId in visibleBrigadeIds && (brigadeId.isBlank() || it.brigadeId == brigadeId) }.sortedBy { it.name }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-screen-6")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SmartText("Davomatni TP plan beruvchi kiritadi. Ish vaqti smena davomiyligidan minus soatni ayirish orqali avtomatik hisoblanadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        TpField(date, { date = it }, "Sana (YYYY-MM-DD)")
        TpChoice("Bo‘lim", shopId, listOf(TpShop("", "Barcha bo‘limlar")) + shops, { it.id }, { it.name }) { shopId = it }
        TpChoice("Brigada", brigadeId, listOf(TpBrigade("", "", "", "Barcha brigadalar")) + brigades, { it.id }, { it.name }) { brigadeId = it }
        if (workers.isEmpty()) SmartText("Tanlangan filtrda ishchi yo‘q.")
        val fullWorkers = workers.filter { worker -> data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }.let { day -> day == null || (day.present && day.minusHours <= 0.0) } }
        val minusWorkers = workers.filter { worker -> data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }?.let { it.present && it.minusHours > 0.0 } == true }
        val absentWorkers = workers.filter { worker -> data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }?.present == false }
        val groups = listOf("To‘liq ishlagan" to fullWorkers, "Minus soati bor" to minusWorkers, "Ishlamagan" to absentWorkers)
        groups.forEachIndexed { groupIndex, (groupTitle, groupWorkers) ->
            if (groupIndex > 0) HorizontalDivider(Modifier.padding(vertical = 6.dp))
            SmartText(groupTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (groupWorkers.isEmpty()) SmartText("—", color = MaterialTheme.colorScheme.onSurfaceVariant)
            groupWorkers.forEach { worker ->
                val day = data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }
                val actualMinutes = if (day == null) data.workerStandardMinutes(worker.id) else data.attendanceWorkMinutes(worker.id, date)
                TpCard(Modifier.clickable(enabled = canWrite) { editWorker = worker }) {
                    SmartText(worker.name, fontWeight = FontWeight.Bold)
                    SmartText(data.brigades.firstOrNull { it.id == worker.brigadeId }?.name.orEmpty(), style = MaterialTheme.typography.bodySmall)
                    SmartText(when {
                        day == null -> "To‘liq ishlagan (standart) • ${data.workerStandardMinutes(worker.id)} daqiqa"
                        !day.present -> "Ishlamadi"
                        day.minusHours > 0.0 -> "Minus ${formatTpNumber(day.minusHours)} soat • hisobdagi ish vaqti $actualMinutes daqiqa"
                        else -> "To‘liq ishlagan • $actualMinutes daqiqa"
                    })
                    SmartText("Umumiy kunlik norma: ${data.globalDailyTargetAmount()} so‘m", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        TpError(error)
    }
    editWorker?.let { worker ->
        val existing = data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }
        var present by remember(worker.id, date) { mutableStateOf(existing?.present ?: true) }
        var minusHours by remember(worker.id, date) { mutableStateOf(existing?.minusHours?.takeIf { it > 0.0 }?.let(::formatTpNumber) ?: "") }
        val standardMinutes = data.workerStandardMinutes(worker.id)
        val parsedMinus = minusHours.toDoubleOrNull() ?: 0.0
        val calculated = if (present) (standardMinutes - kotlin.math.round(parsedMinus * 60.0).toInt()).coerceAtLeast(0) else 0
        AlertDialog(
            onDismissRequest = { editWorker = null },
            title = { SmartText(worker.name) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SmartText("Smena bo‘yicha standart: ${minutesLabel(standardMinutes)}")
                Row(verticalAlignment = Alignment.CenterVertically) { SmartText("Ishda", Modifier.weight(1f)); Switch(present, { present = it; if (!it) minusHours = "" }) }
                TpField(minusHours, { minusHours = decimalInput(it) }, "Minus soat", KeyboardType.Decimal, enabled = present)
                SmartText("Hisoblanadigan ish vaqti: ${minutesLabel(calculated)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                SmartText("Masalan 1 soat = 60 daqiqa, 1.5 soat = 90 daqiqa.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } },
            confirmButton = { TextButton(onClick = {
                val result = repo.setAttendance(worker.id, date, present, minusHours.toDoubleOrNull() ?: 0.0)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { editWorker = null; refresh() }
            }) { SmartText("Saqlash") } },
            dismissButton = { TextButton(onClick = { editWorker = null }) { SmartText("Bekor qilish") } }
        )
    }
}

@Composable
internal fun TpNavRow(title: String, badgeCount: Int = 0, onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            SmartText(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            if (badgeCount > 0) {
                Surface(shape = RoundedCornerShape(999.dp), color = Color(0xFFD32F2F)) {
                    SmartText(badgeCount.coerceAtMost(999).toString(), Modifier.padding(horizontal = 8.dp, vertical = 2.dp), color = Color.White, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(8.dp))
            }
            SmartText("›", style = MaterialTheme.typography.headlineSmall)
        }
    }
}

@Composable
internal fun TpCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp), content = content)
    }
}

@Composable
internal fun TpField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    enabled: Boolean = true
) {
    val numeric = keyboardType == KeyboardType.Number || keyboardType == KeyboardType.Decimal
    var focusedBefore by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { SmartText(label) },
        modifier = Modifier.fillMaxWidth().onFocusChanged { state ->
            if (numeric && state.isFocused && !focusedBefore && value.trim() in setOf("0", "0.0", "0.00")) onChange("")
            focusedBefore = state.isFocused
        },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType), singleLine = singleLine, enabled = enabled
    )
}

@Composable
internal fun <T> TpChoice(
    label: String,
    selectedId: String,
    options: List<T>,
    id: (T) -> String,
    text: (T) -> String,
    onSelect: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val selected = options.firstOrNull { id(it) == selectedId }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            SmartText("$label: ${selected?.let(text) ?: "Tanlang"}", Modifier.weight(1f))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { option -> DropdownMenuItem(text = { SmartText(text(option)) }, onClick = { open = false; onSelect(id(option)) }) }
        }
    }
}

@Composable
internal fun TpError(message: String?) {
    if (!message.isNullOrBlank()) SmartText(message, color = MaterialTheme.colorScheme.error)
}

internal fun digitsOnly(value: String): String = value.filter(Char::isDigit)
internal fun decimalInput(value: String): String {
    var separator = false
    return buildString {
        value.forEach { char ->
            if (char.isDigit()) append(char)
            else if ((char == '.' || char == ',') && !separator) { append('.'); separator = true }
        }
    }
}
private fun tpBrigadirTimingLabel(job: TpPlanJob): String {
    val planned = minutesLabel(job.estimatedMinutes.coerceAtLeast(0))
    val started = job.startedAt?.let { runCatching { java.time.LocalDateTime.parse(it) }.getOrNull() }
        ?: return "Taxminiy davomiylik: $planned"
    val finish = started.plusMinutes(job.estimatedMinutes.coerceAtLeast(0).toLong())
    val remaining = java.time.Duration.between(java.time.LocalDateTime.now(), finish).toMinutes().coerceAtLeast(0L).toInt()
    val finishTime = finish.format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"))
    return "Taxminiy tugash: $finishTime • qolgan ${minutesLabel(remaining)}"
}

internal fun minutesLabel(minutes: Int): String = "${minutes / 60} soat ${minutes % 60} daqiqa"
internal fun orderStatusLabel(status: TpOrderStatus): String = when (status) {
    TpOrderStatus.NEW -> "Yangi"; TpOrderStatus.PLANNING -> "Rejalanmoqda"; TpOrderStatus.READY -> "Tayyor"
    TpOrderStatus.APPROVED -> "Tasdiqlangan"; TpOrderStatus.IN_PROGRESS -> "Quyilmoqda"
    TpOrderStatus.COMPLETE -> "Yakunlangan"; TpOrderStatus.CANCELLED -> "Bekor qilingan"
}
internal fun jobStatusLabel(status: TpJobStatus): String = when (status) {
    TpJobStatus.UNASSIGNED -> "Taqsimlanmagan"; TpJobStatus.QUEUED -> "Navbatda"; TpJobStatus.IN_PROGRESS -> "Ishda"
    TpJobStatus.COMPLETE -> "Yakunlangan"; TpJobStatus.HOLD -> "Kutilmoqda"
}
internal fun materialStatusLabel(status: TpMaterialStatus): String = when (status) {
    TpMaterialStatus.PLANNED -> "Tayyorlanmagan"; TpMaterialStatus.CONFIRMED -> "Tayyor"; TpMaterialStatus.DELIVERED -> "Stanokka chiqarilgan"
}
