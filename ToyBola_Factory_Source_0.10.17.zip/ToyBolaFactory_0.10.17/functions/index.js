"use strict";

const crypto = require("crypto");
const { setGlobalOptions } = require("firebase-functions/v2");
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { onDocumentWritten } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");

initializeApp();
setGlobalOptions({
  region: "europe-west1",
  maxInstances: 10,
  memory: "256MiB",
  timeoutSeconds: 60,
  serviceAccount: "toybola-functions-runtime@toybola-factory.iam.gserviceaccount.com"
});

const db = getFirestore();
const auth = getAuth();
const messaging = getMessaging();
const ROLES = new Set([
  "ADMIN", "RAHBAR", "BRIGADIR", "QUALITY",
  "TP_NACHALNIK", "TP_PLAN", "TP_BRIGADIR", "TP_SERYO", "TP_QABUL", "TP_QUALITY"
]);
const PERMISSION_KEYS = [
  "BRIGADIR_READ", "BRIGADIR_WRITE",
  "QUALITY_READ", "QUALITY_WRITE",
  "DAILY_ISSUE_READ", "DAILY_ISSUE_WRITE",
  "MONITORING_READ",
  "MASTER_DATA_READ", "MASTER_DATA_WRITE",
  "TP_ORDER_READ", "TP_ORDER_WRITE",
  "TP_PLANNING_READ", "TP_PLANNING_WRITE",
  "TP_MACHINE_READ", "TP_MACHINE_WRITE",
  "TP_ATTENDANCE_READ", "TP_ATTENDANCE_WRITE",
  "TP_SERYO_READ", "TP_SERYO_WRITE",
  "TP_RECEIVING_READ", "TP_RECEIVING_WRITE",
  "TP_QUALITY_READ", "TP_QUALITY_WRITE",
  "TP_MONITORING_READ",
  "TP_MASTER_DATA_READ", "TP_MASTER_DATA_WRITE"
];

function normalizeCode(value) {
  return String(value || "").trim().toUpperCase();
}
function sha256(value) {
  return crypto.createHash("sha256").update(String(value), "utf8").digest("hex");
}
function clientIp(request) {
  const raw = request && request.rawRequest;
  const forwarded = raw && raw.headers ? raw.headers["x-forwarded-for"] : "";
  const first = Array.isArray(forwarded) ? forwarded[0] : String(forwarded || "").split(",")[0];
  return String(first || (raw && raw.ip) || "unknown").trim();
}
async function loginThrottleRef(request, userCode) {
  const key = sha256(`${normalizeCode(userCode)}|${clientIp(request)}`);
  return db.collection("authThrottle").doc(key);
}
async function assertNotThrottled(ref) {
  const snap = await ref.get();
  if (!snap.exists) return;
  const blockedUntil = Number(snap.get("blockedUntilMs") || 0);
  if (blockedUntil > Date.now()) throw new HttpsError("resource-exhausted", "Juda ko‘p urinish. 15 daqiqadan keyin qayta urinib ko‘ring.");
}
async function recordLoginFailure(ref) {
  const now = Date.now();
  await db.runTransaction(async tx => {
    const snap = await tx.get(ref);
    const oldStart = snap.exists ? Number(snap.get("windowStartMs") || 0) : 0;
    const inWindow = oldStart > 0 && now - oldStart < 15 * 60 * 1000;
    const count = inWindow ? Number(snap.get("count") || 0) + 1 : 1;
    const windowStartMs = inWindow ? oldStart : now;
    const blockedUntilMs = count >= 5 ? now + 15 * 60 * 1000 : 0;
    tx.set(ref, { count, windowStartMs, blockedUntilMs, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
  });
}
function asBooleanMap(raw) {
  const source = raw && typeof raw === "object" ? raw : {};
  const out = {};
  for (const key of PERMISSION_KEYS) out[key] = source[key] === true;
  return out;
}
function permissionOverrides(raw) {
  const source = raw && typeof raw === "object" ? raw : {};
  const out = {};
  for (const key of PERMISSION_KEYS) {
    if (Object.prototype.hasOwnProperty.call(source, key)) out[key] = source[key] === true;
  }
  return out;
}
function policyFromUser(uid, data) {
  const role = String(data.role || "").toUpperCase();
  return {
    uid,
    userCode: data.userCode || "",
    displayName: data.displayName || "",
    role,
    enabled: data.enabled === true,
    allBrigades: data.allBrigades === true,
    allowedBrigadeIds: Array.isArray(data.allowedBrigadeIds) ? data.allowedBrigadeIds : [],
    permissions: role === "ADMIN" ? roleDefaults("ADMIN") : asBooleanMap(data.permissions),
    notifications: Array.isArray(data.notifications) ? data.notifications : [],
    revision: Number(data.revision || 0)
  };
}
function storageClaimsFromPolicy(policy) {
  const permissions = policy.permissions || {};
  return {
    role: policy.role,
    policyRevision: policy.revision,
    storageAssemblyRead: permissions.DAILY_ISSUE_READ === true || permissions.MONITORING_READ === true,
    storageAssemblyWrite: permissions.DAILY_ISSUE_WRITE === true,
    storageTpRead: permissions.TP_QUALITY_READ === true || permissions.TP_MONITORING_READ === true,
    storageTpWrite: permissions.TP_QUALITY_WRITE === true
  };
}

async function requireUser(request) {
  if (!request.auth || !request.auth.uid) throw new HttpsError("unauthenticated", "Kirish talab qilinadi");
  const snap = await db.collection("users").doc(request.auth.uid).get();
  if (!snap.exists || snap.get("enabled") !== true) throw new HttpsError("permission-denied", "Foydalanuvchi o‘chirilgan");
  return { uid: request.auth.uid, data: snap.data() };
}
async function requireAdmin(request) {
  const user = await requireUser(request);
  if (String(user.data.role || "").toUpperCase() !== "ADMIN") throw new HttpsError("permission-denied", "Administrator ruxsati kerak");
  return user;
}
function roleDefaults(role) {
  const allFalse = Object.fromEntries(PERMISSION_KEYS.map(k => [k, false]));
  if (role === "ADMIN") return Object.fromEntries(PERMISSION_KEYS.map(k => [k, true]));
  if (role === "RAHBAR") return { ...allFalse, BRIGADIR_READ: true, QUALITY_READ: true, DAILY_ISSUE_READ: true, MONITORING_READ: true, MASTER_DATA_READ: true, TP_ORDER_READ: true, TP_PLANNING_READ: true, TP_MACHINE_READ: true, TP_ATTENDANCE_READ: true, TP_SERYO_READ: true, TP_RECEIVING_READ: true, TP_QUALITY_READ: true, TP_MONITORING_READ: true, TP_MASTER_DATA_READ: true };
  if (role === "BRIGADIR") return { ...allFalse, BRIGADIR_READ: true, BRIGADIR_WRITE: true, DAILY_ISSUE_READ: true, DAILY_ISSUE_WRITE: true, MONITORING_READ: true };
  if (role === "QUALITY") return { ...allFalse, QUALITY_READ: true, QUALITY_WRITE: true, DAILY_ISSUE_READ: true, DAILY_ISSUE_WRITE: true, MONITORING_READ: true };
  if (role === "TP_NACHALNIK") return { ...allFalse, TP_ORDER_READ: true, TP_ORDER_WRITE: true, TP_PLANNING_READ: true, TP_MACHINE_READ: true, TP_ATTENDANCE_READ: true, TP_MONITORING_READ: true, TP_MASTER_DATA_READ: true };
  if (role === "TP_PLAN") return { ...allFalse, TP_ORDER_READ: true, TP_PLANNING_READ: true, TP_PLANNING_WRITE: true, TP_MACHINE_READ: true, TP_MACHINE_WRITE: true, TP_ATTENDANCE_READ: true, TP_ATTENDANCE_WRITE: true, TP_SERYO_READ: true, TP_MONITORING_READ: true, TP_MASTER_DATA_READ: true, TP_MASTER_DATA_WRITE: true };
  if (role === "TP_BRIGADIR") return { ...allFalse, TP_MACHINE_READ: true, TP_MACHINE_WRITE: true, TP_SERYO_READ: true, TP_RECEIVING_READ: true, TP_QUALITY_READ: true, TP_MONITORING_READ: true };
  if (role === "TP_SERYO") return { ...allFalse, TP_MACHINE_READ: true, TP_SERYO_READ: true, TP_SERYO_WRITE: true, TP_MONITORING_READ: true, TP_MASTER_DATA_READ: true };
  if (role === "TP_QABUL") return { ...allFalse, TP_MACHINE_READ: true, TP_RECEIVING_READ: true, TP_RECEIVING_WRITE: true, TP_MONITORING_READ: true };
  if (role === "TP_QUALITY") return { ...allFalse, TP_MACHINE_READ: true, TP_QUALITY_READ: true, TP_QUALITY_WRITE: true, TP_MONITORING_READ: true };
  return allFalse;
}

function rolePrefix(role) {
  if (role === "ADMIN") return "ADM";
  if (role === "RAHBAR") return "RHB";
  if (role === "QUALITY") return "SIF";
  if (role === "TP_NACHALNIK") return "TPN";
  if (role === "TP_PLAN") return "TPL";
  if (role === "TP_BRIGADIR") return "TPB";
  if (role === "TP_SERYO") return "SER";
  if (role === "TP_QABUL") return "QAB";
  if (role === "TP_QUALITY") return "TPS";
  return "BRG";
}
function randomDigits(length) {
  const max = 10 ** length;
  return String(crypto.randomInt(0, max)).padStart(length, "0");
}
async function generateUniqueUserCode(role) {
  const prefix = rolePrefix(role);
  for (let attempt = 0; attempt < 40; attempt += 1) {
    const userCode = `${prefix}-${randomDigits(6)}`;
    const snap = await db.collection("loginCodes").doc(sha256(userCode)).get();
    if (!snap.exists) return userCode;
  }
  throw new HttpsError("resource-exhausted", "Yangi foydalanuvchi kodi yaratilmadi. Qayta urinib ko‘ring.");
}
function generateDeviceCode(role) {
  return `DEV-${rolePrefix(role)}-${randomDigits(8)}`;
}
function defaultNotifications(role) {
  return role === "ADMIN" || role === "RAHBAR" ? ["DAY_STATUS", "ISSUE_SUMMARY"] : [];
}
function normalizedBrigadeIds(raw) {
  return Array.isArray(raw) ? [...new Set(raw.map(String).map(v => v.trim()).filter(Boolean))] : [];
}
function validateUserScope(role, allBrigades, allowedBrigadeIds) {
  if (role === "ADMIN" && !allBrigades) throw new HttpsError("invalid-argument", "Administrator barcha brigadalarga ruxsatli bo‘lishi kerak");
  if (!allBrigades && allowedBrigadeIds.length === 0) throw new HttpsError("invalid-argument", "Kamida bitta brigadani tanlang");
}


function recoveryArray(root, key) {
  const value = root && root[key];
  if (value == null) return [];
  if (!Array.isArray(value)) throw new HttpsError("invalid-argument", `Backup ${key} ro‘yxati noto‘g‘ri`);
  if (value.length > 10000) throw new HttpsError("invalid-argument", `Backup ${key} ro‘yxati juda katta`);
  return value;
}
function validateRecoveryId(value, label) {
  const text = String(value || "").trim();
  if (!text || text.length > 300 || text.includes("/")) {
    throw new HttpsError("invalid-argument", `${label} ID noto‘g‘ri`);
  }
  return text;
}
function recoveryDate(value, label) {
  const text = String(value || "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) throw new HttpsError("invalid-argument", `${label} sana noto‘g‘ri`);
  return text;
}
function recoveryText(value, max = 4000) {
  return String(value == null ? "" : value).slice(0, max);
}
function recoveryInt(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.trunc(n) : fallback;
}
function recoveryNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}
function singleRecoveryPayload(key, item) {
  return JSON.stringify({ [key]: [item] });
}
function settingsRecoveryPayload(root) {
  return JSON.stringify({
    workHours: recoveryArray(root, "workHours"),
    efficiencyNorm: recoveryArray(root, "efficiencyNorm"),
    roundTimes: recoveryArray(root, "roundTimes"),
    monitoringWeights: recoveryArray(root, "monitoringWeights"),
    preparedYears: recoveryArray(root, "preparedYears")
  });
}
function recoveryStamp(adminUid, recoveryId) {
  return {
    updatedAt: FieldValue.serverTimestamp(),
    updatedBy: adminUid,
    recoveredBy: adminUid,
    recoveryId
  };
}
async function commitRecoveryWrites(writes) {
  for (let offset = 0; offset < writes.length; offset += 400) {
    const batch = db.batch();
    for (const write of writes.slice(offset, offset + 400)) batch.set(write.ref, write.data);
    await batch.commit();
  }
}

exports.loginWithCodes = onCall({ enforceAppCheck: false }, async (request) => {
  const userCode = normalizeCode(request.data && request.data.userCode);
  const deviceCode = normalizeCode(request.data && request.data.deviceCode);
  const installId = String((request.data && request.data.installId) || "").trim();
  if (!userCode || !deviceCode || !installId) throw new HttpsError("invalid-argument", "Kodlar to‘liq emas");

  const throttleRef = await loginThrottleRef(request, userCode);
  await assertNotThrottled(throttleRef);
  const loginRef = db.collection("loginCodes").doc(sha256(userCode));
  const loginSnap = await loginRef.get();
  if (!loginSnap.exists || loginSnap.get("enabled") !== true) {
    await recordLoginFailure(throttleRef);
    throw new HttpsError("permission-denied", "Foydalanuvchi yoki qurilma kodi noto‘g‘ri");
  }
  const loginData = loginSnap.data();
  const deviceHash = sha256(deviceCode);
  const allowedDevices = Array.isArray(loginData.deviceHashes) ? loginData.deviceHashes : [];
  if (!allowedDevices.includes(deviceHash)) {
    await recordLoginFailure(throttleRef);
    throw new HttpsError("permission-denied", "Foydalanuvchi yoki qurilma kodi noto‘g‘ri");
  }

  const uid = loginData.uid;
  const userRef = db.collection("users").doc(uid);
  const userSnap = await userRef.get();
  if (!userSnap.exists || userSnap.get("enabled") !== true) {
    await recordLoginFailure(throttleRef);
    throw new HttpsError("permission-denied", "Foydalanuvchi o‘chirilgan");
  }

  await userRef.set({ lastLoginAt: FieldValue.serverTimestamp() }, { merge: true });
  await userRef.collection("devices").doc(installId).set({
    installId,
    deviceHash,
    lastSeenAt: FieldValue.serverTimestamp(),
    enabled: true
  }, { merge: true });

  const policy = policyFromUser(uid, userSnap.data());
  const claims = storageClaimsFromPolicy(policy);
  await auth.setCustomUserClaims(uid, claims);
  const token = await auth.createCustomToken(uid, claims);
  await throttleRef.delete().catch(() => undefined);
  return { token, policy: policyFromUser(uid, userSnap.data()) };
});

exports.getMyPolicy = onCall(async (request) => {
  const user = await requireUser(request);
  const policy = policyFromUser(user.uid, user.data);
  await auth.setCustomUserClaims(user.uid, storageClaimsFromPolicy(policy));
  return policy;
});

exports.registerFcmToken = onCall(async (request) => {
  const user = await requireUser(request);
  const installId = String((request.data && request.data.installId) || "").trim();
  const token = String((request.data && request.data.token) || "").trim();
  if (!installId || !token) throw new HttpsError("invalid-argument", "Qurilma tokeni to‘liq emas");
  await db.collection("users").doc(user.uid).collection("devices").doc(installId).set({
    installId,
    fcmToken: token,
    enabled: true,
    lastSeenAt: FieldValue.serverTimestamp()
  }, { merge: true });
  return { ok: true };
});

exports.adminCreateUser = onCall(async (request) => {
  const admin = await requireAdmin(request);
  const data = request.data || {};
  const displayName = String(data.displayName || "").trim();
  const role = normalizeCode(data.role);
  const allBrigades = data.allBrigades === true || role === "ADMIN";
  const allowedBrigadeIds = allBrigades ? [] : normalizedBrigadeIds(data.allowedBrigadeIds);
  if (!displayName || !ROLES.has(role)) throw new HttpsError("invalid-argument", "Ism yoki rol noto‘g‘ri");
  validateUserScope(role, allBrigades, allowedBrigadeIds);

  const userCode = await generateUniqueUserCode(role);
  const deviceCode = generateDeviceCode(role);
  const loginId = sha256(userCode);
  const uid = `tb_${loginId.slice(0, 28)}`;
  const permissions = role === "ADMIN" ? roleDefaults(role) : { ...roleDefaults(role), ...permissionOverrides(data.permissions) };
  const notifications = defaultNotifications(role);
  const userDoc = {
    uid,
    userCode,
    displayName,
    role,
    enabled: data.enabled !== false,
    allBrigades,
    allowedBrigadeIds,
    permissions,
    notifications,
    revision: 1,
    createdBy: admin.uid,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp()
  };

  try {
    await auth.createUser({ uid, displayName, disabled: data.enabled === false });
  } catch (error) {
    if (!(error && error.code === "auth/uid-already-exists")) throw error;
  }
  const batch = db.batch();
  batch.create(db.collection("users").doc(uid), userDoc);
  batch.create(db.collection("loginCodes").doc(loginId), {
    uid,
    enabled: data.enabled !== false,
    deviceHashes: [sha256(deviceCode)],
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp()
  });
  try {
    await batch.commit();
  } catch (error) {
    await auth.deleteUser(uid).catch(() => undefined);
    throw error;
  }
  return {
    user: policyFromUser(uid, userDoc),
    credentials: { userCode, deviceCode }
  };
});

exports.adminUpdateUser = onCall(async (request) => {
  const admin = await requireAdmin(request);
  const data = request.data || {};
  const uid = String(data.uid || "").trim();
  if (!uid) throw new HttpsError("invalid-argument", "Foydalanuvchi ID kerak");
  const ref = db.collection("users").doc(uid);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError("not-found", "Foydalanuvchi topilmadi");
  const previous = snap.data();

  const displayName = String(data.displayName || previous.displayName || "").trim();
  const role = normalizeCode(data.role || previous.role);
  const enabled = data.enabled !== false;
  const allBrigades = data.allBrigades === true || role === "ADMIN";
  const allowedBrigadeIds = allBrigades ? [] : normalizedBrigadeIds(data.allowedBrigadeIds);
  if (!displayName || !ROLES.has(role)) throw new HttpsError("invalid-argument", "Ism yoki rol noto‘g‘ri");
  validateUserScope(role, allBrigades, allowedBrigadeIds);
  if (uid === admin.uid && (!enabled || role !== "ADMIN")) {
    throw new HttpsError("failed-precondition", "O‘zingizning faol Admin hisobingizni o‘chirib yoki rolini almashtirib bo‘lmaydi");
  }

  const revision = Number(previous.revision || 0) + 1;
  const permissions = role === "ADMIN" ? roleDefaults(role) : { ...roleDefaults(role), ...permissionOverrides(data.permissions) };
  const notifications = Array.isArray(previous.notifications) ? previous.notifications : defaultNotifications(role);
  const patch = {
    displayName,
    role,
    enabled,
    allBrigades,
    allowedBrigadeIds,
    permissions,
    notifications,
    revision,
    updatedBy: admin.uid,
    updatedAt: FieldValue.serverTimestamp()
  };
  await ref.set(patch, { merge: true });

  const userCode = normalizeCode(previous.userCode);
  if (userCode) {
    await db.collection("loginCodes").doc(sha256(userCode)).set({
      uid,
      enabled,
      updatedAt: FieldValue.serverTimestamp()
    }, { merge: true });
  }
  await auth.updateUser(uid, { displayName, disabled: !enabled });
  if (!enabled) await auth.revokeRefreshTokens(uid);
  await sendToUid(uid, "Ruxsatlar yangilandi", "Toy Bola ruxsatlaringiz yangilandi.", "MONITORING", "POLICY_CHANGED", `policy-${revision}`);
  return policyFromUser(uid, { ...previous, ...patch });
});

exports.adminDeleteBrigadier = onCall(async (request) => {
  const admin = await requireAdmin(request);
  const uid = String(request.data && request.data.uid || "").trim();
  if (!uid) throw new HttpsError("invalid-argument", "Foydalanuvchi ID kerak");
  if (uid === admin.uid) throw new HttpsError("failed-precondition", "O‘zingizni o‘chira olmaysiz");
  const ref = db.collection("users").doc(uid);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError("not-found", "Foydalanuvchi topilmadi");
  const data = snap.data();
  const role = normalizeCode(data.role);
  if (!["BRIGADIR", "TP_BRIGADIR", "TP_SERYO"].includes(role)) {
    throw new HttpsError("failed-precondition", "Bu foydalanuvchi brigadir roli emas");
  }
  const userCode = normalizeCode(data.userCode);
  if (userCode) await db.collection("loginCodes").doc(sha256(userCode)).delete().catch(() => undefined);
  const devices = await ref.collection("devices").get();
  const batch = db.batch();
  devices.docs.forEach(doc => batch.delete(doc.ref));
  batch.set(ref, { enabled: false, deleted: true, deletedBy: admin.uid, deletedAt: FieldValue.serverTimestamp(), revision: Number(data.revision || 0) + 1 }, { merge: true });
  await batch.commit();
  await auth.deleteUser(uid).catch(error => { if (!(error && error.code === "auth/user-not-found")) throw error; });
  return { ok: true };
});

const TP_RESET_COLLECTIONS = [
  "tpProducts", "tpMaterials", "tpOrders", "tpJobs", "tpAttendance", "tpReceipts",
  "tpQualityRounds", "tpDailyIssues", "tpAuditLog", "tpWorkers", "tpMachines"
];

async function deleteCollectionDocuments(collectionName) {
  let total = 0;
  while (true) {
    const snap = await db.collection(collectionName).limit(400).get();
    if (snap.empty) break;
    const batch = db.batch();
    snap.docs.forEach(doc => batch.delete(doc.ref));
    await batch.commit();
    total += snap.size;
  }
  return total;
}

exports.adminResetTpData = onCall(async (request) => {
  const admin = await requireAdmin(request);
  const orderSnap = await db.collection("tpOrders").get();
  if (!orderSnap.empty) {
    for (let i = 0; i < orderSnap.docs.length; i += 400) {
      const batch = db.batch();
      orderSnap.docs.slice(i, i + 400).forEach(doc => batch.set(doc.ref, { suppressDeleteNotification: true }, { merge: true }));
      await batch.commit();
    }
  }
  let deleted = 0;
  for (const collectionName of TP_RESET_COLLECTIONS) deleted += await deleteCollectionDocuments(collectionName);
  const requestedTarget = Number(request.data && request.data.dailyTargetAmount || 100000);
  const dailyTargetAmount = Number.isFinite(requestedTarget) && requestedTarget > 0 ? Math.round(requestedTarget) : 100000;
  await db.collection("settings").doc("tp").set({
    payload: JSON.stringify({ settings: { dailyTargetAmount } }),
    updatedBy: admin.uid,
    updatedAt: FieldValue.serverTimestamp()
  }, { merge: true });
  await db.collection("adminAudit").add({ action: "TP_RESET_FOR_FRESH_IMPORT", deleted, adminUid: admin.uid, createdAt: FieldValue.serverTimestamp() });
  return { ok: true, deleted };
});

exports.adminResetDeviceCode = onCall(async (request) => {
  const admin = await requireAdmin(request);
  const uid = String(request.data && request.data.uid || "").trim();
  if (!uid) throw new HttpsError("invalid-argument", "Foydalanuvchi ID kerak");
  const ref = db.collection("users").doc(uid);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError("not-found", "Foydalanuvchi topilmadi");
  const data = snap.data();
  const userCode = normalizeCode(data.userCode);
  const role = normalizeCode(data.role);
  if (!userCode) throw new HttpsError("failed-precondition", "Foydalanuvchi kodi topilmadi");
  const deviceCode = generateDeviceCode(role);
  const revision = Number(data.revision || 0) + 1;
  await db.collection("loginCodes").doc(sha256(userCode)).set({
    uid,
    enabled: data.enabled === true,
    deviceHashes: [sha256(deviceCode)],
    updatedAt: FieldValue.serverTimestamp()
  }, { merge: true });
  await ref.set({ revision, updatedBy: admin.uid, deviceResetAt: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp() }, { merge: true });
  await auth.revokeRefreshTokens(uid);
  await sendToUid(uid, "Qurilma kodi yangilandi", "Toy Bola qurilma kodi yangilandi. Keyingi kirishda yangi koddan foydalaning.", "MONITORING", "POLICY_CHANGED", `device-reset-${revision}`);
  return { userCode, deviceCode };
});

exports.adminUpsertUser = onCall(async (request) => {
  await requireAdmin(request);
  const data = request.data || {};
  const userCode = normalizeCode(data.userCode);
  const displayName = String(data.displayName || "").trim();
  const role = normalizeCode(data.role);
  const deviceCodes = Array.isArray(data.deviceCodes) ? data.deviceCodes.map(normalizeCode).filter(Boolean) : [];
  const allBrigades = data.allBrigades === true || role === "ADMIN";
  const allowedBrigadeIds = allBrigades ? [] : normalizedBrigadeIds(data.allowedBrigadeIds);
  const notifications = Array.isArray(data.notifications) ? [...new Set(data.notifications.map(String).filter(Boolean))] : [];
  if (!userCode || !displayName || !ROLES.has(role)) throw new HttpsError("invalid-argument", "Foydalanuvchi ma’lumoti noto‘g‘ri");
  if (deviceCodes.length === 0) throw new HttpsError("invalid-argument", "Kamida bitta qurilma kodi kerak");
  validateUserScope(role, allBrigades, allowedBrigadeIds);

  const loginId = sha256(userCode);
  const existingLogin = await db.collection("loginCodes").doc(loginId).get();
  const uid = existingLogin.exists ? existingLogin.get("uid") : `tb_${loginId.slice(0, 28)}`;
  try { await auth.getUser(uid); } catch (e) {
    if (e && e.code === "auth/user-not-found") await auth.createUser({ uid, displayName }); else throw e;
  }

  const previous = await db.collection("users").doc(uid).get();
  const revision = Number(previous.exists ? previous.get("revision") || 0 : 0) + 1;
  const permissions = role === "ADMIN" ? roleDefaults(role) : { ...roleDefaults(role), ...permissionOverrides(data.permissions) };
  const userDoc = {
    uid, userCode, displayName, role, enabled: data.enabled !== false,
    allBrigades, allowedBrigadeIds, permissions, notifications,
    revision, updatedAt: FieldValue.serverTimestamp()
  };
  await db.collection("users").doc(uid).set(userDoc, { merge: true });
  await db.collection("loginCodes").doc(loginId).set({
    uid, enabled: data.enabled !== false,
    deviceHashes: deviceCodes.map(sha256),
    updatedAt: FieldValue.serverTimestamp()
  }, { merge: true });
  await sendToUid(uid, "Ruxsatlar yangilandi", "Toy Bola ruxsatlaringiz yangilandi.", "MONITORING", "POLICY_CHANGED", `policy-${revision}`);
  return policyFromUser(uid, userDoc);
});

exports.adminDisableUser = onCall(async (request) => {
  await requireAdmin(request);
  const userCode = normalizeCode(request.data && request.data.userCode);
  if (!userCode) throw new HttpsError("invalid-argument", "Foydalanuvchi kodi kerak");
  const loginRef = db.collection("loginCodes").doc(sha256(userCode));
  const login = await loginRef.get();
  if (!login.exists) throw new HttpsError("not-found", "Foydalanuvchi topilmadi");
  const uid = login.get("uid");
  await loginRef.set({ enabled: false, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
  await db.collection("users").doc(uid).set({ enabled: false, revision: FieldValue.increment(1), updatedAt: FieldValue.serverTimestamp() }, { merge: true });
  await auth.revokeRefreshTokens(uid);
  return { ok: true };
});

exports.adminListUsers = onCall(async (request) => {
  await requireAdmin(request);
  const snap = await db.collection("users").orderBy("displayName").limit(200).get();
  return { users: snap.docs.filter(d => d.get("deleted") !== true).map(d => policyFromUser(d.id, d.data())) };
});



function safeJsonObject(raw) {
  if (typeof raw !== "string" || !raw.trim()) return null;
  try {
    const value = JSON.parse(raw);
    return value && typeof value === "object" && !Array.isArray(value) ? value : null;
  } catch (_) {
    return null;
  }
}
function payloadItems(doc, key) {
  const root = safeJsonObject(doc.get("payload"));
  const items = root && Array.isArray(root[key]) ? root[key] : [];
  return items.filter(item => item && typeof item === "object");
}
function permissionEnabled(userData, key) {
  return String(userData && userData.role || "").toUpperCase() === "ADMIN" ||
    !!(userData && userData.permissions && userData.permissions[key] === true);
}
function anyReadPermission(userData) {
  return ["BRIGADIR_READ", "QUALITY_READ", "DAILY_ISSUE_READ", "MONITORING_READ", "MASTER_DATA_READ"]
    .some(key => permissionEnabled(userData, key));
}
async function scopedDocs(collectionName, brigadeIds) {
  const seen = new Map();
  for (const brigadeId of brigadeIds) {
    const snap = await db.collection(collectionName).where("brigadeId", "==", brigadeId).get();
    for (const doc of snap.docs) seen.set(doc.id, doc);
  }
  return [...seen.values()];
}
function fallbackBrigade(doc) {
  return {
    id: doc.id,
    name: recoveryText(doc.get("name"), 200),
    archived: doc.get("archived") === true,
    deleted: doc.get("deleted") === true
  };
}
function fallbackWorker(doc) {
  return {
    id: doc.id,
    brigadeId: recoveryText(doc.get("brigadeId"), 300),
    name: recoveryText(doc.get("name"), 200),
    startDate: recoveryText(doc.get("startDate"), 32),
    archived: doc.get("archived") === true
  };
}
function fallbackProduct(doc) {
  return {
    id: doc.id,
    brigadeId: recoveryText(doc.get("brigadeId"), 300),
    article: recoveryText(doc.get("article"), 120),
    name: recoveryText(doc.get("name"), 240),
    archived: doc.get("archived") === true,
    prices: [],
    stages: []
  };
}
function fallbackWorkerDay(doc) {
  return {
    workerId: recoveryText(doc.get("workerId"), 300),
    brigadeId: recoveryText(doc.get("brigadeId"), 300),
    date: recoveryText(doc.get("date"), 32),
    worked: doc.get("worked") !== false,
    hours: recoveryInt(doc.get("hours"), 10),
    updatedAt: "",
    entries: []
  };
}
function fallbackBrigadeDay(doc) {
  return {
    brigadeId: recoveryText(doc.get("brigadeId"), 300),
    date: recoveryText(doc.get("date"), 32),
    worked: doc.get("worked") !== false,
    brigadirClosedAt: recoveryText(doc.get("brigadirClosedAt"), 80) || null,
    brigadirLateReason: recoveryText(doc.get("brigadirLateReason")),
    qualityClosedAt: recoveryText(doc.get("qualityClosedAt"), 80) || null,
    qualityLateReason: recoveryText(doc.get("qualityLateReason")),
    closedAt: recoveryText(doc.get("closedAt"), 80) || null,
    reopenCount: Math.max(0, recoveryInt(doc.get("reopenCount"), 0)),
    lastReopenedAt: recoveryText(doc.get("lastReopenedAt"), 80) || null,
    lastReopenReason: recoveryText(doc.get("lastReopenReason"))
  };
}
function fallbackQualityRound(doc) {
  const gradeRaw = doc.get("grade");
  const scoreRaw = doc.get("score");
  return {
    workerId: recoveryText(doc.get("workerId"), 300),
    brigadeId: recoveryText(doc.get("brigadeId"), 300),
    date: recoveryText(doc.get("date"), 32),
    round: recoveryInt(doc.get("round"), 0),
    grade: gradeRaw == null ? null : recoveryInt(gradeRaw, 0),
    score: scoreRaw == null ? null : recoveryInt(scoreRaw, 0),
    missedReason: recoveryText(doc.get("missedReason")),
    missedAt: recoveryText(doc.get("missedAt"), 80) || null,
    absenceType: recoveryText(doc.get("absenceType"), 20),
    absenceReason: recoveryText(doc.get("absenceReason")),
    absenceAt: recoveryText(doc.get("absenceAt"), 80) || null
  };
}
function fallbackDailyIssue(doc) {
  return {
    id: doc.id,
    brigadeId: recoveryText(doc.get("brigadeId"), 300),
    date: recoveryText(doc.get("date"), 32),
    productId: recoveryText(doc.get("productId"), 300),
    articleSnapshot: recoveryText(doc.get("article"), 120),
    productNameSnapshot: recoveryText(doc.get("productName"), 240),
    stageId: recoveryText(doc.get("stageId"), 300),
    stageNameSnapshot: recoveryText(doc.get("stageName"), 240),
    note: recoveryText(doc.get("note")),
    createdAt: recoveryText(doc.get("createdAtText"), 80)
  };
}
function fallbackAudit(doc) {
  const brigade = recoveryText(doc.get("brigadeId"), 300);
  const recordDate = recoveryText(doc.get("recordDate"), 32);
  return {
    id: doc.id,
    dateTime: recoveryText(doc.get("dateTime"), 80),
    action: recoveryText(doc.get("action"), 160),
    brigadeId: brigade || null,
    recordDate: recordDate || null,
    details: recoveryText(doc.get("details"))
  };
}
function collectPayloadOrFallback(docs, key, fallback) {
  const out = [];
  for (const doc of docs) {
    const items = payloadItems(doc, key);
    if (items.length) out.push(...items);
    else {
      const value = fallback(doc);
      if (value) out.push(value);
    }
  }
  return out;
}

/**
 * Authoritative server -> client snapshot.
 *
 * The signed-in user's server profile defines permissions and brigade scope. Firebase Admin SDK
 * performs the actual reads so legacy Firestore rows cannot make a fresh-install client query fail
 * with PERMISSION_DENIED. The server still applies the same scope/permission policy before data is
 * returned.
 */
exports.getAssemblySnapshot = onCall({ enforceAppCheck: false, timeoutSeconds: 60, memory: "512MiB" }, async (request) => {
  const current = await requireUser(request);
  const userData = current.data || {};
  if (!anyReadPermission(userData)) throw new HttpsError("permission-denied", "Ma’lumotlarni ko‘rish ruxsati yo‘q");

  let brigadeDocs = [];
  if (userData.allBrigades === true) {
    brigadeDocs = (await db.collection("brigades").get()).docs;
  } else {
    const ids = normalizedBrigadeIds(userData.allowedBrigadeIds);
    for (const id of ids) {
      const snap = await db.collection("brigades").doc(id).get();
      if (snap.exists) brigadeDocs.push(snap);
    }
  }
  const brigadeIds = [...new Set(brigadeDocs.map(doc => doc.id).filter(Boolean))];
  const can = key => permissionEnabled(userData, key);
  const root = {
    brigades: collectPayloadOrFallback(brigadeDocs, "brigades", fallbackBrigade),
    workers: [], products: [], brigadeFk: [],
    workHours: [], efficiencyNorm: [], roundTimes: [], monitoringWeights: [], preparedYears: [],
    workerDays: [], brigadeDays: [], qualityRounds: [], dailyIssues: [], auditLog: []
  };

  if (can("BRIGADIR_READ") || can("QUALITY_READ") || can("MONITORING_READ") || can("MASTER_DATA_READ")) {
    root.workers = collectPayloadOrFallback(await scopedDocs("workers", brigadeIds), "workers", fallbackWorker);
  }
  if (can("BRIGADIR_READ") || can("QUALITY_READ") || can("DAILY_ISSUE_READ") || can("MONITORING_READ") || can("MASTER_DATA_READ")) {
    root.products = collectPayloadOrFallback(await scopedDocs("products", brigadeIds), "products", fallbackProduct);
  }
  if (can("BRIGADIR_READ") || can("MONITORING_READ") || can("MASTER_DATA_READ")) {
    root.brigadeFk = collectPayloadOrFallback(await scopedDocs("brigadeFk", brigadeIds), "brigadeFk", doc => ({ brigadeId: recoveryText(doc.get("brigadeId"), 300), versions: [] }));
  }
  if (can("BRIGADIR_READ") || can("QUALITY_READ") || can("MONITORING_READ")) {
    root.workerDays = collectPayloadOrFallback(await scopedDocs("workerDays", brigadeIds), "workerDays", fallbackWorkerDay);
    root.brigadeDays = (await scopedDocs("brigadeDays", brigadeIds)).map(fallbackBrigadeDay);
  }
  if (can("QUALITY_READ") || can("MONITORING_READ")) {
    root.qualityRounds = collectPayloadOrFallback(await scopedDocs("qualityRounds", brigadeIds), "qualityRounds", fallbackQualityRound);
  }
  if (can("DAILY_ISSUE_READ") || can("MONITORING_READ")) {
    root.dailyIssues = collectPayloadOrFallback(await scopedDocs("dailyIssues", brigadeIds), "dailyIssues", fallbackDailyIssue);
  }

  const settingsSnap = await db.collection("settings").doc("assembly").get();
  let hasSettings = false;
  if (settingsSnap.exists) {
    const settings = safeJsonObject(settingsSnap.get("payload"));
    if (settings) {
      for (const key of ["workHours", "efficiencyNorm", "roundTimes", "monitoringWeights", "preparedYears"]) {
        if (Array.isArray(settings[key])) root[key] = settings[key];
      }
      hasSettings = true;
    }
  }

  if (can("MONITORING_READ") || can("MASTER_DATA_READ")) {
    const auditDocs = userData.allBrigades === true
      ? (await db.collection("auditLog").orderBy("dateTime", "desc").limit(2000).get()).docs
      : await scopedDocs("auditLog", brigadeIds);
    root.auditLog = collectPayloadOrFallback(auditDocs.slice(0, 2000), "auditLog", fallbackAudit).slice(-2000);
  }

  const payload = JSON.stringify(root);
  if (Buffer.byteLength(payload, "utf8") > 8 * 1024 * 1024) {
    throw new HttpsError("resource-exhausted", "Server snapshot juda katta. Ma’lumotni bo‘lib yuklash kerak.");
  }
  const counts = {
    brigades: root.brigades.length, workers: root.workers.length, products: root.products.length,
    brigadeFk: root.brigadeFk.length, workerDays: root.workerDays.length, brigadeDays: root.brigadeDays.length,
    qualityRounds: root.qualityRounds.length, dailyIssues: root.dailyIssues.length, auditLog: root.auditLog.length
  };
  return { ok: true, payload, hasSettings, counts };
});

const TP_READ_KEYS = [
  "TP_ORDER_READ", "TP_PLANNING_READ", "TP_MACHINE_READ", "TP_ATTENDANCE_READ",
  "TP_SERYO_READ", "TP_RECEIVING_READ", "TP_QUALITY_READ", "TP_MONITORING_READ", "TP_MASTER_DATA_READ"
];
function anyTpReadPermission(userData) {
  return TP_READ_KEYS.some(key => permissionEnabled(userData, key));
}
async function allDocs(collectionName) {
  return (await db.collection(collectionName).get()).docs;
}
function collectTpPayload(docs, key) {
  const seen = new Map();
  for (const doc of docs) {
    for (const item of payloadItems(doc, key)) {
      const id = String(item.id || `${doc.id}_${seen.size}`);
      seen.set(id, item);
    }
  }
  return [...seen.values()];
}

/** Trusted, permission-scoped TP/Seryo bootstrap for fresh installs and cross-device sync. */
exports.getTpSnapshot = onCall({ enforceAppCheck: false, timeoutSeconds: 60, memory: "512MiB" }, async (request) => {
  const current = await requireUser(request);
  const userData = current.data || {};
  if (!anyTpReadPermission(userData)) throw new HttpsError("permission-denied", "TP ma’lumotlarini ko‘rish ruxsati yo‘q");
  const can = key => permissionEnabled(userData, key);
  const allBrigades = userData.allBrigades === true;
  const brigadeIds = allBrigades ? [] : normalizedBrigadeIds(userData.allowedBrigadeIds);
  const scoped = async collection => allBrigades ? allDocs(collection) : scopedDocs(collection, brigadeIds);

  const root = {
    shops: [], shifts: [], brigades: [], machines: [], workers: [], products: [], materials: [],
    orders: [], jobs: [], attendance: [], receipts: [], qualityRounds: [], dailyIssues: [], machineDowntimes: [], auditLog: [],
    settings: { firstBatchEntered: false, priceRevision: 0, dailyTargetAmount: 100000 }
  };

  root.shops = collectTpPayload(await allDocs("tpShops"), "shops");
  root.shifts = collectTpPayload(await allDocs("tpShifts"), "shifts");
  root.machines = collectTpPayload(await allDocs("tpMachines"), "machines");
  root.products = collectTpPayload(await allDocs("tpProducts"), "products");
  root.materials = collectTpPayload(await allDocs("tpMaterials"), "materials");

  const brigadeDocs = allBrigades
    ? await allDocs("tpBrigades")
    : (await Promise.all(brigadeIds.map(id => db.collection("tpBrigades").doc(id).get()))).filter(doc => doc.exists);
  root.brigades = collectTpPayload(brigadeDocs, "brigades");
  root.workers = collectTpPayload(await scoped("tpWorkers"), "workers");

  let jobDocs;
  if (allBrigades) {
    jobDocs = await allDocs("tpJobs");
  } else {
    jobDocs = await scopedDocs("tpJobs", brigadeIds);
    if (can("TP_PLANNING_READ") || can("TP_ORDER_READ")) {
      const unassigned = (await db.collection("tpJobs").where("brigadeId", "==", "").get()).docs;
      const byId = new Map(jobDocs.map(doc => [doc.id, doc]));
      for (const doc of unassigned) byId.set(doc.id, doc);
      jobDocs = [...byId.values()];
    }
  }
  root.jobs = collectTpPayload(jobDocs, "jobs");

  if (can("TP_ORDER_READ") || can("TP_PLANNING_READ") || can("TP_MONITORING_READ") || allBrigades) {
    root.orders = collectTpPayload(await allDocs("tpOrders"), "orders");
  } else {
    const orderIds = [...new Set(root.jobs.map(job => String(job.orderId || "")).filter(Boolean))];
    const orderDocs = (await Promise.all(orderIds.map(id => db.collection("tpOrders").doc(id).get()))).filter(doc => doc.exists);
    root.orders = collectTpPayload(orderDocs, "orders");
  }
  if (can("TP_ATTENDANCE_READ") || can("TP_MONITORING_READ")) root.attendance = collectTpPayload(await scoped("tpAttendance"), "attendance");
  if (can("TP_RECEIVING_READ") || can("TP_MONITORING_READ")) root.receipts = collectTpPayload(await scoped("tpReceipts"), "receipts");
  if (can("TP_QUALITY_READ") || can("TP_MONITORING_READ")) {
    root.qualityRounds = collectTpPayload(await scoped("tpQualityRounds"), "qualityRounds");
    root.dailyIssues = collectTpPayload(await scoped("tpDailyIssues"), "dailyIssues");
  }
  if (can("TP_MACHINE_READ") || can("TP_MONITORING_READ")) {
    root.machineDowntimes = collectTpPayload(await scoped("tpMachineDowntimes"), "machineDowntimes");
  }
  if (can("TP_MONITORING_READ") || can("TP_MASTER_DATA_READ")) root.auditLog = collectTpPayload((await scoped("tpAuditLog")).slice(-3000), "auditLog");

  const settingsSnap = await db.collection("settings").doc("tp").get();
  let hasSettings = false;
  if (settingsSnap.exists) {
    const settingsRoot = safeJsonObject(settingsSnap.get("payload"));
    if (settingsRoot && settingsRoot.settings && typeof settingsRoot.settings === "object") {
      root.settings = settingsRoot.settings;
      hasSettings = true;
    }
  }

  const counts = Object.fromEntries(Object.entries(root).filter(([, value]) => Array.isArray(value)).map(([key, value]) => [key, value.length]));
  const hasData = hasSettings || Object.values(counts).some(value => value > 0);
  const payload = JSON.stringify(root);
  if (Buffer.byteLength(payload, "utf8") > 8 * 1024 * 1024) {
    throw new HttpsError("resource-exhausted", "TP server snapshot juda katta. Ma’lumotni bo‘lib yuklash kerak.");
  }
  return { ok: true, payload, hasData, hasSettings, counts };
});

/**
 * Admin-only one-time legacy-local recovery.
 *
 * Android sends the already checksum-verified, merged AssemblyData JSON. This endpoint verifies
 * Admin identity again, validates IDs/dates, normalizes every Firestore document and writes with
 * Firebase Admin SDK. Client Security Rules are intentionally not used for this migration path;
 * normal day-to-day writes continue through the regular scoped client rules.
 */
exports.adminRestoreAssemblyBackup = onCall(async (request) => {
  const admin = await requireAdmin(request);
  const raw = request.data || {};
  const payload = String(raw.payload || "");
  const expectedHash = String(raw.payloadSha256 || "").trim().toLowerCase();
  if (!payload) throw new HttpsError("invalid-argument", "Backup payload bo‘sh");
  if (Buffer.byteLength(payload, "utf8") > 7 * 1024 * 1024) {
    throw new HttpsError("invalid-argument", "Backup hajmi juda katta");
  }
  if (!expectedHash || sha256(payload) !== expectedHash) {
    throw new HttpsError("invalid-argument", "Backup checksum mos emas");
  }

  let root;
  try { root = JSON.parse(payload); } catch (_) {
    throw new HttpsError("invalid-argument", "Backup JSON buzilgan");
  }
  const recoveryId = `rec_${Date.now()}_${crypto.randomBytes(5).toString("hex")}`;
  const stamp = () => recoveryStamp(admin.uid, recoveryId);
  const writes = [];
  const counts = {
    brigades: 0, workers: 0, products: 0, brigadeFk: 0, settings: 0,
    workerDays: 0, brigadeDays: 0, qualityRounds: 0, dailyIssues: 0, auditLog: 0
  };

  for (const item of recoveryArray(root, "brigades")) {
    const id = validateRecoveryId(item.id, "Brigada");
    writes.push({
      ref: db.collection("brigades").doc(id),
      data: {
        brigadeId: id,
        name: recoveryText(item.name, 200),
        archived: item.archived === true,
        deleted: item.deleted === true,
        payload: singleRecoveryPayload("brigades", item),
        ...stamp()
      }
    });
    counts.brigades += 1;
  }

  for (const item of recoveryArray(root, "workers")) {
    const id = validateRecoveryId(item.id, "Ishchi");
    const brigadeId = validateRecoveryId(item.brigadeId, "Ishchi brigada");
    writes.push({ ref: db.collection("workers").doc(id), data: {
      brigadeId, name: recoveryText(item.name, 200), startDate: recoveryText(item.startDate, 32),
      archived: item.archived === true, payload: singleRecoveryPayload("workers", item), ...stamp()
    }});
    counts.workers += 1;
  }

  for (const item of recoveryArray(root, "products")) {
    const id = validateRecoveryId(item.id, "Mahsulot");
    const brigadeId = validateRecoveryId(item.brigadeId, "Mahsulot brigada");
    writes.push({ ref: db.collection("products").doc(id), data: {
      brigadeId, article: recoveryText(item.article, 120), name: recoveryText(item.name, 240),
      archived: item.archived === true, payload: singleRecoveryPayload("products", item), ...stamp()
    }});
    counts.products += 1;
  }

  for (const item of recoveryArray(root, "brigadeFk")) {
    const brigadeId = validateRecoveryId(item.brigadeId, "FK brigada");
    writes.push({ ref: db.collection("brigadeFk").doc(brigadeId), data: {
      brigadeId, payload: singleRecoveryPayload("brigadeFk", item), ...stamp()
    }});
    counts.brigadeFk += 1;
  }

  const hasSettings = ["workHours", "efficiencyNorm", "roundTimes", "monitoringWeights", "preparedYears"]
    .some(key => recoveryArray(root, key).length > 0);
  if (hasSettings) {
    writes.push({ ref: db.collection("settings").doc("assembly"), data: {
      payload: settingsRecoveryPayload(root), ...stamp()
    }});
    counts.settings = 1;
  }

  for (const item of recoveryArray(root, "workerDays")) {
    const workerId = validateRecoveryId(item.workerId, "Ishchi kun");
    const brigadeId = validateRecoveryId(item.brigadeId, "Ishchi kun brigada");
    const date = recoveryDate(item.date, "Ishchi kun");
    const entries = Array.isArray(item.entries) ? item.entries : [];
    const earned = entries.reduce((sum, entry) => {
      const quantity = recoveryNumber(entry && entry.quantity, 0);
      const price = Number(entry && entry.unitPriceSnapshot || 0);
      return sum + (Number.isFinite(price) ? Math.round(quantity * price) : 0);
    }, 0);
    writes.push({ ref: db.collection("workerDays").doc(`${workerId}_${date}`), data: {
      brigadeId, date, workerId, worked: item.worked !== false, hours: recoveryInt(item.hours, 10),
      earned: Number.isFinite(earned) ? earned : 0,
      payload: singleRecoveryPayload("workerDays", item), ...stamp()
    }});
    counts.workerDays += 1;
  }

  for (const item of recoveryArray(root, "brigadeDays")) {
    const brigadeId = validateRecoveryId(item.brigadeId, "Brigada kuni");
    const date = recoveryDate(item.date, "Brigada kuni");
    const brigadirClosedAt = recoveryText(item.brigadirClosedAt, 80);
    const qualityClosedAt = recoveryText(item.qualityClosedAt, 80);
    const brigadirClosed = !!brigadirClosedAt;
    const qualityClosed = !!qualityClosedAt;
    const fullyClosed = brigadirClosed && qualityClosed;
    const closedAt = fullyClosed
      ? (recoveryText(item.closedAt, 80) || qualityClosedAt || brigadirClosedAt)
      : "";
    writes.push({ ref: db.collection("brigadeDays").doc(`${brigadeId}_${date}`), data: {
      brigadeId, date, worked: item.worked !== false,
      brigadirClosed, brigadirClosedAt, brigadirLateReason: recoveryText(item.brigadirLateReason),
      qualityClosed, qualityClosedAt, qualityLateReason: recoveryText(item.qualityLateReason),
      fullyClosed, closedAt, reopenCount: Math.max(0, recoveryInt(item.reopenCount, 0)),
      lastReopenedAt: recoveryText(item.lastReopenedAt, 80),
      lastReopenReason: recoveryText(item.lastReopenReason),
      ...stamp()
    }});
    counts.brigadeDays += 1;
  }

  for (const item of recoveryArray(root, "qualityRounds")) {
    const workerId = validateRecoveryId(item.workerId, "Sifat raundi ishchi");
    const brigadeId = validateRecoveryId(item.brigadeId, "Sifat raundi brigada");
    const date = recoveryDate(item.date, "Sifat raundi");
    const round = recoveryInt(item.round, 0);
    if (round < 1 || round > 3) throw new HttpsError("invalid-argument", "Sifat raundi 1–3 bo‘lishi kerak");
    const absenceType = ["EXCUSED", "UNEXCUSED"].includes(String(item.absenceType || ""))
      ? String(item.absenceType) : "";
    const absenceReason = recoveryText(item.absenceReason);
    if (absenceType === "EXCUSED" && !absenceReason.trim()) {
      throw new HttpsError("invalid-argument", "Sababli sifat raundida izoh yo‘q");
    }
    const grade = item.grade == null ? null : recoveryInt(item.grade, 0);
    const score = item.score == null ? null : recoveryInt(item.score, 0);
    const absenceAt = recoveryText(item.absenceAt, 80);
    const missedAt = recoveryText(item.missedAt, 80);
    const finished = grade != null || (!!absenceType && !!absenceAt) || (!!missedAt && recoveryText(item.missedReason).trim() !== "");
    writes.push({ ref: db.collection("qualityRounds").doc(`${workerId}_${date}_${round}`), data: {
      brigadeId, date, workerId, round, finished,
      absenceType, absenceReason, absenceAt,
      missedReason: recoveryText(item.missedReason), missedAt,
      grade, score,
      payload: singleRecoveryPayload("qualityRounds", item), ...stamp()
    }});
    counts.qualityRounds += 1;
  }

  for (const item of recoveryArray(root, "dailyIssues")) {
    const id = validateRecoveryId(item.id, "Kun muammosi");
    const brigadeId = validateRecoveryId(item.brigadeId, "Kun muammosi brigada");
    const date = recoveryDate(item.date, "Kun muammosi");
    writes.push({ ref: db.collection("dailyIssues").doc(id), data: {
      brigadeId, date,
      productId: recoveryText(item.productId, 300), article: recoveryText(item.articleSnapshot, 120),
      productName: recoveryText(item.productNameSnapshot, 240), stageId: recoveryText(item.stageId, 300),
      stageName: recoveryText(item.stageNameSnapshot, 240), note: recoveryText(item.note),
      createdAtText: recoveryText(item.createdAt, 80),
      payload: singleRecoveryPayload("dailyIssues", item), ...stamp()
    }});
    counts.dailyIssues += 1;
  }

  // Keep user-created audit history, but cap it to the same 2000-row client retention window.
  const auditItems = recoveryArray(root, "auditLog").slice(-2000);
  for (const item of auditItems) {
    const id = validateRecoveryId(item.id || `legacy_${crypto.randomUUID()}`, "Audit");
    const brigadeId = item.brigadeId == null ? "" : recoveryText(item.brigadeId, 300);
    writes.push({ ref: db.collection("auditLog").doc(id), data: {
      dateTime: recoveryText(item.dateTime, 80), action: recoveryText(item.action, 160),
      brigadeId, recordDate: recoveryText(item.recordDate, 32), details: recoveryText(item.details),
      payload: singleRecoveryPayload("auditLog", item), ...stamp()
    }});
    counts.auditLog += 1;
  }

  const totalBeforeAudit = Object.values(counts).reduce((sum, value) => sum + value, 0);
  if (totalBeforeAudit === 0) throw new HttpsError("failed-precondition", "Tiklash uchun ish ma’lumoti yo‘q");

  const recoveryAuditId = `recovery_${recoveryId}`;
  const recoveryAuditItem = {
    id: recoveryAuditId,
    dateTime: new Date().toISOString().replace(/Z$/, ""),
    action: "SERVER_RECOVERY",
    brigadeId: null,
    recordDate: null,
    details: `Admin server recovery ${recoveryId}; client=${recoveryText(raw.clientVersion, 40)}; records=${totalBeforeAudit}`
  };
  writes.push({ ref: db.collection("auditLog").doc(recoveryAuditId), data: {
    dateTime: recoveryAuditItem.dateTime, action: recoveryAuditItem.action,
    brigadeId: "", recordDate: "", details: recoveryAuditItem.details,
    payload: singleRecoveryPayload("auditLog", recoveryAuditItem), ...stamp()
  }});
  counts.auditLog += 1;

  await commitRecoveryWrites(writes);
  await db.collection("serverRecoveryLog").doc(recoveryId).set({
    recoveryId,
    adminUid: admin.uid,
    clientVersion: recoveryText(raw.clientVersion, 40),
    payloadSha256: expectedHash,
    counts,
    totalWritten: writes.length,
    createdAt: FieldValue.serverTimestamp()
  });

  return { ok: true, recoveryId, counts, totalWritten: writes.length };
});


function effectivePermission(userData, key) {
  const role = normalizeCode(userData && userData.role);
  return role === "ADMIN" || permissionEnabled(userData, key) || roleDefaults(role)[key] === true;
}
function assemblyScopeAllowed(userData, brigadeId) {
  if (!brigadeId) return true;
  if (userData.allBrigades === true || normalizeCode(userData.role) === "ADMIN") return true;
  return normalizedBrigadeIds(userData.allowedBrigadeIds).includes(String(brigadeId));
}
function assemblyItem(root, key, predicate) {
  const rows = root && Array.isArray(root[key]) ? root[key] : [];
  return rows.find(row => row && typeof row === "object" && predicate(row)) || null;
}
function assemblyMiniPayload(key, item) {
  return JSON.stringify({ [key]: [item] });
}
function assemblyStamp(uid, payload, brigadeId, date) {
  const out = { payload, updatedAt: FieldValue.serverTimestamp(), updatedBy: uid };
  if (brigadeId) out.brigadeId = brigadeId;
  if (date) out.date = date;
  return out;
}

/**
 * Reliable Assembly/Sborka outbox writer. Clients previously wrote Firestore batches directly;
 * a single legacy/rules mismatch could keep Brigadir/Quality rows in Pending forever. This
 * callable validates the signed-in user's write permission + brigade scope server-side and then
 * performs Admin SDK writes, so a valid local outbox can always drain when the network is healthy.
 */
exports.applyAssemblyWrites = onCall({ enforceAppCheck: false, timeoutSeconds: 60, memory: "512MiB" }, async (request) => {
  const current = await requireUser(request);
  const userData = current.data || {};
  const keys = Array.isArray(request.data && request.data.keys) ? request.data.keys.map(String).slice(0, 220) : [];
  const payloadText = String((request.data && request.data.payload) || "");
  const root = safeJsonObject(payloadText);
  if (!root) throw new HttpsError("invalid-argument", "Assembly sync payload noto‘g‘ri");
  if (keys.length === 0) return { ok: true, applied: [] };

  const applied = [];
  const batches = [];
  let batch = db.batch();
  let writeCount = 0;
  const commitIfNeeded = async force => {
    if (writeCount >= 350 || (force && writeCount > 0)) {
      batches.push(batch.commit());
      batch = db.batch();
      writeCount = 0;
    }
  };
  const requireWrite = (permission, brigadeId) => {
    if (!effectivePermission(userData, permission)) throw new HttpsError("permission-denied", `${permission} ruxsati kerak`);
    if (!assemblyScopeAllowed(userData, brigadeId)) throw new HttpsError("permission-denied", "Brigada ruxsati yo‘q");
  };

  for (const rawKey of keys) {
    const key = String(rawKey || "");
    const sep = key.indexOf(":");
    const prefix = sep >= 0 ? key.slice(0, sep) : key;
    const id = sep >= 0 ? key.slice(sep + 1) : "";
    let item = null;
    let brigadeId = "";
    let date = "";
    let ref = null;
    let doc = null;
    let deleteRef = null;

    if (prefix === "BRIGADE") {
      item = assemblyItem(root, "brigades", row => String(row.id) === id);
      if (!item) { applied.push(key); continue; }
      brigadeId = String(item.id || ""); requireWrite("MASTER_DATA_WRITE", brigadeId);
      ref = db.collection("brigades").doc(brigadeId);
      doc = { ...assemblyStamp(current.uid, assemblyMiniPayload("brigades", item), brigadeId), name: String(item.name || ""), archived: item.archived === true, deleted: item.deleted === true };
    } else if (prefix === "WORKER") {
      item = assemblyItem(root, "workers", row => String(row.id) === id);
      if (!item) { applied.push(key); continue; }
      brigadeId = String(item.brigadeId || ""); requireWrite("MASTER_DATA_WRITE", brigadeId);
      ref = db.collection("workers").doc(String(item.id));
      doc = { ...assemblyStamp(current.uid, assemblyMiniPayload("workers", item), brigadeId), name: String(item.name || ""), archived: item.archived === true, startDate: String(item.startDate || "") };
    } else if (prefix === "PRODUCT") {
      item = assemblyItem(root, "products", row => String(row.id) === id);
      if (!item) { applied.push(key); continue; }
      brigadeId = String(item.brigadeId || ""); requireWrite("MASTER_DATA_WRITE", brigadeId);
      ref = db.collection("products").doc(String(item.id));
      doc = { ...assemblyStamp(current.uid, assemblyMiniPayload("products", item), brigadeId), article: String(item.article || ""), name: String(item.name || ""), archived: item.archived === true };
    } else if (prefix === "BRIGADE_FK") {
      item = assemblyItem(root, "brigadeFk", row => String(row.brigadeId) === id);
      if (!item) { applied.push(key); continue; }
      brigadeId = String(item.brigadeId || ""); requireWrite("MASTER_DATA_WRITE", brigadeId);
      ref = db.collection("brigadeFk").doc(brigadeId);
      doc = assemblyStamp(current.uid, assemblyMiniPayload("brigadeFk", item), brigadeId);
    } else if (prefix === "WORKER_DAY") {
      const parts = id.split("|");
      item = assemblyItem(root, "workerDays", row => String(row.workerId) === parts[0] && String(row.date) === parts[1]);
      if (!item) { applied.push(key); continue; }
      brigadeId = String(item.brigadeId || ""); date = String(item.date || ""); requireWrite("BRIGADIR_WRITE", brigadeId);
      ref = db.collection("workerDays").doc(`${item.workerId}_${date}`);
      doc = { ...assemblyStamp(current.uid, assemblyMiniPayload("workerDays", item), brigadeId, date), workerId: String(item.workerId || ""), worked: item.worked !== false, hours: Number(item.hours || 0), earned: Number(item.earned || 0) };
    } else if (prefix === "BRIGADE_DAY") {
      const parts = id.split("|");
      item = assemblyItem(root, "brigadeDays", row => String(row.brigadeId) === parts[0] && String(row.date) === parts[1]);
      if (!item) { applied.push(key); continue; }
      brigadeId = String(item.brigadeId || ""); date = String(item.date || "");
      if (!effectivePermission(userData, "BRIGADIR_WRITE") && !effectivePermission(userData, "QUALITY_WRITE")) throw new HttpsError("permission-denied", "Kun yopish ruxsati yo‘q");
      if (!assemblyScopeAllowed(userData, brigadeId)) throw new HttpsError("permission-denied", "Brigada ruxsati yo‘q");
      ref = db.collection("brigadeDays").doc(`${brigadeId}_${date}`);
      const brigadirClosedAt = item.brigadirClosedAt == null ? "" : String(item.brigadirClosedAt);
      const qualityClosedAt = item.qualityClosedAt == null ? "" : String(item.qualityClosedAt);
      const closedAt = item.closedAt == null ? "" : String(item.closedAt);
      doc = {
        brigadeId, date, worked: item.worked !== false,
        brigadirClosed: !!brigadirClosedAt, brigadirClosedAt, brigadirLateReason: String(item.brigadirLateReason || ""),
        qualityClosed: !!qualityClosedAt, qualityClosedAt, qualityLateReason: String(item.qualityLateReason || ""),
        fullyClosed: !!closedAt, closedAt, reopenCount: Number(item.reopenCount || 0),
        lastReopenedAt: item.lastReopenedAt == null ? "" : String(item.lastReopenedAt), lastReopenReason: String(item.lastReopenReason || ""),
        updatedAt: FieldValue.serverTimestamp(), updatedBy: current.uid
      };
    } else if (prefix === "QUALITY_ROUND") {
      const parts = id.split("|");
      item = assemblyItem(root, "qualityRounds", row => String(row.workerId) === parts[0] && String(row.date) === parts[1] && Number(row.round) === Number(parts[2]));
      if (!item) { applied.push(key); continue; }
      brigadeId = String(item.brigadeId || ""); date = String(item.date || ""); requireWrite("QUALITY_WRITE", brigadeId);
      ref = db.collection("qualityRounds").doc(`${item.workerId}_${date}_${Number(item.round || 0)}`);
      doc = { ...assemblyStamp(current.uid, assemblyMiniPayload("qualityRounds", item), brigadeId, date), workerId: String(item.workerId || ""), round: Number(item.round || 0), finished: item.grade != null || !!item.absenceType, absenceType: String(item.absenceType || ""), absenceReason: String(item.absenceReason || ""), absenceAt: item.absenceAt == null ? "" : String(item.absenceAt) };
      if (item.grade != null) doc.grade = Number(item.grade); if (item.score != null) doc.score = Number(item.score);
    } else if (prefix === "DAILY_ISSUE") {
      item = assemblyItem(root, "dailyIssues", row => String(row.id) === id);
      if (!item) { applied.push(key); continue; }
      brigadeId = String(item.brigadeId || ""); date = String(item.date || ""); requireWrite("DAILY_ISSUE_WRITE", brigadeId);
      ref = db.collection("dailyIssues").doc(String(item.id));
      doc = { ...assemblyStamp(current.uid, assemblyMiniPayload("dailyIssues", item), brigadeId, date), productId: String(item.productId || ""), article: String(item.articleSnapshot || ""), productName: String(item.productNameSnapshot || ""), stageId: String(item.stageId || ""), stageName: String(item.stageNameSnapshot || ""), note: String(item.note || ""), createdAtText: String(item.createdAt || ""), imageUrl: String(item.imageUrl || ""), imagePath: String(item.imagePath || "") };
    } else if (prefix === "DAILY_ISSUE_DELETE") {
      deleteRef = db.collection("dailyIssues").doc(id);
      const existing = await deleteRef.get();
      brigadeId = existing.exists ? String(existing.get("brigadeId") || "") : "";
      requireWrite("DAILY_ISSUE_WRITE", brigadeId);
    } else if (prefix === "AUDIT") {
      item = assemblyItem(root, "auditLog", row => String(row.id) === id);
      if (!item) { applied.push(key); continue; }
      brigadeId = String(item.brigadeId || ""); date = String(item.recordDate || "");
      const canAudit = ["BRIGADIR_WRITE","QUALITY_WRITE","DAILY_ISSUE_WRITE","MASTER_DATA_WRITE"].some(k => effectivePermission(userData, k));
      if (!canAudit) throw new HttpsError("permission-denied", "Audit yozish ruxsati yo‘q");
      if (!assemblyScopeAllowed(userData, brigadeId)) throw new HttpsError("permission-denied", "Brigada ruxsati yo‘q");
      ref = db.collection("auditLog").doc(String(item.id));
      doc = { ...assemblyStamp(current.uid, assemblyMiniPayload("auditLog", item), brigadeId, date), action: String(item.action || ""), dateTime: String(item.dateTime || ""), details: String(item.details || "") };
    } else if (prefix === "SETTINGS") {
      requireWrite("MASTER_DATA_WRITE", "");
      ref = db.collection("settings").doc("assembly");
      const settingsPayload = JSON.stringify({ workHours: root.workHours || [], efficiencyNorm: root.efficiencyNorm || [], roundTimes: root.roundTimes || [], monitoringWeights: root.monitoringWeights || [], preparedYears: root.preparedYears || [] });
      doc = assemblyStamp(current.uid, settingsPayload);
    } else {
      applied.push(key); continue;
    }

    if (deleteRef) batch.delete(deleteRef); else batch.set(ref, doc, { merge: true });
    writeCount += 1; applied.push(key); await commitIfNeeded(false);
  }
  await commitIfNeeded(true);
  await Promise.all(batches);
  return { ok: true, applied };
});


function tpItem(root, key, predicate) {
  const rows = root && Array.isArray(root[key]) ? root[key] : [];
  return rows.find(row => row && typeof row === "object" && predicate(row)) || null;
}
function tpMiniPayload(key, item) { return JSON.stringify({ [key]: [item] }); }
function tpStamp(uid, payload, brigadeId) {
  const out = { payload, updatedAt: FieldValue.serverTimestamp(), updatedBy: uid };
  if (brigadeId !== undefined && brigadeId !== null) out.brigadeId = String(brigadeId);
  return out;
}
function tpAnyWrite(userData, keys) { return keys.some(key => effectivePermission(userData, key)); }

/**
 * Reliable TP/Seryo outbox writer.
 *
 * TP used to write Firestore batches directly from Android. One rules/scope mismatch could leave
 * the entire local outbox stuck forever, and a concurrent server pull could then overwrite a new
 * local resin/plan confirmation. This callable validates the signed-in user server-side and writes
 * through Admin SDK, matching the reliable Assembly/Sborka path.
 */
exports.applyTpWrites = onCall({ enforceAppCheck: false, timeoutSeconds: 60, memory: "512MiB" }, async (request) => {
  const current = await requireUser(request);
  const userData = current.data || {};
  const keys = Array.isArray(request.data && request.data.keys) ? request.data.keys.map(String).slice(0, 220) : [];
  const payloadText = String((request.data && request.data.payload) || "");
  const root = safeJsonObject(payloadText);
  if (!root) throw new HttpsError("invalid-argument", "TP sync payload noto‘g‘ri");
  if (keys.length === 0) return { ok: true, applied: [] };

  const applied = [];
  const commits = [];
  let batch = db.batch();
  let writeCount = 0;
  const flush = async force => {
    if (writeCount >= 350 || (force && writeCount > 0)) {
      commits.push(batch.commit());
      batch = db.batch();
      writeCount = 0;
    }
  };
  const requireAny = (permissions, brigadeId = "") => {
    if (!tpAnyWrite(userData, permissions)) throw new HttpsError("permission-denied", `${permissions.join("/")} ruxsati kerak`);
    if (!assemblyScopeAllowed(userData, brigadeId)) throw new HttpsError("permission-denied", "Brigada ruxsati yo‘q");
  };

  for (const rawKey of keys) {
    const key = String(rawKey || "");
    const sep = key.indexOf(":");
    const prefix = sep >= 0 ? key.slice(0, sep) : key;
    const id = sep >= 0 ? key.slice(sep + 1) : "";
    let item = null;
    let brigadeId = "";
    let ref = null;
    let doc = null;
    let deleteRef = null;

    if (prefix === "TP_SHOP") {
      item = tpItem(root, "shops", row => String(row.id) === id); if (!item) { applied.push(key); continue; }
      requireAny(["TP_MASTER_DATA_WRITE"]); ref = db.collection("tpShops").doc(id);
      doc = { ...tpStamp(current.uid, tpMiniPayload("shops", item)), name: String(item.name || ""), archived: item.archived === true };
    } else if (prefix === "TP_SHIFT") {
      item = tpItem(root, "shifts", row => String(row.id) === id); if (!item) { applied.push(key); continue; }
      requireAny(["TP_MASTER_DATA_WRITE"]); ref = db.collection("tpShifts").doc(id);
      doc = { ...tpStamp(current.uid, tpMiniPayload("shifts", item)), name: String(item.name || ""), archived: item.archived === true };
    } else if (prefix === "TP_BRIGADE") {
      item = tpItem(root, "brigades", row => String(row.id) === id); if (!item) { applied.push(key); continue; }
      brigadeId = String(item.id || ""); requireAny(["TP_MASTER_DATA_WRITE"], brigadeId); ref = db.collection("tpBrigades").doc(id);
      doc = { ...tpStamp(current.uid, tpMiniPayload("brigades", item), brigadeId), name: String(item.name || ""), shopId: String(item.shopId || ""), shiftId: String(item.shiftId || ""), archived: item.archived === true };
    } else if (prefix === "TP_MACHINE") {
      item = tpItem(root, "machines", row => String(row.id) === id); if (!item) { applied.push(key); continue; }
      requireAny(["TP_MASTER_DATA_WRITE"]); ref = db.collection("tpMachines").doc(id);
      doc = { ...tpStamp(current.uid, tpMiniPayload("machines", item)), number: Number(item.number || 0), shopId: String(item.shopId || ""), capacity: Number(item.capacity || 0), archived: item.archived === true };
    } else if (prefix === "TP_WORKER") {
      item = tpItem(root, "workers", row => String(row.id) === id); if (!item) { applied.push(key); continue; }
      brigadeId = String(item.brigadeId || ""); requireAny(["TP_MASTER_DATA_WRITE"], brigadeId); ref = db.collection("tpWorkers").doc(id);
      doc = { ...tpStamp(current.uid, tpMiniPayload("workers", item), brigadeId), name: String(item.name || ""), archived: item.archived === true };
    } else if (prefix === "TP_PRODUCT") {
      item = tpItem(root, "products", row => String(row.id) === id); if (!item) { applied.push(key); continue; }
      requireAny(["TP_MASTER_DATA_WRITE"]); ref = db.collection("tpProducts").doc(id);
      doc = { ...tpStamp(current.uid, tpMiniPayload("products", item)), article: String(item.article || ""), name: String(item.name || ""), archived: item.archived === true };
    } else if (prefix === "TP_MATERIAL") {
      item = tpItem(root, "materials", row => String(row.id) === id); if (!item) { applied.push(key); continue; }
      requireAny(["TP_MASTER_DATA_WRITE", "TP_SERYO_WRITE"]); ref = db.collection("tpMaterials").doc(id);
      doc = { ...tpStamp(current.uid, tpMiniPayload("materials", item)), code: String(item.code || ""), type: String(item.type || "RESIN"), availableAmount: Number(item.availableAmount || 0), archived: item.archived === true };
    } else if (prefix === "TP_ORDER") {
      item = tpItem(root, "orders", row => String(row.id) === id); if (!item) { applied.push(key); continue; }
      requireAny(["TP_ORDER_WRITE", "TP_PLANNING_WRITE", "TP_MACHINE_WRITE", "TP_RECEIVING_WRITE"]); ref = db.collection("tpOrders").doc(id);
      doc = { ...tpStamp(current.uid, tpMiniPayload("orders", item)), batchNumber: String(item.batchNumber || ""), productId: String(item.productId || ""), articleSnapshot: String(item.articleSnapshot || ""), productNameSnapshot: String(item.productNameSnapshot || ""), quantity: Number(item.quantity || 0), createdAt: String(item.createdAt || ""), status: String(item.status || "NEW"), priority: Number(item.priority || 0), requestedDate: String(item.requestedDate || ""), planApprovedAt: item.planApprovedAt == null ? "" : String(item.planApprovedAt) };
    } else if (prefix === "TP_ORDER_DELETE") {
      requireAny(["TP_ORDER_WRITE"]); deleteRef = db.collection("tpOrders").doc(id);
    } else if (prefix === "TP_JOB") {
      item = tpItem(root, "jobs", row => String(row.id) === id); if (!item) { applied.push(key); continue; }
      brigadeId = item.brigadeId == null ? "" : String(item.brigadeId); requireAny(["TP_PLANNING_WRITE", "TP_MACHINE_WRITE", "TP_SERYO_WRITE", "TP_RECEIVING_WRITE"], brigadeId); ref = db.collection("tpJobs").doc(id);
      doc = { ...tpStamp(current.uid, tpMiniPayload("jobs", item), brigadeId), orderId: String(item.orderId || ""), moldCode: String(item.moldCode || ""), colorCode: String(item.colorCode || ""), machineId: item.machineId == null ? "" : String(item.machineId), status: String(item.status || "UNASSIGNED"), materialStatus: String(item.materialStatus || "PLANNED"), estimatedMinutes: Number(item.estimatedMinutes || 0), planConfirmedAt: item.planConfirmedAt == null ? "" : String(item.planConfirmedAt), planEditedAt: item.planEditedAt == null ? "" : String(item.planEditedAt), planEditReason: String(item.planEditReason || ""), resinConfirmedAt: item.resinConfirmedAt == null ? "" : String(item.resinConfirmedAt), materialDeliveredAt: item.materialDeliveredAt == null ? "" : String(item.materialDeliveredAt) };
    } else if (prefix === "TP_JOB_DELETE") {
      const existing = await db.collection("tpJobs").doc(id).get(); brigadeId = existing.exists ? String(existing.get("brigadeId") || "") : "";
      requireAny(["TP_ORDER_WRITE", "TP_PLANNING_WRITE"], brigadeId); deleteRef = db.collection("tpJobs").doc(id);
    } else if (prefix === "TP_ATTENDANCE") {
      item = tpItem(root, "attendance", row => String(row.id) === id); if (!item) { applied.push(key); continue; }
      brigadeId = String(item.brigadeId || ""); requireAny(["TP_ATTENDANCE_WRITE"], brigadeId); ref = db.collection("tpAttendance").doc(id);
      doc = { ...tpStamp(current.uid, tpMiniPayload("attendance", item), brigadeId), workerId: String(item.workerId || ""), date: String(item.date || "") };
    } else if (prefix === "TP_RECEIPT") {
      item = tpItem(root, "receipts", row => String(row.id) === id); if (!item) { applied.push(key); continue; }
      brigadeId = String(item.brigadeId || ""); requireAny(["TP_RECEIVING_WRITE"], brigadeId); ref = db.collection("tpReceipts").doc(id);
      doc = { ...tpStamp(current.uid, tpMiniPayload("receipts", item), brigadeId), jobId: String(item.jobId || ""), orderId: String(item.orderId || ""), workerId: String(item.workerId || ""), date: String(item.date || ""), creditedPieces: Number(item.creditedPieces || 0) };
    } else if (prefix === "TP_RECEIPT_DELETE") {
      const existing = await db.collection("tpReceipts").doc(id).get(); brigadeId = existing.exists ? String(existing.get("brigadeId") || "") : "";
      requireAny(["TP_RECEIVING_WRITE"], brigadeId); deleteRef = db.collection("tpReceipts").doc(id);
    } else if (prefix === "TP_QUALITY") {
      item = tpItem(root, "qualityRounds", row => String(row.id) === id); if (!item) { applied.push(key); continue; }
      brigadeId = String(item.brigadeId || ""); requireAny(["TP_QUALITY_WRITE"], brigadeId); ref = db.collection("tpQualityRounds").doc(id);
      doc = { ...tpStamp(current.uid, tpMiniPayload("qualityRounds", item), brigadeId), jobId: String(item.jobId || ""), workerId: String(item.workerId || ""), date: String(item.date || ""), round: Number(item.round || 0), score: Number(item.score || 0) };
    } else if (prefix === "TP_ISSUE") {
      item = tpItem(root, "dailyIssues", row => String(row.id) === id); if (!item) { applied.push(key); continue; }
      brigadeId = String(item.brigadeId || ""); requireAny(["TP_QUALITY_WRITE"], brigadeId); ref = db.collection("tpDailyIssues").doc(id);
      doc = { ...tpStamp(current.uid, tpMiniPayload("dailyIssues", item), brigadeId), date: String(item.date || ""), title: String(item.title || ""), imageUrl: String(item.imageUrl || ""), imagePath: String(item.imagePath || "") };
    } else if (prefix === "TP_DOWNTIME") {
      item = tpItem(root, "machineDowntimes", row => String(row.id) === id); if (!item) { applied.push(key); continue; }
      brigadeId = String(item.brigadeId || ""); requireAny(["TP_MACHINE_WRITE"], brigadeId); ref = db.collection("tpMachineDowntimes").doc(id);
      doc = { ...tpStamp(current.uid, tpMiniPayload("machineDowntimes", item), brigadeId), machineId: String(item.machineId || ""), date: String(item.date || ""), stoppedAt: String(item.stoppedAt || ""), resumedAt: String(item.resumedAt || ""), note: String(item.note || "") };
    } else if (prefix === "TP_AUDIT") {
      item = tpItem(root, "auditLog", row => String(row.id) === id); if (!item) { applied.push(key); continue; }
      brigadeId = item.brigadeId == null ? "" : String(item.brigadeId);
      requireAny(["TP_ORDER_WRITE", "TP_PLANNING_WRITE", "TP_MACHINE_WRITE", "TP_ATTENDANCE_WRITE", "TP_SERYO_WRITE", "TP_RECEIVING_WRITE", "TP_QUALITY_WRITE", "TP_MASTER_DATA_WRITE"], brigadeId);
      ref = db.collection("tpAuditLog").doc(id); doc = { ...tpStamp(current.uid, tpMiniPayload("auditLog", item), brigadeId), action: String(item.action || ""), recordDate: item.recordDate == null ? "" : String(item.recordDate) };
    } else if (prefix === "TP_SETTINGS") {
      requireAny(["TP_MASTER_DATA_WRITE"]); ref = db.collection("settings").doc("tp");
      doc = tpStamp(current.uid, JSON.stringify({ settings: root.settings || {} }));
    } else {
      // Unknown legacy key must not block the whole queue forever.
      applied.push(key); continue;
    }

    if (deleteRef) batch.delete(deleteRef); else batch.set(ref, doc, { merge: true });
    writeCount += 1; applied.push(key); await flush(false);
  }
  await flush(true); await Promise.all(commits);
  return { ok: true, applied };
});

exports.onTpOrderWritten = onDocumentWritten("tpOrders/{orderId}", async (event) => {
  const before = event.data && event.data.before.exists ? event.data.before.data() : null;
  const after = event.data && event.data.after.exists ? event.data.after.data() : null;
  if (!before && after) {
    const label = [after.batchNumber, after.articleSnapshot, after.productNameSnapshot].map(v => String(v || "").trim()).filter(Boolean).join(" • ") || "Yangi TP zakaz";
    await notifyTpByPermissions(["TP_PLANNING_READ"], String(after.brigadeId || ""), "Yangi zakaz", label, "TP_PLAN", "TP_ORDER_NEW", `tp-order-new-${event.params.orderId}`);
    return;
  }
  if (!before || after) return;
  if (before.suppressDeleteNotification === true) return;
  const batchNumber = String(before.batchNumber || "").trim();
  const article = String(before.articleSnapshot || "").trim();
  const productName = String(before.productNameSnapshot || "").trim();
  const label = [batchNumber, article, productName].filter(Boolean).join(" • ") || "TP zakaz";
  await notifyTpUsers(
    "Zakaz o‘chirildi",
    `${label} nachalnik tomonidan o‘chirildi. Reja va bog‘liq vazifalar yangilandi.`,
    "TP_PLAN",
    `tp-order-delete-${event.params.orderId}`
  );
});

async function notifyTpByPermissions(permissionKeys, brigadeId, title, body, route, kind, key) {
  const users = await db.collection("users").where("enabled", "==", true).get();
  const tasks = [];
  for (const doc of users.docs) {
    const data = doc.data();
    if (data.deleted === true) continue;
    const role = normalizeCode(data.role);
    const allowed = data.allBrigades === true || role === "ADMIN" || !brigadeId || normalizedBrigadeIds(data.allowedBrigadeIds).includes(brigadeId);
    if (!allowed) continue;
    const relevant = role === "ADMIN" || permissionKeys.some(permission => effectivePermission(data, permission));
    if (relevant) tasks.push(sendToUid(doc.id, title, body, route, kind, key));
  }
  await Promise.all(tasks);
}

async function notifyTpUsers(title, body, route, key) {
  await notifyTpByPermissions(
    ["TP_ORDER_READ", "TP_PLANNING_READ", "TP_MACHINE_READ", "TP_SERYO_READ", "TP_RECEIVING_READ", "TP_QUALITY_READ", "TP_MONITORING_READ"],
    "", title, body, route, "TP_ORDER_DELETED", key
  );
}

async function maybeNotifyLowMachineQueues() {
  const jobsSnap = await db.collection("tpJobs").get();
  const totals = new Map();
  for (const doc of jobsSnap.docs) {
    const data = doc.data();
    const status = String(data.status || "");
    const machineId = String(data.machineId || "");
    const planConfirmedAt = String(data.planConfirmedAt || "");
    if (!machineId || !planConfirmedAt || status === "COMPLETE") continue;
    const minutes = Math.max(0, Number(data.estimatedMinutes || 0));
    totals.set(machineId, (totals.get(machineId) || 0) + minutes);
  }

  // One notification per low-queue episode: after a machine rises above 18h (or gets no
  // planned work), the marker is cleared and a future drop to <=18h may notify again.
  const markerRef = db.collection("systemAlerts").doc("tp-low-machine-queue");
  const marker = await markerRef.get();
  const previousActive = new Set(marker.exists && Array.isArray(marker.get("activeMachineIds")) ? marker.get("activeMachineIds").map(String) : []);
  const currentActive = new Set();
  const newlyLow = [];

  for (const [machineId, minutes] of totals.entries()) {
    if (minutes <= 1080) {
      currentActive.add(machineId);
      if (!previousActive.has(machineId)) {
        const snap = await db.collection("tpMachines").doc(machineId).get();
        const number = snap.exists ? Number(snap.get("number") || 0) : 0;
        newlyLow.push({ machineId, number, minutes });
      }
    }
  }

  await markerRef.set({ activeMachineIds: [...currentActive], updatedAt: FieldValue.serverTimestamp() }, { merge: true });
  if (!newlyLow.length) return;
  newlyLow.sort((a, b) => a.minutes - b.minutes || a.number - b.number);
  const labels = newlyLow.map(row => `${row.number || "?"}-stanok — ${Math.floor(row.minutes / 60)} soat ${Math.round(row.minutes % 60)} daqiqa`).join("; ");
  const keySource = newlyLow.map(row => row.machineId).sort().join("|");
  await notifyTpByPermissions(["TP_PLANNING_READ"], "", "Stanok rejasi kamaymoqda", `18 soat yoki undan kam ish qolgan stanoklar: ${labels}`, "TP_PLAN", "TP_MACHINE_LOW_QUEUE", `tp-low-machine-${crypto.createHash("sha1").update(keySource).digest("hex").slice(0,12)}-${Date.now()}`);
}

exports.onTpJobWritten = onDocumentWritten("tpJobs/{jobId}", async (event) => {
  const before = event.data && event.data.before.exists ? event.data.before.data() : {};
  const after = event.data && event.data.after.exists ? event.data.after.data() : null;
  if (!after) { await maybeNotifyLowMachineQueues(); return; }
  const brigadeId = String(after.brigadeId || "");
  const orderId = String(after.orderId || "");
  let order = null;
  if (orderId) {
    const snap = await db.collection("tpOrders").doc(orderId).get();
    if (snap.exists) order = snap.data();
  }
  const label = [order && order.articleSnapshot, order && order.productNameSnapshot, after.colorCode].map(v => String(v || "").trim()).filter(Boolean).join(" • ") || "TP detal";
  if (!before.planConfirmedAt && after.planConfirmedAt) {
    await notifyTpByPermissions(["TP_SERYO_READ"], brigadeId, "Detal rejalandi", `${label} uchun seryoni tanlash kerak.`, "TP_SERYO", "TP_PLAN_CONFIRMED", `tp-plan-confirm-${orderId}-${String(after.moldCode || "")}-${after.planConfirmedAt}`);
  }
  if (!before.resinConfirmedAt && after.resinConfirmedAt) {
    await notifyTpByPermissions(["TP_SERYO_READ"], brigadeId, "Qorishma tayyorlash", `${label} seryosi tasdiqlandi va tayyorlashga yuborildi.`, "TP_SERYO", "TP_RESIN_CONFIRMED", `tp-resin-confirm-${event.params.jobId}-${after.resinConfirmedAt}`);
  }
  if (!before.materialDeliveredAt && after.materialDeliveredAt) {
    await notifyTpByPermissions(["TP_MACHINE_READ"], brigadeId, "Seryo yetkazildi", `${label} stanok uchun tayyor.`, "TP_MACHINE", "TP_MATERIAL_DELIVERED", `tp-material-${event.params.jobId}-${after.materialDeliveredAt}`);
  }
  if (after.planEditedAt && String(before.planEditedAt || "") !== String(after.planEditedAt || "")) {
    const reason = String(after.planEditReason || "").trim();
    await notifyTpByPermissions(["TP_SERYO_READ","TP_MACHINE_READ","TP_RECEIVING_READ","TP_QUALITY_READ"], brigadeId, "Plan tahrirlandi", `${label}${reason ? ` • Sharh: ${reason}` : ""}`, "TP_PLAN", "TP_PLAN_EDITED", `tp-plan-edit-${orderId}-${String(after.moldCode || "")}-${after.planEditedAt}`);
  }
  await maybeNotifyLowMachineQueues();
});

exports.onWorkerDayWritten = onDocumentWritten("workerDays/{dayId}", async (event) => {
  const current = event.data && event.data.after.exists ? event.data.after.data() : (event.data && event.data.before.exists ? event.data.before.data() : null);
  if (!current || !current.brigadeId) return;
  await sendSyncSignal(String(current.brigadeId), ["BRIGADIR_READ", "MONITORING_READ"], "MONITORING", `worker-day-${event.params.dayId}`);
});

exports.onAssemblyQualityRoundWritten = onDocumentWritten("qualityRounds/{roundId}", async (event) => {
  const current = event.data && event.data.after.exists ? event.data.after.data() : (event.data && event.data.before.exists ? event.data.before.data() : null);
  if (!current || !current.brigadeId) return;
  await sendSyncSignal(String(current.brigadeId), ["QUALITY_READ", "MONITORING_READ"], "QUALITY", `quality-round-${event.params.roundId}`);
});

exports.onBrigadeDayWritten = onDocumentWritten("brigadeDays/{dayId}", async (event) => {
  const before = event.data && event.data.before.exists ? event.data.before.data() : null;
  const after = event.data && event.data.after.exists ? event.data.after.data() : null;
  const current = after || before;
  if (!current) return;
  const brigadeId = current.brigadeId;
  const date = current.date;
  if (!brigadeId || !date) return;

  await sendSyncSignal(
    brigadeId,
    ["BRIGADIR_READ", "QUALITY_READ", "MONITORING_READ"],
    "MONITORING",
    `brigade-day-${brigadeId}-${date}`
  );
  if (!after) return;
  if ((!before || before.brigadirClosed !== after.brigadirClosed) && after.brigadirClosed === true) {
    await notifyWatchers(brigadeId, "DAY_STATUS", "Brigadir kuni yopildi", `${date} kuni brigadir tomonidan yopildi.`, "MONITORING", `brigadir-close-${brigadeId}-${date}`);
  }
  if ((!before || before.qualityClosed !== after.qualityClosed) && after.qualityClosed === true) {
    await notifyWatchers(brigadeId, "DAY_STATUS", "Sifat kuni yopildi", `${date} kuni sifat nazorati tomonidan yopildi.`, "MONITORING", `quality-close-${brigadeId}-${date}`);
  }
});

exports.onDailyIssueWritten = onDocumentWritten("dailyIssues/{issueId}", async (event) => {
  const before = event.data && event.data.before.exists ? event.data.before.data() : null;
  const after = event.data && event.data.after.exists ? event.data.after.data() : null;
  const current = after || before;
  if (!current || !current.brigadeId) return;
  await sendSyncSignal(
    current.brigadeId,
    ["DAILY_ISSUE_READ", "MONITORING_READ"],
    "DAILY_ISSUE",
    `daily-issue-${event.params.issueId}`
  );
});

exports.qualityDeadlineCheck = onSchedule({ schedule: "55 17 * * *", timeZone: "Asia/Tashkent" }, async () => {
  const date = localDateString(new Date());
  const active = await activeBrigades();
  const days = await db.collection("brigadeDays").where("date", "==", date).get();
  const closed = new Set(days.docs.filter(d => d.get("qualityClosed") === true).map(d => d.get("brigadeId")));
  for (const brigade of active) {
    if (!closed.has(brigade.id)) await notifyWatchers(brigade.id, "DAY_STATUS", "Sifat kuni yopilmagan", `${date} kuni sifat nazorati yopilmagan.`, "QUALITY", `quality-deadline-${brigade.id}-${date}`);
  }
});

exports.brigadirDeadlineCheck = onSchedule({ schedule: "5 9 * * *", timeZone: "Asia/Tashkent" }, async () => {
  const date = localDateString(new Date(Date.now() - 24 * 60 * 60 * 1000));
  const active = await activeBrigades();
  const days = await db.collection("brigadeDays").where("date", "==", date).get();
  const byBrigade = new Map(days.docs.map(d => [d.get("brigadeId"), d.data()]));
  for (const brigade of active) {
    const day = byBrigade.get(brigade.id);
    if (day && day.brigadirClosed === true) continue;
    await notifyWatchers(brigade.id, "DAY_STATUS", "Brigadir yopish muddati o‘tdi", `${date} kuni brigadir tomonidan yopilmagan.`, "BRIGADIR", `brigadir-deadline-${brigade.id}-${date}`);
  }
});

exports.issueDailySummary = onSchedule({ schedule: "0 18 * * *", timeZone: "Asia/Tashkent" }, async () => {
  const date = localDateString(new Date());
  const issues = await db.collection("dailyIssues").where("date", "==", date).get();
  const groups = new Map();
  for (const doc of issues.docs) {
    const brigadeId = doc.get("brigadeId");
    if (!brigadeId) continue;
    groups.set(brigadeId, (groups.get(brigadeId) || 0) + 1);
  }
  for (const [brigadeId, count] of groups.entries()) {
    await notifyWatchers(brigadeId, "ISSUE_SUMMARY", "Bugungi Sborka muammolari", `${date} kuni ${count} ta muammo yozildi.`, "MONITORING", `issue-summary-${brigadeId}-${date}`);
  }
});

async function activeBrigades() {
  const snap = await db.collection("brigades").where("archived", "==", false).get();
  return snap.docs.filter(d => d.get("deleted") !== true).map(d => ({ id: d.id, ...d.data() }));
}

function localDateString(date) {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Tashkent", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(date);
  const map = Object.fromEntries(parts.map(p => [p.type, p.value]));
  return `${map.year}-${map.month}-${map.day}`;
}

async function sendSyncSignal(brigadeId, permissionKeys, route, key) {
  const users = await db.collection("users").where("enabled", "==", true).get();
  const tasks = [];
  for (const doc of users.docs) {
    const data = doc.data();
    const inScope = data.allBrigades === true || (Array.isArray(data.allowedBrigadeIds) && data.allowedBrigadeIds.includes(brigadeId));
    const permissions = data.permissions && typeof data.permissions === "object" ? data.permissions : {};
    const canRead = String(data.role || "").toUpperCase() === "ADMIN" || permissionKeys.some(keyName => permissions[keyName] === true);
    if (inScope && canRead) tasks.push(sendDataToUid(doc.id, route, "DATA_CHANGED", key));
  }
  await Promise.all(tasks);
}

async function sendDataToUid(uid, route, type, key) {
  const devices = await db.collection("users").doc(uid).collection("devices").where("enabled", "==", true).get();
  const tokens = [...new Set(devices.docs.map(d => d.get("fcmToken")).filter(Boolean))];
  if (tokens.length === 0) return;
  const response = await messaging.sendEachForMulticast({
    tokens,
    data: { route: String(route || "MONITORING"), type: String(type || "DATA_CHANGED"), key: String(key || "data-change") },
    android: { collapseKey: String(key || "toybola-sync").slice(0, 64), priority: "high" }
  });
  await disableInvalidTokens(devices.docs, tokens, response);
}

async function disableInvalidTokens(deviceDocs, tokens, response) {
  const invalid = [];
  response.responses.forEach((r, i) => {
    if (!r.success && r.error && ["messaging/registration-token-not-registered", "messaging/invalid-registration-token"].includes(r.error.code)) invalid.push(tokens[i]);
  });
  if (invalid.length) {
    const batch = db.batch();
    deviceDocs.filter(d => invalid.includes(d.get("fcmToken"))).forEach(d => batch.set(d.ref, { enabled: false }, { merge: true }));
    await batch.commit();
  }
}

async function notifyWatchers(brigadeId, notificationKey, title, body, route, key) {
  const users = await db.collection("users").where("enabled", "==", true).get();
  const tasks = [];
  for (const doc of users.docs) {
    const data = doc.data();
    const notifications = Array.isArray(data.notifications) ? data.notifications : [];
    const inScope = data.allBrigades === true || (Array.isArray(data.allowedBrigadeIds) && data.allowedBrigadeIds.includes(brigadeId));
    if (notifications.includes(notificationKey) && inScope) tasks.push(sendToUid(doc.id, title, body, route, notificationKey, key));
  }
  await Promise.all(tasks);
}

async function sendToUid(uid, title, body, route, type, key) {
  const devices = await db.collection("users").doc(uid).collection("devices").where("enabled", "==", true).get();
  const tokens = [...new Set(devices.docs.map(d => d.get("fcmToken")).filter(Boolean))];
  if (tokens.length === 0) return;
  const response = await messaging.sendEachForMulticast({
    tokens,
    notification: { title, body },
    data: { title, body, route, type, key }
  });
  await disableInvalidTokens(devices.docs, tokens, response);
}
