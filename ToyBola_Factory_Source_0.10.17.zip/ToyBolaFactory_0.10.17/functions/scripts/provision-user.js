"use strict";

const crypto = require("crypto");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

initializeApp();
const db = getFirestore();
const auth = getAuth();
const normalize = v => String(v || "").trim().toUpperCase();
const sha256 = v => crypto.createHash("sha256").update(String(v), "utf8").digest("hex");

const permissionKeys = [
  "BRIGADIR_READ", "BRIGADIR_WRITE",
  "QUALITY_READ", "QUALITY_WRITE",
  "DAILY_ISSUE_READ", "DAILY_ISSUE_WRITE",
  "MONITORING_READ", "MASTER_DATA_READ", "MASTER_DATA_WRITE",
  "TP_ORDER_READ", "TP_ORDER_WRITE",
  "TP_PLANNING_READ", "TP_PLANNING_WRITE",
  "TP_MACHINE_READ", "TP_MACHINE_WRITE",
  "TP_ATTENDANCE_READ", "TP_ATTENDANCE_WRITE",
  "TP_OVERTIME_READ", "TP_OVERTIME_WRITE",
  "TP_SERYO_READ", "TP_SERYO_WRITE",
  "TP_RECEIVING_READ", "TP_RECEIVING_WRITE",
  "TP_QUALITY_READ", "TP_QUALITY_WRITE",
  "TP_MONITORING_READ",
  "TP_MASTER_DATA_READ", "TP_MASTER_DATA_WRITE"
];

function defaults(role) {
  const p = Object.fromEntries(permissionKeys.map(k => [k, false]));
  if (role === "ADMIN") permissionKeys.forEach(k => { p[k] = true; });
  if (role === "RAHBAR") Object.assign(p, {
    BRIGADIR_READ: true, QUALITY_READ: true, DAILY_ISSUE_READ: true,
    MONITORING_READ: true, MASTER_DATA_READ: true, TP_OVERTIME_READ: true
  });
  if (role === "BRIGADIR") Object.assign(p, {
    BRIGADIR_READ: true, BRIGADIR_WRITE: true,
    DAILY_ISSUE_READ: true, DAILY_ISSUE_WRITE: true, MONITORING_READ: true
  });
  if (role === "QUALITY") Object.assign(p, {
    QUALITY_READ: true, QUALITY_WRITE: true,
    DAILY_ISSUE_READ: true, DAILY_ISSUE_WRITE: true, MONITORING_READ: true
  });
  if (role === "TP_NACHALNIK") Object.assign(p, {
    TP_ORDER_READ: true, TP_ORDER_WRITE: true, TP_PLANNING_READ: true,
    TP_MACHINE_READ: true, TP_ATTENDANCE_READ: true,
    TP_MONITORING_READ: true, TP_MASTER_DATA_READ: true
  });
  if (role === "TP_PLAN") Object.assign(p, {
    TP_ORDER_READ: true, TP_PLANNING_READ: true, TP_PLANNING_WRITE: true,
    TP_MACHINE_READ: true, TP_MACHINE_WRITE: true,
    TP_ATTENDANCE_READ: true, TP_ATTENDANCE_WRITE: true,
    TP_OVERTIME_READ: true, TP_OVERTIME_WRITE: true,
    TP_SERYO_READ: true, TP_MONITORING_READ: true,
    TP_MASTER_DATA_READ: true, TP_MASTER_DATA_WRITE: true
  });
  if (role === "TP_BRIGADIR") Object.assign(p, {
    TP_MACHINE_READ: true, TP_MACHINE_WRITE: true,
    TP_SERYO_READ: true, TP_RECEIVING_READ: true, TP_QUALITY_READ: true,
    TP_MONITORING_READ: true
  });
  if (role === "TP_SERYO") Object.assign(p, {
    TP_MACHINE_READ: true,
    TP_SERYO_READ: true, TP_SERYO_WRITE: true,
    TP_MONITORING_READ: true, TP_MASTER_DATA_READ: true
  });
  if (role === "TP_QABUL") Object.assign(p, {
    TP_MACHINE_READ: true,
    TP_RECEIVING_READ: true, TP_RECEIVING_WRITE: true, TP_MONITORING_READ: true
  });
  if (role === "TP_QUALITY") Object.assign(p, {
    TP_MACHINE_READ: true,
    TP_QUALITY_READ: true, TP_QUALITY_WRITE: true, TP_MONITORING_READ: true
  });
  return p;
}

(async () => {
  const userCode = normalize(process.env.TOYBOLA_USER_CODE);
  const deviceCode = normalize(process.env.TOYBOLA_DEVICE_CODE);
  const displayName = String(process.env.TOYBOLA_DISPLAY_NAME || "").trim();
  const role = normalize(process.env.TOYBOLA_ROLE);
  const allBrigades = String(process.env.TOYBOLA_ALL_BRIGADES || "false").toLowerCase() === "true";
  const allowedBrigadeIds = String(process.env.TOYBOLA_BRIGADES || "")
    .split(",").map(v => v.trim()).filter(Boolean);

  if (!userCode || !deviceCode || !displayName) throw new Error("User code, device code va ism kerak");
  if (!["ADMIN", "RAHBAR", "BRIGADIR", "QUALITY", "TP_NACHALNIK", "TP_PLAN", "TP_BRIGADIR", "TP_SERYO", "TP_QABUL", "TP_QUALITY"].includes(role)) throw new Error("Role noto‘g‘ri");
  if (!allBrigades && allowedBrigadeIds.length === 0) throw new Error("Kamida bitta brigade ID kerak");

  const loginId = sha256(userCode);
  const loginRef = db.collection("loginCodes").doc(loginId);
  const existingLogin = await loginRef.get();
  const uid = existingLogin.exists ? existingLogin.get("uid") : `tb_${loginId.slice(0, 28)}`;

  try {
    await auth.getUser(uid);
  } catch (e) {
    if (e && e.code === "auth/user-not-found") await auth.createUser({ uid, displayName });
    else throw e;
  }

  const userRef = db.collection("users").doc(uid);
  const previous = await userRef.get();
  const revision = Number(previous.exists ? previous.get("revision") || 0 : 0) + 1;
  const notifications = role === "ADMIN" || role === "RAHBAR" ? ["DAY_STATUS", "ISSUE_SUMMARY"] : [];

  await userRef.set({
    uid, userCode, displayName, role, enabled: true,
    allBrigades, allowedBrigadeIds: [...new Set(allowedBrigadeIds)],
    permissions: defaults(role), notifications, revision,
    updatedAt: FieldValue.serverTimestamp(),
    ...(previous.exists ? {} : { createdAt: FieldValue.serverTimestamp() })
  }, { merge: true });

  await loginRef.set({
    uid, enabled: true,
    // Provisioning is a rotation too: only the newly issued code remains valid.
    deviceHashes: [sha256(deviceCode)],
    updatedAt: FieldValue.serverTimestamp()
  }, { merge: true });

  console.log(`Pilot user tayyor: ${userCode} / role=${role} / uid=${uid}`);
})().catch(err => { console.error(err); process.exit(1); });
