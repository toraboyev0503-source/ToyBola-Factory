package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate

private enum class TpMonitorPage { ROOT, WORKERS, WORKER, MACHINES, MACHINE, MATERIALS, MATERIAL }

@Composable
fun TpMonitoringScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val revision by TpDataEvents.revision.collectAsState()
    val policy = remember(revision) { AccessGuard(context).currentPolicy() }
    val data = remember(revision, policy.revision) { repository.load().scopedFor(policy) }
    var page by remember { mutableStateOf(TpMonitorPage.ROOT) }
    var selectedWorkerId by remember { mutableStateOf<String?>(null) }
    var selectedMachineId by remember { mutableStateOf<String?>(null) }
    var selectedMaterialId by remember { mutableStateOf<String?>(null) }
    var from by remember { mutableStateOf(LocalDate.now().toString()) }
    var to by remember { mutableStateOf(LocalDate.now().toString()) }
    val exportBrigades = data.brigades.filterNot { it.archived }.sortedBy { it.name.lowercase() }.take(6)
    var excelBrigadeId by remember(exportBrigades) {
        mutableStateOf(exportBrigades.firstOrNull()?.id.orEmpty())
    }
    var excelMessage by remember { mutableStateOf<String?>(null) }
    val excelLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri ->
        if (uri != null && excelBrigadeId.isNotBlank()) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    MonthlyPayrollXlsxExporter.writeTp(context, out, data, excelBrigadeId, from, to)
                } ?: error("Excel faylini ochib bo‘lmadi")
            }.onSuccess { excelMessage = "Excel saqlandi" }
                .onFailure { excelMessage = it.message ?: "Excel saqlanmadi" }
        }
    }

    fun setHalfMonth(secondHalf: Boolean) {
        val base = runCatching { LocalDate.parse(from) }.getOrDefault(LocalDate.now())
        val (start, end) = MonthlyPayrollXlsxExporter.periodForHalf(base.year, base.monthValue, secondHalf)
        from = start
        to = end
    }

    fun exportExcel() {
        val brigade = exportBrigades.firstOrNull { it.id == excelBrigadeId } ?: return
        val safeName = brigade.name.replace(Regex("[^\\p{L}\\p{N}._-]+"), "_").trim('_').ifBlank { "brigada" }
        excelMessage = null
        excelLauncher.launch("TP_${safeName}_${from}_${to}.xlsx")
    }

    fun back() {
        when (page) {
            TpMonitorPage.ROOT -> onBack()
            TpMonitorPage.WORKER -> page = TpMonitorPage.WORKERS
            TpMonitorPage.MACHINE -> page = TpMonitorPage.MACHINES
            TpMonitorPage.MATERIAL -> page = TpMonitorPage.MATERIALS
            else -> page = TpMonitorPage.ROOT
        }
    }
    BackHandler { back() }

    val title = when (page) {
        TpMonitorPage.ROOT -> "Monitoring"
        TpMonitorPage.WORKERS -> "Monitoring • Ishchilar"
        TpMonitorPage.WORKER -> "Ishchi tafsiloti"
        TpMonitorPage.MACHINES -> "Monitoring • Stanoklar"
        TpMonitorPage.MACHINE -> "Stanok tafsiloti"
        TpMonitorPage.MATERIALS -> "Monitoring • Seryo bo‘limi"
        TpMonitorPage.MATERIAL -> "Seryo tafsiloti"
    }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(title, canGoBack = true, onMenu = {}, onBack = ::back)
        when (page) {
            TpMonitorPage.ROOT -> TpMonitoringRoot(
                data = data,
                from = from,
                to = to,
                onFrom = { from = it },
                onTo = { to = it },
                exportBrigades = exportBrigades,
                excelBrigadeId = excelBrigadeId,
                onExcelBrigade = { excelBrigadeId = it },
                onFirstHalf = { setHalfMonth(false) },
                onSecondHalf = { setHalfMonth(true) },
                onExportExcel = ::exportExcel,
                excelMessage = excelMessage,
                onWorkers = { page = TpMonitorPage.WORKERS },
                onMachines = { page = TpMonitorPage.MACHINES },
                onMaterials = { page = TpMonitorPage.MATERIALS }
            )
            TpMonitorPage.WORKERS -> TpWorkerMonitoring(data, from, to) { selectedWorkerId = it; page = TpMonitorPage.WORKER }
            TpMonitorPage.WORKER -> selectedWorkerId?.let { TpWorkerMonitoringDetail(data, it, from, to) }
            TpMonitorPage.MACHINES -> TpMachineMonitoring(data, from, to) { selectedMachineId = it; page = TpMonitorPage.MACHINE }
            TpMonitorPage.MACHINE -> selectedMachineId?.let { TpMachineMonitoringDetail(data, it, from, to) }
            TpMonitorPage.MATERIALS -> TpMaterialMonitoring(data, from, to) { selectedMaterialId = it; page = TpMonitorPage.MATERIAL }
            TpMonitorPage.MATERIAL -> selectedMaterialId?.let { TpMaterialMonitoringDetail(data, it, from, to) }
        }
    }
}

@Composable
private fun TpMonitoringRoot(
    data: TpData,
    from: String,
    to: String,
    onFrom: (String) -> Unit,
    onTo: (String) -> Unit,
    exportBrigades: List<TpBrigade>,
    excelBrigadeId: String,
    onExcelBrigade: (String) -> Unit,
    onFirstHalf: () -> Unit,
    onSecondHalf: () -> Unit,
    onExportExcel: () -> Unit,
    excelMessage: String?,
    onWorkers: () -> Unit,
    onMachines: () -> Unit,
    onMaterials: () -> Unit
) {
    val today = LocalDate.now().toString()
    val workers = data.workers.filterNot { it.archived }
    val machines = data.machines.filterNot { it.archived }
    val activeJobs = data.jobs.filter { it.machineId != null && it.status != TpJobStatus.COMPLETE }
    val busyIds = activeJobs.mapNotNull { it.machineId }.toSet()
    val absentToday = data.attendance.count { it.date == today && !it.present }
    val minusToday = data.attendance.count { it.date == today && it.present && it.minusHours > 0.0 }
    val stopToday = data.machineDowntimes.filter { it.date == today }
    val shortMaterials = activeMaterialShortages(data)
    val soonFree = machines.count { machine ->
        val minutes = activeJobs.filter { it.machineId == machine.id }.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
        minutes in 1..1080
    }
    val prepWaiting = data.jobs.count { it.resinConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED && it.status != TpJobStatus.COMPLETE }

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-root"))
            .navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)) { TpDatePickerButton("Dan", from, onFrom) }
            Box(Modifier.weight(1f)) { TpDatePickerButton("Gacha", to, onTo) }
        }

        Text("Oylik Excel", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Shablon: TP.xlsx • qo‘shimcha soat puli ishchi maoshiga qo‘shiladi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (exportBrigades.isNotEmpty()) {
            TpFilterRow(exportBrigades, excelBrigadeId, { it.id }, { it.name }, onExcelBrigade)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onFirstHalf, modifier = Modifier.weight(1f)) { Text("1–15") }
                OutlinedButton(onClick = onSecondHalf, modifier = Modifier.weight(1f)) { Text("16–oy oxiri") }
            }
            Button(onClick = onExportExcel, modifier = Modifier.fillMaxWidth()) { Text("Excelga chiqarish") }
            if (!excelMessage.isNullOrBlank()) {
                Text(excelMessage, color = if (excelMessage.contains("saqlandi", ignoreCase = true)) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            }
        } else {
            Text("Excel uchun ko‘rinadigan brigada yo‘q.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Text("E’tibor talab qiladi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        TpCard {
            if (absentToday == 0 && stopToday.isEmpty() && shortMaterials.isEmpty() && soonFree == 0 && prepWaiting == 0) {
                Text("Hozir keskin ogohlantirish yo‘q.", color = MaterialTheme.colorScheme.primary)
            } else {
                if (absentToday > 0) Text("• $absentToday ishchi bugun ishlamadi", color = MaterialTheme.colorScheme.error)
                if (stopToday.isNotEmpty()) Text("• ${stopToday.size} ta stanok o‘chish yozuvi • ${stopToday.sumOf { it.durationMinutes() }} daqiqa", color = MaterialTheme.colorScheme.error)
                if (shortMaterials.isNotEmpty()) Text("• ${shortMaterials.size} ta seryo/krasitel qoldig‘i faol reja uchun yetmaydi", color = MaterialTheme.colorScheme.error)
                if (soonFree > 0) Text("• $soonFree stanokda 18 soat yoki kam ish qolgan")
                if (prepWaiting > 0) Text("• $prepWaiting qorishma tayyorlash/yetkazishni kutmoqda")
            }
        }

        MonitoringDirectionCard(
            title = "1. Ishchilar",
            summary = "${workers.size} ishchi • $absentToday ishlamagan • $minusToday minus soatli",
            detail = "Davomat → brigada → ishchi → ishlab chiqarish, qo‘shimcha soat, sifat va foydalilik",
            onClick = onWorkers
        )
        MonitoringDirectionCard(
            title = "2. Stanoklar",
            summary = "${machines.size} stanok • ${busyIds.size} ishda/navbatda • ${machines.size - busyIds.size} bo‘sh",
            detail = "Sex → stanok → joriy reja, navbat, qabul, o‘chishlar va yo‘qotilgan vaqt",
            onClick = onMachines
        )
        MonitoringDirectionCard(
            title = "3. Seryo bo‘limi",
            summary = "${data.materials.count { !it.archived }} material • $prepWaiting tayyorlashda • ${shortMaterials.size} yetishmovchilik",
            detail = "Seryo/krasitel → qoldiq → prixod/rasxod → qaysi zakaz va stanoklarga sarflangani",
            onClick = onMaterials
        )
    }
}

@Composable
private fun MonitoringDirectionCard(title: String, summary: String, detail: String, onClick: () -> Unit) {
    TpCard(Modifier.clickable(onClick = onClick)) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(summary, fontWeight = FontWeight.SemiBold)
        Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun TpWorkerMonitoring(data: TpData, from: String, to: String, onWorker: (String) -> Unit) {
    val workers = data.workers.filterNot { it.archived }
    val periodAttendance = data.attendance.filter { it.date in from..to }
    val absent = periodAttendance.count { !it.present }
    val minus = periodAttendance.count { it.present && it.minusHours > 0.0 }
    val totalPiece = data.receipts.filter { it.date in from..to }.sumOf { it.earnedAmount }
    val totalExtra = data.extraHours.filter { it.date in from..to }.sumOf { it.amount }

    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-workers")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Umumiy xulosa", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        TpCard {
            Text("${workers.size} faol ishchi • $absent ishlamagan kun • $minus minus-soatli kun")
            Text("Ishlab chiqarish: $totalPiece so‘m • Qo‘shimcha soat: $totalExtra so‘m")
        }
        data.brigades.filterNot { it.archived }.sortedBy { it.name }.forEach { brigade ->
            val brigadeWorkers = workers.filter { it.brigadeId == brigade.id }
            if (brigadeWorkers.isNotEmpty()) {
                Text(brigade.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                brigadeWorkers.forEach { worker ->
                    val receipts = data.receipts.filter { it.workerId == worker.id && it.date in from..to }
                    val extra = data.extraHours.filter { it.workerId == worker.id && it.date in from..to }.sumOf { it.amount }
                    val earned = receipts.sumOf { it.earnedAmount } + extra
                    val quality = data.qualityRounds.filter { it.workerId == worker.id && it.date in from..to }.map { it.score }.takeIf { it.isNotEmpty() }?.average()
                    TpCard(Modifier.clickable { onWorker(worker.id) }) {
                        Text(worker.name, fontWeight = FontWeight.Bold)
                        Text("Topgan: $earned so‘m${if (extra > 0) " • qo‘shimcha $extra so‘m" else ""}")
                        Text("Qabul: ${receipts.sumOf { it.creditedPieces }} dona • Sifat: ${quality?.toInt()?.let { "$it%" } ?: "—"}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun TpWorkerMonitoringDetail(data: TpData, workerId: String, from: String, to: String) {
    val worker = data.workers.firstOrNull { it.id == workerId } ?: return
    val brigade = data.brigades.firstOrNull { it.id == worker.brigadeId }
    val dates = periodDates(from, to)
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-worker-$workerId")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(worker.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(brigade?.name.orEmpty(), color = MaterialTheme.colorScheme.onSurfaceVariant)
        dates.forEach { date ->
            val attendance = data.attendance.firstOrNull { it.workerId == workerId && it.date == date }
            val piece = data.workerPieceEarned(workerId, date)
            val extra = data.workerExtraEarned(workerId, date)
            val quality = data.workerQuality(workerId, date)
            val efficiency = data.workerEfficiency(workerId, date)
            if (attendance != null || piece > 0 || extra > 0 || quality != null) {
                TpCard {
                    Text(date, fontWeight = FontWeight.Bold)
                    Text(when {
                        attendance == null -> "Davomat yozuvi yo‘q"
                        !attendance.present -> "Ishlamadi"
                        attendance.minusHours > 0 -> "Minus ${formatTpNumber(attendance.minusHours)} soat • ${data.attendanceWorkMinutes(workerId, date)} daqiqa"
                        else -> "To‘liq ishlagan • ${data.attendanceWorkMinutes(workerId, date)} daqiqa"
                    })
                    Text("Ishlab chiqarish: $piece so‘m${if (extra > 0) " • Qo‘shimcha: $extra so‘m" else ""}")
                    Text("Jami: ${piece + extra} so‘m • Samaradorlik: ${efficiency?.toInt()?.let { "$it%" } ?: "—"} • Sifat: ${quality?.toInt()?.let { "$it%" } ?: "—"}")
                }
            }
        }
    }
}

@Composable
private fun TpMachineMonitoring(data: TpData, from: String, to: String, onMachine: (String) -> Unit) {
    val machines = data.machines.filterNot { it.archived }
    val jobs = data.jobs.filter { it.machineId != null && it.status != TpJobStatus.COMPLETE }
    val busyIds = jobs.mapNotNull { it.machineId }.toSet()
    val stops = data.machineDowntimes.filter { it.date in from..to }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-machines")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TpCard {
            Text("${machines.size} stanok • ${busyIds.size} ish/navbat • ${machines.size - busyIds.size} bo‘sh")
            Text("O‘chish: ${stops.size} marta • ${stops.sumOf { it.durationMinutes() }} daqiqa")
        }
        data.shops.filterNot { it.archived }.sortedBy { it.name }.forEach { shop ->
            val shopMachines = machines.filter { it.shopId == shop.id }
            if (shopMachines.isNotEmpty()) {
                Text(shop.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                shopMachines.forEach { machine ->
                    val machineJobs = jobs.filter { it.machineId == machine.id }
                    val receipts = data.receipts.filter { it.machineId == machine.id && it.date in from..to }
                    val downtime = stops.filter { it.machineId == machine.id }
                    TpCard(Modifier.clickable { onMachine(machine.id) }) {
                        Text("${machine.number}-stanok${machine.name.takeIf { it.isNotBlank() }?.let { " • $it" }.orEmpty()}", fontWeight = FontWeight.Bold)
                        if (machineJobs.isEmpty()) Text("Zakaz yo‘q", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        else Text("${machineJobs.count { it.status == TpJobStatus.IN_PROGRESS }} ishda • ${machineJobs.count { it.status != TpJobStatus.IN_PROGRESS }} navbatda • ${minutesLabel(machineJobs.sumOf { it.estimatedMinutes.coerceAtLeast(0) })} ish")
                        Text("Qabul: ${receipts.sumOf { it.creditedPieces }} dona • O‘chish: ${downtime.size} / ${downtime.sumOf { it.durationMinutes() }} daq", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun TpMachineMonitoringDetail(data: TpData, machineId: String, from: String, to: String) {
    val machine = data.machines.firstOrNull { it.id == machineId } ?: return
    val shop = data.shops.firstOrNull { it.id == machine.shopId }
    val jobs = data.jobs.filter { it.machineId == machineId && it.status != TpJobStatus.COMPLETE }.sortedBy { it.priority }
    val stops = data.machineDowntimes.filter { it.machineId == machineId && it.date in from..to }.sortedWith(compareByDescending<TpMachineDowntime> { it.date }.thenByDescending { it.stoppedAt })
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-machine-$machineId")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("${machine.number}-stanok • ${shop?.name.orEmpty()}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Joriy va navbatdagi ishlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (jobs.isEmpty()) Text("Zakaz yo‘q.")
        jobs.forEach { job ->
            val order = data.orders.firstOrNull { it.id == job.orderId }
            TpCard {
                Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.Bold)
                Text(job.outputs.map { it.detailName }.distinct().joinToString())
                Text("Rang ${job.colorCode} • ${minutesLabel(job.estimatedMinutes)} • ${job.status.name}")
                Text(if (job.materialStatus == TpMaterialStatus.DELIVERED) "✓ Seryo yetkazilgan" else "Seryo kutilmoqda", color = if (job.materialStatus == TpMaterialStatus.DELIVERED) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            }
        }
        Text("O‘chishlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (stops.isEmpty()) Text("Tanlangan davrda o‘chish yozuvi yo‘q.")
        stops.forEach { stop -> TpCard {
            Text("${stop.date} • ${stop.stoppedAt}–${stop.startedAt} • ${stop.durationMinutes()} daqiqa", fontWeight = FontWeight.Bold)
            Text(stop.reason)
        } }
    }
}

@Composable
private fun TpMaterialMonitoring(data: TpData, from: String, to: String, onMaterial: (String) -> Unit) {
    val materials = data.materials.filterNot { it.archived }.sortedWith(compareBy<TpMaterial> { it.type }.thenBy { it.code })
    val shortages = activeMaterialShortages(data).toSet()
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-materials")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        val waiting = data.jobs.count { it.resinConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED && it.status != TpJobStatus.COMPLETE }
        TpCard {
            Text("${materials.size} material • $waiting tayyorlash/yetkazishda • ${shortages.size} yetishmovchilik")
        }
        materials.forEach { material ->
            val incoming = material.movements.filter { it.kind == TpMaterialMovementKind.IN && it.createdAt.take(10) in from..to }.sumOf { it.amount }
            val outgoing = material.movements.filter { it.kind == TpMaterialMovementKind.OUT && it.createdAt.take(10) in from..to }.sumOf { it.amount }
            val short = shortages.any { it.startsWith(material.code + " ") }
            TpCard(Modifier.clickable { onMaterial(material.id) }) {
                Text("${material.code} • ${if (material.type == TpMaterialType.RESIN) "Seryo" else "Krasitel"}", fontWeight = FontWeight.Bold)
                Text("Ostatka: ${formatTpNumber(material.currentStock())} ${if (material.type == TpMaterialType.RESIN) "kg" else "g"}")
                Text("Prixod: ${formatTpNumber(incoming)} • Rasxod: ${formatTpNumber(outgoing)}", style = MaterialTheme.typography.bodySmall)
                if (short) Text("⚠ Faol reja uchun yetmaydi", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun TpMaterialMonitoringDetail(data: TpData, materialId: String, from: String, to: String) {
    val material = data.materials.firstOrNull { it.id == materialId } ?: return
    val movements = material.movements.filter { it.createdAt.take(10) in from..to }.sortedByDescending { it.createdAt }
    val relatedJobs = data.jobs.filter { job ->
        job.status != TpJobStatus.COMPLETE && if (material.type == TpMaterialType.RESIN) job.resinCode.equals(material.code, true) else job.colorCode.equals(material.code, true)
    }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-material-$materialId")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("${material.code} • ${if (material.type == TpMaterialType.RESIN) "Seryo" else "Krasitel"}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        TpCard {
            Text("Hozirgi ostatka: ${formatTpNumber(material.currentStock())} ${if (material.type == TpMaterialType.RESIN) "kg" else "g"}")
            val reserved = relatedJobs.sumOf { if (material.type == TpMaterialType.RESIN) it.requiredResinKg else it.requiredColorGrams }
            Text("Faol rejalarga kerak: ${formatTpNumber(reserved)}")
            Text("Erkin hisobiy qoldiq: ${formatTpNumber(material.currentStock() - reserved)}")
        }
        Text("Qayerga kerak", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        relatedJobs.forEach { job ->
            val order = data.orders.firstOrNull { it.id == job.orderId }
            val machine = data.machines.firstOrNull { it.id == job.machineId }
            TpCard {
                Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.Bold)
                Text("${machine?.number?.let { "$it-stanok" } ?: "Stanok belgilanmagan"} • ${job.outputs.map { it.detailName }.distinct().joinToString()} • rang ${job.colorCode}")
                Text("Kerak: ${formatTpNumber(if (material.type == TpMaterialType.RESIN) job.requiredResinKg else job.requiredColorGrams)}")
            }
        }
        Text("Harakatlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (movements.isEmpty()) Text("Tanlangan davrda harakat yo‘q.")
        movements.forEach { move -> TpCard {
            Text("${if (move.kind == TpMaterialMovementKind.IN) "Prixod" else "Rasxod"}: ${formatTpNumber(move.amount)}", fontWeight = FontWeight.Bold)
            Text(move.createdAt.take(16).replace('T', ' '))
            if (move.note.isNotBlank()) Text(move.note, style = MaterialTheme.typography.bodySmall)
        } }
    }
}

private fun activeMaterialShortages(data: TpData): List<String> {
    val jobs = data.jobs.filter { it.status != TpJobStatus.COMPLETE && it.planConfirmedAt != null }
    val resinNeed = jobs.groupBy { it.resinCode }.mapValues { (_, rows) -> rows.sumOf { it.requiredResinKg } }
    val colorNeed = jobs.groupBy { it.colorCode }.mapValues { (_, rows) -> rows.sumOf { it.requiredColorGrams } }
    return buildList {
        resinNeed.forEach { (code, need) -> if (data.materialStock(TpMaterialType.RESIN, code) + 1e-9 < need) add("$code seryo") }
        colorNeed.forEach { (code, need) -> if (data.materialStock(TpMaterialType.COLOR, code) + 1e-9 < need) add("$code krasitel") }
    }
}

private fun periodDates(from: String, to: String): List<String> {
    val start = runCatching { LocalDate.parse(from) }.getOrElse { return emptyList() }
    val end = runCatching { LocalDate.parse(to) }.getOrElse { return emptyList() }
    if (end.isBefore(start)) return emptyList()
    val result = mutableListOf<String>()
    var cursor = start
    var guard = 0
    while (!cursor.isAfter(end) && guard < 370) {
        result += cursor.toString()
        cursor = cursor.plusDays(1)
        guard++
    }
    return result.reversed()
}
