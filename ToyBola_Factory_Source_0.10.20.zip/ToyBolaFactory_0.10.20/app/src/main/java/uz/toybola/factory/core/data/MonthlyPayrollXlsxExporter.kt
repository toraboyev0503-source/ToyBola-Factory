package uz.toybola.factory.core.data

import android.content.Context
import uz.toybola.factory.R
import java.io.InputStream
import java.io.OutputStream
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Writes the payroll/production workbooks from the approved TP.xlsx and Sborka.xlsx templates.
 * We deliberately edit the existing XLSX XML instead of rebuilding the workbook so borders,
 * column widths, merged cells and print-oriented formatting in the user's template are retained.
 */
object MonthlyPayrollXlsxExporter {
    private const val DETAIL_ROW_START = 3
    private const val DETAIL_ROW_END = 32
    private const val TP_SALARY_ROW_START = 3
    private const val TP_SALARY_ROW_END = 52
    private const val SBORKA_SALARY_ROW_START = 4
    private const val SBORKA_SALARY_ROW_END = 53

    fun writeTp(
        context: Context,
        output: OutputStream,
        data: TpData,
        from: String,
        to: String
    ) {
        val period = validatePeriod(from, to)
        val activeBrigades = data.brigades
            .filterNot { it.archived }
            .associateBy { it.id }
        val shiftNames = data.shifts.associate { it.id to it.name }
        val machineNames = data.machines.associate { it.id to "${it.number}-stanok" }
        val orders = data.orders.associateBy { it.id }

        data class DetailKey(
            val date: String,
            val machineId: String,
            val brigadeId: String,
            val shiftId: String,
            val orderId: String,
            val detailName: String,
            val unitPrice: Double,
            val piecesPerShot: Int
        )

        val detailRows = data.receipts
            .filter { it.brigadeId in activeBrigades && it.date in period.from..period.to }
            .groupBy {
                DetailKey(
                    it.date,
                    it.machineId,
                    it.brigadeId,
                    it.shiftId,
                    it.orderId,
                    it.detailNameSnapshot,
                    it.unitPriceSnapshot,
                    it.piecesPerShotSnapshot
                )
            }
            .map { (key, receipts) ->
                val order = orders[key.orderId]
                val brigade = activeBrigades[key.brigadeId]
                val shiftName = shiftNames[key.shiftId].orEmpty()
                listOf<XlsxCellValue>(
                    XlsxCellValue.Text(displayDate(key.date)),
                    XlsxCellValue.Text(machineNames[key.machineId].orEmpty()),
                    XlsxCellValue.Text(brigade?.name.orEmpty()),
                    XlsxCellValue.Text(shiftName),
                    XlsxCellValue.Text(order?.articleSnapshot.orEmpty()),
                    XlsxCellValue.Text(order?.productNameSnapshot.orEmpty()),
                    XlsxCellValue.Text(key.detailName),
                    XlsxCellValue.Number(receipts.sumOf { it.creditedPieces }.toString()),
                    XlsxCellValue.Number(trimNumber(key.unitPrice)),
                    XlsxCellValue.Number(receipts.sumOf { it.earnedAmount }.toString())
                )
            }
            .sortedWith(compareBy<List<XlsxCellValue>>(
                { (it[0] as XlsxCellValue.Text).value },
                { (it[2] as XlsxCellValue.Text).value },
                { (it[1] as XlsxCellValue.Text).value },
                { (it[4] as XlsxCellValue.Text).value },
                { (it[6] as XlsxCellValue.Text).value }
            ))

        val workers = data.workers
            .filter { !it.archived && it.brigadeId in activeBrigades }
            .sortedWith(
                compareBy<TpWorker> { activeBrigades[it.brigadeId]?.name?.lowercase().orEmpty() }
                    .thenBy { it.name.lowercase() }
            )
        val workerSalary = workers.associateWith { worker ->
            data.receipts
                .filter { it.workerId == worker.id && it.date in period.from..period.to }
                .sumOf { it.earnedAmount } +
                data.extraHours
                    .filter { it.workerId == worker.id && it.date in period.from..period.to }
                    .sumOf { it.amount }
        }
        val totalSalary = workerSalary.values.sum()
        val workedDays = data.attendance
            .filter { it.brigadeId in activeBrigades && it.date in period.from..period.to && it.present }
            .map { it.date }
            .distinct()
            .size

        val prices = buildList {
            data.products.filterNot { it.archived }.sortedBy { it.article.lowercase() }.forEach { product ->
                product.details.filterNot { it.archived }.sortedBy { it.name.lowercase() }.forEach { detail ->
                    add(listOf(
                        XlsxCellValue.Text(product.article),
                        XlsxCellValue.Text(product.name),
                        XlsxCellValue.Text(detail.name),
                        XlsxCellValue.Number(trimNumber(detail.unitPrice))
                    ))
                }
            }
        }

        val salaryRows = workers.map { worker -> worker.name to workerSalary.getValue(worker) }

        context.resources.openRawResource(R.raw.tp_monthly_template).use { template ->
            rewriteTemplate(
                template = template,
                output = output,
                transforms = mapOf(
                    "xl/worksheets/sheet1.xml" to { xml ->
                        patchDetailSheet(
                            source = xml,
                            title = "Barcha brigadalar",
                            rows = detailRows,
                            columns = listOf("A", "B", "C", "D", "E", "F", "G", "H", "I", "J"),
                            summaryValueColumn = "J",
                            totalSalary = totalSalary,
                            workedDays = workedDays
                        )
                    },
                    "xl/worksheets/sheet2.xml" to { xml ->
                        patchDynamicTable(xml, prices, templateRow = 2, columns = listOf("A", "B", "C", "D"))
                    },
                    "xl/worksheets/sheet3.xml" to { xml ->
                        patchTpSalarySheet(xml, period.label, salaryRows, totalSalary)
                    }
                )
            )
        }
    }

    fun writeSborka(
        context: Context,
        output: OutputStream,
        data: AssemblyData,
        from: String,
        to: String
    ) {
        val period = validatePeriod(from, to)
        val brigades = data.brigades.filter { !it.archived && !it.deleted }.sortedBy { it.name.lowercase() }
        require(brigades.size <= 4) { "Sborka shabloni 4 ta brigada uchun. Hozir ${brigades.size} ta faol brigada ko‘rinmoqda." }

        val transforms = mutableMapOf<String, (String) -> String>()
        val totalByBrigade = mutableMapOf<String, Long>()

        brigades.forEachIndexed { index, brigade ->
            data class RowKey(val date: String, val article: String, val product: String, val unitPrice: Long)
            val rows = data.workerDays
                .filter { it.brigadeId == brigade.id && it.date in period.from..period.to && it.worked }
                .flatMap { day -> day.entries.map { entry -> day.date to entry } }
                .groupBy { (date, entry) -> RowKey(date, entry.articleSnapshot, entry.productNameSnapshot, entry.unitPriceSnapshot) }
                .map { (key, entries) ->
                    listOf<XlsxCellValue>(
                        XlsxCellValue.Text(displayDate(key.date)),
                        XlsxCellValue.Text(key.article),
                        XlsxCellValue.Text(key.product),
                        XlsxCellValue.Number(trimNumber(entries.sumOf { it.second.quantity })),
                        XlsxCellValue.Number(key.unitPrice.toString()),
                        XlsxCellValue.Number(entries.sumOf { it.second.amount }.toString())
                    )
                }
                .sortedWith(compareBy<List<XlsxCellValue>>(
                    { (it[0] as XlsxCellValue.Text).value },
                    { (it[1] as XlsxCellValue.Text).value },
                    { (it[2] as XlsxCellValue.Text).value }
                ))


            val salary = data.workerDays
                .filter { it.brigadeId == brigade.id && it.date in period.from..period.to && it.worked }
                .sumOf { it.earned }
            totalByBrigade[brigade.id] = salary
            val workedDays = data.brigadeDays
                .filter { it.brigadeId == brigade.id && it.date in period.from..period.to && it.worked }
                .map { it.date }
                .distinct()
                .ifEmpty {
                    data.workerDays.filter { it.brigadeId == brigade.id && it.date in period.from..period.to && it.worked }
                        .map { it.date }.distinct()
                }
                .size

            transforms["xl/worksheets/sheet${index + 1}.xml"] = { xml ->
                patchDetailSheet(
                    source = xml,
                    title = brigade.name,
                    rows = rows,
                    columns = listOf("A", "B", "C", "D", "E", "F"),
                    summaryValueColumn = "F",
                    totalSalary = salary,
                    workedDays = workedDays
                )
            }
        }

        // If fewer than four brigades are visible to the current policy, blank the unused brigade sheets.
        for (index in brigades.size until 4) {
            val values = mutableMapOf<String, XlsxCellValue>("A1" to XlsxCellValue.Text(""), "F33" to XlsxCellValue.Text(""), "F34" to XlsxCellValue.Text(""))
            clearRange(values, DETAIL_ROW_START, DETAIL_ROW_END, listOf("A", "B", "C", "D", "E", "F"))
            transforms["xl/worksheets/sheet${index + 1}.xml"] = { xml -> patchCells(xml, values) }
        }

        val priceRows = data.products.filterNot { it.archived }.sortedWith(compareBy<Product> { it.article.lowercase() }.thenBy { it.name.lowercase() }).map { product ->
            listOf<XlsxCellValue>(
                XlsxCellValue.Text(product.article),
                XlsxCellValue.Text(product.name),
                XlsxCellValue.Number(product.priceAt(period.to).toString())
            )
        }
        transforms["xl/worksheets/sheet5.xml"] = { xml -> patchDynamicTable(xml, priceRows, templateRow = 2, columns = listOf("A", "B", "C")) }

        val salaryValues = mutableMapOf<String, XlsxCellValue>()
        salaryValues["A1"] = XlsxCellValue.Text("${period.label}yil.")
        val groupStartColumns = listOf("A", "D", "G", "J")
        val nameColumns = listOf("B", "E", "H", "K")
        val salaryColumns = listOf("C", "F", "I", "L")

        for (group in 0 until 4) {
            val brigade = brigades.getOrNull(group)
            salaryValues["${groupStartColumns[group]}2"] = XlsxCellValue.Text(brigade?.name.orEmpty())
            clearRange(salaryValues, SBORKA_SALARY_ROW_START, SBORKA_SALARY_ROW_END, listOf(groupStartColumns[group], nameColumns[group], salaryColumns[group]))
            if (brigade != null) {
                val workers = data.workers.filter { !it.archived && it.brigadeId == brigade.id }.sortedBy { it.name.lowercase() }
                require(workers.size <= SBORKA_SALARY_ROW_END - SBORKA_SALARY_ROW_START + 1) {
                    "${brigade.name} brigadasida 50 tadan ko‘p ishchi bor."
                }
                workers.forEachIndexed { index, worker ->
                    val r = SBORKA_SALARY_ROW_START + index
                    val salary = data.workerDays.filter { it.workerId == worker.id && it.date in period.from..period.to && it.worked }.sumOf { it.earned }
                    salaryValues["${groupStartColumns[group]}$r"] = XlsxCellValue.Number((index + 1).toString())
                    salaryValues["${nameColumns[group]}$r"] = XlsxCellValue.Text(worker.name)
                    salaryValues["${salaryColumns[group]}$r"] = XlsxCellValue.Number(salary.toString())
                }
                salaryValues["${salaryColumns[group]}54"] = XlsxCellValue.Number(totalByBrigade[brigade.id].orEmptyLong().toString())
            } else {
                salaryValues["${salaryColumns[group]}54"] = XlsxCellValue.Text("")
            }
        }
        salaryValues["L58"] = XlsxCellValue.Number(totalByBrigade.values.sum().toString())
        transforms["xl/worksheets/sheet6.xml"] = { xml -> patchCells(xml, salaryValues) }

        context.resources.openRawResource(R.raw.sborka_monthly_template).use { template ->
            rewriteTemplate(template, output, transforms)
        }
    }

    fun periodForHalf(year: Int, month: Int, secondHalf: Boolean): Pair<String, String> {
        val ym = java.time.YearMonth.of(year, month)
        val start = if (secondHalf) ym.atDay(16) else ym.atDay(1)
        val end = if (secondHalf) ym.atEndOfMonth() else ym.atDay(15)
        return start.toString() to end.toString()
    }

    private data class Period(val from: String, val to: String, val label: String)

    private fun validatePeriod(from: String, to: String): Period {
        val start = runCatching { LocalDate.parse(from) }.getOrNull() ?: error("Boshlanish sanasi noto‘g‘ri")
        val end = runCatching { LocalDate.parse(to) }.getOrNull() ?: error("Tugash sanasi noto‘g‘ri")
        require(!end.isBefore(start)) { "Tugash sanasi boshlanish sanasidan oldin bo‘lmasin" }
        require(start.year == end.year && start.month == end.month) { "Excel davri bitta oy ichida bo‘lsin" }
        return Period(start.toString(), end.toString(), "${start.dayOfMonth}-${end.dayOfMonth}.${start.monthValue.toString().padStart(2, '0')}.${start.year}")
    }

    private fun displayDate(iso: String): String = runCatching {
        LocalDate.parse(iso).format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
    }.getOrDefault(iso)

    private sealed interface XlsxCellValue {
        data class Text(val value: String) : XlsxCellValue
        data class Number(val value: String) : XlsxCellValue
    }

    private fun clearRange(target: MutableMap<String, XlsxCellValue>, start: Int, end: Int, columns: List<String>) {
        for (row in start..end) columns.forEach { column -> target["$column$row"] = XlsxCellValue.Text("") }
    }

    private fun rewriteTemplate(
        template: InputStream,
        output: OutputStream,
        transforms: Map<String, (String) -> String>
    ) {
        ZipInputStream(template.buffered()).use { zin ->
            ZipOutputStream(output.buffered()).use { zout ->
                var entry = zin.nextEntry
                while (entry != null) {
                    val bytes = zin.readBytes()
                    val transformed = transforms[entry.name]?.invoke(bytes.toString(Charsets.UTF_8))?.toByteArray(Charsets.UTF_8) ?: bytes
                    val outEntry = ZipEntry(entry.name).apply { time = entry.time }
                    zout.putNextEntry(outEntry)
                    zout.write(transformed)
                    zout.closeEntry()
                    zin.closeEntry()
                    entry = zin.nextEntry
                }
            }
        }
    }

    private fun patchTpSalarySheet(
        source: String,
        periodLabel: String,
        workers: List<Pair<String, Long>>,
        totalSalary: Long
    ): String {
        val baseCapacity = TP_SALARY_ROW_END - TP_SALARY_ROW_START + 1
        val extraRows = (workers.size - baseCapacity).coerceAtLeast(0)
        var xml = source
        var totalRow = TP_SALARY_ROW_END + 1

        if (extraRows > 0) {
            val standardTemplate = rowXml(xml, TP_SALARY_ROW_END - 1)
                ?: error("TP Maosh shablonida standart ishchi qatori topilmadi")
            val bottomTemplate = rowXml(xml, TP_SALARY_ROW_END)
                ?: error("TP Maosh shablonida oxirgi ishchi qatori topilmadi")

            xml = shiftRowsAndMerges(xml, startRow = totalRow, delta = extraRows)
            xml = replaceRow(
                xml,
                TP_SALARY_ROW_END,
                cloneRow(standardTemplate, TP_SALARY_ROW_END - 1, TP_SALARY_ROW_END)
            )

            val additions = buildString {
                if (extraRows > 1) {
                    for (row in TP_SALARY_ROW_END + 1 until TP_SALARY_ROW_END + extraRows) {
                        append(cloneRow(standardTemplate, TP_SALARY_ROW_END - 1, row))
                    }
                }
                append(cloneRow(bottomTemplate, TP_SALARY_ROW_END, TP_SALARY_ROW_END + extraRows))
            }
            val lastBaseWorkerRow = rowXml(xml, TP_SALARY_ROW_END)
                ?: error("TP Maosh shablonini kengaytirib bo‘lmadi")
            xml = xml.replace(lastBaseWorkerRow, lastBaseWorkerRow + additions)
            totalRow += extraRows
            xml = updateDimensionLastRow(xml, totalRow)
        }

        val values = mutableMapOf<String, XlsxCellValue>()
        values["A1"] = XlsxCellValue.Text("Sana: $periodLabel")
        val lastWorkerRow = maxOf(TP_SALARY_ROW_END, TP_SALARY_ROW_START + workers.size - 1)
        clearRange(values, TP_SALARY_ROW_START, lastWorkerRow, listOf("A", "B", "C"))
        workers.forEachIndexed { index, (name, salary) ->
            val row = TP_SALARY_ROW_START + index
            values["A$row"] = XlsxCellValue.Number((index + 1).toString())
            values["B$row"] = XlsxCellValue.Text(name)
            values["C$row"] = XlsxCellValue.Number(salary.toString())
        }
        values["C$totalRow"] = XlsxCellValue.Number(totalSalary.toString())
        return patchCells(xml, values)
    }

    private fun patchDetailSheet(
        source: String,
        title: String,
        rows: List<List<XlsxCellValue>>,
        columns: List<String>,
        summaryValueColumn: String,
        totalSalary: Long,
        workedDays: Int
    ): String {
        val baseCapacity = DETAIL_ROW_END - DETAIL_ROW_START + 1
        val extraRows = (rows.size - baseCapacity).coerceAtLeast(0)
        var xml = source
        var summaryRow = 33

        if (extraRows > 0) {
            val standardTemplate = rowXml(xml, 31) ?: error("Excel shablonida 31-qator topilmadi")
            val bottomTemplate = rowXml(xml, 32) ?: error("Excel shablonida 32-qator topilmadi")

            // Move summary rows and their merged cells down before inserting additional data rows.
            xml = shiftRowsAndMerges(xml, startRow = 33, delta = extraRows)

            // Row 32 used to be the bottom-border row. It becomes a normal middle row when expanding.
            xml = replaceRow(xml, 32, cloneRow(standardTemplate, 31, 32))
            val additions = buildString {
                if (extraRows > 1) {
                    for (row in 33 until 32 + extraRows) append(cloneRow(standardTemplate, 31, row))
                }
                append(cloneRow(bottomTemplate, 32, 32 + extraRows))
            }
            val row32 = rowXml(xml, 32) ?: error("Excel shablonida 32-qatorni kengaytirib bo‘lmadi")
            xml = xml.replace(row32, row32 + additions)
            summaryRow += extraRows
            xml = updateDimensionLastRow(xml, summaryRow + 1)
        }

        val values = mutableMapOf<String, XlsxCellValue>()
        values["A1"] = XlsxCellValue.Text(title)
        val lastDataRow = maxOf(DETAIL_ROW_END, DETAIL_ROW_START + rows.size - 1)
        clearRange(values, DETAIL_ROW_START, lastDataRow, columns)
        rows.forEachIndexed { index, row ->
            val r = DETAIL_ROW_START + index
            columns.forEachIndexed { columnIndex, column ->
                values["$column$r"] = row.getOrElse(columnIndex) { XlsxCellValue.Text("") }
            }
        }
        values["$summaryValueColumn$summaryRow"] = XlsxCellValue.Number(totalSalary.toString())
        values["$summaryValueColumn${summaryRow + 1}"] = XlsxCellValue.Number(workedDays.toString())
        return patchCells(xml, values)
    }

    private fun rowXml(source: String, row: Int): String? =
        Regex("<row\\b[^>]*\\br=\"$row\"[^>]*>.*?</row>", setOf(RegexOption.DOT_MATCHES_ALL)).find(source)?.value

    private fun replaceRow(source: String, row: Int, replacement: String): String {
        val old = rowXml(source, row) ?: return source
        return source.replace(old, replacement)
    }

    private fun cloneRow(template: String, fromRow: Int, toRow: Int): String {
        var result = Regex("(<row\\b[^>]*\\br=\")$fromRow(\")").replace(template) { m ->
            "${m.groupValues[1]}$toRow${m.groupValues[2]}"
        }
        result = Regex("([A-Z]+)$fromRow(?=\")").replace(result) { m -> "${m.groupValues[1]}$toRow" }
        return result
    }

    private fun shiftRowsAndMerges(source: String, startRow: Int, delta: Int): String {
        if (delta <= 0) return source
        var result = source
        val rows = Regex("<row\\b[^>]*\\br=\"(\\d+)\"[^>]*>.*?</row>", setOf(RegexOption.DOT_MATCHES_ALL))
            .findAll(source)
            .mapNotNull { it.groupValues[1].toIntOrNull() }
            .filter { it >= startRow }
            .distinct()
            .sortedDescending()
        rows.forEach { row ->
            val old = rowXml(result, row) ?: return@forEach
            result = result.replace(old, cloneRow(old, row, row + delta))
        }
        val mergeRegex = Regex("<mergeCell ref=\"([A-Z]+)(\\d+):([A-Z]+)(\\d+)\"/>")
        result = mergeRegex.replace(result) { m ->
            val r1 = m.groupValues[2].toInt()
            val r2 = m.groupValues[4].toInt()
            val n1 = if (r1 >= startRow) r1 + delta else r1
            val n2 = if (r2 >= startRow) r2 + delta else r2
            "<mergeCell ref=\"${m.groupValues[1]}$n1:${m.groupValues[3]}$n2\"/>"
        }
        return result
    }

    private fun updateDimensionLastRow(source: String, lastRow: Int): String {
        val dimension = Regex("(<dimension\\s+ref=\"[A-Z]+1:[A-Z]+)(\\d+)(\"/>)")
        return dimension.replace(source) { m -> "${m.groupValues[1]}$lastRow${m.groupValues[3]}" }
    }

    private fun patchDynamicTable(
        source: String,
        rows: List<List<XlsxCellValue>>,
        templateRow: Int,
        columns: List<String>
    ): String {
        val neededLastRow = (templateRow + rows.size - 1).coerceAtLeast(templateRow)
        var xml = ensureRows(source, templateRow, neededLastRow)
        val values = mutableMapOf<String, XlsxCellValue>()
        // Clear the template row when the dataset is empty, and write all generated rows otherwise.
        columns.forEach { values["$it$templateRow"] = XlsxCellValue.Text("") }
        rows.forEachIndexed { index, row ->
            val r = templateRow + index
            columns.forEachIndexed { columnIndex, column -> values["$column$r"] = row.getOrElse(columnIndex) { XlsxCellValue.Text("") } }
        }
        xml = patchCells(xml, values)
        return xml
    }

    private fun ensureRows(source: String, templateRow: Int, lastRow: Int): String {
        if (lastRow <= templateRow) return source
        val rowRegex = Regex("<row\\b[^>]*\\br=\"$templateRow\"[^>]*>.*?</row>", setOf(RegexOption.DOT_MATCHES_ALL))
        val template = rowRegex.find(source)?.value ?: return source
        val existingRows = Regex("<row\\b[^>]*\\br=\"(\\d+)\"").findAll(source).mapNotNull { it.groupValues[1].toIntOrNull() }.toSet()
        val clones = buildString {
            for (row in templateRow + 1..lastRow) {
                if (row in existingRows) continue
                var clone = Regex("(<row\\b[^>]*\\br=\")$templateRow(\")").replace(template) { m -> "${m.groupValues[1]}$row${m.groupValues[2]}" }
                clone = Regex("([A-Z]+)$templateRow(?=\")").replace(clone) { m -> "${m.groupValues[1]}$row" }
                append(clone)
            }
        }
        if (clones.isBlank()) return source
        var result = source.replace("</sheetData>", "$clones</sheetData>")
        val dimension = Regex("(<dimension\\s+ref=\"[A-Z]+1:[A-Z]+)(\\d+)(\"/>)")
        result = dimension.replace(result) { match ->
            val old = match.groupValues[2].toIntOrNull() ?: lastRow
            "${match.groupValues[1]}${maxOf(old, lastRow)}${match.groupValues[3]}"
        }
        return result
    }

    private fun patchCells(source: String, values: Map<String, XlsxCellValue>): String {
        var result = source
        values.forEach { (ref, value) ->
            val cellRegex = Regex(
                "<c\\b([^>]*\\br=\"${Regex.escape(ref)}\"[^>/]*)\\s*(?:/>|>.*?</c>)",
                setOf(RegexOption.DOT_MATCHES_ALL)
            )
            val match = cellRegex.find(result) ?: return@forEach
            var attrs = match.groupValues[1]
            attrs = attrs.replace(Regex("\\s+t=\"[^\"]*\""), "")
            val replacement = when (value) {
                is XlsxCellValue.Text -> "<c$attrs t=\"inlineStr\"><is><t xml:space=\"preserve\">${xmlEscape(value.value)}</t></is></c>"
                is XlsxCellValue.Number -> "<c$attrs><v>${xmlEscape(value.value)}</v></c>"
            }
            result = result.replaceRange(match.range, replacement)
        }
        return result
    }

    private fun trimNumber(value: Double): String = if (value.isFinite()) {
        java.math.BigDecimal.valueOf(value).stripTrailingZeros().toPlainString()
    } else "0"

    private fun xmlEscape(value: String): String = buildString(value.length + 16) {
        value.forEach { ch ->
            append(when (ch) {
                '&' -> "&amp;"
                '<' -> "&lt;"
                '>' -> "&gt;"
                '"' -> "&quot;"
                '\'' -> "&apos;"
                else -> ch
            })
        }
    }

    private fun Long?.orEmptyLong(): Long = this ?: 0L
}
