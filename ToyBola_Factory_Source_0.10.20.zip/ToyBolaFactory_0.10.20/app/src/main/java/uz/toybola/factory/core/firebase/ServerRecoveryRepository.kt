package uz.toybola.factory.core.firebase

import android.content.Context
import com.google.firebase.functions.FirebaseFunctions
import uz.toybola.factory.core.data.AssemblyData
import uz.toybola.factory.core.data.AssemblyDataRepository
import java.security.MessageDigest

data class ServerRecoveryResult(
    val recoveryId: String,
    val totalWritten: Int,
    val counts: Map<String, Int>
)

/**
 * Admin-only one-time legacy-local -> server recovery bridge.
 *
 * IMPORTANT: recovery data is NOT written with the Android Firestore client. The callable
 * verifies the signed-in Admin on the server and writes normalized documents with Admin SDK.
 * This intentionally bypasses client Security Rules only for this audited migration endpoint.
 */
class ServerRecoveryRepository(context: Context) {
    private val repository = AssemblyDataRepository(context.applicationContext)
    private val functions = FirebaseFunctions.getInstance("europe-west1")

    suspend fun uploadAll(data: AssemblyData): Result<ServerRecoveryResult> = runCatching {
        val payload = repository.encodeForSync(data)
        val bytes = payload.toByteArray(Charsets.UTF_8)
        require(bytes.size <= MAX_PAYLOAD_BYTES) {
            "Backup juda katta (${bytes.size / 1024} KB). Uni bo‘lib tiklash kerak."
        }
        val response = functions.getHttpsCallable("adminRestoreAssemblyBackup")
            .call(
                mapOf(
                    "payload" to payload,
                    "payloadSha256" to sha256(payload),
                    "clientVersion" to "0.10.20"
                )
            )
            .awaitResult()
        val root = response.data as? Map<*, *> ?: error("Server tiklash javobi noto‘g‘ri")
        val counts = (root["counts"] as? Map<*, *>).orEmpty().mapNotNull { (k, v) ->
            val key = k?.toString() ?: return@mapNotNull null
            key to ((v as? Number)?.toInt() ?: 0)
        }.toMap()
        ServerRecoveryResult(
            recoveryId = root["recoveryId"]?.toString().orEmpty(),
            totalWritten = (root["totalWritten"] as? Number)?.toInt() ?: counts.values.sum(),
            counts = counts
        )
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it.toInt() and 0xff) }

    companion object {
        // Callable payloads have an upstream request limit. Keep headroom for JSON wrapping/auth.
        private const val MAX_PAYLOAD_BYTES = 7 * 1024 * 1024
    }
}
