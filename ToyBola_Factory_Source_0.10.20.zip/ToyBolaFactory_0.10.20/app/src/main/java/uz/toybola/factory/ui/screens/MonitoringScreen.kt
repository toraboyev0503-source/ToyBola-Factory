package uz.toybola.factory.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.AssemblyDataEvents
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import kotlin.math.roundToLong

private enum class IssueExportScope { DAY, MONTH, YEAR }

enum class MonitoringPage { WORKERS, BRIGADIRS, QUALITY, ISSUES }

private data class WorkerMetric(
    val worker: Worker,
    val brigade: Brigade,
    val day: WorkerDay,
    val quality: Double?,
    val efficiency: Double?,
    val final: Double?
)

private data class MonitoringReportRequest(
    val fileName: String,
    val title: String,
    val metadata: List<String>,
    val headers: List<String>,
    val rows: List<List<String>>
)

@Composable
fun MonitoringScreen(
    strings: AppStrings,
    repository: AssemblyDataRepository,
    onBack: () -> Unit,
    isAdmin: Boolean = false
) {
    var revision by remember { mutableIntStateOf(0) }
    val serverRevision by AssemblyDataEvents.revision.collectAsState()
    val context = LocalContext.current
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(revision, serverRevision, policy.revision) { repository.load().scopedFor(policy) }
    val today = remember { LocalDate.now() }
    val allYears = remember(data, today) {
        val dates = buildList {
            addAll(data.workerDays.map { it.date })
            addAll(data.qualityRounds.map { it.date })
            addAll(data.dailyIssues.map { it.date })
            addAll(data.brigadeDays.map { it.date })
        }.mapNotNull { runCatching { LocalDate.parse(it).year }.getOrNull() }
        (dates + today.year).distinct().sortedDescending()
    }
    var page by remember { mutableStateOf(MonitoringPage.WORKERS) }
    var year by remember { mutableIntStateOf(today.year) }
    var month by remember { mutableIntStateOf(today.monthValue) }
    var day by remember { mutableIntStateOf(today.dayOfMonth) }
    val brigades = data.brigades.filter { !it.archived && !it.deleted }.sortedBy { it.name.lowercase() }
    var brigadeId by remember { mutableStateOf("") } // empty = all
    var yearMenu by remember { mutableStateOf(false) }
    var brigadeMenu by remember { mutableStateOf(false) }
    var reopenTarget by remember { mutableStateOf<Pair<Brigade, BrigadeDay>?>(null) }
    var reopenReason by remember { mutableStateOf("") }
    var reopenMessage by remember { mutableStateOf<String?>(null) }

    var exportScope by remember { mutableStateOf<IssueExportScope?>(null) }
    var exportMessage by remember { mutableStateOf<String?>(null) }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) { uri ->
        val scope = exportScope
        if (uri != null && scope != null) {
            val selectedDate = safeSelectedDate(year, month, day)
            val issues = when (scope) {
                IssueExportScope.DAY -> data.dailyIssues.filter { it.date == selectedDate.toString() }
                IssueExportScope.MONTH -> data.dailyIssues.filter { runCatching { YearMonth.from(LocalDate.parse(it.date)) }.getOrNull() == YearMonth.of(year, month) }
                IssueExportScope.YEAR -> data.dailyIssues.filter { runCatching { LocalDate.parse(it.date).year }.getOrNull() == year }
            }.filter { brigadeId.isBlank() || it.brigadeId == brigadeId }
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    DailyIssueDocxExporter.write(
                        output = out,
                        title = issueExportTitle(scope, selectedDate, year, month),
                        issues = issues,
                        brigadeNames = data.brigades.associate { it.id to it.name }
                    )
                } ?: error("Output stream")
            }.onSuccess { exportMessage = strings.exportSuccess }.onFailure { exportMessage = strings.exportFailed }
        }
        exportScope = null
    }

    var reportRequest by remember { mutableStateOf<MonitoringReportRequest?>(null) }
    val reportExporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) { uri ->
        val request = reportRequest
        if (uri != null && request != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    MonitoringDocxExporter.write(
                        output = out,
                        title = request.title,
                        metadata = request.metadata,
                        headers = request.headers,
                        rows = request.rows
                    )
                } ?: error("Output stream")
            }.onSuccess { exportMessage = strings.exportSuccess }.onFailure { exportMessage = strings.exportFailed }
        }
        reportRequest = null
    }

    var payrollPeriod by remember { mutableStateOf<Pair<String, String>?>(null) }
    val payrollExporter = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri ->
        val period = payrollPeriod
        if (uri != null && period != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    MonthlyPayrollXlsxExporter.writeSborka(context, out, data, period.first, period.second)
                } ?: error("Excel faylini ochib bo‘lmadi")
            }.onSuccess { exportMessage = "Excel saqlandi" }
                .onFailure { exportMessage = it.message ?: "Excel saqlanmadi" }
        }
        payrollPeriod = null
    }

    fun exportPayroll(secondHalf: Boolean) {
        val period = MonthlyPayrollXlsxExporter.periodForHalf(year, month, secondHalf)
        payrollPeriod = period
        val part = if (secondHalf) "16-oxiri" else "1-15"
        exportMessage = null
        payrollExporter.launch("Sborka_Maosh_${year}-${month.toString().padStart(2, '0')}_$part.xlsx")
    }

    fun exportReport(request: MonitoringReportRequest) {
        reportRequest = request
        reportExporter.launch(request.fileName)
    }

    fun export(scope: IssueExportScope) {
        exportScope = scope
        val selectedDate = safeSelectedDate(year, month, day)
        val name = when (scope) {
            IssueExportScope.DAY -> "ToyBola_Kun_muammolari_${selectedDate}.docx"
            IssueExportScope.MONTH -> "ToyBola_Muammolar_${year}-${month.toString().padStart(2, '0')}.docx"
            IssueExportScope.YEAR -> "ToyBola_Muammolar_${year}.docx"
        }
        exporter.launch(name)
    }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(strings.monitoring, canGoBack = true, onMenu = {}, onBack = onBack)
        Column(
            Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("MonitoringScreen-screen-1")).navigationBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MonitoringModeButton(strings.monitorWorkers, page == MonitoringPage.WORKERS, Modifier.weight(1f)) { page = MonitoringPage.WORKERS }
                MonitoringModeButton(strings.monitorBrigadirs, page == MonitoringPage.BRIGADIRS, Modifier.weight(1f)) { page = MonitoringPage.BRIGADIRS }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MonitoringModeButton(strings.monitorQualityStaff, page == MonitoringPage.QUALITY, Modifier.weight(1f)) { page = MonitoringPage.QUALITY }
                MonitoringModeButton(strings.problemProducts, page == MonitoringPage.ISSUES, Modifier.weight(1f)) { page = MonitoringPage.ISSUES }
            }

            val metricKind = page.toMetricKind()
            val yearMetric = data.monitoringMetric(
                metricKind,
                LocalDate.of(year, 1, 1),
                LocalDate.of(year, 12, 31),
                brigadeId
            )

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) {
                    OutlinedButton(onClick = { yearMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("$year • ${metricText(yearMetric, strings)}")
                    }
                    DropdownMenu(expanded = yearMenu, onDismissRequest = { yearMenu = false }) {
                        allYears.forEach { y ->
                            DropdownMenuItem(text = { Text(y.toString()) }, onClick = {
                                year = y; yearMenu = false
                                if (year != today.year && month == today.monthValue) day = 1
                            })
                        }
                        DropdownMenuItem(text = { Text("${today.year + 1} — ${strings.notActiveYet}") }, enabled = false, onClick = {})
                    }
                }
                Box(Modifier.weight(1f)) {
                    val selected = brigades.firstOrNull { it.id == brigadeId }
                    OutlinedButton(onClick = { brigadeMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(selected?.name ?: strings.allBrigades)
                    }
                    DropdownMenu(expanded = brigadeMenu, onDismissRequest = { brigadeMenu = false }) {
                        DropdownMenuItem(text = { Text(strings.allBrigades) }, onClick = { brigadeId = ""; brigadeMenu = false })
                        brigades.forEach { b -> DropdownMenuItem(text = { Text(b.name) }, onClick = { brigadeId = b.id; brigadeMenu = false }) }
                    }
                }
            }

            MonthGrid(strings, data, metricKind, year, month, brigadeId, onMonth = { m ->
                month = m
                day = if (year == today.year && m == today.monthValue) today.dayOfMonth else 1
            })

            Text("Oylik Excel", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Shablon: Sborka.xlsx • tanlangan oy uchun ikki yopilish davri.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { exportPayroll(false) }, modifier = Modifier.weight(1f)) { Text("1–15 Excel") }
                OutlinedButton(onClick = { exportPayroll(true) }, modifier = Modifier.weight(1f)) { Text("16–oy oxiri Excel") }
            }
            if (!exportMessage.isNullOrBlank() && (exportMessage!!.contains("Excel", true) || exportMessage!!.contains("qator", true) || exportMessage!!.contains("brigada", true))) {
                Text(exportMessage!!, color = if (exportMessage!!.contains("saqlandi", true)) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            }

            val selectedDateText = safeSelectedDate(year, month, day).toString()
            val closedForSelectedDate = if (isAdmin) {
                brigades.mapNotNull { brigade ->
                    if (brigadeId.isNotBlank() && brigade.id != brigadeId) return@mapNotNull null
                    data.brigadeDay(brigade.id, selectedDateText)
                        ?.takeIf { it.fullyClosed }
                        ?.let { brigade to it }
                }
            } else emptyList()

            DayCalendar(
                strings, metricKind, year, month, day, data, brigadeId,
                onDay = { selectedDay ->
                    day = selectedDay
                    if (isAdmin) {
                        val clickedDate = LocalDate.of(year, month, selectedDay).toString()
                        val closed = brigades.mapNotNull { brigade ->
                            if (brigadeId.isNotBlank() && brigade.id != brigadeId) return@mapNotNull null
                            data.brigadeDay(brigade.id, clickedDate)
                                ?.takeIf { it.fullyClosed }
                                ?.let { brigade to it }
                        }
                        if (closed.size == 1) {
                            reopenReason = ""
                            reopenMessage = null
                            reopenTarget = closed.first()
                        }
                    }
                }
            )

            if (isAdmin && closedForSelectedDate.isNotEmpty()) {
                Text(strings.closedDays, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                closedForSelectedDate.forEach { pair ->
                    val brigade = pair.first
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable {
                            reopenReason = ""
                            reopenMessage = null
                            reopenTarget = pair
                        },
                        shape = RoundedCornerShape(12.dp),
                        tonalElevation = 1.dp
                    ) {
                        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(brigade.name, fontWeight = FontWeight.SemiBold)
                                Text(selectedDateText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(strings.reopenDay, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            if (!reopenMessage.isNullOrBlank()) {
                Text(reopenMessage!!, color = MaterialTheme.colorScheme.primary)
            }

            when (page) {
                MonitoringPage.WORKERS -> WorkerMonitoring(strings, data, year, month, day, brigadeId, onExportReport = { exportReport(it) }, exportMessage = exportMessage)
                MonitoringPage.BRIGADIRS -> BrigadirMonitoring(strings, data, year, month, brigadeId, onExportReport = { exportReport(it) }, exportMessage = exportMessage)
                MonitoringPage.QUALITY -> QualityStaffMonitoring(strings, data, year, month, brigadeId, onExportReport = { exportReport(it) }, exportMessage = exportMessage)
                MonitoringPage.ISSUES -> IssueMonitoring(strings, data, year, month, day, brigadeId, onExport = ::export, exportMessage = exportMessage)
            }
        }
    }

    reopenTarget?.let { (brigade, closedDay) ->
        AlertDialog(
            onDismissRequest = { reopenTarget = null; reopenReason = "" },
            title = { Text(strings.reopenDay) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("${brigade.name} • ${closedDay.date}", fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = reopenReason,
                        onValueChange = { reopenReason = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(strings.reopenReason) },
                        minLines = 3
                    )
                    if (!reopenMessage.isNullOrBlank()) {
                        Text(reopenMessage!!, color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = reopenReason.isNotBlank(),
                    onClick = {
                        val result = repository.reopenDay(brigade.id, closedDay.date, reopenReason)
                        reopenMessage = result.fold(
                            onSuccess = { strings.dayReopened },
                            onFailure = { it.message ?: strings.required }
                        )
                        if (result.isSuccess) {
                            revision++
                            reopenTarget = null
                            reopenReason = ""
                        }
                    }
                ) { Text(strings.reopenDay) }
            },
            dismissButton = { TextButton(onClick = { reopenTarget = null; reopenReason = "" }) { Text(strings.cancel) } }
        )
    }
}

@Composable
private fun MonitoringModeButton(text: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    if (selected) Button(onClick = onClick, modifier = modifier) { Text(text) }
    else OutlinedButton(onClick = onClick, modifier = modifier) { Text(text) }
}

@Composable
private fun MonthGrid(
    strings: AppStrings,
    data: AssemblyData,
    kind: MonitoringMetricKind,
    year: Int,
    selectedMonth: Int,
    brigadeId: String,
    onMonth: (Int) -> Unit
) {
    Text(strings.months, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    (1..12).chunked(4).forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            row.forEach { m ->
                val ym = YearMonth.of(year, m)
                val metric = data.monitoringMetric(kind, ym.atDay(1), ym.atEndOfMonth(), brigadeId)
                val selected = selectedMonth == m
                Surface(
                    modifier = Modifier.weight(1f).clickable { onMonth(m) },
                    shape = RoundedCornerShape(10.dp),
                    color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .45f)
                ) {
                    Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(monthShort(m), fontWeight = FontWeight.SemiBold)
                        Text(metricText(metric, strings), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        (0..3).forEach { q ->
            val startMonth = q * 3 + 1
            val start = LocalDate.of(year, startMonth, 1)
            val end = YearMonth.of(year, startMonth + 2).atEndOfMonth()
            val metric = data.monitoringMetric(kind, start, end, brigadeId)
            Surface(Modifier.weight(1f), shape = RoundedCornerShape(8.dp), tonalElevation = 1.dp) {
                Column(Modifier.padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Q${q + 1}", fontWeight = FontWeight.SemiBold)
                    Text(metricText(metric, strings), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun DayCalendar(
    strings: AppStrings,
    kind: MonitoringMetricKind,
    year: Int,
    month: Int,
    selectedDay: Int,
    data: AssemblyData,
    brigadeId: String,
    onDay: (Int) -> Unit
) {
    val ym = YearMonth.of(year, month)
    val offset = ym.atDay(1).dayOfWeek.value - 1
    val cells = buildList<Int?> {
        repeat(offset) { add(null) }
        for (d in 1..ym.lengthOfMonth()) add(d)
        while (size % 7 != 0) add(null)
    }
    listOf("Du", "Se", "Cho", "Pa", "Ju", "Sha", "Ya").let { names ->
        Row(Modifier.fillMaxWidth()) { names.forEach { Text(it, Modifier.weight(1f), style = MaterialTheme.typography.labelSmall) } }
    }
    cells.chunked(7).forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            row.forEach { d ->
                if (d == null) Spacer(Modifier.weight(1f).height(52.dp)) else {
                    val date = LocalDate.of(year, month, d)
                    val metric = data.monitoringMetric(kind, date, date, brigadeId)
                    Surface(
                        modifier = Modifier.weight(1f).height(52.dp).clickable { onDay(d) },
                        shape = RoundedCornerShape(8.dp),
                        color = if (d == selectedDay) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .35f)
                    ) {
                        Column(Modifier.padding(horizontal = 2.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(d.toString(), style = MaterialTheme.typography.labelMedium)
                            Text(metricText(metric, strings, compact = true), style = MaterialTheme.typography.labelSmall, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WorkerMonitoring(
    strings: AppStrings,
    data: AssemblyData,
    year: Int,
    month: Int,
    day: Int,
    brigadeId: String,
    onExportReport: (MonitoringReportRequest) -> Unit,
    exportMessage: String?
) {
    val date = safeSelectedDate(year, month, day).toString()
    var belowQuality by remember { mutableStateOf(false) }
    var belowEfficiency by remember { mutableStateOf(false) }
    var belowFinal by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<WorkerMetric?>(null) }

    Text(date, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

    val selectedBrigades = data.brigades.filter { !it.archived && !it.deleted && (brigadeId.isBlank() || it.id == brigadeId) }
    val activityBrigades = selectedBrigades.filter { brigade ->
        data.brigadeDay(brigade.id, date) != null ||
            data.workerDays.any { it.brigadeId == brigade.id && it.date == date } ||
            data.qualityRounds.any { it.brigadeId == brigade.id && it.date == date }
    }
    if (activityBrigades.isEmpty()) {
        Text(strings.noMonitoringData, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    val dayMetric = data.monitoringMetric(MonitoringMetricKind.WORKERS, LocalDate.parse(date), LocalDate.parse(date), brigadeId)
    if (dayMetric.state == MonitoringMetricState.NOT_WORKED) {
        Text(strings.didNotWork, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    if (dayMetric.state == MonitoringMetricState.INCOMPLETE) {
        val missing = monitoringMissing(data, activityBrigades, date)
        Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(14.dp)) {
            Column(Modifier.padding(14.dp)) {
                Text("⚠ ${strings.monitoringNotReady}", fontWeight = FontWeight.Bold)
                missing.take(8).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            }
        }
        return
    }

    FilterLine(strings, strings.qualityResult, belowQuality) { belowQuality = it }
    FilterLine(strings, strings.efficiency, belowEfficiency) { belowEfficiency = it }
    FilterLine(strings, strings.finalResult, belowFinal) { belowFinal = it }

    val norm = data.efficiencyNormAt(date).toDouble()
    val metrics = activityBrigades.flatMap { b ->
        data.workerDays.filter { it.brigadeId == b.id && it.date == date && it.worked }.mapNotNull { wd ->
            val worker = data.workers.firstOrNull { it.id == wd.workerId } ?: return@mapNotNull null
            WorkerMetric(worker, b, wd, data.qualityAverage(worker.id, date), data.workerEfficiency(worker.id, date), data.workerFinalResult(worker.id, date))
        }
    }.filter {
        (!belowQuality || (it.quality ?: 999.0) < 75.0) &&
            (!belowEfficiency || (it.efficiency ?: 999.0) < norm) &&
            (!belowFinal || (it.final ?: 999.0) < norm)
    }.sortedBy { it.worker.name.lowercase() }

    OutlinedButton(
        onClick = {
            val brigadeLabel = if (brigadeId.isBlank()) strings.allBrigades else data.brigades.firstOrNull { it.id == brigadeId }?.name.orEmpty()
            val filterText = listOf(
                "${strings.qualityResult}: ${if (belowQuality) strings.belowThreshold else strings.all}",
                "${strings.efficiency}: ${if (belowEfficiency) strings.belowThreshold else strings.all}",
                "${strings.finalResult}: ${if (belowFinal) strings.belowThreshold else strings.all}"
            ).joinToString(" • ")
            onExportReport(
                MonitoringReportRequest(
                    fileName = "ToyBola_Ishchilar_${date}.docx",
                    title = "${strings.monitorWorkers} — $date",
                    metadata = listOf("${strings.brigade}: $brigadeLabel", filterText),
                    headers = listOf(strings.name, strings.brigade, strings.qualityResult, strings.efficiency, strings.finalResult),
                    rows = metrics.map { listOf(
                        it.worker.name, it.brigade.name,
                        it.quality?.let { value -> "%.1f%%".format(value) } ?: "—",
                        it.efficiency?.let { value -> "%.1f%%".format(value) } ?: "—",
                        it.final?.let { value -> "%.1f%%".format(value) } ?: "—"
                    ) }
                )
            )
        },
        modifier = Modifier.fillMaxWidth()
    ) { Text(strings.exportWord) }
    if (!exportMessage.isNullOrBlank()) Text(exportMessage, color = MaterialTheme.colorScheme.primary)

    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(strings.name, Modifier.weight(1.5f), fontWeight = FontWeight.Bold)
        Text(strings.qualityResult, Modifier.weight(.8f), fontWeight = FontWeight.Bold)
        Text(strings.efficiency, Modifier.weight(1f), fontWeight = FontWeight.Bold)
        Text(strings.finalShort, Modifier.weight(.8f), fontWeight = FontWeight.Bold)
    }
    metrics.forEach { metric ->
        Surface(Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { detail = metric }, shape = RoundedCornerShape(12.dp), tonalElevation = 1.dp) {
            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(metric.worker.name, Modifier.weight(1.5f), fontWeight = FontWeight.SemiBold)
                Text(metric.quality?.let { "%.1f%%".format(it) } ?: "—", Modifier.weight(.8f))
                Text(metric.efficiency?.let { "%.1f%%".format(it) } ?: "—", Modifier.weight(1f))
                Text(metric.final?.let { "%.1f%%".format(it) } ?: "—", Modifier.weight(.8f))
            }
        }
    }

    detail?.let { metric -> WorkerDetailDialog(strings, data, metric, date) { detail = null } }
}

@Composable
private fun FilterLine(strings: AppStrings, label: String, below: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.widthIn(min = 100.dp), fontWeight = FontWeight.SemiBold)
        FilterChip(selected = !below, onClick = { onChange(false) }, label = { Text(strings.all) })
        Spacer(Modifier.width(6.dp))
        FilterChip(selected = below, onClick = { onChange(true) }, label = { Text(strings.belowThreshold) })
    }
}

@Composable
private fun WorkerDetailDialog(strings: AppStrings, data: AssemblyData, metric: WorkerMetric, date: String, onDismiss: () -> Unit) {
    val start = runCatching { LocalDate.parse(metric.worker.startDate) }.getOrNull()
    val at = runCatching { LocalDate.parse(date) }.getOrNull()
    val experience = if (start != null && at != null) ChronoUnit.DAYS.between(start, at).coerceAtLeast(0) else 0
    val fk = data.brigadeFkAt(metric.brigade.id, date)
    val required = if (fk != null) fk.toDouble() * metric.day.hours / data.workHoursAt(date) else null
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(metric.worker.name) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DetailLine(strings.brigade, metric.brigade.name)
                DetailLine(strings.experience, "$experience ${strings.days}")
                DetailLine(strings.hours, "${metric.day.hours}")
                DetailLine(strings.qualityResult, metric.quality?.let { "%.1f%%".format(it) } ?: "—")
                DetailLine(strings.totalAmount, "${money(metric.day.earned)} ${strings.som}")
                DetailLine(strings.requiredAmount, required?.let { "${money(it.roundToLong())} ${strings.som}" } ?: "—")
                DetailLine(strings.efficiency, metric.efficiency?.let { "%.1f%%".format(it) } ?: "—")
                DetailLine(strings.finalResult, metric.final?.let { "%.1f%%".format(it) } ?: "—")
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(strings.close) } }
    )
}

@Composable private fun DetailLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) { Text(label, Modifier.weight(1f)); Text(value, fontWeight = FontWeight.Bold) }
}

@Composable
private fun BrigadirMonitoring(
    strings: AppStrings,
    data: AssemblyData,
    year: Int,
    month: Int,
    brigadeId: String,
    onExportReport: (MonitoringReportRequest) -> Unit,
    exportMessage: String?
) {
    Text("${strings.monitorBrigadirs} • ${year}-${month.toString().padStart(2, '0')}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    val ym = YearMonth.of(year, month)
    val brigades = data.brigades.filter { !it.archived && !it.deleted && (brigadeId.isBlank() || it.id == brigadeId) }
    val reportRows = brigades.map { brigade ->
        val days = data.brigadeDays.filter { it.brigadeId == brigade.id && runCatching { YearMonth.from(LocalDate.parse(it.date)) }.getOrNull() == ym && it.brigadirClosed }
        val onTime = ratio(days.count { it.brigadirClosedOnTime() }, days.size)
        val noReopen = ratio(days.count { it.reopenCount == 0 }, days.size)
        val brigadeResults = data.workerDays
            .filter { it.brigadeId == brigade.id && it.worked && runCatching { YearMonth.from(LocalDate.parse(it.date)) }.getOrNull() == ym }
            .mapNotNull { data.workerFinalResult(it.workerId, it.date) }
        val brigadeResult = brigadeResults.takeIf { it.isNotEmpty() }?.average()
        val totalMetric = data.monitoringMetric(MonitoringMetricKind.BRIGADIRS, ym.atDay(1), ym.atEndOfMonth(), brigade.id)
        brigade to listOf(
            strings.onTimeClose to percent(onTime),
            strings.noReopen to percent(noReopen),
            strings.brigadeResult to percent(brigadeResult),
            strings.finalResult to metricText(totalMetric, strings)
        )
    }
    OutlinedButton(
        onClick = {
            val brigadeLabel = if (brigadeId.isBlank()) strings.allBrigades else data.brigades.firstOrNull { it.id == brigadeId }?.name.orEmpty()
            onExportReport(
                MonitoringReportRequest(
                    fileName = "ToyBola_Brigadirlar_${year}-${month.toString().padStart(2, '0')}.docx",
                    title = "${strings.monitorBrigadirs} — ${year}-${month.toString().padStart(2, '0')}",
                    metadata = listOf("${strings.brigade}: $brigadeLabel"),
                    headers = listOf(strings.brigade, strings.onTimeClose, strings.noReopen, strings.brigadeResult, strings.finalResult),
                    rows = reportRows.map { (brigade, rows) -> listOf(brigade.name) + rows.map { it.second } }
                )
            )
        },
        modifier = Modifier.fillMaxWidth()
    ) { Text(strings.exportWord) }
    if (!exportMessage.isNullOrBlank()) Text(exportMessage, color = MaterialTheme.colorScheme.primary)
    reportRows.forEach { (brigade, rows) -> ScoreCard(brigade.name, rows) }
}

@Composable
private fun QualityStaffMonitoring(
    strings: AppStrings,
    data: AssemblyData,
    year: Int,
    month: Int,
    brigadeId: String,
    onExportReport: (MonitoringReportRequest) -> Unit,
    exportMessage: String?
) {
    Text("${strings.monitorQualityStaff} • ${year}-${month.toString().padStart(2, '0')}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    val ym = YearMonth.of(year, month)
    val brigades = data.brigades.filter { !it.archived && !it.deleted && (brigadeId.isBlank() || it.id == brigadeId) }
    val reportRows = brigades.map { brigade ->
        val rounds = data.qualityRounds.filter { it.brigadeId == brigade.id && runCatching { YearMonth.from(LocalDate.parse(it.date)) }.getOrNull() == ym }
        val onTimeRounds = ratio(rounds.count { it.isEvaluated || it.isWorkerAbsent }, rounds.count { it.isFinished })
        val recheckRequired = rounds.filter { it.needsRecheck }
        val rechecks = ratio(recheckRequired.count { it.recheck != null }, recheckRequired.size).let { if (recheckRequired.isEmpty()) 100.0 else it }
        val days = data.brigadeDays.filter { it.brigadeId == brigade.id && runCatching { YearMonth.from(LocalDate.parse(it.date)) }.getOrNull() == ym && it.qualityClosed }
        val onTimeClose = ratio(days.count { it.qualityClosedOnTime() }, days.size)
        val finished = rounds.count { it.isFinished && it.recheckComplete }
        val discipline = ratio(finished, rounds.size)
        val totalMetric = data.monitoringMetric(MonitoringMetricKind.QUALITY, ym.atDay(1), ym.atEndOfMonth(), brigade.id)
        brigade to listOf(
            strings.roundsOnTime to percent(onTimeRounds),
            strings.rechecks to percent(rechecks),
            strings.onTimeClose to percent(onTimeClose),
            strings.dataDiscipline to percent(discipline),
            strings.finalResult to metricText(totalMetric, strings)
        )
    }
    OutlinedButton(
        onClick = {
            val brigadeLabel = if (brigadeId.isBlank()) strings.allBrigades else data.brigades.firstOrNull { it.id == brigadeId }?.name.orEmpty()
            onExportReport(
                MonitoringReportRequest(
                    fileName = "ToyBola_Sifat_nazoratchilari_${year}-${month.toString().padStart(2, '0')}.docx",
                    title = "${strings.monitorQualityStaff} — ${year}-${month.toString().padStart(2, '0')}",
                    metadata = listOf("${strings.brigade}: $brigadeLabel"),
                    headers = listOf(strings.brigade, strings.roundsOnTime, strings.rechecks, strings.onTimeClose, strings.dataDiscipline, strings.finalResult),
                    rows = reportRows.map { (brigade, rows) -> listOf(brigade.name) + rows.map { it.second } }
                )
            )
        },
        modifier = Modifier.fillMaxWidth()
    ) { Text(strings.exportWord) }
    if (!exportMessage.isNullOrBlank()) Text(exportMessage, color = MaterialTheme.colorScheme.primary)
    reportRows.forEach { (brigade, rows) -> ScoreCard(brigade.name, rows) }
}

@Composable
private fun ScoreCard(title: String, rows: List<Pair<String, String>>) {
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), tonalElevation = 1.dp) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            rows.forEach { (label, value) -> DetailLine(label, value) }
        }
    }
}

@Composable
private fun IssueMonitoring(
    strings: AppStrings,
    data: AssemblyData,
    year: Int,
    month: Int,
    day: Int,
    brigadeId: String,
    onExport: (IssueExportScope) -> Unit,
    exportMessage: String?
) {
    var productId by remember { mutableStateOf<String?>(null) }
    var stageId by remember { mutableStateOf<String?>(null) }
    Text(strings.issueHistory, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { onExport(IssueExportScope.DAY) }, Modifier.weight(1f)) { Text(strings.exportDay) }
        OutlinedButton(onClick = { onExport(IssueExportScope.MONTH) }, Modifier.weight(1f)) { Text(strings.exportMonth) }
        OutlinedButton(onClick = { onExport(IssueExportScope.YEAR) }, Modifier.weight(1f)) { Text(strings.exportYear) }
    }
    if (!exportMessage.isNullOrBlank()) Text(exportMessage, color = MaterialTheme.colorScheme.primary)
    val ym = YearMonth.of(year, month)
    val issues = data.dailyIssues.filter {
        runCatching { YearMonth.from(LocalDate.parse(it.date)) }.getOrNull() == ym && (brigadeId.isBlank() || it.brigadeId == brigadeId)
    }
    val products = issues.groupBy { it.productId }.entries.sortedByDescending { it.value.size }
    if (products.isEmpty()) Text(strings.noMonitoringData)
    products.forEach { (pid, records) ->
        val title = records.firstOrNull()?.let { "${it.articleSnapshot} — ${it.productNameSnapshot}" } ?: pid
        Surface(Modifier.fillMaxWidth().clickable { productId = pid }, shape = RoundedCornerShape(12.dp), tonalElevation = 1.dp) {
            Row(Modifier.padding(13.dp)) { Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold); Text(records.size.toString(), fontWeight = FontWeight.Bold) }
        }
    }

    productId?.let { pid ->
        val productIssues = issues.filter { it.productId == pid }
        AlertDialog(
            onDismissRequest = { productId = null },
            title = { Text(productIssues.firstOrNull()?.productNameSnapshot ?: strings.problemProducts) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    productIssues.groupBy { it.stageId }.entries.sortedByDescending { it.value.size }.forEach { (sid, records) ->
                        Surface(Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { stageId = sid }, shape = RoundedCornerShape(10.dp), tonalElevation = 1.dp) {
                            Row(Modifier.padding(11.dp)) { Text(records.first().stageNameSnapshot, Modifier.weight(1f)); Text(records.size.toString(), fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { productId = null }) { Text(strings.close) } }
        )
        stageId?.let { sid ->
            val stageIssues = productIssues.filter { it.stageId == sid }.sortedByDescending { it.createdAt }
            AlertDialog(
                onDismissRequest = { stageId = null },
                title = { Text(stageIssues.firstOrNull()?.stageNameSnapshot ?: strings.issueStage) },
                text = {
                    Column(Modifier.heightIn(max = 430.dp).verticalScroll(rememberScrollState())) {
                        stageIssues.forEach { issue ->
                            Text(issue.date, fontWeight = FontWeight.Bold)
                            Text(issue.note)
                            HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { stageId = null }) { Text(strings.close) } }
            )
        }
    }
}

private fun MonitoringPage.toMetricKind(): MonitoringMetricKind = when (this) {
    MonitoringPage.WORKERS -> MonitoringMetricKind.WORKERS
    MonitoringPage.BRIGADIRS -> MonitoringMetricKind.BRIGADIRS
    MonitoringPage.QUALITY -> MonitoringMetricKind.QUALITY
    MonitoringPage.ISSUES -> MonitoringMetricKind.ISSUES
}

private fun metricText(metric: MonitoringMetric, strings: AppStrings, compact: Boolean = false): String = when (metric.state) {
    MonitoringMetricState.VALUE -> when {
        metric.count != null -> strings.issueCount(metric.count)
        metric.percentage != null -> if (compact) "%.0f%%".format(metric.percentage) else "%.1f%%".format(metric.percentage)
        else -> "—"
    }
    MonitoringMetricState.INCOMPLETE -> "⚠"
    MonitoringMetricState.NOT_WORKED -> if (compact) strings.didNotWorkShort else strings.didNotWork
    MonitoringMetricState.NO_DATA -> "—"
}

private fun monitoringMissing(data: AssemblyData, brigades: List<Brigade>, date: String): List<String> = buildList {
    brigades.forEach { b ->
        val day = data.brigadeDay(b.id, date)
        if (day?.fullyClosed != true) add("${b.name}: kun to‘liq yopilmagan")
        data.brigadirMissing(b.id, date).take(3).forEach { add("${b.name}: $it") }
        data.qualityMissing(b.id, date).take(3).forEach { add("${b.name}: $it") }
    }
}.distinct()

private fun safeSelectedDate(year: Int, month: Int, day: Int): LocalDate {
    val ym = YearMonth.of(year, month)
    return LocalDate.of(year, month, day.coerceIn(1, ym.lengthOfMonth()))
}

private fun monthShort(month: Int): String = listOf("Yan", "Fev", "Mar", "Apr", "May", "Iyn", "Iyl", "Avg", "Sen", "Okt", "Noy", "Dek")[month - 1]
private fun ratio(n: Int, d: Int): Double? = if (d <= 0) null else n * 100.0 / d
private fun percent(v: Double?): String = v?.let { "%.1f%%".format(it) } ?: "—"
private fun money(v: Long): String = String.format("%,d", v).replace(',', '\'')

private fun issueExportTitle(scope: IssueExportScope, date: LocalDate, year: Int, month: Int): String = when (scope) {
    IssueExportScope.DAY -> "Kun muammolari — $date"
    IssueExportScope.MONTH -> "Oy muammolari — ${year}-${month.toString().padStart(2, '0')}"
    IssueExportScope.YEAR -> "Yil muammolari — $year"
}
