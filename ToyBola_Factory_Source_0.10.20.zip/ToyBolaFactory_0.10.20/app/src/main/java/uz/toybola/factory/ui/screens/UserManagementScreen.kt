package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import uz.toybola.factory.core.data.AssemblyDataRepository
import uz.toybola.factory.core.data.Brigade
import uz.toybola.factory.core.data.TpDataRepository
import uz.toybola.factory.core.firebase.AdminManagedUser
import uz.toybola.factory.core.firebase.AdminUserDraft
import uz.toybola.factory.core.firebase.AdminUserRepository
import uz.toybola.factory.core.firebase.AssemblyDataEvents
import uz.toybola.factory.core.firebase.GeneratedUserCredentials
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings

private val USER_ROLES = listOf(
    "BRIGADIR", "QUALITY", "TP_NACHALNIK", "TP_PLAN", "TP_BRIGADIR",
    "TP_SERYO", "TP_QABUL", "TP_QUALITY", "RAHBAR", "ADMIN"
)
private val PERMISSION_KEYS = listOf(
    "BRIGADIR_READ", "BRIGADIR_WRITE",
    "QUALITY_READ", "QUALITY_WRITE",
    "DAILY_ISSUE_READ", "DAILY_ISSUE_WRITE",
    "MONITORING_READ",
    "MASTER_DATA_READ", "MASTER_DATA_WRITE",
    "TP_ORDER_READ", "TP_ORDER_WRITE",
    "TP_PLANNING_READ", "TP_PLANNING_WRITE",
    "TP_MACHINE_READ", "TP_MACHINE_WRITE",
    "TP_ATTENDANCE_READ", "TP_ATTENDANCE_WRITE",
    "TP_SERYO_READ", "TP_SERYO_WRITE",
    "TP_RECEIVING_READ", "TP_RECEIVING_WRITE",
    "TP_QUALITY_READ", "TP_QUALITY_WRITE",
    "TP_MONITORING_READ",
    "TP_MASTER_DATA_READ", "TP_MASTER_DATA_WRITE"
 )

private data class PermissionDepartment(val id: String, val title: String, val keys: Set<String>)

private val PERMISSION_DEPARTMENTS = listOf(
    PermissionDepartment("ASSEMBLY", "Sborka", setOf("BRIGADIR_READ", "BRIGADIR_WRITE", "QUALITY_READ", "QUALITY_WRITE", "DAILY_ISSUE_READ", "DAILY_ISSUE_WRITE")),
    PermissionDepartment("TP_PLAN", "TP • Plan", setOf("TP_ORDER_READ", "TP_ORDER_WRITE", "TP_PLANNING_READ", "TP_PLANNING_WRITE", "TP_MACHINE_READ", "TP_MACHINE_WRITE", "TP_ATTENDANCE_READ", "TP_ATTENDANCE_WRITE")),
    PermissionDepartment("TP_SERYO", "TP • Seryo", setOf("TP_SERYO_READ", "TP_SERYO_WRITE")),
    PermissionDepartment("TP_RECEIVING", "TP • Qabul", setOf("TP_RECEIVING_READ", "TP_RECEIVING_WRITE")),
    PermissionDepartment("TP_QUALITY", "TP • Sifat", setOf("TP_QUALITY_READ", "TP_QUALITY_WRITE")),
    PermissionDepartment("CONTROL", "Monitoring va ma’lumotlar", setOf("MONITORING_READ", "MASTER_DATA_READ", "MASTER_DATA_WRITE", "TP_MONITORING_READ", "TP_MASTER_DATA_READ", "TP_MASTER_DATA_WRITE"))
)

private fun departmentsForPermissions(permissions: Map<String, Boolean>): Set<String> = PERMISSION_DEPARTMENTS
    .filter { group -> group.keys.any { permissions[it] == true } }.map { it.id }.toSet()

private data class UserBrigadeOption(val id: String, val name: String)

@Composable
fun UserManagementScreen(
    strings: AppStrings,
    assemblyRepository: AssemblyDataRepository,
    tpRepository: TpDataRepository,
    onBack: () -> Unit,
    currentUid: String,
    onSelfDeviceCodeReset: (String, String) -> Unit
) {
    val context = LocalContext.current
    val api = remember(context) { AdminUserRepository(context) }
    val scope = rememberCoroutineScope()
    val dataRevision by AssemblyDataEvents.revision.collectAsState()
    val tpRevision by TpDataEvents.revision.collectAsState()
    val brigades = remember(dataRevision, tpRevision) {
        val assembly = assemblyRepository.load().brigades.filter { !it.archived && !it.deleted }
            .map { UserBrigadeOption(it.id, "Sborka • ${it.name}") }
        val tp = tpRepository.load().brigades.filterNot { it.archived }
            .map { UserBrigadeOption(it.id, "TP • ${it.name}") }
        (assembly + tp).distinctBy { it.id }.sortedBy { it.name.lowercase() }
    }

    var users by remember { mutableStateOf<List<AdminManagedUser>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var pageError by remember { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var editUser by remember { mutableStateOf<AdminManagedUser?>(null) }
    var saving by remember { mutableStateOf(false) }
    var editorError by remember { mutableStateOf<String?>(null) }
    var credentials by remember { mutableStateOf<Pair<String, GeneratedUserCredentials>?>(null) }
    var deleteUser by remember { mutableStateOf<AdminManagedUser?>(null) }

    fun reload() {
        scope.launch {
            loading = true
            pageError = null
            api.listUsers()
                .onSuccess { users = it }
                .onFailure { pageError = friendlyError(it) }
            loading = false
        }
    }

    LaunchedEffect(Unit) { reload() }
    BackHandler(onBack = onBack)

    Column(Modifier.fillMaxSize()) {
        AppTopBar(strings.userManagement, canGoBack = true, onMenu = {}, onBack = onBack)
        Column(
            Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("UserManagementScreen-screen-1")).navigationBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { editorError = null; showCreate = true },
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)
            ) { Text("+ ${strings.addUser}", fontWeight = FontWeight.Bold) }

            OutlinedButton(onClick = ::reload, modifier = Modifier.fillMaxWidth()) { Text(strings.refresh) }

            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (!pageError.isNullOrBlank()) Text(pageError!!, color = MaterialTheme.colorScheme.error)

            users.forEach { user ->
                ManagedUserCard(
                    user = user,
                    brigades = brigades,
                    strings = strings,
                    onClick = { editorError = null; editUser = user }
                )
            }
        }
    }

    if (showCreate) {
        UserEditorDialog(
            strings = strings,
            brigades = brigades,
            initial = null,
            saving = saving,
            error = editorError,
            onDismiss = { if (!saving) showCreate = false },
            onSubmit = { draft ->
                saving = true
                editorError = null
                scope.launch {
                    api.createUser(draft)
                        .onSuccess { (user, codes) ->
                            users = (users.filterNot { it.uid == user.uid } + user)
                                .sortedWith(compareByDescending<AdminManagedUser> { it.enabled }.thenBy { it.displayName.lowercase() })
                            showCreate = false
                            credentials = user.displayName to codes
                        }
                        .onFailure { editorError = friendlyError(it) }
                    saving = false
                }
            }
        )
    }

    editUser?.let { selected ->
        UserEditorDialog(
            strings = strings,
            brigades = brigades,
            initial = selected,
            saving = saving,
            error = editorError,
            onDismiss = { if (!saving) editUser = null },
            onSubmit = { draft ->
                saving = true
                editorError = null
                scope.launch {
                    api.updateUser(selected.uid, draft)
                        .onSuccess { updated ->
                            users = users.map { if (it.uid == updated.uid) updated else it }
                                .sortedWith(compareByDescending<AdminManagedUser> { it.enabled }.thenBy { it.displayName.lowercase() })
                            editUser = null
                        }
                        .onFailure { editorError = friendlyError(it) }
                    saving = false
                }
            },
            onDelete = if (selected.role.uppercase() in setOf("BRIGADIR", "TP_BRIGADIR", "TP_SERYO")) ({ deleteUser = selected }) else null,
            onResetDeviceCode = {
                saving = true
                editorError = null
                scope.launch {
                    api.resetDeviceCode(selected.uid)
                        .onSuccess { newDeviceCode ->
                            if (selected.uid == currentUid) onSelfDeviceCodeReset(selected.userCode, newDeviceCode)
                            credentials = selected.displayName to GeneratedUserCredentials(selected.userCode, newDeviceCode)
                            editUser = null
                        }
                        .onFailure { editorError = friendlyError(it) }
                    saving = false
                }
            }
        )
    }

    deleteUser?.let { selected ->
        AlertDialog(
            onDismissRequest = { if (!saving) deleteUser = null },
            title = { Text("Brigadirni o‘chirish") },
            text = { Text("${selected.displayName} foydalanuvchisi va uning kirish kodi o‘chiriladi. Bu amalni qaytarib bo‘lmaydi. Davom etasizmi?") },
            confirmButton = { TextButton(enabled = !saving, onClick = {
                saving = true
                pageError = null
                scope.launch {
                    api.deleteBrigadier(selected.uid)
                        .onSuccess {
                            users = users.filterNot { it.uid == selected.uid }
                            if (editUser?.uid == selected.uid) editUser = null
                            deleteUser = null
                        }
                        .onFailure { pageError = friendlyError(it) }
                    saving = false
                }
            }) { Text("O‘chirish", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(enabled = !saving, onClick = { deleteUser = null }) { Text(strings.cancel) } }
        )
    }

    credentials?.let { (name, codes) ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text(strings.generatedCodes) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(name, fontWeight = FontWeight.Bold)
                    Text(strings.generatedCodesHelp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    SelectionContainer {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp), tonalElevation = 1.dp) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(strings.userCode, style = MaterialTheme.typography.labelMedium)
                                    Text(codes.userCode, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                }
                            }
                            Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp), tonalElevation = 1.dp) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(strings.deviceCode, style = MaterialTheme.typography.labelMedium)
                                    Text(codes.deviceCode, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { credentials = null }) { Text(strings.close) } }
        )
    }
}

@Composable
private fun ManagedUserCard(
    user: AdminManagedUser,
    brigades: List<UserBrigadeOption>,
    strings: AppStrings,
    onClick: () -> Unit
) {
    val brigadeText = if (user.allBrigades) strings.allBrigades else {
        val names = brigades.filter { it.id in user.allowedBrigadeIds }.map { it.name }
        if (names.isEmpty()) "—" else names.joinToString(", ")
    }
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        tonalElevation = 1.dp
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(user.displayName.ifBlank { user.userCode }, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Text(if (user.enabled) strings.enabled else strings.disabled,
                    color = if (user.enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            }
            Text("${strings.role}: ${userRoleLabel(user.role)}", style = MaterialTheme.typography.bodySmall)
            Text("${strings.userCode}: ${user.userCode}", style = MaterialTheme.typography.bodySmall)
            Text("${strings.brigade}: $brigadeText", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun UserEditorDialog(
    strings: AppStrings,
    brigades: List<UserBrigadeOption>,
    initial: AdminManagedUser?,
    saving: Boolean,
    error: String?,
    onDismiss: () -> Unit,
    onSubmit: (AdminUserDraft) -> Unit,
    onResetDeviceCode: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null
) {
    var displayName by remember(initial?.uid) { mutableStateOf(initial?.displayName.orEmpty()) }
    var role by remember(initial?.uid) { mutableStateOf(initial?.role?.ifBlank { "BRIGADIR" } ?: "BRIGADIR") }
    var enabled by remember(initial?.uid) { mutableStateOf(initial?.enabled ?: true) }
    var allBrigades by remember(initial?.uid) { mutableStateOf(initial?.allBrigades ?: false) }
    var selectedBrigades by remember(initial?.uid) { mutableStateOf(initial?.allowedBrigadeIds ?: emptySet()) }
    var permissions by remember(initial?.uid) {
        mutableStateOf(
            initial?.permissions?.let { current -> normalizePermissionMap(current) }
                ?: if (role == "ADMIN") defaultPermissions("ADMIN") else emptyPermissions()
        )
    }
    var selectedDepartments by remember(initial?.uid) {
        mutableStateOf(if (role == "ADMIN") PERMISSION_DEPARTMENTS.map { it.id }.toSet() else departmentsForPermissions(permissions))
    }
    var roleMenu by remember { mutableStateOf(false) }
    var validation by remember { mutableStateOf<String?>(null) }

    fun updatePermission(key: String, value: Boolean) {
        val next = permissions.toMutableMap()
        next[key] = value
        if (value && key.endsWith("_WRITE")) next[key.removeSuffix("_WRITE") + "_READ"] = true
        if (!value && key.endsWith("_READ")) next[key.removeSuffix("_READ") + "_WRITE"] = false
        permissions = normalizePermissionMap(next)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) strings.addUser else strings.editUser) },
        text = {
            Column(
                Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = displayName,
                    onValueChange = { displayName = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(strings.name) },
                    singleLine = true
                )

                if (initial != null) {
                    SelectionContainer { Text("${strings.userCode}: ${initial.userCode}", fontWeight = FontWeight.SemiBold) }
                }

                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { roleMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("${strings.role}: ${userRoleLabel(role)}", modifier = Modifier.weight(1f))
                    }
                    DropdownMenu(expanded = roleMenu, onDismissRequest = { roleMenu = false }) {
                        USER_ROLES.forEach { option ->
                            DropdownMenuItem(text = { Text(userRoleLabel(option)) }, onClick = {
                                roleMenu = false
                                role = option
                                if (option == "ADMIN") {
                                    permissions = defaultPermissions("ADMIN")
                                    selectedDepartments = PERMISSION_DEPARTMENTS.map { it.id }.toSet()
                                    allBrigades = true
                                } else {
                                    // Department-first flow: role does not silently grant sections.
                                    permissions = emptyPermissions()
                                    selectedDepartments = emptySet()
                                    allBrigades = false
                                }
                            })
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(strings.enabled, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    Switch(checked = enabled, onCheckedChange = { enabled = it })
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(strings.allBrigadesAccess, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    Switch(
                        checked = allBrigades || role == "ADMIN",
                        onCheckedChange = { allBrigades = it },
                        enabled = role != "ADMIN"
                    )
                }
                if (!allBrigades && role != "ADMIN") {
                    Column {
                        brigades.forEach { brigade ->
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    selectedBrigades = if (brigade.id in selectedBrigades) selectedBrigades - brigade.id else selectedBrigades + brigade.id
                                },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = brigade.id in selectedBrigades,
                                    onCheckedChange = { checked ->
                                        selectedBrigades = if (checked) selectedBrigades + brigade.id else selectedBrigades - brigade.id
                                    }
                                )
                                Text(brigade.name)
                            }
                        }
                    }
                }

                HorizontalDivider()
                Text("1. Bo‘limlarni tanlang", fontWeight = FontWeight.Bold)
                Text("Avval foydalanuvchi qaysi bo‘limlarga kirishini yoqing. Keyin faqat shu bo‘limlarning ruxsatlari ko‘rinadi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                PERMISSION_DEPARTMENTS.forEach { department ->
                    val checked = role == "ADMIN" || department.id in selectedDepartments
                    Row(
                        Modifier.fillMaxWidth().clickable(enabled = role != "ADMIN") {
                            val turnOn = department.id !in selectedDepartments
                            selectedDepartments = if (turnOn) selectedDepartments + department.id else selectedDepartments - department.id
                            val next = permissions.toMutableMap()
                            if (!turnOn) department.keys.forEach { next[it] = false }
                            else department.keys.filter { it.endsWith("_READ") }.forEach { next[it] = true }
                            permissions = normalizePermissionMap(next)
                        },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Switch(
                            checked = checked,
                            onCheckedChange = if (role == "ADMIN") null else { turnOn ->
                                selectedDepartments = if (turnOn) selectedDepartments + department.id else selectedDepartments - department.id
                                val next = permissions.toMutableMap()
                                if (!turnOn) department.keys.forEach { next[it] = false }
                                else department.keys.filter { it.endsWith("_READ") }.forEach { next[it] = true }
                                permissions = normalizePermissionMap(next)
                            }
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(department.title, fontWeight = FontWeight.SemiBold)
                    }
                }

                HorizontalDivider()
                Text("2. Ruxsatlarni belgilang", fontWeight = FontWeight.Bold)
                if (role != "ADMIN" && selectedDepartments.isEmpty()) {
                    Text("Kamida bitta bo‘limni yoqing.", color = MaterialTheme.colorScheme.error)
                }
                if (role == "ADMIN" || "ASSEMBLY" in selectedDepartments) {
                    Text("Sborka", fontWeight = FontWeight.Bold)
                    PermissionPair(strings.brigadir, "BRIGADIR_READ", "BRIGADIR_WRITE", permissions, ::updatePermission, strings, role != "ADMIN")
                    PermissionPair(strings.quality, "QUALITY_READ", "QUALITY_WRITE", permissions, ::updatePermission, strings, role != "ADMIN")
                    PermissionPair(strings.dailyIssue, "DAILY_ISSUE_READ", "DAILY_ISSUE_WRITE", permissions, ::updatePermission, strings, role != "ADMIN")
                }
                if (role == "ADMIN" || "TP_PLAN" in selectedDepartments) {
                    Text("TP • Plan", fontWeight = FontWeight.Bold)
                    PermissionPair("Zakaz (nachalnik)", "TP_ORDER_READ", "TP_ORDER_WRITE", permissions, ::updatePermission, strings, role != "ADMIN")
                    PermissionPair("Plan beruvchi", "TP_PLANNING_READ", "TP_PLANNING_WRITE", permissions, ::updatePermission, strings, role != "ADMIN")
                    PermissionPair("TP brigadir / stanok", "TP_MACHINE_READ", "TP_MACHINE_WRITE", permissions, ::updatePermission, strings, role != "ADMIN")
                    PermissionPair("Davomat va qo‘shimcha soat", "TP_ATTENDANCE_READ", "TP_ATTENDANCE_WRITE", permissions, ::updatePermission, strings, role != "ADMIN")
                }
                if (role == "ADMIN" || "TP_SERYO" in selectedDepartments) {
                    Text("TP • Seryo", fontWeight = FontWeight.Bold)
                    PermissionPair("Seryo", "TP_SERYO_READ", "TP_SERYO_WRITE", permissions, ::updatePermission, strings, role != "ADMIN")
                }
                if (role == "ADMIN" || "TP_RECEIVING" in selectedDepartments) {
                    Text("TP • Qabul", fontWeight = FontWeight.Bold)
                    PermissionPair("Qabul qilish", "TP_RECEIVING_READ", "TP_RECEIVING_WRITE", permissions, ::updatePermission, strings, role != "ADMIN")
                }
                if (role == "ADMIN" || "TP_QUALITY" in selectedDepartments) {
                    Text("TP • Sifat", fontWeight = FontWeight.Bold)
                    PermissionPair("TP sifat", "TP_QUALITY_READ", "TP_QUALITY_WRITE", permissions, ::updatePermission, strings, role != "ADMIN")
                }
                if (role == "ADMIN" || "CONTROL" in selectedDepartments) {
                    Text("Monitoring va ma’lumotlar", fontWeight = FontWeight.Bold)
                    PermissionPair(strings.monitoring, "MONITORING_READ", null, permissions, ::updatePermission, strings, role != "ADMIN")
                    PermissionPair(strings.masterData, "MASTER_DATA_READ", "MASTER_DATA_WRITE", permissions, ::updatePermission, strings, role != "ADMIN")
                    PermissionPair("TP monitoring", "TP_MONITORING_READ", null, permissions, ::updatePermission, strings, role != "ADMIN")
                    PermissionPair("TP ma’lumotlari", "TP_MASTER_DATA_READ", "TP_MASTER_DATA_WRITE", permissions, ::updatePermission, strings, role != "ADMIN")
                }

                if (initial != null && onResetDeviceCode != null) {
                    HorizontalDivider()
                    OutlinedButton(
                        onClick = onResetDeviceCode,
                        enabled = !saving,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(strings.resetDeviceCode) }
                }
                if (initial != null && onDelete != null) {
                    OutlinedButton(
                        onClick = onDelete,
                        enabled = !saving,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Brigadirni o‘chirish", color = MaterialTheme.colorScheme.error) }
                }

                val shownError = validation ?: error
                if (!shownError.isNullOrBlank()) Text(shownError, color = MaterialTheme.colorScheme.error)
                if (saving) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(enabled = !saving, onClick = {
                validation = when {
                    displayName.isBlank() -> strings.required
                    role != "ADMIN" && selectedDepartments.isEmpty() -> "Kamida bitta bo‘limni tanlang"
                    role != "ADMIN" && !allBrigades && selectedBrigades.isEmpty() -> strings.chooseBrigade
                    else -> null
                }
                if (validation == null) {
                    onSubmit(
                        AdminUserDraft(
                            displayName = displayName,
                            role = role,
                            enabled = enabled,
                            allBrigades = allBrigades || role == "ADMIN",
                            allowedBrigadeIds = if (allBrigades || role == "ADMIN") emptySet() else selectedBrigades,
                            permissions = if (role == "ADMIN") defaultPermissions("ADMIN") else normalizePermissionMap(permissions)
                        )
                    )
                }
            }) { Text(strings.save) }
        },
        dismissButton = { TextButton(enabled = !saving, onClick = onDismiss) { Text(strings.cancel) } }
    )
}

@Composable
private fun PermissionPair(
    title: String,
    readKey: String,
    writeKey: String?,
    permissions: Map<String, Boolean>,
    onChange: (String, Boolean) -> Unit,
    strings: AppStrings,
    enabled: Boolean = true
) {
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp), tonalElevation = 1.dp) {
        Column(Modifier.padding(10.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = permissions[readKey] == true, onCheckedChange = { onChange(readKey, it) }, enabled = enabled)
                    Text(strings.readAccess, style = MaterialTheme.typography.bodySmall)
                }
                if (writeKey != null) {
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = permissions[writeKey] == true, onCheckedChange = { onChange(writeKey, it) }, enabled = enabled)
                        Text(strings.writeAccess, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

private fun emptyPermissions(): Map<String, Boolean> = PERMISSION_KEYS.associateWith { false }

private fun defaultPermissions(role: String): Map<String, Boolean> {
    val out = PERMISSION_KEYS.associateWith { false }.toMutableMap()
    when (role.uppercase()) {
        "ADMIN" -> PERMISSION_KEYS.forEach { out[it] = true }
        "RAHBAR" -> PERMISSION_KEYS.filter { it.endsWith("_READ") }.forEach { out[it] = true }
        "BRIGADIR" -> listOf("BRIGADIR_READ", "BRIGADIR_WRITE", "DAILY_ISSUE_READ", "DAILY_ISSUE_WRITE", "MONITORING_READ").forEach { out[it] = true }
        "QUALITY" -> listOf("QUALITY_READ", "QUALITY_WRITE", "DAILY_ISSUE_READ", "DAILY_ISSUE_WRITE", "MONITORING_READ").forEach { out[it] = true }
        "TP_NACHALNIK" -> listOf("TP_ORDER_READ", "TP_ORDER_WRITE", "TP_PLANNING_READ", "TP_MACHINE_READ", "TP_ATTENDANCE_READ", "TP_MONITORING_READ", "TP_MASTER_DATA_READ").forEach { out[it] = true }
        "TP_PLAN" -> listOf("TP_ORDER_READ", "TP_PLANNING_READ", "TP_PLANNING_WRITE", "TP_MACHINE_READ", "TP_MACHINE_WRITE", "TP_ATTENDANCE_READ", "TP_ATTENDANCE_WRITE", "TP_SERYO_READ", "TP_MONITORING_READ", "TP_MASTER_DATA_READ", "TP_MASTER_DATA_WRITE").forEach { out[it] = true }
        "TP_BRIGADIR" -> listOf("TP_MACHINE_READ", "TP_MACHINE_WRITE", "TP_SERYO_READ", "TP_RECEIVING_READ", "TP_QUALITY_READ", "TP_MONITORING_READ").forEach { out[it] = true }
        "TP_SERYO" -> listOf("TP_MACHINE_READ", "TP_SERYO_READ", "TP_SERYO_WRITE", "TP_MONITORING_READ", "TP_MASTER_DATA_READ").forEach { out[it] = true }
        "TP_QABUL" -> listOf("TP_MACHINE_READ", "TP_RECEIVING_READ", "TP_RECEIVING_WRITE", "TP_MONITORING_READ").forEach { out[it] = true }
        "TP_QUALITY" -> listOf("TP_MACHINE_READ", "TP_QUALITY_READ", "TP_QUALITY_WRITE", "TP_MONITORING_READ").forEach { out[it] = true }
    }
    return out
}

private fun userRoleLabel(role: String): String = when (role.uppercase()) {
    "ADMIN" -> "Admin"
    "RAHBAR" -> "Rahbar"
    "BRIGADIR" -> "Sborka brigadiri"
    "QUALITY" -> "Sborka sifat nazoratchisi"
    "TP_NACHALNIK" -> "TP nachalnik"
    "TP_PLAN" -> "TP plan beruvchi"
    "TP_BRIGADIR" -> "TP brigadir"
    "TP_SERYO" -> "Seryo brigadiri"
    "TP_QABUL" -> "TP qabul qiluvchi"
    "TP_QUALITY" -> "TP sifat nazoratchisi"
    else -> role
}

private fun normalizePermissionMap(raw: Map<String, Boolean>): Map<String, Boolean> =
    PERMISSION_KEYS.associateWith { raw[it] == true }

private fun friendlyError(error: Throwable): String =
    error.message?.substringAfter(": ")?.takeIf { it.isNotBlank() } ?: "Server xatosi"
