# ToyBola Factory 0.10.21

## 0.10.21 — authoritative delete va qurilmalararo sync

- Server snapshot endi authoritative: serverda yo‘q yozuv lokal keshdan ham olib tashlanadi.
- Zakaz, vazifa, qabul, qo‘shimcha soat va kun muammosi o‘chirilganda server tombstone saqlaydi; eski/offline qurilma ularni qayta yarata olmaydi.
- Sync serverdan olish → lokal pending o‘zgarishlarni xavfsiz birlashtirish → serverga yuborish → qayta tekshirish tartibida ishlaydi.
- Outbox har bir yozuv versiyasini saqlaydi; sync paytida yana tahrirlangan yangi holat yo‘qolmaydi.
- Firestore `syncState` listenerlari va FCM/WorkManager fallback boshqa qurilmadagi o‘zgarishni tez yuklaydi.
- Fresh install serverdan toza bootstrap qiladi; bo‘sh serverga eski lokal keshni avtomatik seed qilish olib tashlandi.
- Android backup/device-transfer lokal bazani yangi qurilmaga ko‘chirmaydi; yangi o‘rnatish doim serverdan boshlanadi.
- Granular ruxsatlarda saqlangan `false` endi rolning eski standart ruxsati bilan serverda qayta yoqilmaydi.
- Tombstone sabab avtomatik tozalangan stale zakaz/vazifa yolg‘on yangi/o‘chirish bildirishnomasi yubormaydi.
- TP va Sborka yarim oylik Excel eksportlari, qo‘shimcha soat hisoblari va barcha faol TP ishchilarining umumiy maosh ro‘yxati saqlandi.
- Foydalanuvchi yaratishda rol bo‘limlarni avtomatik yoqmaydi: avval bo‘lim, keyin shu bo‘lim ruxsatlari tanlanadi.

## 0.10.18 — Kotlin compile tuzatishi

- `TpScreens.kt` dagi Boshlash tugmasida `enabled`, `onClick` va `modifier` argumentlari Kotlin talab qiladigan aniq named-argument shakliga keltirildi.
- Funksional xatti-harakat o‘zgarmadi; bu patch GitHub Actions `compileDebugKotlin` xatosini bartaraf etadi.

## 0.10.17 — Monitoring, stanok o‘chishlari, qo‘shimcha soatlar va bo‘limli ruxsatlar

- Plan beruvchi brigadani tanlamaydi; stanok sexi va kutilayotgan boshlanish smenasidan avtomatik biriktiriladi.
- Bitta detal tasdiqlangach Seryo tayyorlash/yetkazish keyingi bosqichlari butun zakaz tasdiqlanishini kutmaydi.
- Sync pull lokal yangi tanlovni eski server snapshot bilan qaytarib yubormasligi uchun dirty-key himoyasi qo‘shildi.
- Stanok vazifasida seryo yetkazilgan ranglar soni ko‘rinadi; Qabul badge olib tashlandi.
- Qabul qiluvchi o‘zi kiritgan qabul yozuvini o‘chira oladi.

- TP/Seryo bosh kartalaridagi izohlar qisqartirildi.
- Qabulda sex filtri olib tashlandi; son maydonlari bo‘sh boshlanadi.
- Sborka Brigadir/Sifat outbox server-side `applyAssemblyWrites` orqali yuboriladi.
- TP zanjirida yangi ishlar FCM bilan tegishli foydalanuvchilarga yuboriladi va bo‘lim badge sonlari ko‘rinadi.
- Plan beruvchi detalma-detal tasdiqlaydi, tasdiqlangan detallar pastga tushadi; tahrirlashda sharh majburiy.
- Plan beruvchiga Zakazlar/Stanoklar ko‘rinishi, sex bo‘yicha stanok bandligi va 18-soat ogohlantirishi qo‘shildi.
- Davomat to‘liq/minus/ishlamagan guruhlarga ajratildi va raqam maydonlaridagi boshlang‘ich 0 muammosi tuzatildi.
- TP sifat raundida baholangan stanok ✓ bilan pastga tushadi va foiz ko‘rsatiladi.

## 0.10.13 — TP/Seryo UX va import tuzatishlari

- TP brigadir detal/rang kesimida taxminiy davomiylik va boshlangan ishning taxminiy tugash vaqtini ko‘radi.
- Kun muammosi rasmlari ilova ichidagi kichik dialog emas, telefonning rasm ko‘ruvchi/Galereya ilovasi orqali ochiladi.
- TP Sifat asosiy oynasi Seryo kabi 3 bo‘limga ajratildi: Baholash, Kun muammosi, Monitoring.
- Baholash asosiy oynasida smena raundlari vaqt bilan ko‘rinadi va faqat ±1 soat oynasida baholash ochiladi.
- Excel importida `"003"`, `'003'` va `'003` kabi matn ko‘rinishidagi kodlardan tashqi qo‘shtirnoq/apostrof olib tashlanadi; dasturda `003` saqlanadi.

## 0.10.11 — TP/Seryo oqimi va ortiqcha nomlarni tozalash

- Plan beruvchi stanok tanlashida stanok raqami bilan sex nomi ko‘rinadi; band stanok ma’lumotida artikul, mahsulot, detal, rang, seryo va holat ko‘rsatiladi.
- Plan beruvchida qolip kodi foydalanuvchiga ikkinchi detal nomi sifatida ko‘rsatilmaydi.
- Seryo tanlash faqat Seryo brigadir oqimida; barcha detal/rang uchun tanlanmaguncha yordamchilarga yuborish bloklanadi.
- Seryo yetishmovchiligi tanlovning o‘zida va yakuniy tasdiqda ogohlantiriladi; brigadir tasdiqlasa oqim davom etadi.
- Tayyorlash/Yetkazish, TP brigadir, Qabul va Sifat oqimlari 0.10.10 dagi soddalashtirilgan status/tartib qoidalarini saqlaydi.
- Ostatka jadvali yanada ixchamlashtirildi; kun/oy/yil kesimi va Excel/PDF eksport saqlandi.
- Kun muammosida Galereya endi tizim fayl tanlagichi emas, Android Photo Picker orqali ochiladi; Kamera ham alohida tanlanadi.
- Global `adjustResize` + `imePadding` saqlanadi, shuning uchun klaviatura input maydonlarini yopib qolmasligi kerak.

# Toy Bola Factory Management System

## 0.10.10 — Zakaz o‘chirish xabari, minus-soat davomat va TP reset

- Nachalnik TP zakazini o‘chira oladi; qabul yozuvi yoki yakunlangan holat bo‘lsa himoya saqlanadi. O‘chirish serverda bog‘liq TP/Seryo foydalanuvchilariga FCM xabar yuboradi.
- Davomatga **Barcha bo‘limlar / Barcha brigadalar** filtri qo‘shildi. Qo‘lda “ishlagan daqiqa” kiritish olib tashlanib, **Minus soat** (1 soat = 60 daqiqa) joriy qilindi.
- Admin User Management ichidan Sborka brigadiri, TP brigadiri va Seryo brigadirini o‘chira oladi; login kodi ham bekor qilinadi.
- Admin uchun **TP/Seryo test ma’lumotlarini tozalash** amali qo‘shildi. Sex/smena, umumiy kunlik norma va brigada identifikatorlari (ruxsatlar uzilmasligi uchun yashirin/arxiv holatda) saqlanadi; qolgan TP master/operatsion ma’lumotlari server va lokal bazadan tozalanadi.

## 0.10.2 — navigatsiya, Plan tasdiqlash, sig‘im, ko‘p-seryo va jim narxi

- Barcha asosiy ekranlarda Back navigatsiyasi bir pog‘onadan qaytadigan qilib tartiblandi; uzun ro‘yxatlarda ichki elementni ochib qaytganda oldingi scroll joyi saqlanadi.
- TP detal ma’lumotidan qo‘lda “mos stanoklar” tanlash olib tashlandi. Moslik faqat stanok sig‘imi va detalga kiritilgan ruxsatli sig‘imlar orqali avtomatik aniqlanadi.
- Plan beruvchida “Tasdiqlanmagan / Tasdiqlangan” oqimi va “Jarayonni boshlash / tasdiqlash” amali qo‘shildi. Tasdiqlanmaguncha plan Seryo, Qabul/Sifat va TP brigadir ish oqimlariga chiqmaydi.
- Bitta detal uchun bir nechta seryo turi kiritish va plan rang-vazifasi kesimida umumiy mos seryoni tanlash qo‘shildi.
- Detal narxi endi dona narxi emas, **1 jim narxi** sifatida ishlaydi. Qabul dona bilan qoladi; ishchi summasi `dona / 1 jimdagi dona × jim narxi` bo‘yicha hisoblanadi.

## 0.10.1 — TP sync, Nachalnik ustuvorligi va Plan beruvchi stanok rejalashi

- TP/Seryo lokal yozuvlari global Sync/Pending indikatoriga qo‘shildi; TP write WorkManager sync navbatiga avtomatik tushadi va faol sync paytidagi yangi so‘rov yo‘qolmaydi.
- Nachalnik zakazida 3 bosqichli rangli ustuvorlik: Eng zaril / Zaril / Keyinroq; kerakli sana maydoni olib tashlandi, zakaz vaqti va taxminiy yakun muddati ko‘rsatiladi.
- Zakazni tahrirlash va ishlab chiqarish boshlanmagan bo‘lsa o‘chirish qo‘shildi.
- Plan beruvchida zakaz → detallar → rang navbati → mos stanok tanlash oqimi soddalashtirildi. Bo‘sh stanoklar tepada, bandlari eng tez bo‘shaydiganidan tartiblanadi.
- Stanok master-data kartasiga sig‘im, detal/qolipga mos sig‘imlar (masalan 60/90/120) qo‘shildi; stanok mosligi va forecast shu cheklovni hisobga oladi.

## 0.10.0 — TP va Seryo ish jarayoni

Asosiy ekrandagi **Seryo va quyish** bo‘limi ishga tushirildi. Ichki tuzilma sodda besh yo‘nalishga yig‘ildi: **Plan**, **Seryo**, **Qabul qilish**, **Sifat** va **Monitoring**. Plan ichida nachalnik zakazi, plan beruvchi hisobi, TP brigadir stanok navbati, davomat hamda mahsulot/qolip ma’lumotlari joylashgan.

Zakazdan detal va rang kesimidagi ehtiyoj, jim soni, ortiqcha chiqadigan dona, seryo kilogrammi, krasitel grammi va taxminiy quyish vaqti avtomatik hisoblanadi. Bir qolipdan ikki yoki undan ko‘p detal birga chiqishi, stanok mosligi, bitta stanokdagi ustuvor navbat, uch sex–ikki smena–olti brigada boshlang‘ich tuzilmasi va keyinchalik brigada/smena qo‘shish yoki almashtirish qo‘llab-quvvatlanadi.

Qabul qilishda smenalararo yarim qop avtomatik hisoblanadi: oldingi ishchi qoldirgan dona yangi ishchiga qayta yozilmaydi. Real qabul reja soniga yetgandagina vazifa va partiya yakunlanadi. Sifat raundlari smena bo‘yicha o‘zgaruvchan, monitoringda partiya, ishchi, stanok, brigada, sifat, seryo va krasitel ko‘rsatkichlari sana oralig‘ida ko‘rinadi hamda Word/Excelga chiqariladi.

TP ma’lumotlari alohida server snapshot orqali fresh install qurilmaga qaytadi. Yozuvlar rol, granular permission va brigada scope bilan Firestore Rules hamda Cloud Functions darajasida tekshiriladi. Admin eski profilida yangi TP permission maydonlari bo‘lmasa ham Admin vakolati to‘liq saqlanadi. Device Code almashtirilganda eski hash bekor qilinadi.

0.9.5 dagi Sborka qoldiqli son o‘zgarishi saqlangan; TP/Seryo qo‘shilishi Sborka hisoblash va ekranlariga boshqa o‘zgarish kiritmaydi.

## 0.9.5 — Sborka qoldiqli son hotfix

Sborka Brigadir oynasidagi mahsulot soni endi `1.5` kabi qoldiqli qiymatni qabul qiladi. Butun sonlar avvalgidek `5` ko‘rinishida qoladi va `5.0` bo‘lib chiqmaydi. Eski butun sonli lokal/server ma’lumotlari yangi formatda o‘zgarishsiz o‘qiladi. Qoldiqli son bo‘yicha topilgan summa eng yaqin butun so‘mga yaxlitlanadi.

0.9.4 dagi server snapshot, recovery, ruxsatlar, Sifat, Monitoring, Kun muammosi va Sborka kunini yopish/qayta ochish ishlashiga boshqa o‘zgarish kiritilmagan.

## 0.9.4 — authoritative server snapshot hotfix

0.9.3 server-side recovery muvaffaqiyatli yozgandan keyin Android clientning bevosita Firestore qayta-o‘qishi ayrim pilot/legacy hujjatlar yoki Rules query sharoitida `PERMISSION_DENIED` bilan to‘xtashi mumkin edi. 0.9.4 da normal server→client bootstrap/sync `getAssemblySnapshot` callable endpoint orqali bajariladi. Endpoint foydalanuvchining serverdagi role/permission/brigada scopeini tekshiradi va faqat ruxsatli ma’lumotni Firebase Admin SDK orqali o‘qib qaytaradi.

Bu fresh install, Admin `Kun muammosi` ko‘rinishi va recoverydan keyingi qayta syncni bir xil server-authoritative yo‘lga birlashtiradi. Oddiy client yozuvlari esa Firestore Security Rules orqali himoyalangan holda qoladi.

Android/Kotlin/Jetpack Compose zavod boshqaruv tizimi.

## 0.9.3 — server-side recovery hotfix

0.9.3 pilotda 0.9.2 recovery vaqtida topilgan `PERMISSION_DENIED` xatosini tuzatadi. Endi Admin backupdagi merged AssemblyData ni oddiy Android Firestore batch bilan yozmaydi. `adminRestoreAssemblyBackup` callable Cloud Function Admin sessiyasini tekshiradi, payload SHA-256 checksumini tasdiqlaydi, eski/legacy hujjatlarni yangi structured schema ga normalizatsiya qiladi va Firebase Admin SDK bilan serverga yozadi.

### Asosiy o‘zgarishlar

- Admin-only `adminRestoreAssemblyBackup` Cloud Function.
- Recovery yozuvlari client Firestore Rules orqali emas, server Admin SDK orqali yoziladi; kundalik oddiy yozuvlar esa avvalgidek Security Rules bilan himoyalanadi.
- Brigada, ishchi, mahsulot/narx, FK, sozlamalar, workerDays, brigadeDays, sifat raundlari, Kun muammosi va audit yozuvlari normalizatsiya qilinadi.
- Har recovery uchun `serverRecoveryLog` va `SERVER_RECOVERY` audit yozuvi yaratiladi.
- Server recovery muvaffaqiyatli bo‘lsa eski client outbox tozalanadi va telefon darhol serverdan qayta sync qiladi.
- 0.9.2 backup format (schemaVersion=2) import bilan mos; yangi export nomi `ToyBola_backup_0.9.4.json`.
- 0.9.1/0.9.2 dagi dailyIssues Admin sync, fresh-install bootstrap, Device Code server-first tekshiruvi va Sababli/Sababsiz sifat raundi saqlanadi.

## 0.9.3 recovery tartibi

1. GitHub rootiga `ToyBola_Factory_Source_0.9.3.zip` yuklang va `.github/workflows/main.yml` ni 0.9.3 workflow bilan almashtiring.
2. Actions: Android test/lint/APK va Firebase rules/functions deploy ikkalasi yashil bo‘lsin.
3. Ma’lumoti bor Brigadir/Sifat telefonlariga 0.9.3 ni **UPDATE** qiling; appni o‘chirmang.
4. Ulardan `Zaxira va server tiklash` → `Lokal backup chiqarish`. 0.9.2 da chiqarilgan to‘g‘ri backup fayllar ham ishlaydi.
5. Admin telefonida backup(lar)ni ketma-ket import qiling. Har importdan keyin server-side recovery bajariladi.
6. Server yuklash muvaffaqiyatli bo‘lgach bitta test telefonda appni o‘chirib fresh install qiling. Barcha ma’lumot serverdan qaytsa migratsiya yakunlangan.

## Xavfsizlik

- Recovery endpoint faqat serverdagi faol `ADMIN` roliga ruxsat beradi.
- Payload checksum va hajm tekshiriladi, ID/sana maydonlari validatsiya qilinadi.
- Service-account private key APK/repository ichida yo‘q.
- Normal foydalanuvchi yozuvlari recovery endpointdan foydalana olmaydi.
