package uz.toybola.factory.core.data

import android.content.Context
import org.w3c.dom.Document
import org.w3c.dom.Element
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.time.LocalDate
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.xml.XMLConstants
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

object TpPayrollXlsxExporter {
    private data class DetailRow(
        val date: String,
        val machine: String,
        val brigade: String,
        val shift: String,
        val article: String,
        val product: String,
        val detail: String,
        val quantity: Int,
        val price: Double,
        val amount: Long
    )

    private data class SalaryRow(val name: String, val amount: Long)
    private data class AssemblyDetailRow(
        val date: String,
        val article: String,
        val product: String,
        val quantity: Double,
        val price: Long,
        val amount: Long
    )

    fun writeAssembly(context: Context, output: OutputStream, data: AssemblyData, from: String, to: String) {
        val start = LocalDate.parse(from)
        val end = LocalDate.parse(to)
        require(!end.isBefore(start)) { "Excel davri noto‘g‘ri" }
        val activeBrigades = data.brigades.filter { !it.archived && !it.deleted }.sortedBy { it.name.lowercase() }
        val entries = context.assets.open("Sborka.xlsx").use(::unzip)
        val salaryGroups = mutableListOf<List<SalaryRow>>()

        repeat(4) { brigadeIndex ->
            val brigade = activeBrigades.getOrNull(brigadeIndex)
            val days = brigade?.let { selected ->
                data.workerDays.filter { it.brigadeId == selected.id && it.date in from..to }
            }.orEmpty()
            val rows = days.sortedWith(compareBy<WorkerDay> { it.date }.thenBy { it.workerId }).flatMap { day ->
                day.entries.map { entry ->
                    AssemblyDetailRow(day.date, entry.articleSnapshot, entry.productNameSnapshot, entry.quantity, entry.unitPriceSnapshot, entry.amount)
                }
            }
            val salaries = brigade?.let { selected ->
                data.workers.filter { it.brigadeId == selected.id && !it.archived }.sortedBy { it.name.lowercase() }.map { worker ->
                    SalaryRow(worker.name, days.filter { it.workerId == worker.id }.sumOf { it.earned })
                }
            }.orEmpty()
            salaryGroups += salaries
            val workedDays = days.asSequence().filter { it.worked }.map { "${it.workerId}|${it.date}" }.distinct().count()
            entries["xl/worksheets/sheet${brigadeIndex + 1}.xml"] = editAssemblyDetails(
                entries.getValue("xl/worksheets/sheet${brigadeIndex + 1}.xml"),
                brigade?.name ?: "${brigadeIndex + 1}-brigada", rows, salaries.sumOf { it.amount }, workedDays
            )
        }

        val prices = data.products.filterNot { it.archived }.map { product ->
            listOf(product.article, product.name, product.currentPrice)
        }.sortedBy { it[0].toString() }
        entries["xl/worksheets/sheet5.xml"] = editAssemblyPrices(entries.getValue("xl/worksheets/sheet5.xml"), prices)
        entries["xl/worksheets/sheet6.xml"] = editAssemblySalaries(
            entries.getValue("xl/worksheets/sheet6.xml"), activeBrigades.take(4).map { it.name }, salaryGroups, from, to
        )
        ZipOutputStream(output).use { zip ->
            entries.forEach { (path, bytes) ->
                zip.putNextEntry(ZipEntry(path)); zip.write(bytes); zip.closeEntry()
            }
        }
    }

    fun write(context: Context, output: OutputStream, data: TpData, from: String, to: String) {
        val start = LocalDate.parse(from)
        val end = LocalDate.parse(to)
        require(!end.isBefore(start)) { "Excel davri noto‘g‘ri" }

        val orders = data.orders.associateBy { it.id }
        val machines = data.machines.associateBy { it.id }
        val brigades = data.brigades.associateBy { it.id }
        val shifts = data.shifts.associateBy { it.id }
        val receipts = data.receipts.filter { it.date in from..to }
        val details = receipts.sortedWith(compareBy<TpReceipt> { it.date }.thenBy { it.workerNameSnapshot }.thenBy { it.createdAt })
            .map { receipt ->
                val order = orders[receipt.orderId]
                DetailRow(
                    date = receipt.date,
                    machine = machines[receipt.machineId]?.number?.let { "$it" }.orEmpty(),
                    brigade = brigades[receipt.brigadeId]?.name.orEmpty(),
                    shift = shifts[receipt.shiftId]?.name.orEmpty(),
                    article = order?.articleSnapshot.orEmpty(),
                    product = order?.productNameSnapshot.orEmpty(),
                    detail = receipt.detailNameSnapshot,
                    quantity = receipt.creditedPieces,
                    price = receipt.unitPriceSnapshot,
                    amount = receipt.earnedAmount
                )
            }
        val salaries = data.workers.filterNot { it.archived }.sortedBy { it.name.lowercase() }.map { worker ->
            SalaryRow(
                name = worker.name,
                amount = receipts.filter { it.workerId == worker.id }.sumOf { it.earnedAmount } +
                    data.extraHours.filter { it.workerId == worker.id && it.date in from..to }.sumOf { it.amount }
            )
        }
        val workedDays = data.attendance.asSequence()
            .filter { it.present && it.date in from..to }
            .map { "${it.workerId}|${it.date}" }
            .distinct().count()
        val prices = data.products.filterNot { it.archived }.flatMap { product ->
            product.details.filterNot { it.archived }.map { detail ->
                listOf(product.article, product.name, detail.name, detail.unitPrice)
            }
        }.sortedWith(compareBy<List<Any>> { it[0].toString() }.thenBy { it[2].toString() })

        val entries = context.assets.open("Tp.xlsx").use(::unzip)
        entries["xl/worksheets/sheet1.xml"] = editDetails(
            entries.getValue("xl/worksheets/sheet1.xml"), details, salaries.sumOf { it.amount }, workedDays
        )
        entries["xl/worksheets/sheet2.xml"] = editPrices(entries.getValue("xl/worksheets/sheet2.xml"), prices)
        entries["xl/worksheets/sheet3.xml"] = editSalaries(entries.getValue("xl/worksheets/sheet3.xml"), salaries, from, to)
        ZipOutputStream(output).use { zip ->
            entries.forEach { (path, bytes) ->
                zip.putNextEntry(ZipEntry(path))
                zip.write(bytes)
                zip.closeEntry()
            }
        }
    }

    private fun editDetails(source: ByteArray, values: List<DetailRow>, totalSalary: Long, workedDays: Int): ByteArray {
        val document = parse(source)
        setCell(document, "A1", "Barcha TP ishchilari")
        val sheetData = document.first("sheetData")
        val templates = sheetData.rows().associateBy { it.rowNumber() }
        sheetData.removeRowsFrom(3)
        val count = maxOf(30, values.size)
        repeat(count) { index ->
            val rowNumber = index + 3
            val template = when {
                index == count - 1 -> templates.getValue(32)
                index == 0 -> templates.getValue(3)
                else -> templates.getValue(4)
            }
            val row = template.cloneForRow(rowNumber)
            values.getOrNull(index)?.let { value ->
                row.setValues(
                    listOf(value.date, value.machine, value.brigade, value.shift, value.article, value.product, value.detail),
                    listOf(value.quantity.toDouble(), value.price, value.amount.toDouble()),
                    numericStartColumn = 7
                )
            } ?: row.clearValues()
            sheetData.appendChild(row)
        }
        val salaryRowNumber = count + 3
        val daysRowNumber = salaryRowNumber + 1
        val salaryRow = templates.getValue(33).cloneForRow(salaryRowNumber)
        salaryRow.setText("H", "Jami maosh")
        salaryRow.setNumber("J", totalSalary.toDouble())
        sheetData.appendChild(salaryRow)
        val daysRow = templates.getValue(34).cloneForRow(daysRowNumber)
        daysRow.setText("H", "Ishlagan kunlari")
        daysRow.setNumber("J", workedDays.toDouble())
        sheetData.appendChild(daysRow)
        updateMerge(document, "H33:I33", "H$salaryRowNumber:I$salaryRowNumber")
        updateMerge(document, "H34:I34", "H$daysRowNumber:I$daysRowNumber")
        updateDimension(document, "A1:J$daysRowNumber")
        return serialize(document)
    }

    private fun editPrices(source: ByteArray, prices: List<List<Any>>): ByteArray {
        val document = parse(source)
        val sheetData = document.first("sheetData")
        val template = sheetData.rows().firstOrNull { it.rowNumber() == 2 }
            ?: error("TP Narxlar shablon qatori topilmadi")
        sheetData.removeRowsFrom(2)
        val count = maxOf(1, prices.size)
        repeat(count) { index ->
            val row = template.cloneForRow(index + 2)
            val value = prices.getOrNull(index)
            if (value == null) row.clearValues() else {
                row.setText("A", value[0].toString())
                row.setText("B", value[1].toString())
                row.setText("C", value[2].toString())
                row.setNumber("D", value[3] as Double)
            }
            sheetData.appendChild(row)
        }
        updateDimension(document, "A1:D${count + 1}")
        return serialize(document)
    }

    private fun editSalaries(source: ByteArray, salaries: List<SalaryRow>, from: String, to: String): ByteArray {
        val document = parse(source)
        setCell(document, "A1", "Sana: ${displayDate(from)}–${displayDate(to)}")
        val sheetData = document.first("sheetData")
        val templates = sheetData.rows().associateBy { it.rowNumber() }
        sheetData.removeRowsFrom(3)
        val count = maxOf(50, salaries.size)
        repeat(count) { index ->
            val rowNumber = index + 3
            val template = when {
                index == count - 1 -> templates.getValue(52)
                index == 0 -> templates.getValue(3)
                else -> templates.getValue(4)
            }
            val row = template.cloneForRow(rowNumber)
            row.setNumber("A", (index + 1).toDouble())
            salaries.getOrNull(index)?.let { salary ->
                row.setText("B", salary.name)
                row.setNumber("C", salary.amount.toDouble())
            } ?: run {
                row.setText("B", "")
                row.setText("C", "")
            }
            sheetData.appendChild(row)
        }
        val summaryRowNumber = count + 3
        val summary = templates.getValue(53).cloneForRow(summaryRowNumber)
        summary.setText("B", "Jami summa:")
        summary.setNumber("C", salaries.sumOf { it.amount }.toDouble())
        sheetData.appendChild(summary)
        updateDimension(document, "A1:C$summaryRowNumber")
        return serialize(document)
    }

    private fun editAssemblyDetails(
        source: ByteArray,
        brigadeName: String,
        values: List<AssemblyDetailRow>,
        totalSalary: Long,
        workedDays: Int
    ): ByteArray {
        val document = parse(source)
        setCell(document, "A1", brigadeName)
        val sheetData = document.first("sheetData")
        val templates = sheetData.rows().associateBy { it.rowNumber() }
        sheetData.removeRowsFrom(3)
        val count = maxOf(30, values.size)
        repeat(count) { index ->
            val rowNumber = index + 3
            val template = when {
                index == count - 1 -> templates.getValue(32)
                index == 0 -> templates.getValue(3)
                else -> templates.getValue(4)
            }
            val row = template.cloneForRow(rowNumber)
            values.getOrNull(index)?.let { value ->
                row.setText("A", value.date)
                row.setText("B", value.article)
                row.setText("C", value.product)
                row.setNumber("D", value.quantity)
                row.setNumber("E", value.price.toDouble())
                row.setNumber("F", value.amount.toDouble())
            } ?: row.clearValues()
            sheetData.appendChild(row)
        }
        val salaryRowNumber = count + 3
        val daysRowNumber = salaryRowNumber + 1
        val salaryRow = templates.getValue(33).cloneForRow(salaryRowNumber)
        salaryRow.setText("D", "Maosh")
        salaryRow.setNumber("F", totalSalary.toDouble())
        sheetData.appendChild(salaryRow)
        val daysRow = templates.getValue(34).cloneForRow(daysRowNumber)
        daysRow.setText("D", "Ishlagan kunlari")
        daysRow.setNumber("F", workedDays.toDouble())
        sheetData.appendChild(daysRow)
        updateMerge(document, "D33:E33", "D$salaryRowNumber:E$salaryRowNumber")
        updateMerge(document, "D34:E34", "D$daysRowNumber:E$daysRowNumber")
        updateDimension(document, "A1:F$daysRowNumber")
        return serialize(document)
    }

    private fun editAssemblyPrices(source: ByteArray, prices: List<List<Any>>): ByteArray {
        val document = parse(source)
        val sheetData = document.first("sheetData")
        val template = sheetData.rows().firstOrNull { it.rowNumber() == 2 }
            ?: error("Sborka Narxlar shablon qatori topilmadi")
        sheetData.removeRowsFrom(2)
        val count = maxOf(1, prices.size)
        repeat(count) { index ->
            val row = template.cloneForRow(index + 2)
            prices.getOrNull(index)?.let { value ->
                row.setText("A", value[0].toString())
                row.setText("B", value[1].toString())
                row.setNumber("C", (value[2] as Long).toDouble())
            } ?: row.clearValues()
            sheetData.appendChild(row)
        }
        updateDimension(document, "A1:C${count + 1}")
        return serialize(document)
    }

    private fun editAssemblySalaries(
        source: ByteArray,
        brigadeNames: List<String>,
        groups: List<List<SalaryRow>>,
        from: String,
        to: String
    ): ByteArray {
        val document = parse(source)
        setCell(document, "A1", "${displayDate(from)}–${displayDate(to)}")
        val titleColumns = listOf("A", "D", "G", "J")
        titleColumns.forEachIndexed { index, column ->
            setCell(document, "${column}2", brigadeNames.getOrNull(index) ?: "${index + 1}-brigada")
        }
        val sheetData = document.first("sheetData")
        val templates = sheetData.rows().associateBy { it.rowNumber() }
        sheetData.removeRowsFrom(4)
        val count = maxOf(50, groups.maxOfOrNull { it.size } ?: 0)
        repeat(count) { index ->
            val row = templates.getValue(if (index == 0) 4 else 5).cloneForRow(index + 4)
            titleColumns.forEachIndexed { brigadeIndex, numberColumn ->
                val nameColumn = columnName(brigadeIndex * 3 + 1)
                val salaryColumn = columnName(brigadeIndex * 3 + 2)
                row.setNumber(numberColumn, (index + 1).toDouble())
                groups.getOrNull(brigadeIndex)?.getOrNull(index)?.let { salary ->
                    row.setText(nameColumn, salary.name)
                    row.setNumber(salaryColumn, salary.amount.toDouble())
                } ?: run {
                    row.setText(nameColumn, "")
                    row.setText(salaryColumn, "")
                }
            }
            sheetData.appendChild(row)
        }
        val summaryRowNumber = count + 4
        val summary = templates.getValue(58).cloneForRow(summaryRowNumber)
        summary.setText("K", "Umumiy summa:")
        summary.setNumber("L", groups.flatten().sumOf { it.amount }.toDouble())
        sheetData.appendChild(summary)
        updateDimension(document, "A1:L$summaryRowNumber")
        return serialize(document)
    }

    private fun unzip(input: java.io.InputStream): LinkedHashMap<String, ByteArray> {
        val entries = linkedMapOf<String, ByteArray>()
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val bytes = ByteArrayOutputStream().also { output -> zip.copyTo(output) }.toByteArray()
                entries[entry.name] = bytes
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        return entries
    }

    private fun parse(bytes: ByteArray): Document {
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = true
            runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
            runCatching { setFeature("http://xml.org/sax/features/external-general-entities", false) }
            runCatching { setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
            // Some Android XML providers do not expose the JAXP 1.5 properties.
            // The entity/doctype features above still keep template parsing closed.
            runCatching { setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", "") }
            runCatching { setAttribute("http://javax.xml.XMLConstants/property/accessExternalSchema", "") }
        }
        return factory.newDocumentBuilder().parse(ByteArrayInputStream(bytes))
    }

    private fun serialize(document: Document): ByteArray {
        val output = ByteArrayOutputStream()
        val factory = TransformerFactory.newInstance().apply {
            runCatching { setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", "") }
            runCatching { setAttribute("http://javax.xml.XMLConstants/property/accessExternalStylesheet", "") }
        }
        factory.newTransformer().apply {
            setOutputProperty(OutputKeys.ENCODING, "UTF-8")
            setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no")
            transform(DOMSource(document), StreamResult(output))
        }
        return output.toByteArray()
    }

    private fun Element.cloneForRow(rowNumber: Int): Element {
        val clone = cloneNode(true) as Element
        clone.setAttribute("r", rowNumber.toString())
        clone.cells().forEach { cell ->
            val column = cell.getAttribute("r").takeWhile { it.isLetter() }
            cell.setAttribute("r", "$column$rowNumber")
        }
        return clone
    }

    private fun Element.setValues(text: List<String>, numbers: List<Double>, numericStartColumn: Int) {
        text.forEachIndexed { index, value -> setText(columnName(index), value) }
        numbers.forEachIndexed { index, value -> setNumber(columnName(numericStartColumn + index), value) }
    }

    private fun Element.clearValues() = cells().forEach { it.clearCellValue() }

    private fun Element.setText(column: String, value: String) {
        val cell = cell(column) ?: return
        cell.clearCellValue()
        cell.setAttribute("t", "inlineStr")
        val inline = ownerDocument.createElementNS(NS, "is")
        val text = ownerDocument.createElementNS(NS, "t")
        text.setAttributeNS(XMLConstants.XML_NS_URI, "xml:space", "preserve")
        text.textContent = value
        inline.appendChild(text)
        cell.appendChild(inline)
    }

    private fun Element.setNumber(column: String, value: Double) {
        val cell = cell(column) ?: return
        cell.clearCellValue()
        cell.removeAttribute("t")
        val node = ownerDocument.createElementNS(NS, "v")
        node.textContent = if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()
        cell.appendChild(node)
    }

    private fun Element.clearCellValue() {
        removeAttribute("t")
        while (firstChild != null) removeChild(firstChild)
    }

    private fun Element.cell(column: String): Element? = cells().firstOrNull {
        it.getAttribute("r").takeWhile(Char::isLetter) == column
    }

    private fun Element.cells(): List<Element> = childElements("c")
    private fun Element.rows(): List<Element> = childElements("row")
    private fun Element.rowNumber(): Int = getAttribute("r").toInt()
    private fun Element.childElements(localName: String): List<Element> = buildList {
        val nodes = childNodes
        for (index in 0 until nodes.length) {
            val node = nodes.item(index)
            if (node is Element && node.localName == localName) add(node)
        }
    }

    private fun Element.removeRowsFrom(firstRow: Int) = rows()
        .filter { it.rowNumber() >= firstRow }
        .forEach { removeChild(it) }

    private fun Document.first(localName: String): Element =
        getElementsByTagNameNS("*", localName).item(0) as? Element ?: error("XLSX $localName topilmadi")

    private fun setCell(document: Document, reference: String, value: String) {
        val cell = document.getElementsByTagNameNS("*", "c").let { nodes ->
            (0 until nodes.length).asSequence().map { nodes.item(it) as Element }
                .firstOrNull { it.getAttribute("r") == reference }
        } ?: return
        val column = reference.takeWhile { it.isLetter() }
        (cell.parentNode as Element).setText(column, value)
    }

    private fun updateMerge(document: Document, old: String, new: String) {
        val nodes = document.getElementsByTagNameNS("*", "mergeCell")
        for (index in 0 until nodes.length) {
            val element = nodes.item(index) as Element
            if (element.getAttribute("ref") == old) element.setAttribute("ref", new)
        }
    }

    private fun updateDimension(document: Document, reference: String) {
        val dimension = document.getElementsByTagNameNS("*", "dimension").item(0) as? Element ?: return
        dimension.setAttribute("ref", reference)
    }

    private fun displayDate(value: String): String = LocalDate.parse(value).let { date ->
        "${date.dayOfMonth.toString().padStart(2, '0')}.${date.monthValue.toString().padStart(2, '0')}.${date.year}"
    }

    private fun columnName(index: Int): String {
        var value = index + 1
        return buildString {
            while (value > 0) {
                insert(0, ('A'.code + (value - 1) % 26).toChar())
                value = (value - 1) / 26
            }
        }
    }

    private const val NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
}
