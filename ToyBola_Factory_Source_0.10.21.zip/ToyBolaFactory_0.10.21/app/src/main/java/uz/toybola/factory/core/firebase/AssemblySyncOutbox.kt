package uz.toybola.factory.core.firebase

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import uz.toybola.factory.core.data.*

object SyncOutboxEvents {
    private val _revision = MutableStateFlow(0L)
    val revision: StateFlow<Long> = _revision.asStateFlow()

    internal fun notifyChanged() {
        _revision.value = _revision.value + 1L
    }
}

class AssemblySyncOutbox(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun recordDiff(before: AssemblyData, after: AssemblyData) {
        synchronized(LOCK) {
            val entries = entriesLocked().toMutableMap()
            addChanged(entries, before.brigades, after.brigades, { it.id }) { "BRIGADE:${it.id}" }
            addChanged(entries, before.workers, after.workers, { it.id }) { "WORKER:${it.id}" }
            addChanged(entries, before.products, after.products, { it.id }) { "PRODUCT:${it.id}" }
            addChanged(entries, before.brigadeFk, after.brigadeFk, { it.brigadeId }) { "BRIGADE_FK:${it.brigadeId}" }
            addChanged(entries, before.workerDays, after.workerDays, { "${it.workerId}|${it.date}" }) { "WORKER_DAY:${it.workerId}|${it.date}" }
            addChanged(entries, before.brigadeDays, after.brigadeDays, { "${it.brigadeId}|${it.date}" }) { "BRIGADE_DAY:${it.brigadeId}|${it.date}" }
            addChanged(entries, before.qualityRounds, after.qualityRounds, { "${it.workerId}|${it.date}|${it.round}" }) { "QUALITY_ROUND:${it.workerId}|${it.date}|${it.round}" }
            addChanged(entries, before.dailyIssues, after.dailyIssues, { it.id }) { "DAILY_ISSUE:${it.id}" }
            val afterIssues = after.dailyIssues.associateBy { it.id }
            before.dailyIssues.filter { afterIssues[it.id] == null }.forEach {
                touch(entries, "DAILY_ISSUE_DELETE:${it.id}")
                entries.remove("DAILY_ISSUE:${it.id}")
            }
            val oldAudit = before.auditLog.associateBy { it.id }
            after.auditLog.filter { oldAudit[it.id] != it }.forEach { touch(entries, "AUDIT:${it.id}") }
            if (before.workHours != after.workHours || before.efficiencyNorm != after.efficiencyNorm ||
                before.roundTimes != after.roundTimes || before.monitoringWeights != after.monitoringWeights ||
                before.preparedYears != after.preparedYears
            ) touch(entries, "SETTINGS:assembly")
            saveLocked(entries)
        }
    }

    fun markAll(data: AssemblyData) {
        synchronized(LOCK) {
            val entries = entriesLocked().toMutableMap()
            data.brigades.forEach { touch(entries, "BRIGADE:${it.id}") }
            data.workers.forEach { touch(entries, "WORKER:${it.id}") }
            data.products.forEach { touch(entries, "PRODUCT:${it.id}") }
            data.brigadeFk.forEach { touch(entries, "BRIGADE_FK:${it.brigadeId}") }
            data.workerDays.forEach { touch(entries, "WORKER_DAY:${it.workerId}|${it.date}") }
            data.brigadeDays.forEach { touch(entries, "BRIGADE_DAY:${it.brigadeId}|${it.date}") }
            data.qualityRounds.forEach { touch(entries, "QUALITY_ROUND:${it.workerId}|${it.date}|${it.round}") }
            data.dailyIssues.forEach { touch(entries, "DAILY_ISSUE:${it.id}") }
            data.auditLog.forEach { touch(entries, "AUDIT:${it.id}") }
            touch(entries, "SETTINGS:assembly")
            saveLocked(entries)
        }
    }

    fun snapshot(): Map<String, Long> = synchronized(LOCK) { entriesLocked() }
    fun pending(): Set<String> = snapshot().keys
    fun acknowledge(key: String, version: Long) = synchronized(LOCK) {
        val entries = entriesLocked().toMutableMap()
        if (entries[key] == version) {
            entries.remove(key)
            saveLocked(entries)
        }
    }
    fun remove(key: String) = removeAll(setOf(key))
    fun removeAll(keys: Set<String>) = synchronized(LOCK) {
        if (keys.isEmpty()) return@synchronized
        val entries = entriesLocked().toMutableMap()
        if (entries.keys.removeAll(keys)) saveLocked(entries)
    }
    fun isEmpty(): Boolean = synchronized(LOCK) { entriesLocked().isEmpty() }
    fun clear() = synchronized(LOCK) { saveLocked(emptyMap()) }

    private fun saveLocked(entries: Map<String, Long>) {
        val json = JSONObject()
        entries.forEach { (key, version) -> json.put(key, version) }
        prefs.edit().putString(KEY_ENTRIES, json.toString()).remove(KEY_PENDING).commit()
        SyncOutboxEvents.notifyChanged()
    }

    private fun <T, K> addChanged(
        target: MutableMap<String, Long>, before: List<T>, after: List<T>, key: (T) -> K, encode: (T) -> String
    ) {
        val old = before.associateBy(key)
        after.filter { old[key(it)] != it }.forEach { touch(target, encode(it)) }
    }

    private fun entriesLocked(): Map<String, Long> {
        val raw = prefs.getString(KEY_ENTRIES, null)
        if (!raw.isNullOrBlank()) {
            return runCatching {
                val json = JSONObject(raw)
                json.keys().asSequence().associateWith { key -> json.optLong(key, 0L) }
            }.getOrDefault(emptyMap())
        }
        return prefs.getStringSet(KEY_PENDING, emptySet()).orEmpty().associateWith { 0L }
    }

    private fun touch(entries: MutableMap<String, Long>, key: String) {
        val previous = entries[key] ?: 0L
        entries[key] = maxOf(System.currentTimeMillis(), previous + 1L)
    }

    companion object {
        private const val PREFS = "toy_bola_sync_outbox"
        private const val KEY_PENDING = "pending"
        private const val KEY_ENTRIES = "pending_entries_v2"
        private val LOCK = Any()
    }
}
