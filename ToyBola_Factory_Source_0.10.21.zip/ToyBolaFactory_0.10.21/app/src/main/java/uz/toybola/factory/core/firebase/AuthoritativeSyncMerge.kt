package uz.toybola.factory.core.firebase

/**
 * Merges one server collection with the small set of records that still have an unacknowledged
 * local outbox write. The server is authoritative for every other id, including ids that are no
 * longer present remotely. A server tombstone always wins over an old local write.
 */
internal fun <T> authoritativeMergeById(
    local: List<T>,
    remote: List<T>,
    id: (T) -> String,
    localDirtyIds: Set<String> = emptySet(),
    localDeleteIds: Set<String> = emptySet(),
    serverDeletedIds: Set<String> = emptySet()
): List<T> {
    val values = LinkedHashMap<String, T>()
    remote.forEach { item ->
        val itemId = id(item)
        if (itemId !in localDeleteIds && itemId !in serverDeletedIds) values[itemId] = item
    }
    local.forEach { item ->
        val itemId = id(item)
        if (itemId in localDirtyIds && itemId !in localDeleteIds && itemId !in serverDeletedIds) {
            values[itemId] = item
        }
    }
    return values.values.toList()
}

internal fun tombstoneIds(tombstones: Set<String>, prefix: String): Set<String> =
    tombstones.asSequence()
        .filter { it.startsWith("$prefix:") }
        .map { it.substringAfter(':') }
        .filter { it.isNotBlank() }
        .toSet()

internal fun outboxIds(keys: Set<String>, prefix: String): Set<String> =
    keys.asSequence()
        .filter { it.startsWith("$prefix:") }
        .map { it.substringAfter(':') }
        .filter { it.isNotBlank() }
        .toSet()

internal fun staleOutboxKeysForTombstones(tombstones: Set<String>): Set<String> = buildSet {
    tombstones.forEach { target ->
        val prefix = target.substringBefore(':')
        val id = target.substringAfter(':', "")
        if (prefix.isBlank() || id.isBlank()) return@forEach
        add(target)
        add("${prefix}_DELETE:$id")
    }
}
