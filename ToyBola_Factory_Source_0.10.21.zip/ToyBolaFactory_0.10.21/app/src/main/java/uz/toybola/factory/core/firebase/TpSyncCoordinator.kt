package uz.toybola.factory.core.firebase

import android.content.Context
import com.google.firebase.functions.FirebaseFunctions
import uz.toybola.factory.core.data.TpData
import uz.toybola.factory.core.data.TpDataRepository
import uz.toybola.factory.core.security.UserAccessPolicy

class TpSyncCoordinator(context: Context) {
    private val appContext = context.applicationContext
    private val repository = TpDataRepository(appContext)
    private val outbox = TpSyncOutbox(appContext)
    private val functions = FirebaseFunctions.getInstance("europe-west1")

    suspend fun sync(@Suppress("UNUSED_PARAMETER") policy: UserAccessPolicy, @Suppress("UNUSED_PARAMETER") uid: String) {
        // Server-first bootstrap is deliberate. Empty server collections are authoritative and
        // must clear stale local cache; automatic "seed when empty" was the resurrection bug.
        reconcile(ServerTpSnapshotRepository(appContext).download().getOrThrow())
        if (!outbox.isEmpty()) {
            flushOutbox()
            reconcile(ServerTpSnapshotRepository(appContext).download().getOrThrow())
        }
    }

    private fun reconcile(snapshot: ServerTpSnapshotResult) {
        outbox.removeAll(staleOutboxKeysForTombstones(snapshot.tombstones))
        val dirty = outbox.pending()
        repository.replaceFromServer(
            merge(repository.load(), snapshot.data, snapshot.hasSettings, dirty, snapshot.tombstones)
        )
    }

    private suspend fun flushOutbox() {
        val entries = outbox.snapshot()
        if (entries.isEmpty()) return
        entries.keys.sorted().chunked(180).forEach { chunk ->
            val response = functions.getHttpsCallable("applyTpWrites")
                .call(
                    mapOf(
                        "keys" to chunk,
                        "payload" to repository.encodeForSync(repository.load()),
                        "clientVersion" to "0.10.21"
                    )
                )
                .awaitResult()
            val body = response.data as? Map<*, *> ?: error("TP server sync javobi noto‘g‘ri")
            val applied = (body["applied"] as? List<*>)?.mapNotNull { it?.toString() }.orEmpty()
            if (applied.isEmpty() && chunk.isNotEmpty()) error("TP server sync hech bir yozuvni qabul qilmadi")
            applied.forEach { key -> entries[key]?.let { version -> outbox.acknowledge(key, version) } }
        }
    }

    private fun merge(
        local: TpData,
        remote: TpData,
        hasSettings: Boolean,
        localDirtyKeys: Set<String>,
        serverTombstones: Set<String>
    ): TpData {
        fun dirty(prefix: String) = outboxIds(localDirtyKeys, prefix)
        fun deleted(prefix: String) = outboxIds(localDirtyKeys, "${prefix}_DELETE")
        fun serverDeleted(prefix: String) = tombstoneIds(serverTombstones, prefix)
        return local.copy(
            shops = authoritativeMergeById(local.shops, remote.shops, { it.id }, dirty("TP_SHOP")),
            shifts = authoritativeMergeById(local.shifts, remote.shifts, { it.id }, dirty("TP_SHIFT")),
            brigades = authoritativeMergeById(local.brigades, remote.brigades, { it.id }, dirty("TP_BRIGADE")),
            machines = authoritativeMergeById(local.machines, remote.machines, { it.id }, dirty("TP_MACHINE")),
            workers = authoritativeMergeById(local.workers, remote.workers, { it.id }, dirty("TP_WORKER")),
            products = authoritativeMergeById(local.products, remote.products, { it.id }, dirty("TP_PRODUCT")),
            materials = authoritativeMergeById(local.materials, remote.materials, { it.id }, dirty("TP_MATERIAL")),
            orders = authoritativeMergeById(local.orders, remote.orders, { it.id }, dirty("TP_ORDER"), deleted("TP_ORDER"), serverDeleted("TP_ORDER")),
            jobs = authoritativeMergeById(local.jobs, remote.jobs, { it.id }, dirty("TP_JOB"), deleted("TP_JOB"), serverDeleted("TP_JOB")),
            attendance = authoritativeMergeById(local.attendance, remote.attendance, { it.id }, dirty("TP_ATTENDANCE")),
            receipts = authoritativeMergeById(local.receipts, remote.receipts, { it.id }, dirty("TP_RECEIPT"), deleted("TP_RECEIPT"), serverDeleted("TP_RECEIPT")),
            qualityRounds = authoritativeMergeById(local.qualityRounds, remote.qualityRounds, { it.id }, dirty("TP_QUALITY")),
            dailyIssues = authoritativeMergeById(local.dailyIssues, remote.dailyIssues, { it.id }, dirty("TP_ISSUE")),
            extraHourTypes = authoritativeMergeById(local.extraHourTypes, remote.extraHourTypes, { it.id }, dirty("TP_EXTRA_HOUR_TYPE")),
            extraHours = authoritativeMergeById(local.extraHours, remote.extraHours, { it.id }, dirty("TP_EXTRA_HOUR"), deleted("TP_EXTRA_HOUR"), serverDeleted("TP_EXTRA_HOUR")),
            machineDowntimes = authoritativeMergeById(local.machineDowntimes, remote.machineDowntimes, { it.id }, dirty("TP_MACHINE_DOWNTIME")),
            auditLog = authoritativeMergeById(local.auditLog, remote.auditLog, { it.id }, dirty("TP_AUDIT")).takeLast(3000),
            settings = if (hasSettings && "TP_SETTINGS:tp" !in localDirtyKeys) remote.settings else local.settings
        )
    }
}
