package uz.toybola.factory.core.firebase

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import uz.toybola.factory.core.data.TpData

object TpDataEvents {
    private val _revision = MutableStateFlow(0L)
    val revision: StateFlow<Long> = _revision.asStateFlow()
    fun notifyChanged() { _revision.value = _revision.value + 1L }
}

class TpSyncOutbox(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun recordDiff(before: TpData, after: TpData) {
        synchronized(LOCK) {
        val keys = entriesLocked().toMutableMap()
        addChanged(keys, before.shops, after.shops, { it.id }) { "TP_SHOP:${it.id}" }
        addChanged(keys, before.shifts, after.shifts, { it.id }) { "TP_SHIFT:${it.id}" }
        addChanged(keys, before.brigades, after.brigades, { it.id }) { "TP_BRIGADE:${it.id}" }
        addChanged(keys, before.machines, after.machines, { it.id }) { "TP_MACHINE:${it.id}" }
        addChanged(keys, before.workers, after.workers, { it.id }) { "TP_WORKER:${it.id}" }
        addChanged(keys, before.products, after.products, { it.id }) { "TP_PRODUCT:${it.id}" }
        addChanged(keys, before.materials, after.materials, { it.id }) { "TP_MATERIAL:${it.id}" }
        addChanged(keys, before.orders, after.orders, { it.id }) { "TP_ORDER:${it.id}" }
        val afterOrders = after.orders.associateBy { it.id }
        before.orders.filter { afterOrders[it.id] == null }.forEach { touch(keys, "TP_ORDER_DELETE:${it.id}"); keys.remove("TP_ORDER:${it.id}") }
        addChanged(keys, before.jobs, after.jobs, { it.id }) { "TP_JOB:${it.id}" }
        val afterJobs = after.jobs.associateBy { it.id }
        before.jobs.filter { afterJobs[it.id] == null }.forEach { touch(keys, "TP_JOB_DELETE:${it.id}"); keys.remove("TP_JOB:${it.id}") }
        addChanged(keys, before.attendance, after.attendance, { it.id }) { "TP_ATTENDANCE:${it.id}" }
        addChanged(keys, before.receipts, after.receipts, { it.id }) { "TP_RECEIPT:${it.id}" }
        val afterReceipts = after.receipts.associateBy { it.id }
        before.receipts.filter { afterReceipts[it.id] == null }.forEach { touch(keys, "TP_RECEIPT_DELETE:${it.id}"); keys.remove("TP_RECEIPT:${it.id}") }
        addChanged(keys, before.qualityRounds, after.qualityRounds, { it.id }) { "TP_QUALITY:${it.id}" }
        addChanged(keys, before.dailyIssues, after.dailyIssues, { it.id }) { "TP_ISSUE:${it.id}" }
        addChanged(keys, before.extraHourTypes, after.extraHourTypes, { it.id }) { "TP_EXTRA_HOUR_TYPE:${it.id}" }
        addChanged(keys, before.extraHours, after.extraHours, { it.id }) { "TP_EXTRA_HOUR:${it.id}" }
        val afterExtraHours = after.extraHours.associateBy { it.id }
        before.extraHours.filter { afterExtraHours[it.id] == null }.forEach { touch(keys, "TP_EXTRA_HOUR_DELETE:${it.id}"); keys.remove("TP_EXTRA_HOUR:${it.id}") }
        addChanged(keys, before.machineDowntimes, after.machineDowntimes, { it.id }) { "TP_MACHINE_DOWNTIME:${it.id}" }
        addChanged(keys, before.auditLog, after.auditLog, { it.id }) { "TP_AUDIT:${it.id}" }
        if (before.settings != after.settings) touch(keys, "TP_SETTINGS:tp")
        saveLocked(keys)
        }
    }

    fun markAll(data: TpData) {
        synchronized(LOCK) {
        val keys = entriesLocked().toMutableMap()
        data.shops.forEach { touch(keys, "TP_SHOP:${it.id}") }
        data.shifts.forEach { touch(keys, "TP_SHIFT:${it.id}") }
        data.brigades.forEach { touch(keys, "TP_BRIGADE:${it.id}") }
        data.machines.forEach { touch(keys, "TP_MACHINE:${it.id}") }
        data.workers.forEach { touch(keys, "TP_WORKER:${it.id}") }
        data.products.forEach { touch(keys, "TP_PRODUCT:${it.id}") }
        data.materials.forEach { touch(keys, "TP_MATERIAL:${it.id}") }
        data.orders.forEach { touch(keys, "TP_ORDER:${it.id}") }
        data.jobs.forEach { touch(keys, "TP_JOB:${it.id}") }
        data.attendance.forEach { touch(keys, "TP_ATTENDANCE:${it.id}") }
        data.receipts.forEach { touch(keys, "TP_RECEIPT:${it.id}") }
        data.qualityRounds.forEach { touch(keys, "TP_QUALITY:${it.id}") }
        data.dailyIssues.forEach { touch(keys, "TP_ISSUE:${it.id}") }
        data.extraHourTypes.forEach { touch(keys, "TP_EXTRA_HOUR_TYPE:${it.id}") }
        data.extraHours.forEach { touch(keys, "TP_EXTRA_HOUR:${it.id}") }
        data.machineDowntimes.forEach { touch(keys, "TP_MACHINE_DOWNTIME:${it.id}") }
        data.auditLog.forEach { touch(keys, "TP_AUDIT:${it.id}") }
        touch(keys, "TP_SETTINGS:tp")
        saveLocked(keys)
        }
    }

    fun snapshot(): Map<String, Long> = synchronized(LOCK) { entriesLocked() }
    fun pending(): Set<String> = snapshot().keys
    fun acknowledge(key: String, version: Long) = synchronized(LOCK) {
        val entries = entriesLocked().toMutableMap()
        if (entries[key] == version) { entries.remove(key); saveLocked(entries) }
    }
    fun remove(key: String) = removeAll(setOf(key))
    fun removeAll(keys: Set<String>) = synchronized(LOCK) {
        if (keys.isEmpty()) return@synchronized
        val entries = entriesLocked().toMutableMap()
        if (entries.keys.removeAll(keys)) saveLocked(entries)
    }
    fun isEmpty(): Boolean = synchronized(LOCK) { entriesLocked().isEmpty() }
    fun clear() = synchronized(LOCK) { saveLocked(emptyMap()) }

    private fun saveLocked(keys: Map<String, Long>) {
        val json = JSONObject()
        keys.forEach { (key, version) -> json.put(key, version) }
        prefs.edit().putString(KEY_ENTRIES, json.toString()).remove(KEY).commit()
        SyncOutboxEvents.notifyChanged()
    }

    private fun <T, K> addChanged(
        target: MutableMap<String, Long>, before: List<T>, after: List<T>, key: (T) -> K, encode: (T) -> String
    ) {
        val old = before.associateBy(key)
        after.filter { old[key(it)] != it }.forEach { touch(target, encode(it)) }
    }

    private fun entriesLocked(): Map<String, Long> {
        val raw = prefs.getString(KEY_ENTRIES, null)
        if (!raw.isNullOrBlank()) return runCatching {
            val json = JSONObject(raw)
            json.keys().asSequence().associateWith { key -> json.optLong(key, 0L) }
        }.getOrDefault(emptyMap())
        return prefs.getStringSet(KEY, emptySet()).orEmpty().associateWith { 0L }
    }

    private fun touch(entries: MutableMap<String, Long>, key: String) {
        val previous = entries[key] ?: 0L
        entries[key] = maxOf(System.currentTimeMillis(), previous + 1L)
    }

    companion object {
        private const val PREFS = "toy_bola_tp_sync_outbox"
        private const val KEY = "pending"
        private const val KEY_ENTRIES = "pending_entries_v2"
        private val LOCK = Any()
    }
}
