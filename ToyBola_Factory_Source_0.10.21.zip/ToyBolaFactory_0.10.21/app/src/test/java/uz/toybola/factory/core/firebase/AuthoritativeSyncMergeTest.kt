package uz.toybola.factory.core.firebase

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class AuthoritativeSyncMergeTest {
    private data class Row(val id: String, val value: String)

    @Test
    fun serverAbsenceRemovesCleanStaleLocalRow() {
        val merged = authoritativeMergeById(
            local = listOf(Row("deleted", "old"), Row("kept", "old")),
            remote = listOf(Row("kept", "server")),
            id = Row::id
        )

        assertEquals(listOf(Row("kept", "server")), merged)
    }

    @Test
    fun pendingOfflineUpdateWinsUntilItIsAcknowledged() {
        val merged = authoritativeMergeById(
            local = listOf(Row("same", "offline"), Row("new", "local")),
            remote = listOf(Row("same", "server")),
            id = Row::id,
            localDirtyIds = setOf("same", "new")
        )

        assertEquals(listOf(Row("same", "offline"), Row("new", "local")), merged)
    }

    @Test
    fun tombstoneAlwaysBeatsStaleDirtyUpdate() {
        val merged = authoritativeMergeById(
            local = listOf(Row("gone", "stale"), Row("safe", "local")),
            remote = listOf(Row("gone", "resurrected"), Row("safe", "server")),
            id = Row::id,
            localDirtyIds = setOf("gone"),
            serverDeletedIds = setOf("gone")
        )

        assertFalse(merged.any { it.id == "gone" })
        assertEquals(listOf(Row("safe", "server")), merged)
    }

    @Test
    fun tombstoneClearsBothUpsertAndDeleteOutboxForms() {
        val stale = staleOutboxKeysForTombstones(setOf("TP_ORDER:123"))

        assertEquals(setOf("TP_ORDER:123", "TP_ORDER_DELETE:123"), stale)
    }
}
