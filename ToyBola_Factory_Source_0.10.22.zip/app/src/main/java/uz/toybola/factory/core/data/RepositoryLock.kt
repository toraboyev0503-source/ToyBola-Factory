package uz.toybola.factory.core.data

/** All repository instances (UI, worker and snapshot) share the same read/modify/write lock. */
object RepositoryLock { val monitor = Any() }
