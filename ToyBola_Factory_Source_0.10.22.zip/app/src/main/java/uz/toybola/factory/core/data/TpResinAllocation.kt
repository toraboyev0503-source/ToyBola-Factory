package uz.toybola.factory.core.data

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale

enum class TpResinAdditionKind { ROUND_25, MANUAL }

data class TpResinAddition(
    val id: String,
    val resinCode: String,
    val kilograms: Double,
    val kind: TpResinAdditionKind,
    val createdAt: String,
    val createdBy: String
)

/** Stock is recorded to one gram; binary floating point must not create a phantom 25 kg bag. */
fun resinKg(value: Double): Double {
    require(value.isFinite() && value >= 0.0) { "Seryo kilogrammini to‘g‘ri kiriting" }
    return BigDecimal.valueOf(value).setScale(9, RoundingMode.HALF_UP).setScale(3, RoundingMode.CEILING).toDouble()
}

fun resinRoundUpAddition(totalKg: Double): Double {
    val total = BigDecimal.valueOf(resinKg(totalKg))
    val bag = BigDecimal.valueOf(25)
    return total.divide(bag, 0, RoundingMode.CEILING).multiply(bag).subtract(total).toDouble()
}

val TpPlanJob.extraResinKg: Double get() = resinKg(resinAdditions.sumOf { it.kilograms })
val TpPlanJob.totalResinKg: Double get() = resinKg(requiredResinKg + extraResinKg)
val TpPlanJob.totalColorGrams: Double get() =
    if (requiredResinKg > 0.0) requiredColorGrams * totalResinKg / requiredResinKg else requiredColorGrams

fun TpData.allResinCodes(): List<String> = (
    materials.filter { !it.archived && it.type == TpMaterialType.RESIN }.map { it.code } +
        products.filterNot { it.archived }.flatMap { it.details }.filterNot { it.archived }.flatMap { it.resinOptions() }
    ).map { it.trim().uppercase(Locale.ROOT) }.filter { it.isNotBlank() }.distinct().sorted()
