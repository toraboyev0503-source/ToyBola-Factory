package uz.toybola.factory.core.firebase

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class FirebaseSyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        if (!ServerAuthRepository(applicationContext).hasFirebaseSession()) return Result.success()
        repeat(3) {
            val generation = FirebaseSyncScheduler.generation.get()
            val sync = FirebaseSyncCoordinator(applicationContext).syncNow()
            if (sync.isFailure) return Result.retry()
            if (generation == FirebaseSyncScheduler.generation.get()) return Result.success()
        }
        return Result.retry()
    }
}
