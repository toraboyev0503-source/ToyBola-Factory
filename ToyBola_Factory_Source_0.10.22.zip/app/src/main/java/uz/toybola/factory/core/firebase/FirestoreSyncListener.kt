package uz.toybola.factory.core.firebase

import android.content.Context
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

/**
 * Small real-time invalidation listeners. Business data itself is still downloaded through the
 * permission-scoped callable snapshots; listeners only wake the durable WorkManager sync.
 */
class FirestoreSyncListener(context: Context) {
    private val appContext = context.applicationContext
    private val db = FirebaseFirestore.getInstance()
    private val registrations = mutableListOf<ListenerRegistration>()

    @Synchronized
    fun start(uid: String) {
        stop()
        if (uid.isBlank()) return
        registrations += listen(db.collection("syncState").document("assembly"))
        registrations += listen(db.collection("syncState").document("tp"))
        registrations += listen(db.collection("users").document(uid), policy = true)
    }

    @Synchronized
    fun stop() {
        registrations.forEach(ListenerRegistration::remove)
        registrations.clear()
    }

    private fun listen(
        reference: com.google.firebase.firestore.DocumentReference,
        policy: Boolean = false
    ): ListenerRegistration {
        var initialized = false
        var fingerprint = ""
        return reference.addSnapshotListener { snapshot, error ->
            if (error != null) {
                // Callable snapshots and the periodic/foreground fallback remain available
                // even when a listener loses authorization or its stream is interrupted.
                FirebaseSyncScheduler.enqueue(appContext)
                return@addSnapshotListener
            }
            if (snapshot == null || snapshot.metadata.hasPendingWrites()) return@addSnapshotListener
            val next = snapshot.fingerprint()
            if (!initialized) {
                initialized = true
                fingerprint = next
                FirebaseSyncScheduler.enqueue(appContext)
                return@addSnapshotListener
            }
            if (next == fingerprint || snapshot.metadata.hasPendingWrites()) return@addSnapshotListener
            fingerprint = next
            if (policy) ServerPolicyEvents.notifyChanged()
            FirebaseSyncScheduler.enqueue(appContext)
        }
    }

    private fun DocumentSnapshot.fingerprint(): String = buildString {
        append(exists())
        append('|')
        append(getLong("revision") ?: 0L)
        append('|')
        append(getTimestamp("updatedAt")?.seconds ?: 0L)
        append(':')
        append(getTimestamp("updatedAt")?.nanoseconds ?: 0)
        append('|')
        append(getBoolean("enabled"))
    }
}
