package uz.toybola.factory.core.firebase

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.FirebaseFunctionsException
import com.google.firebase.messaging.FirebaseMessaging
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.SectionAccess
import uz.toybola.factory.core.security.UserAccessPolicy
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.sync.withLock
import uz.toybola.factory.core.data.*

class ServerAuthRepository(context: Context) {
    private val appContext = context.applicationContext
    private val auth = FirebaseAuth.getInstance()
    private val functions = FirebaseFunctions.getInstance("europe-west1")
    private val policyCache = ServerPolicyCache(appContext)
    private val preferences = AppPreferences(appContext)
    private val deviceIdentity = ServerDeviceIdentity(appContext)

    suspend fun signInWithCodes(deviceCode: String, userCode: String, allowOfflineFallback: Boolean): Result<UserAccessPolicy> = SyncSessionGate.mutex.withLock { runCatching {
        val normalizedDevice = deviceCode.trim().uppercase(Locale.ROOT)
        val normalizedUser = userCode.trim().uppercase(Locale.ROOT)
        require(normalizedDevice.isNotBlank() && normalizedUser.isNotBlank()) { "Qurilma va foydalanuvchi kodini kiriting" }

        try {
            val result = functions.getHttpsCallable("loginWithCodes")
                .call(mapOf(
                    "deviceCode" to normalizedDevice,
                    "userCode" to normalizedUser,
                    "installId" to deviceIdentity.installId()
                ))
                .awaitResult()
            val root = result.data as? Map<*, *> ?: error("Server javobi noto‘g‘ri")
            val token = root["token"] as? String ?: error("Kirish tokeni olinmadi")
            val oldUid = auth.currentUser?.uid ?: policyCache.load(preferences.setup()?.userCode.orEmpty())?.uid
            auth.signInWithCustomToken(token).awaitResult()
            if (!oldUid.isNullOrBlank() && oldUid != auth.currentUser?.uid) {
                synchronized(RepositoryLock.monitor) {
                    val assembly = AssemblyDataRepository(appContext)
                    val tp = TpDataRepository(appContext)
                    val assemblyOutbox = AssemblySyncOutbox(appContext)
                    val tpOutbox = TpSyncOutbox(appContext)
                    val recovery = SyncRecoveryStore(appContext, oldUid)
                    if (!assemblyOutbox.isEmpty()) recovery.save(assembly.encodeForSync(assembly.load()), assemblyOutbox.pending(), "Foydalanuvchi almashdi (Sborka)")
                    if (!tpOutbox.isEmpty()) recovery.save(tp.encodeForSync(tp.load()), tpOutbox.pending(), "Foydalanuvchi almashdi (TP)")
                    assemblyOutbox.clear()
                    tpOutbox.clear()
                    assembly.replaceFromServer(AssemblyData())
                    tp.replaceFromServer(TpData())
                }
            }
            val policy = parsePolicy(root["policy"] as? Map<*, *> ?: emptyMap<Any, Any>(), normalizedUser)
            policyCache.save(policy)
            kotlinx.coroutines.withTimeoutOrNull(5_000) { registerFcmTokenBestEffort() }
            policy
        } catch (error: Exception) {
            // Offline fallback is allowed only for genuine connectivity failures. A server-side
            // permission-denied (for example after Device Code rotation) must never fall back to
            // the old locally cached credential.
            if (!allowOfflineFallback || !isConnectivityFailure(error)) throw error
            val setup = preferences.setup()
            val localCodesMatch = setup != null &&
                setup.deviceCode.equals(normalizedDevice, true) &&
                setup.userCode.equals(normalizedUser, true)
            val cached = policyCache.load(normalizedUser)
            if (localCodesMatch && cached != null && auth.currentUser?.uid == cached.uid) cached
            else throw error
        }
    } }


    private fun isConnectivityFailure(error: Exception): Boolean {
        val functionsError = error as? FirebaseFunctionsException
        if (functionsError != null) {
            return functionsError.code == FirebaseFunctionsException.Code.UNAVAILABLE ||
                functionsError.code == FirebaseFunctionsException.Code.DEADLINE_EXCEEDED
        }
        val text = error.message.orEmpty().lowercase(Locale.ROOT)
        return text.contains("network") || text.contains("unavailable") || text.contains("timeout") || text.contains("timed out")
    }

    fun cachedPolicy(userCode: String): UserAccessPolicy? = policyCache.load(userCode)

    suspend fun refreshPolicy(): Result<UserAccessPolicy> = runCatching {
        val user = auth.currentUser ?: error("Server sessiyasi mavjud emas")
        val result = functions.getHttpsCallable("getMyPolicy").call().awaitResult()
        val root = result.data as? Map<*, *> ?: error("Server javobi noto‘g‘ri")
        val policy = parsePolicy(root, root["userCode"]?.toString().orEmpty())
            .copy(uid = user.uid)
        // getMyPolicy refreshes server-side custom claims used by Storage Rules.
        val token = user.getIdToken(false).awaitResult()
        if (root["claimsChanged"] == true || (token.claims["policyRevision"] as? Number)?.toLong() != policy.revision) user.getIdToken(true).awaitResult()
        policyCache.save(policy)
        policy
    }

    fun hasFirebaseSession(): Boolean = auth.currentUser != null

    private suspend fun registerFcmTokenBestEffort() {
        runCatching {
            val token = FirebaseMessaging.getInstance().token.awaitResult()
            functions.getHttpsCallable("registerFcmToken")
                .call(mapOf("installId" to deviceIdentity.installId(), "token" to token))
                .awaitResult()
        }
    }

    private fun parsePolicy(raw: Map<*, *>, fallbackUserCode: String): UserAccessPolicy {
        val permissions = (raw["permissions"] as? Map<*, *>) ?: emptyMap<Any, Any>()
        val role = raw["role"]?.toString().orEmpty()
        fun permission(key: String): Boolean = role.equals("ADMIN", true) || permissions[key] as? Boolean == true
        val sections = mapOf(
            AssemblySection.BRIGADIR to SectionAccess(permission("BRIGADIR_READ"), permission("BRIGADIR_WRITE")),
            AssemblySection.QUALITY to SectionAccess(permission("QUALITY_READ"), permission("QUALITY_WRITE")),
            AssemblySection.DAILY_ISSUE to SectionAccess(permission("DAILY_ISSUE_READ"), permission("DAILY_ISSUE_WRITE")),
            AssemblySection.MONITORING to SectionAccess(permission("MONITORING_READ"), false),
            AssemblySection.MASTER_DATA to SectionAccess(permission("MASTER_DATA_READ"), permission("MASTER_DATA_WRITE")),
            AssemblySection.TP_ORDER to SectionAccess(permission("TP_ORDER_READ"), permission("TP_ORDER_WRITE")),
            AssemblySection.TP_PLANNING to SectionAccess(permission("TP_PLANNING_READ"), permission("TP_PLANNING_WRITE")),
            AssemblySection.TP_MACHINE to SectionAccess(permission("TP_MACHINE_READ"), permission("TP_MACHINE_WRITE")),
            AssemblySection.TP_ATTENDANCE to SectionAccess(permission("TP_ATTENDANCE_READ"), permission("TP_ATTENDANCE_WRITE")),
            AssemblySection.TP_SERYO to SectionAccess(permission("TP_SERYO_READ"), permission("TP_SERYO_WRITE")),
            AssemblySection.TP_RECEIVING to SectionAccess(permission("TP_RECEIVING_READ"), permission("TP_RECEIVING_WRITE")),
            AssemblySection.TP_QUALITY to SectionAccess(permission("TP_QUALITY_READ"), permission("TP_QUALITY_WRITE")),
            AssemblySection.TP_MONITORING to SectionAccess(permission("TP_MONITORING_READ"), false),
            AssemblySection.TP_MASTER_DATA to SectionAccess(permission("TP_MASTER_DATA_READ"), permission("TP_MASTER_DATA_WRITE"))
        )
        val allBrigades = role.equals("ADMIN", true) || raw["allBrigades"] as? Boolean == true
        val brigadeIds = if (allBrigades) null else (raw["allowedBrigadeIds"] as? List<*>)
            .orEmpty().mapNotNull { item ->
                item?.toString()?.trim()?.takeIf { text -> text.isNotBlank() }
            }.toSet()
        val notifications = (raw["notifications"] as? List<*>)
            .orEmpty().mapNotNull { item ->
                item?.toString()?.trim()?.takeIf { text -> text.isNotBlank() }
            }.toSet()
        return UserAccessPolicy(
            uid = raw["uid"]?.toString().orEmpty(),
            userCode = raw["userCode"]?.toString()?.ifBlank { fallbackUserCode } ?: fallbackUserCode,
            displayName = raw["displayName"]?.toString().orEmpty(),
            role = role,
            allowedBrigadeIds = brigadeIds,
            sections = sections,
            notificationKeys = notifications,
            revision = (raw["revision"] as? Number)?.toLong() ?: 0L,
            source = "server"
        )
    }
}

private class ServerDeviceIdentity(context: Context) {
    private val prefs = context.getSharedPreferences("toy_bola_server_device", Context.MODE_PRIVATE)
    fun installId(): String {
        val existing = prefs.getString("install_id", null)
        if (!existing.isNullOrBlank()) return existing
        val created = UUID.randomUUID().toString()
        prefs.edit().putString("install_id", created).apply()
        return created
    }
}
