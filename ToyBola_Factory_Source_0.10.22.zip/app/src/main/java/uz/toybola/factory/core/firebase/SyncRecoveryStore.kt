package uz.toybola.factory.core.firebase

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.UUID
import java.io.File

/** Rejected offline edits are kept locally for export; they are never silently re-uploaded. */
class SyncRecoveryStore(context: Context, uid: String = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: "locked") {
    private val directory = File(context.applicationContext.filesDir, "sync-recovery/" + uid)
    private val prefs = context.applicationContext.getSharedPreferences("sync-recovery-notice", Context.MODE_PRIVATE)
    private val noticeKey = "seen_" + uid
    fun unseenCount(): Int = (count() - prefs.getInt(noticeKey, 0)).coerceAtLeast(0)
    fun acknowledgeNotice() { prefs.edit().putInt(noticeKey, count()).apply(); events.value += 1 }
    fun save(payload: String, keys: Collection<String>, reason: String) {
        check(directory.isDirectory || directory.mkdirs()) { "Zaxira papkasi yaratilmadi" }
        val record = JSONObject().put("createdAt", System.currentTimeMillis()).put("reason", reason)
            .put("keys", JSONArray(keys)).put("payload", JSONObject(payload))
        File(directory, UUID.randomUUID().toString() + ".json").writeText(record.toString(2))
        events.value += 1
    }
    fun count(): Int = directory.listFiles { file -> file.extension == "json" }?.size ?: 0
    fun export(): String = JSONObject().put("format", "ToyBolaSyncRecovery-v1").put("records",
        JSONArray().apply { directory.listFiles { file -> file.extension == "json" }.orEmpty().sortedBy { it.lastModified() }.forEach { put(JSONObject(it.readText())) } }
    ).toString(2)
    companion object { val events = MutableStateFlow(0L) }
}
