package uz.toybola.factory.core.firebase

import kotlinx.coroutines.sync.Mutex

/** A login may not replace Firebase identity while an old user's snapshot/push is in flight. */
internal object SyncSessionGate { val mutex = Mutex() }
