package uz.toybola.factory.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.toybola.factory.core.firebase.SyncRecoveryStore

@Composable
fun SyncRecoveryNotice(showAll: Boolean = false) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { SyncRecoveryStore(context) }
    val revision by SyncRecoveryStore.events.collectAsState()
    val count = remember(revision) { if (showAll) store.count() else store.unseenCount() }
    var open by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            message = withContext(Dispatchers.IO) {
                runCatching {
                    val content = store.export()
                    checkNotNull(context.contentResolver.openOutputStream(uri)).bufferedWriter().use { it.write(content) }
                }.fold({ "Zaxira fayli saqlandi. Uni administratorga yuborishingiz mumkin." }, { it.message ?: "Fayl saqlanmadi" })
            }
        }
    }
    if (count > 0) TextButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
        Text("⚠ Tekshirish uchun saqlangan o‘zgarishlar: " + count)
    }
    if (open) AlertDialog(onDismissRequest = { open = false }, title = { Text("Sinxronlash ziddiyati") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Boshqa qurilmada shu ma’lumot o‘zgargan yoki admin ma’lumotlarni tozalagan. Ekranga serverdagi nusxa yuklandi. Yuborilmagan yozuvlaringiz zaxirada saqlangan; ular o‘z-o‘zidan serverga qaytarilmaydi.")
            Text("Zaxirani saqlab, administrator bilan tekshiring. Kerakli tuzatishni yangilangan ma’lumot ustida qayta kiriting.")
            message?.let { Text(it) }
        }
    }, confirmButton = {
        TextButton(onClick = { export.launch("ToyBola_sync_recovery.json") }) { Text("Zaxirani saqlash") }
    }, dismissButton = {
        TextButton(onClick = { store.acknowledgeNotice(); open = false }) { Text("Ko‘rdim") }
    })
}
