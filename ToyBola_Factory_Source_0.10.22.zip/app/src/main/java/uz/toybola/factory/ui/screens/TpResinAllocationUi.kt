package uz.toybola.factory.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*

@Composable
internal fun AlternativeResinDialog(data: TpData, onDismiss: () -> Unit, onSelect: (String) -> String?) {
    var error by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Barcha seryolar") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(query, { query = it }, label = { Text("Nomi yoki kodi") }, singleLine = true)
            Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                val codes = data.allResinCodes().filter { code ->
                    val name = data.materials.firstOrNull { it.type == TpMaterialType.RESIN && it.code.equals(code, true) }?.name.orEmpty()
                    code.contains(query, true) || name.contains(query, true)
                }
                if (codes.isEmpty()) Text("Seryo topilmadi")
                codes.forEach { code ->
                    val material = data.materials.firstOrNull { !it.archived && it.type == TpMaterialType.RESIN && it.code.equals(code, true) }
                    TextButton(onClick = { error = onSelect(code) }, modifier = Modifier.fillMaxWidth()) {
                        Text(listOf(code, material?.name.orEmpty()).filter { it.isNotBlank() }.distinct().joinToString(" • "))
                    }
                }
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }, confirmButton = {}, dismissButton = { TextButton(onClick = onDismiss) { Text("Yopish") } })
}

@Composable
internal fun ResinExtraDialog(job: TpPlanJob, onDismiss: () -> Unit, onAdd: (TpResinAdditionKind, Double) -> String?) {
    var manual by remember { mutableStateOf(false) }
    var amount by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val round = resinRoundUpAddition(job.totalResinKg)
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Qo‘shimcha seryo") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(job.outputs.joinToString { it.detailName }, fontWeight = FontWeight.SemiBold)
            Text("${job.resinCode} • jami ${formatTpNumber(job.totalResinKg)} kg")
            Button(onClick = { error = onAdd(TpResinAdditionKind.ROUND_25, 0.0) }, enabled = round > 0.0, modifier = Modifier.fillMaxWidth()) {
                Text(if (round > 0.0) "25 kg ga yaxlitlash → ${formatTpNumber(job.totalResinKg + round)} kg" else "25 kg ga allaqachon yaxlitlangan")
            }
            OutlinedButton(onClick = { manual = true }, modifier = Modifier.fillMaxWidth()) { Text("Qo‘shimcha berish") }
            if (manual) {
                OutlinedTextField(amount, { amount = it }, label = { Text("Qo‘shimcha kg") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                Button(onClick = {
                    val value = amount.trim().replace(',', '.').toDoubleOrNull()
                    error = if (value == null || !value.isFinite() || value <= 0.0) "Kilogrammni to‘g‘ri kiriting"
                        else onAdd(TpResinAdditionKind.MANUAL, value)
                }, modifier = Modifier.fillMaxWidth()) { Text("Qo‘shish") }
            }
            Text("Krasitel ham retsept nisbatida oshadi. Ikkala amalni ketma-ket qo‘llash mumkin.", style = MaterialTheme.typography.bodySmall)
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }, confirmButton = {}, dismissButton = { TextButton(onClick = onDismiss) { Text("Yopish") } })
}

@Composable
internal fun PreparationQuantity(label: String, code: String, kilograms: Double) {
    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.medium) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(code, Modifier.weight(1f), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("${formatTpNumber(kilograms)} kg", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
internal fun ResinAdditionSummary(job: TpPlanJob) {
    if (job.resinAdditions.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Asosiy: ${formatTpNumber(job.requiredResinKg)} kg • qo‘shimcha: +${formatTpNumber(job.extraResinKg)} kg", fontWeight = FontWeight.SemiBold)
        job.resinAdditions.forEach { extra ->
            Text("${extra.resinCode}: +${formatTpNumber(extra.kilograms)} kg • ${if (extra.kind == TpResinAdditionKind.ROUND_25) "25 kg ga yaxlitlash" else "Qo‘lda qo‘shilgan"}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
internal fun ResinExtraMonitoring(data: TpData, from: String, to: String, resinCode: String? = null) {
    val rows = data.jobs.flatMap { job ->
        job.resinAdditions.filter { it.createdAt.take(10) in from..to && (resinCode == null || it.resinCode.equals(resinCode, true)) }.map { job to it }
    }.sortedByDescending { it.second.createdAt }
    if (rows.isEmpty()) return
    Text("Qo‘shimcha berilgan seryo", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    rows.forEach { (job, extra) ->
        val order = data.orders.firstOrNull { it.id == job.orderId }
        TpCard {
            Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.Bold)
            Text(job.outputs.joinToString { it.detailName } + " • rang " + job.colorCode)
            Text("${extra.resinCode}: +${formatTpNumber(extra.kilograms)} kg", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(if (extra.kind == TpResinAdditionKind.ROUND_25) "25 kg ga yuqoriga yaxlitlash" else "Brigadir qo‘lda qo‘shgan")
            Text(extra.createdAt.take(16).replace('T', ' ') + " • " + extra.createdBy, style = MaterialTheme.typography.bodySmall)
        }
    }
}
