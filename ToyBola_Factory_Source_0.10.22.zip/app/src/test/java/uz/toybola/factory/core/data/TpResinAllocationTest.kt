package uz.toybola.factory.core.data
import org.junit.Assert.*
import org.junit.Test

class TpResinAllocationTest {
    private fun job() = TpPlanJob(
        id = "j", orderId = "o", moldCode = "m", colorCode = "001", outputs = emptyList(),
        requiredShots = 1, cycleSeconds = 1, estimatedMinutes = 1,
        resinCode = "002", requiredResinKg = 257.3, requiredColorGrams = 2058.4,
        compatibleMachineIds = emptySet(), priority = 1
    )
    private fun extra(kg: Double, kind: TpResinAdditionKind) =
        TpResinAddition(kind.name, "002", kg, kind, "2026-09-05T10:00", "USR-1")
    @Test fun roundsUpNotDown() {
        assertEquals(17.7, resinRoundUpAddition(257.3), 0.00001)
        assertEquals(24.999, resinRoundUpAddition(25.001), 0.00001)
        assertEquals(0.0, resinRoundUpAddition(275.0), 0.0)
        assertEquals(0.0, resinRoundUpAddition(25.00000000003), 0.0)
        assertEquals(24.999, resinRoundUpAddition(25.0004), 0.00001)
    }
    @Test fun manualAndRoundingWorkTogetherAndScaleColorant() {
        val rounded = job().copy(resinAdditions = listOf(extra(17.7, TpResinAdditionKind.ROUND_25)))
        assertEquals(275.0, rounded.totalResinKg, 0.00001)
        assertEquals(2200.0, rounded.totalColorGrams, 0.00001)
        val manual = rounded.copy(resinAdditions = rounded.resinAdditions + extra(5.0, TpResinAdditionKind.MANUAL))
        assertEquals(280.0, manual.totalResinKg, 0.00001)
        assertEquals(2240.0, manual.totalColorGrams, 0.00001)
        assertEquals(20.0, resinRoundUpAddition(manual.totalResinKg), 0.00001)
        assertEquals(257.3, manual.requiredResinKg, 0.00001)
    }
    @Test fun zeroExtraPreservesRecipe() {
        assertEquals(job().requiredResinKg, job().totalResinKg, 0.00001)
        assertEquals(job().requiredColorGrams, job().totalColorGrams, 0.00001)
        assertEquals(0.0, job().extraResinKg, 0.0)
    }
    @Test fun invalidQuantitiesFailSafely() {
        listOf(Double.NaN, Double.POSITIVE_INFINITY, -1.0).forEach { value ->
            assertTrue(runCatching { resinRoundUpAddition(value) }.isFailure)
        }
    }
}
