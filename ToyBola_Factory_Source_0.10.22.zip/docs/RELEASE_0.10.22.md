# 0.10.22 — foydalanish va tekshirish

## GitHub orqali yangilash

1. Repozitoriydagi Source ZIP o‘rniga ToyBola_Factory_Source_0.10.22.zip qo‘ying.
2. .github/workflows/main.yml ni yangi main.yml bilan almashtiring.
3. Actions’da Android va Firebase server ishlarining ikkalasi ham muvaffaqiyatli tugashini kuting. Serverga kirish uchun oldindan kelishilgan GitHub variables/secrets va WIF sozlamalari saqlangan.
4. Barcha qurilmalarga aynan shu builddan chiqqan 0.10.22 APKni o‘rnating. Mavjud ilovaning ustidan yangilang; foydalanuvchi ma’lumotlarini qo‘lda o‘chirmang.
5. Har qurilmada internet bilan kiring. Zarur ruxsatlar va to‘g‘ri TP/Sborka brigadalari berilganini tekshiring.

Yangi Android eski serverga TP yozuvlarini yubormaydi; server protokoli yangilanmagan bo‘lsa ekranda Firebase deploy haqida aniq xabar chiqadi. Eski APKlar ham yangi yozish protokoliga mos emas: barcha telefonlarni bir xil versiyaga o‘tkazish kerak.

## Foydalanuvchilar

Rol tanlash va foydalanuvchi kartasidagi rol satri olib tashlandi. Admin huquqi serverda himoya sifatida saqlanadi; oddiy yangi hisob CUSTOM ichki belgisi bilan yaratiladi. Bu foydalanuvchi tanlaydigan rol emas va hech qanday avtomatik ruxsat bermaydi.

Yuqoridagi yetti tanlov bosh ekranga mos: Seryo va quyish, YTM sklad, Zapchast sklad, Sborka va Xonadon, TM va EXP sklad, Rahbariyat nazorati, Ma’lumotlar. Yoqilgan bo‘limning mavjud ichki ruxsatlari pastda chiqadi. Bir-biriga tegishli monitoring/master-data ruxsatlari takroran o‘chirib yuborilmaydi.

Avvalgi ilovada hali ishlamagan YTM, Zapchast va TM/EXP ombor ekranlari bu patchda ham yangi ombor tizimiga aylantirilmagan; tanlovlari saqlanadi, ichki funksiyalar hali mavjud emasligi oynada ko‘rsatiladi.

## Seryo

- Asosiy ro‘yxat detal uchun belgilangan seryolarni saqlaydi. “Boshqa” barcha faol seryo kodi va nomlarini ochadi; qidirish mumkin.
- Tasdiqlashdan oldin har bir detal/rang vazifasida “+ Qo‘shimcha” bor.
- “25 kg ga yaxlitlash” jami hisobni faqat yuqoriga yaxlitlaydi: 257.300 → 275 kg. Bir marta yaxlitlangan miqdorga shu tugmani qayta bosish yana bir qop qo‘shmaydi.
- “Qo‘shimcha berish” tanlangan seryoga qo‘lda kg qo‘shadi. Qo‘lda qo‘shish va yaxlitlashni ketma-ket ishlatish mumkin.
- Asosiy hisob o‘zgarmaydi. Qo‘shimcha yozuvda turi, kg, vaqt va foydalanuvchi kodi saqlanadi. Tasdiqlangan/yetkazilgan qorishmaga yashirin qo‘shimcha kiritilmaydi.
- Foydalanuvchi tasdiqlaganidek, krasitel ham retsept nisbatida oshadi. Ostatka nazorati va yetkazish sarfi jami seryo/krasitelga qaraydi.
- Monitoring → Seryo bo‘limida sana oralig‘i bo‘yicha qaysi mahsulot/detal/rangga qaysi seryodan qancha qo‘shimcha berilgani alohida ko‘rsatiladi.
- Tayyorlovchida artikul va mahsulot nomi, seryo kodi/kg, krasitel kodi/kg ko‘rsatiladi. Ichki krasitel ombor birligi avvalgidek gramm; tayyorlovchi uchun kg ga aylantiriladi.
- Bir qolipda birgalikda quyiladigan detallar bitta umumiy qorishma vazifasi bo‘lib qoladi; umumiy sarfni har bir detalga qayta hisoblab ikki marta yechmaydi.

## Sinxronlashdagi himoyalar

TP/Seryo-only profilning Sborka ruxsat xatosi TP yuklanishini to‘xtatishi tuzatildi. Har kanal mustaqil ishlaydi. Joriy server ruxsati tekshirilmasdan eski cached ruxsat bilan push qilinmaydi.

Ilova ko‘rinib turganda tezkor yangilash, qayta ochishda pull, Firestore signaliga javob, 30 soniyali zaxira tekshiruv bor. WorkManager internet qaytganda va davriy fon tekshiruvida yordam beradi. Fon ishining aniq vaqti Android/batareya cheklovlariga bog‘liq; internet bo‘lmasa serverlararo real vaqt almashinuvi bo‘lmaydi.

TP yozuvlarida tahrirdan oldingi holat qayd qilinadi. Server ushbu holat, yangi lokal o‘zgarish va joriy server holatini tranzaksiyada solishtiradi. Mustaqil maydonlar hamda IDli sarf yozuvlari birlashadi; zid maydonlarda bir batchning yarmini yozib qolmaydi. Yetkazish sarfi qayta urinishda deterministik ID orqali takrorlanmaydi.

Sborka yozuvlari ham yagona tranzaksiyada tekshiriladi: brigadirning eski nusxasi sifat nazoratining yangi yopilishini bekor qilmaydi. Kundalik berilgan ishni o‘chirish va uning markeri birga saqlanadi. Bitta so‘rovda o‘chirish va eski nusxa birga kelsa, o‘chirish ustun turadi.

O‘chirish markerlari TP master-data va operatsion kolleksiyalariga ham kengaydi. O‘chirilgan zakaz ostida yangi IDli eski vazifa ham qayta yaratilmaydi. To‘liq TP tozalashda server davri oshadi; oldingi offline navbat, hatto hali serverga bormagan yangi IDlar ham, yangi davrga avtomatik yuborilmaydi.

Ziddiyatli yoki eski protokoldagi navbat ekranda ogohlantirish beradi. To‘liq yuborilmagan holat telefonning shu foydalanuvchiga tegishli ichki zaxirasida saqlanadi. “Zaxirani saqlash” orqali JSON chiqarib administrator bilan tekshirish mumkin. Zaxira avtomatik serverga import qilinmaydi. Hisob almashganda avvalgi hisobning navbati yangi hisob nomidan yuborilmaydi.

## Ikki telefonda qabul sinovi

Bu ro‘yxatni haqiqiy serverga deploy va APK o‘rnatilgandan keyin bajaring:

1. Admindan TP zakaz yarating; faqat TP/Seryo o‘qish ruxsatli boshqa hisobda ko‘rinishini tekshiring. Sborka huquqi shart emas.
2. Ikkinchi telefonni offline qiling, bir yozuvni o‘zgartiring. Admin shu zakazni o‘chirsin. Ikkinchi telefonni online qilib sinxronlang: zakaz/vazifalar qaytmasin.
3. Ikkita qurilmadan bir vazifaning mustaqil maydonlarini o‘zgartiring: yangi qiymatlar ikkalasi ham saqlansin. Bir maydon zid o‘zgarsa zaxira ogohlantirishi va server nusxasi ko‘rinsin.
4. 257.300 kg hisobda yaxlitlash → 275 kg, keyin +5 kg → 280 kg. Krasitel retseptga mos oshsin, monitoringda +17.7 va +5 alohida bo‘lsin.
5. “Boshqa”dan boshqa faol seryoni tanlang. Tayyorlovchida tanlangan kodi, jami kg va krasitel kg to‘g‘ri bo‘lsin.
6. Ikki qurilmada bir vazifani yetkazishni qayta urinib ko‘ring: ombordan bir xil sarf ikki marta yechilmasin.
7. Read-only foydalanuvchi o‘qiy olsin, tasdiqlash/o‘zgartirish vakolatisiz yoza olmasin. Ruxsat kamaytirilganda ekranlar yangilansin.
8. Yangi o‘rnatilgan telefonda serverdagi ma’lumot yuklansin; boshqa profilning kesh ma’lumoti ko‘rinmasin.
9. Maoshning 1–15 va 16–oy oxiri Excel eksportlarini real ma’lumot bilan ochib tekshiring.

## Tekshiruv chegarasi

Avtomatik Kotlin hisob/merge/permission/Excel testlari, Android build/lint va haqiqiy server handlerlarini xotiradagi Firestore/Auth o‘rnini bosuvchi obyektlar bilan bajaruvchi Node testlar bor. Bu Node testlari Firebase Emulator yoki haqiqiy tarmoq testi emas.

Ishlab turgan Firebase loyihasiga bu ish davomida deploy qilinmadi; real foydalanuvchi ma’lumotlari o‘zgartirilmadi. Samsung Galaxy Note 8/Redmi qurilmalarida, background battery rejimlarida va real production IAM/rules muhitida masofadan tekshirilmagan. “Barcha mumkin bo‘lgan xatolar yo‘q” degan kafolat berilmaydi.

Texnik asos: [Firestore tranzaksiyalari](https://firebase.google.com/docs/firestore/manage-data/transactions), [real vaqt listenerlari](https://firebase.google.com/docs/firestore/query-data/listen).
