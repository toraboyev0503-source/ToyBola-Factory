# 0.10.22 — yakuniy tekshiruv natijalari

Tekshiruv sanasi: 2026-09-05. Android: versionName 0.10.22, versionCode 1022.

## Bajarilgan tekshiruvlar

- Yakuniy Android manba kodi: testDebugUnitTest + assembleDebug — BUILD SUCCESSFUL.
- JVM unit testlari: 51 ta, 0 xato, 0 muvaffaqiyatsiz test. Hisob-kitob, seryo yaxlitlash va krasitel nisbati, TP/Sborka modellari, merge, ruxsatlar hamda Excel import testlari.
- To‘liq Android lint: 0 error, 59 warning, 1 hint. Lintdan keyin faqat TP materialini rejalashtirish ruxsati bilan tahrirlashga oid kichik guard tuzatildi; undan keyin yakuniy compile, 51 test va APK yig‘ish yana muvaffaqiyatli bajarildi. Ogohlantirishlar nolga tushirilgani da’vo qilinmaydi.
- Server testlari: 21 ta, barchasi PASS. Ular haqiqiy handler kodini xotiradagi Firestore/Auth o‘rnini bosuvchi obyektlar bilan chaqiradi; bu Firebase Emulator yoki haqiqiy tarmoq sinovi emas.
- Server sintaksisi: index.js, sync-merge.js, tp-mutation.js, bootstrap-admin.js, provision-user.js — PASS.
- GitHub Actions main.yml: YAML parser bilan o‘qildi; Android hamda Firebase deploy ishlari saqlangan.
- Yig‘ilgan nusxa va yetkazilayotgan manbaning app/src fayllari hash bo‘yicha bir xil.
- Tp.xlsx va Sborka.xlsx shablonlari manba paketida saqlangan.
- Manbada PEM private key boshlanish markerlari topilmadi. Mavjud ilova yangilanishiga mos debug imzolash keystori o‘z holicha saqlangan; u production maxfiy kaliti emas.

## Server regressiya ssenariylari

TP-only profilning birinchi yuklanishi; read-only yozuvni rad etish; Seryo ruxsati bilan planning maydonini buzishni rad etish; boshqa qurilmaning mustaqil yangi maydonini saqlash; zid batchni to‘liq rad etish; o‘chirilgan zakaz ostida yangi ID bilan qayta tiriltirishni bloklash; tozalash davri eskirgan offline yozuvlarni rad etish; haqiqiy brigada chegarasini tekshirish; rol tanlamasdan faqat aniq ruxsatlar bilan foydalanuvchi yaratish; master-data o‘chirish markerlari; Sborka sifat yopilishini saqlash; o‘chirilgan daily issue va bir so‘rovdagi delete/upsert ustuvorligi; IDli sarflarni takrorlamasdan merge qilish; eski noma’lum navbatni xavfsiz zaxiraga ajratish.

## Bajarilmagan tashqi sinovlar

Haqiqiy Firebase loyihasiga deploy, GitHub Actions bulutdagi ishga tushishi, production IAM/Firestore Rules emulator baholashi va Samsung Galaxy Note 8/Redmi qurilmalaridagi qo‘l bilan sinov bu muhitda bajarilmadi. UI/state restoration hamda haqiqiy oylik Excel eksportining barcha holatlari uchun avtomatlashtirilgan qurilma testi mavjud emas.

Yangilash tartibi, barcha telefonlarni bir xil versiyaga o‘tkazish zarurati, ziddiyat zaxirasini olish va ikki telefonli qabul sinovi RELEASE_0.10.22.md da. Paketni qo‘yishning o‘zi serverni yangilamaydi: Actions ichidagi Android va Firebase deploy ishlari ikkalasi ham muvaffaqiyatli tugashi kerak.
