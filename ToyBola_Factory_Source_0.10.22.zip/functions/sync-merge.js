"use strict";
const equal = (a, b) => canonical(a) === canonical(b);
function canonical(value) {
  if (Array.isArray(value)) return "[" + value.map(canonical).join(",") + "]";
  if (value && typeof value === "object") return "{" + Object.keys(value).sort().map(k => JSON.stringify(k) + ":" + canonical(value[k])).join(",") + "}";
  return JSON.stringify(value);
}
function rowKey(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  if (value.id != null) return String(value.id);
  if (value.detailId != null) return String(value.detailId);
  if (value.effectiveFrom != null) return String(value.effectiveFrom);
  return null;
}
/** Three-way merge: unchanged local fields never overwrite a newer server value.
 * Conflicting changes are reported, not guessed. Keyed additions are idempotent.
 */
function mergeValue(base, local, remote, path, conflicts) {
  // Old app payloads omit fields whose local decoder supplies an empty default.
  if (path && remote === undefined && (base === null || base === false || base === "" || base === 0 || (Array.isArray(base) && base.length === 0))) remote = base;
  if (equal(local, base)) return remote;
  if (equal(remote, base) || equal(local, remote)) return local;
  if (Array.isArray(base) && Array.isArray(local) && Array.isArray(remote)) {
    const lists = [base, local, remote];
    if (lists.every(rows => rows.every(row => rowKey(row) != null) && new Set(rows.map(rowKey)).size === rows.length)) {
      const [b, l, r] = lists.map(rows => new Map(rows.map(row => [rowKey(row), row])));
      const result = [];
      for (const id of new Set([...r.keys(), ...l.keys()])) {
        // A removed child must not reappear due to a stale edit to its parent.
        if (b.has(id) && !r.has(id)) continue;
        const value = mergeValue(b.get(id), l.get(id), r.get(id), path + "/" + id, conflicts);
        if (value !== undefined) result.push(value);
      }
      return result;
    }
  }
  if ([base, local, remote].every(v => v && typeof v === "object" && !Array.isArray(v))) {
    const result = {};
    for (const key of new Set([...Object.keys(base), ...Object.keys(local), ...Object.keys(remote)])) {
      const value = mergeValue(base[key], local[key], remote[key], path + "/" + key, conflicts);
      if (value !== undefined) result[key] = value;
    }
    return result;
  }
  conflicts.push(path);
  return remote;
}
function mergeRecord(base, local, remote, known = true) {
  const conflicts = [];
  if (!known) return { value: remote, conflicts: ["missing-baseline"] };
  // null baseline denotes an intentional new record.
  const value = mergeValue(base == null ? undefined : base, local, remote == null ? undefined : remote, "", conflicts);
  return { value, conflicts };
}
module.exports = { mergeRecord, equal };
