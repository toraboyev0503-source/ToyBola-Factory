"use strict";
const { test } = require("node:test");
const assert = require("node:assert/strict");
const { mergeRecord } = require("./sync-merge");
test("stale material fields do not overwrite planning updates", () => {
 const base = { machineId:"one", resinCode:"001", resinConfirmedAt:null };
 const merged = mergeRecord(base, {...base,resinConfirmedAt:"now"}, {...base,machineId:"two"});
 assert.deepEqual(merged, {value:{machineId:"two",resinCode:"001",resinConfirmedAt:"now"},conflicts:[]});
});
test("concurrent changes to the same field are explicit conflicts", () => {
 const merged=mergeRecord({resinCode:"001"},{resinCode:"002"},{resinCode:"003"});
 assert.deepEqual(merged.conflicts,["/resinCode"]);
});
test("concurrent stock movements are merged exactly once", () => {
 const before={movements:[]};
 const a={id:"job-a-RESIN",amount:275};
 const b={id:"job-b-RESIN",amount:50};
 const result=mergeRecord(before,{movements:[a]},{movements:[b]});
 assert.deepEqual(result.value.movements,[b,a]);
 assert.equal(mergeRecord(before,{movements:[a]},result.value).value.movements.length,2);
});
test("server-deleted children are not resurrected by stale parent edits", () => {
 const base={details:[{id:"one",name:"old"}]};
 assert.deepEqual(mergeRecord(base,{details:[{id:"one",name:"stale edit"}]},{details:[]}).value,{details:[]});
});
test("unknown legacy pending data is quarantined instead of overwriting", () => {
 assert.equal(mergeRecord(null,{n:1},{n:2},false).conflicts.length,1);
 assert.equal(mergeRecord(null,{id:"new"},null,false).conflicts.length,1);
 assert.deepEqual(mergeRecord(null,{id:"new"},null,true).value,{id:"new"});
});
test("unrelated custom/unknown server fields survive", () => {
 assert.deepEqual(mergeRecord({n:1},{n:2},{n:1,future:true}).value,{n:2,future:true});
});
test("new optional fields work with old payloads that omitted their defaults", () => {
 const base={id:"j",resinAdditions:[],alternativeResin:false};
 const local={...base,resinAdditions:[{id:"a",kilograms:17.7}]};
 const result=mergeRecord(base,local,{id:"j"});
 assert.deepEqual(result.conflicts,[]);
 assert.equal(result.value.resinAdditions[0].kilograms,17.7);
});
