package uz.toybola.factory

import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Surface
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import uz.toybola.factory.core.data.AssemblyDataRepository
import uz.toybola.factory.core.data.TpDataRepository
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.canReadScreen
import uz.toybola.factory.core.notifications.NotificationInboxRepository
import uz.toybola.factory.core.firebase.AssemblySyncOutbox
import uz.toybola.factory.core.firebase.FirebaseSyncCoordinator
import uz.toybola.factory.core.firebase.FirebaseSyncScheduler
import uz.toybola.factory.core.firebase.ServerAuthRepository
import uz.toybola.factory.core.firebase.ServerMigrationState
import uz.toybola.factory.core.firebase.ServerPolicyEvents
import uz.toybola.factory.core.notifications.NotificationRouteState
import uz.toybola.factory.ui.components.GlobalDrawer
import uz.toybola.factory.ui.model.AppScreen
import uz.toybola.factory.ui.model.AppStrings
import uz.toybola.factory.ui.screens.*
import uz.toybola.factory.ui.theme.ToyBolaTheme

@Composable
fun ToyBolaApp(
    preferences: AppPreferences,
    assemblyDataRepository: AssemblyDataRepository,
    tpDataRepository: TpDataRepository,
    notificationInboxRepository: NotificationInboxRepository
) {
    var settings by remember { mutableStateOf(preferences.loadSettings()) }
    var authenticated by remember { mutableStateOf(false) }
    val stack = remember { mutableStateListOf(AppScreen.SPLASH) }
    var lastInteraction by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    var unreadNotifications by remember { mutableStateOf(notificationInboxRepository.unreadCount()) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val notificationRoute by NotificationRouteState.route
    val serverPolicyEvent by ServerPolicyEvents.revision.collectAsState()
    val serverAuthRepository = remember { ServerAuthRepository(preferences.appContext) }
    val serverMigrationState = remember { ServerMigrationState(preferences.appContext) }
    val syncOutbox = remember { AssemblySyncOutbox(preferences.appContext) }
    var accessPolicy by remember {
        val code = preferences.setup()?.userCode.orEmpty()
        mutableStateOf(serverAuthRepository.cachedPolicy(code) ?: UserAccessPolicy.locked(code))
    }

    fun replace(screen: AppScreen) {
        stack.clear()
        stack.add(screen)
    }

    fun push(screen: AppScreen) {
        // Navigation is permission-gated as well as visually disabled. This protects
        // notification/deep-link/internal routes from opening a forbidden screen.
        if (!accessPolicy.canReadScreen(screen)) return
        if (stack.lastOrNull() != screen) stack.add(screen)
    }

    fun pop() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    fun finishAuthentication(policy: UserAccessPolicy) {
        accessPolicy = policy
        val localAtLogin = assemblyDataRepository.load()
        val hasRealLocalPayload = localAtLogin.brigades.isNotEmpty() || localAtLogin.workers.isNotEmpty() ||
            localAtLogin.products.isNotEmpty() || localAtLogin.workerDays.isNotEmpty() || localAtLogin.brigadeDays.isNotEmpty() ||
            localAtLogin.qualityRounds.isNotEmpty() || localAtLogin.dailyIssues.isNotEmpty() || localAtLogin.auditLog.isNotEmpty()

        // 0.9.4 keeps the one-time legacy-local recovery safeguards. On an upgraded phone that still
        // contains real business data, protect that data from an empty/partial remote snapshot
        // until it has been exported/imported and the Admin finishes the server migration.
        if (hasRealLocalPayload && !serverMigrationState.legacyProtectionInitialized()) {
            serverMigrationState.setRecoveryInProgress(true)
            serverMigrationState.markLegacyProtectionInitialized()
        }

        if (policy.isAdmin() && policy.allowedBrigadeIds == null && !serverMigrationState.wasSeedScheduled(policy.uid)) {
            val local = localAtLogin
            // Only an upgraded installation with real local business data may seed the server.
            // A fresh install contains only default settings; marking those as an outbox seed can
            // overwrite valid server settings before the initial pull and leaves the app empty.
            if (hasRealLocalPayload) syncOutbox.markAll(local)
            serverMigrationState.markSeedScheduled(policy.uid)
        }
        authenticated = true
        lastInteraction = SystemClock.elapsedRealtime()
        replace(AppScreen.HOME)

        // Do an immediate bootstrap pull after successful login. WorkManager remains the retry/
        // connectivity fallback, but a freshly installed Admin should not wait minutes for data.
        scope.launch {
            val result = FirebaseSyncCoordinator(preferences.appContext).syncNow()
            if (result.isFailure) FirebaseSyncScheduler.enqueue(preferences.appContext)
        }
    }

    fun lock() {
        authenticated = false
        replace(if (preferences.hasSetup()) AppScreen.LOGIN else AppScreen.SETUP)
        scope.launch { drawerState.close() }
    }

    fun openNotificationRoute(route: String) {
        val target = when (route) {
            "BRIGADIR" -> AppScreen.BRIGADIR
            "QUALITY" -> AppScreen.QUALITY
            "MONITORING" -> AppScreen.MONITORING
            "DAILY_ISSUE" -> AppScreen.DAILY_ISSUE
            else -> null
        }
        if (target != null && accessPolicy.canReadScreen(target)) {
            replace(AppScreen.HOME)
            push(AppScreen.ASSEMBLY_ENTRY)
            push(AppScreen.ASSEMBLY)
            push(target)
        }
        unreadNotifications = notificationInboxRepository.unreadCount()
    }

    LaunchedEffect(authenticated, settings.autoLockMinutes) {
        while (authenticated) {
            delay(1_000)
            val elapsed = SystemClock.elapsedRealtime() - lastInteraction
            if (elapsed >= settings.autoLockMinutes * 60_000L) lock()
        }
    }

    LaunchedEffect(notificationRoute, authenticated) {
        if (authenticated && notificationRoute != null) {
            openNotificationRoute(notificationRoute.orEmpty())
            NotificationRouteState.clear()
        }
    }

    LaunchedEffect(serverPolicyEvent, authenticated) {
        if (authenticated && serverPolicyEvent > 0L) {
            serverAuthRepository.refreshPolicy()
                .onSuccess { refreshed ->
                    accessPolicy = refreshed
                    val currentScreen = stack.lastOrNull()
                    if (currentScreen != null && !refreshed.canReadScreen(currentScreen)) replace(AppScreen.HOME)
                }
                .onFailure { error ->
                    val message = error.message.orEmpty()
                    if (message.contains("o‘chirilgan", ignoreCase = true) ||
                        message.contains("disabled", ignoreCase = true)) {
                        lock()
                    }
                }
        }
    }

    ToyBolaTheme(settings) {
        val strings = AppStrings(settings.language)
        val current = stack.lastOrNull() ?: AppScreen.SPLASH
        val allowDrawer = current == AppScreen.HOME

        val screenOwnsBack = current == AppScreen.TP_PLAN || current == AppScreen.BRIGADIR ||
            current == AppScreen.QUALITY || current == AppScreen.DAILY_ISSUE ||
            current == AppScreen.MASTER_DATA || current == AppScreen.USER_ADMIN
        BackHandler(enabled = stack.size > 1 && !screenOwnsBack) { pop() }

        ModalNavigationDrawer(
            drawerState = drawerState,
            gesturesEnabled = allowDrawer,
            drawerContent = {
                ModalDrawerSheet(
                    modifier = Modifier
                        .fillMaxWidth(0.54f)
                        .widthIn(min = 210.dp, max = 340.dp)
                ) {
                    GlobalDrawer(
                        strings = strings,
                        settings = settings,
                        onSettingsChange = {
                            settings = it
                            preferences.saveSettings(it)
                        },
                        unreadNotifications = unreadNotifications,
                        onNotifications = {
                            unreadNotifications = notificationInboxRepository.unreadCount()
                            scope.launch {
                                drawerState.close()
                                push(AppScreen.NOTIFICATIONS)
                            }
                        },
                        showUserManagement = accessPolicy.isAdmin(),
                        onUserManagement = {
                            scope.launch {
                                drawerState.close()
                                push(AppScreen.USER_ADMIN)
                            }
                        },
                        onBackupRestore = {
                            scope.launch {
                                drawerState.close()
                                push(AppScreen.BACKUP_RESTORE)
                            }
                        },
                        onLock = ::lock
                    )
                }
            }
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(authenticated) {
                        if (authenticated) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                lastInteraction = SystemClock.elapsedRealtime()
                            }
                        }
                    }
            ) {
                when (current) {
                    AppScreen.SPLASH -> SplashScreen {
                        replace(if (preferences.hasSetup()) AppScreen.LOGIN else AppScreen.SETUP)
                    }
                    AppScreen.SETUP -> SetupScreen(
                        strings = strings,
                        onServerLogin = serverAuthRepository::signInWithCodes,
                        onAuthenticated = { deviceCode, userCode, policy ->
                            preferences.saveSetup(deviceCode, userCode)
                            finishAuthentication(policy)
                        }
                    )
                    AppScreen.LOGIN -> LoginScreen(
                        strings = strings,
                        savedSetup = preferences.setup(),
                        onServerLogin = serverAuthRepository::signInWithCodes,
                        onAuthenticated = { deviceCode, userCode, policy ->
                            preferences.saveSetup(deviceCode, userCode)
                            finishAuthentication(policy)
                        }
                    )
                    AppScreen.HOME -> HomeScreen(
                        strings = strings,
                        onMenu = {
                            unreadNotifications = notificationInboxRepository.unreadCount()
                            scope.launch { drawerState.open() }
                        },
                        canOpenMolding = accessPolicy.canReadScreen(AppScreen.TP_MAIN),
                        canOpenManagement = accessPolicy.canReadScreen(AppScreen.MANAGEMENT),
                        onMolding = { push(AppScreen.TP_MAIN) },
                        onAssembly = { push(AppScreen.ASSEMBLY_ENTRY) },
                        onManagement = { push(AppScreen.MANAGEMENT) }
                    )
                    AppScreen.MANAGEMENT -> ManagementMonitoringScreen(strings, ::pop, { accessPolicy.canReadScreen(it) }, ::push)
                    AppScreen.NOTIFICATIONS -> NotificationsScreen(
                        strings = strings,
                        repository = notificationInboxRepository,
                        onBack = {
                            unreadNotifications = notificationInboxRepository.unreadCount()
                            pop()
                        },
                        onOpenRoute = ::openNotificationRoute
                    )
                    AppScreen.TP_MAIN -> TpMainScreen(strings, ::pop, { accessPolicy.canReadScreen(it) }, ::push)
                    AppScreen.TP_PLAN -> TpPlanScreen(strings, tpDataRepository, ::pop)
                    AppScreen.TP_SERYO -> TpSeryoScreen(strings, tpDataRepository, ::pop)
                    AppScreen.TP_RECEIVING -> TpReceivingScreen(strings, tpDataRepository, ::pop)
                    AppScreen.TP_QUALITY -> TpQualityScreen(strings, tpDataRepository, ::pop)
                    AppScreen.TP_MONITORING -> TpMonitoringScreen(strings, tpDataRepository, ::pop)
                    AppScreen.ASSEMBLY_ENTRY -> AssemblyEntryScreen(strings, onBack = ::pop) { push(AppScreen.ASSEMBLY) }
                    AppScreen.ASSEMBLY -> AssemblyMainScreen(
                        strings = strings,
                        onBack = ::pop,
                        canOpen = { screen -> accessPolicy.canReadScreen(screen) },
                        onOpen = ::push
                    )
                    AppScreen.BRIGADIR -> BrigadirScreen(strings, assemblyDataRepository, ::pop)
                    AppScreen.QUALITY -> QualityScreen(strings, assemblyDataRepository, ::pop)
                    AppScreen.DAILY_ISSUE -> DailyIssueScreen(strings, assemblyDataRepository, ::pop)
                    AppScreen.MONITORING -> MonitoringScreen(strings, assemblyDataRepository, ::pop, isAdmin = accessPolicy.isAdmin())
                    AppScreen.MASTER_DATA -> MasterDataScreen(strings, assemblyDataRepository, ::pop)
                    AppScreen.USER_ADMIN -> UserManagementScreen(
                        strings = strings,
                        assemblyRepository = assemblyDataRepository,
                        tpRepository = tpDataRepository,
                        onBack = ::pop,
                        currentUid = accessPolicy.uid,
                        onSelfDeviceCodeReset = { userCode, deviceCode ->
                            preferences.saveSetup(deviceCode, userCode)
                        }
                    )
                    AppScreen.BACKUP_RESTORE -> BackupRestoreScreen(
                        strings = strings,
                        repository = assemblyDataRepository,
                        isAdmin = accessPolicy.isAdmin(),
                        allowedBrigadeIds = accessPolicy.allowedBrigadeIds,
                        onBack = ::pop
                    )
                }
            }
        }
    }
}
