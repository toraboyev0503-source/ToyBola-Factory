package uz.toybola.factory.core.firebase

import android.content.Context
import uz.toybola.factory.core.data.TpData
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy

class TpAccessGuard(context: Context) {
    private val appContext = context.applicationContext
    private val preferences = AppPreferences(appContext)
    private val cache = ServerPolicyCache(appContext)

    private fun policy(): UserAccessPolicy {
        val code = preferences.setup()?.userCode.orEmpty()
        return cache.load(code) ?: UserAccessPolicy.locked(code)
    }

    fun validate(before: TpData, after: TpData) {
        if (before == after) return
        val policy = policy()
        require(policy.source != "locked") { "Server ruxsati yuklanmagan. Internetga ulanib qayta kiring." }
        if (policy.isAdmin()) return

        if (before.shops != after.shops || before.shifts != after.shifts || before.machines != after.machines ||
            before.products != after.products || before.materials != after.materials || before.settings != after.settings
        ) requireWrite(policy, AssemblySection.TP_MASTER_DATA)

        changed(before.brigades, after.brigades) { it.id }.forEach { requireWrite(policy, AssemblySection.TP_MASTER_DATA, it.id) }
        changed(before.workers, after.workers) { it.id }.forEach { requireWrite(policy, AssemblySection.TP_MASTER_DATA, it.brigadeId) }
        changed(before.orders, after.orders) { it.id }.forEach { order ->
            require(
                policy.canWrite(AssemblySection.TP_ORDER) || policy.canWrite(AssemblySection.TP_PLANNING) ||
                    policy.canWrite(AssemblySection.TP_MACHINE) || policy.canWrite(AssemblySection.TP_RECEIVING)
            ) { "TP zakazini o‘zgartirishga ruxsat yo‘q" }
        }

        val oldJobs = before.jobs.associateBy { it.id }
        changed(before.jobs, after.jobs) { it.id }.forEach { job ->
            val old = oldJobs[job.id]
            val deleted = old != null && after.jobs.none { it.id == job.id }
            if (deleted) {
                require(policy.canWrite(AssemblySection.TP_ORDER) || policy.canWrite(AssemblySection.TP_PLANNING)) {
                    "TP zakaz vazifasini o‘chirishga ruxsat yo‘q"
                }
                return@forEach
            }
            job.brigadeId?.let { require(policy.canAccessBrigade(it)) { "Bu brigadaga ruxsat yo‘q" } }
            val materialChanged = old != null && (old.materialStatus != job.materialStatus ||
                old.materialConfirmedAt != job.materialConfirmedAt || old.materialDeliveredAt != job.materialDeliveredAt)
            if (materialChanged) requireWrite(policy, AssemblySection.TP_SERYO, job.brigadeId)
            else if (old != null && old.copy(status = job.status) == job) {
                require(
                    policy.canWrite(AssemblySection.TP_MACHINE) || policy.canWrite(AssemblySection.TP_RECEIVING)
                ) { "Stanok vazifasi holatini o‘zgartirishga ruxsat yo‘q" }
            }
            else require(
                policy.canWrite(AssemblySection.TP_PLANNING) || policy.canWrite(AssemblySection.TP_MACHINE)
            ) { "TP planini o‘zgartirishga ruxsat yo‘q" }
        }
        changed(before.attendance, after.attendance) { it.id }.forEach { requireWrite(policy, AssemblySection.TP_ATTENDANCE, it.brigadeId) }
        changed(before.receipts, after.receipts) { it.id }.forEach { requireWrite(policy, AssemblySection.TP_RECEIVING, it.brigadeId) }
        changed(before.qualityRounds, after.qualityRounds) { it.id }.forEach { requireWrite(policy, AssemblySection.TP_QUALITY, it.brigadeId) }
        changed(before.dailyIssues, after.dailyIssues) { it.id }.forEach { requireWrite(policy, AssemblySection.TP_QUALITY, it.brigadeId) }
    }

    private fun requireWrite(policy: UserAccessPolicy, section: AssemblySection, brigadeId: String? = null) {
        require(policy.canWrite(section)) { "${section.name} bo‘limida yozish ruxsati yo‘q" }
        brigadeId?.let { require(policy.canAccessBrigade(it)) { "Bu brigadaga ruxsat yo‘q" } }
    }

    private fun <T, K> changed(before: List<T>, after: List<T>, key: (T) -> K): List<T> {
        val old = before.associateBy(key)
        val now = after.associateBy(key)
        return (after.filter { old[key(it)] != it } + before.filter { now[key(it)] == null }).distinctBy(key)
    }
}
