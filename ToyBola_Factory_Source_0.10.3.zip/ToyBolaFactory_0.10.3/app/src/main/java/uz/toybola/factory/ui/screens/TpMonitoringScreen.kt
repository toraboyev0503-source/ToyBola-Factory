package uz.toybola.factory.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate

@Composable
fun TpMonitoringScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val revision by TpDataEvents.revision.collectAsState()
    val policy = remember(revision) { AccessGuard(context).currentPolicy() }
    val data = remember(revision, policy.revision) { repository.load().scopedFor(policy) }
    var from by remember { mutableStateOf(LocalDate.now().withDayOfMonth(1).toString()) }
    var to by remember { mutableStateOf(LocalDate.now().toString()) }
    var brigadeId by remember { mutableStateOf("") }
    var exportMessage by remember { mutableStateOf<String?>(null) }
    var pendingReport by remember { mutableStateOf<TpReportTable?>(null) }
    val word = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) { uri ->
        val report = pendingReport
        if (uri != null && report != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { output ->
                MonitoringDocxExporter.write(output, report.title, report.metadata, report.headers, report.rows)
            } ?: error("Fayl ochilmadi")
        }.onSuccess { exportMessage = "Word hisoboti saqlandi" }.onFailure { exportMessage = it.message ?: "Eksport xatosi" }
        pendingReport = null
    }
    val excel = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) { uri ->
        val report = pendingReport
        if (uri != null && report != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { output -> TpXlsxExporter.write(output, report) } ?: error("Fayl ochilmadi")
        }.onSuccess { exportMessage = "Excel hisoboti saqlandi" }.onFailure { exportMessage = it.message ?: "Eksport xatosi" }
        pendingReport = null
    }
    val report = remember(data, from, to, brigadeId) { buildTpReport(data, from, to, brigadeId.ifBlank { null }) }
    val orderIdsForBrigade = data.jobs.filter { brigadeId.isBlank() || it.brigadeId == brigadeId }.map { it.orderId }.toSet()
    val orders = data.orders.filter { order ->
        order.requestedDate in from..to && (brigadeId.isBlank() || order.id in orderIdsForBrigade)
    }
    val receipts = data.receipts.filter { it.date in from..to && (brigadeId.isBlank() || it.brigadeId == brigadeId) }
    val rounds = data.qualityRounds.filter { it.date in from..to && (brigadeId.isBlank() || it.brigadeId == brigadeId) }
    val scopedJobs = data.jobs.filter { brigadeId.isBlank() || it.brigadeId == brigadeId }
    val receiptJobIds = receipts.map { it.jobId }.toSet()
    val relevantJobs = scopedJobs.filter { job ->
        orders.any { it.id == job.orderId } || job.id in receiptJobIds ||
            (job.materialDeliveredAt ?: job.materialConfirmedAt)?.take(10)?.let { it in from..to } == true
    }
    val materialJobs = scopedJobs.filter { job ->
        job.materialStatus != TpMaterialStatus.PLANNED &&
            (job.materialDeliveredAt ?: job.materialConfirmedAt)?.take(10)?.let { it in from..to } == true
    }

    Column(Modifier.fillMaxSize()) {
        AppTopBar("TP monitoring", canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoringScreen-screen-1")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) { TpField(from, { from = it }, "Boshlanish") }
                Box(Modifier.weight(1f)) { TpField(to, { to = it }, "Tugash") }
            }
            TpChoice("Brigada", brigadeId, listOf<TpBrigade?>(null) + data.brigades.filterNot { it.archived }, { it?.id.orEmpty() }, { it?.name ?: "Barchasi" }) { brigadeId = it }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pendingReport = report; word.launch("ToyBola_TP_${from}_${to}.docx") }, Modifier.weight(1f)) { Text("Word") }
                OutlinedButton(onClick = { pendingReport = report; excel.launch("ToyBola_TP_${from}_${to}.xlsx") }, Modifier.weight(1f)) { Text("Excel") }
            }
            if (!exportMessage.isNullOrBlank()) Text(exportMessage!!, color = MaterialTheme.colorScheme.primary)

            Text("Umumiy natija", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TpMetric("Partiya", orders.size.toString(), Modifier.weight(1f))
                TpMetric("Yakunlangan", orders.count { it.status == TpOrderStatus.COMPLETE }.toString(), Modifier.weight(1f))
                TpMetric("Qabul", "${receipts.sumOf { it.creditedPieces }} dona", Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TpMetric("Stanok vazifa", relevantJobs.size.toString(), Modifier.weight(1f))
                TpMetric("Sifat", rounds.map { it.score }.takeIf { it.isNotEmpty() }?.average()?.toInt()?.let { "$it%" } ?: "—", Modifier.weight(1f))
                TpMetric("Muammo", data.dailyIssues.count { it.date in from..to && (brigadeId.isBlank() || it.brigadeId == brigadeId) }.toString(), Modifier.weight(1f))
            }

            Text("Partiyalar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            orders.sortedByDescending { it.createdAt }.forEach { order ->
                TpCard { Text("${order.batchNumber} • ${order.articleSnapshot}", fontWeight = FontWeight.Bold); Text("${order.quantity} dona • ${data.orderProgress(order.id).toInt()}% • ${orderStatusLabel(order.status)}"); order.completedAt?.let { Text("Yakun: ${it.take(16).replace('T', ' ')}") } }
            }

            Text("Brigadalar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            data.brigades.filterNot { it.archived }.filter { brigadeId.isBlank() || it.id == brigadeId }.forEach { brigade ->
                val brigadeReceipts = receipts.filter { it.brigadeId == brigade.id }
                val brigadeRounds = rounds.filter { it.brigadeId == brigade.id }
                val brigadeJobs = relevantJobs.filter { it.brigadeId == brigade.id }
                if (brigadeReceipts.isNotEmpty() || brigadeRounds.isNotEmpty() || brigadeJobs.isNotEmpty()) TpCard {
                    Text(brigade.name, fontWeight = FontWeight.Bold)
                    Text("Qabul: ${brigadeReceipts.sumOf { it.creditedPieces }} dona • Vazifa: ${brigadeJobs.size}")
                    Text("Sifat: ${brigadeRounds.map { it.score }.takeIf { it.isNotEmpty() }?.average()?.toInt()?.let { "$it%" } ?: "—"}")
                }
            }

            Text("Stanoklar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            relevantJobs.groupBy { it.machineId }.filterKeys { it != null }.entries.sortedBy { (machineId, _) -> data.machines.firstOrNull { it.id == machineId }?.number }.forEach { (machineId, jobs) ->
                val machine = data.machines.firstOrNull { it.id == machineId }
                val produced = receipts.filter { it.machineId == machineId }.sumOf { it.creditedPieces }
                TpCard {
                    Text("${machine?.number ?: 0}-stanok", fontWeight = FontWeight.Bold)
                    Text("${jobs.size} vazifa • ${jobs.count { it.status == TpJobStatus.COMPLETE }} yakunlangan • $produced dona qabul")
                }
            }

            Text("Ishchilar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            data.workers.filterNot { it.archived }.filter { brigadeId.isBlank() || it.brigadeId == brigadeId }.forEach { worker ->
                val earned = receipts.filter { it.workerId == worker.id }.sumOf { it.earnedAmount }
                val quality = rounds.filter { it.workerId == worker.id }.map { it.score }.takeIf { it.isNotEmpty() }?.average()
                val attendance = data.attendance.filter { it.workerId == worker.id && it.date in from..to && it.present }
                val target = attendance.sumOf { worker.dailyTargetAmount.toDouble() * it.workMinutes / worker.defaultWorkMinutes.coerceAtLeast(1) }
                val efficiency = if (target > 0) earned * 100.0 / target else null
                val usefulness = if (efficiency != null && quality != null) (efficiency + quality) / 2 else null
                TpCard {
                    Text(worker.name, fontWeight = FontWeight.Bold)
                    Text("Topdi: $earned so‘m • Norma: ${target.toLong()} so‘m")
                    Text("Samaradorlik ${efficiency?.toInt()?.let { "$it%" } ?: "—"} • Sifat ${quality?.toInt()?.let { "$it%" } ?: "—"} • Foydalilik ${usefulness?.toInt()?.let { "$it%" } ?: "—"}")
                }
            }

            Text("Seryo va krasitel", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            materialJobs.groupBy { it.resinCode }.forEach { (code, jobs) ->
                TpCard { Text(code, fontWeight = FontWeight.Bold); Text("${formatTpNumber(jobs.sumOf { it.requiredResinKg })} kg ishlatildi") }
            }
            materialJobs.groupBy { it.colorCode }.forEach { (code, jobs) ->
                TpCard { Text("$code rang", fontWeight = FontWeight.Bold); Text("${formatTpNumber(jobs.sumOf { it.requiredColorGrams })} gram ishlatildi") }
            }
        }
    }
}

@Composable
private fun TpMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, shape = MaterialTheme.shapes.medium, tonalElevation = 1.dp) {
        Column(Modifier.padding(10.dp)) { Text(value, fontWeight = FontWeight.Bold); Text(label, style = MaterialTheme.typography.bodySmall) }
    }
}
