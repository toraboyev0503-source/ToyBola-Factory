package uz.toybola.factory.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate

@Composable
fun TpSeryoScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val serverRevision by TpDataEvents.revision.collectAsState()
    var revision by remember { mutableIntStateOf(0) }
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(serverRevision, revision, policy.revision) { repository.load().scopedFor(policy) }
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_SERYO)
    var error by remember { mutableStateOf<String?>(null) }
    val approvedOrderIds = data.orders.filter { it.planApprovedAt != null }.map { it.id }.toSet()
    val jobs = data.jobs.filter { it.orderId in approvedOrderIds && it.machineId != null && it.status != TpJobStatus.COMPLETE }.sortedBy { it.priority }
    val resinNeed = jobs.groupBy { it.resinCode }.mapValues { it.value.sumOf(TpPlanJob::requiredResinKg) }
    val colorNeed = jobs.groupBy { it.colorCode }.mapValues { it.value.sumOf(TpPlanJob::requiredColorGrams) }
    fun refresh() { revision++ }

    Column(Modifier.fillMaxSize()) {
        AppTopBar("Seryo", canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpOperationsScreens-screen-1")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Faol zakazlar uchun jami ehtiyoj", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            (resinNeed.map { (code, amount) -> Triple(code, amount, TpMaterialType.RESIN) } +
                colorNeed.map { (code, amount) -> Triple(code, amount, TpMaterialType.COLOR) }).forEach { (code, need, type) ->
                val available = data.materials.firstOrNull { it.type == type && it.code.equals(code, true) }?.availableAmount ?: 0.0
                val unit = if (type == TpMaterialType.RESIN) "kg" else "g"
                Text("$code: ${formatTpNumber(need)} $unit kerak / ${formatTpNumber(available)} $unit mavjud",
                    color = if (available >= need) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            }
            HorizontalDivider()
            if (jobs.isEmpty()) Text("Tayyorlanadigan qorishma yo‘q.")
            jobs.forEach { job ->
                val order = data.orders.firstOrNull { it.id == job.orderId }
                val machine = data.machines.firstOrNull { it.id == job.machineId }
                TpCard {
                    Text("${order?.batchNumber.orEmpty()} • ${machine?.number ?: 0}-stanok", fontWeight = FontWeight.Bold)
                    Text("${job.moldCode} • rang ${job.colorCode} • ${job.requiredShots} jim")
                    Text("${formatTpNumber(job.requiredResinKg)} kg ${job.resinCode}", style = MaterialTheme.typography.titleMedium)
                    Text("${formatTpNumber(job.requiredColorGrams)} gram ${job.colorCode} krasitel")
                    if (job.requiredResinKg > 0) Text("Nisbat: 25 kg ga ${formatTpNumber(job.requiredColorGrams * 25.0 / job.requiredResinKg)} gram")
                    Text("Holat: ${materialStatusLabel(job.materialStatus)}", color = MaterialTheme.colorScheme.primary)
                    if (canWrite && job.materialStatus == TpMaterialStatus.PLANNED) Button(onClick = {
                        error = repository.confirmMaterial(job.id, delivered = false).exceptionOrNull()?.message
                        if (error == null) refresh()
                    }, Modifier.fillMaxWidth()) { Text("Qorishma tayyor — tasdiqlash") }
                    if (canWrite && job.materialStatus == TpMaterialStatus.CONFIRMED) Button(onClick = {
                        error = repository.confirmMaterial(job.id, delivered = true).exceptionOrNull()?.message
                        if (error == null) refresh()
                    }, Modifier.fillMaxWidth()) { Text("Stanokka olib chiqildi") }
                }
            }
            TpError(error)
        }
    }
}

@Composable
fun TpReceivingScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val serverRevision by TpDataEvents.revision.collectAsState()
    var revision by remember { mutableIntStateOf(0) }
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(serverRevision, revision, policy.revision) { repository.load().scopedFor(policy) }
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_RECEIVING)
    val approvedOrderIds = data.orders.filter { it.planApprovedAt != null }.map { it.id }.toSet()
    val jobs = data.jobs.filter { it.orderId in approvedOrderIds && it.machineId != null && it.status != TpJobStatus.COMPLETE }.sortedBy { it.priority }
    var jobId by remember(jobs.map { it.id }) { mutableStateOf(jobs.firstOrNull()?.id.orEmpty()) }
    val job = jobs.firstOrNull { it.id == jobId }
    var detailId by remember(jobId) { mutableStateOf(job?.outputs?.firstOrNull()?.detailId.orEmpty()) }
    val output = job?.outputs?.firstOrNull { it.detailId == detailId }
    val workers = data.workers.filter { !it.archived && it.brigadeId == job?.brigadeId }.sortedBy { it.name }
    var workerId by remember(jobId, workers.map { it.id }) { mutableStateOf(workers.firstOrNull()?.id.orEmpty()) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var bags by remember { mutableStateOf("0") }
    var remainder by remember(jobId, detailId, revision) { mutableStateOf((job?.let { data.openRemainder(it.id, detailId) } ?: 0).toString()) }
    var receiver by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    val carry = job?.let { data.openRemainder(it.id, detailId) } ?: 0
    val preview = if (output != null) runCatching {
        calculateReceiptCredit(output.bagCapacity, carry, bags.toIntOrNull() ?: 0, remainder.toIntOrNull() ?: 0)
    }.getOrNull() else null

    Column(Modifier.fillMaxSize()) {
        AppTopBar("Qabul qilish", canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpOperationsScreens-screen-2")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Qabul qiluvchi asosan qop sonini yozadi. Oldingi smenadan qolgan yarim qop avtomatik ayriladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (jobs.isEmpty()) Text("Qabul qilinadigan faol stanok vazifasi yo‘q.")
            TpChoice("Vazifa", jobId, jobs, { it.id }, { item ->
                val machine = data.machines.firstOrNull { it.id == item.machineId }?.number ?: 0
                val order = data.orders.firstOrNull { it.id == item.orderId }?.batchNumber.orEmpty()
                "$machine-stanok • $order • ${item.moldCode} • ${item.colorCode}"
            }) { jobId = it }
            if (job != null) TpChoice("Detal", detailId, job.outputs, { it.detailId }, { it.detailName }) { detailId = it }
            TpChoice("Ishchi", workerId, workers, { it.id }, { it.name }) { workerId = it }
            TpField(date, { date = it }, "Sana (YYYY-MM-DD)")
            TpField(bags, { bags = digitsOnly(it) }, "Yopilgan to‘liq qop soni", KeyboardType.Number)
            TpField(remainder, { remainder = digitsOnly(it) }, "Amaldan keyingi qop qoldig‘i", KeyboardType.Number)
            TpField(receiver, { receiver = it }, "Qabul qiluvchi ismi")
            if (output != null) {
                TpCard {
                    Text("Qop sig‘imi: ${output.bagCapacity} dona")
                    Text("Oldingi smenadan qoldiq: $carry dona", fontWeight = FontWeight.Bold)
                    if (preview != null) Text("Bu ishchiga yoziladi: $preview dona", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    else Text("Qop va qoldiq sonini tekshiring", color = MaterialTheme.colorScheme.error)
                }
            }
            Button(enabled = canWrite && job != null && output != null && workerId.isNotBlank() && preview != null, onClick = {
                val result = repository.addReceipt(jobId, detailId, workerId, date, bags.toIntOrNull() ?: 0, remainder.toIntOrNull() ?: 0, receiver)
                message = result.exceptionOrNull()?.message ?: "Qabul qilindi: $preview dona"
                if (result.isSuccess) { bags = "0"; revision++ }
            }, modifier = Modifier.fillMaxWidth()) { Text("Qabul qilish") }
            if (!message.isNullOrBlank()) Text(message!!, color = if (message!!.startsWith("Qabul")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            HorizontalDivider()
            Text("Bugungi qabul", fontWeight = FontWeight.Bold)
            data.receipts.filter { it.date == date }.sortedByDescending { it.createdAt }.take(50).forEach { receipt ->
                TpCard {
                    Text("${receipt.workerNameSnapshot} • ${receipt.detailNameSnapshot} • ${receipt.creditedPieces} dona", fontWeight = FontWeight.Bold)
                    Text("${receipt.completedBags} qop • oldingi ${receipt.carryInPieces} • yangi qoldiq ${receipt.remainderAfter}")
                    Text("Qabul qildi: ${receipt.receiverName}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun TpQualityScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val serverRevision by TpDataEvents.revision.collectAsState()
    var revision by remember { mutableIntStateOf(0) }
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(serverRevision, revision, policy.revision) { repository.load().scopedFor(policy) }
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_QUALITY)
    var mode by remember { mutableStateOf("ROUND") }
    Column(Modifier.fillMaxSize()) {
        AppTopBar("TP sifat", canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpOperationsScreens-screen-3")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(mode == "ROUND", { mode = "ROUND" }, SegmentedButtonDefaults.itemShape(0, 2)) { Text("Raund") }
                SegmentedButton(mode == "ISSUE", { mode = "ISSUE" }, SegmentedButtonDefaults.itemShape(1, 2)) { Text("Kun muammosi") }
            }
            if (mode == "ROUND") TpQualityRoundForm(data, repository, canWrite) { revision++ }
            else TpDailyIssueForm(data, repository, canWrite) { revision++ }
        }
    }
}

@Composable
private fun TpQualityRoundForm(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    val approvedOrderIds = data.orders.filter { it.planApprovedAt != null }.map { it.id }.toSet()
    val jobs = data.jobs.filter { it.orderId in approvedOrderIds && it.machineId != null && it.status != TpJobStatus.COMPLETE }.sortedBy { it.priority }
    var jobId by remember(jobs.map { it.id }) { mutableStateOf(jobs.firstOrNull()?.id.orEmpty()) }
    val job = jobs.firstOrNull { it.id == jobId }
    val workers = data.workers.filter { !it.archived && it.brigadeId == job?.brigadeId }
    var workerId by remember(jobId) { mutableStateOf(workers.firstOrNull()?.id.orEmpty()) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    val shift = data.shifts.firstOrNull { it.id == job?.shiftId }
    var round by remember(jobId) { mutableStateOf("1") }
    var score by remember { mutableStateOf("100") }
    var issue by remember { mutableStateOf("") }
    var checker by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    if (jobs.isEmpty()) Text("Tekshiriladigan faol stanok vazifasi yo‘q.")
    TpChoice("Stanok vazifasi", jobId, jobs, { it.id }, { item ->
        val machine = data.machines.firstOrNull { it.id == item.machineId }?.number ?: 0
        "$machine-stanok • ${item.moldCode} • ${item.colorCode}"
    }) { jobId = it }
    TpChoice("Ishchi", workerId, workers, { it.id }, { it.name }) { workerId = it }
    TpField(date, { date = it }, "Sana (YYYY-MM-DD)")
    TpChoice("Raund", round, shift?.roundTimes.orEmpty().mapIndexed { index, time -> (index + 1) to time }, { it.first.toString() }, { "${it.first}-raund • ${it.second}" }) { round = it }
    TpField(score, { score = digitsOnly(it) }, "Baho (0–100)", KeyboardType.Number)
    TpField(issue, { issue = it }, "Muammo/izoh", singleLine = false)
    TpField(checker, { checker = it }, "Sifat nazoratchisi")
    Button(enabled = canWrite && job != null && workerId.isNotBlank(), onClick = {
        val result = repo.saveQualityRound(jobId, workerId, date, round.toIntOrNull() ?: 1, score.toIntOrNull() ?: -1, issue, checker)
        message = result.exceptionOrNull()?.message ?: "Raund saqlandi"
        if (result.isSuccess) refresh()
    }, modifier = Modifier.fillMaxWidth()) { Text("Raundni saqlash") }
    if (!message.isNullOrBlank()) Text(message!!, color = if (message == "Raund saqlandi") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
    HorizontalDivider()
    data.qualityRounds.filter { it.date == date }.sortedWith(compareBy({ it.machineId }, { it.round })).forEach { record ->
        val worker = data.workers.firstOrNull { it.id == record.workerId }?.name.orEmpty()
        val machine = data.machines.firstOrNull { it.id == record.machineId }?.number ?: 0
        TpCard { Text("$machine-stanok • $worker • ${record.round}-raund", fontWeight = FontWeight.Bold); Text("${record.score}% • ${record.issue.ifBlank { "Muammo yo‘q" }}") }
    }
}

@Composable
private fun TpDailyIssueForm(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    val brigades = data.brigades.filterNot { it.archived }
    var brigadeId by remember { mutableStateOf(brigades.firstOrNull()?.id.orEmpty()) }
    val machines = data.machines.filter { machine -> data.brigades.firstOrNull { it.id == brigadeId }?.shopId == machine.shopId }
    var machineId by remember(brigadeId) { mutableStateOf("") }
    var orderId by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var title by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    TpChoice("Brigada", brigadeId, brigades, { it.id }, { it.name }) { brigadeId = it }
    TpChoice("Stanok (ixtiyoriy)", machineId, listOf<TpMachine?>(null) + machines, { it?.id.orEmpty() }, { it?.let { machine -> "${machine.number}-stanok" } ?: "Belgilanmagan" }) { machineId = it }
    TpChoice("Partiya (ixtiyoriy)", orderId, listOf<TpOrder?>(null) + data.orders, { it?.id.orEmpty() }, { it?.let { order -> "${order.batchNumber} • ${order.articleSnapshot}" } ?: "Belgilanmagan" }) { orderId = it }
    TpField(date, { date = it }, "Sana (YYYY-MM-DD)")
    TpField(title, { title = it }, "Muammo nomi")
    TpField(note, { note = it }, "Batafsil izoh", singleLine = false)
    Button(enabled = canWrite && brigadeId.isNotBlank(), onClick = {
        val result = repo.addDailyIssue(brigadeId, date, machineId.ifBlank { null }, orderId.ifBlank { null }, title, note)
        message = result.exceptionOrNull()?.message ?: "Kun muammosi saqlandi"
        if (result.isSuccess) { title = ""; note = ""; refresh() }
    }, modifier = Modifier.fillMaxWidth()) { Text("Muammoni saqlash") }
    if (!message.isNullOrBlank()) Text(message!!, color = if (message!!.startsWith("Kun")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
    HorizontalDivider()
    data.dailyIssues.filter { it.date == date && (brigadeId.isBlank() || it.brigadeId == brigadeId) }.sortedByDescending { it.createdAt }.forEach { issue ->
        TpCard { Text(issue.title, fontWeight = FontWeight.Bold); Text(issue.note); Text(issue.createdAt.take(16).replace('T', ' '), style = MaterialTheme.typography.bodySmall) }
    }
}
