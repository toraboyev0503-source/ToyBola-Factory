package uz.toybola.factory.core.data

import org.w3c.dom.Element
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.util.Locale
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

/** One validated detail row from the standard TP Excel template. */
data class TpExcelDetailRow(
    val article: String,
    val productName: String,
    val detailName: String,
    val requiredPerProduct: Int,
    val piecesPerShot: Int,
    val bagCapacity: Int,
    val cycleSeconds: Int,
    val grossShotWeightGrams: Double,
    val unusableShotWeightGrams: Double,
    val resinCodes: List<String>,
    val unitPrice: Double,
    val compatibleCapacities: Set<Int>
)

data class TpExcelColorRow(
    val article: String,
    val detailName: String,
    val colorCode: String,
    val share: Double,
    val gramsPer25Kg: Double
)

data class TpExcelImportPayload(
    val details: List<TpExcelDetailRow>,
    val colors: List<TpExcelColorRow>
) {
    val productCount: Int get() = details.map { it.article.uppercase(Locale.ROOT) }.distinct().size
    val detailCount: Int get() = details.size
    val colorCount: Int get() = colors.size
}

/**
 * Lightweight XLSX reader used only for the ToyBola TP import template.
 * It intentionally has no Apache POI dependency, keeping the Android APK small and predictable.
 */
object TpExcelImporter {
    private const val PRODUCTS_SHEET = "Mahsulotlar"
    private const val COLORS_SHEET = "Ranglar"

    fun parse(input: InputStream): TpExcelImportPayload {
        val entries = readZip(input)
        require(entries.containsKey("xl/workbook.xml")) { "Bu Excel (.xlsx) fayli emas yoki fayl buzilgan" }

        val sharedStrings = entries["xl/sharedStrings.xml"]?.let(::parseSharedStrings).orEmpty()
        val sheets = sheetTargets(entries)
        val productsPath = sheets[PRODUCTS_SHEET]
            ?: error("Excelda '$PRODUCTS_SHEET' varag‘i topilmadi. Standart shablondan foydalaning.")
        val colorsPath = sheets[COLORS_SHEET]
            ?: error("Excelda '$COLORS_SHEET' varag‘i topilmadi. Standart shablondan foydalaning.")

        val productRows = parseSheet(entries[productsPath] ?: error("$PRODUCTS_SHEET varag‘i o‘qilmadi"), sharedStrings)
        val colorRows = parseSheet(entries[colorsPath] ?: error("$COLORS_SHEET varag‘i o‘qilmadi"), sharedStrings)

        val details = parseDetails(productRows)
        val colors = parseColors(colorRows)
        require(details.isNotEmpty()) { "Mahsulotlar varag‘ida import qilinadigan detal yo‘q" }

        val detailKeys = details.map { key(it.article, it.detailName) }.toSet()
        val missingColors = details.filter { detail -> colors.none { key(it.article, it.detailName) == key(detail.article, detail.detailName) } }
        require(missingColors.isEmpty()) {
            "Quyidagi detallarga Ranglar varag‘ida rang kiritilmagan: " +
                missingColors.take(5).joinToString { "${it.article}/${it.detailName}" } +
                if (missingColors.size > 5) " ..." else ""
        }
        val unknownColors = colors.filter { key(it.article, it.detailName) !in detailKeys }
        require(unknownColors.isEmpty()) {
            "Ranglar varag‘ida Mahsulotlar varag‘ida yo‘q detal bor: " +
                unknownColors.take(5).joinToString { "${it.article}/${it.detailName}" }
        }

        return TpExcelImportPayload(details, colors)
    }

    private fun parseDetails(rows: List<List<String>>): List<TpExcelDetailRow> {
        require(rows.isNotEmpty()) { "Mahsulotlar varag‘i bo‘sh" }
        val headers = HeaderMap(rows.first())
        val ixArticle = headers.required("Artikul")
        val ixProduct = headers.required("Mahsulot nomi")
        val ixDetail = headers.required("Detal nomi")
        val ixRequired = headers.required("1 mahsulotga nechta")
        val ixPerShot = headers.required("1 jimda nechta")
        val ixBag = headers.required("1 qopda nechta")
        val ixCycle = headers.required("1 jim vaqti (sekund)")
        val ixGross = headers.required("1 jim umumiy og'irligi (g)", "1 jim umumiy og‘irligi (g)")
        val ixUnusable = headers.required("Yaroqsiz qism og'irligi (g)", "Yaroqsiz qism og‘irligi (g)")
        val ixResins = headers.required("Seryo turlari")
        val ixPrice = headers.required("1 jim narxi (so'm)", "1 jim narxi (so‘m)")
        val ixCapacities = headers.required("Stanok sig'imlari", "Stanok sig‘imlari")

        val result = mutableListOf<TpExcelDetailRow>()
        val seen = mutableSetOf<String>()
        rows.drop(1).forEachIndexed { offset, row ->
            if (row.all { it.isBlank() }) return@forEachIndexed
            val line = offset + 2
            fun text(index: Int, label: String): String = cell(row, index).trim().also {
                require(it.isNotBlank()) { "$PRODUCTS_SHEET $line-qator: '$label' bo‘sh" }
            }
            val article = text(ixArticle, "Artikul").uppercase(Locale.ROOT)
            val product = text(ixProduct, "Mahsulot nomi")
            val detail = text(ixDetail, "Detal nomi")
            val rowKey = key(article, detail)
            require(seen.add(rowKey)) { "$PRODUCTS_SHEET $line-qator: $article/$detail takrorlangan" }

            val resins = splitCodes(text(ixResins, "Seryo turlari"))
            require(resins.isNotEmpty()) { "$PRODUCTS_SHEET $line-qator: kamida bitta seryo turi kerak" }
            val capacities = splitInts(text(ixCapacities, "Stanok sig‘imlari"))
            require(capacities.isNotEmpty()) { "$PRODUCTS_SHEET $line-qator: stanok sig‘imlarini kiriting" }

            val required = intValue(cell(row, ixRequired), "$PRODUCTS_SHEET $line-qator: 1 mahsulotga nechta")
            val perShot = intValue(cell(row, ixPerShot), "$PRODUCTS_SHEET $line-qator: 1 jimda nechta")
            val bag = intValue(cell(row, ixBag), "$PRODUCTS_SHEET $line-qator: 1 qopda nechta")
            val cycle = intValue(cell(row, ixCycle), "$PRODUCTS_SHEET $line-qator: 1 jim vaqti")
            val gross = decimalValue(cell(row, ixGross), "$PRODUCTS_SHEET $line-qator: umumiy og‘irlik")
            val unusable = decimalValue(cell(row, ixUnusable), "$PRODUCTS_SHEET $line-qator: yaroqsiz og‘irlik")
            val price = decimalValue(cell(row, ixPrice), "$PRODUCTS_SHEET $line-qator: 1 jim narxi")

            require(required > 0 && perShot > 0 && bag > 0 && cycle > 0) { "$PRODUCTS_SHEET $line-qator: sonli normativlar 0 dan katta bo‘lsin" }
            require(gross > 0.0 && unusable in 0.0..gross) { "$PRODUCTS_SHEET $line-qator: og‘irliklarni tekshiring" }
            require(price >= 0.0) { "$PRODUCTS_SHEET $line-qator: narx manfiy bo‘lmasin" }

            result += TpExcelDetailRow(article, product, detail, required, perShot, bag, cycle, gross, unusable, resins, price, capacities)
        }
        val productNames = result.groupBy { it.article }.mapValues { (_, values) -> values.map { it.productName.trim() }.distinct() }
        val inconsistent = productNames.filterValues { it.size > 1 }
        require(inconsistent.isEmpty()) { "Bitta artikul uchun mahsulot nomi turlicha yozilgan: ${inconsistent.keys.take(5).joinToString()}" }
        return result
    }

    private fun parseColors(rows: List<List<String>>): List<TpExcelColorRow> {
        require(rows.isNotEmpty()) { "Ranglar varag‘i bo‘sh" }
        val headers = HeaderMap(rows.first())
        val ixArticle = headers.required("Artikul")
        val ixDetail = headers.required("Detal nomi")
        val ixColor = headers.required("Rang kodi")
        val ixShare = headers.required("Taqsimot ulushi")
        val ixGrams = headers.required("25 kg ga krasitel (g)")

        val result = mutableListOf<TpExcelColorRow>()
        val seen = mutableSetOf<String>()
        rows.drop(1).forEachIndexed { offset, row ->
            if (row.all { it.isBlank() }) return@forEachIndexed
            val line = offset + 2
            val article = cell(row, ixArticle).trim().uppercase(Locale.ROOT)
            val detail = cell(row, ixDetail).trim()
            val color = cell(row, ixColor).trim().uppercase(Locale.ROOT)
            require(article.isNotBlank() && detail.isNotBlank() && color.isNotBlank()) { "$COLORS_SHEET $line-qator: artikul, detal va rang kodi majburiy" }
            val share = decimalValue(cell(row, ixShare), "$COLORS_SHEET $line-qator: taqsimot ulushi")
            val grams = decimalValue(cell(row, ixGrams), "$COLORS_SHEET $line-qator: krasitel")
            require(share > 0.0 && grams >= 0.0) { "$COLORS_SHEET $line-qator: ulush > 0 va krasitel >= 0 bo‘lsin" }
            val unique = "${key(article, detail)}|$color"
            require(seen.add(unique)) { "$COLORS_SHEET $line-qator: $article/$detail/$color takrorlangan" }
            result += TpExcelColorRow(article, detail, color, share, grams)
        }
        return result
    }

    private fun readZip(input: InputStream): Map<String, ByteArray> {
        val result = linkedMapOf<String, ByteArray>()
        ZipInputStream(input.buffered()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) result[entry.name] = zip.readBytes()
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        return result
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val doc = document(bytes)
        val nodes = doc.getElementsByTagNameNS("*", "si")
        return (0 until nodes.length).map { index ->
            val si = nodes.item(index) as Element
            val texts = si.getElementsByTagNameNS("*", "t")
            buildString { for (i in 0 until texts.length) append(texts.item(i).textContent) }
        }
    }

    private fun sheetTargets(entries: Map<String, ByteArray>): Map<String, String> {
        val workbook = document(entries.getValue("xl/workbook.xml"))
        val relsBytes = entries["xl/_rels/workbook.xml.rels"] ?: error("Excel relationships topilmadi")
        val relsDoc = document(relsBytes)
        val relationships = mutableMapOf<String, String>()
        val relNodes = relsDoc.getElementsByTagNameNS("*", "Relationship")
        for (i in 0 until relNodes.length) {
            val e = relNodes.item(i) as Element
            relationships[e.getAttribute("Id")] = e.getAttribute("Target")
        }
        val result = linkedMapOf<String, String>()
        val sheetNodes = workbook.getElementsByTagNameNS("*", "sheet")
        for (i in 0 until sheetNodes.length) {
            val e = sheetNodes.item(i) as Element
            val name = e.getAttribute("name")
            val rid = e.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id")
                .ifBlank { e.getAttribute("r:id") }
            val target = relationships[rid] ?: continue
            val normalized = when {
                target.startsWith("/") -> target.removePrefix("/")
                target.startsWith("xl/") -> target
                else -> "xl/$target"
            }.replace("../", "")
            result[name] = normalized
        }
        return result
    }

    private fun parseSheet(bytes: ByteArray, sharedStrings: List<String>): List<List<String>> {
        val doc = document(bytes)
        val rowNodes = doc.getElementsByTagNameNS("*", "row")
        val rows = mutableListOf<List<String>>()
        for (i in 0 until rowNodes.length) {
            val row = rowNodes.item(i) as Element
            val cells = row.getElementsByTagNameNS("*", "c")
            val values = mutableMapOf<Int, String>()
            var maxCol = -1
            for (j in 0 until cells.length) {
                val cell = cells.item(j) as Element
                val ref = cell.getAttribute("r")
                val col = columnIndex(ref)
                if (col < 0) continue
                maxCol = maxOf(maxCol, col)
                val type = cell.getAttribute("t")
                val value = when (type) {
                    "inlineStr" -> {
                        val t = cell.getElementsByTagNameNS("*", "t")
                        buildString { for (k in 0 until t.length) append(t.item(k).textContent) }
                    }
                    "s" -> {
                        val raw = firstText(cell, "v")
                        raw.toIntOrNull()?.let { sharedStrings.getOrNull(it) }.orEmpty()
                    }
                    "b" -> if (firstText(cell, "v") == "1") "TRUE" else "FALSE"
                    else -> firstText(cell, "v")
                }
                values[col] = value
            }
            if (maxCol >= 0) rows += (0..maxCol).map { values[it].orEmpty() }
        }
        return rows
    }

    private fun firstText(parent: Element, localName: String): String {
        val nodes = parent.getElementsByTagNameNS("*", localName)
        return if (nodes.length > 0) nodes.item(0).textContent.orEmpty() else ""
    }

    private fun document(bytes: ByteArray) = DocumentBuilderFactory.newInstance().apply {
        isNamespaceAware = true
        runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
        runCatching { setFeature("http://xml.org/sax/features/external-general-entities", false) }
        runCatching { setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
    }.newDocumentBuilder().parse(ByteArrayInputStream(bytes))

    private fun columnIndex(ref: String): Int {
        val letters = ref.takeWhile { it.isLetter() }.uppercase(Locale.ROOT)
        if (letters.isBlank()) return -1
        var value = 0
        letters.forEach { value = value * 26 + (it - 'A' + 1) }
        return value - 1
    }

    private fun cell(row: List<String>, index: Int): String = row.getOrNull(index).orEmpty()
    private fun decimalValue(raw: String, label: String): Double = raw.trim().replace(',', '.').toDoubleOrNull()
        ?.takeIf { it.isFinite() } ?: error("$label noto‘g‘ri")
    private fun intValue(raw: String, label: String): Int {
        val value = decimalValue(raw, label)
        require(value % 1.0 == 0.0 && value in 1.0..Int.MAX_VALUE.toDouble()) { "$label butun son bo‘lishi kerak" }
        return value.toInt()
    }
    private fun splitCodes(raw: String): List<String> = raw.split(',', '/', ';').map { it.trim().uppercase(Locale.ROOT) }.filter { it.isNotBlank() }.distinct()
    private fun splitInts(raw: String): Set<Int> = raw.split(',', '/', ';', ' ').mapNotNull { it.trim().toIntOrNull() }.filter { it > 0 }.toSet()
    private fun key(article: String, detail: String): String = article.trim().uppercase(Locale.ROOT) + "|" + detail.trim().lowercase(Locale.ROOT)

    private class HeaderMap(headerRow: List<String>) {
        private val indexes = headerRow.mapIndexed { index, value -> normalize(value) to index }.toMap()
        fun required(vararg aliases: String): Int = aliases.firstNotNullOfOrNull { indexes[normalize(it)] }
            ?: error("Ustun topilmadi: ${aliases.first()}")
        private fun normalize(value: String): String = value.trim().lowercase(Locale.ROOT)
            .replace('‘', '\'').replace('’', '\'').replace('`', '\'')
            .replace(Regex("\\s+"), " ")
    }
}
