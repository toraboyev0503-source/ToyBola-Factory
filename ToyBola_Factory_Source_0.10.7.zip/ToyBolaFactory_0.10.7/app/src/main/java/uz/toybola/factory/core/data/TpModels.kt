package uz.toybola.factory.core.data

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.roundToLong

enum class TpMaterialType { RESIN, COLOR }
enum class TpMaterialMovementKind { IN, OUT }
enum class TpOrderStatus { NEW, PLANNING, READY, APPROVED, IN_PROGRESS, COMPLETE, CANCELLED }
enum class TpJobStatus { UNASSIGNED, QUEUED, IN_PROGRESS, COMPLETE, HOLD }
enum class TpMaterialStatus { PLANNED, CONFIRMED, DELIVERED }

data class TpShop(
    val id: String,
    val name: String,
    val archived: Boolean = false
)

data class TpShift(
    val id: String,
    val name: String,
    val startTime: String,
    val endTime: String,
    val roundTimes: List<String>,
    val archived: Boolean = false
) {
    fun durationMinutes(): Int {
        val start = LocalTime.parse(startTime)
        val end = LocalTime.parse(endTime)
        val raw = Duration.between(start, end).toMinutes()
        return (if (raw <= 0) raw + 24 * 60 else raw).toInt()
    }
}

data class TpBrigade(
    val id: String,
    val shopId: String,
    val shiftId: String,
    val name: String,
    val archived: Boolean = false
)

data class TpMachine(
    val id: String,
    val shopId: String,
    val number: Int,
    val name: String = "",
    val archived: Boolean = false,
    /** Injection/moulding machine clamp/capacity class. 0 keeps legacy data unrestricted until configured. */
    val capacity: Int = 0
)

data class TpWorker(
    val id: String,
    val brigadeId: String,
    val name: String,
    val dailyTargetAmount: Long,
    /** Legacy field kept only for backward JSON compatibility; calculations use the brigade shift duration. */
    val defaultWorkMinutes: Int = 0,
    val archived: Boolean = false
)

data class TpColorRule(
    val colorCode: String,
    val share: Double,
    val gramsPer25Kg: Double
)

/**
 * A detail is one required component of a finished toy. Details that come from the same mould
 * share [moldCode]. Each detail still keeps its own output-per-shot and product requirement.
 */
data class TpDetail(
    val id: String,
    val name: String,
    val moldCode: String,
    val requiredPerProduct: Int,
    val piecesPerShot: Int,
    val bagCapacity: Int,
    val cycleSeconds: Int,
    val grossShotWeightGrams: Double,
    val unusableShotWeightGrams: Double,
    val resinCode: String,
    val unitPrice: Double,
    val compatibleMachineIds: Set<String>,
    /** Allowed machine capacity classes such as 60/90/120. Empty is tolerated only for legacy records until configured. */
    val compatibleCapacities: Set<Int> = emptySet(),
    val colors: List<TpColorRule>,
    val archived: Boolean = false,
    /** Allowed resin/raw-material codes for this detail. [resinCode] is kept as the legacy/default code. */
    val resinCodes: List<String> = emptyList()
) {
    fun estimatedPiecesIn12Hours(): Int = if (cycleSeconds > 0) (12 * 60 * 60 / cycleSeconds) * piecesPerShot else 0
}

data class TpProduct(
    val id: String,
    val article: String,
    val name: String,
    val details: List<TpDetail> = emptyList(),
    val archived: Boolean = false
)

data class TpMaterialMovement(
    val id: String,
    val kind: TpMaterialMovementKind,
    val amount: Double,
    val createdAt: String,
    val note: String = "",
    val sourceJobId: String? = null
)

data class TpMaterial(
    val id: String,
    val code: String,
    val name: String,
    val type: TpMaterialType,
    /** Legacy/opening balance. New stock changes are stored in [movements]. */
    val availableAmount: Double,
    val archived: Boolean = false,
    val movements: List<TpMaterialMovement> = emptyList()
)

data class TpOrder(
    val id: String,
    val batchNumber: String,
    val productId: String,
    val articleSnapshot: String,
    val productNameSnapshot: String,
    val quantity: Int,
    val priority: Int,
    val requestedDate: String,
    val note: String,
    val status: TpOrderStatus,
    val createdAt: String,
    val completedAt: String? = null,
    /** Set only when the planner presses “Jarayonni boshlash”. */
    val planApprovedAt: String? = null
)

data class TpJobOutput(
    val detailId: String,
    val detailName: String,
    val requiredPieces: Int,
    val plannedPieces: Int,
    val piecesPerShot: Int,
    val bagCapacity: Int,
    val unitPrice: Double
) {
    val extraPieces: Int get() = (plannedPieces - requiredPieces).coerceAtLeast(0)
}

data class TpPlanJob(
    val id: String,
    val orderId: String,
    val moldCode: String,
    val colorCode: String,
    val outputs: List<TpJobOutput>,
    val requiredShots: Int,
    val cycleSeconds: Int,
    val estimatedMinutes: Int,
    val resinCode: String,
    val requiredResinKg: Double,
    val requiredColorGrams: Double,
    val compatibleMachineIds: Set<String>,
    val machineId: String? = null,
    val brigadeId: String? = null,
    val shiftId: String? = null,
    val priority: Int,
    val status: TpJobStatus = TpJobStatus.UNASSIGNED,
    val materialStatus: TpMaterialStatus = TpMaterialStatus.PLANNED,
    val materialConfirmedAt: String? = null,
    val materialDeliveredAt: String? = null
)

data class TpAttendance(
    val id: String,
    val workerId: String,
    val brigadeId: String,
    val shiftId: String,
    val date: String,
    val present: Boolean,
    val workMinutes: Int,
    val updatedAt: String
)

/**
 * [completedBags] is the number of physically closed bags. [creditedPieces] excludes the pieces
 * already credited to the previous shift's open bag, preventing a 30 + 70 bag becoming 30 + 100.
 */
data class TpReceipt(
    val id: String,
    val jobId: String,
    val orderId: String,
    val detailId: String,
    val detailNameSnapshot: String,
    val machineId: String,
    val workerId: String,
    val workerNameSnapshot: String,
    val brigadeId: String,
    val shiftId: String,
    val date: String,
    val colorCode: String,
    val completedBags: Int,
    val bagCapacity: Int,
    val carryInPieces: Int,
    val remainderAfter: Int,
    val creditedPieces: Int,
    val unitPriceSnapshot: Double,
    val receiverName: String,
    val createdAt: String,
    /** Price is per mould shot (jim), so receipt pieces must be converted back to shot-equivalent. */
    val piecesPerShotSnapshot: Int = 1
) {
    val earnedAmount: Long get() = calculatePieceWorkAmount(creditedPieces, piecesPerShotSnapshot, unitPriceSnapshot)
}

data class TpQualityRound(
    val id: String,
    val brigadeId: String,
    val shiftId: String,
    val machineId: String,
    val workerId: String,
    val jobId: String,
    val date: String,
    val round: Int,
    val scheduledTime: String,
    val score: Int,
    val issue: String,
    val checkedBy: String,
    val checkedAt: String
)

data class TpDailyIssue(
    val id: String,
    val brigadeId: String,
    val date: String,
    val machineId: String?,
    val orderId: String?,
    val title: String,
    val note: String,
    val createdAt: String,
    val imageUrl: String = "",
    val imagePath: String = ""
)

data class TpAuditEntry(
    val id: String,
    val action: String,
    val brigadeId: String? = null,
    val recordDate: String? = null,
    val details: String,
    val createdAt: String
)

data class TpSettings(
    val firstBatchEntered: Boolean = false,
    val priceRevision: Int = 0
)

data class TpData(
    val shops: List<TpShop> = emptyList(),
    val shifts: List<TpShift> = emptyList(),
    val brigades: List<TpBrigade> = emptyList(),
    val machines: List<TpMachine> = emptyList(),
    val workers: List<TpWorker> = emptyList(),
    val products: List<TpProduct> = emptyList(),
    val materials: List<TpMaterial> = emptyList(),
    val orders: List<TpOrder> = emptyList(),
    val jobs: List<TpPlanJob> = emptyList(),
    val attendance: List<TpAttendance> = emptyList(),
    val receipts: List<TpReceipt> = emptyList(),
    val qualityRounds: List<TpQualityRound> = emptyList(),
    val dailyIssues: List<TpDailyIssue> = emptyList(),
    val auditLog: List<TpAuditEntry> = emptyList(),
    val settings: TpSettings = TpSettings()
) {
    fun orderProgress(orderId: String): Double {
        val orderJobs = jobs.filter { it.orderId == orderId }
        val required = orderJobs.sumOf { job -> job.outputs.sumOf { it.requiredPieces } }
        if (required <= 0) return 0.0
        val received = orderJobs.sumOf { job ->
            job.outputs.sumOf { output ->
                receipts.filter { it.jobId == job.id && it.detailId == output.detailId }
                    .sumOf { it.creditedPieces }
                    .coerceAtMost(output.requiredPieces)
            }
        }
        return received * 100.0 / required
    }

    fun openRemainder(jobId: String, detailId: String): Int = receipts
        .filter { it.jobId == jobId && it.detailId == detailId }
        .maxByOrNull { it.createdAt }
        ?.remainderAfter
        ?: 0

    fun workerEarned(workerId: String, date: String): Long = receipts
        .filter { it.workerId == workerId && it.date == date }
        .sumOf { it.earnedAmount }

    fun workerQuality(workerId: String, date: String): Double? = qualityRounds
        .filter { it.workerId == workerId && it.date == date }
        .map { it.score }
        .takeIf { it.isNotEmpty() }
        ?.average()

    fun workerStandardMinutes(workerId: String): Int {
        val worker = workers.firstOrNull { it.id == workerId } ?: return 0
        val brigade = brigades.firstOrNull { it.id == worker.brigadeId } ?: return 0
        return shifts.firstOrNull { it.id == brigade.shiftId }?.durationMinutes() ?: 0
    }

    fun workerEfficiency(workerId: String, date: String): Double? {
        val worker = workers.firstOrNull { it.id == workerId } ?: return null
        val day = attendance.firstOrNull { it.workerId == workerId && it.date == date } ?: return null
        val standardMinutes = workerStandardMinutes(workerId)
        if (!day.present || day.workMinutes <= 0 || worker.dailyTargetAmount <= 0 || standardMinutes <= 0) return null
        val target = worker.dailyTargetAmount.toDouble() * day.workMinutes / standardMinutes
        return if (target > 0) workerEarned(workerId, date) * 100.0 / target else null
    }

    fun workerUsefulness(workerId: String, date: String): Double? {
        val efficiency = workerEfficiency(workerId, date) ?: return null
        val quality = workerQuality(workerId, date) ?: return null
        return (efficiency + quality) / 2.0
    }

    fun activeJobsForMachine(machineId: String): List<TpPlanJob> = jobs
        .filter { it.machineId == machineId && it.status != TpJobStatus.COMPLETE }
        .sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id })
}


fun TpMaterial.currentStock(): Double = availableAmount + movements.sumOf { movement ->
    if (movement.kind == TpMaterialMovementKind.IN) movement.amount else -movement.amount
}

fun TpMaterial.dayIncoming(date: String): Double = movements
    .filter { it.kind == TpMaterialMovementKind.IN && it.createdAt.take(10) == date }
    .sumOf { it.amount }

fun TpMaterial.dayOutgoing(date: String): Double = movements
    .filter { it.kind == TpMaterialMovementKind.OUT && it.createdAt.take(10) == date }
    .sumOf { it.amount }

fun TpMaterial.openingStock(date: String): Double = availableAmount + movements
    .filter { it.createdAt.take(10) < date }
    .sumOf { if (it.kind == TpMaterialMovementKind.IN) it.amount else -it.amount }

fun TpMaterial.closingStock(date: String): Double = openingStock(date) + dayIncoming(date) - dayOutgoing(date)

fun TpData.materialStock(type: TpMaterialType, code: String): Double = materials
    .firstOrNull { !it.archived && it.type == type && it.code.equals(code, true) }
    ?.currentStock() ?: 0.0


fun tpPriorityLabel(priority: Int): String = when (priority.coerceIn(1, 3)) {
    1 -> "Eng zaril"
    2 -> "Zaril"
    else -> "Keyinroq"
}

fun TpDetail.resinOptions(): List<String> = (resinCodes.ifEmpty { listOf(resinCode) })
    .map { it.trim().uppercase(Locale.ROOT) }
    .filter { it.isNotBlank() }
    .distinct()

fun TpDetail.acceptsMachine(machine: TpMachine): Boolean {
    if (machine.archived) return false
    return compatibleCapacities.isEmpty() || (machine.capacity > 0 && machine.capacity in compatibleCapacities)
}

fun TpPlanJob.acceptsMachine(machine: TpMachine, data: TpData): Boolean {
    if (machine.archived) return false
    val detailCaps = outputs.mapNotNull { output ->
        data.products.asSequence().flatMap { it.details.asSequence() }
            .firstOrNull { it.id == output.detailId }?.compatibleCapacities
    }.filter { it.isNotEmpty() }
    if (detailCaps.isEmpty()) return true
    val common = detailCaps.drop(1).fold(detailCaps.first()) { acc, set -> acc intersect set }
    return machine.capacity > 0 && machine.capacity in common
}

fun TpData.machineAvailabilityMinutes(machineId: String, excludingOrderId: String? = null): Int = jobs
    .filter { it.machineId == machineId && it.status != TpJobStatus.COMPLETE && it.orderId != excludingOrderId }
    .sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id })
    .sumOf { it.estimatedMinutes.coerceAtLeast(0) }

fun TpData.orderForecastMinutes(orderId: String): Int {
    val order = orders.firstOrNull { it.id == orderId } ?: return 0
    val planned = jobs.filter { it.orderId == orderId }
    val sourceJobs = if (planned.isNotEmpty()) planned else runCatching {
        buildPlanJobs(this, order) { "forecast-${order.id}-${System.nanoTime()}" }
    }.getOrDefault(emptyList())
    if (sourceJobs.isEmpty()) return 0

    // Greedy optimistic forecast: each unassigned color job uses the compatible machine that can
    // finish it earliest; assigned jobs respect the machine queue already planned before them.
    val virtualLoads = machines.filterNot { it.archived }.associate { it.id to machineAvailabilityMinutes(it.id, orderId) }.toMutableMap()
    var completion = 0
    sourceJobs.sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id }).forEach { job ->
        val assigned = job.machineId?.let { id -> machines.firstOrNull { it.id == id && job.acceptsMachine(it, this) } }
        val candidates = if (assigned != null) listOf(assigned) else machines.filter { job.acceptsMachine(it, this) }
        val machine = candidates.minWithOrNull(compareBy<TpMachine> { virtualLoads[it.id] ?: 0 }.thenBy { it.number })
            ?: return 0
        val finish = run {
            val start = virtualLoads[machine.id] ?: 0
            val end = start + job.estimatedMinutes
            virtualLoads[machine.id] = end
            end
        }
        completion = maxOf(completion, finish)
    }
    return completion
}

fun allocateByColor(total: Int, colors: List<TpColorRule>): Map<String, Int> {
    if (total <= 0) return emptyMap()
    val valid = colors.filter { it.colorCode.isNotBlank() && it.share > 0.0 }
    if (valid.isEmpty()) return mapOf("000" to total)
    val sum = valid.sumOf { it.share }
    val raw = valid.map { rule -> rule to total * rule.share / sum }
    val base = raw.associate { (rule, value) -> rule.colorCode to value.toInt() }.toMutableMap()
    var remaining = total - base.values.sum()
    raw.sortedByDescending { (_, value) -> value - value.toInt() }.forEach { (rule, _) ->
        if (remaining > 0) {
            base[rule.colorCode] = base.getValue(rule.colorCode) + 1
            remaining--
        }
    }
    return base
}

fun nextBatchNumber(previous: String): String {
    val match = Regex("^(.*?)(\\d+)$").matchEntire(previous.trim())
    if (match != null) {
        val prefix = match.groupValues[1]
        val digits = match.groupValues[2]
        val next = digits.toLongOrNull()?.plus(1) ?: return "${previous.trim()}-2"
        return prefix + next.toString().padStart(digits.length, '0')
    }
    return "${previous.trim()}-2"
}

fun calculateReceiptCredit(
    bagCapacity: Int,
    carryInPieces: Int,
    completedBags: Int,
    remainderAfter: Int
): Int {
    require(bagCapacity > 0) { "Qop sig‘imi 0 dan katta bo‘lsin" }
    require(carryInPieces in 0 until bagCapacity) { "Oldingi qoldiq noto‘g‘ri" }
    require(completedBags >= 0) { "Qop soni manfiy bo‘lmasin" }
    require(remainderAfter in 0 until bagCapacity) { "Yangi qoldiq qop sig‘imidan kam bo‘lsin" }
    val credited = completedBags * bagCapacity - carryInPieces + remainderAfter
    require(credited > 0) { "Yangi ishlab chiqarilgan son 0 dan katta bo‘lsin" }
    return credited
}

fun calculatePieceWorkAmount(pieces: Int, piecesPerShot: Int, pricePerShot: Double): Long {
    if (pieces <= 0 || piecesPerShot <= 0 || pricePerShot <= 0.0) return 0L
    return (pieces.toDouble() / piecesPerShot.toDouble() * pricePerShot).roundToLong()
}

fun buildPlanJobs(data: TpData, order: TpOrder, idFactory: () -> String): List<TpPlanJob> {
    val product = data.products.firstOrNull { it.id == order.productId } ?: error("Mahsulot topilmadi")
    require(product.details.any { !it.archived }) { "Mahsulot detallari kiritilmagan" }
    var sequence = 0
    return product.details.filterNot { it.archived }.groupBy { it.moldCode.ifBlank { it.id } }.flatMap { (moldCode, details) ->
        val resinSets = details.map { it.resinOptions().toSet() }
        require(resinSets.all { it.isNotEmpty() }) { "$moldCode qolipidagi har bir detal uchun seryo turini kiriting" }
        val commonResins = resinSets.drop(1).fold(resinSets.first()) { acc, set -> acc intersect set }.sorted()
        require(commonResins.isNotEmpty()) {
            "$moldCode qolipida birga chiqadigan detallar uchun umumiy seryo turi topilmadi"
        }
        val colorSignatures = details.map { detail ->
            detail.colors.sortedBy { it.colorCode.uppercase(Locale.ROOT) }
                .map { Triple(it.colorCode.trim().uppercase(Locale.ROOT), it.share, it.gramsPer25Kg) }
        }
        require(colorSignatures.distinct().size == 1) {
            "$moldCode qolipida birga chiqadigan detallar rang taqsimoti bir xil bo‘lsin"
        }
        val allocations = details.associateWith { detail ->
            allocateByColor(order.quantity * detail.requiredPerProduct, detail.colors)
        }
        val colorCodes = allocations.values.flatMap { it.keys }.distinct()
        colorCodes.mapNotNull { colorCode ->
            val requiredByDetail = details.mapNotNull { detail ->
                val required = allocations.getValue(detail)[colorCode] ?: 0
                if (required > 0) detail to required else null
            }
            if (requiredByDetail.isEmpty()) return@mapNotNull null
            val shots = requiredByDetail.maxOf { (detail, required) ->
                ceil(required.toDouble() / detail.piecesPerShot.coerceAtLeast(1)).toInt()
            }
            val outputs = requiredByDetail.map { (detail, required) ->
                TpJobOutput(
                    detailId = detail.id,
                    detailName = detail.name,
                    requiredPieces = required,
                    plannedPieces = shots * detail.piecesPerShot,
                    piecesPerShot = detail.piecesPerShot,
                    bagCapacity = detail.bagCapacity,
                    unitPrice = detail.unitPrice
                )
            }
            val reference = requiredByDetail.first().first
            val cycleSeconds = details.maxOf { it.cycleSeconds }
            val grossGrams = details.maxOf { it.grossShotWeightGrams }
            val resinKg = shots * grossGrams / 1000.0
            val colorRule = reference.colors.firstOrNull { it.colorCode == colorCode }
            val colorGrams = resinKg / 25.0 * (colorRule?.gramsPer25Kg ?: 0.0)
            val capacitySets = details.map { it.compatibleCapacities }.filter { it.isNotEmpty() }
            val capacityIntersection = capacitySets.drop(1).fold(capacitySets.firstOrNull().orEmpty()) { result, set -> result intersect set }
            require(capacitySets.size < 2 || capacityIntersection.isNotEmpty()) {
                "$moldCode qolipidagi detallar uchun umumiy stanok sig‘imi topilmadi"
            }
            sequence++
            TpPlanJob(
                id = idFactory(),
                orderId = order.id,
                moldCode = moldCode,
                colorCode = colorCode,
                outputs = outputs,
                requiredShots = shots,
                cycleSeconds = cycleSeconds,
                estimatedMinutes = ceil(shots * cycleSeconds / 60.0).toInt(),
                resinCode = commonResins.first(),
                requiredResinKg = roundMaterial(resinKg),
                requiredColorGrams = roundMaterial(colorGrams),
                compatibleMachineIds = emptySet(),
                priority = order.priority * 100 + sequence
            )
        }
    }
}

fun formatTpNumber(value: Double): String = BigDecimal.valueOf(value).stripTrailingZeros().toPlainString()

private fun roundMaterial(value: Double): Double = BigDecimal.valueOf(value)
    .setScale(3, RoundingMode.HALF_UP)
    .toDouble()

fun isoToday(): String = LocalDate.now().toString()
