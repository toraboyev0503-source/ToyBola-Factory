# 0.2.0: release shrinking remains disabled during active debug testing.
# Final production keep/shrink rules will be locked before 1.0.0 signed release.
