package uz.toybola.factory.core.data

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

private fun todayIso(): String = LocalDate.now().toString()

data class Brigade(
    val id: String,
    val name: String,
    val archived: Boolean = false,
    val deleted: Boolean = false
)

data class Worker(
    val id: String,
    val brigadeId: String,
    val name: String,
    val startDate: String,
    val archived: Boolean = false
)

data class PriceVersion(
    val price: Long,
    val effectiveFrom: String
)

data class ProductStage(
    val id: String,
    val name: String,
    val archived: Boolean = false
)

data class Product(
    val id: String,
    val brigadeId: String,
    val article: String,
    val name: String,
    val priceHistory: List<PriceVersion>,
    val stages: List<ProductStage> = emptyList(),
    val archived: Boolean = false
) {
    val currentPrice: Long get() = priceAt(todayIso())

    fun priceAt(date: String): Long = priceHistory
        .filter { it.effectiveFrom <= date }
        .maxByOrNull { it.effectiveFrom }
        ?.price
        ?: priceHistory.minByOrNull { it.effectiveFrom }?.price
        ?: 0L

    fun activeStages(): List<ProductStage> = stages.filterNot { it.archived }
}

data class LongVersion(val value: Long, val effectiveFrom: String)
data class IntVersion(val value: Int, val effectiveFrom: String)

data class BrigadeFkHistory(
    val brigadeId: String,
    val versions: List<LongVersion>
) {
    val current: Long? get() = valueAt(todayIso())

    fun valueAt(date: String): Long? = versions
        .filter { it.effectiveFrom <= date }
        .maxByOrNull { it.effectiveFrom }
        ?.value
        ?: versions.minByOrNull { it.effectiveFrom }?.value
}

data class RoundTimesVersion(
    val first: String,
    val second: String,
    val third: String,
    val effectiveFrom: String
)

data class BrigadirWeights(
    val onTimeClose: Int = 40,
    val noReopen: Int = 20,
    val brigadeResult: Int = 40
) {
    val total: Int get() = onTimeClose + noReopen + brigadeResult
}

data class QualityWeights(
    val roundsOnTime: Int = 50,
    val rechecks: Int = 20,
    val onTimeClose: Int = 20,
    val dataDiscipline: Int = 10
) {
    val total: Int get() = roundsOnTime + rechecks + onTimeClose + dataDiscipline
}

data class MonitoringWeightsVersion(
    val brigadir: BrigadirWeights,
    val quality: QualityWeights,
    val effectiveFrom: String
)

data class ProductionEntry(
    val id: String,
    val productId: String,
    val articleSnapshot: String,
    val productNameSnapshot: String,
    val quantity: Double,
    val unitPriceSnapshot: Long
) {
    val amount: Long get() = productionAmount(quantity, unitPriceSnapshot)
}

fun normalizeProductionQuantityInput(raw: String): String {
    val normalized = StringBuilder(raw.length)
    var hasDecimalSeparator = false
    raw.forEach { character ->
        when {
            character.isDigit() -> normalized.append(character)
            (character == '.' || character == ',') && !hasDecimalSeparator -> {
                normalized.append('.')
                hasDecimalSeparator = true
            }
        }
    }
    return normalized.toString()
}

fun parseProductionQuantity(raw: String): Double? = normalizeProductionQuantityInput(raw)
    .toDoubleOrNull()
    ?.takeIf { it.isFinite() && it > 0.0 }

fun formatProductionQuantity(quantity: Double): String = if (quantity.isFinite()) {
    BigDecimal.valueOf(quantity).stripTrailingZeros().toPlainString()
} else {
    "0"
}

fun addProductionQuantities(first: Double, second: Double): Double =
    BigDecimal.valueOf(first).add(BigDecimal.valueOf(second)).toDouble()

fun productionAmount(quantity: Double, unitPrice: Long): Long = BigDecimal.valueOf(quantity)
    .multiply(BigDecimal.valueOf(unitPrice))
    .setScale(0, RoundingMode.HALF_UP)
    .longValueExact()

data class WorkerDay(
    val workerId: String,
    val brigadeId: String,
    val date: String,
    val worked: Boolean = true,
    val hours: Int,
    val entries: List<ProductionEntry> = emptyList(),
    val updatedAt: String = ""
) {
    val earned: Long get() = entries.sumOf { it.amount }
    val isComplete: Boolean get() = !worked || entries.isNotEmpty()
}

data class BrigadeDay(
    val brigadeId: String,
    val date: String,
    val worked: Boolean = true,
    val brigadirClosedAt: String? = null,
    val brigadirLateReason: String = "",
    val qualityClosedAt: String? = null,
    val qualityLateReason: String = "",
    val closedAt: String? = null,
    val reopenCount: Int = 0,
    val lastReopenedAt: String? = null,
    val lastReopenReason: String = ""
) {
    val brigadirClosed: Boolean get() = brigadirClosedAt != null
    val qualityClosed: Boolean get() = qualityClosedAt != null
    val fullyClosed: Boolean get() = closedAt != null && brigadirClosed && qualityClosed

    fun brigadirClosedOnTime(): Boolean {
        val actual = brigadirClosedAt?.let { runCatching { LocalDateTime.parse(it) }.getOrNull() } ?: return false
        val deadline = LocalDate.parse(date).plusDays(1).atTime(9, 0)
        return !actual.isAfter(deadline)
    }

    fun qualityClosedOnTime(): Boolean {
        val actual = qualityClosedAt?.let { runCatching { LocalDateTime.parse(it) }.getOrNull() } ?: return false
        val deadline = LocalDate.parse(date).atTime(17, 50)
        return !actual.isAfter(deadline)
    }
}

data class QualityRecheck(
    val grade: Int,
    val note: String = "",
    val checkedAt: String
)

data class QualityRoundRecord(
    val id: String,
    val workerId: String,
    val brigadeId: String,
    val date: String,
    val round: Int,
    val scheduledTime: String,
    val grade: Int? = null,
    val score: Int? = null,
    val productId: String? = null,
    val articleSnapshot: String = "",
    val productNameSnapshot: String = "",
    val stageId: String? = null,
    val stageNameSnapshot: String = "",
    val note: String = "",
    val evaluatedAt: String? = null,
    val absenceType: String = "",
    val absenceReason: String = "",
    val absenceAt: String? = null,
    val missedReason: String = "",
    val missedAt: String? = null,
    val recheck: QualityRecheck? = null
) {
    val isEvaluated: Boolean get() = grade != null
    val isExcusedAbsence: Boolean get() = absenceType == "EXCUSED" && absenceAt != null && absenceReason.isNotBlank()
    val isUnexcusedAbsence: Boolean get() = absenceType == "UNEXCUSED" && absenceAt != null
    val isWorkerAbsent: Boolean get() = isExcusedAbsence || isUnexcusedAbsence
    val isMissed: Boolean get() = grade == null && !isWorkerAbsent && missedAt != null
    val needsRecheck: Boolean get() = grade == 3 || grade == 4
    val isFinished: Boolean get() = isEvaluated || isWorkerAbsent || (isMissed && missedReason.isNotBlank())
    val recheckComplete: Boolean get() = !needsRecheck || recheck != null
}

data class DailyIssueRecord(
    val id: String,
    val brigadeId: String,
    val date: String,
    val productId: String,
    val articleSnapshot: String,
    val productNameSnapshot: String,
    val stageId: String,
    val stageNameSnapshot: String,
    val note: String,
    val createdAt: String,
    val imageUrl: String = "",
    val imagePath: String = ""
)

data class AuditEntry(
    val id: String,
    val dateTime: String,
    val action: String,
    val brigadeId: String? = null,
    val recordDate: String? = null,
    val details: String = ""
)

data class AssemblyData(
    val brigades: List<Brigade> = emptyList(),
    val workers: List<Worker> = emptyList(),
    val products: List<Product> = emptyList(),
    val brigadeFk: List<BrigadeFkHistory> = emptyList(),
    val workHours: List<IntVersion> = emptyList(),
    val efficiencyNorm: List<IntVersion> = emptyList(),
    val roundTimes: List<RoundTimesVersion> = emptyList(),
    val monitoringWeights: List<MonitoringWeightsVersion> = emptyList(),
    val preparedYears: List<Int> = emptyList(),
    val workerDays: List<WorkerDay> = emptyList(),
    val brigadeDays: List<BrigadeDay> = emptyList(),
    val qualityRounds: List<QualityRoundRecord> = emptyList(),
    val dailyIssues: List<DailyIssueRecord> = emptyList(),
    val auditLog: List<AuditEntry> = emptyList()
) {
    fun currentWorkHours(): Int = workHours.current()?.value ?: 10
    fun workHoursAt(date: String): Int = workHours.valueAt(date) ?: 10
    fun currentEfficiencyNorm(): Int = efficiencyNorm.current()?.value ?: 85
    fun efficiencyNormAt(date: String): Int = efficiencyNorm.valueAt(date) ?: 85
    fun currentRoundTimes(): RoundTimesVersion = roundTimes.currentBy { it.effectiveFrom }
        ?: RoundTimesVersion("10:00", "13:00", "16:00", "2000-01-01")
    fun roundTimesAt(date: String): RoundTimesVersion = roundTimes
        .filter { it.effectiveFrom <= date }
        .maxByOrNull { it.effectiveFrom }
        ?: roundTimes.minByOrNull { it.effectiveFrom }
        ?: RoundTimesVersion("10:00", "13:00", "16:00", "2000-01-01")
    fun currentMonitoringWeights(): MonitoringWeightsVersion = monitoringWeights.currentBy { it.effectiveFrom }
        ?: MonitoringWeightsVersion(BrigadirWeights(), QualityWeights(), "2000-01-01")
    fun monitoringWeightsAt(date: String): MonitoringWeightsVersion = monitoringWeights
        .filter { it.effectiveFrom <= date }
        .maxByOrNull { it.effectiveFrom }
        ?: monitoringWeights.minByOrNull { it.effectiveFrom }
        ?: MonitoringWeightsVersion(BrigadirWeights(), QualityWeights(), "2000-01-01")
    fun brigadeFkAt(brigadeId: String, date: String): Long? = brigadeFk.firstOrNull { it.brigadeId == brigadeId }?.valueAt(date)
    fun workerDay(workerId: String, date: String): WorkerDay? = workerDays.firstOrNull { it.workerId == workerId && it.date == date }
    fun brigadeDay(brigadeId: String, date: String): BrigadeDay? = brigadeDays.firstOrNull { it.brigadeId == brigadeId && it.date == date }
    fun qualityRound(workerId: String, date: String, round: Int): QualityRoundRecord? = qualityRounds.firstOrNull {
        it.workerId == workerId && it.date == date && it.round == round
    }
    fun dailyIssuesFor(date: String, brigadeId: String? = null): List<DailyIssueRecord> = dailyIssues.filter { it.date == date && (brigadeId == null || it.brigadeId == brigadeId) }
    fun qualityAverage(workerId: String, date: String): Double? {
        val scores = qualityRounds.filter { it.workerId == workerId && it.date == date }.mapNotNull { it.score }
        return if (scores.isEmpty()) null else scores.average()
    }

    fun workerEfficiency(workerId: String, date: String): Double? {
        val day = workerDay(workerId, date) ?: return null
        if (!day.worked) return null
        val fk = brigadeFkAt(day.brigadeId, date) ?: return null
        val defaultHours = workHoursAt(date)
        if (defaultHours <= 0) return null
        val required = fk.toDouble() * day.hours / defaultHours
        return if (required > 0) day.earned * 100.0 / required else null
    }

    fun workerFinalResult(workerId: String, date: String): Double? {
        val quality = qualityAverage(workerId, date) ?: return null
        val efficiency = workerEfficiency(workerId, date) ?: return null
        return (quality + efficiency) / 2.0
    }

    fun activeWorkers(brigadeId: String): List<Worker> = workers.filter { !it.archived && it.brigadeId == brigadeId }

    fun brigadirMissing(brigadeId: String, date: String): List<String> {
        val brigadeWorked = brigadeDay(brigadeId, date)?.worked ?: true
        if (!brigadeWorked) return emptyList()
        val missing = mutableListOf<String>()
        if (brigadeFkAt(brigadeId, date) == null) missing += "F/K kiritilmagan"
        val active = activeWorkers(brigadeId)
        if (active.isEmpty()) missing += "Faol ishchi kiritilmagan"
        active.forEach { worker ->
            val day = workerDay(worker.id, date)
            if (day == null || !day.isComplete) missing += worker.name
        }
        return missing
    }

    fun qualityMissing(brigadeId: String, date: String): List<String> {
        val brigadeWorked = brigadeDay(brigadeId, date)?.worked ?: true
        if (!brigadeWorked) return emptyList()
        val missing = mutableListOf<String>()
        activeWorkers(brigadeId).forEach { worker ->
            if (workerDay(worker.id, date)?.worked == false) return@forEach
            for (round in 1..3) {
                val record = qualityRound(worker.id, date, round)
                if (record == null || !record.isFinished) missing += "${worker.name} — $round-raund"
                else if (!record.recheckComplete) missing += "${worker.name} — $round-raund qayta tekshiruv"
            }
        }
        return missing
    }

    fun hasActivity(brigadeId: String, date: String): Boolean =
        brigadeDays.any { it.brigadeId == brigadeId && it.date == date } ||
            workerDays.any { it.brigadeId == brigadeId && it.date == date } ||
            qualityRounds.any { it.brigadeId == brigadeId && it.date == date } ||
            dailyIssues.any { it.brigadeId == brigadeId && it.date == date }

    fun openBrigadirDates(brigadeId: String, beforeDate: String = todayIso()): List<String> {
        val dates = (workerDays.filter { it.brigadeId == brigadeId }.map { it.date } +
            qualityRounds.filter { it.brigadeId == brigadeId }.map { it.date } +
            brigadeDays.filter { it.brigadeId == brigadeId }.map { it.date }).distinct()
        return dates.filter { it < beforeDate && brigadeDay(brigadeId, it)?.brigadirClosed != true }.sorted()
    }

    fun openQualityDates(brigadeId: String, beforeDate: String = todayIso()): List<String> {
        val dates = (qualityRounds.filter { it.brigadeId == brigadeId }.map { it.date } +
            workerDays.filter { it.brigadeId == brigadeId }.map { it.date } +
            brigadeDays.filter { it.brigadeId == brigadeId }.map { it.date }).distinct()
        return dates.filter { it < beforeDate && brigadeDay(brigadeId, it)?.qualityClosed != true }.sorted()
    }

    fun roundScheduledTime(date: String, round: Int): String {
        val t = roundTimesAt(date)
        return when (round) { 1 -> t.first; 2 -> t.second; else -> t.third }
    }

    fun roundDeadline(date: String, round: Int): LocalDateTime =
        LocalDateTime.of(LocalDate.parse(date), LocalTime.parse(roundScheduledTime(date, round))).plusHours(1)
}

private fun List<IntVersion>.current(): IntVersion? = currentBy { it.effectiveFrom }
private fun List<IntVersion>.valueAt(date: String): Int? = filter { it.effectiveFrom <= date }.maxByOrNull { it.effectiveFrom }?.value
    ?: minByOrNull { it.effectiveFrom }?.value

private fun <T> List<T>.currentBy(date: (T) -> String): T? {
    val today = todayIso()
    return filter { date(it) <= today }.maxByOrNull(date) ?: minByOrNull(date)
}
