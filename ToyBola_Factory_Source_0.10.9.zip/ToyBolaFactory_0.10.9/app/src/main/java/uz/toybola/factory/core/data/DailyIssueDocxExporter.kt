package uz.toybola.factory.core.data

import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object DailyIssueDocxExporter {
    fun write(
        output: OutputStream,
        title: String,
        issues: List<DailyIssueRecord>,
        brigadeNames: Map<String, String>
    ) {
        ZipOutputStream(output).use { zip ->
            zip.putText("[Content_Types].xml", contentTypes)
            zip.putText("_rels/.rels", rootRels)
            zip.putText("word/document.xml", documentXml(title, issues, brigadeNames))
        }
    }

    private fun documentXml(
        title: String,
        issues: List<DailyIssueRecord>,
        brigadeNames: Map<String, String>
    ): String {
        val body = buildString {
            append(paragraph(title, bold = true))
            append(paragraph("Jami muammo: ${issues.size}", bold = true))
            if (issues.isEmpty()) {
                append(paragraph("Muammo yozuvlari mavjud emas."))
            } else {
                issues.sortedWith(compareBy<DailyIssueRecord> { it.date }.thenBy { it.createdAt }).forEachIndexed { index, issue ->
                    append(paragraph("${index + 1}. ${issue.date} • ${brigadeNames[issue.brigadeId].orEmpty()}", bold = true))
                    append(paragraph("${issue.articleSnapshot} — ${issue.productNameSnapshot}"))
                    append(paragraph("Yig‘uv bosqichi: ${issue.stageNameSnapshot}"))
                    append(paragraph("Muammo: ${issue.note}"))
                    append(paragraph(""))
                }
            }
            append("<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\"/></w:sectPr>")
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>$body</w:body></w:document>"""
    }

    private fun paragraph(text: String, bold: Boolean = false): String {
        val escaped = xmlEscape(text)
        val props = if (bold) "<w:rPr><w:b/></w:rPr>" else ""
        return "<w:p><w:r>$props<w:t xml:space=\"preserve\">$escaped</w:t></w:r></w:p>"
    }

    private fun xmlEscape(value: String): String = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")

    private fun ZipOutputStream.putText(path: String, value: String) {
        putNextEntry(ZipEntry(path))
        write(value.toByteArray(Charsets.UTF_8))
        closeEntry()
    }

    private const val contentTypes = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>"""

    private const val rootRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""
}
