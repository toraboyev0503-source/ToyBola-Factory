package uz.toybola.factory.core.data

import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object MonitoringDocxExporter {
    fun write(
        output: OutputStream,
        title: String,
        metadata: List<String>,
        headers: List<String>,
        rows: List<List<String>>
    ) {
        ZipOutputStream(output).use { zip ->
            zip.putText("[Content_Types].xml", contentTypes)
            zip.putText("_rels/.rels", rootRels)
            zip.putText("word/document.xml", documentXml(title, metadata, headers, rows))
        }
    }

    private fun documentXml(
        title: String,
        metadata: List<String>,
        headers: List<String>,
        rows: List<List<String>>
    ): String {
        val body = buildString {
            append(paragraph(title, bold = true, size = 30))
            metadata.filter { it.isNotBlank() }.forEach { append(paragraph(it)) }
            append(paragraph(""))
            if (rows.isEmpty()) {
                append(paragraph("Ma’lumot mavjud emas."))
            } else {
                append(table(headers, rows))
            }
            append("<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"900\" w:right=\"720\" w:bottom=\"900\" w:left=\"720\"/></w:sectPr>")
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>$body</w:body></w:document>"""
    }

    private fun table(headers: List<String>, rows: List<List<String>>): String = buildString {
        append("<w:tbl><w:tblPr><w:tblBorders>")
        listOf("top", "left", "bottom", "right", "insideH", "insideV").forEach { side ->
            append("<w:$side w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"B7B7B7\"/>")
        }
        append("</w:tblBorders></w:tblPr>")
        append(row(headers, bold = true))
        rows.forEach { append(row(it, bold = false)) }
        append("</w:tbl>")
    }

    private fun row(values: List<String>, bold: Boolean): String = buildString {
        append("<w:tr>")
        values.forEach { value ->
            append("<w:tc><w:tcPr><w:tcMar><w:top w:w=\"80\" w:type=\"dxa\"/><w:left w:w=\"90\" w:type=\"dxa\"/><w:bottom w:w=\"80\" w:type=\"dxa\"/><w:right w:w=\"90\" w:type=\"dxa\"/></w:tcMar></w:tcPr>")
            append(paragraph(value, bold = bold))
            append("</w:tc>")
        }
        append("</w:tr>")
    }

    private fun paragraph(text: String, bold: Boolean = false, size: Int? = null): String {
        val escaped = xmlEscape(text)
        val props = buildString {
            if (bold || size != null) {
                append("<w:rPr>")
                if (bold) append("<w:b/>")
                if (size != null) append("<w:sz w:val=\"$size\"/>")
                append("</w:rPr>")
            }
        }
        return "<w:p><w:r>$props<w:t xml:space=\"preserve\">$escaped</w:t></w:r></w:p>"
    }

    private fun xmlEscape(value: String): String = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")

    private fun ZipOutputStream.putText(path: String, value: String) {
        putNextEntry(ZipEntry(path))
        write(value.toByteArray(Charsets.UTF_8))
        closeEntry()
    }

    private const val contentTypes = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>"""

    private const val rootRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""
}
