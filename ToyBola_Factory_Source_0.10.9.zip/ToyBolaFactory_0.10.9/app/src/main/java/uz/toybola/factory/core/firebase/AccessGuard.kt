package uz.toybola.factory.core.firebase

import android.content.Context
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy

class AccessGuard(context: Context) {
    private val appContext = context.applicationContext
    private val preferences = AppPreferences(appContext)
    private val cache = ServerPolicyCache(appContext)

    fun currentPolicy(): UserAccessPolicy {
        val code = preferences.setup()?.userCode.orEmpty()
        return cache.load(code) ?: UserAccessPolicy.locked(code)
    }

    fun validate(before: AssemblyData, after: AssemblyData) {
        if (before == after) return
        val policy = currentPolicy()
        require(policy.source != "locked") { "Server ruxsati yuklanmagan. Internetga ulanib qayta kiring." }
        if (policy.isAdmin()) return

        if (before.workHours != after.workHours ||
            before.efficiencyNorm != after.efficiencyNorm ||
            before.roundTimes != after.roundTimes ||
            before.monitoringWeights != after.monitoringWeights ||
            before.preparedYears != after.preparedYears
        ) requireSection(policy, AssemblySection.MASTER_DATA, null)

        changed(before.brigades, after.brigades) { it.id }.forEach { brigade ->
            requireSection(policy, AssemblySection.MASTER_DATA, brigade.id)
        }
        changed(before.workers, after.workers) { it.id }.forEach { worker ->
            requireSection(policy, AssemblySection.MASTER_DATA, worker.brigadeId)
        }
        changed(before.products, after.products) { it.id }.forEach { product ->
            requireSection(policy, AssemblySection.MASTER_DATA, product.brigadeId)
        }
        changed(before.brigadeFk, after.brigadeFk) { it.brigadeId }.forEach { fk ->
            requireSection(policy, AssemblySection.MASTER_DATA, fk.brigadeId)
        }
        changed(before.workerDays, after.workerDays) { "${it.workerId}|${it.date}" }.forEach { day ->
            requireSection(policy, AssemblySection.BRIGADIR, day.brigadeId)
        }
        changed(before.qualityRounds, after.qualityRounds) { "${it.workerId}|${it.date}|${it.round}" }.forEach { round ->
            requireSection(policy, AssemblySection.QUALITY, round.brigadeId)
        }
        changed(before.dailyIssues, after.dailyIssues) { it.id }.forEach { issue ->
            require(policy.canWriteDailyIssue() && policy.canAccessBrigade(issue.brigadeId)) {
                "Kun muammosini yozishga ruxsat yo‘q"
            }
        }
        removed(before.dailyIssues, after.dailyIssues) { it.id }.forEach { issue ->
            require(policy.canWriteDailyIssue() && policy.canAccessBrigade(issue.brigadeId)) {
                "Kun muammosini o‘chirishga ruxsat yo‘q"
            }
        }

        val oldDays = before.brigadeDays.associateBy { "${it.brigadeId}|${it.date}" }
        val newDays = after.brigadeDays.associateBy { "${it.brigadeId}|${it.date}" }
        (oldDays.keys + newDays.keys).forEach { key ->
            val old = oldDays[key]
            val new = newDays[key]
            if (old == new || new == null) return@forEach
            require(policy.canAccessBrigade(new.brigadeId)) { "Bu brigadaga ruxsat yo‘q" }
            if (old != null && new.reopenCount > old.reopenCount) {
                require(policy.isAdmin()) { "Kunni qayta ochish faqat administratorga ruxsat" }
            }
            val brigadirChanged = old == null || old.worked != new.worked || old.brigadirClosedAt != new.brigadirClosedAt ||
                old.brigadirLateReason != new.brigadirLateReason || old.lastReopenedAt != new.lastReopenedAt ||
                old.lastReopenReason != new.lastReopenReason
            val qualityChanged = old == null || old.qualityClosedAt != new.qualityClosedAt || old.qualityLateReason != new.qualityLateReason
            if (brigadirChanged && qualityChanged) {
                require(policy.canWrite(AssemblySection.BRIGADIR) || policy.canWrite(AssemblySection.QUALITY)) { "Kun holatini o‘zgartirishga ruxsat yo‘q" }
            } else if (brigadirChanged) {
                requireSection(policy, AssemblySection.BRIGADIR, new.brigadeId)
            } else if (qualityChanged) {
                requireSection(policy, AssemblySection.QUALITY, new.brigadeId)
            }
        }
    }

    private fun requireSection(policy: UserAccessPolicy, section: AssemblySection, brigadeId: String?) {
        require(policy.canWrite(section)) { "${section.name} bo‘limida yozish ruxsati yo‘q" }
        if (brigadeId != null) require(policy.canAccessBrigade(brigadeId)) { "Bu brigadaga ruxsat yo‘q" }
    }

    private fun <T, K> changed(before: List<T>, after: List<T>, key: (T) -> K): List<T> {
        val old = before.associateBy(key)
        return after.filter { old[key(it)] != it }
    }

    private fun <T, K> removed(before: List<T>, after: List<T>, key: (T) -> K): List<T> {
        val current = after.associateBy(key)
        return before.filter { current[key(it)] == null }
    }
}
