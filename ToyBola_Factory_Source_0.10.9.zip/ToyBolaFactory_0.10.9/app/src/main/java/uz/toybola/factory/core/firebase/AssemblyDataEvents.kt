package uz.toybola.factory.core.firebase

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Process-wide lightweight revision signal for local AssemblyData changes.
 *
 * FirebaseSyncCoordinator uses its own repository instance. Without a shared signal,
 * already-open Compose screens can keep showing the old SharedPreferences snapshot even
 * after the server pull has replaced local data. Screens collect this revision and reload.
 */
object AssemblyDataEvents {
    private val _revision = MutableStateFlow(0L)
    val revision: StateFlow<Long> = _revision.asStateFlow()

    fun notifyChanged() {
        _revision.value = _revision.value + 1L
    }
}
