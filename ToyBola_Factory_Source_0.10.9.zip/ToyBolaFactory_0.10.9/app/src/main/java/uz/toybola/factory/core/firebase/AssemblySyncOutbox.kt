package uz.toybola.factory.core.firebase

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import uz.toybola.factory.core.data.*

object SyncOutboxEvents {
    private val _revision = MutableStateFlow(0L)
    val revision: StateFlow<Long> = _revision.asStateFlow()

    internal fun notifyChanged() {
        _revision.value = _revision.value + 1L
    }
}

class AssemblySyncOutbox(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun recordDiff(before: AssemblyData, after: AssemblyData) {
        val keys = pending().toMutableSet()
        addChanged(keys, before.brigades, after.brigades, { it.id }) { "BRIGADE:${it.id}" }
        addChanged(keys, before.workers, after.workers, { it.id }) { "WORKER:${it.id}" }
        addChanged(keys, before.products, after.products, { it.id }) { "PRODUCT:${it.id}" }
        addChanged(keys, before.brigadeFk, after.brigadeFk, { it.brigadeId }) { "BRIGADE_FK:${it.brigadeId}" }
        addChanged(keys, before.workerDays, after.workerDays, { "${it.workerId}|${it.date}" }) { "WORKER_DAY:${it.workerId}|${it.date}" }
        addChanged(keys, before.brigadeDays, after.brigadeDays, { "${it.brigadeId}|${it.date}" }) { "BRIGADE_DAY:${it.brigadeId}|${it.date}" }
        addChanged(keys, before.qualityRounds, after.qualityRounds, { "${it.workerId}|${it.date}|${it.round}" }) { "QUALITY_ROUND:${it.workerId}|${it.date}|${it.round}" }
        addChanged(keys, before.dailyIssues, after.dailyIssues, { it.id }) { "DAILY_ISSUE:${it.id}" }
        val afterIssues = after.dailyIssues.associateBy { it.id }
        before.dailyIssues.filter { afterIssues[it.id] == null }.forEach { keys += "DAILY_ISSUE_DELETE:${it.id}" }
        val oldAudit = before.auditLog.associateBy { it.id }
        after.auditLog.filter { oldAudit[it.id] != it }.forEach { keys += "AUDIT:${it.id}" }
        if (before.workHours != after.workHours || before.efficiencyNorm != after.efficiencyNorm ||
            before.roundTimes != after.roundTimes || before.monitoringWeights != after.monitoringWeights ||
            before.preparedYears != after.preparedYears
        ) keys += "SETTINGS:assembly"
        save(keys)
    }

    @Synchronized
    fun markAll(data: AssemblyData) {
        val keys = pending().toMutableSet()
        data.brigades.forEach { keys += "BRIGADE:${it.id}" }
        data.workers.forEach { keys += "WORKER:${it.id}" }
        data.products.forEach { keys += "PRODUCT:${it.id}" }
        data.brigadeFk.forEach { keys += "BRIGADE_FK:${it.brigadeId}" }
        data.workerDays.forEach { keys += "WORKER_DAY:${it.workerId}|${it.date}" }
        data.brigadeDays.forEach { keys += "BRIGADE_DAY:${it.brigadeId}|${it.date}" }
        data.qualityRounds.forEach { keys += "QUALITY_ROUND:${it.workerId}|${it.date}|${it.round}" }
        data.dailyIssues.forEach { keys += "DAILY_ISSUE:${it.id}" }
        data.auditLog.forEach { keys += "AUDIT:${it.id}" }
        keys += "SETTINGS:assembly"
        save(keys)
    }

    @Synchronized fun pending(): Set<String> = prefs.getStringSet(KEY_PENDING, emptySet()).orEmpty().toSet()
    @Synchronized fun remove(key: String) = save(pending() - key)
    @Synchronized fun isEmpty(): Boolean = pending().isEmpty()
    @Synchronized fun clear() = save(emptySet())

    private fun save(keys: Set<String>) {
        prefs.edit().putStringSet(KEY_PENDING, keys).apply()
        SyncOutboxEvents.notifyChanged()
    }

    private fun <T, K> addChanged(
        target: MutableSet<String>, before: List<T>, after: List<T>, key: (T) -> K, encode: (T) -> String
    ) {
        val old = before.associateBy(key)
        after.filter { old[key(it)] != it }.forEach { target += encode(it) }
    }

    companion object {
        private const val PREFS = "toy_bola_sync_outbox"
        private const val KEY_PENDING = "pending"
    }
}
