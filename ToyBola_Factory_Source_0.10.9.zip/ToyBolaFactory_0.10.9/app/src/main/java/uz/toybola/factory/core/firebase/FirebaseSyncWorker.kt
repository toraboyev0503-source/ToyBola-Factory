package uz.toybola.factory.core.firebase

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class FirebaseSyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        if (!ServerAuthRepository(applicationContext).hasFirebaseSession()) return Result.success()
        val sync = FirebaseSyncCoordinator(applicationContext).syncNow()
        return if (sync.isSuccess) Result.success() else Result.retry()
    }
}
