package uz.toybola.factory.core.firebase

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.SectionAccess
import uz.toybola.factory.core.security.UserAccessPolicy
import java.util.Locale

class ServerPolicyCache(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun save(policy: UserAccessPolicy) {
        val sections = JSONObject()
        policy.sections.forEach { (section, access) ->
            sections.put(section.name, JSONObject().put("read", access.canRead).put("write", access.canWrite))
        }
        val root = JSONObject()
            .put("uid", policy.uid)
            .put("userCode", policy.userCode)
            .put("displayName", policy.displayName)
            .put("role", policy.role)
            .put("allBrigades", policy.allowedBrigadeIds == null)
            .put("brigades", JSONArray().apply { policy.allowedBrigadeIds?.forEach { brigadeId -> put(brigadeId) } })
            .put("sections", sections)
            .put("notifications", JSONArray().apply { policy.notificationKeys.forEach { notificationKey -> put(notificationKey) } })
            .put("revision", policy.revision)
            .put("source", policy.source)
        prefs.edit().putString(key(policy.userCode), root.toString()).apply()
    }

    fun load(userCode: String): UserAccessPolicy? {
        val normalized = userCode.trim().uppercase(Locale.ROOT)
        if (normalized.isBlank()) return null
        val raw = prefs.getString(key(normalized), null) ?: return null
        return runCatching {
            val root = JSONObject(raw)
            val sectionObject = root.optJSONObject("sections") ?: JSONObject()
            val sections = AssemblySection.entries.associateWith { section ->
                val item = sectionObject.optJSONObject(section.name)
                SectionAccess(item?.optBoolean("read") == true, item?.optBoolean("write") == true)
            }
            val brigadeIds: Set<String>? = if (root.optBoolean("allBrigades")) {
                null
            } else {
                val values = mutableSetOf<String>()
                val arr = root.optJSONArray("brigades") ?: JSONArray()
                repeat(arr.length()) { i ->
                    val value = arr.optString(i, "").trim()
                    if (value.isNotBlank()) values.add(value)
                }
                values
            }
            val notifications: Set<String> = mutableSetOf<String>().apply {
                val arr = root.optJSONArray("notifications") ?: JSONArray()
                repeat(arr.length()) { i ->
                    val value = arr.optString(i, "").trim()
                    if (value.isNotBlank()) add(value)
                }
            }
            UserAccessPolicy(
                uid = root.optString("uid"),
                userCode = root.optString("userCode", normalized),
                displayName = root.optString("displayName"),
                role = root.optString("role"),
                allowedBrigadeIds = brigadeIds,
                sections = sections,
                notificationKeys = notifications,
                revision = root.optLong("revision"),
                source = root.optString("source", "server-cache")
            )
        }.getOrNull()
    }

    fun clear(userCode: String) {
        prefs.edit().remove(key(userCode)).apply()
    }

    private fun key(code: String) = "policy_${code.trim().uppercase(Locale.ROOT)}"

    companion object { private const val PREFS = "toy_bola_server_policy" }
}
