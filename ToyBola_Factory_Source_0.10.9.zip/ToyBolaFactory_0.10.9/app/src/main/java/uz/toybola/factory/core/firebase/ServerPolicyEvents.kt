package uz.toybola.factory.core.firebase

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** In-process signal used to refresh permissions immediately after a POLICY_CHANGED FCM. */
object ServerPolicyEvents {
    private val _revision = MutableStateFlow(0L)
    val revision: StateFlow<Long> = _revision.asStateFlow()

    fun notifyChanged() {
        _revision.value = _revision.value + 1L
    }
}
