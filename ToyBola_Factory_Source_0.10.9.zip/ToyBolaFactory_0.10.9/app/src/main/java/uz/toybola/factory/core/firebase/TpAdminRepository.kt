package uz.toybola.factory.core.firebase

import android.content.Context
import com.google.firebase.functions.FirebaseFunctions
import uz.toybola.factory.core.data.TpDataRepository

class TpAdminRepository(context: Context) {
    private val appContext = context.applicationContext
    private val functions = FirebaseFunctions.getInstance("europe-west1")

    suspend fun resetTpForFreshImport(): Result<Int> = runCatching {
        val dailyTarget = TpDataRepository(appContext).load().globalDailyTargetAmount()
        val result = functions.getHttpsCallable("adminResetTpData").call(mapOf("dailyTargetAmount" to dailyTarget)).awaitResult()
        val root = result.data as? Map<*, *> ?: error("Server javobi noto‘g‘ri")
        val deleted = (root["deleted"] as? Number)?.toInt() ?: 0
        TpDataRepository(appContext).resetTpForFreshImportLocal()
        deleted
    }
}
