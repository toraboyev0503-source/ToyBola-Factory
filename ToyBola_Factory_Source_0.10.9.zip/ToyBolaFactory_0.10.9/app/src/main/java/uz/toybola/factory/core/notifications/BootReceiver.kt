package uz.toybola.factory.core.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import uz.toybola.factory.core.data.AssemblyDataRepository

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            NotificationScheduler.scheduleUpcoming(context, AssemblyDataRepository(context))
        }
    }
}
