package uz.toybola.factory.core.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import uz.toybola.factory.MainActivity
import uz.toybola.factory.R
import uz.toybola.factory.core.data.AssemblyDataRepository

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val type = intent.getStringExtra(NotificationScheduler.EXTRA_TYPE) ?: return
        val date = intent.getStringExtra(NotificationScheduler.EXTRA_DATE) ?: return
        val repo = AssemblyDataRepository(context)
        val data = repo.load()
        val activeBrigades = data.brigades.filterNot { it.archived }

        val (title, body, route) = when (type) {
            NotificationScheduler.QUALITY_ROUND_1,
            NotificationScheduler.QUALITY_ROUND_2,
            NotificationScheduler.QUALITY_ROUND_3 -> {
                val round = when (type) {
                    NotificationScheduler.QUALITY_ROUND_1 -> 1
                    NotificationScheduler.QUALITY_ROUND_2 -> 2
                    else -> 3
                }
                if (activeBrigades.all { data.brigadeDay(it.id, date)?.qualityClosed == true }) return
                Triple("Sifat nazorati", "$round-raund boshlandi. Baholash oynasi ±1 soat.", "QUALITY")
            }
            NotificationScheduler.QUALITY_CLOSE -> {
                val pending = activeBrigades.filter { data.brigadeDay(it.id, date)?.qualityClosed != true }
                if (pending.isEmpty()) return
                Triple("Sifat kuni yopilmagan", "${pending.size} ta brigada bo‘yicha sabab va yakunlashni tekshiring.", "QUALITY")
            }
            NotificationScheduler.ISSUE_SUMMARY -> {
                val count = data.dailyIssues.count { it.date == date }
                if (count == 0) return
                val top = data.dailyIssues.filter { it.date == date }.groupBy { it.productId }.maxByOrNull { it.value.size }?.value?.firstOrNull()
                val extra = top?.let { " Eng ko‘p: ${it.articleSnapshot} — ${it.productNameSnapshot}." }.orEmpty()
                Triple("Bugungi Sborka muammolari", "$count ta muammo yozildi.$extra", "MONITORING")
            }
            NotificationScheduler.BRIGADIR_REMINDER -> {
                val pending = activeBrigades.filter { b -> data.hasActivity(b.id, date) && data.brigadeDay(b.id, date)?.brigadirClosed != true }
                if (pending.isEmpty()) return
                Triple("Brigadir kuni yopilmagan", "$date kuni uchun ${pending.size} ta brigada ochiq. 09:00 gacha yoping.", "BRIGADIR")
            }
            NotificationScheduler.BRIGADIR_DEADLINE -> {
                val pending = activeBrigades.filter { b -> data.hasActivity(b.id, date) && data.brigadeDay(b.id, date)?.brigadirClosed != true }
                if (pending.isEmpty()) return
                Triple("Brigadir yopish muddati o‘tdi", "$date kuni yopilmagan. Sabab yozib, kunni yakunlang.", "BRIGADIR")
            }
            else -> return
        }
        val notificationKey = "$type|$date"
        NotificationInboxRepository(context).addOrUpdate(notificationKey, title, body, route)
        show(context, title, body, route, notificationKey, notificationKey.hashCode())
    }

    private fun show(context: Context, title: String, body: String, route: String, notificationKey: String, id: Int) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Toy Bola eslatmalari", NotificationManager.IMPORTANCE_HIGH))
        }
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_ROUTE, route)
            putExtra(EXTRA_NOTIFICATION_KEY, notificationKey)
        }
        val pending = PendingIntent.getActivity(context, id, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()
        manager.notify(id, notification)
    }

    companion object {
        const val EXTRA_ROUTE = "notification_route"
        const val EXTRA_NOTIFICATION_KEY = "notification_key"
        private const val CHANNEL_ID = "toy_bola_operational"
    }
}
