package uz.toybola.factory.core.notifications

import androidx.compose.runtime.mutableStateOf

object NotificationRouteState {
    val route = mutableStateOf<String?>(null)
    fun set(value: String?) { route.value = value }
    fun clear() { route.value = null }
}
