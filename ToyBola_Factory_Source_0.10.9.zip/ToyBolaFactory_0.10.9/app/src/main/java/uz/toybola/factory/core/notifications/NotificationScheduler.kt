package uz.toybola.factory.core.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import uz.toybola.factory.core.data.AssemblyDataRepository
import uz.toybola.factory.core.firebase.ServerPolicyCache
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.core.security.AssemblySection
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

object NotificationScheduler {
    const val EXTRA_TYPE = "notification_type"
    const val EXTRA_DATE = "notification_date"

    const val QUALITY_ROUND_1 = "quality_round_1"
    const val QUALITY_ROUND_2 = "quality_round_2"
    const val QUALITY_ROUND_3 = "quality_round_3"
    const val QUALITY_CLOSE = "quality_close"
    const val ISSUE_SUMMARY = "issue_summary"
    const val BRIGADIR_REMINDER = "brigadir_reminder"
    const val BRIGADIR_DEADLINE = "brigadir_deadline"

    fun scheduleUpcoming(context: Context, repository: AssemblyDataRepository, days: Int = 4) {
        val appContext = context.applicationContext
        cancelManagedUpcoming(appContext, 14)
        val userCode = AppPreferences(appContext).setup()?.userCode.orEmpty()
        val policy = ServerPolicyCache(appContext).load(userCode) ?: return
        val qualityUser = policy.canWrite(AssemblySection.QUALITY) || policy.role.equals("QUALITY", true)
        val brigadirUser = policy.canWrite(AssemblySection.BRIGADIR) || policy.role.equals("BRIGADIR", true)
        val issueWatcher = "ISSUE_SUMMARY" in policy.notificationKeys
        if (!qualityUser && !brigadirUser && !issueWatcher) return

        val data = repository.load()
        val today = LocalDate.now()
        repeat(days.coerceIn(1, 14)) { offset ->
            val date = today.plusDays(offset.toLong())
            if (qualityUser) {
                val times = data.roundTimesAt(date.toString())
                schedule(appContext, date.atTime(LocalTime.parse(times.first)), QUALITY_ROUND_1, date)
                schedule(appContext, date.atTime(LocalTime.parse(times.second)), QUALITY_ROUND_2, date)
                schedule(appContext, date.atTime(LocalTime.parse(times.third)), QUALITY_ROUND_3, date)
                schedule(appContext, date.atTime(17, 50), QUALITY_CLOSE, date)
            }
            if (issueWatcher) schedule(appContext, date.atTime(18, 0), ISSUE_SUMMARY, date)
            if (brigadirUser) {
                schedule(appContext, date.plusDays(1).atTime(8, 50), BRIGADIR_REMINDER, date)
                schedule(appContext, date.plusDays(1).atTime(9, 0), BRIGADIR_DEADLINE, date)
            }
        }
    }

    private fun cancelManagedUpcoming(context: Context, days: Int) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val today = LocalDate.now()
        val types = listOf(
            QUALITY_ROUND_1, QUALITY_ROUND_2, QUALITY_ROUND_3, QUALITY_CLOSE,
            ISSUE_SUMMARY, BRIGADIR_REMINDER, BRIGADIR_DEADLINE
        )
        repeat(days.coerceIn(1, 30)) { offset ->
            val date = today.plusDays(offset.toLong())
            types.forEach { type ->
                val pending = PendingIntent.getBroadcast(
                    context,
                    ("$type|$date").hashCode(),
                    Intent(context, NotificationReceiver::class.java),
                    PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
                )
                if (pending != null) {
                    alarm.cancel(pending)
                    pending.cancel()
                }
            }
        }
    }

    private fun schedule(context: Context, whenAt: LocalDateTime, type: String, recordDate: LocalDate) {
        val now = LocalDateTime.now()
        if (!whenAt.isAfter(now)) return
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, NotificationReceiver::class.java).apply {
            putExtra(EXTRA_TYPE, type)
            putExtra(EXTRA_DATE, recordDate.toString())
        }
        val requestCode = ("$type|$recordDate").hashCode()
        val pending = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val millis = whenAt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending)
    }
}
