package uz.toybola.factory.core.permissions

import android.content.Context

enum class AssemblyPermission {
    BRIGADIR_READ,
    BRIGADIR_WRITE,
    QUALITY_READ,
    QUALITY_WRITE,
    DAILY_ISSUE_READ,
    DAILY_ISSUE_WRITE,
    MONITORING_READ,
    MASTER_DATA_READ,
    MASTER_DATA_WRITE,
    DAY_STATUS_NOTIFICATIONS
}

data class UserAccessPolicy(
    val userCode: String,
    val allowedBrigadeIds: Set<String> = emptySet(),
    val permissions: Set<AssemblyPermission> = AssemblyPermission.entries.toSet(),
    val serverManaged: Boolean = false
)

/**
 * Local cache for the access policy that will later be supplied by the central server.
 *
 * Current offline test builds default to all permissions so existing behaviour does not change.
 * When the server layer is connected, the downloaded policy can be cached through
 * [saveServerPolicy]. The server/security rules remain the authority; this cache is only for
 * fast UI gating and offline continuity.
 */
class AccessPolicyRepository(context: Context) {
    private val prefs = context.getSharedPreferences("toy_bola_access_policy", Context.MODE_PRIVATE)

    fun policyFor(userCode: String): UserAccessPolicy {
        val normalized = userCode.trim().uppercase()
        if (normalized.isBlank()) return localDefault(normalized)

        val managed = prefs.getBoolean(key(normalized, "managed"), false)
        if (!managed) return localDefault(normalized)

        val permissionNames = prefs.getStringSet(key(normalized, "permissions"), emptySet()).orEmpty()
        val permissions = permissionNames.mapNotNullTo(mutableSetOf()) { name ->
            runCatching { AssemblyPermission.valueOf(name) }.getOrNull()
        }
        val brigades = prefs.getStringSet(key(normalized, "brigades"), emptySet()).orEmpty()

        return UserAccessPolicy(
            userCode = normalized,
            allowedBrigadeIds = brigades,
            permissions = permissions,
            serverManaged = true
        )
    }

    fun saveServerPolicy(policy: UserAccessPolicy) {
        val normalized = policy.userCode.trim().uppercase()
        if (normalized.isBlank()) return
        prefs.edit()
            .putBoolean(key(normalized, "managed"), true)
            .putStringSet(key(normalized, "permissions"), policy.permissions.map { it.name }.toSet())
            .putStringSet(key(normalized, "brigades"), policy.allowedBrigadeIds)
            .apply()
    }

    fun clearServerPolicy(userCode: String) {
        val normalized = userCode.trim().uppercase()
        prefs.edit()
            .remove(key(normalized, "managed"))
            .remove(key(normalized, "permissions"))
            .remove(key(normalized, "brigades"))
            .apply()
    }

    private fun localDefault(userCode: String) = UserAccessPolicy(userCode = userCode)

    private fun key(userCode: String, suffix: String) = "${userCode}_$suffix"
}
