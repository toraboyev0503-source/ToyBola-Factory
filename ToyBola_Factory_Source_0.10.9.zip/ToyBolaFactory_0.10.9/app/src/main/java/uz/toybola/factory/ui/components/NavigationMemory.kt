package uz.toybola.factory.ui.components

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember

/**
 * Keeps the exact vertical position of long lists while the user opens a child screen and returns.
 * Positions live only for the current app process; they are not business data and are never synced.
 */
private object NavigationScrollMemory {
    val positions = mutableMapOf<String, Int>()
}

@Composable
fun rememberRetainedScrollState(key: String): ScrollState {
    val state = remember(key) { ScrollState(NavigationScrollMemory.positions[key] ?: 0) }
    DisposableEffect(key, state) {
        onDispose { NavigationScrollMemory.positions[key] = state.value }
    }
    return state
}
