package uz.toybola.factory.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import uz.toybola.factory.core.data.AssemblyBackupRepository
import uz.toybola.factory.core.data.AssemblyDataRepository
import uz.toybola.factory.core.firebase.AssemblySyncOutbox
import uz.toybola.factory.core.firebase.ServerRecoveryRepository
import uz.toybola.factory.core.firebase.FirebaseSyncCoordinator
import uz.toybola.factory.core.firebase.SyncStatusEvents
import uz.toybola.factory.core.firebase.ServerMigrationState
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings

@Composable
fun BackupRestoreScreen(
    strings: AppStrings,
    repository: AssemblyDataRepository,
    isAdmin: Boolean,
    allowedBrigadeIds: Set<String>?,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val backupRepository = remember(context) { AssemblyBackupRepository(context) }
    val outbox = remember(context) { AssemblySyncOutbox(context) }
    val migrationState = remember(context) { ServerMigrationState(context) }
    val serverRecovery = remember(context) { ServerRecoveryRepository(context) }
    var summary by remember { mutableStateOf(backupRepository.localSummary(allowedBrigadeIds)) }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var confirmUpload by remember { mutableStateOf(false) }
    val runtime by SyncStatusEvents.state.collectAsState()

    val createBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            busy = true
            scope.launch {
                val result = backupRepository.exportTo(uri, allowedBrigadeIds)
                message = result.fold(
                    onSuccess = { strings.backupExported },
                    onFailure = { it.message ?: strings.backupFailed }
                )
                summary = backupRepository.localSummary(allowedBrigadeIds)
                busy = false
            }
        }
    }

    val importBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null && isAdmin) {
            busy = true
            scope.launch {
                migrationState.setRecoveryInProgress(true)
                val imported = backupRepository.importAndMerge(uri)
                if (imported.isFailure) {
                    migrationState.setRecoveryInProgress(false)
                    message = imported.exceptionOrNull()?.message ?: strings.backupFailed
                    busy = false
                    return@launch
                }
                summary = backupRepository.localSummary(allowedBrigadeIds)
                val upload = serverRecovery.uploadAll(repository.load())
                if (upload.isSuccess) {
                    // The complete merged local snapshot has now been normalized server-side, so
                    // old client outbox rows are superseded by the audited recovery transaction.
                    outbox.clear()
                    migrationState.setRecoveryInProgress(false)
                    val refresh = FirebaseSyncCoordinator(context).syncNow()
                    message = if (refresh.isSuccess) {
                        strings.backupImportedAndUploaded
                    } else {
                        strings.serverUploadComplete + ". Qayta sinxronlash: " +
                            (refresh.exceptionOrNull()?.message ?: "xato")
                    }
                } else {
                    migrationState.setRecoveryInProgress(true)
                    message = strings.backupImportedPending + ": " +
                        (upload.exceptionOrNull()?.message ?: "server xatosi")
                }
                summary = backupRepository.localSummary(allowedBrigadeIds)
                busy = false
            }
        }
    }

    Scaffold(
        topBar = { AppTopBar(strings.backupRestore, true, {}, onBack) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(strings.backupRestoreHelp, style = MaterialTheme.typography.bodyMedium)

            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(strings.localData, fontWeight = FontWeight.Bold)
                    Text(strings.backupCountLine(summary.brigades, summary.workers, summary.products))
                    Text(strings.backupOperationalCountLine(summary.workerDays, summary.qualityRounds, summary.dailyIssues))
                    Text("${strings.total}: ${summary.totalRecords}")
                }
            }

            Button(
                onClick = { createBackup.launch(AssemblyBackupRepository.DEFAULT_FILE_NAME) },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth()
            ) { Text(strings.exportLocalBackup) }

            if (isAdmin) {
                HorizontalDivider()
                Text(strings.adminRecovery, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(strings.adminRecoveryHelp, style = MaterialTheme.typography.bodySmall)

                Button(
                    onClick = { importBackup.launch(arrayOf("application/json", "text/*", "application/octet-stream")) },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(strings.importBackupToServer) }

                OutlinedButton(
                    onClick = { confirmUpload = true },
                    enabled = !busy && summary.totalRecords > 1,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(strings.uploadAllLocalToServer) }
            }

            if (busy || runtime.syncing) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
            }
            if (message.isNotBlank()) {
                Text(
                    message,
                    color = if (message.contains("xato", true) || message.contains("failed", true))
                        MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
            }
        }
    }

    if (confirmUpload) {
        AlertDialog(
            onDismissRequest = { confirmUpload = false },
            title = { Text(strings.uploadAllLocalToServer) },
            text = { Text(strings.uploadAllConfirm) },
            confirmButton = {
                TextButton(onClick = {
                    confirmUpload = false
                    busy = true
                    scope.launch {
                        migrationState.setRecoveryInProgress(true)
                        val result = serverRecovery.uploadAll(repository.load())
                        if (result.isSuccess) {
                            outbox.clear()
                            migrationState.setRecoveryInProgress(false)
                            val refresh = FirebaseSyncCoordinator(context).syncNow()
                            message = if (refresh.isSuccess) {
                                strings.serverUploadComplete
                            } else {
                                strings.serverUploadComplete + ". Qayta sinxronlash: " +
                                    (refresh.exceptionOrNull()?.message ?: "xato")
                            }
                        } else {
                            migrationState.setRecoveryInProgress(true)
                            message = strings.serverUploadPending + ": " +
                                (result.exceptionOrNull()?.message ?: "server xatosi")
                        }
                        summary = backupRepository.localSummary(allowedBrigadeIds)
                        busy = false
                    }
                }) { Text(strings.yes) }
            },
            dismissButton = { TextButton(onClick = { confirmUpload = false }) { Text(strings.cancel) } }
        )
    }
}
