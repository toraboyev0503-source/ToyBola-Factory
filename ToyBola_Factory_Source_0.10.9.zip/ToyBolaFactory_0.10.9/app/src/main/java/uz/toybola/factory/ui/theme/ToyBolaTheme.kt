package uz.toybola.factory.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import uz.toybola.factory.ui.model.AppSettings
import uz.toybola.factory.ui.model.AppThemePreset

private val Red = Color(0xFFE62B20)
private val Yellow = Color(0xFFFFC21C)
private val Navy = Color(0xFF142534)
private val Ice = Color(0xFFF3F9FC)

@Composable
fun ToyBolaTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val seed = when (settings.themePreset) {
        AppThemePreset.BRAND -> Red
        AppThemePreset.CALM -> Color(0xFF367DB5)
        AppThemePreset.NEUTRAL -> Color(0xFF59636D)
    }

    val colors = if (settings.darkMode) {
        darkColorScheme(
            primary = seed,
            secondary = Yellow,
            background = Color(0xFF101418),
            surface = Color(0xFF182027),
            onPrimary = Color.White,
            onBackground = Color(0xFFF4F7F9),
            onSurface = Color(0xFFF4F7F9)
        )
    } else {
        lightColorScheme(
            primary = seed,
            secondary = Yellow,
            tertiary = Navy,
            background = Ice,
            surface = Color.White,
            onPrimary = Color.White,
            onBackground = Navy,
            onSurface = Navy
        )
    }

    MaterialTheme(colorScheme = colors, content = content)
}
