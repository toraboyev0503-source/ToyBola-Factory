package uz.toybola.factory.core.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AssemblyBackupMergeTest {
    @Test
    fun mergeCombinesTwoPhoneBackupsWithoutDroppingData() {
        val local = AssemblyData(
            brigades = listOf(Brigade("b1", "Keles")),
            workers = listOf(Worker("w1", "b1", "Ali", "2026-01-01")),
            products = listOf(Product("p1", "b1", "TB-1", "Toy", priceHistory = listOf(PriceVersion(1000, "2026-01-01")))),
            workerDays = listOf(WorkerDay("w1", "b1", "2026-08-20", hours = 10)),
            dailyIssues = listOf(DailyIssueRecord("i1", "b1", "2026-08-20", "p1", "TB-1", "Toy", "s1", "Stage", "A", "2026-08-20T10:00:00"))
        )
        val incoming = AssemblyData(
            brigades = listOf(Brigade("b1", "Keles")),
            qualityRounds = listOf(
                QualityRoundRecord("q1", "w1", "b1", "2026-08-20", 1, "10:00", grade = 1, score = 100)
            ),
            dailyIssues = listOf(DailyIssueRecord("i2", "b1", "2026-08-20", "p1", "TB-1", "Toy", "s1", "Stage", "B", "2026-08-20T11:00:00"))
        )

        val merged = mergeAssemblyBackup(local, incoming)

        assertEquals(1, merged.brigades.size)
        assertEquals(1, merged.workers.size)
        assertEquals(1, merged.products.size)
        assertEquals(1, merged.workerDays.size)
        assertEquals(1, merged.qualityRounds.size)
        assertEquals(2, merged.dailyIssues.size)
        assertTrue(merged.dailyIssues.map { it.id }.containsAll(listOf("i1", "i2")))
    }

    @Test
    fun mergeUnionsHistoricalPricesByEffectiveDate() {
        val local = AssemblyData(products = listOf(
            Product("p1", "b1", "TB-1", "Toy", priceHistory = listOf(PriceVersion(1000, "2026-01-01")))
        ))
        val incoming = AssemblyData(products = listOf(
            Product("p1", "b1", "TB-1", "Toy", priceHistory = listOf(PriceVersion(1200, "2026-08-01")))
        ))

        val merged = mergeAssemblyBackup(local, incoming)
        assertEquals(listOf(1000L, 1200L), merged.products.single().priceHistory.sortedBy { it.effectiveFrom }.map { it.price })
    }
}
