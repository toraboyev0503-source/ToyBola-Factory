package uz.toybola.factory.core.data

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class MonitoringMetricsTest {
    private val date = "2026-08-18"
    private val d = LocalDate.parse(date)

    @Test
    fun completedDayProducesExpectedPercentagesAndIssueCount() {
        val data = completeData()
        assertEquals(100.0, data.monitoringMetric(MonitoringMetricKind.WORKERS, d, d).percentage!!, 0.001)
        assertEquals(100.0, data.monitoringMetric(MonitoringMetricKind.BRIGADIRS, d, d).percentage!!, 0.001)
        assertEquals(100.0, data.monitoringMetric(MonitoringMetricKind.QUALITY, d, d).percentage!!, 0.001)
        assertEquals(2, data.monitoringMetric(MonitoringMetricKind.ISSUES, d, d).count)
    }

    @Test
    fun incompleteDayDoesNotReturnMisleadingPercentage() {
        val data = completeData().let { it.copy(brigadeDays = it.brigadeDays.map { day -> day.copy(closedAt = null) }) }
        assertEquals(MonitoringMetricState.INCOMPLETE, data.monitoringMetric(MonitoringMetricKind.WORKERS, d, d).state)
        assertEquals(MonitoringMetricState.INCOMPLETE, data.monitoringMetric(MonitoringMetricKind.BRIGADIRS, d, d).state)
    }

    @Test
    fun nonWorkingDayIsNotZeroPercent() {
        val base = completeData()
        val off = base.copy(
            brigadeDays = base.brigadeDays.map { it.copy(worked = false, brigadirClosedAt = null, qualityClosedAt = null, closedAt = null) },
            workerDays = emptyList(),
            qualityRounds = emptyList()
        )
        assertEquals(MonitoringMetricState.NOT_WORKED, off.monitoringMetric(MonitoringMetricKind.WORKERS, d, d).state)
    }


    @Test
    fun archivedBrigade_doesNotMakeAllBrigadesIncomplete() {
        val base = completeData()
        val archived = Brigade("b2", "Old", archived = true)
        val incompleteArchivedDay = BrigadeDay("b2", date, worked = true)
        val data = base.copy(
            brigades = base.brigades + archived,
            brigadeDays = base.brigadeDays + incompleteArchivedDay
        )
        assertEquals(100.0, data.monitoringMetric(MonitoringMetricKind.WORKERS, d, d).percentage!!, 0.001)
        assertEquals(100.0, data.monitoringMetric(MonitoringMetricKind.BRIGADIRS, d, d).percentage!!, 0.001)
    }

    private fun completeData(): AssemblyData {
        val brigade = Brigade("b1", "B1")
        val worker = Worker("w1", "b1", "Ali", "2026-01-01")
        val workerDay = WorkerDay(
            workerId = "w1", brigadeId = "b1", date = date, worked = true, hours = 10,
            entries = listOf(ProductionEntry("e1", "p1", "A1", "Toy", 100.0, 1000))
        )
        val rounds = (1..3).map { round ->
            QualityRoundRecord(
                id = "q$round", workerId = "w1", brigadeId = "b1", date = date, round = round,
                scheduledTime = when (round) { 1 -> "10:00"; 2 -> "13:00"; else -> "16:00" },
                grade = 1, score = 100, productId = "p1", articleSnapshot = "A1", productNameSnapshot = "Toy",
                evaluatedAt = "2026-08-18T10:00:00"
            )
        }
        return AssemblyData(
            brigades = listOf(brigade),
            workers = listOf(worker),
            brigadeFk = listOf(BrigadeFkHistory("b1", listOf(LongVersion(100000, "2000-01-01")))),
            workHours = listOf(IntVersion(10, "2000-01-01")),
            efficiencyNorm = listOf(IntVersion(85, "2000-01-01")),
            roundTimes = listOf(RoundTimesVersion("10:00", "13:00", "16:00", "2000-01-01")),
            monitoringWeights = listOf(MonitoringWeightsVersion(BrigadirWeights(), QualityWeights(), "2000-01-01")),
            workerDays = listOf(workerDay),
            brigadeDays = listOf(BrigadeDay("b1", date, true, "2026-08-19T08:50:00", "", "2026-08-18T17:40:00", "", "2026-08-18T17:41:00")),
            qualityRounds = rounds,
            dailyIssues = listOf(
                DailyIssueRecord("i1", "b1", date, "p1", "A1", "Toy", "s1", "Stage", "x", "2026-08-18T12:00:00"),
                DailyIssueRecord("i2", "b1", date, "p1", "A1", "Toy", "s1", "Stage", "y", "2026-08-18T13:00:00")
            )
        )
    }
}
