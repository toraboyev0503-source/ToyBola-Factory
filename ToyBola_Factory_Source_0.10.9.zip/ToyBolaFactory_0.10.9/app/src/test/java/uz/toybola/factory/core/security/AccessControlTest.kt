package uz.toybola.factory.core.security

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AccessControlTest {
    @Test
    fun assemblyOnlyUserDoesNotRequestTpSnapshot() {
        val policy = UserAccessPolicy(
            userCode = "BRG01",
            role = "BRIGADIR",
            sections = mapOf(AssemblySection.BRIGADIR to SectionAccess(canRead = true, canWrite = true))
        )
        assertFalse(policy.canReadAnyTp())
    }

    @Test
    fun tpRoleRequestsTpSnapshot() {
        val policy = UserAccessPolicy(
            userCode = "TPL01",
            role = "TP_PLAN",
            sections = mapOf(AssemblySection.TP_PLANNING to SectionAccess(canRead = true, canWrite = true))
        )
        assertTrue(policy.canReadAnyTp())
    }

    @Test
    fun adminKeepsTpAccessWhenLegacyPermissionMapHasNoTpKeys() {
        val policy = UserAccessPolicy(userCode = "ADMIN001", role = "ADMIN", sections = emptyMap())
        assertTrue(policy.canReadAnyTp())
    }
}
