# ToyBola Factory 0.10.0

## Foydalanuvchi oqimi

1. **TP nachalnik** Plan ichida artikul, mahsulot, son, kerakli sana va ustuvorlik bilan partiya ochadi. Birinchi partiya raqami qo‘lda, keyingilari avtomatik beriladi.
2. **TP plan beruvchi** mahsulot kartasidagi qolip/detal ma’lumotlaridan avtomatik plan hosil qiladi, mos stanok, brigada va navbatni belgilaydi. Davomatni kiritadi yoki ishlagan daqiqani o‘zgartiradi.
3. **Seryo** har vazifa uchun kg seryo va gram krasitelni, jami ehtiyoj hamda mavjud qoldiq yetishini ko‘radi; qorishmani tasdiqlab stanokka chiqaradi.
4. **TP brigadir** o‘z brigadasidagi stanok navbatini, detal/rang/jim sonini va seryo yetkazilgan holatini ko‘radi. Vazifani boshlaydi yoki kutishga qo‘yadi.
5. **Qabul qiluvchi** qop soni, qop qoldig‘i, ishchi va qabul qiluvchi ismini kiritadi. Oldingi smena qoldig‘i avtomatik ayriladi; partiya faqat real qabul rejasiga yetganda yopiladi.
6. **TP sifat nazoratchisi** smena uchun belgilangan raundlarda stanok va ishchini baholaydi, muammo va kun muammosini yozadi.
7. **Admin/Rahbar** Monitoringda partiya, ishchi, stanok, brigada, sifat va xomashyo natijalarini sana/brigada bo‘yicha ko‘radi hamda Word yoki Excel hisobot oladi.

## Ma’lumot kartalari

- 3 sex, kunduzgi/tungi smena va 6 brigada tayyor boshlang‘ich tuzilma; nom, vaqt, raundlar va brigada birikmasi o‘zgartiriladi.
- Stanok raqami zavod bo‘yicha yagona; yangi sex, brigada va stanok qo‘shiladi.
- Mahsulot: artikul, nom va detallar.
- Detal/qolip: bir mahsulotga ketadigan dona, bir jimdagi dona, qop sig‘imi, sikl soniyasi, jimning umumiy/yaroqsiz og‘irligi, seryo kodi, narx va mos stanoklar.
- Rang: bitta detalga bir yoki ko‘p rang ulushi hamda har 25 kg uchun krasitel grammi.
- Ishchi: brigada, kunlik pul normasi va odatiy ishlash daqiqasi.
- Xomashyo: seryo qoldig‘i kilogrammda, krasitel qoldig‘i gramda.

## Himoya va sinxronlash

- Yangi TP rollari va har bo‘lim uchun alohida o‘qish/yozish ruxsatlari bor.
- Client yozuvlari Firestore Rules orqali, server snapshot esa Cloud Function orqali tekshiriladi.
- TP ma’lumotlari hujjatlar kesimida yoziladi; bitta telefon butun server holatini bosib ketmaydi.
- Har muhim o‘zgarish TP audit jurnaliga tushadi.
- Fresh install `getAssemblySnapshot` va `getTpSnapshot` orqali ruxsatli ma’lumotni serverdan qaytaradi.

## Sborka chegarasi

Sborka 0.9.5 dagi qoldiqli son imkoniyati bilan qoladi. TP/Seryo moduli alohida repository, outbox, snapshot va ekranlarda ishlaydi; mavjud Sborka biznes mantig‘i o‘zgartirilmagan.
