# ToyBola Factory 0.10.1

## TP avtomatik sync

TP/Seryo lokal o‘zgarishlari endi global Sync/Pending indikatoriga Assembly bilan birga kiradi. Har TP write lokalga saqlangach TP outbox diff yozadi va WorkManager sync avtomatik rejalashtiriladi. Faol sync paytida kelgan yangi sync so‘rovi `APPEND_OR_REPLACE` orqali keyingi ish sifatida saqlanadi.

## Nachalnik zakazi

- Ustuvorlik: **Eng zaril / Zaril / Keyinroq** rangli 3 tugma.
- Ro‘yxat ustuvorlik bo‘yicha saralanadi.
- `Kerakli sana` foydalanuvchi maydoni yo‘q.
- Zakaz kartasi berilgan vaqt va taxminiy to‘liq quyish muddatini ko‘rsatadi.
- Zakaz edit/delete mavjud; ishlab chiqarish boshlangan ma’lumotni xavfli tarzda o‘zgartirish bloklanadi.

## Plan beruvchi

Zakaz kartasidan detal rejasiga kiriladi. Har detal jami dona bilan ko‘rinadi. Ranglar ochilib, ularning navbati 1..N qilib qayta tartiblanadi. Stanok tanlashda faqat mos mashinalar chiqadi: bo‘shlari birinchi, bandlari eng tez bo‘shaydiganidan boshlab. Stanokdagi hozirgi qolip/rang/detal va taxminiy boshlanish kechikishi ko‘rsatiladi.

## Sig‘im modeli

- Stanok: `capacity` — masalan 60, 90, 120.
- Detal/qolip: `compatibleCapacities` — bir yoki bir nechta mos sig‘im.
- Existing `compatibleMachineIds` ham saqlanadi va sig‘im bilan birga qo‘llanadi.
- Legacy ma’lumot buzilmaydi: eski stanok capacity 0, eski detal compatibleCapacities bo‘sh holatda ochiladi.

## Server va delete

Nachalnik ishlab chiqarish boshlanmagan zakazni o‘chirsa, TP outbox order/job delete operatsiyalarini serverga yuboradi. Firestore Rules faqat tegishli TP_ORDER/TP_PLANNING permission bilan delete ga ruxsat beradi.

## Tekshiruv holati

Model compile, TP capacity/forecast smoke test va Node syntax checks lokal bajarildi. To‘liq Android Gradle test/lint/APK build bu muhitda Gradle/Android SDK bo‘lmagani sababli GitHub Actionsda tekshiriladi.
