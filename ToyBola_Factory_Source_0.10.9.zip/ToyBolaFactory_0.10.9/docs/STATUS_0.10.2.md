# ToyBola Factory 0.10.2

0.10.2 — 0.10.1 muvaffaqiyatli bazasi ustidagi TP/Seryo pilot tuzatishlari. Sborka biznes hisoblari o‘zgartirilmagan; umumiy navigatsiyada Back/scroll xulqi yaxshilangan.

## Asosiy o‘zgarishlar

- Back bosish bir pog‘ona: ilova global Back va ichki ekran Back boshqaruvi ajratildi; TP Plan/mahsulot va Brigadir ichki oynalari o‘z parent ro‘yxatiga qaytadi.
- Uzoq asosiy ro‘yxatlar child oynadan qaytganda scroll pozitsiyasini eslab qoladi.
- Detal → mos stanok qo‘lda tanlanmaydi. Stanok `capacity`, detal `compatibleCapacities`; Plan beruvchi mos stanokni shu kesishma bilan oladi.
- Plan beruvchida **Tasdiqlanmagan / Tasdiqlangan** ro‘yxatlar va **Jarayonni boshlash / tasdiqlash** tugmasi bor. Approval downstream ish oqimlari uchun gate vazifasini bajaradi.
- Detal bir nechta seryo turiga ega bo‘lishi mumkin; bir qolipdagi detallar uchun umumiy variantlardan biri plan vazifasiga tanlanadi.
- Narx 1 detal donasiga emas, **1 jimga** tegishli. Qabul dona bilan kiritiladi; ishchi topgan summa jim ekvivalentiga aylantiriladi.

## Saqlash va sync

`planApprovedAt`, `resinCodes`, `piecesPerShotSnapshot` yangi ma’lumotlari lokal JSON va TP sync payloadlarda saqlanadi. Legacy fieldlar formatni buzmaslik uchun qoldirilgan. 0.10.1 dagi TP auto-sync/Pending fix saqlangan.

## Tekshiruv holati

Pure Kotlin TP model/report kompilyatsiyasi va ikki smoke-test muvaffaqiyatli. Node Functions syntax checklari muvaffaqiyatli. To‘liq Android Compose buildni GitHub Actions bajarishi kerak; APKni pilot telefonga faqat Actions test/lint/assembleDebug yashil bo‘lgach o‘rnating.
