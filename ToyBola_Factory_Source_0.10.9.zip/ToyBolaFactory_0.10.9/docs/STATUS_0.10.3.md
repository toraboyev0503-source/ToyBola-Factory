# ToyBola Factory 0.10.3

0.10.3 — 0.10.2 funksiyalariga tegmagan build-fix versiya.

## Tuzatilgan build xatosi
GitHub Actions `:app:compileDebugKotlin` bosqichida quyidagi xato chiqqan edi:

- `TpMasterDataScreen.kt:31:5 'public' function exposes its 'internal' parameter type 'TpMasterPage'`
- `TpMasterDataScreen.kt:32:5 'public' function exposes its 'internal' parameter type argument 'TpMasterPage'`

Sabab: `TpMasterDataPage(...)` public composable bo‘lib, uning `page` va `onPageChange` public signature'ida `internal enum class TpMasterPage` ishlatilgan.

Tuzatish: `TpMasterPage` visibility `internal` dan public enum'ga o‘zgartirildi. Funksional mantiq o‘zgarmadi.

## Versiya
- versionName: 0.10.3
- versionCode: 1003

## Saqlangan 0.10.2 funksiyalari
- bir pog‘onali Back va retained scroll;
- sig‘im asosidagi avtomatik stanok mosligi;
- Plan tasdiqlash / jarayonni boshlash oqimi;
- bir detal uchun bir nechta seryo turi;
- jim asosidagi narx va ish haqi hisoblash;
- TP avtomatik sync tuzatishlari.
