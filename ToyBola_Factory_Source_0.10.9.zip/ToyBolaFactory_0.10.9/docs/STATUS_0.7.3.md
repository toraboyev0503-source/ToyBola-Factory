# Toy Bola 0.7.3 holati

## Mobil Sborka funksiyalari

- [x] Brigadir kundalik ishlab chiqarish
- [x] Mahsulotni master data’dan tanlash
- [x] Tarixiy F/K, narx va normativlar
- [x] Sifat 3 raund va ±1 soat oynasi
- [x] 3/4 bahoda qayta tekshiruv
- [x] O‘tkazib yuborilgan raund sababini saqlash
- [x] Kun muammosi CRUD
- [x] Kun yopish / kech yopish / sabablar
- [x] Oldingi yopilmagan kun bugungi kiritishni bloklamaydi
- [x] Monitoring: tanlangan tur va brigada bo‘yicha Yil/Kvartal/Oy/Kun dinamik natijalari
- [x] Ishchilar monitoringida umumiy yakuniy natija %
- [x] Brigadir monitoringida 40/20/40 umumiy baho %
- [x] Sifat monitoringida 50/20/20/10 umumiy baho %
- [x] Muammoli mahsulotlarda davr bo‘yicha muammolar soni
- [x] DOCX Kun/Oy/Yil muammolar eksporti Monitoring ichida
- [x] Audit log
- [x] Offline lokal vaqtli eslatmalar
- [x] Device credential bilan lock/auth

## Keyingi integratsiya qatlami

- [ ] Firebase/markaziy backend
- [ ] Ko‘p qurilmali sync va conflict resolution
- [ ] Server-side brigade scope va individual permissions
- [ ] Rahbarlarga server/FCM holat bildirishnomalari
- [ ] Windows boshqaruv dasturi
- [ ] Final signed production release


## 0.7.1
- Monitoring "Barcha brigadalar" endi arxiv/deleted brigadalarni majburiy ma’lumot sifatida hisoblamaydi.
- Arxivdagi ishchisiz brigadani o‘chirish (UI dan yashirish, tarixiy nomni ichki saqlash) qo‘shildi.
- Ishchilar, Brigadirlar va Sifat nazoratchilari monitoringida joriy filtrga mos Word hisobot eksporti qo‘shildi.


## 0.7.2
- Asosiy ekranning chap drawer menyusiga doimiy “Bildirishnomalar” bo‘limi qo‘shildi.
- Yangi bildirishnomalar soni drawer ichida ko‘rsatiladi.
- Bildirishnomalar foydalanuvchi kodi bo‘yicha lokal inboxda saqlanadi.
- Bildirishnoma ustiga bosilganda tegishli Brigadir / Sifat / Monitoring / Kun muammosi ekraniga o‘tadi.
- “Barchasini o‘qildi qilish” mavjud; o‘qilgan bildirishnomalar launcher/system panelidan ham tozalanadi.
- Server bosqichida aynan shu inbox foydalanuvchi/brigada permissionlari bo‘yicha keladigan FCM xabarlar uchun ishlatiladi.


## 0.7.3
- Chap global sozlamalar drawer kontenti default 80% masshtabga tushirildi (oldingi ko‘rinishdan 20% kichik).
- Drawer ichida Menyu masshtabi: 70/80/90/100/110% tanlovi qo‘shildi va lokal saqlanadi.
- Server bosqichi uchun section-level read/write va brigade-scope permission modeli qo‘shildi.
- Hozir lokal testda barcha huquqlar ochiq; real enforcement Firestore Security Rules/backend bilan server bosqichida yoqiladi.
