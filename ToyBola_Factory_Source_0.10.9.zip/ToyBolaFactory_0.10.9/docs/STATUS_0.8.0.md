# ToyBola Factory — 0.8.0 server pilot status

## Tayyor

- Android Firebase konfiguratsiyasi (`google-services.json`)
- Firebase Auth custom-token client
- Cloud Functions custom login
- Firestore sync/outbox/pull
- Role + permission + brigade-scope modeli
- Firestore Security Rules
- FCM token registration va server notifications
- Scheduled deadline checks
- One-time local-data seed for Admin
- WIF GitHub deploy workflow
- Admin bootstrap + pilot user provisioning

## Server collectionlari

- `users/{uid}` + `devices/{installId}`
- `loginCodes/{sha256(userCode)}`
- `brigades`
- `workers`
- `products`
- `brigadeFk`
- `settings/assembly`
- `workerDays`
- `brigadeDays`
- `qualityRounds`
- `dailyIssues`
- `auditLog`

## Pilotdan oldin bir martalik

- `docs/SERVER_RUNTIME_SETUP.txt` blokini Cloud Shell'da bajarish.
- GitHub Secrets orqali Admin bootstrap.

## Pilot test

- Bosh Admin login
- 0.7.3 lokal ma’lumotlarning serverga seed bo‘lishi
- ikkinchi telefon/user provision
- brigada scope tekshiruvi
- ikki telefonda write/read sync
- internet o‘chib/qaytganda outbox sync
- Brigadir/Sifat field ownership
- FCM va lokal notification
- server disable / policy refresh

## Keyingi bosqich

Pilot barqaror bo‘lgach App Check + Play Integrity enforcement, markaziy kompyuter Admin UI va keyingi zavod modullari.
