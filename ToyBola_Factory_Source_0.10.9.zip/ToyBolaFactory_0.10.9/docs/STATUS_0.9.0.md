# ToyBola Factory — 0.9.0 status

## Kiritilgan o‘zgarishlar

1. **Kun muammosi sync tuzatishi**
   - Firestore `dailyIssues` pull ochiq UI'ga global data revision orqali yetib boradi.
   - `onDailyIssueWritten` data-only FCM signal yuboradi.
   - FCM signal WorkManager sync'ni ishga tushiradi.
   - Brigadir/Quality cached va server ma'lumotlari brigade scope bilan filtrlanadi.

2. **Universal sync UI**
   - Synced va pending yozuvlar soni.
   - Syncing / internet kutilmoqda / error holati.
   - Indikatorni bosib manual sync.
   - WorkManager `CONNECTED` constraint + unique `KEEP`: internet qaytganda pending ish davom etadi.

3. **Admin: foydalanuvchilar va ruxsatlar**
   - Android Admin drawer ichida yangi boshqaruv sahifasi.
   - Yaratish, tahrirlash, enable/disable, rol, brigada scope, granular permissions.
   - Server avtomatik User Code + Device Code yaratadi.
   - Device Code reset mavjud.
   - GitHub Secrets provision normal kundalik oqimdan chiqarildi; fallback sifatida qoldi.

4. **Permission navigation hardening**
   - Disabled card endi clickable emas.
   - `ToyBolaApp.push()` ichida permission guard.
   - Notification route ham permission bilan tekshiriladi.
   - Server policy o‘zgarsa, endi ruxsatsiz ochiq ekran HOME'ga qaytariladi.

5. **Admin day reopen**
   - Monitoring ichida to‘liq yopilgan kunni qayta ochish.
   - Sabab majburiy.
   - Lokal `DAY_REOPEN` audit.
   - Firestore `brigadeDays` yangilanadi va server data-change signali boshqa qurilmalarni sync qiladi.

## Moslik

- Firebase project: `toybola-factory`
- Android package: `uz.toybola.factory`
- Functions region: `europe-west1`
- 0.8.0 foydalanuvchi/login hujjatlari bilan backward-compatible.
- Yangi GitHub Secret talab qilinmaydi.

## Tekshiruv modeli

Mahalliy statik tekshiruvlar JSON/XML/YAML/Node/pure Kotlin darajasida bajariladi. To‘liq Android compiler, unit test, lint va APK build uchun GitHub Actions authoritative hisoblanadi.
