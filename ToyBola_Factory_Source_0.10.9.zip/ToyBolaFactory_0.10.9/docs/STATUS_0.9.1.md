# ToyBola Factory 0.9.1

Pilot hotfix / consolidated update.

## Tuzatilgan muammolar
1. Fresh install yoki ilova to‘liq o‘chirib qayta o‘rnatilganda Admin lokal bazasi bo‘sh qolib ketmasligi:
   - muvaffaqiyatli login ortidan foreground server sync;
   - fresh install default ma’lumotlari serverga seed qilinmaydi;
   - Admin brigade-scope kolleksiyalarni brigada bo‘yicha pull qiladi;
   - legacy audit xatosi bootstrapni to‘liq to‘xtatmaydi.
2. `dailyIssues` Admin qurilmasiga kelmasligi:
   - Admin barcha brigadalardagi ruxsatli yozuvlarni brigada scope bo‘yicha oladi;
   - ekran ochilishi va manual/auto sync server pullni ishga tushiradi.
3. Device Code reset:
   - server yangi hash bilan eski hashni almashtiradi;
   - login avval serverda tekshiriladi;
   - server `permission-denied` javobida eski lokal cache fallback ishlamaydi;
   - Admin o‘z Device Code'ini yangilasa lokal saqlangan kod ham yangi qiymatga o‘tadi.

## Yangi sifat raundi funksiyasi
Sifat baholash oynasida `Ishchi raundda yo‘q` tugmasi:
- `Sababli`: izoh majburiy, raund yakunlangan, worker quality average'ga kirmaydi.
- `Sababsiz`: raund yakunlangan va 0% sifat natijasi sifatida hisoblanadi.
- Ikkalasi ham sifat nazoratchining raundni o‘z vaqtida bajarganligi sifatida hisoblanadi.
- Holat audit log va Firebase sync payload ichida saqlanadi.

## Compatibility
0.9.0 ma’lumot formati backward-compatible: eski quality round hujjatlarida absence maydonlari bo‘lmasa bo‘sh qiymat sifatida o‘qiladi.
