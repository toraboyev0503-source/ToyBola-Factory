# ToyBola Factory 0.9.2

## Maqsad

Legacy lokal ma’lumotlarni bir marta xavfsiz Firebase serverga ko‘chirish va undan keyin barcha qurilmalarda fresh-install bootstrapni server asosida ishlatish.

## Pilotdan kelgan root cause

Admin fresh install qilganda `users` serverdan ko‘rindi, lekin brigada, ishchilar, mahsulot/narxlar va boshqa assembly ma’lumotlari ko‘rinmadi. Bu login muammosi emas: foydalanuvchilar serverda bor, lekin eski biznes datasetning muhim qismi ayrim telefonlarning lokal `SharedPreferences` datasetida qolgan va server kolleksiyalariga to‘liq seed qilinmagan.

## Recovery flow

- `AssemblyBackupRepository`: scope-limited JSON backup + SHA-256 checksum.
- `mergeAssemblyBackup`: Brigadir/Quality backup datasetlarini ID/key bo‘yicha union/merge qiladi.
- Admin import: merge → `AssemblySyncOutbox.markAll()` → `FirebaseSyncCoordinator.syncNow()`.
- Sync muvaffaqiyatsiz bo‘lsa outbox pending qoladi; import qilingan lokal dataset yo‘qolmaydi.
- `ServerMigrationState.recovery_in_progress` migration vaqtida remote-empty snapshot lokal legacy datasetni o‘chirib yubormasligi uchun himoya beradi.

## Saqlangan 0.9.1 fixes

- Admin `dailyIssues` brigade-scope pull.
- foreground bootstrap sync.
- Device Code resetdan keyin server-first validation.
- Quality worker absence: EXCUSED / UNEXCUSED.
- EXCUSED score=null; UNEXCUSED score=0.
- Worker absence inspector round completion sifatida hisoblanadi.

## Verification

Local checks:
- AssemblyModels + MonitoringMetrics + AssemblyBackupMerge pure Kotlin compile.
- Recovery merge smoke test.
- Quality absence average smoke test.
- JSON/XML/YAML parse.
- Node syntax check for Firebase Functions scripts.
- ZIP integrity.

Authoritative Android compile: GitHub Actions `./gradlew test`, `./gradlew lint`, `./gradlew assembleDebug`.
