# ToyBola Factory 0.9.3

## Root cause
0.9.2 Admin recovery merged lokal datasetni `AssemblySyncOutbox.markAll()` orqali oddiy Android Firestore client batch bilan serverga yozardi. Eski server hujjatlarining ayrimlari yangi immutable/scope maydonlariga mos bo‘lmagani sabab Firestore Rules butun batchni `PERMISSION_DENIED` bilan rad qilishi mumkin edi.

## Fix
- `adminRestoreAssemblyBackup` callable: active ADMIN tekshiruvi + SHA-256 + payload/ID/date validation.
- Firebase Admin SDK orqali normalized overwrite (client Rules bypass faqat recovery endpoint ichida).
- Server collections: brigades, workers, products, brigadeFk, settings/assembly, workerDays, brigadeDays, qualityRounds, dailyIssues, auditLog.
- Recovery log: serverRecoveryLog + SERVER_RECOVERY audit.
- Android: ServerRecoveryRepository; import/manual recovery endi direct client bulk-write qilmaydi.
- Successdan keyin outbox.clear() va server pull sync.

## Saqlangan pilot fixes
- Admin dailyIssues scope pull/refresh.
- Fresh-install bootstrap.
- Device Code server-first validation/reset.
- Quality EXCUSED/Sababli (score null, izoh majburiy) va UNEXCUSED/Sababsiz (score 0).
