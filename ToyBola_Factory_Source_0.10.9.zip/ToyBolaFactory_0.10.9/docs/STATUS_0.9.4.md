# ToyBola Factory 0.9.4

## Root cause
0.9.3 server-side recovery muvaffaqiyatli tugagan, lekin darhol keyingi Android `FirebaseSyncCoordinator.syncNow()` bevosita Firestore client read/query yo‘lidan ketib `PERMISSION_DENIED` olgan. Shu sabab ekranda “Serverga to‘liq yuklash yakunlandi. Qayta sinxronlash: PERMISSION_DENIED” ko‘ringan.

## Fix
- `getAssemblySnapshot` callable Cloud Function qo‘shildi.
- Server signed-in userni tekshiradi, role/permissions/brigade scope asosida faqat ruxsatli datasetni yig‘adi.
- Legacy Firestore qatorlar klient querysini yiqita olmaydi, chunki o‘qish Admin SDK bilan serverda bajariladi.
- Android `FirebaseSyncCoordinator` normal bootstrap/sync uchun shu server snapshotni authoritative source sifatida ishlatadi.
- Client writes va kundalik tahrirlar Firestore Security Rules bilan himoyalangan holda qoladi.

## Expected test
Recoverydan keyin sync xatosiz tugashi, Admin fresh install qilganda brigada/ishchi/mahsulot/narx/kunlik ma’lumot/sifat raundlari/Kun muammosi serverdan qaytishi kerak.
