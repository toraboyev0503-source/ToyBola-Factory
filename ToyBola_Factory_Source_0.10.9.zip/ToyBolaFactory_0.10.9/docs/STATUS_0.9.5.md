# ToyBola Factory 0.9.5

## Maqsad

Sborka bo‘limida mahsulot sonini `1.5` kabi qoldiqli qiymat bilan kiritish va butun qiymatlarni `.0` qo‘shimchasiz ko‘rsatish.

## O‘zgarishlar

- Yangi mahsulot yozishda son maydoni qoldiqli klaviaturani qabul qiladi.
- Kiritilgan sonni tahrirlash oynasi ham qoldiqli qiymatni qabul qiladi.
- Nuqta va vergul decimal ajratgich sifatida qabul qilinadi; ichki format nuqtaga normalizatsiya qilinadi.
- `5` qiymati ekranda `5`, `1.5` qiymati `1.5` ko‘rinadi.
- Mahsulot soni lokal JSON, server payload, snapshot va recovery yo‘lida qoldiqli ko‘rinishda saqlanadi.
- Eski butun sonli 0.9.4 ma’lumotlari orqaga mos ravishda o‘qiladi.
- Qoldiqli miqdor bo‘yicha pul eng yaqin butun so‘mga yaxlitlanadi; butun sonli eski hisob o‘zgarmaydi.

## O‘zgarmagan qismlar

- Sborka kunlik ish jarayoni, mahsulot tanlash va takroriy mahsulotni birlashtirish.
- Ish vaqti, F/K, foydalilik hisoblash formulasi, kunni yopish/qayta ochish.
- Sifat raundlari, Kun muammosi va Monitoring.
- Firebase ruxsatlari, server snapshot va oddiy sync oqimi.

## TP va Seryo talabi

Kelajakdagi TP/Seryo modulida ishchi davomadini kiritish va o‘zgartirish TP Plan beruvchiga tegishli bo‘ladi. Stanok ishchisi uchun alohida ilova bo‘limi hozircha yaratilmaydi. Bu talab 0.9.5 da yangi TP/Seryo modulini kodga qo‘shmaydi.
