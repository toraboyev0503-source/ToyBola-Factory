package uz.toybola.factory.core.firebase

import android.content.Context
import com.google.firebase.functions.FirebaseFunctions
import uz.toybola.factory.core.data.TpData
import uz.toybola.factory.core.data.TpDataRepository

data class ServerTpSnapshotResult(
    val data: TpData,
    val hasData: Boolean,
    val hasSettings: Boolean,
    val counts: Map<String, Int>
)

class ServerTpSnapshotRepository(context: Context) {
    private val repository = TpDataRepository(context.applicationContext)
    private val functions = FirebaseFunctions.getInstance("europe-west1")

    suspend fun download(): Result<ServerTpSnapshotResult> = runCatching {
        val response = functions.getHttpsCallable("getTpSnapshot")
            .call(mapOf("clientVersion" to "0.11.0"))
            .awaitResult()
        val root = response.data as? Map<*, *> ?: error("TP server snapshot javobi noto‘g‘ri")
        val payload = root["payload"]?.toString().orEmpty()
        require(payload.isNotBlank()) { "TP server snapshot bo‘sh" }
        require(payload.toByteArray(Charsets.UTF_8).size <= MAX_PAYLOAD_BYTES) { "TP server snapshot juda katta" }
        val counts = (root["counts"] as? Map<*, *>).orEmpty().mapNotNull { (key, value) ->
            key?.toString()?.let { it to ((value as? Number)?.toInt() ?: 0) }
        }.toMap()
        ServerTpSnapshotResult(
            data = repository.decodeForSync(payload),
            hasData = root["hasData"] == true,
            hasSettings = root["hasSettings"] == true,
            counts = counts
        )
    }

    companion object { private const val MAX_PAYLOAD_BYTES = 8 * 1024 * 1024 }
}
