package uz.toybola.factory.desktop

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import kotlinx.coroutines.launch

fun main() = application {
    val state = remember { DesktopAppState() }
    Window(
        onCloseRequest = ::exitApplication,
        title = "ToyBola Factory ${DesktopConfig.VERSION}"
    ) {
        MaterialTheme {
            ToyBolaDesktopApp(state)
        }
    }
}

@Composable
private fun ToyBolaDesktopApp(state: DesktopAppState) {
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        state.restoreSession()
        launch { state.autoSyncLoop() }
    }

    if (state.session == null) {
        LoginScreen(state)
        return
    }

    Row(Modifier.fillMaxSize()) {
        NavigationRail(
            modifier = Modifier.width(220.dp).fillMaxHeight(),
            header = {
                Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("ToyBola Factory", fontWeight = FontWeight.Bold)
                    Text("Windows ${DesktopConfig.VERSION}", style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(8.dp))
                }
            }
        ) {
            DesktopScreen.entries.filter(state::visible).forEach { item ->
                NavigationRailItem(
                    selected = state.screen == item,
                    onClick = { state.screen = item },
                    icon = { Text(item.title.take(2)) },
                    label = { Text(item.title, maxLines = 1) },
                    alwaysShowLabel = true
                )
            }
        }

        Column(Modifier.fillMaxSize()) {
            Surface(tonalElevation = 2.dp) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(state.screen.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    if (state.pending > 0) AssistChip(onClick = { state.screen = DesktopScreen.SYNC }, label = { Text("Pending ${state.pending}") })
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = { scope.launch { state.syncNow() } }, enabled = !state.syncing) {
                        Text(if (state.syncing) "Sync..." else "Sync")
                    }
                    Text(state.policy?.displayName.orEmpty(), style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.width(10.dp))
                    TextButton(onClick = state::logout) { Text("Chiqish") }
                }
            }
            if (state.error.isNotBlank()) {
                Surface(color = MaterialTheme.colorScheme.errorContainer) {
                    Text(state.error, Modifier.fillMaxWidth().padding(10.dp), color = MaterialTheme.colorScheme.onErrorContainer)
                }
            } else if (state.message.isNotBlank()) {
                Surface(color = MaterialTheme.colorScheme.secondaryContainer) {
                    Text(state.message, Modifier.fillMaxWidth().padding(8.dp), color = MaterialTheme.colorScheme.onSecondaryContainer)
                }
            }
            Box(Modifier.fillMaxSize().padding(16.dp)) {
                when (state.screen) {
                    DesktopScreen.HOME -> HomeScreen(state)
                    DesktopScreen.ASSEMBLY_BRIGADIR -> AssemblyBrigadirScreen(state)
                    DesktopScreen.ASSEMBLY_QUALITY -> AssemblyQualityScreen(state)
                    DesktopScreen.ASSEMBLY_ISSUES -> AssemblyIssuesScreen(state)
                    DesktopScreen.ASSEMBLY_MONITORING -> AssemblyMonitoringScreen(state)
                    DesktopScreen.ASSEMBLY_MASTER -> AssemblyMasterScreen(state)
                    DesktopScreen.TP_PLAN -> TpPlanScreen(state)
                    DesktopScreen.TP_SERYO -> TpSeryoScreen(state)
                    DesktopScreen.TP_RECEIVING -> TpReceivingScreen(state)
                    DesktopScreen.TP_QUALITY -> TpQualityScreen(state)
                    DesktopScreen.TP_MONITORING -> TpMonitoringScreen(state)
                    DesktopScreen.TP_MASTER -> TpMasterScreen(state)
                    DesktopScreen.USERS -> UserAdminScreen(state)
                    DesktopScreen.SYNC -> SyncScreen(state)
                }
            }
        }
    }
}

@Composable
private fun LoginScreen(state: DesktopAppState) {
    val scope = rememberCoroutineScope()
    var deviceCode by remember { mutableStateOf("") }
    var userCode by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Card(Modifier.width(440.dp)) {
            Column(Modifier.padding(28.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("ToyBola Factory", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Windows client • Android bilan bitta server")
                OutlinedTextField(deviceCode, { deviceCode = it.uppercase() }, label = { Text("Device Code") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(userCode, { userCode = it.uppercase() }, label = { Text("User Code") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(
                    onClick = { scope.launch { state.login(deviceCode, userCode) } },
                    enabled = !state.busy && deviceCode.isNotBlank() && userCode.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (state.busy) "Kirilmoqda..." else "Kirish") }
                if (state.error.isNotBlank()) Text(state.error, color = MaterialTheme.colorScheme.error)
                Text("Internet bo‘lmasa oxirgi muvaffaqiyatli sessiya va lokal ma’lumot bilan offline ishlash mumkin; yozuvlar keyin sync qilinadi.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
