@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package uz.toybola.factory.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import java.time.LocalDate

private data class SeryoDetailPick(
    val jobId: String?,
    val productId: String,
    val detailId: String,
    val colorCode: String,
    val label: String
)

private fun recentMachinePicks(data: TpData, machineId: String): List<SeryoDetailPick> {
    return data.jobs.asSequence()
        .filter { it.machineId == machineId }
        .sortedByDescending { it.startedAt ?: it.materialDeliveredAt ?: it.resinConfirmedAt ?: it.planConfirmedAt ?: "" }
        .flatMap { job ->
            val order = data.orders.firstOrNull { it.id == job.orderId }
            job.outputs.asSequence().map { output ->
                SeryoDetailPick(
                    jobId = job.id,
                    productId = order?.productId.orEmpty(),
                    detailId = output.detailId,
                    colorCode = job.colorCode,
                    label = "${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()} • ${output.detailName}"
                )
            }
        }
        .distinctBy { it.productId + "|" + it.detailId }
        .take(3)
        .toList()
}

private fun otherPick(data: TpData, productId: String, detailId: String, colorCode: String): SeryoDetailPick? {
    val product = data.products.firstOrNull { it.id == productId && !it.archived } ?: return null
    val detail = product.details.firstOrNull { it.id == detailId && !it.archived } ?: return null
    return SeryoDetailPick(null, product.id, detail.id, colorCode, "${product.article} • ${product.name} • ${detail.name}")
}

@Composable
fun TpSeryoDailyRoot(onOpenBreakage: () -> Unit, onOpenReturned: () -> Unit, onOpenCompensation: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Kundalik qabul qilish", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Ftarichka kirimi va brak o‘rniga beriladigan alohida zakazlar.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        SeryoNav("Brak qabul qilish", onOpenBreakage)
        SeryoNav("Qaytgan ftarichkani qabul qilish", onOpenReturned)
        SeryoNav("Brak o‘rniga beriladigan qorishma", onOpenCompensation)
    }
}

@Composable
fun TpBreakageReceivePage(data: TpData, repository: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var sourceMode by remember { mutableStateOf("MACHINE") }
    var showDialog by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var reverseTarget by remember { mutableStateOf<Pair<TpMaterial, TpMaterialMovement>?>(null) }
    val today = LocalDate.now().toString()
    val history = data.materials.filter { it.type == TpMaterialType.RECYCLED }.flatMap { material ->
        material.movements.filter { it.kind == TpMaterialMovementKind.IN && it.createdAt.startsWith(today) && it.sourceKind in setOf(TpMaterialSourceKind.BREAKAGE_MACHINE, TpMaterialSourceKind.BREAKAGE_AREA) }
            .map { material to it }
    }.sortedByDescending { it.second.createdAt }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Brak qabul qilish", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            listOf("MACHINE" to "Stanok", "OTHER" to "Boshqa").forEachIndexed { index, option ->
                SegmentedButton(sourceMode == option.first, { sourceMode = option.first }, SegmentedButtonDefaults.itemShape(index, 2)) { Text(option.second) }
            }
        }
        if (canWrite) Button(onClick = { showDialog = true }, Modifier.fillMaxWidth()) { Text("+ Brak qabul qilish") }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Text("Bugungi kirimlar", fontWeight = FontWeight.Bold)
        if (history.isEmpty()) Text("Bugun brak kirimi yo‘q.")
        history.forEach { (material, movement) -> SeryoMovementCard(data, material, movement, if (canWrite) ({ reverseTarget = material to movement }) else null) }
    }
    reverseTarget?.let { (material, movement) ->
        MovementReverseDialog(material, movement, onDismiss = { reverseTarget = null }) { reason ->
            val result = repository.reverseMaterialMovement(material.id, movement.id, reason)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { reverseTarget = null; refresh() }
        }
    }
    if (showDialog) {
        if (sourceMode == "MACHINE") {
            RecycledMachineReceiveDialog(data, title = "Brak qabul qilish", returned = false, onDismiss = { showDialog = false }) { code, kg, machineId, pick ->
                val result = repository.receiveRecycled(code, kg, TpMaterialSourceKind.BREAKAGE_MACHINE, machineId, productId = pick?.productId, detailId = pick?.detailId)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { refresh(); showDialog = false }
            }
        } else {
            RecycledAreaReceiveDialog(data, onDismiss = { showDialog = false }) { area, code, kg ->
                val result = repository.receiveRecycled(code, kg, TpMaterialSourceKind.BREAKAGE_AREA, sourceArea = area)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { refresh(); showDialog = false }
            }
        }
    }
}

@Composable
fun TpReturnedRecycledPage(data: TpData, repository: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var showDialog by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var reverseTarget by remember { mutableStateOf<Pair<TpMaterial, TpMaterialMovement>?>(null) }
    val today = LocalDate.now().toString()
    val history = data.materials.filter { it.type == TpMaterialType.RECYCLED }.flatMap { material ->
        material.movements.filter { it.kind == TpMaterialMovementKind.IN && it.createdAt.startsWith(today) && it.sourceKind == TpMaterialSourceKind.RETURNED_RECYCLED }
            .map { material to it }
    }.sortedByDescending { it.second.createdAt }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Qaytgan ftarichka", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        if (canWrite) Button(onClick = { showDialog = true }, Modifier.fillMaxWidth()) { Text("+ Qaytgan ftarichkani qabul qilish") }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (history.isEmpty()) Text("Bugun qaytgan ftarichka yozuvi yo‘q.")
        history.forEach { (material, movement) -> SeryoMovementCard(data, material, movement, if (canWrite) ({ reverseTarget = material to movement }) else null) }
    }
    reverseTarget?.let { (material, movement) ->
        MovementReverseDialog(material, movement, onDismiss = { reverseTarget = null }) { reason ->
            val result = repository.reverseMaterialMovement(material.id, movement.id, reason)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { reverseTarget = null; refresh() }
        }
    }
    if (showDialog) RecycledMachineReceiveDialog(data, title = "Qaytgan ftarichka", returned = true, onDismiss = { showDialog = false }) { code, kg, machineId, pick ->
        val result = repository.receiveRecycled(code, kg, TpMaterialSourceKind.RETURNED_RECYCLED, machineId, productId = pick?.productId, detailId = pick?.detailId)
        error = result.exceptionOrNull()?.message
        if (result.isSuccess) { refresh(); showDialog = false }
    }
}

@Composable
fun TpSeryoCompensationPage(data: TpData, repository: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var showDialog by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Brak o‘rniga qorishma", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Har bir yozuv bitta detal uchun mustaqil zakaz. Tayyorlovchi qisman-qisman berishi mumkin.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (canWrite) Button(onClick = { showDialog = true }, Modifier.fillMaxWidth()) { Text("+ Yangi zakaz") }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        data.seryoCompensations.sortedByDescending { it.createdAt }.forEach { comp ->
            val machine = data.machines.firstOrNull { it.id == comp.machineId }
            val shop = data.shops.firstOrNull { it.id == comp.shopId }
            SeryoCard {
                Text("${shop?.name.orEmpty()} • ${machine?.number ?: 0}-stanok", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("${comp.articleSnapshot} • ${comp.productNameSnapshot} • ${comp.detailNameSnapshot}")
                Text("Zakaz ${formatTpNumber(comp.targetKg)} kg • Berildi ${formatTpNumber(comp.deliveredKg())} kg • Qoldi ${formatTpNumber(comp.remainingKg())} kg")
                Text(if (comp.isComplete()) "✓ Yakunlandi" else "Tayyorlashni kutmoqda", color = if (comp.isComplete()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    if (showDialog) CompensationCreateDialog(data, onDismiss = { showDialog = false }) { machineId, pick, kg ->
        if (pick == null) {
            error = "Mahsulot va detalni tanlang"
        } else {
            val result = repository.createSeryoCompensation(machineId, pick.productId, pick.detailId, pick.colorCode, kg, pick.jobId)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { refresh(); showDialog = false }
        }
    }
}

@Composable
private fun RecycledMachineReceiveDialog(
    data: TpData,
    title: String,
    returned: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, Double, String, SeryoDetailPick?) -> Unit
) {
    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    var shopId by remember { mutableStateOf(shops.firstOrNull()?.id.orEmpty()) }
    val machines = data.machines.filter { !it.archived && (if (returned) it.shopId == shopId else true) }
        .sortedWith(compareBy<TpMachine> { shops.indexOfFirst { shop -> shop.id == it.shopId }.let { i -> if (i < 0) Int.MAX_VALUE else i } }.thenBy { it.number })
    var machineId by remember(shopId, returned) { mutableStateOf(machines.firstOrNull()?.id.orEmpty()) }
    val recents = remember(data, machineId) { recentMachinePicks(data, machineId) }
    var sourceIndex by remember(machineId) { mutableIntStateOf(0) }
    var otherProductId by remember { mutableStateOf("") }
    var otherDetailId by remember(otherProductId) { mutableStateOf("") }
    var otherColorCode by remember(otherDetailId) { mutableStateOf("") }
    val products = data.products.filterNot { it.archived }.sortedBy { it.article }
    val otherProduct = products.firstOrNull { it.id == otherProductId }
    val otherDetails = otherProduct?.details?.filterNot { it.archived }.orEmpty()
    val isOther = sourceIndex >= 3 || sourceIndex >= recents.size
    val pick = if (!isOther) recents.getOrNull(sourceIndex) else otherPick(data, otherProductId, otherDetailId, otherColorCode)
    val recycled = data.materials.filter { !it.archived && it.type == TpMaterialType.RECYCLED }
    var recycledCode by remember { mutableStateOf(recycled.firstOrNull()?.code.orEmpty()) }
    var amount by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("KG") }
    val kg = amount.replace(',', '.').toDoubleOrNull()?.let { if (unit == "G") it / 1000.0 else it }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (returned) {
                SeryoChoice("Sex", shopId, shops, { it.id }, { it.name }) { shopId = it }
            }
            SeryoChoice("Stanok", machineId, machines, { it.id }, { m ->
                val shop = data.shops.firstOrNull { it.id == m.shopId }?.name.orEmpty(); "$shop • ${m.number}-stanok"
            }) { machineId = it; sourceIndex = 0 }
            val sourceOptions = listOf(0 to "Hozir chiqayotgan", 1 to "Undan oldingi", 2 to "Undan ham oldingi", 3 to "Boshqa")
            SeryoChoice("Detal manbasi", sourceIndex.toString(), sourceOptions, { it.first.toString() }, { it.second }) { sourceIndex = it.toInt() }
            if (!isOther) {
                Text(pick?.label ?: "Bu stanok uchun oldingi detal topilmadi", style = MaterialTheme.typography.bodySmall)
            } else {
                SeryoChoice("Artikul / mahsulot", otherProductId, products, { it.id }, { "${it.article} • ${it.name}" }) { otherProductId = it; otherDetailId = ""; otherColorCode = "" }
                SeryoChoice("Detal", otherDetailId, otherDetails, { it.id }, { it.name }) { id ->
                    otherDetailId = id
                    otherColorCode = otherDetails.firstOrNull { it.id == id }?.colors?.firstOrNull()?.colorCode.orEmpty()
                }
            }
            SeryoChoice("Ftarichka turi", recycledCode, recycled, { it.code }, { "${it.code} • ostatka ${formatTpNumber(it.currentStock())} kg" }) { recycledCode = it }
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                listOf("KG" to "kg", "G" to "gram").forEachIndexed { index, item ->
                    SegmentedButton(unit == item.first, { unit = item.first }, SegmentedButtonDefaults.itemShape(index, 2)) { Text(item.second) }
                }
            }
            SeryoField(amount, { amount = decimalInputLocal(it) }, if (unit == "G") "Og‘irlik (gram)" else "Og‘irlik (kg)", KeyboardType.Decimal)
        } },
        confirmButton = { TextButton(onClick = { if (machineId.isNotBlank() && recycledCode.isNotBlank() && kg != null && kg > 0) onSave(recycledCode, kg, machineId, pick) }) { Text("Qabul qilish") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

@Composable
private fun RecycledAreaReceiveDialog(data: TpData, onDismiss: () -> Unit, onSave: (String, String, Double) -> Unit) {
    val areas = listOf("Xonadon", "Keles sborka", "Mikon sborka")
    var area by remember { mutableStateOf(areas.first()) }
    val recycled = data.materials.filter { !it.archived && it.type == TpMaterialType.RECYCLED }
    var code by remember { mutableStateOf(recycled.firstOrNull()?.code.orEmpty()) }
    var amount by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("KG") }
    val kg = amount.replace(',', '.').toDoubleOrNull()?.let { if (unit == "G") it / 1000.0 else it }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Brak qabul qilish — Boshqa") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SeryoChoice("Manba", area, areas, { it }, { it }) { area = it }
            SeryoChoice("Ftarichka turi", code, recycled, { it.code }, { "${it.code} • ostatka ${formatTpNumber(it.currentStock())} kg" }) { code = it }
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                listOf("KG" to "kg", "G" to "gram").forEachIndexed { index, item -> SegmentedButton(unit == item.first, { unit = item.first }, SegmentedButtonDefaults.itemShape(index, 2)) { Text(item.second) } }
            }
            SeryoField(amount, { amount = decimalInputLocal(it) }, if (unit == "G") "Og‘irlik (gram)" else "Og‘irlik (kg)", KeyboardType.Decimal)
        }
    }, confirmButton = { TextButton(onClick = { if (code.isNotBlank() && kg != null && kg > 0) onSave(area, code, kg) }) { Text("Qabul qilish") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } })
}

@Composable
private fun CompensationCreateDialog(data: TpData, onDismiss: () -> Unit, onSave: (String, SeryoDetailPick?, Double) -> Unit) {
    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    var shopId by remember { mutableStateOf(shops.firstOrNull()?.id.orEmpty()) }
    val machines = data.machines.filter { !it.archived && it.shopId == shopId }.sortedBy { it.number }
    var machineId by remember(shopId) { mutableStateOf(machines.firstOrNull()?.id.orEmpty()) }
    val recents = remember(data, machineId) { recentMachinePicks(data, machineId) }
    var sourceIndex by remember(machineId) { mutableIntStateOf(0) }
    val products = data.products.filterNot { it.archived }.sortedBy { it.article }
    var productId by remember { mutableStateOf("") }
    var detailId by remember(productId) { mutableStateOf("") }
    val product = products.firstOrNull { it.id == productId }
    val details = product?.details?.filterNot { it.archived }.orEmpty()
    var colorCode by remember(detailId) { mutableStateOf(details.firstOrNull { it.id == detailId }?.colors?.firstOrNull()?.colorCode.orEmpty()) }
    val detail = details.firstOrNull { it.id == detailId }
    val isOther = sourceIndex >= 3 || sourceIndex >= recents.size
    val pick = if (!isOther) recents.getOrNull(sourceIndex) else otherPick(data, productId, detailId, colorCode)
    var amount by remember { mutableStateOf("") }
    val kg = amount.replace(',', '.').toDoubleOrNull()
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Brak o‘rniga qorishma") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SeryoChoice("Sex", shopId, shops, { it.id }, { it.name }) { shopId = it }
            SeryoChoice("Stanok", machineId, machines, { it.id }, { "${it.number}-stanok" }) { machineId = it; sourceIndex = 0 }
            val sourceOptions = listOf(0 to "Hozir chiqayotgan", 1 to "Undan oldingi", 2 to "Undan ham oldingi", 3 to "Boshqa")
            SeryoChoice("Detal manbasi", sourceIndex.toString(), sourceOptions, { it.first.toString() }, { it.second }) { sourceIndex = it.toInt() }
            if (!isOther) Text(pick?.label ?: "Oldingi detal topilmadi") else {
                SeryoChoice("Artikul / mahsulot", productId, products, { it.id }, { "${it.article} • ${it.name}" }) { productId = it; detailId = "" }
                SeryoChoice("Detal", detailId, details, { it.id }, { it.name }) { detailId = it }
                if ((detail?.colors?.size ?: 0) > 1) SeryoChoice("Rang", colorCode, detail!!.colors, { it.colorCode }, { it.colorCode }) { colorCode = it }
            }
            SeryoField(amount, { amount = decimalInputLocal(it) }, "Beriladigan xomashyo (kg)", KeyboardType.Decimal)
        }
    }, confirmButton = { TextButton(onClick = { if (machineId.isNotBlank() && pick != null && kg != null && kg > 0) onSave(machineId, pick, kg) }) { Text("Zakaz berish") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } })
}

@Composable
fun TpMaterialPreparationV2Page(data: TpData, repository: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var selectedJobId by remember { mutableStateOf<String?>(null) }
    var selectedCompId by remember { mutableStateOf<String?>(null) }
    val today = LocalDate.now().toString()
    val jobs = data.jobs.filter { it.planConfirmedAt != null && it.resinConfirmedAt != null && it.status != TpJobStatus.COMPLETE && (it.remainingFeedstockKg() > 0.0 || it.materialDeliveredAt?.startsWith(today) == true) }
        .sortedWith(compareBy<TpPlanJob> { it.remainingFeedstockKg() <= 0.0 }.thenBy { it.resinConfirmedAt.orEmpty() }.thenBy { it.priority })
    val comps = data.seryoCompensations.filter { !it.isComplete() || it.completedAt?.startsWith(today) == true }.sortedWith(compareBy<TpSeryoCompensationOrder> { it.isComplete() }.thenBy { it.createdAt })

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Tayyorlash va yetkazish", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Har bir zakazni bo‘lib-bo‘lib chiqarish mumkin. Dastur berilgan jami kilogrammni va qoldiqni avtomatik nazorat qiladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        val openCount = jobs.count { it.remainingFeedstockKg() > 0.0 } + comps.count { !it.isComplete() }
        Text("Ochiq zakazlar: $openCount", fontWeight = FontWeight.Bold)
        jobs.forEach { job -> PreparationV2Card(data, job, onClick = { selectedJobId = job.id; selectedCompId = null }) }
        comps.forEach { comp -> CompensationPreparationCard(data, comp, onClick = { selectedCompId = comp.id; selectedJobId = null }) }
        if (jobs.isEmpty() && comps.isEmpty()) Text("Tayyorlanadigan qorishma yo‘q.")
    }
    selectedJobId?.let { id -> data.jobs.firstOrNull { it.id == id }?.let { job ->
        JobBatchDialog(data, job, repository, canWrite, onDismiss = { selectedJobId = null }, onSaved = refresh)
    } }
    selectedCompId?.let { id -> data.seryoCompensations.firstOrNull { it.id == id }?.let { comp ->
        CompensationBatchDialog(data, comp, repository, canWrite, onDismiss = { selectedCompId = null }, onSaved = refresh)
    } }
}

@Composable
private fun PreparationV2Card(data: TpData, job: TpPlanJob, onClick: () -> Unit) {
    val order = data.orders.firstOrNull { it.id == job.orderId }
    val machine = data.machines.firstOrNull { it.id == job.machineId }
    val shop = machine?.let { m -> data.shops.firstOrNull { it.id == m.shopId } }
    SeryoCard(Modifier.clickable(onClick = onClick)) {
        Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(10.dp)) {
            Text("Yetkazish: ${shop?.name.orEmpty()} • ${machine?.number ?: 0}-stanok", Modifier.fillMaxWidth().padding(8.dp), fontWeight = FontWeight.Bold)
        }
        Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.Bold)
        Text(job.outputs.joinToString { it.detailName })
        Text("${job.feedstockType.displayName()}: ${job.resinCode} • Krasitel: ${job.colorCode}")
        Text("Zakaz ${formatTpNumber(job.totalResinKg)} kg • Berildi ${formatTpNumber(job.deliveredFeedstockKg())} kg • Qoldi ${formatTpNumber(job.remainingFeedstockKg())} kg", fontWeight = FontWeight.SemiBold)
        if (job.remainingFeedstockKg() <= 0.0) Text("✓ To‘liq yetkazildi", color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun CompensationPreparationCard(data: TpData, comp: TpSeryoCompensationOrder, onClick: () -> Unit) {
    val machine = data.machines.firstOrNull { it.id == comp.machineId }
    val shop = data.shops.firstOrNull { it.id == comp.shopId }
    SeryoCard(Modifier.clickable(onClick = onClick)) {
        Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(10.dp)) {
            Text("Brak o‘rniga • ${shop?.name.orEmpty()} • ${machine?.number ?: 0}-stanok", Modifier.fillMaxWidth().padding(8.dp), fontWeight = FontWeight.Bold)
        }
        Text("${comp.articleSnapshot} • ${comp.productNameSnapshot} • ${comp.detailNameSnapshot}", fontWeight = FontWeight.Bold)
        Text("Zakaz ${formatTpNumber(comp.targetKg)} kg • Berildi ${formatTpNumber(comp.deliveredKg())} kg • Qoldi ${formatTpNumber(comp.remainingKg())} kg")
        if (comp.isComplete()) Text("✓ To‘liq yetkazildi", color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun JobBatchDialog(data: TpData, job: TpPlanJob, repository: TpDataRepository, canWrite: Boolean, onDismiss: () -> Unit, onSaved: () -> Unit) {
    val order = data.orders.firstOrNull { it.id == job.orderId }
    val machine = data.machines.firstOrNull { it.id == job.machineId }
    val shop = machine?.let { data.shops.firstOrNull { s -> s.id == it.shopId } }
    var adding by remember { mutableStateOf(false) }
    var type by remember { mutableStateOf(job.feedstockType) }
    val resins = resinOptionsForJobV2(data, job)
    val recycled = recycledOptionsForJobV2(data, job)
    var code by remember(type) { mutableStateOf(if (type == job.feedstockType) job.resinCode else if (type == TpMaterialType.RESIN) resins.firstOrNull().orEmpty() else recycled.firstOrNull().orEmpty()) }
    var amount by remember { mutableStateOf("") }
    var recycledColor by remember { mutableStateOf("0") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(order?.productNameSnapshot ?: "Qorishma") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(10.dp)) { Text("Yetkazish: ${shop?.name.orEmpty()} • ${machine?.number ?: 0}-stanok", Modifier.fillMaxWidth().padding(9.dp), fontWeight = FontWeight.Bold) }
            Text(job.outputs.joinToString { it.detailName }, fontWeight = FontWeight.Bold)
            Text("Zakaz: ${formatTpNumber(job.totalResinKg)} kg • Berildi: ${formatTpNumber(job.deliveredFeedstockKg())} kg • Qoldi: ${formatTpNumber(job.remainingFeedstockKg())} kg")
            if (canWrite && job.remainingFeedstockKg() > 0.0) Button(onClick = { adding = !adding }, Modifier.fillMaxWidth()) { Text(if (adding) "− Yopish" else "+ Yangi berish") }
            if (adding) {
                val types = buildList { add(TpMaterialType.RESIN); if (recycled.isNotEmpty()) add(TpMaterialType.RECYCLED) }
                if (types.size > 1) SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    types.forEachIndexed { index, item -> SegmentedButton(type == item, { type = item }, SegmentedButtonDefaults.itemShape(index, types.size)) { Text(item.displayName()) } }
                }
                val options = if (type == TpMaterialType.RESIN) resins else recycled
                SeryoChoice(type.displayName(), code, options, { it }, { c -> "$c • ostatka ${formatTpNumber(data.materialStock(type, c))} kg" }) { code = it }
                Text("Krasitel: ${job.colorCode}${if (type == TpMaterialType.RECYCLED) " • odatda 0 g" else " • avtomatik nisbatda"}")
                if (type == TpMaterialType.RECYCLED) SeryoField(recycledColor, { recycledColor = decimalInputLocal(it) }, "Krasitel (g) — ixtiyoriy", KeyboardType.Decimal)
                SeryoField(amount, { amount = decimalInputLocal(it) }, "Beriladigan miqdor (kg)", KeyboardType.Decimal)
                Button(onClick = {
                    val kg = amount.replace(',', '.').toDoubleOrNull()
                    val grams = recycledColor.replace(',', '.').toDoubleOrNull() ?: 0.0
                    if (kg == null || kg <= 0) error = "Kilogrammni kiriting" else {
                        val result = repository.addJobMaterialBatch(job.id, type, code, kg, grams)
                        error = result.exceptionOrNull()?.message
                        if (result.isSuccess) { amount = ""; recycledColor = "0"; adding = false; onSaved() }
                    }
                }, Modifier.fillMaxWidth()) { Text("Berishni saqlash") }
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Text("Berilgan partiyalar", fontWeight = FontWeight.Bold)
            if (job.materialBatches.isEmpty()) Text("Hali berilmagan.")
            job.materialBatches.sortedByDescending { it.createdAt }.forEach { BatchRow(it) }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Yopish") } })
}

@Composable
private fun CompensationBatchDialog(data: TpData, comp: TpSeryoCompensationOrder, repository: TpDataRepository, canWrite: Boolean, onDismiss: () -> Unit, onSaved: () -> Unit) {
    val detail = data.products.asSequence().flatMap { it.details.asSequence() }.firstOrNull { it.id == comp.detailId }
    val machine = data.machines.firstOrNull { it.id == comp.machineId }
    val shop = data.shops.firstOrNull { it.id == comp.shopId }
    val resins = ((detail?.resinOptions().orEmpty()) + data.allResinCodes()).distinct()
    val recycledAllowed = detail?.recycledOptions().orEmpty().map { it.uppercase() }.toSet()
    val recycled = data.materials.filter { !it.archived && it.type == TpMaterialType.RECYCLED && it.code.uppercase() in recycledAllowed }.map { it.code }.distinct()
    var adding by remember { mutableStateOf(false) }
    var type by remember { mutableStateOf(comp.defaultFeedstockType) }
    var code by remember(type) { mutableStateOf(if (type == comp.defaultFeedstockType) comp.defaultFeedstockCode else if (type == TpMaterialType.RESIN) resins.firstOrNull().orEmpty() else recycled.firstOrNull().orEmpty()) }
    var amount by remember { mutableStateOf("") }
    var recycledColor by remember { mutableStateOf("0") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Brak o‘rniga • ${comp.detailNameSnapshot}") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(10.dp)) { Text("Yetkazish: ${shop?.name.orEmpty()} • ${machine?.number ?: 0}-stanok", Modifier.fillMaxWidth().padding(9.dp), fontWeight = FontWeight.Bold) }
            Text("Zakaz: ${formatTpNumber(comp.targetKg)} kg • Berildi: ${formatTpNumber(comp.deliveredKg())} kg • Qoldi: ${formatTpNumber(comp.remainingKg())} kg")
            if (canWrite && !comp.isComplete()) Button(onClick = { adding = !adding }, Modifier.fillMaxWidth()) { Text(if (adding) "− Yopish" else "+ Yangi berish") }
            if (adding) {
                val types = buildList { add(TpMaterialType.RESIN); if (recycled.isNotEmpty()) add(TpMaterialType.RECYCLED) }
                if (types.size > 1) SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) { types.forEachIndexed { index, item -> SegmentedButton(type == item, { type = item }, SegmentedButtonDefaults.itemShape(index, types.size)) { Text(item.displayName()) } } }
                val options = if (type == TpMaterialType.RESIN) resins else recycled
                SeryoChoice(type.displayName(), code, options, { it }, { c -> "$c • ostatka ${formatTpNumber(data.materialStock(type, c))} kg" }) { code = it }
                Text("Krasitel: ${comp.colorCode}${if (type == TpMaterialType.RECYCLED) " • odatda 0 g" else " • avtomatik nisbatda"}")
                if (type == TpMaterialType.RECYCLED) SeryoField(recycledColor, { recycledColor = decimalInputLocal(it) }, "Krasitel (g) — ixtiyoriy", KeyboardType.Decimal)
                SeryoField(amount, { amount = decimalInputLocal(it) }, "Beriladigan miqdor (kg)", KeyboardType.Decimal)
                Button(onClick = {
                    val kg = amount.replace(',', '.').toDoubleOrNull(); val grams = recycledColor.replace(',', '.').toDoubleOrNull() ?: 0.0
                    if (kg == null || kg <= 0) error = "Kilogrammni kiriting" else {
                        val result = repository.addCompensationMaterialBatch(comp.id, type, code, kg, grams)
                        error = result.exceptionOrNull()?.message
                        if (result.isSuccess) { amount = ""; recycledColor = "0"; adding = false; onSaved() }
                    }
                }, Modifier.fillMaxWidth()) { Text("Berishni saqlash") }
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Text("Berilgan partiyalar", fontWeight = FontWeight.Bold)
            if (comp.batches.isEmpty()) Text("Hali berilmagan.")
            comp.batches.sortedByDescending { it.createdAt }.forEach { BatchRow(it) }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Yopish") } })
}

private fun resinOptionsForJobV2(data: TpData, job: TpPlanJob): List<String> {
    val sets = job.outputs.mapNotNull { output ->
        data.products.asSequence().flatMap { it.details.asSequence() }.firstOrNull { it.id == output.detailId }?.resinOptions()?.map { it.uppercase() }?.toSet()
    }
    val preferred = if (sets.isEmpty()) emptySet() else sets.drop(1).fold(sets.first()) { acc, set -> acc intersect set }
    val master = data.materials.filter { !it.archived && it.type == TpMaterialType.RESIN }.map { it.code }
    return (master.filter { it.uppercase() in preferred } + master.filter { it.uppercase() !in preferred } + listOfNotNull(job.resinCode.takeIf { it.isNotBlank() })).distinct()
}
private fun recycledOptionsForJobV2(data: TpData, job: TpPlanJob): List<String> {
    val sets = job.outputs.mapNotNull { output ->
        data.products.asSequence().flatMap { it.details.asSequence() }.firstOrNull { it.id == output.detailId }?.recycledOptions()?.map { it.uppercase() }?.toSet()
    }
    if (sets.isEmpty()) return emptyList()
    val allowed = sets.drop(1).fold(sets.first()) { acc, set -> acc intersect set }
    return data.materials.filter { !it.archived && it.type == TpMaterialType.RECYCLED && it.code.uppercase() in allowed }.map { it.code }.distinct()
}

@Composable
private fun BatchRow(batch: TpMaterialBatch) {
    Surface(shape = RoundedCornerShape(10.dp), tonalElevation = 1.dp) {
        Column(Modifier.fillMaxWidth().padding(8.dp)) {
            Text("${batch.feedstockType.displayName()} ${batch.feedstockCode} • ${formatTpNumber(batch.feedstockKg)} kg", fontWeight = FontWeight.SemiBold)
            Text("Krasitel: ${if (batch.colorGrams > 0.0) "${batch.colorCode} • ${formatTpNumber(batch.colorGrams)} g" else "0 g"}", style = MaterialTheme.typography.bodySmall)
            Text(batch.createdAt.take(16).replace('T', ' '), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SeryoMovementCard(data: TpData, material: TpMaterial, movement: TpMaterialMovement, onReverse: (() -> Unit)? = null) {
    val machine = movement.sourceMachineId?.let { id -> data.machines.firstOrNull { it.id == id } }
    val shop = movement.sourceShopId?.let { id -> data.shops.firstOrNull { it.id == id } }
    val reversed = material.movements.any { it.note.contains("REV:${movement.id}") }
    SeryoCard {
        Text("${material.code} • +${formatTpNumber(movement.amount)} kg", fontWeight = FontWeight.Bold)
        val source = when {
            movement.sourceArea.isNotBlank() -> movement.sourceArea
            machine != null -> "${shop?.name.orEmpty()} • ${machine.number}-stanok"
            else -> "—"
        }
        Text(source)
        if (movement.productNameSnapshot.isNotBlank()) Text("${movement.articleSnapshot} • ${movement.productNameSnapshot} • ${movement.detailNameSnapshot}", style = MaterialTheme.typography.bodySmall)
        Text(movement.createdAt.take(16).replace('T', ' '), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (reversed) Text("↩ Bekor qilingan / teskari yozuv kiritilgan", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        else if (onReverse != null) TextButton(onClick = onReverse) { Text("Tuzatish / bekor qilish") }
    }
}

@Composable
private fun MovementReverseDialog(material: TpMaterial, movement: TpMaterialMovement, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var reason by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Kirimni bekor qilish") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${material.code} • ${formatTpNumber(movement.amount)} ${material.type.unitLabel()} • ${movement.createdAt.take(16).replace('T', ' ')}")
                Text("Asl yozuv o‘chirilmaydi. Ostatkani qaytaruvchi teskari tranzaksiya yoziladi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                SeryoField(reason, { reason = it }, "Sabab")
            }
        },
        confirmButton = { TextButton(onClick = { if (reason.trim().length >= 3) onConfirm(reason) }) { Text("Tasdiqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") }
        }
    )
}

@Composable
private fun SeryoNav(title: String, onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(14.dp), tonalElevation = 1.dp) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold); Text("›") }
    }
}

@Composable
private fun SeryoCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), tonalElevation = 1.dp) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp), content = content)
    }
}

@Composable
private fun <T> SeryoChoice(label: String, selectedId: String, options: List<T>, id: (T) -> String, text: (T) -> String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val selected = options.firstOrNull { id(it) == selectedId }
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Box(Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { expanded = true }, Modifier.fillMaxWidth()) { Text(selected?.let(text) ?: "Tanlang", Modifier.weight(1f)); Text("▾") }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { item -> DropdownMenuItem(text = { Text(text(item)) }, onClick = { onSelect(id(item)); expanded = false }) }
            }
        }
    }
}

@Composable
private fun SeryoField(value: String, onValue: (String) -> Unit, label: String, keyboardType: KeyboardType = KeyboardType.Text) {
    OutlinedTextField(value, onValue, Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true,
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = keyboardType))
}

private fun decimalInputLocal(value: String): String = value.filter { it.isDigit() || it == '.' || it == ',' }.replace(',', '.')
