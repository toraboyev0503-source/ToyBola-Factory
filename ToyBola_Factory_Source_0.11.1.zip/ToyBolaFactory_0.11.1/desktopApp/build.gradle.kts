import org.jetbrains.compose.desktop.application.dsl.TargetFormat

plugins {
    id("org.jetbrains.kotlin.jvm")
    id("org.jetbrains.compose")
    id("org.jetbrains.kotlin.plugin.compose")
}

group = "uz.toybola.factory"
version = "0.11.1"

kotlin {
    jvmToolchain(17)
}

dependencies {
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    implementation("org.json:json:20250517")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.10.2")
    testImplementation(kotlin("test-junit5"))
}

compose.desktop {
    application {
        mainClass = "uz.toybola.factory.desktop.MainKt"
        nativeDistributions {
            // Windows pilot 0.11.1: bundle the complete Java module set.
            // This avoids a trimmed runtime missing a module that is loaded at startup/reflection time.
            includeAllModules = true
            targetFormats(TargetFormat.Msi, TargetFormat.Exe)
            packageName = "ToyBolaFactory"
            packageVersion = "0.11.1"
            description = "ToyBola Factory production monitoring and TP/Seryo desktop client"
            vendor = "ToyBola"
            windows {
                menuGroup = "ToyBola"
                upgradeUuid = "9F5D07CA-3DB4-4E6B-96F4-6E7D15C6B110"
            }
        }
    }
}

tasks.test {
    useJUnitPlatform()
}
