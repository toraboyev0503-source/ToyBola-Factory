package uz.toybola.factory.ui.model

class AppStrings(private val language: AppLanguage) {
    private fun value(uz: String, ru: String, en: String): String = when (language) {
        AppLanguage.UZ -> uz
        AppLanguage.RU -> ru
        AppLanguage.EN -> en
    }

    val appName = "TOY BOLA"
    val systemName = value("Zavod boshqaruv tizimi", "Система управления заводом", "Factory management system")
    val loading = value("Yuklanmoqda...", "Загрузка...", "Loading...")
    val firstSetup = value("Qurilmani sozlash", "Настройка устройства", "Device setup")
    val deviceCode = value("Qurilma kodi", "Код устройства", "Device code")
    val userCode = value("Foydalanuvchi kodi", "Код пользователя", "User code")
    val save = value("Saqlash", "Сохранить", "Save")
    val cancel = value("Bekor qilish", "Отмена", "Cancel")
    val close = value("Yopish", "Закрыть", "Close")
    val edit = value("Tahrirlash", "Изменить", "Edit")
    val change = value("O‘zgartirish", "Изменить", "Change")
    val login = value("Kirish", "Войти", "Sign in")
    val wrongCodes = value("Qurilma yoki foydalanuvchi kodi noto‘g‘ri", "Неверный код устройства или пользователя", "Invalid device or user code")
    val setupHint = value(
        "Qurilma va foydalanuvchi kodini kiriting. So‘ng telefon qulfi bilan tasdiqlang.",
        "Введите код устройства и пользователя, затем подтвердите блокировкой телефона.",
        "Enter the device and user codes, then confirm with the phone lock."
    )
    val loginHint = value(
        "Kodlarni tekshiring va telefon qulfi bilan tasdiqlang.",
        "Проверьте коды и подтвердите блокировкой телефона.",
        "Verify the codes and confirm with the phone lock."
    )
    val required = value("Barcha zarur maydonlarni to‘ldiring", "Заполните обязательные поля", "Complete all required fields")
    val confirmWithPhoneLock = value("Telefon qulfi bilan tasdiqlash", "Подтвердить блокировкой телефона", "Confirm with phone lock")
    val confirmPhoneLock = value("Toy Bola — tasdiqlash", "Toy Bola — подтверждение", "Toy Bola — confirmation")
    val confirmPhoneLockDesc = value("Telefon PIN/parol/patterni bilan tasdiqlang", "Подтвердите PIN/паролем/графическим ключом телефона", "Confirm using the phone PIN/password/pattern")
    val phoneLockFailed = value("Telefon qulfi tasdiqlanmadi", "Блокировка телефона не подтверждена", "Phone lock was not confirmed")
    val phoneLockNotSet = value("Telefonda ekran qulfi o‘rnatilmagan. Avval PIN/parol/pattern o‘rnating.", "На телефоне не настроена блокировка экрана. Сначала задайте PIN/пароль/ключ.", "No secure screen lock is configured. Set a PIN/password/pattern first.")
    val phoneLockUnavailable = value("Telefon qulfi oynasini ochib bo‘lmadi", "Не удалось открыть проверку блокировки", "Could not open phone lock verification")

    val menu = value("Sozlamalar", "Настройки", "Settings")
    val notifications = value("Bildirishnomalar", "Уведомления", "Notifications")
    val noNotifications = value("Hozircha bildirishnoma yo‘q", "Уведомлений пока нет", "No notifications yet")
    val markAllRead = value("Barchasini o‘qildi qilish", "Отметить все прочитанными", "Mark all as read")
    val newLabel = value("Yangi", "Новое", "New")
    val theme = value("Tema", "Тема", "Theme")
    val languageTitle = value("Til", "Язык", "Language")
    val darkMode = value("Tun rejimi", "Тёмный режим", "Dark mode")
    val autoLock = value("Avtomatik bloklash", "Автоблокировка", "Auto lock")
    val drawerScale = value("Menyu masshtabi", "Масштаб меню", "Menu scale")
    val accessDenied = value("Bu bo‘limga ruxsat yo‘q", "Нет доступа к этому разделу", "You do not have access to this section")
    val userManagement = value("Foydalanuvchilar va ruxsatlar", "Пользователи и доступы", "Users & permissions")
    val manage = value("Boshqarish", "Управлять", "Manage")
    val addUser = value("Foydalanuvchi qo‘shish", "Добавить пользователя", "Add user")
    val editUser = value("Foydalanuvchini tahrirlash", "Изменить пользователя", "Edit user")
    val role = value("Rol", "Роль", "Role")
    val enabled = value("Faol", "Активен", "Enabled")
    val disabled = value("O‘chirilgan", "Отключён", "Disabled")
    val permissions = value("Ruxsatlar", "Разрешения", "Permissions")
    val readAccess = value("Ko‘rish", "Просмотр", "Read")
    val writeAccess = value("Yozish", "Запись", "Write")
    val allBrigadesAccess = value("Barcha brigadalarga ruxsat", "Доступ ко всем бригадам", "Access to all brigades")
    val generatedCodes = value("Yangi kirish kodlari", "Новые коды входа", "New login codes")
    val generatedCodesHelp = value("Qurilma kodi faqat hozir ko‘rsatiladi. Ikkala kodni foydalanuvchiga xavfsiz tarzda yuboring.", "Код устройства показывается только сейчас. Безопасно передайте пользователю оба кода.", "The device code is shown only now. Share both codes with the user securely.")
    val resetDeviceCode = value("Qurilma kodini yangilash", "Сбросить код устройства", "Reset device code")
    val refresh = value("Yangilash", "Обновить", "Refresh")
    val yes = value("Ha", "Да", "Yes")
    val total = value("Jami", "Всего", "Total")
    val backupRestore = value("Zaxira va server tiklash", "Резерв и восстановление сервера", "Backup & server recovery")
    val backupRestoreHelp = value(
        "Eski lokal ma’lumotni xavfsiz backup qiling. Server migratsiyasida Brigadir/Sifat telefonidan eksport qilingan backup Admin telefonida import qilinib serverga yuboriladi.",
        "Сохраните старые локальные данные в резервную копию. Для миграции экспорт с телефона бригадира/контролёра импортируется на телефоне администратора и отправляется на сервер.",
        "Safely back up legacy local data. During migration, a backup exported from a Brigadier/Quality phone is imported on the Admin phone and uploaded to the server."
    )
    val localData = value("Telefondagi lokal ma’lumot", "Локальные данные на телефоне", "Local data on this phone")
    val exportLocalBackup = value("Lokal backup chiqarish", "Экспорт локальной копии", "Export local backup")
    val backupExported = value("Backup fayli saqlandi", "Резервная копия сохранена", "Backup file saved")
    val backupFailed = value("Backup amali bajarilmadi", "Операция резервной копии не выполнена", "Backup operation failed")
    val adminRecovery = value("Admin: serverni tiklash", "Админ: восстановление сервера", "Admin: server recovery")
    val adminRecoveryHelp = value(
        "Brigadir va Sifat telefonlaridan olingan backup fayllarini ketma-ket import qilish mumkin. Ma’lumotlar birlashtiriladi va har importdan keyin serverga to‘liq yuboriladi.",
        "Можно последовательно импортировать копии с телефонов бригадира и контроля качества. Данные объединяются и после каждого импорта полностью отправляются на сервер.",
        "You can import Brigadier and Quality backups one after another. Data is merged and fully uploaded to the server after each import."
    )
    val importBackupToServer = value("Backupni import qilib serverga yuborish", "Импортировать копию и отправить на сервер", "Import backup and upload to server")
    val uploadAllLocalToServer = value("Barcha lokal ma’lumotni serverga yuborish", "Отправить все локальные данные на сервер", "Upload all local data to server")
    val uploadAllConfirm = value(
        "Telefondagi barcha ToyBola ish ma’lumoti serverga qayta yoziladi. Bu faqat tiklash/migratsiya uchun ishlatiladi. Davom etasizmi?",
        "Все рабочие данные ToyBola с телефона будут повторно записаны на сервер. Используйте только для восстановления/миграции. Продолжить?",
        "All ToyBola business data on this phone will be written to the server again. Use this only for recovery/migration. Continue?"
    )
    val backupImportedAndUploaded = value("Backup birlashtirildi va serverga yuborildi", "Копия объединена и отправлена на сервер", "Backup merged and uploaded to server")
    val backupImportedPending = value("Backup birlashtirildi, lekin serverga yuborish navbatda qoldi", "Копия объединена, но отправка на сервер осталась в очереди", "Backup merged, but server upload remains pending")
    val serverUploadComplete = value("Serverga to‘liq yuklash yakunlandi", "Полная загрузка на сервер завершена", "Full server upload completed")
    val serverUploadPending = value("Serverga yuklash yakunlanmadi, ma’lumot navbatda saqlandi", "Загрузка на сервер не завершена, данные сохранены в очереди", "Server upload did not finish; data remains queued")
    val syncedShort = value("Sync", "Синх.", "Synced")
    val pendingShort = value("Navbat", "Очередь", "Pending")
    val syncing = value("Sinxronlanmoqda", "Синхронизация", "Syncing")
    val waitingNetwork = value("Internet kutilmoqda", "Ожидание интернета", "Waiting for network")
    val minutes = value("daqiqa", "мин", "min")
    val logout = value("Qulflash", "Заблокировать", "Lock")
    val notLaunched = value("Bu bo‘lim hali ishga tushirilmagan", "Раздел ещё не запущен", "This section is not active yet")
    val back = value("Orqaga", "Назад", "Back")

    val molding = value("Seryo", "Сырьё", "Raw materials")
    val moldingDesc = value("Xomashyo, ftarichka va ostatka", "Сырьё, вторичка и остатки", "Raw materials, regrind and stock")
    val tp = value("TP", "ТП", "TP")
    val tpDesc = value("Zakaz, reja, stanok, qabul va sifat", "Заказы, план, станки, приём и качество", "Orders, planning, machines, receiving and quality")
    val ytmWarehouse = value("YTM sklad", "Склад YTM", "YTM warehouse")
    val ytmWarehouseDesc = value("Quyilgan detallar ombori", "Склад отлитых деталей", "Warehouse for molded parts")
    val sparePartsWarehouse = value("Zapchast sklad", "Склад запчастей", "Spare parts warehouse")
    val sparePartsWarehouseDesc = value("Yig‘ish uchun boshqa detallar ombori", "Склад дополнительных деталей для сборки", "Warehouse for additional assembly parts")
    val assemblyAndHome = value("Sborka va Xonadon", "Сборка и надомники", "Assembly and home work")
    val assemblyAndHomeDesc = value("Sex va xonadon yig‘ish jarayonlari", "Сборка в цехе и у надомников", "Workshop and home assembly processes")
    val finishedGoods = value("TM va EXP sklad", "Склад TM и EXP", "TM & EXP warehouse")
    val finishedGoodsDesc = value("Tayyor mahsulot va yuklash", "Готовая продукция и отгрузка", "Finished goods and shipping")
    val managementControl = value("Rahbariyat nazorati", "Контроль руководства", "Management control")
    val managementControlDesc = value("Zavod bo‘limlari bo‘yicha nazorat", "Контроль по подразделениям завода", "Factory-wide department monitoring")
    val globalMasterData = value("Ma’lumotlar", "Данные", "Master data")
    val globalMasterDataDesc = value("Zavod bo‘yicha asosiy ma’lumotlar", "Основные данные по заводу", "Factory-wide master data")

    val assembly = value("Sborka", "Сборка", "Assembly")
    val homeWork = value("Xonadon", "Надомники", "Home work")
    val homeWorkDesc = value("Xonadonlarda yig‘iladigan mahsulotlar", "Продукция, собираемая надомниками", "Products assembled by home workers")
    val assemblyDesc = value("Sexdagi sborka jarayonini boshqarish", "Управление сборкой в цехе", "Manage workshop assembly")
    val brigadir = value("Brigadir", "Бригадир", "Brigadier")
    val brigadirDesc = value("Ishchilar va kunlik ishlab chiqarish", "Работники и дневное производство", "Workers and daily production")
    val quality = value("Sifat", "Качество", "Quality")
    val qualityDesc = value("3 raundli sifat nazorati", "Контроль качества в 3 раунда", "Three-round quality control")
    val workerUnavailable = value("Ishchi raundda yo‘q", "Работник отсутствует на раунде", "Worker absent for round")
    val excused = value("Sababli", "По уважительной причине", "Excused")
    val unexcused = value("Sababsiz", "Без уважительной причины", "Unexcused")
    val absenceChoiceHelp = value(
        "Sababli — sifat o‘rtachasiga ta’sir qilmaydi. Sababsiz — ushbu raund 0% hisoblanadi.",
        "Уважительная причина не влияет на среднюю оценку качества. Без уважительной причины этот раунд считается как 0%.",
        "Excused absence does not affect the quality average. Unexcused absence counts as 0% for this round."
    )
    val excusedReasonRequired = value(
        "Sababli holatda izoh majburiy.",
        "При уважительной причине комментарий обязателен.",
        "A note is required for an excused absence."
    )
    val dailyIssue = value("Kun muammosi", "Проблемы дня", "Daily issues")
    val dailyIssueDesc = value("Mahsulot va yig‘uv bosqichi muammolari", "Проблемы изделий и этапов сборки", "Product and assembly-stage issues")
    val monitoring = value("Monitoring", "Мониторинг", "Monitoring")
    val monitoringDesc = value("Natijalar va nazorat", "Результаты и контроль", "Results and oversight")
    val masterData = value("Ma’lumot", "Данные", "Data")
    val masterDataDesc = value("Sborkaga tegishli ma’lumotlar", "Данные, относящиеся к сборке", "Assembly-specific master data")

    val brandTheme = value("Toy Bola", "Toy Bola", "Toy Bola")
    val calmTheme = value("Sokin", "Спокойная", "Calm")
    val neutralTheme = value("Neytral", "Нейтральная", "Neutral")

    val skeletonReady = value(
        "Bu bo‘lim keyingi versiyada to‘liq ulanadi.",
        "Этот раздел будет полностью подключён в следующей версии.",
        "This section will be fully connected in a later version."
    )

    // Sborka -> Ma'lumot
    val masterDataIntro = value("Sborkaga tegishli asosiy ma’lumotlarni shu yerdan boshqaring.", "Управляйте основными данными сборки здесь.", "Manage assembly master data here.")
    val brigades = value("Brigadalar", "Бригады", "Brigades")
    val workers = value("Ishchilar", "Работники", "Workers")
    val products = value("Mahsulotlar", "Продукты", "Products")
    val fk = "F/K"
    val workHours = value("Ish vaqti", "Рабочее время", "Work hours")
    val roundTimes = value("Sifat raund vaqtlari", "Время раундов качества", "Quality round times")
    val efficiencyNorm = value("Samaradorlik normativi", "Норматив эффективности", "Efficiency threshold")
    val monitoringCriteria = value("Monitoring mezonlari", "Критерии мониторинга", "Monitoring criteria")
    val assemblyStages = value("Yig‘uv bosqichlari", "Этапы сборки", "Assembly stages")
    val archive = value("Arxiv", "Архив", "Archive")
    val yearCopy = value("Yangi yil ma’lumotlari", "Данные нового года", "New-year data")
    val addBrigade = value("Brigada qo‘shish", "Добавить бригаду", "Add brigade")
    val editBrigade = value("Brigadani tahrirlash", "Изменить бригаду", "Edit brigade")
    val brigadeName = value("Brigada nomi", "Название бригады", "Brigade name")
    val brigade = value("Brigada", "Бригада", "Brigade")
    val noBrigades = value("Hali brigada kiritilmagan", "Бригады ещё не добавлены", "No brigades yet")
    val addWorker = value("Ishchi qo‘shish", "Добавить работника", "Add worker")
    val editWorker = value("Ishchini tahrirlash", "Изменить работника", "Edit worker")
    val workerName = value("Ishchi ismi", "Имя работника", "Worker name")
    val startDate = value("Ish boshlagan sana", "Дата начала работы", "Start date")
    val started = value("Boshlagan", "Начало", "Started")
    val noWorkers = value("Hali ishchi kiritilmagan", "Работники ещё не добавлены", "No workers yet")
    val createBrigadeFirst = value("Avval brigada yarating", "Сначала создайте бригаду", "Create a brigade first")
    val selectBrigade = value("Brigadani tanlang", "Выберите бригаду", "Select brigade")
    val addProduct = value("Mahsulot qo‘shish", "Добавить продукт", "Add product")
    val editProduct = value("Mahsulotni tahrirlash", "Изменить продукт", "Edit product")
    val article = value("Artikul", "Артикул", "Article")
    val productName = value("Mahsulot nomi", "Название продукта", "Product name")
    val price = value("Narxi", "Цена", "Price")
    val priceHistory = value("Narx tarixi", "История цен", "Price history")
    val noProducts = value("Hali mahsulot kiritilmagan", "Продукты ещё не добавлены", "No products yet")
    val oneStagePerLine = value("Har bir yig‘uv bosqichini yangi qatordan yozing.", "Каждый этап сборки вводите с новой строки.", "Enter each assembly stage on a new line.")
    val noStages = value("Yig‘uv bosqichi kiritilmagan", "Этапы сборки не указаны", "No assembly stages")
    val stagesHelp = value("Yig‘uv bosqichlari mahsulot ichida saqlanadi. O‘zgartirish uchun Mahsulotlar bo‘limidan mahsulotni oching.", "Этапы сборки хранятся внутри продукта. Для изменения откройте продукт в разделе Продукты.", "Assembly stages are stored inside each product. Edit them from Products.")
    val fkHelp = value("Har bir brigada uchun F/K alohida belgilanadi. Yangi qiymat eski hisoblarni o‘zgartirmaydi.", "F/K задаётся отдельно для каждой бригады. Новое значение не меняет старые расчёты.", "F/K is set per brigade. New values do not change historical calculations.")
    val amount = value("Summa", "Сумма", "Amount")
    val som = value("so‘m", "сум", "UZS")
    val hours = value("soat", "час", "hours")
    val percent = value("Foiz", "Процент", "Percent")
    val notEntered = value("Kiritilmagan", "Не введено", "Not entered")
    val toArchive = value("Arxivga", "В архив", "Archive")
    val archiveEmpty = value("Arxiv bo‘sh", "Архив пуст", "Archive is empty")
    val restore = value("Qaytarish", "Восстановить", "Restore")
    val deletePermanently = value("O‘chirish", "Удалить", "Delete")
    val deleteBrigadeTitle = value("Brigadani o‘chirish", "Удалить бригаду", "Delete brigade")
    val deleteBrigadeConfirm = value("Bu bo‘sh brigada arxiv ro‘yxatidan o‘chiriladi. Davom etasizmi?", "Эта пустая бригада будет удалена из архива. Продолжить?", "This empty brigade will be removed from the archive. Continue?")
    val currentValue = value("Amaldagi qiymat", "Текущее значение", "Current value")
    val history = value("Tarix", "История", "History")
    val roundTimeHelp = value("Default vaqtlar: 10:00 / 13:00 / 16:00. Keyin o‘zgartirilsa eski davr o‘z qiymatida qoladi.", "Время по умолчанию: 10:00 / 13:00 / 16:00. Старые периоды сохраняют прежние значения.", "Default times: 10:00 / 13:00 / 16:00. Historical periods retain their values.")
    val round1 = value("1-raund", "1-й раунд", "Round 1")
    val round2 = value("2-raund", "2-й раунд", "Round 2")
    val round3 = value("3-raund", "3-й раунд", "Round 3")
    val effectiveDate = value("Amal qilish sanasi", "Дата вступления в силу", "Effective date")
    val monitoringCriteriaHelp = value("Standart qiymatlar avtomatik kiritilgan. Jami har bir rol uchun 100% bo‘lishi shart.", "Стандартные значения уже заполнены. Сумма для каждой роли должна быть 100%.", "Default values are prefilled. Each role must total 100%.")
    val onTimeClose = value("Vaqtida yopish", "Закрытие вовремя", "On-time close")
    val noReopen = value("Qayta ochilmaslik", "Без повторного открытия", "No reopen")
    val brigadeResult = value("Brigada natijasi", "Результат бригады", "Brigade result")
    val roundsOnTime = value("Raundlarni vaqtida bajarish", "Раунды вовремя", "Rounds on time")
    val rechecks = value("Qayta tekshiruvlar", "Повторные проверки", "Rechecks")
    val dataDiscipline = value("Ma’lumot intizomi", "Дисциплина данных", "Data discipline")
    val dateFormatHint = "YYYY-MM-DD"
    val invalidDate = value("Sana formati noto‘g‘ri", "Неверный формат даты", "Invalid date format")
    val invalidPrice = value("Narxni to‘g‘ri kiriting", "Введите корректную цену", "Enter a valid price")
    val errorGeneric = value("Xatolik yuz berdi", "Произошла ошибка", "An error occurred")
    val yearCopyHelp = value("Keyingi yil uchun amaldagi normativlar 1-yanvardan yangi tarixiy versiya sifatida tayyorlanadi.", "Текущие нормативы будут подготовлены на 1 января следующего года как новая историческая версия.", "Current norms will be prepared for January 1 of the next year as new historical versions.")
    val yearCopyMastersCarry = value("Brigada, ishchi va mahsulotlar faol bo‘lsa avtomatik davom etadi; ularni keraksiz nusxalab ko‘paytirmaymiz.", "Активные бригады, работники и продукты продолжаются автоматически без лишних копий.", "Active brigades, workers and products carry forward automatically without duplicate records.")
    val prepareNextYear = value("Keyingi yilni tayyorlash", "Подготовить следующий год", "Prepare next year")
    val prepared = value("Tayyorlangan", "Подготовлено", "Prepared")


    val newValue = value("Yangi qiymat", "Новое значение", "New value")
    val noHistory = value("Tarix hali yo‘q", "История пока пуста", "No history yet")
    val initialValue = value("Boshlang‘ich qiymat", "Начальное значение", "Initial value")
    val manageStages = value("Yig‘uv bosqichlarini boshqarish", "Управлять этапами сборки", "Manage assembly stages")
    val addStage = value("Bosqich qo‘shish", "Добавить этап", "Add stage")
    val editStage = value("Bosqichni tahrirlash", "Изменить этап", "Edit stage")
    val stageName = value("Bosqich nomi", "Название этапа", "Stage name")
    val newPrice = value("Yangi narx", "Новая цена", "New price")
    val stagesEditHint = value("Yig‘uv bosqichlari mahsulot saqlangandan keyin alohida oynadan boshqariladi.", "Этапы сборки управляются в отдельном окне после сохранения товара.", "Assembly stages are managed in a separate screen after saving the product.")

    // Brigadir
    val today = value("Bugun", "Сегодня", "Today")
    val worked = value("Ishladi", "Работал", "Worked")
    val didNotWork = value("Ishlamadi", "Не работал", "Did not work")
    val didNotWorkShort = value("Ishlam.", "Не раб.", "Off")
    val unfinished = value("Tugallanmagan", "Не завершено", "Incomplete")
    val completed = value("Tugallangan", "Завершено", "Completed")
    val noWorkersForBrigade = value("Bu brigadada faol ishchi yo‘q", "В этой бригаде нет активных работников", "No active workers in this brigade")
    val chooseBrigade = value("Brigadani tanlang", "Выберите бригаду", "Choose brigade")
    val workerDay = value("Ishchi kuni", "День работника", "Worker day")
    val addProduction = value("Mahsulot yozish", "Добавить производство", "Add production")
    val quantity = value("Soni", "Количество", "Quantity")
    val unitPrice = value("Narx", "Цена", "Unit price")
    val totalAmount = value("Topgan summa", "Заработанная сумма", "Earned amount")
    val requiredAmount = value("Kerakli summa", "Требуемая сумма", "Required amount")
    val efficiency = value("Samaradorlik", "Эффективность", "Efficiency")
    val selectProduct = value("Mahsulotni tanlang", "Выберите товар", "Select product")
    val noProductsForBrigade = value("Bu brigada uchun faol mahsulot yo‘q", "Для этой бригады нет активных товаров", "No active products for this brigade")
    val duplicateProduct = value("Bu mahsulot bugun avval kiritilgan. Sonini birlashtirasizmi?", "Этот товар уже был введён сегодня. Объединить количество?", "This product was already entered today. Merge the quantity?")
    val merge = value("Birlashtirish", "Объединить", "Merge")
    val delete = value("O‘chirish", "Удалить", "Delete")
    val editQuantity = value("Sonini tahrirlash", "Изменить количество", "Edit quantity")
    val fkMissing = value("Bu brigada uchun F/K kiritilmagan", "Для этой бригады не задан F/K", "F/K is not set for this brigade")
    val markNotWorked = value("Ishlamadi qilish", "Отметить как не работал", "Mark as did not work")
    val markWorked = value("Ishladi qilish", "Отметить как работал", "Mark as worked")
    val brigadeWorked = value("Brigada ishladi", "Бригада работала", "Brigade worked")
    val brigadeDidNotWork = value("Brigada ishlamadi", "Бригада не работала", "Brigade did not work")
    val changeHours = value("Soatni o‘zgartirish", "Изменить часы", "Change hours")

    // Sifat
    val qualityPending = value("Baholanmagan", "Не проверено", "Not checked")
    val qualityDone = value("Baholangan", "Проверено", "Checked")
    val qualityNotChecked = value("Hali baholanmagan", "Ещё не проверено", "Not checked yet")
    val qualityMissed = value("O‘tkazib yuborildi", "Пропущено", "Missed")
    val qualityResult = value("Sifat", "Качество", "Quality")
    val grade = value("Baho", "Оценка", "Grade")
    val note = value("Izoh", "Комментарий", "Note")
    val reason = value("Sabab", "Причина", "Reason")
    val selectAssemblyStage = value("Yig‘uv bosqichini tanlang", "Выберите этап сборки", "Select assembly stage")
    val productHasNoStages = value("Bu mahsulotda faol yig‘uv bosqichi yo‘q", "У этого продукта нет активных этапов сборки", "This product has no active assembly stages")
    val noteRequiredForBadGrade = value("3 va 4 bahoda izoh majburiy.", "Для оценок 3 и 4 комментарий обязателен.", "A note is required for grades 3 and 4.")
    val recheckRequired = value("Qayta tekshiruv kerak", "Требуется повторная проверка", "Recheck required")
    val recheck = value("Qayta tekshirish", "Повторная проверка", "Recheck")
    val rechecked = value("Qayta tekshirildi", "Повторно проверено", "Rechecked")
    val originalGrade = value("Dastlabki baho", "Исходная оценка", "Original grade")
    val recheckKeepsOriginal = value("Qayta tekshiruv dastlabki bahoni o‘zgartirmaydi.", "Повторная проверка не изменяет исходную оценку.", "The recheck does not change the original grade.")
    val missedReasonRequired = value("Raund vaqti o‘tgan. O‘tkazib yuborish sababini yozing.", "Время раунда прошло. Укажите причину пропуска.", "The round window has passed. Enter the reason it was missed.")
    val qualityTooEarly = value("Bu raund uchun baholash vaqti hali boshlanmagan.", "Время оценки этого раунда ещё не началось.", "The scoring window for this round has not started yet.")
    val qualityWindow = value("Baholash oynasi", "Окно оценки", "Scoring window")
    val availableNow = value("Hozir mumkin", "Доступно сейчас", "Available now")
    val notStartedYet = value("Hali boshlanmagan", "Ещё не началось", "Not started yet")
    val windowPassed = value("Vaqt o‘tgan", "Время истекло", "Window passed")
    val scheduled = value("Belgilangan vaqt", "Назначенное время", "Scheduled time")
    val roundShort = value("raund", "раунд", "round")
    val excellent = value("A’lo", "Отлично", "Excellent")
    val good = value("Yaxshi", "Хорошо", "Good")
    val unsatisfactory = value("Qoniqarsiz", "Неудовлетворительно", "Unsatisfactory")
    val bad = value("Yomon", "Плохо", "Bad")


    // Kun muammosi
    val addIssue = value("Muammo yozish", "Добавить проблему", "Add issue")
    val issueProduct = value("Mahsulot", "Продукт", "Product")
    val issueStage = value("Yig‘uv bosqichi", "Этап сборки", "Assembly stage")
    val issueText = value("Muammo izohi", "Описание проблемы", "Issue description")
    val noIssuesToday = value("Bugun muammo yozilmagan", "Сегодня проблем не записано", "No issues recorded today")
    val issueSaved = value("Muammo saqlandi", "Проблема сохранена", "Issue saved")
    val editIssue = value("Muammoni tahrirlash", "Изменить проблему", "Edit issue")
    val deleteIssue = value("Muammoni o‘chirish", "Удалить проблему", "Delete issue")
    val exportWord = value("Word chiqarish", "Экспорт Word", "Export Word")
    val exportDay = value("Kun", "День", "Day")
    val exportMonth = value("Oy", "Месяц", "Month")
    val exportYear = value("Yil", "Год", "Year")
    val exportSuccess = value("Word fayl saqlandi", "Файл Word сохранён", "Word file saved")
    val exportFailed = value("Word faylni yaratib bo‘lmadi", "Не удалось создать Word-файл", "Could not create Word file")
    val chooseProductFirst = value("Avval mahsulotni tanlang", "Сначала выберите продукт", "Choose a product first")


    // Kun yopish va monitoring
    val unclosedDays = value("Yopilmagan oldingi kunlar", "Незакрытые прошлые дни", "Unclosed previous days")
    val unclosedQualityDays = value("Yopilmagan sifat kunlari", "Незакрытые дни качества", "Unclosed quality days")
    val open = value("Ochish", "Открыть", "Open")
    val closedDays = value("Yopilgan kunlar", "Закрытые дни", "Closed days")
    val reopenDay = value("Kunni qayta ochish", "Повторно открыть день", "Reopen day")
    val reopenReason = value("Qayta ochish sababi", "Причина повторного открытия", "Reason for reopening")
    val dayReopened = value("Kun qayta ochildi", "День повторно открыт", "Day reopened")
    val brigadirDayClosed = value("Brigadir kuni yopildi", "День бригадира закрыт", "Brigadier day closed")
    val qualityDayClosed = value("Sifat kuni yopildi", "День качества закрыт", "Quality day closed")
    val cannotCloseDay = value("Kunni yopish uchun ma’lumotlar to‘liq emas", "Недостаточно данных для закрытия дня", "Data is incomplete for closing the day")
    val cannotCloseQuality = value("Sifat kunini yopish uchun ma’lumotlar to‘liq emas", "Недостаточно данных для закрытия качества", "Quality data is incomplete for closing the day")
    val closeBrigadirDay = value("Brigadir kunini yopish", "Закрыть день бригадира", "Close brigadier day")
    val closeQualityDay = value("Sifat kunini yopish", "Закрыть день качества", "Close quality day")
    val lateCloseReason = value("Kech yopish sababi", "Причина позднего закрытия", "Reason for late close")
    val brigadirDeadlinePassed = value("09:00 yopish muddati o‘tdi", "Срок закрытия 09:00 истёк", "09:00 closing deadline has passed")
    val qualityDeadlinePassed = value("17:50 gacha sifat kuni yopilmadi", "День качества не закрыт до 17:50", "Quality day was not closed by 17:50")
    val writeReason = value("Sabab yozish", "Написать причину", "Write reason")
    val monitorWorkers = value("Ishchilar", "Работники", "Workers")
    val monitorBrigadirs = value("Brigadirlar", "Бригадиры", "Brigadiers")
    val monitorQualityStaff = value("Sifat nazoratchilari", "Контролёры качества", "Quality inspectors")
    val problemProducts = value("Muammoli mahsulotlar", "Проблемные товары", "Problem products")
    val allBrigades = value("Barcha brigadalar", "Все бригады", "All brigades")
    val all = value("Barchasi", "Все", "All")
    val belowThreshold = value("Mezondan past", "Ниже нормы", "Below threshold")
    val notActiveYet = value("hali faol emas", "ещё не активен", "not active yet")
    val months = value("Oylar va kvartallar", "Месяцы и кварталы", "Months and quarters")
    val noMonitoringData = value("Bu davr uchun ma’lumot yo‘q", "Нет данных за этот период", "No data for this period")
    val monitoringNotReady = value("Monitoring tayyor emas", "Мониторинг не готов", "Monitoring is not ready")
    val name = value("Ism", "Имя", "Name")
    val searchWorker = value("Ishchini qidirish", "Поиск работника", "Search worker")
    val finalResult = value("Yakuniy natija", "Итоговый результат", "Final result")
    val finalShort = value("Yakuniy", "Итог", "Final")
    val experience = value("Tajriba", "Стаж", "Experience")
    val days = value("kun", "дней", "days")
    val issueHistory = value("Muammolar tarixi va Word hisobot", "История проблем и Word-отчёт", "Issue history and Word report")
    val auditLog = value("Audit tarixi", "Журнал аудита", "Audit log")
    val auditHelp = value("Muhim o‘zgarishlar va kun yopish/qayta ochish tarixini ko‘rsatadi.", "Показывает историю важных изменений и закрытия/повторного открытия дней.", "Shows important changes and day close/reopen history.")
    val noAudit = value("Audit yozuvlari hali yo‘q", "Записей аудита пока нет", "No audit records yet")

    fun backupCountLine(brigades: Int, workers: Int, products: Int): String = value(
        "Brigada: $brigades • Ishchi: $workers • Mahsulot: $products",
        "Бригады: $brigades • Работники: $workers • Товары: $products",
        "Brigades: $brigades • Workers: $workers • Products: $products"
    )

    fun backupOperationalCountLine(workerDays: Int, qualityRounds: Int, dailyIssues: Int): String = value(
        "Ish kunlari: $workerDays • Sifat raundlari: $qualityRounds • Kun muammosi: $dailyIssues",
        "Рабочие дни: $workerDays • Раунды качества: $qualityRounds • Проблемы дня: $dailyIssues",
        "Worker days: $workerDays • Quality rounds: $qualityRounds • Daily issues: $dailyIssues"
    )

    fun issueCount(count: Int): String = value("$count ta", "$count шт.", count.toString())

    fun notificationCount(count: Int): String = value("$count yangi", "$count новых", "$count new")

    fun brigadeRowSubtitle(workerCount: Int, productCount: Int): String = value(
        "$workerCount ishchi • $productCount mahsulot",
        "$workerCount работников • $productCount продуктов",
        "$workerCount workers • $productCount products"
    )

    fun yearPrepared(year: Int): String = value(
        "$year yil uchun normativlar tayyorlandi.",
        "Нормативы на $year год подготовлены.",
        "Norms for $year are prepared."
    )
}
