# Toy Bola Factory Management System

## 0.11.2 — Android + Windows birgalikdagi client

- Android ilovasi saqlanadi va shu versiyadan boshlab Windows desktop client ham bitta source paket ichida yuradi.
- Windows client Compose Desktop asosida desktop ekraniga mos chap navigatsiya, keng jadvallar va dialoglardan foydalanadi.
- Android va Windows bir xil Firebase project, User Code/Device Code, role/permission va server snapshot ma’lumotlari bilan ishlaydi.
- Windows lokal cache + outbox bilan offline ishlay oladi; internet qaytganda pending yozuvlar serverga yuboriladi va ruxsatli snapshot qayta olinadi.
- Windows yozuvlari yangi `desktopApplyWrites` callable orqali serverda permission/brigada scope qayta tekshirilgandan keyin Firestore’ga yoziladi.
- TP/Seryo, Plan, Ostatka, Qabul, Sifat, Monitoring, master-data va Sborka asosiy ish oqimlari desktop UIga moslashtirildi.
- GitHub Actions endi Android test/lint/APK bilan birga Windows test/compile va `.exe`/`.msi` paketlarini ham chiqaradi; Firebase deploy har ikkala client build muvaffaqiyatli bo‘lgandan keyin ishlaydi.
- Keyingi versiyalarda Android va Windows versiya raqami birga oshiriladi.

### GitHub artifactlar

- Android: `ToyBola-0.11.2-android-debug-apk`
- Windows: `ToyBola-0.11.2-windows` (`.exe`, `.msi` va distributable papka)

## 0.10.2 — navigatsiya, Plan tasdiqlash, sig‘im, ko‘p-seryo va jim narxi

- Barcha asosiy ekranlarda Back navigatsiyasi bir pog‘onadan qaytadigan qilib tartiblandi; uzun ro‘yxatlarda ichki elementni ochib qaytganda oldingi scroll joyi saqlanadi.
- TP detal ma’lumotidan qo‘lda “mos stanoklar” tanlash olib tashlandi. Moslik faqat stanok sig‘imi va detalga kiritilgan ruxsatli sig‘imlar orqali avtomatik aniqlanadi.
- Plan beruvchida “Tasdiqlanmagan / Tasdiqlangan” oqimi va “Jarayonni boshlash / tasdiqlash” amali qo‘shildi. Tasdiqlanmaguncha plan Seryo, Qabul/Sifat va TP brigadir ish oqimlariga chiqmaydi.
- Bitta detal uchun bir nechta seryo turi kiritish va plan rang-vazifasi kesimida umumiy mos seryoni tanlash qo‘shildi.
- Detal narxi endi dona narxi emas, **1 jim narxi** sifatida ishlaydi. Qabul dona bilan qoladi; ishchi summasi `dona / 1 jimdagi dona × jim narxi` bo‘yicha hisoblanadi.

## 0.10.1 — TP sync, Nachalnik ustuvorligi va Plan beruvchi stanok rejalashi

- TP/Seryo lokal yozuvlari global Sync/Pending indikatoriga qo‘shildi; TP write WorkManager sync navbatiga avtomatik tushadi va faol sync paytidagi yangi so‘rov yo‘qolmaydi.
- Nachalnik zakazida 3 bosqichli rangli ustuvorlik: Eng zaril / Zaril / Keyinroq; kerakli sana maydoni olib tashlandi, zakaz vaqti va taxminiy yakun muddati ko‘rsatiladi.
- Zakazni tahrirlash va ishlab chiqarish boshlanmagan bo‘lsa o‘chirish qo‘shildi.
- Plan beruvchida zakaz → detallar → rang navbati → mos stanok tanlash oqimi soddalashtirildi. Bo‘sh stanoklar tepada, bandlari eng tez bo‘shaydiganidan tartiblanadi.
- Stanok master-data kartasiga sig‘im, detal/qolipga mos sig‘imlar (masalan 60/90/120) qo‘shildi; stanok mosligi va forecast shu cheklovni hisobga oladi.

## 0.10.0 — TP va Seryo ish jarayoni

Asosiy ekrandagi **Seryo va quyish** bo‘limi ishga tushirildi. Ichki tuzilma sodda besh yo‘nalishga yig‘ildi: **Plan**, **Seryo**, **Qabul qilish**, **Sifat** va **Monitoring**. Plan ichida nachalnik zakazi, plan beruvchi hisobi, TP brigadir stanok navbati, davomat hamda mahsulot/qolip ma’lumotlari joylashgan.

Zakazdan detal va rang kesimidagi ehtiyoj, jim soni, ortiqcha chiqadigan dona, seryo kilogrammi, krasitel grammi va taxminiy quyish vaqti avtomatik hisoblanadi. Bir qolipdan ikki yoki undan ko‘p detal birga chiqishi, stanok mosligi, bitta stanokdagi ustuvor navbat, uch sex–ikki smena–olti brigada boshlang‘ich tuzilmasi va keyinchalik brigada/smena qo‘shish yoki almashtirish qo‘llab-quvvatlanadi.

Qabul qilishda smenalararo yarim qop avtomatik hisoblanadi: oldingi ishchi qoldirgan dona yangi ishchiga qayta yozilmaydi. Real qabul reja soniga yetgandagina vazifa va partiya yakunlanadi. Sifat raundlari smena bo‘yicha o‘zgaruvchan, monitoringda partiya, ishchi, stanok, brigada, sifat, seryo va krasitel ko‘rsatkichlari sana oralig‘ida ko‘rinadi hamda Word/Excelga chiqariladi.

TP ma’lumotlari alohida server snapshot orqali fresh install qurilmaga qaytadi. Yozuvlar rol, granular permission va brigada scope bilan Firestore Rules hamda Cloud Functions darajasida tekshiriladi. Admin eski profilida yangi TP permission maydonlari bo‘lmasa ham Admin vakolati to‘liq saqlanadi. Device Code almashtirilganda eski hash bekor qilinadi.

0.9.5 dagi Sborka qoldiqli son o‘zgarishi saqlangan; TP/Seryo qo‘shilishi Sborka hisoblash va ekranlariga boshqa o‘zgarish kiritmaydi.

## 0.9.5 — Sborka qoldiqli son hotfix

Sborka Brigadir oynasidagi mahsulot soni endi `1.5` kabi qoldiqli qiymatni qabul qiladi. Butun sonlar avvalgidek `5` ko‘rinishida qoladi va `5.0` bo‘lib chiqmaydi. Eski butun sonli lokal/server ma’lumotlari yangi formatda o‘zgarishsiz o‘qiladi. Qoldiqli son bo‘yicha topilgan summa eng yaqin butun so‘mga yaxlitlanadi.

0.9.4 dagi server snapshot, recovery, ruxsatlar, Sifat, Monitoring, Kun muammosi va Sborka kunini yopish/qayta ochish ishlashiga boshqa o‘zgarish kiritilmagan.

## 0.9.4 — authoritative server snapshot hotfix

0.9.3 server-side recovery muvaffaqiyatli yozgandan keyin Android clientning bevosita Firestore qayta-o‘qishi ayrim pilot/legacy hujjatlar yoki Rules query sharoitida `PERMISSION_DENIED` bilan to‘xtashi mumkin edi. 0.9.4 da normal server→client bootstrap/sync `getAssemblySnapshot` callable endpoint orqali bajariladi. Endpoint foydalanuvchining serverdagi role/permission/brigada scopeini tekshiradi va faqat ruxsatli ma’lumotni Firebase Admin SDK orqali o‘qib qaytaradi.

Bu fresh install, Admin `Kun muammosi` ko‘rinishi va recoverydan keyingi qayta syncni bir xil server-authoritative yo‘lga birlashtiradi. Oddiy client yozuvlari esa Firestore Security Rules orqali himoyalangan holda qoladi.

Android/Kotlin/Jetpack Compose zavod boshqaruv tizimi.

## 0.9.3 — server-side recovery hotfix

0.9.3 pilotda 0.9.2 recovery vaqtida topilgan `PERMISSION_DENIED` xatosini tuzatadi. Endi Admin backupdagi merged AssemblyData ni oddiy Android Firestore batch bilan yozmaydi. `adminRestoreAssemblyBackup` callable Cloud Function Admin sessiyasini tekshiradi, payload SHA-256 checksumini tasdiqlaydi, eski/legacy hujjatlarni yangi structured schema ga normalizatsiya qiladi va Firebase Admin SDK bilan serverga yozadi.

### Asosiy o‘zgarishlar

- Admin-only `adminRestoreAssemblyBackup` Cloud Function.
- Recovery yozuvlari client Firestore Rules orqali emas, server Admin SDK orqali yoziladi; kundalik oddiy yozuvlar esa avvalgidek Security Rules bilan himoyalanadi.
- Brigada, ishchi, mahsulot/narx, FK, sozlamalar, workerDays, brigadeDays, sifat raundlari, Kun muammosi va audit yozuvlari normalizatsiya qilinadi.
- Har recovery uchun `serverRecoveryLog` va `SERVER_RECOVERY` audit yozuvi yaratiladi.
- Server recovery muvaffaqiyatli bo‘lsa eski client outbox tozalanadi va telefon darhol serverdan qayta sync qiladi.
- 0.9.2 backup format (schemaVersion=2) import bilan mos; yangi export nomi `ToyBola_backup_0.9.4.json`.
- 0.9.1/0.9.2 dagi dailyIssues Admin sync, fresh-install bootstrap, Device Code server-first tekshiruvi va Sababli/Sababsiz sifat raundi saqlanadi.

## 0.9.3 recovery tartibi

1. GitHub rootiga `ToyBola_Factory_Source_0.9.3.zip` yuklang va `.github/workflows/main.yml` ni 0.9.3 workflow bilan almashtiring.
2. Actions: Android test/lint/APK va Firebase rules/functions deploy ikkalasi yashil bo‘lsin.
3. Ma’lumoti bor Brigadir/Sifat telefonlariga 0.9.3 ni **UPDATE** qiling; appni o‘chirmang.
4. Ulardan `Zaxira va server tiklash` → `Lokal backup chiqarish`. 0.9.2 da chiqarilgan to‘g‘ri backup fayllar ham ishlaydi.
5. Admin telefonida backup(lar)ni ketma-ket import qiling. Har importdan keyin server-side recovery bajariladi.
6. Server yuklash muvaffaqiyatli bo‘lgach bitta test telefonda appni o‘chirib fresh install qiling. Barcha ma’lumot serverdan qaytsa migratsiya yakunlangan.

## Xavfsizlik

- Recovery endpoint faqat serverdagi faol `ADMIN` roliga ruxsat beradi.
- Payload checksum va hajm tekshiriladi, ID/sana maydonlari validatsiya qilinadi.
- Service-account private key APK/repository ichida yo‘q.
- Normal foydalanuvchi yozuvlari recovery endpointdan foydalana olmaydi.
