package uz.toybola.factory.core.data

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import uz.toybola.factory.core.firebase.syncableRecordCount
import java.security.MessageDigest
import java.time.Instant

/**
 * Portable one-time recovery backup for the legacy-local -> Firebase migration.
 *
 * The payload is the same version-tolerant JSON used by the sync layer. A SHA-256 checksum
 * protects against a truncated/corrupted transfer file. Import MERGES into the current local
 * database; this makes it safe to import backups from both Brigadir and Quality phones before
 * the Admin performs the one-time full server upload.
 */
class AssemblyBackupRepository(context: Context) {
    private val appContext = context.applicationContext
    private val repository = AssemblyDataRepository(appContext)

    data class BackupSummary(
        val totalRecords: Int,
        val brigades: Int,
        val workers: Int,
        val products: Int,
        val workerDays: Int,
        val qualityRounds: Int,
        val dailyIssues: Int
    )

    data class ImportResult(
        val imported: BackupSummary,
        val merged: BackupSummary
    )

    fun localSummary(allowedBrigadeIds: Set<String>? = null): BackupSummary =
        summary(scoped(repository.load(), allowedBrigadeIds))

    fun exportTo(uri: Uri, allowedBrigadeIds: Set<String>? = null): Result<BackupSummary> = runCatching {
        val data = scoped(repository.load(), allowedBrigadeIds)
        require(hasBusinessData(data)) { "Eksport qilish uchun ish ma’lumoti topilmadi" }
        val payload = repository.encodeForSync(data)
        val envelope = JSONObject().apply {
            put("format", FORMAT)
            put("schemaVersion", SCHEMA_VERSION)
            put("appVersion", "0.11.2")
            put("exportedAt", Instant.now().toString())
            put("payloadSha256", sha256(payload))
            put("payload", payload)
        }
        appContext.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use {
            it.write(envelope.toString())
        } ?: error("Backup faylini yozib bo‘lmadi")
        summary(data)
    }

    fun importAndMerge(uri: Uri): Result<ImportResult> = runCatching {
        val raw = appContext.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            ?: error("Backup faylini o‘qib bo‘lmadi")
        val root = JSONObject(raw)
        require(root.optString("format") == FORMAT) { "Bu ToyBola backup fayli emas" }
        val schema = root.optInt("schemaVersion", 0)
        require(schema in 1..SCHEMA_VERSION) { "Backup formati qo‘llab-quvvatlanmaydi" }
        val payload = root.optString("payload")
        require(payload.isNotBlank()) { "Backup ichida ma’lumot yo‘q" }
        val expected = root.optString("payloadSha256")
        require(expected.isNotBlank() && expected.equals(sha256(payload), ignoreCase = true)) {
            "Backup fayli buzilgan yoki to‘liq ko‘chmagan"
        }
        val imported = repository.decodeForSync(payload)
        require(hasBusinessData(imported)) { "Backup ichida ish ma’lumoti topilmadi" }
        val merged = repository.mergeFromBackup(imported)
        ImportResult(summary(imported), summary(merged))
    }


    private fun scoped(data: AssemblyData, allowedBrigadeIds: Set<String>?): AssemblyData {
        val allowed = allowedBrigadeIds ?: return data
        return data.copy(
            brigades = data.brigades.filter { it.id in allowed },
            workers = data.workers.filter { it.brigadeId in allowed },
            products = data.products.filter { it.brigadeId in allowed },
            brigadeFk = data.brigadeFk.filter { it.brigadeId in allowed },
            workerDays = data.workerDays.filter { it.brigadeId in allowed },
            brigadeDays = data.brigadeDays.filter { it.brigadeId in allowed },
            qualityRounds = data.qualityRounds.filter { it.brigadeId in allowed },
            dailyIssues = data.dailyIssues.filter { it.brigadeId in allowed },
            auditLog = data.auditLog.filter { it.brigadeId == null || it.brigadeId in allowed }
        )
    }
    private fun summary(data: AssemblyData): BackupSummary = BackupSummary(
        totalRecords = data.syncableRecordCount(),
        brigades = data.brigades.size,
        workers = data.workers.size,
        products = data.products.size,
        workerDays = data.workerDays.size,
        qualityRounds = data.qualityRounds.size,
        dailyIssues = data.dailyIssues.size
    )

    private fun hasBusinessData(data: AssemblyData): Boolean =
        data.brigades.isNotEmpty() || data.workers.isNotEmpty() || data.products.isNotEmpty() ||
            data.brigadeFk.isNotEmpty() || data.workerDays.isNotEmpty() || data.brigadeDays.isNotEmpty() ||
            data.qualityRounds.isNotEmpty() || data.dailyIssues.isNotEmpty() || data.auditLog.isNotEmpty()

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it.toInt() and 0xff) }

    companion object {
        const val DEFAULT_FILE_NAME = "ToyBola_backup_0.11.2.json"
        private const val FORMAT = "TOYBOLA_ASSEMBLY_BACKUP"
        private const val SCHEMA_VERSION = 2
    }
}
