package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate

private enum class TpSeryoPage { ROOT, ORDERS, STOCK, MONITORING }
private enum class TpStockPage { ROOT, OUT, IN, BALANCE }

@Composable
fun TpSeryoScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val serverRevision by TpDataEvents.revision.collectAsState()
    var revision by remember { mutableIntStateOf(0) }
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(serverRevision, revision, policy.revision) { repository.load().scopedFor(policy) }
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_SERYO)
    var page by remember { mutableStateOf(TpSeryoPage.ROOT) }
    var stockPage by remember { mutableStateOf(TpStockPage.ROOT) }
    fun refresh() { revision++ }
    fun goBackOneLevel() {
        when {
            page == TpSeryoPage.STOCK && stockPage != TpStockPage.ROOT -> stockPage = TpStockPage.ROOT
            page != TpSeryoPage.ROOT -> page = TpSeryoPage.ROOT
            else -> onBack()
        }
    }
    BackHandler(enabled = page != TpSeryoPage.ROOT || stockPage != TpStockPage.ROOT) { goBackOneLevel() }

    Column(Modifier.fillMaxSize()) {
        AppTopBar("Seryo", canGoBack = true, onMenu = {}, onBack = ::goBackOneLevel)
        when (page) {
            TpSeryoPage.ROOT -> Column(
                Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpSeryo-root"))
                    .navigationBarsPadding().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TpNavRow("1. Buyurtma") { page = TpSeryoPage.ORDERS }
                TpNavRow("2. Ostatka") { page = TpSeryoPage.STOCK; stockPage = TpStockPage.ROOT }
                TpNavRow("3. Monitoring") { page = TpSeryoPage.MONITORING }
            }
            TpSeryoPage.ORDERS -> TpSeryoOrders(data, repository, canWrite, ::refresh)
            TpSeryoPage.STOCK -> when (stockPage) {
                TpStockPage.ROOT -> Column(
                    Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpSeryo-stock-root"))
                        .navigationBarsPadding().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Ostatka harakati", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    TpNavRow("Rasxod") { stockPage = TpStockPage.OUT }
                    TpNavRow("Prixod") { stockPage = TpStockPage.IN }
                    TpNavRow("Ostatka") { stockPage = TpStockPage.BALANCE }
                }
                TpStockPage.OUT -> TpMaterialMovementPage(data, repository, canWrite, incoming = false, refresh = ::refresh)
                TpStockPage.IN -> TpMaterialMovementPage(data, repository, canWrite, incoming = true, refresh = ::refresh)
                TpStockPage.BALANCE -> TpMaterialBalancePage(data)
            }
            TpSeryoPage.MONITORING -> TpSeryoMonitoring(data)
        }
    }
}

@Composable
private fun TpSeryoOrders(data: TpData, repository: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var error by remember { mutableStateOf<String?>(null) }
    val approvedOrderIds = data.orders.filter { it.planApprovedAt != null }.map { it.id }.toSet()
    val jobs = data.jobs.filter { it.orderId in approvedOrderIds && it.machineId != null && it.status != TpJobStatus.COMPLETE }.sortedBy { it.priority }
    val resinNeed = jobs.filter { it.materialStatus != TpMaterialStatus.DELIVERED }.groupBy { it.resinCode }.mapValues { it.value.sumOf(TpPlanJob::requiredResinKg) }
    val colorNeed = jobs.filter { it.materialStatus != TpMaterialStatus.DELIVERED }.groupBy { it.colorCode }.mapValues { it.value.sumOf(TpPlanJob::requiredColorGrams) }
    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpSeryo-orders"))
            .navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Buyurtma", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Faol zakazlar uchun qolgan ehtiyoj", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        (resinNeed.map { (code, amount) -> Triple(code, amount, TpMaterialType.RESIN) } +
            colorNeed.map { (code, amount) -> Triple(code, amount, TpMaterialType.COLOR) }).forEach { (code, need, type) ->
            val available = data.materialStock(type, code)
            val unit = if (type == TpMaterialType.RESIN) "kg" else "g"
            Text(
                "$code: ${formatTpNumber(need)} $unit kerak / ${formatTpNumber(available)} $unit mavjud",
                color = if (available + 1e-9 >= need) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
        }
        HorizontalDivider()
        if (jobs.isEmpty()) Text("Tayyorlanadigan qorishma yo‘q.")
        jobs.forEach { job ->
            val order = data.orders.firstOrNull { it.id == job.orderId }
            val machine = data.machines.firstOrNull { it.id == job.machineId }
            TpCard {
                Text("${order?.batchNumber.orEmpty()} • ${machine?.number ?: 0}-stanok", fontWeight = FontWeight.Bold)
                Text("${job.moldCode} • rang ${job.colorCode} • ${job.requiredShots} jim")
                Text("${formatTpNumber(job.requiredResinKg)} kg ${job.resinCode}", style = MaterialTheme.typography.titleMedium)
                Text("${formatTpNumber(job.requiredColorGrams)} gram ${job.colorCode} krasitel")
                if (job.requiredResinKg > 0) Text("Nisbat: 25 kg ga ${formatTpNumber(job.requiredColorGrams * 25.0 / job.requiredResinKg)} gram")
                Text("Holat: ${materialStatusLabel(job.materialStatus)}", color = MaterialTheme.colorScheme.primary)
                if (canWrite && job.materialStatus == TpMaterialStatus.PLANNED) Button(onClick = {
                    error = repository.confirmMaterial(job.id, delivered = false).exceptionOrNull()?.message
                    if (error == null) refresh()
                }, Modifier.fillMaxWidth()) { Text("Qorishma tayyor — tasdiqlash") }
                if (canWrite && job.materialStatus == TpMaterialStatus.CONFIRMED) Button(onClick = {
                    error = repository.confirmMaterial(job.id, delivered = true).exceptionOrNull()?.message
                    if (error == null) refresh()
                }, Modifier.fillMaxWidth()) { Text("Stanokka olib chiqildi") }
            }
        }
        TpError(error)
    }
}

@Composable
private fun TpMaterialMovementPage(
    data: TpData,
    repository: TpDataRepository,
    canWrite: Boolean,
    incoming: Boolean,
    refresh: () -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val movements = data.materials.flatMap { material ->
        material.movements.filter { movement -> movement.kind == if (incoming) TpMaterialMovementKind.IN else TpMaterialMovementKind.OUT }
            .map { movement -> material to movement }
    }.sortedByDescending { it.second.createdAt }
    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState(if (incoming) "TpSeryo-prixod" else "TpSeryo-rasxod"))
            .navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(if (incoming) "Prixod" else "Rasxod", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Sana va vaqt avtomatik qayd etiladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (canWrite) Button(onClick = { showDialog = true }, Modifier.fillMaxWidth()) { Text(if (incoming) "+ Prixod kiritish" else "+ Rasxod kiritish") }
        if (!message.isNullOrBlank()) Text(message!!, color = if (message!!.startsWith("Saqlandi")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
        if (movements.isEmpty()) Text("Hali yozuv yo‘q.")
        movements.take(150).forEach { (material, movement) ->
            TpCard {
                Text("${material.code} • ${if (material.type == TpMaterialType.RESIN) "Seryo" else "Krasitel"}", fontWeight = FontWeight.Bold)
                Text("${formatTpNumber(movement.amount)} ${if (material.type == TpMaterialType.RESIN) "kg" else "g"}")
                Text(movement.createdAt.take(16).replace('T', ' '), style = MaterialTheme.typography.bodySmall)
                if (movement.sourceJobId != null) Text("Stanokka chiqarilgan", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (movement.note.isNotBlank()) Text(movement.note, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    if (showDialog) TpMaterialMovementDialog(
        data = data, incoming = incoming, onDismiss = { showDialog = false }
    ) { code, type, amount, note ->
        val result = repository.addMaterialMovement(code, type, amount, incoming, note)
        message = result.exceptionOrNull()?.message ?: "Saqlandi"
        if (result.isSuccess) { showDialog = false; refresh() }
        result.isSuccess
    }
}

@Composable
private fun TpMaterialMovementDialog(
    data: TpData,
    incoming: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, TpMaterialType, Double, String) -> Boolean
) {
    var type by remember { mutableStateOf(TpMaterialType.RESIN) }
    var code by remember(type) { mutableStateOf(if (incoming) "" else data.materials.firstOrNull { !it.archived && it.type == type }?.code.orEmpty()) }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (incoming) "Prixod kiritish" else "Rasxod kiritish") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                TpMaterialType.entries.forEachIndexed { index, option ->
                    SegmentedButton(
                        selected = type == option,
                        onClick = {
                            type = option
                            if (!incoming) code = data.materials.firstOrNull { !it.archived && it.type == option }?.code.orEmpty()
                        },
                        shape = SegmentedButtonDefaults.itemShape(index, TpMaterialType.entries.size)
                    ) { Text(if (option == TpMaterialType.RESIN) "Seryo" else "Krasitel") }
                }
            }
            if (incoming) TpField(code, { code = it.uppercase() }, "Kod")
            else TpChoice(
                label = "Kod", selectedId = code,
                options = data.materials.filter { !it.archived && it.type == type }.sortedBy { it.code },
                id = { it.code }, text = { "${it.code} • ostatka ${formatTpNumber(it.currentStock())}" }
            ) { code = it }
            TpField(amount, { amount = decimalInput(it) }, if (type == TpMaterialType.RESIN) "Miqdor (kg)" else "Miqdor (gram)", KeyboardType.Decimal)
            TpField(note, { note = it }, "Izoh (ixtiyoriy)", singleLine = false)
        } },
        confirmButton = { TextButton(onClick = {
            val parsed = amount.toDoubleOrNull()
            if (parsed != null && onSave(code, type, parsed, note)) onDismiss()
        }) { Text("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

@Composable
private fun TpMaterialBalancePage(data: TpData) {
    var type by remember { mutableStateOf(TpMaterialType.RESIN) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var search by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf("CODE") }
    var descending by remember { mutableStateOf(false) }
    val rows = data.materials.filter { !it.archived && it.type == type && it.code.contains(search.trim(), ignoreCase = true) }
        .let { source ->
            val comparator = when (sort) {
                "IN" -> compareBy<TpMaterial> { it.dayIncoming(date) }
                "OUT" -> compareBy<TpMaterial> { it.dayOutgoing(date) }
                "STOCK" -> compareBy<TpMaterial> { it.closingStock(date) }
                else -> compareBy<TpMaterial> { it.code }
            }
            if (descending) source.sortedWith(comparator.reversed()) else source.sortedWith(comparator)
        }
    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpSeryo-balance"))
            .navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Ostatka", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            TpMaterialType.entries.forEachIndexed { index, option ->
                SegmentedButton(type == option, { type = option }, SegmentedButtonDefaults.itemShape(index, TpMaterialType.entries.size)) {
                    Text(if (option == TpMaterialType.RESIN) "Seryo" else "Krasitel")
                }
            }
        }
        TpField(date, { date = it }, "Sana (YYYY-MM-DD)")
        TpField(search, { search = it }, "Kod bo‘yicha qidiruv")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)) {
                TpChoice(
                    "Tartib", sort,
                    listOf("CODE" to "Kod", "IN" to "Prixod", "OUT" to "Rasxod", "STOCK" to "Ostatka"),
                    { it.first }, { it.second }
                ) { sort = it }
            }
            OutlinedButton(onClick = { descending = !descending }) { Text(if (descending) "↓" else "↑") }
        }
        Text(if (type == TpMaterialType.RESIN) "Seryo oldi-berdi" else "Krasitel oldi-berdi", fontWeight = FontWeight.Bold)
        val horizontal = rememberScrollState()
        Column(Modifier.fillMaxWidth().horizontalScroll(horizontal)) {
            Row(Modifier.width(700.dp).padding(vertical = 8.dp)) {
                Text("№", Modifier.width(42.dp), fontWeight = FontWeight.Bold)
                Text("Kod", Modifier.width(150.dp), fontWeight = FontWeight.Bold)
                Text("Prixod", Modifier.width(155.dp), fontWeight = FontWeight.Bold)
                Text("Rasxod", Modifier.width(155.dp), fontWeight = FontWeight.Bold)
                Text("Ostatka", Modifier.width(170.dp), fontWeight = FontWeight.Bold)
            }
            HorizontalDivider(Modifier.width(700.dp))
            rows.forEachIndexed { index, material ->
                Row(Modifier.width(700.dp).padding(vertical = 10.dp)) {
                    Text("${index + 1}", Modifier.width(42.dp))
                    Text(material.code, Modifier.width(150.dp), fontWeight = FontWeight.SemiBold)
                    Text(formatTpNumber(material.dayIncoming(date)), Modifier.width(155.dp))
                    Text(formatTpNumber(material.dayOutgoing(date)), Modifier.width(155.dp))
                    Text(formatTpNumber(material.closingStock(date)), Modifier.width(170.dp), fontWeight = FontWeight.Bold)
                }
                HorizontalDivider(Modifier.width(700.dp))
            }
        }
        if (rows.isEmpty()) Text("Mos yozuv topilmadi.")
        Text("Hisob: oldingi kun yakuni + bugungi prixod − bugungi rasxod.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun TpSeryoMonitoring(data: TpData) {
    val today = LocalDate.now().toString()
    val approvedIds = data.orders.filter { it.planApprovedAt != null }.map { it.id }.toSet()
    val pendingJobs = data.jobs.filter { it.orderId in approvedIds && it.status != TpJobStatus.COMPLETE && it.materialStatus != TpMaterialStatus.DELIVERED }
    val resinNeeds = pendingJobs.groupBy { it.resinCode }.mapValues { it.value.sumOf(TpPlanJob::requiredResinKg) }
    val colorNeeds = pendingJobs.groupBy { it.colorCode }.mapValues { it.value.sumOf(TpPlanJob::requiredColorGrams) }
    val shortages = (resinNeeds.map { Triple(TpMaterialType.RESIN, it.key, it.value) } + colorNeeds.map { Triple(TpMaterialType.COLOR, it.key, it.value) })
        .filter { (type, code, need) -> data.materialStock(type, code) + 1e-9 < need }
    val todayInResin = data.materials.filter { it.type == TpMaterialType.RESIN }.sumOf { it.dayIncoming(today) }
    val todayOutResin = data.materials.filter { it.type == TpMaterialType.RESIN }.sumOf { it.dayOutgoing(today) }
    val todayInColor = data.materials.filter { it.type == TpMaterialType.COLOR }.sumOf { it.dayIncoming(today) }
    val todayOutColor = data.materials.filter { it.type == TpMaterialType.COLOR }.sumOf { it.dayOutgoing(today) }
    val recent = data.materials.flatMap { material -> material.movements.map { movement -> material to movement } }.sortedByDescending { it.second.createdAt }.take(20)
    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpSeryo-monitoring"))
            .navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Seryo monitoring", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TpCard(Modifier.weight(1f)) { Text("${pendingJobs.size}", fontWeight = FontWeight.Bold); Text("Faol buyurtma") }
            TpCard(Modifier.weight(1f)) { Text("${shortages.size}", fontWeight = FontWeight.Bold); Text("Yetishmovchilik") }
        }
        TpCard {
            Text("Bugungi seryo", fontWeight = FontWeight.Bold)
            Text("Prixod ${formatTpNumber(todayInResin)} kg • Rasxod ${formatTpNumber(todayOutResin)} kg")
        }
        TpCard {
            Text("Bugungi krasitel", fontWeight = FontWeight.Bold)
            Text("Prixod ${formatTpNumber(todayInColor)} g • Rasxod ${formatTpNumber(todayOutColor)} g")
        }
        Text("Material holati", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Tayyorlanmagan: ${pendingJobs.count { it.materialStatus == TpMaterialStatus.PLANNED }} • Tayyor: ${pendingJobs.count { it.materialStatus == TpMaterialStatus.CONFIRMED }}")
        if (shortages.isNotEmpty()) {
            Text("Yetishmayotganlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
            shortages.sortedByDescending { it.third - data.materialStock(it.first, it.second) }.forEach { (type, code, need) ->
                val stock = data.materialStock(type, code)
                TpCard {
                    Text(code, fontWeight = FontWeight.Bold)
                    Text("Kerak ${formatTpNumber(need)} ${if (type == TpMaterialType.RESIN) "kg" else "g"} • Bor ${formatTpNumber(stock)}")
                    Text("Yetmaydi ${formatTpNumber((need - stock).coerceAtLeast(0.0))}", color = MaterialTheme.colorScheme.error)
                }
            }
        }
        Text("Oxirgi harakatlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (recent.isEmpty()) Text("Harakatlar hali yo‘q.")
        recent.forEach { (material, movement) ->
            Text(
                "${movement.createdAt.take(16).replace('T', ' ')} • ${material.code} • ${if (movement.kind == TpMaterialMovementKind.IN) "+" else "−"}${formatTpNumber(movement.amount)} ${if (material.type == TpMaterialType.RESIN) "kg" else "g"}",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
fun TpReceivingScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val serverRevision by TpDataEvents.revision.collectAsState()
    var revision by remember { mutableIntStateOf(0) }
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(serverRevision, revision, policy.revision) { repository.load().scopedFor(policy) }
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_RECEIVING)
    val approvedOrderIds = data.orders.filter { it.planApprovedAt != null }.map { it.id }.toSet()
    val jobs = data.jobs.filter { it.orderId in approvedOrderIds && it.machineId != null && it.status != TpJobStatus.COMPLETE }.sortedBy { it.priority }
    var jobId by remember(jobs.map { it.id }) { mutableStateOf(jobs.firstOrNull()?.id.orEmpty()) }
    val job = jobs.firstOrNull { it.id == jobId }
    var detailId by remember(jobId) { mutableStateOf(job?.outputs?.firstOrNull()?.detailId.orEmpty()) }
    val output = job?.outputs?.firstOrNull { it.detailId == detailId }
    val workers = data.workers.filter { !it.archived && it.brigadeId == job?.brigadeId }.sortedBy { it.name }
    var workerId by remember(jobId, workers.map { it.id }) { mutableStateOf(workers.firstOrNull()?.id.orEmpty()) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var bags by remember { mutableStateOf("0") }
    var remainder by remember(jobId, detailId, revision) { mutableStateOf((job?.let { data.openRemainder(it.id, detailId) } ?: 0).toString()) }
    var receiver by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    val carry = job?.let { data.openRemainder(it.id, detailId) } ?: 0
    val preview = if (output != null) runCatching {
        calculateReceiptCredit(output.bagCapacity, carry, bags.toIntOrNull() ?: 0, remainder.toIntOrNull() ?: 0)
    }.getOrNull() else null

    Column(Modifier.fillMaxSize()) {
        AppTopBar("Qabul qilish", canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpOperationsScreens-screen-2")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Qabul qiluvchi asosan qop sonini yozadi. Oldingi smenadan qolgan yarim qop avtomatik ayriladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (jobs.isEmpty()) Text("Qabul qilinadigan faol stanok vazifasi yo‘q.")
            TpChoice("Vazifa", jobId, jobs, { it.id }, { item ->
                val machine = data.machines.firstOrNull { it.id == item.machineId }?.number ?: 0
                val order = data.orders.firstOrNull { it.id == item.orderId }?.batchNumber.orEmpty()
                "$machine-stanok • $order • ${item.moldCode} • ${item.colorCode}"
            }) { jobId = it }
            if (job != null) TpChoice("Detal", detailId, job.outputs, { it.detailId }, { it.detailName }) { detailId = it }
            TpChoice("Ishchi", workerId, workers, { it.id }, { it.name }) { workerId = it }
            TpField(date, { date = it }, "Sana (YYYY-MM-DD)")
            TpField(bags, { bags = digitsOnly(it) }, "Yopilgan to‘liq qop soni", KeyboardType.Number)
            TpField(remainder, { remainder = digitsOnly(it) }, "Amaldan keyingi qop qoldig‘i", KeyboardType.Number)
            TpField(receiver, { receiver = it }, "Qabul qiluvchi ismi")
            if (output != null) {
                TpCard {
                    Text("Qop sig‘imi: ${output.bagCapacity} dona")
                    Text("Oldingi smenadan qoldiq: $carry dona", fontWeight = FontWeight.Bold)
                    if (preview != null) Text("Bu ishchiga yoziladi: $preview dona", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    else Text("Qop va qoldiq sonini tekshiring", color = MaterialTheme.colorScheme.error)
                }
            }
            Button(enabled = canWrite && job != null && output != null && workerId.isNotBlank() && preview != null, onClick = {
                val result = repository.addReceipt(jobId, detailId, workerId, date, bags.toIntOrNull() ?: 0, remainder.toIntOrNull() ?: 0, receiver)
                message = result.exceptionOrNull()?.message ?: "Qabul qilindi: $preview dona"
                if (result.isSuccess) { bags = "0"; revision++ }
            }, modifier = Modifier.fillMaxWidth()) { Text("Qabul qilish") }
            if (!message.isNullOrBlank()) Text(message!!, color = if (message!!.startsWith("Qabul")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            HorizontalDivider()
            Text("Bugungi qabul", fontWeight = FontWeight.Bold)
            data.receipts.filter { it.date == date }.sortedByDescending { it.createdAt }.take(50).forEach { receipt ->
                TpCard {
                    Text("${receipt.workerNameSnapshot} • ${receipt.detailNameSnapshot} • ${receipt.creditedPieces} dona", fontWeight = FontWeight.Bold)
                    Text("${receipt.completedBags} qop • oldingi ${receipt.carryInPieces} • yangi qoldiq ${receipt.remainderAfter}")
                    Text("Qabul qildi: ${receipt.receiverName}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun TpQualityScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val serverRevision by TpDataEvents.revision.collectAsState()
    var revision by remember { mutableIntStateOf(0) }
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(serverRevision, revision, policy.revision) { repository.load().scopedFor(policy) }
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_QUALITY)
    var mode by remember { mutableStateOf("ROUND") }
    Column(Modifier.fillMaxSize()) {
        AppTopBar("TP sifat", canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpOperationsScreens-screen-3")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(mode == "ROUND", { mode = "ROUND" }, SegmentedButtonDefaults.itemShape(0, 2)) { Text("Raund") }
                SegmentedButton(mode == "ISSUE", { mode = "ISSUE" }, SegmentedButtonDefaults.itemShape(1, 2)) { Text("Kun muammosi") }
            }
            if (mode == "ROUND") TpQualityRoundForm(data, repository, canWrite) { revision++ }
            else TpDailyIssueForm(data, repository, canWrite) { revision++ }
        }
    }
}

@Composable
private fun TpQualityRoundForm(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    val approvedOrderIds = data.orders.filter { it.planApprovedAt != null }.map { it.id }.toSet()
    val jobs = data.jobs.filter { it.orderId in approvedOrderIds && it.machineId != null && it.status != TpJobStatus.COMPLETE }.sortedBy { it.priority }
    var jobId by remember(jobs.map { it.id }) { mutableStateOf(jobs.firstOrNull()?.id.orEmpty()) }
    val job = jobs.firstOrNull { it.id == jobId }
    val workers = data.workers.filter { !it.archived && it.brigadeId == job?.brigadeId }
    var workerId by remember(jobId) { mutableStateOf(workers.firstOrNull()?.id.orEmpty()) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    val shift = data.shifts.firstOrNull { it.id == job?.shiftId }
    var round by remember(jobId) { mutableStateOf("1") }
    var score by remember { mutableStateOf("100") }
    var issue by remember { mutableStateOf("") }
    var checker by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    if (jobs.isEmpty()) Text("Tekshiriladigan faol stanok vazifasi yo‘q.")
    TpChoice("Stanok vazifasi", jobId, jobs, { it.id }, { item ->
        val machine = data.machines.firstOrNull { it.id == item.machineId }?.number ?: 0
        "$machine-stanok • ${item.moldCode} • ${item.colorCode}"
    }) { jobId = it }
    TpChoice("Ishchi", workerId, workers, { it.id }, { it.name }) { workerId = it }
    TpField(date, { date = it }, "Sana (YYYY-MM-DD)")
    TpChoice("Raund", round, shift?.roundTimes.orEmpty().mapIndexed { index, time -> (index + 1) to time }, { it.first.toString() }, { "${it.first}-raund • ${it.second}" }) { round = it }
    TpField(score, { score = digitsOnly(it) }, "Baho (0–100)", KeyboardType.Number)
    TpField(issue, { issue = it }, "Muammo/izoh", singleLine = false)
    TpField(checker, { checker = it }, "Sifat nazoratchisi")
    Button(enabled = canWrite && job != null && workerId.isNotBlank(), onClick = {
        val result = repo.saveQualityRound(jobId, workerId, date, round.toIntOrNull() ?: 1, score.toIntOrNull() ?: -1, issue, checker)
        message = result.exceptionOrNull()?.message ?: "Raund saqlandi"
        if (result.isSuccess) refresh()
    }, modifier = Modifier.fillMaxWidth()) { Text("Raundni saqlash") }
    if (!message.isNullOrBlank()) Text(message!!, color = if (message == "Raund saqlandi") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
    HorizontalDivider()
    data.qualityRounds.filter { it.date == date }.sortedWith(compareBy({ it.machineId }, { it.round })).forEach { record ->
        val worker = data.workers.firstOrNull { it.id == record.workerId }?.name.orEmpty()
        val machine = data.machines.firstOrNull { it.id == record.machineId }?.number ?: 0
        TpCard { Text("$machine-stanok • $worker • ${record.round}-raund", fontWeight = FontWeight.Bold); Text("${record.score}% • ${record.issue.ifBlank { "Muammo yo‘q" }}") }
    }
}

@Composable
private fun TpDailyIssueForm(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    val brigades = data.brigades.filterNot { it.archived }
    var brigadeId by remember { mutableStateOf(brigades.firstOrNull()?.id.orEmpty()) }
    val machines = data.machines.filter { machine -> data.brigades.firstOrNull { it.id == brigadeId }?.shopId == machine.shopId }
    var machineId by remember(brigadeId) { mutableStateOf("") }
    var orderId by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var title by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    TpChoice("Brigada", brigadeId, brigades, { it.id }, { it.name }) { brigadeId = it }
    TpChoice("Stanok (ixtiyoriy)", machineId, listOf<TpMachine?>(null) + machines, { it?.id.orEmpty() }, { it?.let { machine -> "${machine.number}-stanok" } ?: "Belgilanmagan" }) { machineId = it }
    TpChoice("Partiya (ixtiyoriy)", orderId, listOf<TpOrder?>(null) + data.orders, { it?.id.orEmpty() }, { it?.let { order -> "${order.batchNumber} • ${order.articleSnapshot}" } ?: "Belgilanmagan" }) { orderId = it }
    TpField(date, { date = it }, "Sana (YYYY-MM-DD)")
    TpField(title, { title = it }, "Muammo nomi")
    TpField(note, { note = it }, "Batafsil izoh", singleLine = false)
    Button(enabled = canWrite && brigadeId.isNotBlank(), onClick = {
        val result = repo.addDailyIssue(brigadeId, date, machineId.ifBlank { null }, orderId.ifBlank { null }, title, note)
        message = result.exceptionOrNull()?.message ?: "Kun muammosi saqlandi"
        if (result.isSuccess) { title = ""; note = ""; refresh() }
    }, modifier = Modifier.fillMaxWidth()) { Text("Muammoni saqlash") }
    if (!message.isNullOrBlank()) Text(message!!, color = if (message!!.startsWith("Kun")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
    HorizontalDivider()
    data.dailyIssues.filter { it.date == date && (brigadeId.isBlank() || it.brigadeId == brigadeId) }.sortedByDescending { it.createdAt }.forEach { issue ->
        TpCard { Text(issue.title, fontWeight = FontWeight.Bold); Text(issue.note); Text(issue.createdAt.take(16).replace('T', ' '), style = MaterialTheme.typography.bodySmall) }
    }
}
