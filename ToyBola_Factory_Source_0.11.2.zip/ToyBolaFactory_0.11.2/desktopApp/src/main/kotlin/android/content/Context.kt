package android.content

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/** Minimal file-backed Android Context/SharedPreferences compatibility used by the shared repositories on Desktop. */
open class Context(
    private val rootDir: File = File(
        System.getenv("TOYBOLA_DATA_DIR")?.takeIf { it.isNotBlank() }
            ?: File(System.getProperty("user.home"), ".toybola-factory").absolutePath
    )
) {
    init { rootDir.mkdirs() }
    val applicationContext: Context get() = this

    fun getSharedPreferences(name: String, mode: Int): SharedPreferences =
        cache.computeIfAbsent(File(rootDir, "prefs_${sanitize(name)}.json").absolutePath) {
            SharedPreferences(File(it))
        }

    fun filesDir(): File = rootDir

    companion object {
        const val MODE_PRIVATE: Int = 0
        private val cache = ConcurrentHashMap<String, SharedPreferences>()
        private fun sanitize(value: String): String = value.replace(Regex("[^A-Za-z0-9._-]"), "_")
    }
}

class SharedPreferences internal constructor(private val file: File) {
    private val lock = Any()

    private fun readRoot(): JSONObject = synchronized(lock) {
        if (!file.exists()) return@synchronized JSONObject()
        runCatching { JSONObject(file.readText(Charsets.UTF_8)) }.getOrElse { JSONObject() }
    }

    fun getString(key: String, defaultValue: String?): String? = synchronized(lock) {
        val root = readRoot()
        if (!root.has(key) || root.isNull(key)) defaultValue else root.optString(key, defaultValue)
    }

    fun getStringSet(key: String, defaultValues: Set<String>?): Set<String>? = synchronized(lock) {
        val root = readRoot()
        val array = root.optJSONArray(key) ?: return@synchronized defaultValues
        buildSet {
            for (i in 0 until array.length()) add(array.optString(i))
        }
    }

    fun edit(): Editor = Editor(this)

    internal fun applyChanges(strings: Map<String, String?>, sets: Map<String, Set<String>?>): Boolean = synchronized(lock) {
        runCatching {
            val root = readRoot()
            strings.forEach { (key, value) -> if (value == null) root.remove(key) else root.put(key, value) }
            sets.forEach { (key, value) ->
                if (value == null) root.remove(key)
                else root.put(key, JSONArray().apply { value.sorted().forEach(::put) })
            }
            file.parentFile?.mkdirs()
            val tmp = File(file.parentFile, file.name + ".tmp")
            tmp.writeText(root.toString(), Charsets.UTF_8)
            if (file.exists()) file.delete()
            if (!tmp.renameTo(file)) {
                file.writeText(root.toString(), Charsets.UTF_8)
                tmp.delete()
            }
        }.isSuccess
    }

    class Editor internal constructor(private val prefs: SharedPreferences) {
        private val strings = linkedMapOf<String, String?>()
        private val sets = linkedMapOf<String, Set<String>?>()
        fun putString(key: String, value: String?): Editor = apply { strings[key] = value }
        fun putStringSet(key: String, value: Set<String>?): Editor = apply { sets[key] = value?.toSet() }
        fun apply() { prefs.applyChanges(strings, sets) }
        fun commit(): Boolean = prefs.applyChanges(strings, sets)
    }
}
