package uz.toybola.factory.desktop

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import uz.toybola.factory.core.data.AssemblyData
import uz.toybola.factory.core.data.AssemblyDataRepository
import uz.toybola.factory.core.data.TpData
import uz.toybola.factory.core.data.TpDataRepository
import uz.toybola.factory.core.firebase.FirebaseSyncScheduler
import java.time.Instant

enum class DesktopScreen(val title: String) {
    HOME("Bosh sahifa"),
    ASSEMBLY_BRIGADIR("Sborka • Brigadir"),
    ASSEMBLY_QUALITY("Sborka • Sifat"),
    ASSEMBLY_ISSUES("Sborka • Kun muammosi"),
    ASSEMBLY_MONITORING("Sborka • Monitoring"),
    ASSEMBLY_MASTER("Sborka • Ma’lumotlar"),
    TP_PLAN("01 • Plan"),
    TP_SERYO("02 • Seryo"),
    TP_RECEIVING("03 • Qabul"),
    TP_QUALITY("04 • Sifat"),
    TP_MONITORING("TP • Monitoring"),
    TP_MASTER("TP • Ma’lumotlar"),
    USERS("Foydalanuvchilar"),
    SYNC("Sync")
}

class DesktopAppState {
    val context = Context()
    val assemblyRepository = AssemblyDataRepository(context)
    val tpRepository = TpDataRepository(context)
    val gateway = FirebaseDesktopGateway(context)
    val syncService = DesktopSyncService(context, gateway, assemblyRepository, tpRepository)

    var session by mutableStateOf<DesktopAuthSession?>(null)
        private set
    var assemblyData by mutableStateOf(assemblyRepository.load())
        private set
    var tpData by mutableStateOf(tpRepository.load())
        private set
    var screen by mutableStateOf(DesktopScreen.HOME)
    var busy by mutableStateOf(false)
        private set
    var syncing by mutableStateOf(false)
        private set
    var message by mutableStateOf("")
    var error by mutableStateOf("")
    var lastSyncEpoch by mutableStateOf(0L)
        private set
    var syncRequested by mutableStateOf(false)
        private set

    init {
        FirebaseSyncScheduler.install { syncRequested = true }
    }

    val policy: DesktopPolicy? get() = session?.policy
    val pending: Int get() = syncService.pendingCount()

    suspend fun restoreSession() {
        busy = true
        runCatching { gateway.restore() }.onSuccess { restored ->
            session = restored
            refreshLocal()
            if (restored != null && !restored.offline) syncNow(silent = true)
            else if (restored?.offline == true) message = "Offline rejim: server ulanishi tiklanganda avtomatik sync bo‘ladi"
        }.onFailure { error = it.message ?: "Sessiyani tiklab bo‘lmadi" }
        busy = false
    }

    suspend fun login(deviceCode: String, userCode: String) {
        busy = true; error = ""; message = ""
        runCatching { gateway.login(deviceCode, userCode) }
            .onSuccess {
                session = it
                message = "Kirish muvaffaqiyatli"
                syncNow(silent = true)
            }
            .onFailure { error = friendly(it) }
        busy = false
    }

    fun logout() {
        gateway.logout()
        session = null
        screen = DesktopScreen.HOME
        message = ""
        error = ""
    }

    fun refreshLocal() {
        assemblyData = assemblyRepository.load()
        tpData = tpRepository.load()
    }

    fun applyMutation(result: Result<Unit>, success: String = "Saqlandi") {
        result.onSuccess {
            refreshLocal()
            message = success
            error = ""
            syncRequested = true
        }.onFailure {
            error = friendly(it)
        }
    }

    suspend fun syncNow(silent: Boolean = false) {
        if (session == null || syncing) return
        syncing = true
        if (!silent) { message = "Sync..."; error = "" }
        runCatching { syncService.sync() }
            .onSuccess { result ->
                refreshLocal()
                session = gateway.session ?: session
                lastSyncEpoch = Instant.now().epochSecond
                syncRequested = false
                message = result.message
                error = ""
            }
            .onFailure {
                error = if (silent) error else friendly(it)
            }
        syncing = false
    }

    suspend fun autoSyncLoop() {
        while (true) {
            delay(4000)
            val active = session ?: continue
            if (active.offline || syncRequested || Instant.now().epochSecond - lastSyncEpoch >= 20) {
                syncNow(silent = true)
            }
        }
    }

    fun canRead(permission: String): Boolean = policy?.let { it.isAdmin() || it.hasPermission(permission) } == true
    fun canWrite(permission: String): Boolean = canRead(permission)

    fun visible(screen: DesktopScreen): Boolean {
        val p = policy ?: return false
        if (p.isAdmin()) return true
        return when (screen) {
            DesktopScreen.HOME, DesktopScreen.SYNC -> true
            DesktopScreen.ASSEMBLY_BRIGADIR -> p.hasPermission("BRIGADIR_READ")
            DesktopScreen.ASSEMBLY_QUALITY -> p.hasPermission("QUALITY_READ")
            DesktopScreen.ASSEMBLY_ISSUES -> p.hasPermission("DAILY_ISSUE_READ")
            DesktopScreen.ASSEMBLY_MONITORING -> p.hasPermission("MONITORING_READ")
            DesktopScreen.ASSEMBLY_MASTER -> p.hasPermission("MASTER_DATA_READ")
            DesktopScreen.TP_PLAN -> listOf("TP_ORDER_READ", "TP_PLANNING_READ", "TP_MACHINE_READ", "TP_ATTENDANCE_READ").any(p::hasPermission)
            DesktopScreen.TP_SERYO -> p.hasPermission("TP_SERYO_READ")
            DesktopScreen.TP_RECEIVING -> p.hasPermission("TP_RECEIVING_READ")
            DesktopScreen.TP_QUALITY -> p.hasPermission("TP_QUALITY_READ")
            DesktopScreen.TP_MONITORING -> p.hasPermission("TP_MONITORING_READ")
            DesktopScreen.TP_MASTER -> p.hasPermission("TP_MASTER_DATA_READ")
            DesktopScreen.USERS -> p.isAdmin()
        }
    }

    private fun friendly(error: Throwable): String {
        val text = error.message.orEmpty()
        return when {
            text.contains("PERMISSION", true) || text.contains("permission", true) -> "Ruxsat yetarli emas: $text"
            text.contains("network", true) || text.contains("HTTP", true) || text.contains("Connect", true) -> "Serverga ulanishda muammo: $text"
            text.isBlank() -> "Noma’lum xato"
            else -> text
        }
    }
}
