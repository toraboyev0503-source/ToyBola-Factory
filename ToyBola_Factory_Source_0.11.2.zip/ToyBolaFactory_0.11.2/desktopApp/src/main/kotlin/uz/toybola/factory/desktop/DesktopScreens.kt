package uz.toybola.factory.desktop

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import uz.toybola.factory.core.data.*
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.roundToLong

@Composable
fun HomeScreen(state: DesktopAppState) {
    val a = state.assemblyData
    val t = state.tpData
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Ish holati", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("Sborka ishchilar", a.workers.count { !it.archived }.toString(), Modifier.weight(1f))
            MetricCard("TP ishchilar", t.workers.count { !it.archived }.toString(), Modifier.weight(1f))
            MetricCard("Faol stanok", t.machines.count { !it.archived }.toString(), Modifier.weight(1f))
            MetricCard("Pending sync", state.pending.toString(), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("Ochiq zakaz", t.orders.count { it.status !in setOf(TpOrderStatus.COMPLETE, TpOrderStatus.CANCELLED) }.toString(), Modifier.weight(1f))
            MetricCard("Jarayondagi vazifa", t.jobs.count { it.status == TpJobStatus.IN_PROGRESS }.toString(), Modifier.weight(1f))
            MetricCard("Seryo vazifa", t.jobs.count { it.materialStatus != TpMaterialStatus.DELIVERED && t.orders.firstOrNull { o -> o.id == it.orderId }?.planApprovedAt != null }.toString(), Modifier.weight(1f))
            MetricCard("Bugungi muammo", (a.dailyIssues.count { it.date == LocalDate.now().toString() } + t.dailyIssues.count { it.date == LocalDate.now().toString() }).toString(), Modifier.weight(1f))
        }
        SectionCard("Windows ↔ Android") {
            Text("Windows client Android bilan aynan bir Firebase loyiha, bir xil User Code/Device Code va bir xil server snapshotlardan foydalanadi.")
            Text("Lokal o‘zgarishlar outboxga tushadi; internet qaytganda avtomatik serverga yuboriladi.")
            Text("Oxirgi sync: ${formatEpoch(state.lastSyncEpoch)}")
        }
    }
}

@Composable
fun SyncScreen(state: DesktopAppState) {
    val scope = rememberCoroutineScope()
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Sinxronizatsiya", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("Sborka pending", state.syncService.assemblyPending().toString(), Modifier.width(200.dp))
            MetricCard("TP pending", state.syncService.tpPending().toString(), Modifier.width(200.dp))
            MetricCard("Jami", state.pending.toString(), Modifier.width(200.dp))
        }
        Button(onClick = { scope.launch { state.syncNow() } }, enabled = !state.syncing) {
            Text(if (state.syncing) "Sync qilinmoqda..." else "Hozir sync qilish")
        }
        Text("Auto-sync: lokal o‘zgarish bo‘lganda navbatga tushadi va fon tekshiruvida serverga yuboriladi.")
        Text("Oxirgi muvaffaqiyatli sync: ${formatEpoch(state.lastSyncEpoch)}")
    }
}

@Composable
fun AssemblyMonitoringScreen(state: DesktopAppState) {
    val data = state.assemblyData
    val today = LocalDate.now().toString()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Sborka monitoring", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("Brigadalar", data.brigades.count { !it.archived && !it.deleted }.toString(), Modifier.weight(1f))
            MetricCard("Ishchilar", data.workers.count { !it.archived }.toString(), Modifier.weight(1f))
            MetricCard("Bugungi yozuv", data.workerDays.count { it.date == today }.toString(), Modifier.weight(1f))
            MetricCard("Bugungi muammo", data.dailyIssues.count { it.date == today }.toString(), Modifier.weight(1f))
        }
        SectionCard("Brigadalar") {
            data.brigades.filter { !it.archived && !it.deleted }.forEach { brigade ->
                val workers = data.activeWorkers(brigade.id)
                val avg = workers.mapNotNull { data.workerFinalResult(it.id, today) }.takeIf { it.isNotEmpty() }?.average()
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Text(brigade.name, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                    Text("${workers.size} ishchi")
                    Spacer(Modifier.width(20.dp))
                    Text(avg?.let { "%.1f%%".format(it) } ?: "—")
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun TpMonitoringScreen(state: DesktopAppState) {
    val data = state.tpData
    val today = LocalDate.now().toString()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("TP / Seryo monitoring", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("Ochiq zakaz", data.orders.count { it.status !in setOf(TpOrderStatus.COMPLETE, TpOrderStatus.CANCELLED) }.toString(), Modifier.weight(1f))
            MetricCard("Navbatdagi vazifa", data.jobs.count { it.status == TpJobStatus.QUEUED }.toString(), Modifier.weight(1f))
            MetricCard("Quyilmoqda", data.jobs.count { it.status == TpJobStatus.IN_PROGRESS }.toString(), Modifier.weight(1f))
            MetricCard("Tugagan", data.jobs.count { it.status == TpJobStatus.COMPLETE }.toString(), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("Bugun seryo rasxod", formatTpNumber(data.materials.filter { it.type == TpMaterialType.RESIN }.sumOf { it.dayOutgoing(today) }) + " kg", Modifier.weight(1f))
            MetricCard("Bugun krasitel rasxod", formatTpNumber(data.materials.filter { it.type == TpMaterialType.COLOR }.sumOf { it.dayOutgoing(today) }) + " g", Modifier.weight(1f))
            MetricCard("Qabul", data.receipts.count { it.date == today }.toString(), Modifier.weight(1f))
            MetricCard("Sifat", data.qualityRounds.count { it.date == today }.toString(), Modifier.weight(1f))
        }
        SectionCard("Stanok holati") {
            data.machines.filter { !it.archived }.sortedBy { it.number }.forEach { machine ->
                val current = data.jobs.filter { it.machineId == machine.id && it.status in setOf(TpJobStatus.IN_PROGRESS, TpJobStatus.QUEUED) }
                    .minByOrNull { it.priority }
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Text("Stanok ${machine.number} • ${machine.capacity}", Modifier.width(180.dp), fontWeight = FontWeight.Medium)
                    Text(current?.let { "${it.moldCode} • ${it.colorCode} • ${it.status.name}" } ?: "Bo‘sh")
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(label, style = MaterialTheme.typography.labelLarge)
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            HorizontalDivider()
            content()
        }
    }
}

@Composable
private fun <T> ChoiceButton(label: String, value: T?, options: List<T>, text: (T) -> String, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(value?.let(text) ?: label, maxLines = 1)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(text = { Text(text(option)) }, onClick = { onSelect(option); expanded = false })
            }
        }
    }
}

private fun formatEpoch(epoch: Long): String = if (epoch <= 0) "—" else runCatching {
    LocalDateTime.ofEpochSecond(epoch, 0, java.time.ZoneOffset.ofHours(5)).format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss"))
}.getOrDefault("—")

// -------------------- TP PLAN --------------------

@Composable
fun TpPlanScreen(state: DesktopAppState) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("Nachalnik zakaz") })
            FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("Plan beruvchi") })
            FilterChip(selected = tab == 2, onClick = { tab = 2 }, label = { Text("Stanok navbati") })
            FilterChip(selected = tab == 3, onClick = { tab = 3 }, label = { Text("Davomat") })
        }
        when (tab) {
            0 -> TpOrderList(state)
            1 -> TpPlanner(state)
            2 -> TpMachineBoard(state)
            else -> TpAttendanceScreen(state)
        }
    }
}

@Composable
private fun TpOrderList(state: DesktopAppState) {
    val data = state.tpData
    val canWrite = state.policy?.hasPermission("TP_ORDER_WRITE") == true || state.policy?.isAdmin() == true
    var showCreate by remember { mutableStateOf(false) }
    var editOrder by remember { mutableStateOf<TpOrder?>(null) }
    var search by remember { mutableStateOf("") }
    val orders = data.orders.filter { search.isBlank() || it.articleSnapshot.contains(search, true) || it.productNameSnapshot.contains(search, true) || it.batchNumber.contains(search, true) }
        .sortedWith(compareBy<TpOrder> { it.priority }.thenByDescending { it.createdAt })

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(search, { search = it }, label = { Text("Qidiruv") }, singleLine = true, modifier = Modifier.width(320.dp))
            Spacer(Modifier.weight(1f))
            if (canWrite) Button(onClick = { showCreate = true }) { Text("+ Yangi zakaz") }
        }
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(orders, key = { it.id }) { order ->
                Card(Modifier.fillMaxWidth(), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        PriorityPill(order.priority)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${order.batchNumber} • ${order.articleSnapshot} ${order.productNameSnapshot}", fontWeight = FontWeight.Bold)
                            Text("${order.quantity} dona • ${order.createdAt.take(16).replace('T',' ')} • ${order.status.name}")
                            val forecast = data.orderForecastMinutes(order.id)
                            if (forecast > 0) Text("Prognoz: ~${forecast / 60} soat ${forecast % 60} daqiqa", style = MaterialTheme.typography.bodySmall)
                        }
                        if (canWrite && order.planApprovedAt == null) {
                            TextButton(onClick = { editOrder = order }) { Text("Tahrirlash") }
                            TextButton(onClick = { state.applyMutation(state.tpRepository.deleteOrder(order.id), "Zakaz o‘chirildi") }) { Text("O‘chirish") }
                        }
                    }
                }
            }
        }
    }
    if (showCreate) OrderDialog(state, null, onDismiss = { showCreate = false })
    editOrder?.let { OrderDialog(state, it, onDismiss = { editOrder = null }) }
}

@Composable
private fun PriorityPill(priority: Int) {
    val label = tpPriorityLabel(priority)
    AssistChip(onClick = {}, label = { Text(label) })
}

@Composable
private fun OrderDialog(state: DesktopAppState, existing: TpOrder?, onDismiss: () -> Unit) {
    val products = state.tpData.products.filter { !it.archived }
    var product by remember(existing?.id) { mutableStateOf(products.firstOrNull { it.id == existing?.productId } ?: products.firstOrNull()) }
    var quantity by remember(existing?.id) { mutableStateOf(existing?.quantity?.toString().orEmpty()) }
    var priority by remember(existing?.id) { mutableStateOf(existing?.priority ?: 2) }
    var note by remember(existing?.id) { mutableStateOf(existing?.note.orEmpty()) }
    var firstBatch by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Yangi zakaz" else "Zakazni tahrirlash") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ChoiceButton("Mahsulot", product, products, { "${it.article} • ${it.name}" }, { product = it })
                OutlinedTextField(quantity, { quantity = it.filter(Char::isDigit) }, label = { Text("Miqdor") }, singleLine = true)
                if (existing == null && state.tpData.orders.isEmpty()) OutlinedTextField(firstBatch, { firstBatch = it }, label = { Text("Birinchi partiya raqami") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1 to "Eng zaril", 2 to "Zaril", 3 to "Keyinroq").forEach { (p, label) ->
                        FilterChip(selected = priority == p, onClick = { priority = p }, label = { Text(label) })
                    }
                }
                OutlinedTextField(note, { note = it }, label = { Text("Izoh") }, minLines = 2)
            }
        },
        confirmButton = {
            Button(onClick = {
                val productId = product?.id ?: return@Button
                val result = if (existing == null) state.tpRepository.createOrder(firstBatch, productId, quantity.toIntOrNull() ?: 0, priority, note)
                else state.tpRepository.updateOrder(existing.id, productId, quantity.toIntOrNull() ?: 0, priority, note)
                state.applyMutation(result, "Zakaz saqlandi")
                if (result.isSuccess) onDismiss()
            }) { Text("Saqlash") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor") } }
    )
}

@Composable
private fun TpPlanner(state: DesktopAppState) {
    val data = state.tpData
    val canWrite = state.policy?.let { it.isAdmin() || it.hasPermission("TP_PLANNING_WRITE") } == true
    var selectedId by remember { mutableStateOf<String?>(null) }
    val pending = data.orders.filter { it.planApprovedAt == null }.sortedWith(compareBy<TpOrder> { it.priority }.thenBy { it.createdAt })
    val approved = data.orders.filter { it.planApprovedAt != null }.sortedBy { it.planApprovedAt }
    val selected = data.orders.firstOrNull { it.id == selectedId }

    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(Modifier.width(360.dp).fillMaxHeight()) {
            LazyColumn(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                item { Text("TASDIQLANMAGAN", fontWeight = FontWeight.Bold); HorizontalDivider() }
                items(pending, key = { it.id }) { order -> OrderNavRow(order, selectedId == order.id) { selectedId = order.id } }
                item { Spacer(Modifier.height(12.dp)); HorizontalDivider(); Text("TASDIQLANGAN", fontWeight = FontWeight.Bold); HorizontalDivider() }
                items(approved, key = { it.id }) { order -> OrderNavRow(order, selectedId == order.id) { selectedId = order.id } }
            }
        }
        Card(Modifier.weight(1f).fillMaxHeight()) {
            if (selected == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Zakazni tanlang") }
            else PlannerDetail(state, selected, canWrite)
        }
    }
}

@Composable
private fun OrderNavRow(order: TpOrder, selected: Boolean, onClick: () -> Unit) {
    Surface(tonalElevation = if (selected) 4.dp else 0.dp, modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(8.dp)) {
            Text("${order.batchNumber} • ${order.articleSnapshot}", fontWeight = FontWeight.Medium)
            Text("${order.quantity} dona • ${tpPriorityLabel(order.priority)}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun PlannerDetail(state: DesktopAppState, order: TpOrder, canWrite: Boolean) {
    val data = state.tpData
    val jobs = data.jobs.filter { it.orderId == order.id }.sortedWith(compareBy<TpPlanJob> { it.moldCode }.thenBy { it.priority })
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("${order.batchNumber} • ${order.articleSnapshot} ${order.productNameSnapshot}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("${order.quantity} dona • ${tpPriorityLabel(order.priority)} • ${order.createdAt.take(16).replace('T',' ')}")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (jobs.isEmpty() && canWrite && order.planApprovedAt == null) Button(onClick = { state.applyMutation(state.tpRepository.generateOrderPlan(order.id), "Plan hisoblandi") }) { Text("Plan hisobini yaratish") }
            if (jobs.isNotEmpty() && canWrite && order.planApprovedAt == null) Button(onClick = { state.applyMutation(state.tpRepository.approveOrderPlan(order.id), "Plan jarayonga topshirildi") }) { Text("Jarayonni boshlash") }
            if (order.planApprovedAt != null) AssistChip(onClick = {}, label = { Text("Tasdiqlangan ${order.planApprovedAt.take(16).replace('T',' ')}") })
        }
        HorizontalDivider()
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(jobs, key = { it.id }) { job -> PlannerJobRow(state, order, job, canWrite) }
        }
    }
}

@Composable
private fun PlannerJobRow(state: DesktopAppState, order: TpOrder, job: TpPlanJob, canWrite: Boolean) {
    val data = state.tpData
    val machine = data.machines.firstOrNull { it.id == job.machineId }
    var assign by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth(), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("${job.moldCode} • rang ${job.colorCode}", fontWeight = FontWeight.Bold)
                Text("${job.outputs.joinToString { "${it.detailName}: ${it.requiredPieces}" }}")
                Text("${job.requiredShots} jim • ${job.estimatedMinutes} min • seryo ${job.resinCode} ${formatTpNumber(job.requiredResinKg)} kg")
            }
            Text(machine?.let { "Stanok ${it.number}" } ?: "Stanok —", fontWeight = FontWeight.Medium)
            if (machine != null && data.machineAvailabilityMinutes(machine.id, order.id) > 0) Text(" • ~${data.machineAvailabilityMinutes(machine.id, order.id)} min keyin")
            if (canWrite && order.planApprovedAt == null) {
                Spacer(Modifier.width(8.dp)); OutlinedButton(onClick = { assign = true }) { Text("Tanlash") }
            }
        }
    }
    if (assign) AssignMachineDialog(state, job, onDismiss = { assign = false })
}

@Composable
private fun AssignMachineDialog(state: DesktopAppState, job: TpPlanJob, onDismiss: () -> Unit) {
    val data = state.tpData
    val machines = data.machines.filter { !it.archived && job.acceptsMachine(it, data) }.sortedWith(compareBy<TpMachine> { data.machineAvailabilityMinutes(it.id, job.orderId) }.thenBy { it.number })
    var machine by remember { mutableStateOf(machines.firstOrNull()) }
    val brigades = machine?.let { m -> data.brigades.filter { !it.archived && it.shopId == m.shopId } }.orEmpty()
    var brigade by remember(machine?.id) { mutableStateOf(brigades.firstOrNull()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Stanok va brigada") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ChoiceButton("Stanok", machine, machines, {
                    val wait = data.machineAvailabilityMinutes(it.id, job.orderId)
                    "${it.number} • ${it.capacity} • ${if (wait == 0) "bo‘sh" else "$wait min"}"
                }, { machine = it; brigade = data.brigades.firstOrNull { b -> !b.archived && b.shopId == it.shopId } })
                ChoiceButton("Brigada", brigade, machine?.let { m -> data.brigades.filter { !it.archived && it.shopId == m.shopId } }.orEmpty(), { it.name }, { brigade = it })
            }
        },
        confirmButton = {
            Button(onClick = {
                val m = machine ?: return@Button; val b = brigade ?: return@Button
                val result = state.tpRepository.assignJob(job.id, m.id, b.id, job.priority)
                state.applyMutation(result, "Stanok biriktirildi")
                if (result.isSuccess) onDismiss()
            }) { Text("Tanlash") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor") } }
    )
}

@Composable
private fun TpMachineBoard(state: DesktopAppState) {
    val data = state.tpData
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items(data.machines.filter { !it.archived }.sortedBy { it.number }, key = { it.id }) { machine ->
            val jobs = data.jobs.filter { it.machineId == machine.id && it.status != TpJobStatus.COMPLETE }.sortedBy { it.priority }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Stanok ${machine.number} • sig‘im ${machine.capacity}", fontWeight = FontWeight.Bold)
                    if (jobs.isEmpty()) Text("Bo‘sh") else jobs.forEachIndexed { index, job -> Text("${index + 1}. ${job.moldCode} • ${job.colorCode} • ${job.status.name}") }
                }
            }
        }
    }
}

@Composable
private fun TpAttendanceScreen(state: DesktopAppState) {
    val data = state.tpData
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var brigade by remember { mutableStateOf(data.brigades.firstOrNull { !it.archived }) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceButton("Brigada", brigade, data.brigades.filter { !it.archived }, { it.name }, { brigade = it }, Modifier.width(260.dp))
            OutlinedTextField(date, { date = it }, label = { Text("Sana") }, singleLine = true, modifier = Modifier.width(180.dp))
        }
        brigade?.let { b ->
            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                items(data.workers.filter { !it.archived && it.brigadeId == b.id }, key = { it.id }) { worker ->
                    val current = data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }
                    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(worker.name, Modifier.weight(1f))
                        Text(current?.let { if (it.present) "${it.workMinutes} min" else "Ishlamadi" } ?: "—")
                        if (state.policy?.let { it.isAdmin() || it.hasPermission("TP_ATTENDANCE_WRITE") } == true) {
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = { state.applyMutation(state.tpRepository.setAttendance(worker.id, date, true, worker.defaultWorkMinutes), "Davomat saqlandi") }) { Text("Ishladi") }
                            Spacer(Modifier.width(6.dp))
                            OutlinedButton(onClick = { state.applyMutation(state.tpRepository.setAttendance(worker.id, date, false, 0), "Davomat saqlandi") }) { Text("Ishlamadi") }
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

// -------------------- TP SERYO --------------------

@Composable
fun TpSeryoScreen(state: DesktopAppState) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Buyurtma", "Ostatka", "Monitoring").forEachIndexed { i, title -> FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(title) }) }
        }
        when (tab) {
            0 -> TpSeryoOrders(state)
            1 -> TpStockScreen(state)
            else -> TpSeryoMonitoring(state)
        }
    }
}

@Composable
private fun TpSeryoOrders(state: DesktopAppState) {
    val data = state.tpData
    val canWrite = state.policy?.let { it.isAdmin() || it.hasPermission("TP_SERYO_WRITE") } == true
    val approved = data.orders.filter { it.planApprovedAt != null }.map { it.id }.toSet()
    val jobs = data.jobs.filter { it.orderId in approved && it.materialStatus != TpMaterialStatus.DELIVERED }.sortedBy { it.priority }
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items(jobs, key = { it.id }) { job ->
            val order = data.orders.firstOrNull { it.id == job.orderId }
            val machine = data.machines.firstOrNull { it.id == job.machineId }
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${order?.batchNumber ?: ""} • ${job.moldCode} • ${job.colorCode}", fontWeight = FontWeight.Bold)
                        Text("Stanok ${machine?.number ?: "—"} • ${job.resinCode}: ${formatTpNumber(job.requiredResinKg)} kg • krasitel ${formatTpNumber(job.requiredColorGrams)} g")
                        Text("Holat: ${job.materialStatus.name}")
                    }
                    if (canWrite && job.materialStatus == TpMaterialStatus.PLANNED) Button(onClick = { state.applyMutation(state.tpRepository.confirmMaterial(job.id, false), "Seryo tasdiqlandi") }) { Text("Tasdiqlash") }
                    if (canWrite && job.materialStatus != TpMaterialStatus.DELIVERED) {
                        Spacer(Modifier.width(8.dp)); OutlinedButton(onClick = { state.applyMutation(state.tpRepository.confirmMaterial(job.id, true), "Stanokka chiqarildi") }) { Text("Stanokka chiqdi") }
                    }
                }
            }
        }
    }
}

@Composable
private fun TpStockScreen(state: DesktopAppState) {
    var subTab by remember { mutableStateOf(2) }
    var type by remember { mutableStateOf(TpMaterialType.RESIN) }
    var search by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var sortMode by remember { mutableStateOf(0) }
    var sortAscending by remember { mutableStateOf(true) }
    var movementMaterial by remember { mutableStateOf<TpMaterial?>(null) }
    var movementKind by remember { mutableStateOf(TpMaterialMovementKind.IN) }
    val data = state.tpData
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Rasxod", "Prixod", "Ostatka").forEachIndexed { i, title -> FilterChip(selected = subTab == i, onClick = { subTab = i }, label = { Text(title) }) }
        }
        if (subTab == 2) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = type == TpMaterialType.RESIN, onClick = { type = TpMaterialType.RESIN }, label = { Text("Seryo") })
                FilterChip(selected = type == TpMaterialType.COLOR, onClick = { type = TpMaterialType.COLOR }, label = { Text("Krasitel") })
                OutlinedTextField(search, { search = it }, label = { Text("Qidiruv") }, singleLine = true, modifier = Modifier.width(220.dp))
                OutlinedTextField(date, { date = it }, label = { Text("Sana") }, singleLine = true, modifier = Modifier.width(160.dp))
                listOf("Kod", "Prixod", "Rasxod", "Ostatka").forEachIndexed { index, label ->
                    FilterChip(selected = sortMode == index, onClick = { sortMode = index }, label = { Text(label) })
                }
                OutlinedButton(onClick = { sortAscending = !sortAscending }) { Text(if (sortAscending) "↑" else "↓") }
            }
            val filtered = data.materials.filter { !it.archived && it.type == type && (search.isBlank() || it.code.contains(search, true)) }
            val sorted = when (sortMode) {
                1 -> filtered.sortedBy { it.dayIncoming(date) }
                2 -> filtered.sortedBy { it.dayOutgoing(date) }
                3 -> filtered.sortedBy { it.closingStock(date) }
                else -> filtered.sortedBy { it.code }
            }.let { if (sortAscending) it else it.reversed() }
            StockTable(sorted, date)
        } else {
            movementKind = if (subTab == 0) TpMaterialMovementKind.OUT else TpMaterialMovementKind.IN
            val materials = data.materials.filter { !it.archived }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (subTab == 0) "Qo‘lda rasxod" else "Yangi prixod", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                if (state.policy?.let { it.isAdmin() || it.hasPermission("TP_SERYO_WRITE") } == true) Button(onClick = { movementMaterial = materials.firstOrNull() }) { Text("+ Kiritish") }
            }
            val movements = materials.flatMap { material -> material.movements.map { material to it } }
                .filter { it.second.kind == movementKind }
                .sortedByDescending { it.second.createdAt }
            LazyColumn(Modifier.fillMaxSize()) {
                items(movements, key = { it.second.id }) { (material, move) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text(move.createdAt.take(16).replace('T',' '), Modifier.width(160.dp))
                        Text(material.code, Modifier.width(120.dp), fontWeight = FontWeight.Medium)
                        Text(formatTpNumber(move.amount), Modifier.width(120.dp))
                        Text(move.note, Modifier.weight(1f))
                    }
                    HorizontalDivider()
                }
            }
        }
    }
    movementMaterial?.let { MaterialMovementDialog(state, movementKind, it, onDismiss = { movementMaterial = null }) }
}

@Composable
private fun StockTable(materials: List<TpMaterial>, date: String) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(Modifier.fillMaxWidth().padding(8.dp)) {
                Text("#", Modifier.width(50.dp), fontWeight = FontWeight.Bold)
                Text("Kod", Modifier.width(150.dp), fontWeight = FontWeight.Bold)
                Text("Prixod", Modifier.width(140.dp), fontWeight = FontWeight.Bold)
                Text("Rasxod", Modifier.width(140.dp), fontWeight = FontWeight.Bold)
                Text("Ostatka", Modifier.width(160.dp), fontWeight = FontWeight.Bold)
            }
            HorizontalDivider()
        }
        items(materials.size) { index ->
            val item = materials[index]
            Row(Modifier.fillMaxWidth().padding(8.dp)) {
                Text((index + 1).toString(), Modifier.width(50.dp))
                Text(item.code, Modifier.width(150.dp))
                Text(formatTpNumber(item.dayIncoming(date)), Modifier.width(140.dp))
                Text(formatTpNumber(item.dayOutgoing(date)), Modifier.width(140.dp))
                Text(formatTpNumber(item.closingStock(date)), Modifier.width(160.dp), fontWeight = FontWeight.Bold)
            }
            HorizontalDivider()
        }
    }
}

@Composable
private fun MaterialMovementDialog(state: DesktopAppState, kind: TpMaterialMovementKind, initial: TpMaterial, onDismiss: () -> Unit) {
    val materials = state.tpData.materials.filter { !it.archived }
    var material by remember { mutableStateOf(initial) }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (kind == TpMaterialMovementKind.IN) "Prixod" else "Rasxod") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ChoiceButton("Kod", material, materials, { "${it.code} • ${if (it.type == TpMaterialType.RESIN) "Seryo" else "Krasitel"}" }, { material = it })
            OutlinedTextField(amount, { amount = decimalInput(it) }, label = { Text(if (material.type == TpMaterialType.RESIN) "Kg" else "Gramm") }, singleLine = true)
            OutlinedTextField(note, { note = it }, label = { Text("Izoh") })
        }
    }, confirmButton = {
        Button(onClick = {
            val result = state.tpRepository.addMaterialMovement(material.code, material.type, amount.replace(',', '.').toDoubleOrNull() ?: 0.0, kind == TpMaterialMovementKind.IN, note)
            state.applyMutation(result, if (kind == TpMaterialMovementKind.IN) "Prixod saqlandi" else "Rasxod saqlandi")
            if (result.isSuccess) onDismiss()
        }) { Text("Saqlash") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor") } })
}

@Composable
private fun TpSeryoMonitoring(state: DesktopAppState) {
    val data = state.tpData
    val today = LocalDate.now().toString()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Kutilayotgan", data.jobs.count { it.materialStatus == TpMaterialStatus.PLANNED && data.orders.firstOrNull { o -> o.id == it.orderId }?.planApprovedAt != null }.toString(), Modifier.weight(1f))
            MetricCard("Tasdiqlangan", data.jobs.count { it.materialStatus == TpMaterialStatus.CONFIRMED }.toString(), Modifier.weight(1f))
            MetricCard("Stanokka chiqarilgan", data.jobs.count { it.materialStatus == TpMaterialStatus.DELIVERED }.toString(), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Bugun seryo prixod", formatTpNumber(data.materials.filter { it.type == TpMaterialType.RESIN }.sumOf { it.dayIncoming(today) }), Modifier.weight(1f))
            MetricCard("Bugun seryo rasxod", formatTpNumber(data.materials.filter { it.type == TpMaterialType.RESIN }.sumOf { it.dayOutgoing(today) }), Modifier.weight(1f))
            MetricCard("Yetishmayotgan kod", data.jobs.count { job -> job.materialStatus != TpMaterialStatus.DELIVERED && data.materialStock(TpMaterialType.RESIN, job.resinCode) < job.requiredResinKg }.toString(), Modifier.weight(1f))
        }
    }
}

// -------------------- TP QABUL / SIFAT --------------------

@Composable
fun TpReceivingScreen(state: DesktopAppState) {
    val data = state.tpData
    val jobs = data.jobs.filter { data.orders.firstOrNull { o -> o.id == it.orderId }?.planApprovedAt != null && it.machineId != null && it.status != TpJobStatus.COMPLETE }.sortedBy { it.priority }
    var receiptJob by remember { mutableStateOf<TpPlanJob?>(null) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Qabul qilinadigan vazifalar", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(jobs, key = { it.id }) { job ->
                val machine = data.machines.firstOrNull { it.id == job.machineId }
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Stanok ${machine?.number ?: "—"} • ${job.moldCode} • ${job.colorCode}", fontWeight = FontWeight.Bold)
                            Text(job.outputs.joinToString { "${it.detailName} ${it.requiredPieces}" })
                        }
                        if (state.policy?.let { it.isAdmin() || it.hasPermission("TP_RECEIVING_WRITE") } == true) Button(onClick = { receiptJob = job }) { Text("Qabul yozish") }
                    }
                }
            }
        }
    }
    receiptJob?.let { ReceiptDialog(state, it, onDismiss = { receiptJob = null }) }
}

@Composable
private fun ReceiptDialog(state: DesktopAppState, job: TpPlanJob, onDismiss: () -> Unit) {
    val data = state.tpData
    var output by remember { mutableStateOf(job.outputs.firstOrNull()) }
    val workers = job.brigadeId?.let { id -> data.workers.filter { !it.archived && it.brigadeId == id } }.orEmpty()
    var worker by remember { mutableStateOf(workers.firstOrNull()) }
    var bags by remember { mutableStateOf("0") }
    var remainder by remember { mutableStateOf("0") }
    var receiver by remember { mutableStateOf(state.policy?.displayName.orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Qabul") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            ChoiceButton("Detal", output, job.outputs, { "${it.detailName} • qop ${it.bagCapacity}" }, { output = it })
            ChoiceButton("Ishchi", worker, workers, { it.name }, { worker = it })
            OutlinedTextField(bags, { bags = it.filter(Char::isDigit) }, label = { Text("To‘liq qop") })
            OutlinedTextField(remainder, { remainder = it.filter(Char::isDigit) }, label = { Text("Ochiq qopdagi yakuniy dona") })
            OutlinedTextField(receiver, { receiver = it }, label = { Text("Qabul qiluvchi") })
            output?.let { Text("Oldingi ochiq qop: ${data.openRemainder(job.id, it.detailId)}/${it.bagCapacity}") }
        }
    }, confirmButton = {
        Button(onClick = {
            val o = output ?: return@Button; val w = worker ?: return@Button
            val result = state.tpRepository.addReceipt(job.id, o.detailId, w.id, LocalDate.now().toString(), bags.toIntOrNull() ?: 0, remainder.toIntOrNull() ?: 0, receiver)
            state.applyMutation(result, "Qabul saqlandi")
            if (result.isSuccess) onDismiss()
        }) { Text("Saqlash") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor") } })
}

@Composable
fun TpQualityScreen(state: DesktopAppState) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("Raund") })
            FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("Kun muammosi") })
        }
        if (tab == 0) TpQualityRounds(state) else TpQualityIssues(state)
    }
}

@Composable
private fun TpQualityRounds(state: DesktopAppState) {
    val data = state.tpData
    val jobs = data.jobs.filter { it.machineId != null && it.brigadeId != null && it.status in setOf(TpJobStatus.QUEUED, TpJobStatus.IN_PROGRESS) }
    var target by remember { mutableStateOf<TpPlanJob?>(null) }
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items(jobs, key = { it.id }) { job ->
            val machine = data.machines.firstOrNull { it.id == job.machineId }
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Stanok ${machine?.number ?: "—"} • ${job.moldCode} • ${job.colorCode}", Modifier.weight(1f))
                    if (state.policy?.let { it.isAdmin() || it.hasPermission("TP_QUALITY_WRITE") } == true) Button(onClick = { target = job }) { Text("Tekshirish") }
                }
            }
        }
    }
    target?.let { TpQualityDialog(state, it, onDismiss = { target = null }) }
}

@Composable
private fun TpQualityDialog(state: DesktopAppState, job: TpPlanJob, onDismiss: () -> Unit) {
    val data = state.tpData
    val workers = job.brigadeId?.let { id -> data.workers.filter { !it.archived && it.brigadeId == id } }.orEmpty()
    var worker by remember { mutableStateOf(workers.firstOrNull()) }
    var round by remember { mutableStateOf(1) }
    var score by remember { mutableStateOf("100") }
    var issue by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Sifat raundi") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceButton("Ishchi", worker, workers, { it.name }, { worker = it })
            OutlinedTextField(round.toString(), { round = it.toIntOrNull()?.coerceAtLeast(1) ?: 1 }, label = { Text("Raund") })
            OutlinedTextField(score, { score = it.filter(Char::isDigit) }, label = { Text("Baho 0–100") })
            OutlinedTextField(issue, { issue = it }, label = { Text("Muammo/izoh") })
        }
    }, confirmButton = {
        Button(onClick = {
            val w = worker ?: return@Button
            val result = state.tpRepository.saveQualityRound(job.id, w.id, LocalDate.now().toString(), round, score.toIntOrNull() ?: 0, issue, state.policy?.displayName.orEmpty())
            state.applyMutation(result, "Sifat saqlandi")
            if (result.isSuccess) onDismiss()
        }) { Text("Saqlash") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor") } })
}

@Composable
private fun TpQualityIssues(state: DesktopAppState) {
    val data = state.tpData
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row {
            Text("Kun muammolari", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            if (state.policy?.let { it.isAdmin() || it.hasPermission("TP_QUALITY_WRITE") } == true) Button(onClick = { show = true }) { Text("+ Muammo") }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            items(data.dailyIssues.sortedByDescending { it.createdAt }, key = { it.id }) { issue ->
                Row(Modifier.fillMaxWidth().padding(8.dp)) {
                    Text(issue.date, Modifier.width(110.dp)); Text(issue.title, Modifier.width(220.dp), fontWeight = FontWeight.Medium); Text(issue.note, Modifier.weight(1f))
                }; HorizontalDivider()
            }
        }
    }
    if (show) TpIssueDialog(state) { show = false }
}

@Composable
private fun TpIssueDialog(state: DesktopAppState, onDismiss: () -> Unit) {
    val data = state.tpData
    val brigades = data.brigades.filter { !it.archived }
    var brigade by remember { mutableStateOf(brigades.firstOrNull()) }
    var title by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Kun muammosi") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceButton("Brigada", brigade, brigades, { it.name }, { brigade = it })
            OutlinedTextField(title, { title = it }, label = { Text("Muammo") })
            OutlinedTextField(note, { note = it }, label = { Text("Izoh") }, minLines = 3)
        }
    }, confirmButton = {
        Button(onClick = {
            val b = brigade ?: return@Button
            val result = state.tpRepository.addDailyIssue(b.id, LocalDate.now().toString(), null, null, title, note)
            state.applyMutation(result, "Muammo saqlandi")
            if (result.isSuccess) onDismiss()
        }) { Text("Saqlash") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor") } })
}

// -------------------- TP MASTER DATA --------------------

@Composable
fun TpMasterScreen(state: DesktopAppState) {
    var tab by remember { mutableStateOf(0) }
    val labels = listOf("Stanoklar", "Mahsulot/Detal", "Seryo/Krasitel", "Sex/Brigada/Ishchi")
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { labels.forEachIndexed { i, label -> FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(label) }) } }
        when (tab) {
            0 -> MachineMaster(state)
            1 -> ProductMaster(state)
            2 -> MaterialMaster(state)
            else -> TpPeopleMaster(state)
        }
    }
}

@Composable
private fun MachineMaster(state: DesktopAppState) {
    val data = state.tpData
    var add by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row { Text("Stanoklar", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); if (state.policy?.let { it.isAdmin() || it.hasPermission("TP_MASTER_DATA_WRITE") } == true) Button(onClick = { add = true }) { Text("+ Stanok") } }
        LazyColumn(Modifier.fillMaxSize()) { items(data.machines.sortedBy { it.number }, key = { it.id }) { m -> Row(Modifier.fillMaxWidth().padding(8.dp)) { Text(m.number.toString(), Modifier.width(80.dp)); Text(m.name.ifBlank { "—" }, Modifier.weight(1f)); Text("Sig‘im ${m.capacity}", Modifier.width(150.dp)); Text(data.shops.firstOrNull { it.id == m.shopId }?.name ?: "—") }; HorizontalDivider() } }
    }
    if (add) MachineDialog(state) { add = false }
}

@Composable
private fun MachineDialog(state: DesktopAppState, onDismiss: () -> Unit) {
    val shops = state.tpData.shops.filter { !it.archived }
    var shop by remember { mutableStateOf(shops.firstOrNull()) }; var number by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }; var capacity by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Stanok") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ChoiceButton("Sex", shop, shops, { it.name }, { shop = it }); OutlinedTextField(number, { number = it.filter(Char::isDigit) }, label = { Text("Stanok raqami") }); OutlinedTextField(name, { name = it }, label = { Text("Nomi") }); OutlinedTextField(capacity, { capacity = it.filter(Char::isDigit) }, label = { Text("Sig‘im") })
    } }, confirmButton = { Button(onClick = { val s = shop ?: return@Button; val r = state.tpRepository.addMachine(s.id, number.toIntOrNull() ?: 0, name, capacity.toIntOrNull() ?: 0); state.applyMutation(r, "Stanok saqlandi"); if (r.isSuccess) onDismiss() }) { Text("Saqlash") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor") } })
}

@Composable
private fun ProductMaster(state: DesktopAppState) {
    val data = state.tpData
    var addProduct by remember { mutableStateOf(false) }; var detailProduct by remember { mutableStateOf<TpProduct?>(null) }
    Column(Modifier.fillMaxSize()) {
        Row { Text("Mahsulotlar", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); if (state.policy?.let { it.isAdmin() || it.hasPermission("TP_MASTER_DATA_WRITE") } == true) Button(onClick = { addProduct = true }) { Text("+ Mahsulot") } }
        LazyColumn(Modifier.fillMaxSize()) {
            items(data.products.filter { !it.archived }.sortedBy { it.article }, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) { Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("${p.article} • ${p.name}", fontWeight = FontWeight.Bold); Text("${p.details.count { !it.archived }} detal") }; if (state.policy?.let { it.isAdmin() || it.hasPermission("TP_MASTER_DATA_WRITE") } == true) OutlinedButton(onClick = { detailProduct = p }) { Text("Detal qo‘shish") } } }
            }
        }
    }
    if (addProduct) AddProductDialog(state) { addProduct = false }
    detailProduct?.let { DetailDialog(state, it) { detailProduct = null } }
}

@Composable
private fun AddProductDialog(state: DesktopAppState, onDismiss: () -> Unit) {
    var article by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Mahsulot") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(article, { article = it.uppercase() }, label = { Text("Artikul") }); OutlinedTextField(name, { name = it }, label = { Text("Nomi") }) } }, confirmButton = { Button(onClick = { val r = state.tpRepository.addProduct(article, name); state.applyMutation(r, "Mahsulot saqlandi"); if (r.isSuccess) onDismiss() }) { Text("Saqlash") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor") } })
}

@Composable
private fun DetailDialog(state: DesktopAppState, product: TpProduct, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }; var mold by remember { mutableStateOf("") }; var required by remember { mutableStateOf("1") }; var perShot by remember { mutableStateOf("1") }; var bag by remember { mutableStateOf("1") }; var cycle by remember { mutableStateOf("60") }; var gross by remember { mutableStateOf("0") }; var waste by remember { mutableStateOf("0") }; var resins by remember { mutableStateOf("") }; var price by remember { mutableStateOf("") }; var capacities by remember { mutableStateOf("") }; var colors by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("${product.article} • yangi detal") }, text = {
        Column(Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Detal nomi") }); OutlinedTextField(mold, { mold = it.uppercase() }, label = { Text("Qolip kodi") })
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { OutlinedTextField(required, { required = it.filter(Char::isDigit) }, label = { Text("1 mahsulotga") }, modifier = Modifier.weight(1f)); OutlinedTextField(perShot, { perShot = it.filter(Char::isDigit) }, label = { Text("1 jimda") }, modifier = Modifier.weight(1f)); OutlinedTextField(bag, { bag = it.filter(Char::isDigit) }, label = { Text("Qop") }, modifier = Modifier.weight(1f)) }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { OutlinedTextField(cycle, { cycle = it.filter(Char::isDigit) }, label = { Text("Sikl sek") }, modifier = Modifier.weight(1f)); OutlinedTextField(gross, { gross = decimalInput(it) }, label = { Text("Jim og‘irligi g") }, modifier = Modifier.weight(1f)); OutlinedTextField(waste, { waste = decimalInput(it) }, label = { Text("Yaroqsiz g") }, modifier = Modifier.weight(1f)) }
            OutlinedTextField(resins, { resins = it.uppercase() }, label = { Text("Seryo kodlari (vergul bilan)") })
            OutlinedTextField(capacities, { capacities = it }, label = { Text("Mos sig‘imlar: 60,90,120") })
            OutlinedTextField(price, { price = decimalInput(it) }, label = { Text("1 jim narxi") })
            OutlinedTextField(colors, { colors = it }, label = { Text("Ranglar: KOD:ulush:25kgGram, ...") }, supportingText = { Text("Misol: 1041:50:200, 001:50:300") })
        }
    }, confirmButton = { Button(onClick = {
        val resinList = resins.split(',').map { it.trim().uppercase() }.filter { it.isNotBlank() }.distinct()
        val colorRules = colors.split(',').mapNotNull { part -> val p = part.trim().split(':'); if (p.size < 3) null else TpColorRule(p[0].trim().uppercase(), p[1].trim().replace(',','.').toDoubleOrNull() ?: 0.0, p[2].trim().replace(',','.').toDoubleOrNull() ?: 0.0) }
        val detail = TpDetail(
            id = java.util.UUID.randomUUID().toString(), name = name, moldCode = mold, requiredPerProduct = required.toIntOrNull() ?: 0,
            piecesPerShot = perShot.toIntOrNull() ?: 0, bagCapacity = bag.toIntOrNull() ?: 0, cycleSeconds = cycle.toIntOrNull() ?: 0,
            grossShotWeightGrams = gross.replace(',','.').toDoubleOrNull() ?: 0.0, unusableShotWeightGrams = waste.replace(',','.').toDoubleOrNull() ?: 0.0,
            resinCode = resinList.firstOrNull().orEmpty(), unitPrice = price.replace(',','.').toDoubleOrNull() ?: 0.0,
            compatibleMachineIds = emptySet(), compatibleCapacities = capacities.split(',').mapNotNull { it.trim().toIntOrNull() }.toSet(), colors = colorRules, resinCodes = resinList
        )
        val r = state.tpRepository.saveDetail(product.id, detail); state.applyMutation(r, "Detal saqlandi"); if (r.isSuccess) onDismiss()
    }) { Text("Saqlash") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor") } })
}

@Composable
private fun MaterialMaster(state: DesktopAppState) {
    val data = state.tpData
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row { Text("Seryo / Krasitel kodlari", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); if (state.policy?.let { it.isAdmin() || it.hasPermission("TP_MASTER_DATA_WRITE") } == true) Button(onClick = { show = true }) { Text("+ Kod") } }
        LazyColumn(Modifier.fillMaxSize()) { items(data.materials.filter { !it.archived }.sortedWith(compareBy<TpMaterial> { it.type.name }.thenBy { it.code }), key = { it.id }) { m -> Row(Modifier.fillMaxWidth().padding(8.dp)) { Text(if (m.type == TpMaterialType.RESIN) "Seryo" else "Krasitel", Modifier.width(100.dp)); Text(m.code, Modifier.width(140.dp), fontWeight = FontWeight.Bold); Text("Ostatka ${formatTpNumber(m.currentStock())}", Modifier.width(200.dp)); Text("Harakat ${m.movements.size}") }; HorizontalDivider() } }
    }
    if (show) MaterialCodeDialog(state) { show = false }
}

@Composable
private fun MaterialCodeDialog(state: DesktopAppState, onDismiss: () -> Unit) {
    var code by remember { mutableStateOf("") }; var type by remember { mutableStateOf(TpMaterialType.RESIN) }; var opening by remember { mutableStateOf("0") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Seryo/Krasitel kodi") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(selected = type == TpMaterialType.RESIN, onClick = { type = TpMaterialType.RESIN }, label = { Text("Seryo") }); FilterChip(selected = type == TpMaterialType.COLOR, onClick = { type = TpMaterialType.COLOR }, label = { Text("Krasitel") }) }; OutlinedTextField(code, { code = it.uppercase() }, label = { Text("Kod") }); OutlinedTextField(opening, { opening = decimalInput(it) }, label = { Text("Boshlang‘ich ostatka") }) } }, confirmButton = { Button(onClick = { val r = state.tpRepository.setMaterial(code, "", type, opening.replace(',','.').toDoubleOrNull() ?: 0.0); state.applyMutation(r, "Kod saqlandi"); if (r.isSuccess) onDismiss() }) { Text("Saqlash") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor") } })
}

@Composable
private fun TpPeopleMaster(state: DesktopAppState) {
    val data = state.tpData
    var mode by remember { mutableStateOf(0) }
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Sex", "Brigada", "Ishchi").forEachIndexed { i, s -> FilterChip(selected = mode == i, onClick = { mode = i }, label = { Text(s) }) }; Spacer(Modifier.weight(1f)); if (state.policy?.let { it.isAdmin() || it.hasPermission("TP_MASTER_DATA_WRITE") } == true) Button(onClick = { show = true }) { Text("+ Qo‘shish") } }
        LazyColumn(Modifier.fillMaxSize()) {
            when (mode) {
                0 -> items(data.shops.filter { !it.archived }, key = { it.id }) { item -> Text(item.name, Modifier.padding(10.dp)); HorizontalDivider() }
                1 -> items(data.brigades.filter { !it.archived }, key = { it.id }) { item -> Row(Modifier.fillMaxWidth().padding(10.dp)) { Text(item.name, Modifier.weight(1f)); Text(data.shops.firstOrNull { it.id == item.shopId }?.name ?: "—") }; HorizontalDivider() }
                else -> items(data.workers.filter { !it.archived }, key = { it.id }) { item -> Row(Modifier.fillMaxWidth().padding(10.dp)) { Text(item.name, Modifier.weight(1f)); Text(data.brigades.firstOrNull { it.id == item.brigadeId }?.name ?: "—"); Spacer(Modifier.width(20.dp)); Text("Norma ${item.dailyTargetAmount}") }; HorizontalDivider() }
            }
        }
    }
    if (show) TpPeopleDialog(state, mode) { show = false }
}

@Composable
private fun TpPeopleDialog(state: DesktopAppState, mode: Int, onDismiss: () -> Unit) {
    val data = state.tpData
    var name by remember { mutableStateOf("") }; var shop by remember { mutableStateOf(data.shops.firstOrNull { !it.archived }) }; var shift by remember { mutableStateOf(data.shifts.firstOrNull { !it.archived }) }; var brigade by remember { mutableStateOf(data.brigades.firstOrNull { !it.archived }) }; var target by remember { mutableStateOf("") }; var minutes by remember { mutableStateOf("680") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(listOf("Sex", "Brigada", "Ishchi")[mode]) }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(name, { name = it }, label = { Text("Nomi") })
        if (mode == 1) { ChoiceButton("Sex", shop, data.shops.filter { !it.archived }, { it.name }, { shop = it }); ChoiceButton("Smena", shift, data.shifts.filter { !it.archived }, { it.name }, { shift = it }) }
        if (mode == 2) { ChoiceButton("Brigada", brigade, data.brigades.filter { !it.archived }, { it.name }, { brigade = it }); OutlinedTextField(target, { target = it.filter(Char::isDigit) }, label = { Text("Kunlik norma so‘m") }); OutlinedTextField(minutes, { minutes = it.filter(Char::isDigit) }, label = { Text("Ish daqiqasi") }) }
    } }, confirmButton = { Button(onClick = {
        val r = when (mode) { 0 -> state.tpRepository.addShop(name); 1 -> { val s = shop ?: return@Button; val sh = shift ?: return@Button; state.tpRepository.addBrigade(s.id, sh.id, name) }; else -> { val b = brigade ?: return@Button; state.tpRepository.addWorker(b.id, name, target.toLongOrNull() ?: 0L, minutes.toIntOrNull() ?: 0) } }
        state.applyMutation(r, "Saqlandi"); if (r.isSuccess) onDismiss()
    }) { Text("Saqlash") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor") } })
}

// -------------------- ASSEMBLY --------------------

@Composable
fun AssemblyBrigadirScreen(state: DesktopAppState) {
    val data = state.assemblyData
    var brigade by remember { mutableStateOf(data.brigades.firstOrNull { !it.archived && !it.deleted }) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var workerDialog by remember { mutableStateOf<Worker?>(null) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { ChoiceButton("Brigada", brigade, data.brigades.filter { !it.archived && !it.deleted }, { it.name }, { brigade = it }, Modifier.width(260.dp)); OutlinedTextField(date, { date = it }, label = { Text("Sana") }, modifier = Modifier.width(180.dp), singleLine = true) }
        brigade?.let { b ->
            LazyColumn(Modifier.fillMaxSize()) {
                items(data.activeWorkers(b.id), key = { it.id }) { worker ->
                    val day = data.workerDay(worker.id, date)
                    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(worker.name, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                        Text(day?.let { if (!it.worked) "Ishlamadi" else "${it.hours} soat • ${it.earned} so‘m" } ?: "—", Modifier.width(260.dp))
                        if (state.policy?.let { it.isAdmin() || it.hasPermission("BRIGADIR_WRITE") } == true) Button(onClick = { workerDialog = worker }) { Text("Kiritish") }
                    }; HorizontalDivider()
                }
            }
        }
    }
    workerDialog?.let { AssemblyProductionDialog(state, it, date) { workerDialog = null } }
}

@Composable
private fun AssemblyProductionDialog(state: DesktopAppState, worker: Worker, date: String, onDismiss: () -> Unit) {
    val data = state.assemblyData
    val products = data.products.filter { !it.archived && it.brigadeId == worker.brigadeId }
    var product by remember { mutableStateOf(products.firstOrNull()) }; var quantity by remember { mutableStateOf("") }; var hours by remember { mutableStateOf((data.workerDay(worker.id, date)?.hours ?: data.workHoursAt(date)).toString()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(worker.name) }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ChoiceButton("Mahsulot", product, products, { "${it.article} • ${it.name}" }, { product = it }); OutlinedTextField(quantity, { quantity = normalizeProductionQuantityInput(it) }, label = { Text("Soni") }); OutlinedTextField(hours, { hours = it.filter(Char::isDigit) }, label = { Text("Soat") })
    } }, confirmButton = { Button(onClick = {
        val p = product ?: return@Button
        val h = state.assemblyRepository.setWorkerHours(worker.id, date, hours.toIntOrNull() ?: data.workHoursAt(date)); if (h.isFailure) { state.applyMutation(h); return@Button }
        val r = state.assemblyRepository.addProductionEntry(worker.id, date, p.id, parseProductionQuantity(quantity) ?: 0.0, true); state.applyMutation(r, "Ishchi natijasi saqlandi"); if (r.isSuccess) onDismiss()
    }) { Text("Saqlash") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor") } })
}

@Composable
fun AssemblyQualityScreen(state: DesktopAppState) {
    val data = state.assemblyData
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var brigade by remember { mutableStateOf(data.brigades.firstOrNull { !it.archived && !it.deleted }) }
    var selected by remember { mutableStateOf<Pair<Worker, Int>?>(null) }
    val canWrite = state.policy?.let { it.isAdmin() || it.hasPermission("QUALITY_WRITE") } == true
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            ChoiceButton("Brigada", brigade, data.brigades.filter { !it.archived && !it.deleted }, { it.name }, { brigade = it }, Modifier.width(280.dp))
            OutlinedTextField(date, { date = it }, label = { Text("Sana") }, singleLine = true, modifier = Modifier.width(180.dp))
            if (canWrite && brigade != null) {
                OutlinedButton(onClick = { state.applyMutation(state.assemblyRepository.closeQualityDay(brigade!!.id, date), "Sifat kuni yopildi") }) { Text("Kunni yopish") }
            }
        }
        brigade?.let { b ->
            val times = data.roundTimesAt(date)
            val scheduled = listOf(times.first, times.second, times.third)
            LazyColumn(Modifier.fillMaxSize()) {
                items(data.activeWorkers(b.id), key = { it.id }) { worker ->
                    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(worker.name, Modifier.width(220.dp), fontWeight = FontWeight.Medium)
                        for (round in 1..3) {
                            val q = data.qualityRound(worker.id, date, round)
                            val label = when {
                                q?.absenceAt != null -> if (q.absenceType == "EXCUSED") "R$round Sababli" else "R$round Sababsiz"
                                q?.missedAt != null -> "R$round O‘tkazildi"
                                q?.grade != null -> "R$round ${q.grade}"
                                else -> "R$round —"
                            }
                            if (canWrite) OutlinedButton(onClick = { selected = worker to round }, modifier = Modifier.width(130.dp)) { Text(label, maxLines = 1) }
                            else Text(label, Modifier.width(130.dp))
                        }
                        Text(scheduled.joinToString(" / "), style = MaterialTheme.typography.bodySmall)
                    }
                    HorizontalDivider()
                }
            }
        }
    }
    selected?.let { (worker, round) ->
        AssemblyQualityDialog(state, worker, date, round) { selected = null }
    }
}

@Composable
private fun AssemblyQualityDialog(state: DesktopAppState, worker: Worker, date: String, round: Int, onDismiss: () -> Unit) {
    val data = state.assemblyData
    val times = data.roundTimesAt(date)
    val scheduledTime = listOf(times.first, times.second, times.third)[round - 1]
    val products = data.products.filter { !it.archived && it.brigadeId == worker.brigadeId }
    var product by remember { mutableStateOf(products.firstOrNull()) }
    var stage by remember(product?.id) { mutableStateOf(product?.stages?.firstOrNull { !it.archived }) }
    var grade by remember { mutableStateOf(1) }
    var note by remember { mutableStateOf("") }
    var absenceReason by remember { mutableStateOf("") }
    var missedReason by remember { mutableStateOf("") }
    val current = data.qualityRound(worker.id, date, round)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${worker.name} • $round-raund • $scheduledTime") },
        text = {
            Column(Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text(current?.let { "Hozirgi holat: ${it.grade?.let { g -> "$g-baho" } ?: it.absenceType.takeIf(String::isNotBlank) ?: it.missedReason.takeIf(String::isNotBlank) ?: "—"}" } ?: "Hali baholanmagan", style = MaterialTheme.typography.bodySmall)
                ChoiceButton("Mahsulot", product, products, { "${it.article} • ${it.name}" }, { product = it; stage = it.stages.firstOrNull { s -> !s.archived } })
                ChoiceButton("Bosqich", stage, product?.stages?.filter { !it.archived }.orEmpty(), { it.name }, { stage = it })
                Text("Baho")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { (1..4).forEach { g -> FilterChip(selected = grade == g, onClick = { grade = g }, label = { Text(g.toString()) }) } }
                OutlinedTextField(note, { note = it }, label = { Text("Izoh (3/4 bahoda majburiy)") }, minLines = 2)
                HorizontalDivider()
                OutlinedTextField(absenceReason, { absenceReason = it }, label = { Text("Ishchi mavjud emas sababi") })
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { val r = state.assemblyRepository.markWorkerAbsent(worker.id, date, round, scheduledTime, true, absenceReason); state.applyMutation(r, "Sababli holat saqlandi"); if (r.isSuccess) onDismiss() }) { Text("Sababli") }
                    OutlinedButton(onClick = { val r = state.assemblyRepository.markWorkerAbsent(worker.id, date, round, scheduledTime, false, absenceReason); state.applyMutation(r, "Sababsiz holat saqlandi"); if (r.isSuccess) onDismiss() }) { Text("Sababsiz") }
                }
                HorizontalDivider()
                OutlinedTextField(missedReason, { missedReason = it }, label = { Text("O‘tkazib yuborish sababi") })
                OutlinedButton(onClick = { val r = state.assemblyRepository.markQualityRoundMissed(worker.id, date, round, scheduledTime, missedReason); state.applyMutation(r, "Raund o‘tkazib yuborilgan deb saqlandi"); if (r.isSuccess) onDismiss() }) { Text("O‘tkazib yuborildi") }
                if (current?.needsRecheck == true) {
                    HorizontalDivider()
                    OutlinedButton(onClick = { val r = state.assemblyRepository.saveQualityRecheck(worker.id, date, round, grade, note); state.applyMutation(r, "Qayta tekshiruv saqlandi"); if (r.isSuccess) onDismiss() }) { Text("Qayta tekshiruvni saqlash") }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val p = product ?: return@Button
                val st = stage ?: return@Button
                val r = state.assemblyRepository.saveQualityRound(worker.id, date, round, scheduledTime, grade, p.id, st.id, note)
                state.applyMutation(r, "Sifat bahosi saqlandi")
                if (r.isSuccess) onDismiss()
            }) { Text("Bahoni saqlash") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor") } }
    )
}

@Composable
fun AssemblyIssuesScreen(state: DesktopAppState) {
    val data = state.assemblyData
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row { Text("Kun muammosi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); if (state.policy?.let { it.isAdmin() || it.hasPermission("DAILY_ISSUE_WRITE") } == true) Button(onClick = { show = true }) { Text("+ Muammo") } }
        LazyColumn(Modifier.fillMaxSize()) { items(data.dailyIssues.sortedByDescending { it.createdAt }, key = { it.id }) { issue -> Row(Modifier.fillMaxWidth().padding(8.dp)) { Text(issue.date, Modifier.width(110.dp)); Text(issue.articleSnapshot, Modifier.width(120.dp)); Text(issue.stageNameSnapshot, Modifier.width(180.dp)); Text(issue.note, Modifier.weight(1f)); if (state.policy?.let { it.isAdmin() || it.hasPermission("DAILY_ISSUE_WRITE") } == true) TextButton(onClick = { state.applyMutation(state.assemblyRepository.removeDailyIssue(issue.id), "Muammo o‘chirildi") }) { Text("O‘chirish") } }; HorizontalDivider() } }
    }
    if (show) AssemblyIssueDialog(state) { show = false }
}

@Composable
private fun AssemblyIssueDialog(state: DesktopAppState, onDismiss: () -> Unit) {
    val data = state.assemblyData
    var brigade by remember { mutableStateOf(data.brigades.firstOrNull { !it.archived && !it.deleted }) }
    val products = brigade?.let { b -> data.products.filter { !it.archived && it.brigadeId == b.id } }.orEmpty()
    var product by remember(brigade?.id) { mutableStateOf(products.firstOrNull()) }
    val stages = product?.stages?.filter { !it.archived }.orEmpty(); var stage by remember(product?.id) { mutableStateOf(stages.firstOrNull()) }; var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Kun muammosi") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ChoiceButton("Brigada", brigade, data.brigades.filter { !it.archived && !it.deleted }, { it.name }, { brigade = it; product = data.products.firstOrNull { p -> !p.archived && p.brigadeId == it.id }; stage = product?.stages?.firstOrNull { s -> !s.archived } }); ChoiceButton("Mahsulot", product, brigade?.let { b -> data.products.filter { !it.archived && it.brigadeId == b.id } }.orEmpty(), { "${it.article} ${it.name}" }, { product = it; stage = it.stages.firstOrNull { s -> !s.archived } }); ChoiceButton("Bosqich", stage, product?.stages?.filter { !it.archived }.orEmpty(), { it.name }, { stage = it }); OutlinedTextField(note, { note = it }, label = { Text("Izoh") }, minLines = 3)
    } }, confirmButton = { Button(onClick = { val b=brigade?:return@Button; val p=product?:return@Button; val s=stage?:return@Button; val r=state.assemblyRepository.addDailyIssue(b.id, LocalDate.now().toString(), p.id, s.id, note); state.applyMutation(r,"Muammo saqlandi"); if(r.isSuccess) onDismiss() }) { Text("Saqlash") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor") } })
}

@Composable
fun AssemblyMasterScreen(state: DesktopAppState) {
    val data = state.assemblyData
    var mode by remember { mutableStateOf(0) }; var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Brigada", "Ishchi", "Mahsulot").forEachIndexed { i, s -> FilterChip(selected = mode == i, onClick = { mode = i }, label = { Text(s) }) }; Spacer(Modifier.weight(1f)); if (state.policy?.let { it.isAdmin() || it.hasPermission("MASTER_DATA_WRITE") } == true) Button(onClick = { show = true }) { Text("+ Qo‘shish") } }
        LazyColumn(Modifier.fillMaxSize()) {
            when(mode) {
                0 -> items(data.brigades.filter { !it.deleted }, key={it.id}) { b -> Text("${b.name}${if(b.archived) " (arxiv)" else ""}", Modifier.padding(10.dp)); HorizontalDivider() }
                1 -> items(data.workers, key={it.id}) { w -> Row(Modifier.fillMaxWidth().padding(10.dp)) { Text(w.name, Modifier.weight(1f)); Text(data.brigades.firstOrNull { it.id==w.brigadeId }?.name ?: "—") }; HorizontalDivider() }
                else -> items(data.products, key={it.id}) { p -> Row(Modifier.fillMaxWidth().padding(10.dp)) { Text(p.article, Modifier.width(120.dp)); Text(p.name, Modifier.weight(1f)); Text("${p.currentPrice} so‘m") }; HorizontalDivider() }
            }
        }
    }
    if(show) AssemblyMasterDialog(state, mode) { show=false }
}

@Composable
private fun AssemblyMasterDialog(state: DesktopAppState, mode:Int, onDismiss:()->Unit){
    val data=state.assemblyData; var name by remember{mutableStateOf("")}; var brigade by remember{mutableStateOf(data.brigades.firstOrNull{!it.archived&&!it.deleted})}; var article by remember{mutableStateOf("")}; var price by remember{mutableStateOf("")}; var startDate by remember{mutableStateOf(LocalDate.now().toString())}
    AlertDialog(onDismissRequest=onDismiss,title={Text(listOf("Brigada","Ishchi","Mahsulot")[mode])},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){ if(mode>0) ChoiceButton("Brigada",brigade,data.brigades.filter{!it.archived&&!it.deleted},{it.name},{brigade=it}); if(mode==2) OutlinedTextField(article,{article=it.uppercase()},label={Text("Artikul")}); OutlinedTextField(name,{name=it},label={Text("Nomi")}); if(mode==1) OutlinedTextField(startDate,{startDate=it},label={Text("Ish boshlagan sana")}); if(mode==2) OutlinedTextField(price,{price=it.filter(Char::isDigit)},label={Text("Narx")})}},confirmButton={Button(onClick={ val r=when(mode){0->state.assemblyRepository.addBrigade(name);1->{val b=brigade?:return@Button;state.assemblyRepository.addWorker(b.id,name,startDate)};else->{val b=brigade?:return@Button;state.assemblyRepository.addProduct(b.id,article,name,price.toLongOrNull()?:0L)}};state.applyMutation(r,"Saqlandi");if(r.isSuccess)onDismiss()}){Text("Saqlash")}},dismissButton={TextButton(onClick=onDismiss){Text("Bekor")}})
}

// -------------------- ADMIN USERS --------------------

@Composable
fun UserAdminScreen(state: DesktopAppState) {
    val scope = rememberCoroutineScope()
    var users by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var showCreate by remember { mutableStateOf(false) }
    suspend fun load() {
        loading = true
        runCatching { state.gateway.callFunction("adminListUsers", JSONObject()) }.onSuccess { root ->
            val arr = root.optJSONArray("users") ?: JSONArray()
            users = buildList { for (i in 0 until arr.length()) arr.optJSONObject(i)?.let(::add) }
        }.onFailure { state.error = it.message.orEmpty() }
        loading = false
    }
    LaunchedEffect(Unit) { load() }
    Column(Modifier.fillMaxSize()) {
        Row { Text("Foydalanuvchilar", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Button(onClick = { showCreate = true }) { Text("+ User") }; Spacer(Modifier.width(8.dp)); OutlinedButton(onClick = { scope.launch { load() } }) { Text("Yangilash") } }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        LazyColumn(Modifier.fillMaxSize()) { items(users, key = { it.optString("uid") }) { u -> Row(Modifier.fillMaxWidth().padding(8.dp)) { Text(u.optString("displayName"), Modifier.width(240.dp), fontWeight=FontWeight.Medium); Text(u.optString("role"), Modifier.width(140.dp)); Text(u.optString("userCode"), Modifier.width(180.dp)); Text(if(u.optBoolean("enabled",true))"Faol" else "O‘chirilgan") }; HorizontalDivider() } }
    }
    if(showCreate) UserCreateDialog(state,onDismiss={showCreate=false},onCreated={scope.launch{load()}})
}

@Composable
private fun UserCreateDialog(state: DesktopAppState, onDismiss:()->Unit, onCreated:()->Unit){
    val scope=rememberCoroutineScope(); var name by remember{mutableStateOf("")}; val roles=listOf("BRIGADIR","QUALITY","TP_NACHALNIK","TP_PLAN","TP_BRIGADIR","TP_SERYO","TP_QABUL","TP_QUALITY","RAHBAR","ADMIN"); var role by remember{mutableStateOf(roles.first())}; var all by remember{mutableStateOf(true)}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Yangi foydalanuvchi")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(name,{name=it},label={Text("Ism")});ChoiceButton("Rol",role,roles,{it},{role=it});Row(verticalAlignment=Alignment.CenterVertically){Checkbox(all,{all=it});Text("Barcha brigadalar")};Text("Brigada granular ruxsatlarini Android Admin oynasidan yoki keyingi desktop permission editoridan boshqarish mumkin.",style=MaterialTheme.typography.bodySmall)}},confirmButton={Button(onClick={scope.launch{runCatching{state.gateway.callFunction("adminCreateUser",JSONObject().put("displayName",name).put("role",role).put("allBrigades",all).put("allowedBrigadeIds",JSONArray()))}.onSuccess{r->state.message="User: ${r.optString("userCode")} / Device: ${r.optString("deviceCode")}";onCreated();onDismiss()}.onFailure{state.error=it.message.orEmpty()}}}){Text("Yaratish")}},dismissButton={TextButton(onClick=onDismiss){Text("Bekor")}})
}

private fun decimalInput(value: String): String {
    val normalized = value.replace(',', '.')
    val filtered = normalized.filter { it.isDigit() || it == '.' }
    val first = filtered.indexOf('.')
    return if (first < 0) filtered else filtered.substring(0, first + 1) + filtered.substring(first + 1).replace(".", "")
}
