package uz.toybola.factory.desktop

import android.content.Context
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AssemblySyncOutbox
import uz.toybola.factory.core.firebase.TpSyncOutbox

data class DesktopPendingWrite(val key: String, val payload: String?)

data class DesktopSyncResult(
    val uploaded: Int,
    val assemblyPending: Int,
    val tpPending: Int,
    val message: String
)

class DesktopSyncService(
    context: Context,
    private val gateway: FirebaseDesktopGateway,
    private val assemblyRepository: AssemblyDataRepository,
    private val tpRepository: TpDataRepository
) {
    private val assemblyOutbox = AssemblySyncOutbox(context)
    private val tpOutbox = TpSyncOutbox(context)
    private val mutex = Mutex()

    fun pendingCount(): Int = assemblyOutbox.pending().size + tpOutbox.pending().size
    fun assemblyPending(): Int = assemblyOutbox.pending().size
    fun tpPending(): Int = tpOutbox.pending().size

    suspend fun sync(): DesktopSyncResult = mutex.withLock {
        var uploaded = 0
        val assemblyKeys = assemblyOutbox.pending().sorted()
        val tpKeys = tpOutbox.pending().sorted()

        if (assemblyKeys.isNotEmpty()) {
            val local = assemblyRepository.load()
            assemblyKeys.chunked(80).forEach { keys ->
                val writes = keys.mapNotNull { key -> assemblyWrite(key, local) }
                if (writes.isNotEmpty()) {
                    gateway.applyWrites(writes)
                    writes.forEach { assemblyOutbox.remove(it.key) }
                    uploaded += writes.size
                }
            }
        }
        if (tpKeys.isNotEmpty()) {
            val local = tpRepository.load()
            tpKeys.chunked(80).forEach { keys ->
                val writes = keys.mapNotNull { key -> tpWrite(key, local) }
                if (writes.isNotEmpty()) {
                    gateway.applyWrites(writes)
                    writes.forEach { tpOutbox.remove(it.key) }
                    uploaded += writes.size
                }
            }
        }

        val (assemblyRaw, tpRaw) = gateway.syncSnapshots()
        assemblyRaw?.let { assemblyRepository.replaceFromServer(assemblyRepository.decodeForSync(it)) }
        tpRaw?.let { tpRepository.replaceFromServer(tpRepository.decodeForSync(it)) }

        DesktopSyncResult(
            uploaded = uploaded,
            assemblyPending = assemblyOutbox.pending().size,
            tpPending = tpOutbox.pending().size,
            message = if (uploaded > 0) "$uploaded ta o‘zgarish serverga yuborildi" else "Server bilan yangilandi"
        )
    }

    private fun assemblyWrite(key: String, data: AssemblyData): DesktopPendingWrite? {
        val type = key.substringBefore(':')
        val id = key.substringAfter(':', "")
        if (type == "DAILY_ISSUE_DELETE") return DesktopPendingWrite(key, null)
        val subset = when (type) {
            "BRIGADE" -> data.brigades.firstOrNull { it.id == id }?.let { AssemblyData(brigades = listOf(it)) }
            "WORKER" -> data.workers.firstOrNull { it.id == id }?.let { AssemblyData(workers = listOf(it)) }
            "PRODUCT" -> data.products.firstOrNull { it.id == id }?.let { AssemblyData(products = listOf(it)) }
            "BRIGADE_FK" -> data.brigadeFk.firstOrNull { it.brigadeId == id }?.let { AssemblyData(brigadeFk = listOf(it)) }
            "WORKER_DAY" -> {
                val p = id.split('|'); if (p.size != 2) null else data.workerDays.firstOrNull { it.workerId == p[0] && it.date == p[1] }?.let { AssemblyData(workerDays = listOf(it)) }
            }
            "BRIGADE_DAY" -> {
                val p = id.split('|'); if (p.size != 2) null else data.brigadeDays.firstOrNull { it.brigadeId == p[0] && it.date == p[1] }?.let { AssemblyData(brigadeDays = listOf(it)) }
            }
            "QUALITY_ROUND" -> {
                val p = id.split('|'); if (p.size != 3) null else data.qualityRounds.firstOrNull { it.workerId == p[0] && it.date == p[1] && it.round == p[2].toIntOrNull() }?.let { AssemblyData(qualityRounds = listOf(it)) }
            }
            "DAILY_ISSUE" -> data.dailyIssues.firstOrNull { it.id == id }?.let { AssemblyData(dailyIssues = listOf(it)) }
            "AUDIT" -> data.auditLog.firstOrNull { it.id == id }?.let { AssemblyData(auditLog = listOf(it)) }
            "SETTINGS" -> AssemblyData(
                workHours = data.workHours,
                efficiencyNorm = data.efficiencyNorm,
                roundTimes = data.roundTimes,
                monitoringWeights = data.monitoringWeights,
                preparedYears = data.preparedYears
            )
            else -> null
        } ?: return null
        return DesktopPendingWrite(key, assemblyRepository.encodeForSync(subset))
    }

    private fun tpWrite(key: String, data: TpData): DesktopPendingWrite? {
        val type = key.substringBefore(':')
        val id = key.substringAfter(':', "")
        if (type == "TP_ORDER_DELETE" || type == "TP_JOB_DELETE") return DesktopPendingWrite(key, null)
        val subset = when (type) {
            "TP_SHOP" -> data.shops.firstOrNull { it.id == id }?.let { TpData(shops = listOf(it)) }
            "TP_SHIFT" -> data.shifts.firstOrNull { it.id == id }?.let { TpData(shifts = listOf(it)) }
            "TP_BRIGADE" -> data.brigades.firstOrNull { it.id == id }?.let { TpData(brigades = listOf(it)) }
            "TP_MACHINE" -> data.machines.firstOrNull { it.id == id }?.let { TpData(machines = listOf(it)) }
            "TP_WORKER" -> data.workers.firstOrNull { it.id == id }?.let { TpData(workers = listOf(it)) }
            "TP_PRODUCT" -> data.products.firstOrNull { it.id == id }?.let { TpData(products = listOf(it)) }
            "TP_MATERIAL" -> data.materials.firstOrNull { it.id == id }?.let { TpData(materials = listOf(it)) }
            "TP_ORDER" -> data.orders.firstOrNull { it.id == id }?.let { TpData(orders = listOf(it)) }
            "TP_JOB" -> data.jobs.firstOrNull { it.id == id }?.let { TpData(jobs = listOf(it)) }
            "TP_ATTENDANCE" -> data.attendance.firstOrNull { it.id == id }?.let { TpData(attendance = listOf(it)) }
            "TP_RECEIPT" -> data.receipts.firstOrNull { it.id == id }?.let { TpData(receipts = listOf(it)) }
            "TP_QUALITY" -> data.qualityRounds.firstOrNull { it.id == id }?.let { TpData(qualityRounds = listOf(it)) }
            "TP_ISSUE" -> data.dailyIssues.firstOrNull { it.id == id }?.let { TpData(dailyIssues = listOf(it)) }
            "TP_AUDIT" -> data.auditLog.firstOrNull { it.id == id }?.let { TpData(auditLog = listOf(it)) }
            "TP_SETTINGS" -> TpData(settings = data.settings)
            else -> null
        } ?: return null
        return DesktopPendingWrite(key, tpRepository.encodeForSync(subset))
    }
}
