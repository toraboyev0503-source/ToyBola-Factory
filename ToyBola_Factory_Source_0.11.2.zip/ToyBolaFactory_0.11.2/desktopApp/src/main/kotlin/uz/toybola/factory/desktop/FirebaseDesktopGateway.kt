package uz.toybola.factory.desktop

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URI
import java.net.URLEncoder
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.util.UUID

object DesktopConfig {
    const val VERSION = "0.11.2"
    const val PROJECT_ID = "toybola-factory"
    const val REGION = "europe-west1"
    // Firebase Web API keys identify a Firebase project; authorization is still enforced by Firebase Auth/Functions.
    const val FIREBASE_API_KEY = "AIzaSyDwdAQ8IAFMvrVUfiP_0_HcjDEpokEm6kY"
    val functionBase: String get() = "https://$REGION-$PROJECT_ID.cloudfunctions.net"
}

data class DesktopPolicy(
    val uid: String,
    val userCode: String,
    val displayName: String,
    val role: String,
    val allBrigades: Boolean,
    val allowedBrigadeIds: Set<String>,
    val permissions: Map<String, Boolean>,
    val revision: Long,
    val raw: JSONObject
) {
    fun canRead(key: String): Boolean = role.equals("ADMIN", true) || permissions["${key}_READ"] == true
    fun canWrite(key: String): Boolean = role.equals("ADMIN", true) || permissions["${key}_WRITE"] == true
    fun hasPermission(key: String): Boolean = role.equals("ADMIN", true) || permissions[key] == true
    fun inBrigade(brigadeId: String): Boolean = allBrigades || brigadeId in allowedBrigadeIds
    fun isAdmin(): Boolean = role.equals("ADMIN", true)
    fun canReadAssembly(): Boolean = isAdmin() || listOf("BRIGADIR_READ", "QUALITY_READ", "DAILY_ISSUE_READ", "MONITORING_READ", "MASTER_DATA_READ").any(::hasPermission)
    fun canReadTp(): Boolean = isAdmin() || listOf("TP_ORDER_READ", "TP_PLANNING_READ", "TP_MACHINE_READ", "TP_ATTENDANCE_READ", "TP_SERYO_READ", "TP_RECEIVING_READ", "TP_QUALITY_READ", "TP_MONITORING_READ", "TP_MASTER_DATA_READ").any(::hasPermission)
}

data class DesktopAuthSession(
    var idToken: String?,
    var refreshToken: String,
    var expiresAtEpochSeconds: Long,
    var policy: DesktopPolicy,
    val installId: String,
    val offline: Boolean = false
)

class DesktopSessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("toy_bola_desktop_session", Context.MODE_PRIVATE)

    fun installId(): String {
        val current = prefs.getString("installId", null)
        if (!current.isNullOrBlank()) return current
        val created = "WIN-${UUID.randomUUID()}"
        prefs.edit().putString("installId", created).commit()
        return created
    }

    fun save(session: DesktopAuthSession) {
        prefs.edit()
            .putString("refreshToken", session.refreshToken)
            .putString("policy", session.policy.raw.toString())
            .putString("userCode", session.policy.userCode)
            .commit()
    }

    fun clear() {
        prefs.edit().putString("refreshToken", null).putString("policy", null).putString("userCode", null).commit()
    }

    fun refreshToken(): String? = prefs.getString("refreshToken", null)?.takeIf { it.isNotBlank() }
    fun cachedPolicy(): DesktopPolicy? = prefs.getString("policy", null)?.let { raw ->
        runCatching { parsePolicy(JSONObject(raw)) }.getOrNull()
    }

    companion object {
        fun parsePolicy(raw: JSONObject): DesktopPolicy = uz.toybola.factory.desktop.parsePolicy(raw)
    }
}

class FirebaseDesktopGateway(private val context: Context) {
    private val http = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NORMAL).build()
    private val store = DesktopSessionStore(context)
    @Volatile var session: DesktopAuthSession? = null
        private set

    suspend fun login(deviceCode: String, userCode: String): DesktopAuthSession = withContext(Dispatchers.IO) {
        val result = callFunctionRaw(
            name = "loginWithCodes",
            data = JSONObject()
                .put("deviceCode", deviceCode.trim().uppercase())
                .put("userCode", userCode.trim().uppercase())
                .put("installId", store.installId()),
            idToken = null
        )
        val customToken = result.optString("token").takeIf { it.isNotBlank() } ?: error("Kirish tokeni olinmadi")
        val auth = exchangeCustomToken(customToken)
        val policyJson = result.optJSONObject("policy") ?: error("Foydalanuvchi ruxsati olinmadi")
        val created = DesktopAuthSession(
            idToken = auth.idToken,
            refreshToken = auth.refreshToken,
            expiresAtEpochSeconds = Instant.now().epochSecond + auth.expiresInSeconds - 60,
            policy = parsePolicy(policyJson),
            installId = store.installId()
        )
        session = created
        store.save(created)
        created
    }

    suspend fun restore(): DesktopAuthSession? = withContext(Dispatchers.IO) {
        val refresh = store.refreshToken() ?: return@withContext null
        val cached = store.cachedPolicy() ?: return@withContext null
        runCatching {
            val auth = refreshIdToken(refresh)
            val provisional = DesktopAuthSession(auth.idToken, auth.refreshToken, Instant.now().epochSecond + auth.expiresInSeconds - 60, cached, store.installId())
            session = provisional
            val fresh = callFunction("getMyPolicy", JSONObject())
            provisional.policy = parsePolicy(fresh)
            store.save(provisional)
            provisional
        }.getOrElse {
            val offline = DesktopAuthSession(null, refresh, 0L, cached, store.installId(), offline = true)
            session = offline
            offline
        }
    }

    fun logout() {
        session = null
        store.clear()
    }

    suspend fun callFunction(name: String, data: JSONObject = JSONObject()): JSONObject = withContext(Dispatchers.IO) {
        val active = requireOnlineSession()
        callFunctionRaw(name, data, active.idToken)
    }

    suspend fun syncSnapshots(): Pair<String?, String?> = withContext(Dispatchers.IO) {
        val policy = session?.policy ?: error("Kirish talab qilinadi")
        val assembly = if (policy.canReadAssembly()) {
            callFunction("getAssemblySnapshot", JSONObject().put("clientVersion", DesktopConfig.VERSION))
                .optString("payload").takeIf { it.isNotBlank() }
        } else null
        val tp = if (policy.canReadTp()) {
            callFunction("getTpSnapshot", JSONObject().put("clientVersion", DesktopConfig.VERSION))
                .optString("payload").takeIf { it.isNotBlank() }
        } else null
        assembly to tp
    }

    suspend fun applyWrites(writes: List<DesktopPendingWrite>): JSONObject = withContext(Dispatchers.IO) {
        if (writes.isEmpty()) return@withContext JSONObject().put("applied", 0)
        val array = org.json.JSONArray()
        writes.forEach { write ->
            array.put(JSONObject().put("key", write.key).apply {
                write.payload?.let { put("payload", it) }
            })
        }
        callFunction("desktopApplyWrites", JSONObject().put("writes", array).put("clientVersion", DesktopConfig.VERSION))
    }

    private suspend fun requireOnlineSession(): DesktopAuthSession {
        var active = session ?: error("Kirish talab qilinadi")
        if (active.idToken == null || active.expiresAtEpochSeconds <= Instant.now().epochSecond) {
            val refreshed = refreshIdToken(active.refreshToken)
            active = active.copy(
                idToken = refreshed.idToken,
                refreshToken = refreshed.refreshToken,
                expiresAtEpochSeconds = Instant.now().epochSecond + refreshed.expiresInSeconds - 60,
                offline = false
            )
            session = active
            store.save(active)
        }
        return active
    }

    private fun callFunctionRaw(name: String, data: JSONObject, idToken: String?): JSONObject {
        val requestBuilder = HttpRequest.newBuilder(URI.create("${DesktopConfig.functionBase}/$name"))
            .header("Content-Type", "application/json; charset=utf-8")
            .POST(HttpRequest.BodyPublishers.ofString(JSONObject().put("data", data).toString()))
        if (!idToken.isNullOrBlank()) requestBuilder.header("Authorization", "Bearer $idToken")
        val response = http.send(requestBuilder.build(), HttpResponse.BodyHandlers.ofString())
        val body = runCatching { JSONObject(response.body()) }.getOrElse { JSONObject() }
        if (response.statusCode() !in 200..299) {
            val message = body.optJSONObject("error")?.optString("message")
                ?: body.optString("error").takeIf { it.isNotBlank() }
                ?: "Server xatosi: HTTP ${response.statusCode()}"
            error(message)
        }
        val errorObject = body.optJSONObject("error")
        if (errorObject != null) throw IllegalStateException(errorObject.optString("message", "Server xatosi"))
        return body.optJSONObject("result") ?: body.optJSONObject("data") ?: body
    }

    private data class TokenResult(val idToken: String, val refreshToken: String, val expiresInSeconds: Long)

    private fun exchangeCustomToken(customToken: String): TokenResult {
        val endpoint = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${DesktopConfig.FIREBASE_API_KEY}"
        val request = HttpRequest.newBuilder(URI.create(endpoint))
            .header("Content-Type", "application/json; charset=utf-8")
            .POST(HttpRequest.BodyPublishers.ofString(JSONObject().put("token", customToken).put("returnSecureToken", true).toString()))
            .build()
        val response = http.send(request, HttpResponse.BodyHandlers.ofString())
        val body = JSONObject(response.body())
        if (response.statusCode() !in 200..299) error(body.optJSONObject("error")?.optString("message", "Firebase Auth xatosi") ?: "Firebase Auth xatosi")
        return TokenResult(body.getString("idToken"), body.getString("refreshToken"), body.optString("expiresIn", "3600").toLong())
    }

    private fun refreshIdToken(refreshToken: String): TokenResult {
        val endpoint = "https://securetoken.googleapis.com/v1/token?key=${DesktopConfig.FIREBASE_API_KEY}"
        val form = "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(refreshToken, StandardCharsets.UTF_8)
        val request = HttpRequest.newBuilder(URI.create(endpoint))
            .header("Content-Type", "application/x-www-form-urlencoded")
            .POST(HttpRequest.BodyPublishers.ofString(form))
            .build()
        val response = http.send(request, HttpResponse.BodyHandlers.ofString())
        val body = JSONObject(response.body())
        if (response.statusCode() !in 200..299) error(body.optJSONObject("error")?.optString("message", "Sessiyani yangilab bo‘lmadi") ?: "Sessiyani yangilab bo‘lmadi")
        return TokenResult(body.getString("id_token"), body.getString("refresh_token"), body.optString("expires_in", "3600").toLong())
    }
}

fun parsePolicy(raw: JSONObject): DesktopPolicy {
    val permissionsObject = raw.optJSONObject("permissions") ?: JSONObject()
    val permissions = buildMap<String, Boolean> {
        permissionsObject.keys().forEach { key -> put(key, permissionsObject.optBoolean(key, false)) }
    }
    val allowedArray = raw.optJSONArray("allowedBrigadeIds")
    val brigades = buildSet {
        if (allowedArray != null) for (i in 0 until allowedArray.length()) add(allowedArray.optString(i))
    }
    return DesktopPolicy(
        uid = raw.optString("uid"),
        userCode = raw.optString("userCode"),
        displayName = raw.optString("displayName"),
        role = raw.optString("role"),
        allBrigades = raw.optBoolean("allBrigades", false),
        allowedBrigadeIds = brigades,
        permissions = permissions,
        revision = raw.optLong("revision", 0L),
        raw = JSONObject(raw.toString())
    )
}
