package uz.toybola.factory.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.Badge
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import uz.toybola.factory.ui.model.AppScreen
import uz.toybola.factory.ui.model.AppStrings

@Composable
fun GlobalBottomBar(
    strings: AppStrings,
    current: AppScreen,
    unreadNotifications: Int,
    syncing: Boolean,
    onHome: () -> Unit,
    onNotifications: () -> Unit,
    onSync: () -> Unit,
    onSettings: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .navigationBarsPadding(),
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 10.dp,
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(82.dp)
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomItem(
                icon = Icons.Rounded.Home,
                label = strings.homeNav,
                selected = current == AppScreen.HOME,
                onClick = onHome
            )
            BottomItem(
                icon = Icons.Rounded.Notifications,
                label = strings.notifications,
                selected = current == AppScreen.NOTIFICATIONS,
                badgeCount = unreadNotifications,
                onClick = onNotifications
            )
            BottomItem(
                icon = Icons.Rounded.Sync,
                label = if (syncing) strings.syncing else strings.syncNav,
                selected = false,
                onClick = onSync
            )
            BottomItem(
                icon = Icons.Rounded.Settings,
                label = strings.menu,
                selected = current == AppScreen.SETTINGS,
                onClick = onSettings
            )
        }
    }
}

@Composable
private fun BottomItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    badgeCount: Int = 0,
    onClick: () -> Unit
) {
    val tint = if (selected) Color(0xFF1976D2) else MaterialTheme.colorScheme.onSurfaceVariant
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = if (selected) Color(0xFFEAF4FF) else Color.Transparent,
        modifier = Modifier.padding(horizontal = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 9.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(contentAlignment = Alignment.TopEnd) {
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(26.dp))
                if (badgeCount > 0) {
                    Badge(
                        containerColor = Color(0xFFFF4D43),
                        contentColor = Color.White,
                        modifier = Modifier.align(Alignment.TopEnd)
                    ) { Text(badgeCount.coerceAtMost(99).toString()) }
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                label,
                color = tint,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1
            )
        }
    }
}
