package uz.toybola.factory.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SectionCard(
    number: Int?,
    title: String,
    description: String,
    enabled: Boolean,
    badgeCount: Int = 0,
    modifier: Modifier = Modifier,
    accentColor: Color = Color(0xFF2D8FD0),
    icon: ImageVector? = null,
    onClick: () -> Unit
) {
    val activeBg = accentColor.copy(alpha = 0.105f)
    val disabledBg = Color(0xFFF3F6F8)
    val textAlpha = if (enabled) 1f else 0.52f
    Surface(
        modifier = modifier
            .height(146.dp)
            .clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        tonalElevation = if (enabled) 2.dp else 0.dp,
        shadowElevation = if (enabled) 2.dp else 0.dp,
        color = if (enabled) activeBg else disabledBg
    ) {
        Box(Modifier.fillMaxSize().alpha(textAlpha)) {
            Column(
                modifier = Modifier.fillMaxSize().padding(18.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    if (number != null) {
                        Text(
                            text = number.toString().padStart(2, '0'),
                            color = if (enabled) accentColor else Color(0xFF93A3AE),
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    if (icon != null) {
                        Icon(
                            icon,
                            contentDescription = null,
                            tint = if (enabled) accentColor else Color(0xFF9BAAB5),
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }
                Column {
                    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 3
                    )
                }
            }

            if (badgeCount > 0 && enabled) {
                Surface(
                    modifier = Modifier.align(Alignment.TopEnd).padding(9.dp),
                    shape = RoundedCornerShape(999.dp),
                    color = Color(0xFFFF4D43)
                ) {
                    Text(
                        text = badgeCount.coerceAtMost(999).toString(),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
