package uz.toybola.factory.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import uz.toybola.factory.R
import uz.toybola.factory.core.firebase.FirebaseSyncCoordinator
import uz.toybola.factory.core.firebase.FirebaseSyncScheduler
import uz.toybola.factory.core.firebase.SyncStatusEvents
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.components.SectionCard
import uz.toybola.factory.ui.model.AppScreen
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate

private data class HomeSection(
    val id: Int,
    val title: String,
    val description: String,
    val accent: Color,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@Composable
fun HomeScreen(
    strings: AppStrings,
    onMenu: () -> Unit,
    canOpenSeryo: Boolean,
    canOpenTp: Boolean,
    canOpenManagement: Boolean,
    onSeryo: () -> Unit,
    onTp: () -> Unit,
    onAssembly: () -> Unit,
    onManagement: () -> Unit
) {
    var disabledMessage by remember { mutableStateOf(false) }
    val sections = listOf(
        HomeSection(1, strings.molding, strings.moldingDesc, Color(0xFF2F8FE5), Icons.Rounded.Factory),
        HomeSection(2, strings.tp, strings.tpDesc, Color(0xFF7657E8), Icons.Rounded.Assignment),
        HomeSection(3, strings.ytmWarehouse, strings.ytmWarehouseDesc, Color(0xFFF2A43A), Icons.Rounded.Warehouse),
        HomeSection(4, strings.sparePartsWarehouse, strings.sparePartsWarehouseDesc, Color(0xFF13A88D), Icons.Rounded.SettingsSuggest),
        HomeSection(5, strings.assemblyAndHome, strings.assemblyAndHomeDesc, Color(0xFFE94A36), Icons.Rounded.Groups),
        HomeSection(6, strings.finishedGoods, strings.finishedGoodsDesc, Color(0xFF459DE7), Icons.Rounded.LocalShipping),
        HomeSection(7, strings.managementControl, strings.managementControlDesc, Color(0xFF8B5DE8), Icons.Rounded.BarChart),
        HomeSection(8, strings.globalMasterData, strings.globalMasterDataDesc, Color(0xFF718394), Icons.Rounded.Description)
    )

    Column(Modifier.fillMaxSize()) {
        HomeBrandHeader(strings)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("HomeScreen-main"))
                .padding(horizontal = 16.dp, vertical = 4.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(strings.systemName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                Text(uzbekDate(LocalDate.now()), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(14.dp))
            sections.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { section ->
                        val launched = section.id in setOf(1, 2, 5, 7)
                        val enabled = when (section.id) {
                            1 -> canOpenSeryo
                            2 -> canOpenTp
                            5 -> true
                            7 -> canOpenManagement
                            else -> false
                        }
                        SectionCard(
                            number = section.id,
                            title = section.title,
                            description = section.description,
                            enabled = launched && enabled,
                            modifier = Modifier.weight(1f),
                            accentColor = section.accent,
                            icon = section.icon,
                            onClick = {
                                when (section.id) {
                                    1 -> if (canOpenSeryo) onSeryo() else disabledMessage = true
                                    2 -> if (canOpenTp) onTp() else disabledMessage = true
                                    5 -> onAssembly()
                                    7 -> if (canOpenManagement) onManagement() else disabledMessage = true
                                    else -> disabledMessage = true
                                }
                            }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
            Spacer(Modifier.height(14.dp))
        }
    }

    if (disabledMessage) {
        AlertDialog(
            onDismissRequest = { disabledMessage = false },
            confirmButton = { TextButton(onClick = { disabledMessage = false }) { Text("OK") } },
            text = { Text(strings.notLaunched) }
        )
    }
}

@Composable
private fun HomeBrandHeader(strings: AppStrings) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val runtime by SyncStatusEvents.state.collectAsState()
    Column(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(R.drawable.toybola_wordmark),
                contentDescription = null,
                modifier = Modifier.width(150.dp).height(74.dp)
            )
            Spacer(Modifier.weight(1f))
            Surface(
                modifier = Modifier.clickable(enabled = !runtime.syncing) {
                    if (!runtime.syncing) scope.launch(kotlinx.coroutines.Dispatchers.IO) { FirebaseSyncCoordinator(context).syncNow() }
                    else FirebaseSyncScheduler.enqueue(context)
                },
                shape = RoundedCornerShape(999.dp),
                color = Color(0xFFF0F7FC)
            ) {
                Row(Modifier.padding(horizontal = 11.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Sync, contentDescription = null, tint = Color(0xFF2E86C1), modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(if (runtime.syncing) strings.syncing else strings.syncedShort, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

private fun uzbekDate(date: LocalDate): String {
    val months = listOf("yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr")
    return "${date.dayOfMonth}-${months[date.monthValue - 1]}, ${date.year}"
}

@Composable
fun ManagementMonitoringScreen(
    strings: AppStrings,
    onBack: () -> Unit,
    canOpen: (AppScreen) -> Boolean,
    onOpen: (AppScreen) -> Unit
) {
    val items = listOf(
        Triple("TP va Seryo", "Partiya, stanok, brigada, sifat va xomashyo", AppScreen.TP_MONITORING),
        Triple("Sborka", "Ishchi, brigada, sifat va foydalilik", AppScreen.MONITORING)
    )
    Column(Modifier.fillMaxSize()) {
        AppTopBar("Umumiy monitoring", canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items.forEachIndexed { index, item ->
                SectionCard(
                    number = index + 1,
                    title = item.first,
                    description = item.second,
                    enabled = canOpen(item.third),
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { if (canOpen(item.third)) onOpen(item.third) }
                )
            }
        }
    }
}
