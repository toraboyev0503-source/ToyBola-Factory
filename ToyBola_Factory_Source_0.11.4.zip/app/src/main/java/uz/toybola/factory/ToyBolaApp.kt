package uz.toybola.factory

import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.toybola.factory.core.data.AssemblyDataRepository
import uz.toybola.factory.core.data.TpDataRepository
import uz.toybola.factory.core.firebase.*
import uz.toybola.factory.core.notifications.NotificationInboxRepository
import uz.toybola.factory.core.notifications.NotificationRouteState
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.canReadScreen
import uz.toybola.factory.ui.components.GlobalBottomBar
import uz.toybola.factory.ui.model.AppScreen
import uz.toybola.factory.ui.model.AppStrings
import uz.toybola.factory.ui.screens.*
import uz.toybola.factory.ui.theme.ToyBolaTheme

@Composable
fun ToyBolaApp(
    preferences: AppPreferences,
    assemblyDataRepository: AssemblyDataRepository,
    tpDataRepository: TpDataRepository,
    notificationInboxRepository: NotificationInboxRepository
) {
    var settings by remember { mutableStateOf(preferences.loadSettings()) }
    var authenticated by remember { mutableStateOf(false) }
    val stack = remember { mutableStateListOf(AppScreen.SPLASH) }
    var lastInteraction by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    var unreadNotifications by remember { mutableStateOf(notificationInboxRepository.unreadCount()) }
    val scope = rememberCoroutineScope()
    val notificationRoute by NotificationRouteState.route
    val serverPolicyEvent by ServerPolicyEvents.revision.collectAsState()
    val syncRuntime by SyncStatusEvents.state.collectAsState()
    val serverAuthRepository = remember { ServerAuthRepository(preferences.appContext) }
    val firestoreSyncListener = remember { FirestoreSyncListener(preferences.appContext) }
    val lifecycleOwner = LocalLifecycleOwner.current
    var accessPolicy by remember {
        val code = preferences.setup()?.userCode.orEmpty()
        mutableStateOf(serverAuthRepository.cachedPolicy(code) ?: UserAccessPolicy.locked(code))
    }

    fun replace(screen: AppScreen) {
        stack.clear()
        stack.add(screen)
    }

    fun push(screen: AppScreen) {
        if (!accessPolicy.canReadScreen(screen)) return
        if (stack.lastOrNull() != screen) stack.add(screen)
    }

    fun pop() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
        else if (authenticated && stack.lastOrNull() != AppScreen.HOME) replace(AppScreen.HOME)
    }

    fun finishAuthentication(policy: UserAccessPolicy) {
        accessPolicy = policy
        authenticated = true
        lastInteraction = SystemClock.elapsedRealtime()
        replace(AppScreen.HOME)
        FirebaseSyncScheduler.ensurePeriodic(preferences.appContext)
        FirebaseSyncScheduler.enqueue(preferences.appContext)
    }

    fun lock() {
        authenticated = false
        replace(if (preferences.hasSetup()) AppScreen.LOGIN else AppScreen.SETUP)
    }

    fun openNotificationRoute(route: String) {
        if (route == "TP_PLAN" && accessPolicy.canReadScreen(AppScreen.TP_PLAN)) {
            replace(AppScreen.HOME)
            push(AppScreen.TP_MAIN)
            push(AppScreen.TP_PLAN)
            unreadNotifications = notificationInboxRepository.unreadCount()
            return
        }
        val target = when (route) {
            "BRIGADIR" -> AppScreen.BRIGADIR
            "QUALITY" -> AppScreen.QUALITY
            "MONITORING" -> AppScreen.MONITORING
            "DAILY_ISSUE" -> AppScreen.DAILY_ISSUE
            else -> null
        }
        if (target != null && accessPolicy.canReadScreen(target)) {
            replace(AppScreen.HOME)
            push(AppScreen.ASSEMBLY_ENTRY)
            push(AppScreen.ASSEMBLY)
            push(target)
        }
        unreadNotifications = notificationInboxRepository.unreadCount()
    }

    LaunchedEffect(authenticated, settings.autoLockMinutes) {
        while (authenticated) {
            delay(1_000)
            val elapsed = SystemClock.elapsedRealtime() - lastInteraction
            if (elapsed >= settings.autoLockMinutes * 60_000L) lock()
        }
    }

    LaunchedEffect(notificationRoute, authenticated) {
        if (authenticated && notificationRoute != null) {
            openNotificationRoute(notificationRoute.orEmpty())
            NotificationRouteState.clear()
        }
    }

    DisposableEffect(authenticated, accessPolicy.uid) {
        if (authenticated) firestoreSyncListener.start(accessPolicy.uid) else firestoreSyncListener.stop()
        onDispose { firestoreSyncListener.stop() }
    }

    LaunchedEffect(authenticated, lifecycleOwner) {
        if (authenticated) lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            launch {
                while (true) {
                    withContext(Dispatchers.IO) { FirebaseSyncCoordinator(preferences.appContext).syncNow() }
                    delay(30_000)
                }
            }
            launch {
                FirebaseSyncScheduler.foregroundRequests.collect {
                    delay(350)
                    withContext(Dispatchers.IO) { FirebaseSyncCoordinator(preferences.appContext).syncNow() }
                }
            }
        }
    }

    LaunchedEffect(serverPolicyEvent, authenticated) {
        if (authenticated && serverPolicyEvent > 0L) {
            serverAuthRepository.refreshPolicy()
                .onSuccess { refreshed ->
                    accessPolicy = refreshed
                    val currentScreen = stack.lastOrNull()
                    if (currentScreen != null && !refreshed.canReadScreen(currentScreen)) replace(AppScreen.HOME)
                }
                .onFailure { error ->
                    val message = error.message.orEmpty()
                    if (message.contains("o‘chirilgan", ignoreCase = true) || message.contains("disabled", ignoreCase = true)) lock()
                }
        }
    }

    ToyBolaTheme(settings) {
        val strings = AppStrings(settings.language)
        val current = stack.lastOrNull() ?: AppScreen.SPLASH
        val screenOwnsBack = current == AppScreen.TP_PLAN || current == AppScreen.TP_MASTER_DATA || current == AppScreen.BRIGADIR ||
            current == AppScreen.QUALITY || current == AppScreen.DAILY_ISSUE || current == AppScreen.MASTER_DATA || current == AppScreen.USER_ADMIN
        BackHandler(enabled = stack.size > 1 && !screenOwnsBack) { pop() }

        Surface(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
                .pointerInput(authenticated) {
                    if (authenticated) {
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            lastInteraction = SystemClock.elapsedRealtime()
                        }
                    }
                }
        ) {
            val showBottomBar = authenticated && current !in setOf(AppScreen.SPLASH, AppScreen.LOGIN, AppScreen.SETUP)
            Scaffold(
                containerColor = androidx.compose.ui.graphics.Color.Transparent,
                bottomBar = {
                    if (showBottomBar) {
                        GlobalBottomBar(
                            strings = strings,
                            current = current,
                            unreadNotifications = unreadNotifications,
                            syncing = syncRuntime.syncing,
                            onHome = { replace(AppScreen.HOME) },
                            onNotifications = {
                                unreadNotifications = notificationInboxRepository.unreadCount()
                                if (current != AppScreen.NOTIFICATIONS) push(AppScreen.NOTIFICATIONS)
                            },
                            onSync = {
                                if (!syncRuntime.syncing) scope.launch(Dispatchers.IO) {
                                    FirebaseSyncCoordinator(preferences.appContext).syncNow()
                                }
                            },
                            onSettings = { if (current != AppScreen.SETTINGS) push(AppScreen.SETTINGS) }
                        )
                    }
                }
            ) { innerPadding ->
                Box(Modifier.fillMaxSize().padding(if (showBottomBar) innerPadding else PaddingValues(0.dp))) {
                    when (current) {
                        AppScreen.SPLASH -> SplashScreen {
                            replace(if (preferences.hasSetup()) AppScreen.LOGIN else AppScreen.SETUP)
                        }
                        AppScreen.SETUP -> SetupScreen(
                            strings = strings,
                            onServerLogin = serverAuthRepository::signInWithCodes,
                            onAuthenticated = { deviceCode, userCode, policy ->
                                preferences.saveSetup(deviceCode, userCode)
                                finishAuthentication(policy)
                            }
                        )
                        AppScreen.LOGIN -> LoginScreen(
                            strings = strings,
                            savedSetup = preferences.setup(),
                            onServerLogin = serverAuthRepository::signInWithCodes,
                            onAuthenticated = { deviceCode, userCode, policy ->
                                preferences.saveSetup(deviceCode, userCode)
                                finishAuthentication(policy)
                            }
                        )
                        AppScreen.HOME -> HomeScreen(
                            strings = strings,
                            onMenu = {},
                            canOpenSeryo = accessPolicy.canReadScreen(AppScreen.TP_SERYO),
                            canOpenTp = accessPolicy.canReadScreen(AppScreen.TP_MAIN),
                            canOpenManagement = accessPolicy.canReadScreen(AppScreen.MANAGEMENT),
                            onSeryo = { push(AppScreen.TP_SERYO) },
                            onTp = { push(AppScreen.TP_MAIN) },
                            onAssembly = { push(AppScreen.ASSEMBLY_ENTRY) },
                            onManagement = { push(AppScreen.MANAGEMENT) }
                        )
                        AppScreen.SETTINGS -> SettingsScreen(
                            strings = strings,
                            settings = settings,
                            onSettingsChange = {
                                settings = it
                                preferences.saveSettings(it)
                            },
                            showUserManagement = accessPolicy.isAdmin(),
                            onUserManagement = { push(AppScreen.USER_ADMIN) },
                            onBackupRestore = { push(AppScreen.BACKUP_RESTORE) },
                            onLock = ::lock,
                            onBack = ::pop
                        )
                        AppScreen.MANAGEMENT -> ManagementMonitoringScreen(strings, ::pop, { accessPolicy.canReadScreen(it) }, ::push)
                        AppScreen.NOTIFICATIONS -> NotificationsScreen(
                            strings = strings,
                            repository = notificationInboxRepository,
                            onBack = {
                                unreadNotifications = notificationInboxRepository.unreadCount()
                                pop()
                            },
                            onOpenRoute = ::openNotificationRoute
                        )
                        AppScreen.TP_MAIN -> TpMainScreen(strings, ::pop, { accessPolicy.canReadScreen(it) }, ::push)
                        AppScreen.TP_PLAN -> TpPlanScreen(strings, tpDataRepository, ::pop)
                        AppScreen.TP_SERYO -> TpSeryoScreen(strings, tpDataRepository, ::pop)
                        AppScreen.TP_RECEIVING -> TpReceivingScreen(strings, tpDataRepository, ::pop)
                        AppScreen.TP_QUALITY -> TpQualityScreen(strings, tpDataRepository, ::pop)
                        AppScreen.TP_MONITORING -> TpMonitoringScreen(strings, tpDataRepository, ::pop)
                        AppScreen.TP_MASTER_DATA -> TpMasterDataScreen(strings, tpDataRepository, ::pop)
                        AppScreen.ASSEMBLY_ENTRY -> AssemblyEntryScreen(strings, onBack = ::pop) { push(AppScreen.ASSEMBLY) }
                        AppScreen.ASSEMBLY -> AssemblyMainScreen(strings = strings, onBack = ::pop, canOpen = { screen -> accessPolicy.canReadScreen(screen) }, onOpen = ::push)
                        AppScreen.BRIGADIR -> BrigadirScreen(strings, assemblyDataRepository, ::pop)
                        AppScreen.QUALITY -> QualityScreen(strings, assemblyDataRepository, ::pop)
                        AppScreen.DAILY_ISSUE -> DailyIssueScreen(strings, assemblyDataRepository, ::pop)
                        AppScreen.MONITORING -> MonitoringScreen(strings, assemblyDataRepository, ::pop, isAdmin = accessPolicy.isAdmin())
                        AppScreen.MASTER_DATA -> MasterDataScreen(strings, assemblyDataRepository, ::pop)
                        AppScreen.USER_ADMIN -> UserManagementScreen(
                            strings = strings,
                            assemblyRepository = assemblyDataRepository,
                            tpRepository = tpDataRepository,
                            onBack = ::pop,
                            currentUid = accessPolicy.uid,
                            onSelfDeviceCodeReset = { userCode, deviceCode -> preferences.saveSetup(deviceCode, userCode) }
                        )
                        AppScreen.BACKUP_RESTORE -> BackupRestoreScreen(
                            strings = strings,
                            repository = assemblyDataRepository,
                            isAdmin = accessPolicy.isAdmin(),
                            allowedBrigadeIds = accessPolicy.allowedBrigadeIds,
                            onBack = ::pop
                        )
                    }
                }
            }
        }
    }
}
