package uz.toybola.factory.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.Badge
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.toybola.factory.ui.model.AppScreen
import uz.toybola.factory.ui.model.AppStrings

@Composable
fun GlobalBottomBar(
    strings: AppStrings,
    current: AppScreen,
    unreadNotifications: Int,
    syncing: Boolean,
    onHome: () -> Unit,
    onNotifications: () -> Unit,
    onSync: () -> Unit,
    onSettings: () -> Unit
) {
    // Navigation-bar inset stays outside the rounded panel. This keeps the panel at a
    // stable visual height and prevents the last label from being clipped on narrow phones.
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            color = Color.White,
            shadowElevation = 8.dp,
            tonalElevation = 0.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(76.dp)
                    .padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BottomItem(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Home,
                    label = strings.homeNav,
                    selected = current == AppScreen.HOME,
                    onClick = onHome
                )
                BottomItem(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Notifications,
                    label = strings.notifications,
                    selected = current == AppScreen.NOTIFICATIONS,
                    badgeCount = unreadNotifications,
                    onClick = onNotifications
                )
                BottomItem(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Sync,
                    // The top status pill may say "Sinxronlanmoqda"; the navigation
                    // destination itself always stays the short, stable label.
                    label = strings.syncNav,
                    selected = false,
                    rotatingHint = syncing,
                    onClick = onSync
                )
                BottomItem(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Settings,
                    label = strings.menu,
                    selected = current == AppScreen.SETTINGS,
                    onClick = onSettings
                )
            }
        }
    }
}

@Composable
private fun BottomItem(
    modifier: Modifier,
    icon: ImageVector,
    label: String,
    selected: Boolean,
    badgeCount: Int = 0,
    rotatingHint: Boolean = false,
    onClick: () -> Unit
) {
    val tint = when {
        selected -> Color(0xFF1976D2)
        rotatingHint -> Color(0xFF54798F)
        else -> Color(0xFF667A87)
    }
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = if (selected) Color(0xFFEAF4FF) else Color.Transparent,
        tonalElevation = 0.dp,
        modifier = modifier.padding(horizontal = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(contentAlignment = Alignment.TopEnd) {
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(25.dp))
                if (badgeCount > 0) {
                    Badge(
                        containerColor = Color(0xFFFF4D43),
                        contentColor = Color.White,
                        modifier = Modifier.offset(x = 8.dp, y = (-5).dp)
                    ) {
                        Text(
                            badgeCount.coerceAtMost(99).toString(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                label,
                color = tint,
                fontSize = 10.sp,
                lineHeight = 11.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
