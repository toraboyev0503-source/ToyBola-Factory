package uz.toybola.factory.core.data

import org.w3c.dom.Element
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.util.Locale
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

/** One validated detail row from the standard TP Excel template. */
data class TpExcelDetailRow(
    val article: String,
    val productName: String,
    val detailName: String,
    val requiredPerProduct: Int,
    val piecesPerShot: Int,
    val bagCapacity: Int,
    val cycleSeconds: Int,
    val grossShotWeightGrams: Double,
    val unusableShotWeightGrams: Double,
    val resinCodes: List<String>,
    val recycledCodes: List<String>,
    val unitPrice: Double,
    val compatibleCapacities: Set<Int>
)

data class TpExcelColorRow(
    val article: String,
    val detailName: String,
    val colorCode: String,
    val share: Double,
    val gramsPer25Kg: Double
)

data class TpExcelBrigadeRow(
    val name: String,
    val shopName: String,
    val shiftName: String
)

data class TpExcelMachineRow(
    val number: Int,
    val shopName: String,
    val capacity: Int,
    val name: String
)

data class TpExcelWorkerRow(
    val name: String,
    val brigadeName: String
)

data class TpExcelMaterialRow(
    val type: TpMaterialType,
    val code: String,
    val name: String,
    val openingAmount: Double
)

data class TpExcelImportPayload(
    val details: List<TpExcelDetailRow>,
    val colors: List<TpExcelColorRow>,
    val brigades: List<TpExcelBrigadeRow> = emptyList(),
    val machines: List<TpExcelMachineRow> = emptyList(),
    val workers: List<TpExcelWorkerRow> = emptyList(),
    val materials: List<TpExcelMaterialRow> = emptyList()
) {
    val productCount: Int get() = details.map { it.article.uppercase(Locale.ROOT) }.distinct().size
    val detailCount: Int get() = details.size
    val colorCount: Int get() = colors.size
    val brigadeCount: Int get() = brigades.size
    val machineCount: Int get() = machines.size
    val workerCount: Int get() = workers.size
    val materialCount: Int get() = materials.size
}

data class TpExcelImportInspection(
    val payload: TpExcelImportPayload,
    val errors: List<String>
) {
    val isValid: Boolean get() = errors.isEmpty()
}

/**
 * Lightweight XLSX reader used only for the ToyBola TP import template.
 * It intentionally has no Apache POI dependency, keeping the Android APK small and predictable.
 *
 * [inspect] collects all detectable workbook errors in one pass so the operator can fix them
 * together instead of uploading the workbook repeatedly for one error at a time.
 */
object TpExcelImporter {
    private const val PRODUCTS_SHEET = "Mahsulotlar"
    private const val COLORS_SHEET = "Ranglar"
    private const val BRIGADES_SHEET = "Brigadalar"
    private const val MACHINES_SHEET = "Stanoklar"
    private const val WORKERS_SHEET = "Ishchilar"
    private const val MATERIALS_SHEET = "Materiallar"

    fun parse(input: InputStream): TpExcelImportPayload {
        val inspection = inspect(input)
        require(inspection.errors.isEmpty()) {
            inspection.errors.joinToString(separator = "\n", prefix = "${inspection.errors.size} ta muammo topildi:\n")
        }
        return inspection.payload
    }

    fun inspect(input: InputStream): TpExcelImportInspection {
        val errors = mutableListOf<String>()
        val entries = runCatching { readZip(input) }.getOrElse {
            return TpExcelImportInspection(TpExcelImportPayload(emptyList(), emptyList()), listOf("Excel faylini o‘qib bo‘lmadi: ${it.message.orEmpty()}"))
        }
        if (!entries.containsKey("xl/workbook.xml")) {
            return TpExcelImportInspection(TpExcelImportPayload(emptyList(), emptyList()), listOf("Bu Excel (.xlsx) fayli emas yoki fayl buzilgan"))
        }

        val sharedStrings = entries["xl/sharedStrings.xml"]?.let { runCatching { parseSharedStrings(it) }.getOrElse { emptyList() } }.orEmpty()
        val sheets = runCatching { sheetTargets(entries) }.getOrElse {
            return TpExcelImportInspection(TpExcelImportPayload(emptyList(), emptyList()), listOf("Excel varaq tuzilmasini o‘qib bo‘lmadi: ${it.message.orEmpty()}"))
        }

        fun sheetRows(name: String, required: Boolean): List<List<String>> {
            val path = sheets[name]
            if (path == null) {
                if (required) errors += "Excelda '$name' varag‘i topilmadi. Standart shablondan foydalaning."
                return emptyList()
            }
            val bytes = entries[path]
            if (bytes == null) {
                errors += "$name varag‘i o‘qilmadi"
                return emptyList()
            }
            return runCatching { parseSheet(bytes, sharedStrings) }.getOrElse {
                errors += "$name varag‘i buzilgan yoki o‘qilmadi: ${it.message.orEmpty()}"
                emptyList()
            }
        }

        val detailRows = sheetRows(PRODUCTS_SHEET, required = true)
        val colorRows = sheetRows(COLORS_SHEET, required = true)
        val brigadeRows = sheetRows(BRIGADES_SHEET, required = false)
        val machineRows = sheetRows(MACHINES_SHEET, required = false)
        val workerRows = sheetRows(WORKERS_SHEET, required = false)
        val materialRows = sheetRows(MATERIALS_SHEET, required = false)

        val details = parseDetails(detailRows, errors)
        val colors = parseColors(colorRows, errors)
        val brigades = parseBrigades(brigadeRows, errors)
        val machines = parseMachines(machineRows, errors)
        val workers = parseWorkers(workerRows, errors)
        val materials = parseMaterials(materialRows, errors)

        if (details.isEmpty() && detailRows.isNotEmpty()) errors += "Mahsulotlar varag‘ida import qilinadigan to‘g‘ri detal yo‘q"

        val detailKeys = details.map { key(it.article, it.detailName) }.toSet()
        details.filter { detail -> colors.none { key(it.article, it.detailName) == key(detail.article, detail.detailName) } }
            .forEach { errors += "$COLORS_SHEET: ${it.article}/${it.detailName} uchun kamida bitta rang kiriting" }
        colors.filter { key(it.article, it.detailName) !in detailKeys }
            .forEach { errors += "$COLORS_SHEET: ${it.article}/${it.detailName} Mahsulotlar varag‘ida topilmadi" }

        details.groupBy { it.article }.forEach { (article, values) ->
            val names = values.map { it.productName.trim() }.distinct()
            if (names.size > 1) errors += "$PRODUCTS_SHEET: $article uchun mahsulot nomi turlicha yozilgan: ${names.joinToString()}"
        }

        return TpExcelImportInspection(
            payload = TpExcelImportPayload(details, colors, brigades, machines, workers, materials),
            errors = errors.distinct()
        )
    }

    private fun parseDetails(rows: List<List<String>>, errors: MutableList<String>): List<TpExcelDetailRow> {
        if (rows.isEmpty()) return emptyList()
        val headers = headerMapOrError(PRODUCTS_SHEET, rows.first(), errors) ?: return emptyList()
        val ixArticle = headers.requiredOrError(PRODUCTS_SHEET, errors, "Artikul")
        val ixProduct = headers.requiredOrError(PRODUCTS_SHEET, errors, "Mahsulot nomi")
        val ixDetail = headers.requiredOrError(PRODUCTS_SHEET, errors, "Detal nomi")
        val ixRequired = headers.requiredOrError(PRODUCTS_SHEET, errors, "1 mahsulotga nechta")
        val ixPerShot = headers.requiredOrError(PRODUCTS_SHEET, errors, "1 jimda nechta")
        val ixBag = headers.requiredOrError(PRODUCTS_SHEET, errors, "1 qopda nechta")
        val ixCycle = headers.requiredOrError(PRODUCTS_SHEET, errors, "1 jim vaqti (sekund)")
        val ixGross = headers.requiredOrError(PRODUCTS_SHEET, errors, "1 jim umumiy og'irligi (g)", "1 jim umumiy og‘irligi (g)")
        val ixUnusable = headers.requiredOrError(PRODUCTS_SHEET, errors, "Yaroqsiz qism og'irligi (g)", "Yaroqsiz qism og‘irligi (g)")
        val ixResins = headers.requiredOrError(PRODUCTS_SHEET, errors, "Seryo turlari")
        val ixRecycled = headers.optional("Ftarichka turlari", "Ftarichka")
        val ixPrice = headers.requiredOrError(PRODUCTS_SHEET, errors, "1 jim narxi (so'm)", "1 jim narxi (so‘m)")
        val ixCapacities = headers.requiredOrError(PRODUCTS_SHEET, errors, "Stanok sig'imlari", "Stanok sig‘imlari")
        val requiredIndexes = listOf(ixArticle, ixProduct, ixDetail, ixRequired, ixPerShot, ixBag, ixCycle, ixGross, ixUnusable, ixResins, ixPrice, ixCapacities)
        if (requiredIndexes.any { it == null }) return emptyList()

        val result = mutableListOf<TpExcelDetailRow>()
        val seen = mutableSetOf<String>()
        rows.drop(1).forEachIndexed { offset, row ->
            if (row.all { it.isBlank() }) return@forEachIndexed
            val line = offset + 2
            runCatching {
                fun text(index: Int?, label: String): String = cell(row, index!!).trim().also {
                    require(it.isNotBlank()) { "$PRODUCTS_SHEET $line-qator: '$label' bo‘sh" }
                }
                val article = cleanCode(text(ixArticle, "Artikul"))
                val product = text(ixProduct, "Mahsulot nomi")
                val detail = text(ixDetail, "Detal nomi")
                val rowKey = key(article, detail)
                require(seen.add(rowKey)) { "$PRODUCTS_SHEET $line-qator: $article/$detail takrorlangan" }
                val rawResins = splitCodes(text(ixResins, "Seryo turlari"))
                val genericRecycledMarker = rawResins.any { it.isGenericRecycledMarker() }
                val resins = rawResins.filterNot { it.isGenericRecycledMarker() }
                val explicitRecycled = ixRecycled?.let { splitCodes(cell(row, it)) }.orEmpty()
                val recycled = when {
                    explicitRecycled.isNotEmpty() -> explicitRecycled
                    genericRecycledMarker -> listOf(TP_ANY_RECYCLED_CODE)
                    else -> emptyList()
                }
                require(resins.isNotEmpty()) { "$PRODUCTS_SHEET $line-qator: kamida bitta haqiqiy seryo turi kerak" }
                val capacities = splitInts(text(ixCapacities, "Stanok sig‘imlari"))
                require(capacities.isNotEmpty()) { "$PRODUCTS_SHEET $line-qator: stanok sig‘imlarini kiriting" }
                val required = intValue(cell(row, ixRequired!!), "$PRODUCTS_SHEET $line-qator: 1 mahsulotga nechta")
                val perShot = intValue(cell(row, ixPerShot!!), "$PRODUCTS_SHEET $line-qator: 1 jimda nechta")
                val bag = intValue(cell(row, ixBag!!), "$PRODUCTS_SHEET $line-qator: 1 qopda nechta")
                val cycle = intValue(cell(row, ixCycle!!), "$PRODUCTS_SHEET $line-qator: 1 jim vaqti")
                val gross = decimalValue(cell(row, ixGross!!), "$PRODUCTS_SHEET $line-qator: umumiy og‘irlik")
                val unusable = decimalValue(cell(row, ixUnusable!!), "$PRODUCTS_SHEET $line-qator: yaroqsiz og‘irlik")
                val price = decimalValue(cell(row, ixPrice!!), "$PRODUCTS_SHEET $line-qator: 1 jim narxi")
                require(required > 0 && perShot > 0 && bag > 0 && cycle > 0) { "$PRODUCTS_SHEET $line-qator: sonli normativlar 0 dan katta bo‘lsin" }
                require(gross > 0.0 && unusable in 0.0..gross) { "$PRODUCTS_SHEET $line-qator: og‘irliklarni tekshiring" }
                require(price >= 0.0) { "$PRODUCTS_SHEET $line-qator: narx manfiy bo‘lmasin" }
                result += TpExcelDetailRow(article, product, detail, required, perShot, bag, cycle, gross, unusable, resins, recycled, price, capacities)
            }.onFailure { errors += (it.message ?: "$PRODUCTS_SHEET $line-qator: noma’lum xato") }
        }
        return result
    }

    private fun parseColors(rows: List<List<String>>, errors: MutableList<String>): List<TpExcelColorRow> {
        if (rows.isEmpty()) return emptyList()
        val headers = headerMapOrError(COLORS_SHEET, rows.first(), errors) ?: return emptyList()
        val ixArticle = headers.requiredOrError(COLORS_SHEET, errors, "Artikul")
        val ixDetail = headers.requiredOrError(COLORS_SHEET, errors, "Detal nomi")
        val ixColor = headers.requiredOrError(COLORS_SHEET, errors, "Rang kodi")
        val ixShare = headers.requiredOrError(COLORS_SHEET, errors, "Taqsimot ulushi")
        val ixGrams = headers.requiredOrError(COLORS_SHEET, errors, "25 kg ga krasitel (g)")
        if (listOf(ixArticle, ixDetail, ixColor, ixShare, ixGrams).any { it == null }) return emptyList()
        val result = mutableListOf<TpExcelColorRow>()
        val seen = mutableSetOf<String>()
        rows.drop(1).forEachIndexed { offset, row ->
            if (row.all { it.isBlank() }) return@forEachIndexed
            val line = offset + 2
            runCatching {
                val article = cleanCode(cell(row, ixArticle!!))
                val detail = cell(row, ixDetail!!).trim()
                val color = cleanCode(cell(row, ixColor!!))
                require(article.isNotBlank() && detail.isNotBlank() && color.isNotBlank()) { "$COLORS_SHEET $line-qator: artikul, detal va rang kodi majburiy" }
                val share = decimalValue(cell(row, ixShare!!), "$COLORS_SHEET $line-qator: taqsimot ulushi")
                val grams = decimalValue(cell(row, ixGrams!!), "$COLORS_SHEET $line-qator: krasitel")
                require(share > 0.0 && grams >= 0.0) { "$COLORS_SHEET $line-qator: ulush > 0 va krasitel >= 0 bo‘lsin" }
                val unique = "${key(article, detail)}|$color"
                require(seen.add(unique)) { "$COLORS_SHEET $line-qator: $article/$detail/$color takrorlangan" }
                result += TpExcelColorRow(article, detail, color, share, grams)
            }.onFailure { errors += (it.message ?: "$COLORS_SHEET $line-qator: noma’lum xato") }
        }
        return result
    }

    private fun parseBrigades(rows: List<List<String>>, errors: MutableList<String>): List<TpExcelBrigadeRow> {
        if (rows.isEmpty()) return emptyList()
        val headers = headerMapOrError(BRIGADES_SHEET, rows.first(), errors) ?: return emptyList()
        val ixName = headers.requiredOrError(BRIGADES_SHEET, errors, "Brigada nomi")
        val ixShop = headers.requiredOrError(BRIGADES_SHEET, errors, "Sex")
        val ixShift = headers.requiredOrError(BRIGADES_SHEET, errors, "Smena")
        if (listOf(ixName, ixShop, ixShift).any { it == null }) return emptyList()
        val result = mutableListOf<TpExcelBrigadeRow>()
        val seen = mutableSetOf<String>()
        rows.drop(1).forEachIndexed { offset, row ->
            if (row.all { it.isBlank() }) return@forEachIndexed
            val line = offset + 2
            runCatching {
                val name = cell(row, ixName!!).trim()
                val shop = cell(row, ixShop!!).trim()
                val shift = cell(row, ixShift!!).trim()
                require(name.isNotBlank() && shop.isNotBlank() && shift.isNotBlank()) { "$BRIGADES_SHEET $line-qator: Brigada nomi, Sex va Smena majburiy" }
                require(seen.add(name.lowercase(Locale.ROOT))) { "$BRIGADES_SHEET $line-qator: '$name' takrorlangan" }
                result += TpExcelBrigadeRow(name, shop, shift)
            }.onFailure { errors += (it.message ?: "$BRIGADES_SHEET $line-qator: noma’lum xato") }
        }
        return result
    }

    private fun parseMachines(rows: List<List<String>>, errors: MutableList<String>): List<TpExcelMachineRow> {
        if (rows.isEmpty()) return emptyList()
        val headers = headerMapOrError(MACHINES_SHEET, rows.first(), errors) ?: return emptyList()
        val ixNumber = headers.requiredOrError(MACHINES_SHEET, errors, "Stanok raqami")
        val ixShop = headers.requiredOrError(MACHINES_SHEET, errors, "Sex")
        val ixCapacity = headers.requiredOrError(MACHINES_SHEET, errors, "Sig'im", "Sig‘im", "Stanok sig'imi", "Stanok sig‘imi")
        val ixName = headers.optional("Qo'shimcha nom", "Qo‘shimcha nom", "Nomi")
        if (listOf(ixNumber, ixShop, ixCapacity).any { it == null }) return emptyList()
        val result = mutableListOf<TpExcelMachineRow>()
        val seen = mutableSetOf<Int>()
        rows.drop(1).forEachIndexed { offset, row ->
            if (row.all { it.isBlank() }) return@forEachIndexed
            val line = offset + 2
            runCatching {
                val number = intValue(cell(row, ixNumber!!), "$MACHINES_SHEET $line-qator: Stanok raqami")
                val shop = cell(row, ixShop!!).trim()
                val capacity = intValue(cell(row, ixCapacity!!), "$MACHINES_SHEET $line-qator: Sig‘im")
                val name = ixName?.let { cell(row, it).trim() }.orEmpty()
                require(shop.isNotBlank()) { "$MACHINES_SHEET $line-qator: Sex bo‘sh" }
                require(seen.add(number)) { "$MACHINES_SHEET $line-qator: $number-stanok takrorlangan" }
                result += TpExcelMachineRow(number, shop, capacity, name)
            }.onFailure { errors += (it.message ?: "$MACHINES_SHEET $line-qator: noma’lum xato") }
        }
        return result
    }

    private fun parseWorkers(rows: List<List<String>>, errors: MutableList<String>): List<TpExcelWorkerRow> {
        if (rows.isEmpty()) return emptyList()
        val headers = headerMapOrError(WORKERS_SHEET, rows.first(), errors) ?: return emptyList()
        val ixName = headers.requiredOrError(WORKERS_SHEET, errors, "Ishchi ismi", "Ism")
        val ixBrigade = headers.requiredOrError(WORKERS_SHEET, errors, "Brigada")
        if (listOf(ixName, ixBrigade).any { it == null }) return emptyList()
        val result = mutableListOf<TpExcelWorkerRow>()
        val seen = mutableSetOf<String>()
        rows.drop(1).forEachIndexed { offset, row ->
            if (row.all { it.isBlank() }) return@forEachIndexed
            val line = offset + 2
            runCatching {
                val name = cell(row, ixName!!).trim()
                val brigade = cell(row, ixBrigade!!).trim()
                require(name.isNotBlank() && brigade.isNotBlank()) { "$WORKERS_SHEET $line-qator: Ishchi ismi va Brigada majburiy" }
                val unique = brigade.lowercase(Locale.ROOT) + "|" + name.lowercase(Locale.ROOT)
                require(seen.add(unique)) { "$WORKERS_SHEET $line-qator: $brigade/$name takrorlangan" }
                result += TpExcelWorkerRow(name, brigade)
            }.onFailure { errors += (it.message ?: "$WORKERS_SHEET $line-qator: noma’lum xato") }
        }
        return result
    }

    private fun parseMaterials(rows: List<List<String>>, errors: MutableList<String>): List<TpExcelMaterialRow> {
        if (rows.isEmpty()) return emptyList()
        val headers = headerMapOrError(MATERIALS_SHEET, rows.first(), errors) ?: return emptyList()
        val ixType = headers.requiredOrError(MATERIALS_SHEET, errors, "Turi")
        val ixCode = headers.requiredOrError(MATERIALS_SHEET, errors, "Kod")
        val ixName = headers.requiredOrError(MATERIALS_SHEET, errors, "Nomi")
        val ixAmount = headers.requiredOrError(MATERIALS_SHEET, errors, "Boshlang'ich ostatka", "Boshlang‘ich ostatka")
        if (listOf(ixType, ixCode, ixName, ixAmount).any { it == null }) return emptyList()
        val result = mutableListOf<TpExcelMaterialRow>()
        val seen = mutableSetOf<String>()
        rows.drop(1).forEachIndexed { offset, row ->
            if (row.all { it.isBlank() }) return@forEachIndexed
            val line = offset + 2
            runCatching {
                val rawType = cell(row, ixType!!).trim().lowercase(Locale.ROOT)
                val type = when (rawType.replace("‘", "'").replace("’", "'")) {
                    "seryo", "resin" -> TpMaterialType.RESIN
                    "krasitel", "color", "rang" -> TpMaterialType.COLOR
                    "ftarichka", "vtorichka", "recycled" -> TpMaterialType.RECYCLED
                    else -> error("$MATERIALS_SHEET $line-qator: Turi Seryo, Krasitel yoki Ftarichka bo‘lsin")
                }
                val code = cleanCode(cell(row, ixCode!!))
                val name = cell(row, ixName!!).trim().ifBlank { code }
                val amount = decimalValue(cell(row, ixAmount!!), "$MATERIALS_SHEET $line-qator: boshlang‘ich ostatka")
                require(code.isNotBlank()) { "$MATERIALS_SHEET $line-qator: Kod majburiy" }
                require(amount >= 0.0) { "$MATERIALS_SHEET $line-qator: ostatka manfiy bo‘lmasin" }
                require(seen.add(type.name + "|" + code)) { "$MATERIALS_SHEET $line-qator: ${type.displayName()}/$code takrorlangan" }
                result += TpExcelMaterialRow(type, code, name, if (type == TpMaterialType.COLOR) amount else normalizeFeedstockKg(amount))
            }.onFailure { errors += (it.message ?: "$MATERIALS_SHEET $line-qator: noma’lum xato") }
        }
        return result
    }

    private fun readZip(input: InputStream): Map<String, ByteArray> {
        val result = linkedMapOf<String, ByteArray>()
        ZipInputStream(input.buffered()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) result[entry.name] = zip.readBytes()
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        return result
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val doc = document(bytes)
        val nodes = doc.getElementsByTagNameNS("*", "si")
        return (0 until nodes.length).map { index ->
            val si = nodes.item(index) as Element
            val texts = si.getElementsByTagNameNS("*", "t")
            buildString { for (i in 0 until texts.length) append(texts.item(i).textContent) }
        }
    }

    private fun sheetTargets(entries: Map<String, ByteArray>): Map<String, String> {
        val workbook = document(entries.getValue("xl/workbook.xml"))
        val relsBytes = entries["xl/_rels/workbook.xml.rels"] ?: error("Excel relationships topilmadi")
        val relsDoc = document(relsBytes)
        val relationships = mutableMapOf<String, String>()
        val relNodes = relsDoc.getElementsByTagNameNS("*", "Relationship")
        for (i in 0 until relNodes.length) {
            val e = relNodes.item(i) as Element
            relationships[e.getAttribute("Id")] = e.getAttribute("Target")
        }
        val result = linkedMapOf<String, String>()
        val sheetNodes = workbook.getElementsByTagNameNS("*", "sheet")
        for (i in 0 until sheetNodes.length) {
            val e = sheetNodes.item(i) as Element
            val name = e.getAttribute("name")
            val rid = e.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id")
                .ifBlank { e.getAttribute("r:id") }
            val target = relationships[rid] ?: continue
            val normalized = when {
                target.startsWith("/") -> target.removePrefix("/")
                target.startsWith("xl/") -> target
                else -> "xl/$target"
            }.replace("../", "")
            result[name] = normalized
        }
        return result
    }

    private fun parseSheet(bytes: ByteArray, sharedStrings: List<String>): List<List<String>> {
        val doc = document(bytes)
        val rowNodes = doc.getElementsByTagNameNS("*", "row")
        val rows = mutableListOf<List<String>>()
        for (i in 0 until rowNodes.length) {
            val row = rowNodes.item(i) as Element
            val cells = row.getElementsByTagNameNS("*", "c")
            val values = mutableMapOf<Int, String>()
            var maxCol = -1
            for (j in 0 until cells.length) {
                val cell = cells.item(j) as Element
                val ref = cell.getAttribute("r")
                val col = columnIndex(ref)
                if (col < 0) continue
                maxCol = maxOf(maxCol, col)
                val type = cell.getAttribute("t")
                val value = when (type) {
                    "inlineStr" -> {
                        val t = cell.getElementsByTagNameNS("*", "t")
                        buildString { for (k in 0 until t.length) append(t.item(k).textContent) }
                    }
                    "s" -> firstText(cell, "v").toIntOrNull()?.let { sharedStrings.getOrNull(it) }.orEmpty()
                    "b" -> if (firstText(cell, "v") == "1") "TRUE" else "FALSE"
                    else -> firstText(cell, "v")
                }
                values[col] = value
            }
            if (maxCol >= 0) rows += (0..maxCol).map { values[it].orEmpty() }
        }
        return rows
    }

    private fun firstText(parent: Element, localName: String): String {
        val nodes = parent.getElementsByTagNameNS("*", localName)
        return if (nodes.length > 0) nodes.item(0).textContent.orEmpty() else ""
    }

    private fun document(bytes: ByteArray) = DocumentBuilderFactory.newInstance().apply {
        isNamespaceAware = true
        runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
        runCatching { setFeature("http://xml.org/sax/features/external-general-entities", false) }
        runCatching { setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
    }.newDocumentBuilder().parse(ByteArrayInputStream(bytes))

    private fun columnIndex(ref: String): Int {
        val letters = ref.takeWhile { it.isLetter() }.uppercase(Locale.ROOT)
        if (letters.isBlank()) return -1
        var value = 0
        letters.forEach { value = value * 26 + (it - 'A' + 1) }
        return value - 1
    }

    private fun cell(row: List<String>, index: Int): String = row.getOrNull(index).orEmpty()
    private fun decimalValue(raw: String, label: String): Double = raw.trim().replace(',', '.').toDoubleOrNull()
        ?.takeIf { it.isFinite() } ?: error("$label noto‘g‘ri")
    private fun intValue(raw: String, label: String): Int {
        val value = decimalValue(raw, label)
        require(value % 1.0 == 0.0 && value in 1.0..Int.MAX_VALUE.toDouble()) { "$label butun son bo‘lishi kerak" }
        return value.toInt()
    }
    private fun longIntValue(raw: String, label: String): Long {
        val value = decimalValue(raw, label)
        require(value % 1.0 == 0.0 && value in 1.0..Long.MAX_VALUE.toDouble()) { "$label butun son bo‘lishi kerak" }
        return value.toLong()
    }
    private fun cleanCode(raw: String): String {
        var value = raw.trim()
        if (value.length >= 2 && ((value.first() == '"' && value.last() == '"') || (value.first() == '\'' && value.last() == '\''))) {
            value = value.substring(1, value.length - 1)
        } else if (value.startsWith("'") && value.length > 1) {
            // Excel users often type '003 to force text; the apostrophe is not part of the code.
            value = value.substring(1)
        }
        return value.trim().uppercase(Locale.ROOT)
    }
    private fun splitCodes(raw: String): List<String> = raw.split(',', '/', ';').map(::cleanCode).filter { it.isNotBlank() }.distinct()
    private fun String.isGenericRecycledMarker(): Boolean = when (trim().lowercase(Locale.ROOT)) {
        "ftarichka", "vtorichka", "recycled" -> true
        else -> false
    }
    private fun splitInts(raw: String): Set<Int> = raw.split(',', '/', ';', ' ').mapNotNull { it.trim().toIntOrNull() }.filter { it > 0 }.toSet()
    private fun key(article: String, detail: String): String = article.trim().uppercase(Locale.ROOT) + "|" + detail.trim().lowercase(Locale.ROOT)

    private fun headerMapOrError(sheet: String, headerRow: List<String>, errors: MutableList<String>): HeaderMap? =
        runCatching { HeaderMap(headerRow) }.getOrElse {
            errors += "$sheet sarlavhalari o‘qilmadi"
            null
        }

    private class HeaderMap(headerRow: List<String>) {
        private val indexes = headerRow.mapIndexed { index, value -> normalize(value) to index }.toMap()
        fun requiredOrError(sheet: String, errors: MutableList<String>, vararg aliases: String): Int? {
            val value = aliases.firstNotNullOfOrNull { indexes[normalize(it)] }
            if (value == null) errors += "$sheet: ustun topilmadi — ${aliases.first()}"
            return value
        }
        fun optional(vararg aliases: String): Int? = aliases.firstNotNullOfOrNull { indexes[normalize(it)] }
        private fun normalize(value: String): String = value.trim().lowercase(Locale.ROOT)
            .replace('‘', '\'').replace('’', '\'').replace('`', '\'')
            .replace(Regex("\\s+"), " ")
    }
}
