package uz.toybola.factory.core.data

import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.OutputStream
import java.time.LocalDate
import java.time.YearMonth

data class TpStockPeriod(
    val from: LocalDate,
    val to: LocalDate,
    val label: String
)

data class TpStockReportRow(
    val index: Int,
    val code: String,
    val incoming: Double,
    val outgoing: Double,
    val closing: Double
)

data class TpStockBalanceReport(
    val title: String,
    val periodLabel: String,
    val unit: String,
    val rows: List<TpStockReportRow>
)

fun tpStockPeriod(year: Int, month: Int?, day: Int?): TpStockPeriod {
    return when {
        month == null -> TpStockPeriod(LocalDate.of(year, 1, 1), LocalDate.of(year, 12, 31), "$year yil")
        day == null -> {
            val ym = YearMonth.of(year, month)
            TpStockPeriod(ym.atDay(1), ym.atEndOfMonth(), "%02d.%04d".format(month, year))
        }
        else -> {
            val date = LocalDate.of(year, month, day)
            TpStockPeriod(date, date, date.toString())
        }
    }
}

fun TpMaterial.periodIncoming(period: TpStockPeriod): Double = movements
    .filter { it.kind == TpMaterialMovementKind.IN && runCatching { LocalDate.parse(it.createdAt.take(10)) }.getOrNull()?.let { date -> !date.isBefore(period.from) && !date.isAfter(period.to) } == true }
    .sumOf { it.amount }

fun TpMaterial.periodOutgoing(period: TpStockPeriod): Double = movements
    .filter { it.kind == TpMaterialMovementKind.OUT && runCatching { LocalDate.parse(it.createdAt.take(10)) }.getOrNull()?.let { date -> !date.isBefore(period.from) && !date.isAfter(period.to) } == true }
    .sumOf { it.amount }

fun TpMaterial.closingAt(date: LocalDate): Double = availableAmount + movements
    .filter { runCatching { LocalDate.parse(it.createdAt.take(10)) }.getOrNull()?.let { d -> !d.isAfter(date) } == true }
    .sumOf { if (it.kind == TpMaterialMovementKind.IN) it.amount else -it.amount }

fun buildTpStockBalanceReport(data: TpData, type: TpMaterialType, period: TpStockPeriod, search: String = ""): TpStockBalanceReport {
    val rows = data.materials
        .filter { !it.archived && it.type == type && (search.isBlank() || it.code.contains(search, true)) }
        .sortedBy { it.code }
        .mapIndexed { index, material ->
            TpStockReportRow(
                index = index + 1,
                code = material.code,
                incoming = type.operationalKg(material.periodIncoming(period)),
                outgoing = type.operationalKg(material.periodOutgoing(period)),
                closing = type.operationalKg(material.closingAt(period.to))
            )
        }
    return TpStockBalanceReport(
        title = "${type.displayName()} oldi-berdi",
        periodLabel = period.label,
        unit = "kg",
        rows = rows
    )
}

fun TpStockBalanceReport.asTable(): TpReportTable = TpReportTable(
    title = title,
    metadata = listOf("Davr: $periodLabel", "Birlik: $unit"),
    headers = listOf("№", "Kod", "Prixod", "Rasxod", "Ostatka"),
    rows = rows.map { row -> listOf(row.index.toString(), row.code, formatTpNumber(row.incoming), formatTpNumber(row.outgoing), formatTpNumber(row.closing)) }
)

object TpStockPdfExporter {
    fun write(output: OutputStream, report: TpStockBalanceReport) {
        val document = PdfDocument()
        val pageWidth = 595 // A4 at 72 dpi
        val pageHeight = 842
        val margin = 36f
        val headerPaint = Paint().apply { textSize = 15f; isFakeBoldText = true }
        val metaPaint = Paint().apply { textSize = 9.5f }
        val cellPaint = Paint().apply { textSize = 8.5f }
        val boldPaint = Paint(cellPaint).apply { isFakeBoldText = true }
        val linePaint = Paint().apply { strokeWidth = 0.6f }
        val rowHeight = 22f
        val colX = floatArrayOf(margin, margin + 34f, margin + 150f, margin + 265f, margin + 380f)
        val widths = floatArrayOf(34f, 116f, 115f, 115f, 143f)
        var pageNumber = 1
        var rowIndex = 0
        while (rowIndex < report.rows.size || (report.rows.isEmpty() && pageNumber == 1)) {
            val page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
            val c = page.canvas
            var y = margin
            c.drawText(report.title, margin, y, headerPaint); y += 18f
            c.drawText("Davr: ${report.periodLabel}    Birlik: ${report.unit}", margin, y, metaPaint); y += 22f
            val headers = listOf("№", "Kod", "Prixod", "Rasxod", "Ostatka")
            headers.forEachIndexed { i, h -> c.drawText(h, colX[i] + 3f, y + 14f, boldPaint) }
            c.drawLine(margin, y + rowHeight, pageWidth - margin, y + rowHeight, linePaint)
            y += rowHeight
            while (rowIndex < report.rows.size && y + rowHeight < pageHeight - margin) {
                val row = report.rows[rowIndex]
                val values = listOf(row.index.toString(), row.code, formatTpNumber(row.incoming), formatTpNumber(row.outgoing), formatTpNumber(row.closing))
                values.forEachIndexed { i, value -> c.drawText(value.take(24), colX[i] + 3f, y + 14f, if (i == 4) boldPaint else cellPaint) }
                c.drawLine(margin, y + rowHeight, pageWidth - margin, y + rowHeight, linePaint)
                y += rowHeight
                rowIndex++
            }
            c.drawText("$pageNumber", pageWidth - margin - 12f, pageHeight - 18f, metaPaint)
            document.finishPage(page)
            pageNumber++
            if (report.rows.isEmpty()) break
        }
        document.writeTo(output)
        document.close()
    }
}
