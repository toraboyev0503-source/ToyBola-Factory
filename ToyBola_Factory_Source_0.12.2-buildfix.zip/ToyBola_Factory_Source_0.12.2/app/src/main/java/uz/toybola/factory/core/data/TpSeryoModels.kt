package uz.toybola.factory.core.data

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDateTime

/** Origin of an inventory movement. Kept explicit so every oldi-berdi can be audited later. */
enum class TpMaterialSourceKind {
    MANUAL,
    BREAKAGE_MACHINE,
    BREAKAGE_AREA,
    RETURNED_RECYCLED,
    JOB_DELIVERY,
    COMPENSATION_DELIVERY
}

/** One real physical batch carried from the preparation room to a machine. */
data class TpMaterialBatch(
    val id: String,
    /** RESIN or RECYCLED. COLOR is never a primary feedstock. */
    val feedstockType: TpMaterialType,
    val feedstockCode: String,
    val feedstockKg: Double,
    val colorCode: String = "",
    /** Krasitel is tracked separately and is not included in the requested feedstock kilograms. */
    val colorGrams: Double = 0.0,
    val createdAt: String = LocalDateTime.now().toString(),
    val createdBy: String = ""
)

/** Independent request created to replace rejected/brak material for one detail. */
data class TpSeryoCompensationOrder(
    val id: String,
    val machineId: String,
    val shopId: String,
    val sourceJobId: String? = null,
    val productId: String,
    val detailId: String,
    val articleSnapshot: String,
    val productNameSnapshot: String,
    val detailNameSnapshot: String,
    val colorCode: String,
    /** Feedstock kg only. Krasitel is accounted as a separate material. */
    val targetKg: Double,
    val defaultFeedstockType: TpMaterialType = TpMaterialType.RESIN,
    val defaultFeedstockCode: String,
    val batches: List<TpMaterialBatch> = emptyList(),
    val createdAt: String,
    val createdBy: String = "",
    val completedAt: String? = null
) {
    fun deliveredKg(): Double = normalizeFeedstockKg(batches.sumOf { it.feedstockKg })
    fun remainingKg(): Double = normalizeFeedstockKg((targetKg - deliveredKg()).coerceAtLeast(0.0))
    fun isComplete(): Boolean = remainingKg() <= 0.000_000_1
}

/** Resin/recycled stock uses 1 gram precision while UI and reports continue to display kilograms. */
fun normalizeFeedstockKg(value: Double): Double {
    require(value.isFinite() && value >= 0.0) { "Kilogrammni to‘g‘ri kiriting" }
    return BigDecimal.valueOf(value).setScale(3, RoundingMode.HALF_UP).toDouble()
}

fun feedstockKgFromGrams(grams: Long): Double {
    require(grams >= 0L) { "Gramm manfiy bo‘lmasin" }
    return BigDecimal.valueOf(grams).divide(BigDecimal.valueOf(1000L), 3, RoundingMode.UNNECESSARY).toDouble()
}

fun TpMaterialType.displayName(): String = when (this) {
    TpMaterialType.RESIN -> "Seryo"
    TpMaterialType.COLOR -> "Krasitel"
    TpMaterialType.RECYCLED -> "Ftarichka"
}

fun TpMaterialType.unitLabel(): String = if (this == TpMaterialType.COLOR) "g" else "kg"

/** Backward-compatible marker used by old Excel files where `Ftarichka` lived inside `Seryo turlari`. */
const val TP_ANY_RECYCLED_CODE: String = "__ANY_RECYCLED__"

fun TpDetail.recycledOptions(): List<String> = recycledCodes
    .map { it.trim().uppercase() }
    .filter { it.isNotBlank() }
    .distinct()

fun TpDetail.allowsAnyRecycled(): Boolean = TP_ANY_RECYCLED_CODE in recycledOptions()

fun TpDetail.explicitRecycledOptions(): List<String> = recycledOptions().filterNot { it == TP_ANY_RECYCLED_CODE }

fun TpDetail.acceptsRecycled(code: String): Boolean {
    val normalized = code.trim().uppercase()
    return allowsAnyRecycled() || normalized in explicitRecycledOptions()
}

fun TpPlanJob.deliveredFeedstockKg(): Double = normalizeFeedstockKg(materialBatches.sumOf { it.feedstockKg })
fun TpPlanJob.remainingFeedstockKg(): Double = normalizeFeedstockKg((totalResinKg - deliveredFeedstockKg()).coerceAtLeast(0.0))
