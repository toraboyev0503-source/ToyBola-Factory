package uz.toybola.factory.core.firebase

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.sync.withLock
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.core.notifications.NotificationScheduler
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.canReadAnyTp
import uz.toybola.factory.core.security.canReadAnyAssembly
import kotlinx.coroutines.CancellationException

class FirebaseSyncCoordinator(context: Context) {
    private val appContext = context.applicationContext
    private val repository = AssemblyDataRepository(appContext)
    private val outbox = AssemblySyncOutbox(appContext)
    private val policyCache = ServerPolicyCache(appContext)
    private val preferences = AppPreferences(appContext)
    private val auth = FirebaseAuth.getInstance()
    private val functions = FirebaseFunctions.getInstance("europe-west1")
    private val syncStatus = SyncStatusStore(appContext)

    suspend fun syncNow(): Result<Unit> = SyncSessionGate.mutex.withLock {
        syncStatus.markSyncing()
        val result = runCatching {
            val user = auth.currentUser ?: return@runCatching
            val setup = preferences.setup() ?: error("Qurilma sozlamasi topilmadi")
            val cachedBefore = policyCache.load(setup.userCode)
            // Never push with cached/revoked permissions when the server rejects refresh.
            val policy = ServerAuthRepository(appContext).refreshPolicy().getOrThrow()
            if (cachedBefore != null && policy != cachedBefore) ServerPolicyEvents.notifyChanged()
            require(policy.userCode.equals(setup.userCode, true)) { "Kirish sozlamasi yangilanmoqda. Qayta uriniladi." }
            require(policy.uid.isBlank() || policy.uid == user.uid) { "Server sessiyasi boshqa foydalanuvchiga tegishli" }

            // Pull before push. A server tombstone must be observed before an offline/stale
            // client is allowed to drain its outbox, otherwise an old phone can recreate a row
            // that another device deleted.
            val failures = mutableListOf<Throwable>()
            if (policy.canReadAnyAssembly()) {
                try {
                    reconcileFromServer(policy, ServerSnapshotRepository(appContext).download().getOrThrow())
                    if (!outbox.isEmpty()) {
                        flushOutbox(user.uid)
                        reconcileFromServer(policy, ServerSnapshotRepository(appContext).download().getOrThrow())
                    }
                    NotificationScheduler.scheduleUpcoming(appContext, repository)
                } catch (error: Exception) {
                    if (error is CancellationException) throw error
                    failures += error
                }
            }
            if (policy.canReadAnyTp()) {
                try {
                    TpSyncCoordinator(appContext).sync(policy, user.uid)
                } catch (error: Exception) {
                    if (error is CancellationException) throw error
                    failures += error
                }
            }
            if (failures.isNotEmpty()) throw failures.first()
            Unit
        }
        result.onSuccess { syncStatus.markSuccess() }
            .onFailure { error -> syncStatus.markFailure(error.message ?: error.javaClass.simpleName) }
        result
    }

    private fun reconcileFromServer(policy: UserAccessPolicy, snapshot: ServerSnapshotResult) = synchronized(uz.toybola.factory.core.data.RepositoryLock.monitor) {
        outbox.removeAll(staleOutboxKeysForTombstones(snapshot.tombstones))
        val dirty = outbox.pending()
        repository.replaceFromServer(
            mergeIntoLocal(repository.load(), snapshot.data, snapshot.hasSettings, policy, dirty, snapshot.tombstones)
        )
    }

    private suspend fun flushOutbox(uid: String) {
        val entries = outbox.snapshot()
        if (entries.isEmpty()) return
        entries.keys.sorted().chunked(180).forEach { chunk ->
            val payload = repository.encodeForSync(repository.load())
            val response = functions.getHttpsCallable("applyAssemblyWrites")
                .call(mapOf("keys" to chunk, "payload" to payload, "clientVersion" to "0.11.0"))
                .awaitResult()
            @Suppress("UNCHECKED_CAST")
            val body = response.data as? Map<String, Any?> ?: error("Server sync javobi noto‘g‘ri")
            @Suppress("UNCHECKED_CAST")
            val applied = (body["applied"] as? List<*>)?.mapNotNull { it?.toString() }.orEmpty()
            if (applied.isEmpty() && chunk.isNotEmpty()) error("Server sync hech bir yozuvni qabul qilmadi")
            applied.forEach { key -> entries[key]?.let { version -> outbox.acknowledge(key, version) } }
        }
    }

    private fun mergeIntoLocal(
        local: AssemblyData,
        remote: AssemblyData,
        hasSettings: Boolean,
        @Suppress("UNUSED_PARAMETER") policy: UserAccessPolicy,
        localDirtyKeys: Set<String>,
        serverTombstones: Set<String>
    ): AssemblyData {
        fun dirty(prefix: String) = outboxIds(localDirtyKeys, prefix)
        fun deleted(prefix: String) = outboxIds(localDirtyKeys, "${prefix}_DELETE")
        fun serverDeleted(prefix: String) = tombstoneIds(serverTombstones, prefix)
        return local.copy(
            brigades = authoritativeMergeById(local.brigades, remote.brigades, { it.id }, dirty("BRIGADE")),
            workers = authoritativeMergeById(local.workers, remote.workers, { it.id }, dirty("WORKER")),
            products = authoritativeMergeById(local.products, remote.products, { it.id }, dirty("PRODUCT")),
            brigadeFk = authoritativeMergeById(local.brigadeFk, remote.brigadeFk, { it.brigadeId }, dirty("BRIGADE_FK")),
            workHours = if ("SETTINGS:assembly" in localDirtyKeys || !hasSettings) local.workHours else remote.workHours,
            efficiencyNorm = if ("SETTINGS:assembly" in localDirtyKeys || !hasSettings) local.efficiencyNorm else remote.efficiencyNorm,
            roundTimes = if ("SETTINGS:assembly" in localDirtyKeys || !hasSettings) local.roundTimes else remote.roundTimes,
            monitoringWeights = if ("SETTINGS:assembly" in localDirtyKeys || !hasSettings) local.monitoringWeights else remote.monitoringWeights,
            preparedYears = if ("SETTINGS:assembly" in localDirtyKeys || !hasSettings) local.preparedYears else remote.preparedYears,
            workerDays = authoritativeMergeById(local.workerDays, remote.workerDays, { "${it.workerId}|${it.date}" }, dirty("WORKER_DAY")),
            brigadeDays = authoritativeMergeById(local.brigadeDays, remote.brigadeDays, { "${it.brigadeId}|${it.date}" }, dirty("BRIGADE_DAY")),
            qualityRounds = authoritativeMergeById(local.qualityRounds, remote.qualityRounds, { "${it.workerId}|${it.date}|${it.round}" }, dirty("QUALITY_ROUND")),
            dailyIssues = authoritativeMergeById(local.dailyIssues, remote.dailyIssues, { it.id }, dirty("DAILY_ISSUE"), deleted("DAILY_ISSUE"), serverDeleted("DAILY_ISSUE")),
            auditLog = authoritativeMergeById(local.auditLog, remote.auditLog, { it.id }, dirty("AUDIT")).takeLast(2000)
        )
    }


}
