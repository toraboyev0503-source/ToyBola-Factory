package uz.toybola.factory.core.firebase

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import uz.toybola.factory.core.data.AssemblyData
import uz.toybola.factory.core.data.TpData

data class SyncRuntimeState(
    val syncing: Boolean = false,
    val waitingForNetwork: Boolean = false,
    val lastSuccessAtMs: Long = 0L,
    val lastError: String = ""
)

object SyncStatusEvents {
    private val _state = MutableStateFlow(SyncRuntimeState())
    val state: StateFlow<SyncRuntimeState> = _state.asStateFlow()

    internal fun set(value: SyncRuntimeState) {
        _state.value = value
    }
}

class SyncStatusStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    init {
        val current = SyncStatusEvents.state.value
        if (current == SyncRuntimeState()) {
            SyncStatusEvents.set(
                SyncRuntimeState(
                    lastSuccessAtMs = prefs.getLong(KEY_LAST_SUCCESS, 0L),
                    lastError = prefs.getString(KEY_LAST_ERROR, "").orEmpty()
                )
            )
        }
    }

    fun markSyncing() {
        val old = SyncStatusEvents.state.value
        SyncStatusEvents.set(old.copy(syncing = true, waitingForNetwork = false, lastError = ""))
    }

    fun markWaitingForNetwork() {
        val old = SyncStatusEvents.state.value
        SyncStatusEvents.set(old.copy(syncing = false, waitingForNetwork = true, lastError = ""))
    }

    fun markSuccess() {
        val now = System.currentTimeMillis()
        prefs.edit().putLong(KEY_LAST_SUCCESS, now).remove(KEY_LAST_ERROR).apply()
        SyncStatusEvents.set(
            SyncRuntimeState(
                syncing = false,
                waitingForNetwork = false,
                lastSuccessAtMs = now,
                lastError = ""
            )
        )
    }

    fun markFailure(message: String?) {
        val clean = message.orEmpty().trim().take(300)
        prefs.edit().putString(KEY_LAST_ERROR, clean).apply()
        val old = SyncStatusEvents.state.value
        SyncStatusEvents.set(old.copy(syncing = false, waitingForNetwork = false, lastError = clean))
    }

    companion object {
        private const val PREFS = "toy_bola_sync_status"
        private const val KEY_LAST_SUCCESS = "last_success_ms"
        private const val KEY_LAST_ERROR = "last_error"
    }
}

/** Number of local records represented by the server sync layer. */
fun AssemblyData.syncableRecordCount(): Int =
    brigades.size + workers.size + products.size + brigadeFk.size + workerDays.size +
        brigadeDays.size + qualityRounds.size + dailyIssues.size + auditLog.size + 1 // settings/assembly


/** Number of TP/Seryo local records represented by the server sync layer. */
fun TpData.syncableRecordCount(): Int =
    shops.size + shifts.size + brigades.size + machines.size + workers.size + products.size +
        materials.size + orders.size + jobs.size + attendance.size + receipts.size +
        qualityRounds.size + dailyIssues.size + extraHourTypes.size + extraHours.size +
        machineDowntimes.size + seryoCompensations.size + auditLog.size + 1 // settings/tp
