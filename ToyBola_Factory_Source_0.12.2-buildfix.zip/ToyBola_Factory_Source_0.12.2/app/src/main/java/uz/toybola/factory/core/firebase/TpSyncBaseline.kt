package uz.toybola.factory.core.firebase

import android.content.Context
import org.json.JSONObject

/** Captures pre-edit values once, not the newer snapshot pulled before a push. */
class TpSyncBaseline(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("tp_sync_baseline", Context.MODE_PRIVATE)
    fun capture(keys: Set<String>, beforePayload: String) {
        if (keys.isEmpty()) return
        val root = JSONObject(beforePayload)
        val entries = read()
        keys.forEach { key ->
            val prefix = key.substringBefore(':').removeSuffix("_DELETE")
            val id = key.substringAfter(':')
            val rootKey = ROOT_KEYS[prefix]
            if (prefix == "TP_SETTINGS") entries.put(key, root.optJSONObject("settings") ?: JSONObject())
            else if (rootKey != null) {
                val rows = root.optJSONArray(rootKey)
                var found: JSONObject? = null
                if (rows != null) repeat(rows.length()) { index ->
                    val row = rows.optJSONObject(index)
                    if (row?.optString("id") == id) found = row
                }
                entries.put(key, found ?: JSONObject.NULL)
            }
        }
        check(prefs.edit().putString("entries", entries.toString()).commit()) { "O‘zgarish asosi saqlanmadi" }
    }
    fun payload(keys: Collection<String>): String {
        val source = read()
        return JSONObject().apply { keys.filter { source.has(it) }.forEach { put(it, source.get(it)) } }.toString()
    }
    fun remove(keys: Collection<String>) {
        val entries = read()
        keys.forEach(entries::remove)
        prefs.edit().putString("entries", entries.toString()).commit()
    }
    fun clear() { prefs.edit().clear().commit() }
    private fun read(): JSONObject = JSONObject(prefs.getString("entries", "{}") ?: "{}")
    companion object {
        val ROOT_KEYS = mapOf(
            "TP_SHOP" to "shops", "TP_SHIFT" to "shifts", "TP_BRIGADE" to "brigades",
            "TP_MACHINE" to "machines", "TP_WORKER" to "workers", "TP_PRODUCT" to "products",
            "TP_MATERIAL" to "materials", "TP_ORDER" to "orders", "TP_JOB" to "jobs",
            "TP_ATTENDANCE" to "attendance", "TP_RECEIPT" to "receipts", "TP_QUALITY" to "qualityRounds",
            "TP_ISSUE" to "dailyIssues", "TP_EXTRA_HOUR_TYPE" to "extraHourTypes", "TP_EXTRA_HOUR" to "extraHours",
            "TP_MACHINE_DOWNTIME" to "machineDowntimes", "TP_SERYO_COMP" to "seryoCompensations", "TP_AUDIT" to "auditLog"
        )
    }
}
