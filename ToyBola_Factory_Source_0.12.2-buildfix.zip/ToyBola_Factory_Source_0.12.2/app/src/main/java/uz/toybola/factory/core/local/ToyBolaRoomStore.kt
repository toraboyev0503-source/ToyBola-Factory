package uz.toybola.factory.core.local

import android.content.Context
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Transitional Room store for the two large legacy JSON snapshots.
 *
 * 0.12 keeps dual-write compatibility with SharedPreferences so an in-place update can migrate
 * existing users without losing rollback/recovery options. Later schema phases can normalize
 * individual entities into dedicated Room tables without changing the public repositories.
 */
@Entity(tableName = "app_snapshots")
data class AppSnapshotEntity(
    @PrimaryKey val snapshotKey: String,
    val payload: String,
    val updatedAtEpochMs: Long
)

@androidx.room.Dao
interface AppSnapshotDao {
    @Query("SELECT * FROM app_snapshots WHERE snapshotKey = :key LIMIT 1")
    fun get(key: String): AppSnapshotEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun put(row: AppSnapshotEntity)
}

@Database(entities = [AppSnapshotEntity::class], version = 1, exportSchema = false)
abstract class ToyBolaRoomDatabase : RoomDatabase() {
    abstract fun snapshots(): AppSnapshotDao
}

object ToyBolaRoomStore {
    const val ASSEMBLY_KEY = "assembly_v1"
    const val TP_KEY = "tp_v1"

    @Volatile private var database: ToyBolaRoomDatabase? = null

    fun dao(context: Context): AppSnapshotDao = (database ?: synchronized(this) {
        database ?: Room.databaseBuilder(
            context.applicationContext,
            ToyBolaRoomDatabase::class.java,
            "toybola-local.db"
        )
            // Existing repositories are synchronous. 0.12 keeps that contract while moving storage
            // under Room; a later coroutine repository refactor can remove main-thread DB access.
            .allowMainThreadQueries()
            .build()
            .also { database = it }
    }).snapshots()
}
