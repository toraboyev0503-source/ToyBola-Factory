package uz.toybola.factory.core.notifications

import android.app.NotificationManager
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import uz.toybola.factory.core.preferences.AppPreferences

data class InboxNotification(
    val key: String,
    val title: String,
    val body: String,
    val route: String,
    val createdAt: Long,
    val read: Boolean,
    val userCode: String,
    val important: Boolean = false,
    val type: String = ""
)

class NotificationInboxRepository(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    @Synchronized
    fun addOrUpdate(key: String, title: String, body: String, route: String, important: Boolean = false, type: String = "") {
        val currentUser = AppPreferences(appContext).setup()?.userCode.orEmpty()
        val items = readAll().toMutableList()
        val index = items.indexOfFirst { it.key == key && it.userCode == currentUser }
        val item = InboxNotification(
            key = key,
            title = title,
            body = body,
            route = route,
            createdAt = System.currentTimeMillis(),
            read = false,
            userCode = currentUser,
            important = important,
            type = type
        )
        if (index >= 0) items[index] = item else items.add(item)
        writeAll(items.sortedByDescending { it.createdAt }.take(MAX_ITEMS))
    }

    @Synchronized
    fun list(): List<InboxNotification> {
        val currentUser = AppPreferences(appContext).setup()?.userCode.orEmpty()
        return readAll()
            .filter { it.userCode == currentUser || (it.userCode.isBlank() && currentUser.isBlank()) }
            .sortedByDescending { it.createdAt }
    }

    fun unreadCount(): Int = list().count { !it.read }

    @Synchronized
    fun markRead(key: String) {
        val currentUser = AppPreferences(appContext).setup()?.userCode.orEmpty()
        val items = readAll().map {
            if (it.key == key && it.userCode == currentUser) it.copy(read = true) else it
        }
        writeAll(items)
        (appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(key.hashCode())
    }

    @Synchronized
    fun markAllRead() {
        val currentUser = AppPreferences(appContext).setup()?.userCode.orEmpty()
        val items = readAll().map {
            if (it.userCode == currentUser) it.copy(read = true) else it
        }
        writeAll(items)
        (appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancelAll()
    }

    private fun readAll(): List<InboxNotification> {
        val raw = prefs.getString(KEY_ITEMS, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    add(
                        InboxNotification(
                            key = obj.optString("key"),
                            title = obj.optString("title"),
                            body = obj.optString("body"),
                            route = obj.optString("route"),
                            createdAt = obj.optLong("createdAt"),
                            read = obj.optBoolean("read"),
                            userCode = obj.optString("userCode"),
                            important = obj.optBoolean("important"),
                            type = obj.optString("type")
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun writeAll(items: List<InboxNotification>) {
        val arr = JSONArray()
        items.forEach { item ->
            arr.put(
                JSONObject()
                    .put("key", item.key)
                    .put("title", item.title)
                    .put("body", item.body)
                    .put("route", item.route)
                    .put("createdAt", item.createdAt)
                    .put("read", item.read)
                    .put("userCode", item.userCode)
                    .put("important", item.important)
                    .put("type", item.type)
            )
        }
        prefs.edit().putString(KEY_ITEMS, arr.toString()).apply()
    }

    companion object {
        private const val PREFS_NAME = "toy_bola_notification_inbox"
        private const val KEY_ITEMS = "items"
        private const val MAX_ITEMS = 120
    }
}
