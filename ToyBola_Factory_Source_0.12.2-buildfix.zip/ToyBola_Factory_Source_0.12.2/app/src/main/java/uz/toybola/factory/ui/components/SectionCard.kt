package uz.toybola.factory.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Main dashboard/TP card.
 *
 * Keep the container fully opaque. Semi-transparent Surface colors + elevation caused
 * visible rectangular compositing layers on some Android 16 devices. The approved
 * design uses a single clean pastel card, so we pre-compose the pastel over white.
 */
@Composable
fun SectionCard(
    number: Int?,
    title: String,
    description: String,
    enabled: Boolean,
    badgeCount: Int = 0,
    modifier: Modifier = Modifier,
    accentColor: Color = Color(0xFF2D8FD0),
    icon: ImageVector? = null,
    visuallyActive: Boolean = enabled,
    onClick: () -> Unit
) {
    val activeBg = accentColor.copy(alpha = 0.10f).compositeOver(Color.White)
    val activeBorder = accentColor.copy(alpha = 0.16f).compositeOver(Color.White)
    val mutedBg = Color(0xFFF3F6F8)
    val mutedBorder = Color(0xFFE8EDF1)
    val titleColor = if (visuallyActive) Color(0xFF142B3C) else Color(0xFF8E9AA3)
    val secondaryColor = if (visuallyActive) Color(0xFF667783) else Color(0xFFA9B2B9)
    val numberColor = if (visuallyActive) accentColor else Color(0xFFAAB6BE)
    val iconColor = if (visuallyActive) accentColor else Color(0xFFB0BBC2)

    Surface(
        modifier = modifier
            .height(132.dp)
            .clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        color = if (visuallyActive) activeBg else mutedBg,
        border = BorderStroke(1.dp, if (visuallyActive) activeBorder else mutedBorder),
        tonalElevation = 0.dp,
        shadowElevation = if (visuallyActive) 2.dp else 1.dp
    ) {
        Box(Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(18.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    if (number != null) {
                        Text(
                            text = number.toString().padStart(2, '0'),
                            color = numberColor,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    if (icon != null) {
                        Icon(
                            icon,
                            contentDescription = null,
                            tint = iconColor,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
                Column {
                    Text(
                        title,
                        color = titleColor,
                        fontSize = 17.sp,
                        lineHeight = 21.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(5.dp))
                    Text(
                        description,
                        color = secondaryColor,
                        fontSize = 13.sp,
                        lineHeight = 17.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (badgeCount > 0 && enabled) {
                Surface(
                    modifier = Modifier.align(Alignment.TopEnd).padding(top = 8.dp, end = 8.dp),
                    shape = RoundedCornerShape(999.dp),
                    color = Color(0xFFFF4D43),
                    tonalElevation = 0.dp
                ) {
                    Text(
                        text = badgeCount.coerceAtMost(99).toString(),
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
