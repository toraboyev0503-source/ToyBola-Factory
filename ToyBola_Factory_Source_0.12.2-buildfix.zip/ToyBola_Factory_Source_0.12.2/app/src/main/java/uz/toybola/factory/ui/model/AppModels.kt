package uz.toybola.factory.ui.model

enum class AppLanguage { UZ, RU, EN }
enum class AppThemePreset { BRAND, CALM, NEUTRAL }

data class UserSetup(
    val deviceCode: String,
    val userCode: String
)

data class AppSettings(
    val language: AppLanguage = AppLanguage.UZ,
    val darkMode: Boolean = false,
    val themePreset: AppThemePreset = AppThemePreset.BRAND,
    val autoLockMinutes: Int = 5,
    // Whole-interface scale. Legacy drawerScalePercent is retained only for backward compatibility.
    val uiScalePercent: Int = 100,
    val drawerScalePercent: Int = 80
)

enum class AppScreen {
    SPLASH,
    SETUP,
    LOGIN,
    HOME,
    MANAGEMENT,
    NOTIFICATIONS,
    SETTINGS,
    SYNC_CENTER,
    TP_MAIN,
    TP_PLAN,
    TP_SHIFT,
    TP_SERYO,
    TP_RECEIVING,
    TP_QUALITY,
    TP_MONITORING,
    TP_MASTER_DATA,
    ASSEMBLY_ENTRY,
    ASSEMBLY,
    BRIGADIR,
    QUALITY,
    DAILY_ISSUE,
    MONITORING,
    MASTER_DATA,
    USER_ADMIN,
    BACKUP_RESTORE
}
