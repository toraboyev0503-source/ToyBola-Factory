package uz.toybola.factory.ui.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.canReadScreen

data class FactoryModuleSpec(
    val number: Int,
    val key: String,
    val launched: Boolean,
    val route: AppScreen?,
    val accent: Color,
    val icon: ImageVector
)

/** Single source of truth for Home module launch state, route and visual identity. */
object ModuleRegistry {
    val production = listOf(
        FactoryModuleSpec(1, "SERYO", true, AppScreen.TP_SERYO, Color(0xFF2F8FE5), Icons.Rounded.Factory),
        FactoryModuleSpec(2, "TP", true, AppScreen.TP_MAIN, Color(0xFF7657E8), Icons.Rounded.Assignment),
        FactoryModuleSpec(3, "YTM", false, null, Color(0xFFF2A43A), Icons.Rounded.Warehouse),
        FactoryModuleSpec(4, "SPARE", false, null, Color(0xFF13A88D), Icons.Rounded.SettingsSuggest),
        FactoryModuleSpec(5, "ASSEMBLY", true, AppScreen.ASSEMBLY_ENTRY, Color(0xFFE94A36), Icons.Rounded.Groups),
        FactoryModuleSpec(6, "TM_EXP", false, null, Color(0xFF459DE7), Icons.Rounded.LocalShipping)
    )
    val management = listOf(
        FactoryModuleSpec(7, "MANAGEMENT", true, AppScreen.MANAGEMENT, Color(0xFF8B5DE8), Icons.Rounded.BarChart),
        FactoryModuleSpec(8, "MASTER", true, AppScreen.MASTER_DATA, Color(0xFF718394), Icons.Rounded.Description)
    )
    val all = production + management

    fun visible(spec: FactoryModuleSpec, policy: UserAccessPolicy): Boolean {
        if (!spec.launched) return true
        if (policy.isAdmin()) return true
        val route = spec.route ?: return true
        return policy.canReadScreen(route)
    }

    fun canOpen(spec: FactoryModuleSpec, policy: UserAccessPolicy): Boolean =
        spec.launched && spec.route != null && (policy.isAdmin() || policy.canReadScreen(spec.route))
}
