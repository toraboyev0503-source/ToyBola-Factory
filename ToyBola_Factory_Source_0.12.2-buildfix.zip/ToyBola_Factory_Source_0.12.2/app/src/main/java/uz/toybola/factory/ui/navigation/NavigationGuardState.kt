package uz.toybola.factory.ui.navigation

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf

/**
 * Cross-screen guard for inline editors that can lose unsaved user input when switching root tabs.
 * Modal dialogs already intercept taps themselves; inline forms register a blocker here while dirty.
 */
object NavigationGuardState {
    private val _blockers = mutableStateOf<Set<String>>(emptySet())
    val blockers: State<Set<String>> get() = _blockers

    fun mark(key: String, dirty: Boolean) {
        _blockers.value = if (dirty) _blockers.value + key else _blockers.value - key
    }

    fun clear() {
        _blockers.value = emptySet()
    }
}
