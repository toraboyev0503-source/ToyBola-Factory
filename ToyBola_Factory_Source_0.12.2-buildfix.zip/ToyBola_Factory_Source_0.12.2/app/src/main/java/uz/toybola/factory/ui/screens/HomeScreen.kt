package uz.toybola.factory.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.toybola.factory.R
import uz.toybola.factory.core.data.AssemblyDataRepository
import uz.toybola.factory.core.data.TpDataRepository
import uz.toybola.factory.core.data.TpJobStatus
import uz.toybola.factory.core.data.TpMaterialStatus
import uz.toybola.factory.core.data.TpOrderStatus
import uz.toybola.factory.core.data.currentStock
import uz.toybola.factory.core.firebase.AssemblyDataEvents
import uz.toybola.factory.core.firebase.SyncStatusEvents
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppNavigationEvents
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.components.SectionCard
import uz.toybola.factory.ui.model.*
import java.time.LocalDate

private data class HomeCopy(val title: String, val description: String)
private data class HomeModuleStatus(val badge: Int = 0, val warning: String = "")

@Composable
fun HomeScreen(
    strings: AppStrings,
    accessPolicy: UserAccessPolicy,
    onOpen: (AppScreen) -> Unit
) {
    var disabledMessage by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val tpRevision by TpDataEvents.revision.collectAsState()
    val assemblyRevision by AssemblyDataEvents.revision.collectAsState()
    val tpData = remember(tpRevision, accessPolicy.revision) { TpDataRepository(context).load().scopedFor(accessPolicy) }
    val assemblyData = remember(assemblyRevision, accessPolicy.revision) { AssemblyDataRepository(context).load().scopedFor(accessPolicy) }
    val brigadeScopeLabel = remember(tpData, assemblyData, accessPolicy.allowedBrigadeIds) {
        val allowed = accessPolicy.allowedBrigadeIds
        when {
            allowed == null -> "Barcha brigadalar"
            allowed.isEmpty() -> ""
            allowed.size == 1 -> {
                val id = allowed.first()
                tpData.brigades.firstOrNull { it.id == id }?.name
                    ?: assemblyData.brigades.firstOrNull { it.id == id }?.name
                    ?: "1 ta brigada"
            }
            else -> "${allowed.size} ta brigada"
        }
    }
    val seryoActions = remember(tpData, accessPolicy.revision) {
        if (accessPolicy.isAdmin() || listOf(AssemblySection.TP_SERYO_APPROVAL, AssemblySection.TP_SERYO_DELIVERY).any(accessPolicy::canRead)) {
            tpData.jobs.count { job ->
                job.planConfirmedAt != null && job.status != TpJobStatus.COMPLETE &&
                    (job.resinConfirmedAt == null || job.materialStatus != TpMaterialStatus.DELIVERED)
            }
        } else 0
    }
    val negativeStock = remember(tpData) { tpData.materials.count { !it.archived && it.currentStock() < -0.0001 } }
    val tpActions = remember(tpData, accessPolicy.revision) {
        var count = 0
        if (accessPolicy.isAdmin() || accessPolicy.canRead(AssemblySection.TP_PLANNING)) {
            count += tpData.orders.count { order ->
                order.status !in setOf(TpOrderStatus.COMPLETE, TpOrderStatus.CANCELLED) &&
                    tpData.jobs.filter { it.orderId == order.id }.let { jobs -> jobs.isEmpty() || jobs.any { it.planConfirmedAt == null } }
            }
        }
        if (accessPolicy.isAdmin() || accessPolicy.canRead(AssemblySection.TP_MACHINE)) {
            count += tpData.jobs.count { it.planConfirmedAt != null && it.materialStatus == TpMaterialStatus.DELIVERED && it.status == TpJobStatus.QUEUED }
        }
        if (accessPolicy.isAdmin() || accessPolicy.canRead(AssemblySection.TP_DAILY_ISSUE)) {
            count += tpData.dailyIssues.count { it.status.name == "NEW" || it.status.name == "IN_PROGRESS" }
        }
        count
    }
    val statuses = mapOf(
        "SERYO" to HomeModuleStatus(seryoActions, if (negativeStock > 0) "⚠ $negativeStock ta manfiy ostatka" else ""),
        "TP" to HomeModuleStatus(tpActions)
    )
    val copies = mapOf(
        "SERYO" to HomeCopy(strings.molding, strings.moldingDesc),
        "TP" to HomeCopy(strings.tp, strings.tpDesc),
        "YTM" to HomeCopy(strings.ytmWarehouse, strings.ytmWarehouseDesc),
        "SPARE" to HomeCopy(strings.sparePartsWarehouse, strings.sparePartsWarehouseDesc),
        "ASSEMBLY" to HomeCopy(strings.assemblyAndHome, strings.assemblyAndHomeDesc),
        "TM_EXP" to HomeCopy(strings.finishedGoods, strings.finishedGoodsDesc),
        "MANAGEMENT" to HomeCopy(strings.managementControl, strings.managementControlDesc),
        "MASTER" to HomeCopy(strings.globalMasterData, strings.globalMasterDataDesc)
    )

    Column(Modifier.fillMaxSize()) {
        HomeBrandHeader(strings, accessPolicy, brigadeScopeLabel)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("HomeScreen-main"))
                .padding(horizontal = 16.dp, vertical = 4.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    strings.systemName,
                    fontSize = 19.sp,
                    lineHeight = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF142B3C),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(10.dp))
                Text(uzbekDate(LocalDate.now()), fontSize = 12.sp, color = Color(0xFF667783), maxLines = 1)
            }
            Spacer(Modifier.height(14.dp))
            ModuleGroup(ModuleRegistry.production, copies, statuses, accessPolicy, onOpen) { disabledMessage = true }
            Spacer(Modifier.height(8.dp))
            Text("Boshqaruv", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(10.dp))
            ModuleGroup(ModuleRegistry.management, copies, statuses, accessPolicy, onOpen) { disabledMessage = true }
            Spacer(Modifier.height(14.dp))
        }
    }

    if (disabledMessage) {
        AlertDialog(
            onDismissRequest = { disabledMessage = false },
            confirmButton = { TextButton(onClick = { disabledMessage = false }) { Text("OK") } },
            text = { Text(strings.notLaunched) }
        )
    }
}

@Composable
private fun ModuleGroup(
    specs: List<FactoryModuleSpec>,
    copies: Map<String, HomeCopy>,
    statuses: Map<String, HomeModuleStatus>,
    policy: UserAccessPolicy,
    onOpen: (AppScreen) -> Unit,
    onUnlaunched: () -> Unit
) {
    val visible = specs.filter { ModuleRegistry.visible(it, policy) }
    visible.chunked(2).forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            row.forEach { spec ->
                val copy = copies.getValue(spec.key)
                val status = statuses[spec.key] ?: HomeModuleStatus()
                val enabled = ModuleRegistry.canOpen(spec, policy)
                val baseDescription = if (!spec.launched) "${copy.description} • Tez orada" else copy.description
                val description = listOf(baseDescription, status.warning.takeIf { it.isNotBlank() }).filterNotNull().joinToString(" • ")
                SectionCard(
                    number = spec.number,
                    title = copy.title,
                    description = description,
                    enabled = enabled,
                    badgeCount = status.badge,
                    visuallyActive = enabled,
                    modifier = if (row.size == 1) Modifier.fillMaxWidth() else Modifier.weight(1f),
                    accentColor = spec.accent,
                    icon = spec.icon,
                    onClick = {
                        when {
                            enabled -> spec.route?.let(onOpen)
                            !spec.launched -> onUnlaunched()
                        }
                    }
                )
            }
            if (row.size == 1 && specs.size > 1) Spacer(Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun HomeBrandHeader(strings: AppStrings, policy: UserAccessPolicy, brigadeScopeLabel: String) {
    val runtime by SyncStatusEvents.state.collectAsState()
    val statusText = when {
        runtime.syncing -> strings.syncing
        runtime.waitingForNetwork -> strings.waitingNetwork
        runtime.lastError.isNotBlank() -> "E’tibor kerak"
        else -> "Sinxronlangan"
    }
    Column(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(R.drawable.toybola_brand_logo),
                contentDescription = strings.appName,
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(88.dp)
            )
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                val name = policy.displayName.ifBlank { policy.userCode }
                Text(name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF142B3C), maxLines = 1, overflow = TextOverflow.Ellipsis)
                val profileLine = listOf(policy.role.takeIf { it.isNotBlank() }, brigadeScopeLabel.takeIf { it.isNotBlank() })
                    .filterNotNull().joinToString(" • ")
                if (profileLine.isNotBlank()) Text(profileLine, fontSize = 11.sp, color = Color(0xFF667783), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Surface(
                modifier = Modifier.clickable(onClick = AppNavigationEvents::requestSyncCenter),
                shape = RoundedCornerShape(999.dp),
                color = if (runtime.lastError.isNotBlank()) MaterialTheme.colorScheme.errorContainer else Color(0xFFF0F7FC),
                tonalElevation = 0.dp
            ) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Sync, contentDescription = null, tint = if (runtime.lastError.isNotBlank()) MaterialTheme.colorScheme.error else Color(0xFF2E86C1), modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(statusText, fontSize = 11.sp, color = Color(0xFF435B69), maxLines = 1)
                }
            }
        }
    }
}

private fun uzbekDate(date: LocalDate): String {
    val months = listOf("yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr")
    return "${date.dayOfMonth}-${months[date.monthValue - 1]}, ${date.year}"
}

@Composable
fun ManagementMonitoringScreen(
    strings: AppStrings,
    onBack: () -> Unit,
    canOpen: (AppScreen) -> Boolean,
    onOpen: (AppScreen) -> Unit
) {
    val items = listOf(
        Triple("TP va Seryo", "Partiya, stanok, brigada, sifat va xomashyo", AppScreen.TP_MONITORING),
        Triple("Sborka", "Ishchi, brigada, sifat va foydalilik", AppScreen.MONITORING)
    )
    Column(Modifier.fillMaxSize()) {
        AppTopBar("Umumiy monitoring", canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items.forEachIndexed { index, item ->
                SectionCard(
                    number = index + 1,
                    title = item.first,
                    description = item.second,
                    enabled = canOpen(item.third),
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { if (canOpen(item.third)) onOpen(item.third) }
                )
            }
        }
    }
}
