package uz.toybola.factory.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.notifications.InboxNotification
import uz.toybola.factory.core.notifications.NotificationInboxRepository
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
fun NotificationsScreen(
    strings: AppStrings,
    repository: NotificationInboxRepository,
    onBack: () -> Unit,
    onOpenRoute: (String) -> Unit
) {
    var notifications by remember { mutableStateOf(repository.list()) }
    var filter by remember { mutableStateOf("NEW") }
    val visible = when (filter) {
        "NEW" -> notifications.filter { !it.read }
        "IMPORTANT" -> notifications.filter { it.important }
        else -> notifications
    }

    Column(modifier = Modifier.fillMaxSize()) {
        AppTopBar(
            title = strings.notifications,
            canGoBack = true,
            onMenu = {},
            onBack = onBack
        )

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(selected = filter == "NEW", onClick = { filter = "NEW" }, label = { Text("Yangi") }, modifier = Modifier.weight(1f))
            FilterChip(selected = filter == "IMPORTANT", onClick = { filter = "IMPORTANT" }, label = { Text("Muhim") }, modifier = Modifier.weight(1f))
            FilterChip(selected = filter == "ALL", onClick = { filter = "ALL" }, label = { Text("Barchasi") }, modifier = Modifier.weight(1f))
        }

        if (visible.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .navigationBarsPadding()
                    .padding(24.dp)
            ) {
                Text(if (notifications.isEmpty()) strings.noNotifications else "Bu filtrda xabar yo‘q.", style = MaterialTheme.typography.bodyLarge)
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(
                    onClick = {
                        repository.markAllRead()
                        notifications = repository.list()
                    }
                ) {
                    Text(strings.markAllRead)
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(visible, key = { it.key }) { item ->
                    NotificationCard(
                        item = item,
                        strings = strings,
                        onOpen = {
                            repository.markRead(item.key)
                            notifications = repository.list()
                            if (item.route.isNotBlank()) onOpenRoute(item.route)
                        }
                    )
                }
                item { Spacer(Modifier.height(12.dp)) }
            }
        }
    }
}

@Composable
private fun NotificationCard(
    item: InboxNotification,
    strings: AppStrings,
    onOpen: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
        shape = RoundedCornerShape(18.dp),
        tonalElevation = if (item.read) 1.dp else 4.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = item.title,
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = if (item.read) FontWeight.SemiBold else FontWeight.Bold
                )
                if (item.important) {
                    Text("Muhim", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.padding(horizontal = 3.dp))
                }
                if (!item.read) {
                    Text(
                        text = strings.newLabel,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(item.body, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                formatTime(item.createdAt),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun formatTime(epochMillis: Long): String {
    if (epochMillis <= 0L) return ""
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
    return Instant.ofEpochMilli(epochMillis)
        .atZone(ZoneId.systemDefault())
        .format(formatter)
}
