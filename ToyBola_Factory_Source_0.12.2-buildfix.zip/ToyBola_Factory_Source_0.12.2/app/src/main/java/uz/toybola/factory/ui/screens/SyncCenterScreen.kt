package uz.toybola.factory.ui.screens

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import uz.toybola.factory.core.data.AssemblyDataRepository
import uz.toybola.factory.core.data.TpDataRepository
import uz.toybola.factory.core.firebase.*
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
fun SyncCenterScreen(strings: AppStrings, onBack: () -> Unit) {
    val context = LocalContext.current
    val runtime by SyncStatusEvents.state.collectAsState()
    val outboxRevision by SyncOutboxEvents.revision.collectAsState()
    val assemblyRevision by AssemblyDataEvents.revision.collectAsState()
    val tpRevision by TpDataEvents.revision.collectAsState()
    val scope = rememberCoroutineScope()
    val assemblyOutbox = remember(context) { AssemblySyncOutbox(context) }
    val tpOutbox = remember(context) { TpSyncOutbox(context) }
    val assemblyRepo = remember(context) { AssemblyDataRepository(context) }
    val tpRepo = remember(context) { TpDataRepository(context) }
    val pending = remember(outboxRevision, assemblyRevision, tpRevision) {
        assemblyOutbox.pending().size + tpOutbox.pending().size
    }
    val localCount = remember(assemblyRevision, tpRevision) {
        assemblyRepo.load().syncableRecordCount() + tpRepo.load().syncableRecordCount()
    }
    val online = context.hasValidatedNetworkForSync()

    val statusTitle = when {
        runtime.syncing -> strings.syncing
        runtime.waitingForNetwork || !online -> strings.waitingNetwork
        runtime.lastError.isNotBlank() -> "E’tibor kerak"
        pending > 0 -> "Saqlangan — sync kutilmoqda"
        else -> "Sinxronlangan"
    }
    val statusColor = when {
        runtime.lastError.isNotBlank() -> MaterialTheme.colorScheme.error
        runtime.waitingForNetwork || !online -> Color(0xFFE58A18)
        runtime.syncing || pending > 0 -> Color(0xFF2E86C1)
        else -> Color(0xFF15936B)
    }
    val statusIcon = when {
        runtime.lastError.isNotBlank() -> Icons.Rounded.ErrorOutline
        runtime.waitingForNetwork || !online -> Icons.Rounded.CloudOff
        runtime.syncing -> Icons.Rounded.Sync
        pending > 0 -> Icons.Rounded.Schedule
        else -> Icons.Rounded.CheckCircle
    }

    Column(Modifier.fillMaxSize()) {
        AppTopBar("Sinxronlash", canGoBack = true, onMenu = {}, onBack = onBack, subtitle = "Server va lokal ma’lumot holati", showSync = false)
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), color = statusColor.copy(alpha = .10f), tonalElevation = 0.dp) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(statusIcon, contentDescription = null, tint = statusColor, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(statusTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = statusColor)
                        Text("Kutilayotgan yozuvlar: $pending", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            InfoRow("Lokal yozuvlar", localCount.toString())
            InfoRow("Oxirgi muvaffaqiyatli sync", formatSyncTime(runtime.lastSuccessAtMs))
            InfoRow("Internet", if (online) "Ulangan" else "Ulanmagan")
            if (runtime.lastError.isNotBlank()) {
                Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.errorContainer) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Sync xatosi", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                        Spacer(Modifier.height(4.dp))
                        Text(runtime.lastError, color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
            }
            Button(
                enabled = !runtime.syncing,
                onClick = {
                    if (!online) {
                        SyncStatusStore(context).markWaitingForNetwork()
                        FirebaseSyncScheduler.enqueue(context)
                    } else {
                        scope.launch(Dispatchers.IO) { FirebaseSyncCoordinator(context).syncNow() }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(Icons.Rounded.Sync, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (runtime.syncing) "Sinxronlanmoqda…" else "Qayta sinxronlash")
            }
            Text(
                "Offline kiritilgan ma’lumot telefonning navbatida saqlanadi. Internet qaytganda serverga yuboriladi; xato bo‘lsa shu ekranda ko‘rinadi.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), tonalElevation = 1.dp) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun formatSyncTime(epochMillis: Long): String {
    if (epochMillis <= 0L) return "Hali yo‘q"
    return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
        .withZone(ZoneId.systemDefault())
        .format(Instant.ofEpochMilli(epochMillis))
}

private fun Context.hasValidatedNetworkForSync(): Boolean {
    val manager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val network = manager.activeNetwork ?: return false
    val capabilities = manager.getNetworkCapabilities(network) ?: return false
    return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
}
