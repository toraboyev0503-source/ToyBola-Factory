package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.time.DayOfWeek
import java.time.LocalDate

private enum class TpMonitorPage { ROOT, WORKERS, WORKER, MACHINES, MACHINE, MATERIALS, MATERIAL }
private enum class TpPeriodPreset { TODAY, YESTERDAY, WEEK, MONTH, CUSTOM }
private data class TpMonitoringFilter(
    val shopId: String = "",
    val shiftId: String = "",
    val brigadeId: String = "",
    val machineId: String = "",
    val productId: String = ""
)
private data class MonitorOption(val id: String, val label: String)

@Composable
fun TpMonitoringScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val revision by TpDataEvents.revision.collectAsState()
    val policy = remember(revision) { AccessGuard(context).currentPolicy() }
    val original = remember(revision, policy.revision) { repository.load().scopedFor(policy) }
    val canExport = policy.isAdmin() || policy.canWrite(AssemblySection.TP_EXPORT)
    var page by remember { mutableStateOf(TpMonitorPage.ROOT) }
    var selectedWorkerId by remember { mutableStateOf<String?>(null) }
    var selectedMachineId by remember { mutableStateOf<String?>(null) }
    var selectedMaterialId by remember { mutableStateOf<String?>(null) }
    var preset by remember { mutableStateOf(TpPeriodPreset.TODAY) }
    var from by remember { mutableStateOf(LocalDate.now().toString()) }
    var to by remember { mutableStateOf(LocalDate.now().toString()) }
    var filter by remember { mutableStateOf(TpMonitoringFilter()) }
    val data = remember(original, filter) { original.monitoringScope(filter) }

    var exportPeriod by remember { mutableStateOf<Pair<String, String>?>(null) }
    var currentReport by remember { mutableStateOf<TpReportTable?>(null) }
    var exportMessage by remember { mutableStateOf<String?>(null) }
    var exporting by remember { mutableStateOf(false) }

    val currentExcelExporter = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri ->
        val report = currentReport
        if (uri != null && report != null) {
            exporting = true
            scope.launch {
                val result = withContext(Dispatchers.IO) { runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { TpXlsxExporter.write(it, report) }
                        ?: error("Excel faylini ochib bo‘lmadi")
                    "Filtrlangan Excel saqlandi"
                } }
                exportMessage = result.getOrElse { it.message ?: "Excel saqlanmadi" }
                exporting = false
                currentReport = null
            }
        } else currentReport = null
    }
    val currentWordExporter = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    ) { uri ->
        val report = currentReport
        if (uri != null && report != null) {
            exporting = true
            scope.launch {
                val result = withContext(Dispatchers.IO) { runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { TpDocxExporter.write(it, report) }
                        ?: error("Word faylini ochib bo‘lmadi")
                    "Filtrlangan Word saqlandi"
                } }
                exportMessage = result.getOrElse { it.message ?: "Word saqlanmadi" }
                exporting = false
                currentReport = null
            }
        } else currentReport = null
    }

    val payrollExporter = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri ->
        val period = exportPeriod
        if (uri != null && period != null) {
            exporting = true
            scope.launch {
                val result = withContext(Dispatchers.IO) { runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { output ->
                        TpPayrollXlsxExporter.write(context, output, data, period.first, period.second)
                    } ?: error("Excel faylini ochib bo‘lmadi")
                    "Oylik Excel saqlandi"
                } }
                exportMessage = result.getOrElse { it.message ?: "Excel saqlanmadi" }
                exporting = false
                exportPeriod = null
            }
        } else exportPeriod = null
    }

    fun filterSummary(): String = buildList {
        original.shops.firstOrNull { it.id == filter.shopId }?.let { add("Sex: ${it.name}") }
        original.shifts.firstOrNull { it.id == filter.shiftId }?.let { add("Smena: ${it.name}") }
        original.brigades.firstOrNull { it.id == filter.brigadeId }?.let { add("Brigada: ${it.name}") }
        original.machines.firstOrNull { it.id == filter.machineId }?.let { add("Stanok: ${it.number}") }
        original.products.firstOrNull { it.id == filter.productId }?.let { add("Mahsulot: ${it.article} ${it.name}") }
    }.joinToString(" • ").ifBlank { "Barcha" }

    fun reportForCurrentScope(): TpReportTable = buildTpReport(data, from, to, null).let { report ->
        report.copy(metadata = report.metadata + "Filter: ${filterSummary()}")
    }
    fun exportCurrentExcel() {
        currentReport = reportForCurrentScope()
        currentExcelExporter.launch("ToyBola_TP_${from}_${to}.xlsx")
    }
    fun exportCurrentWord() {
        currentReport = reportForCurrentScope()
        currentWordExporter.launch("ToyBola_TP_${from}_${to}.docx")
    }
    fun exportPayroll(firstHalf: Boolean) {
        val month = runCatching { LocalDate.parse(from) }.getOrDefault(LocalDate.now()).withDayOfMonth(1)
        val period = if (firstHalf) month.toString() to month.withDayOfMonth(minOf(15, month.lengthOfMonth())).toString()
        else month.withDayOfMonth(minOf(16, month.lengthOfMonth())).toString() to month.withDayOfMonth(month.lengthOfMonth()).toString()
        exportPeriod = period
        payrollExporter.launch("ToyBola_TP_Maosh_${period.first}_${period.second}.xlsx")
    }
    fun applyPreset(value: TpPeriodPreset) {
        preset = value
        val today = LocalDate.now()
        when (value) {
            TpPeriodPreset.TODAY -> { from = today.toString(); to = today.toString() }
            TpPeriodPreset.YESTERDAY -> { val day = today.minusDays(1); from = day.toString(); to = day.toString() }
            TpPeriodPreset.WEEK -> { val start = today.minusDays((today.dayOfWeek.value - DayOfWeek.MONDAY.value).toLong()); from = start.toString(); to = today.toString() }
            TpPeriodPreset.MONTH -> { from = today.withDayOfMonth(1).toString(); to = today.toString() }
            TpPeriodPreset.CUSTOM -> Unit
        }
    }

    fun back() {
        when (page) {
            TpMonitorPage.ROOT -> onBack()
            TpMonitorPage.WORKER -> page = TpMonitorPage.WORKERS
            TpMonitorPage.MACHINE -> page = TpMonitorPage.MACHINES
            TpMonitorPage.MATERIAL -> page = TpMonitorPage.MATERIALS
            else -> page = TpMonitorPage.ROOT
        }
    }
    BackHandler { back() }

    val title = when (page) {
        TpMonitorPage.ROOT -> "Monitoring"
        TpMonitorPage.WORKERS -> "Monitoring • Ishchilar"
        TpMonitorPage.WORKER -> "Ishchi tafsiloti"
        TpMonitorPage.MACHINES -> "Monitoring • Stanoklar"
        TpMonitorPage.MACHINE -> "Stanok tafsiloti"
        TpMonitorPage.MATERIALS -> "Monitoring • Seryo bo‘limi"
        TpMonitorPage.MATERIAL -> "Seryo tafsiloti"
    }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(title, canGoBack = true, onMenu = {}, onBack = ::back)
        if (exporting) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
            Text("Eksport tayyorlanmoqda…", Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        when (page) {
            TpMonitorPage.ROOT -> TpMonitoringRoot(
                original = original,
                data = data,
                from = from,
                to = to,
                preset = preset,
                filter = filter,
                onPreset = ::applyPreset,
                onFrom = { preset = TpPeriodPreset.CUSTOM; from = it },
                onTo = { preset = TpPeriodPreset.CUSTOM; to = it },
                onFilter = { filter = it },
                canExport = canExport && !exporting,
                onExportExcel = ::exportCurrentExcel,
                onExportWord = ::exportCurrentWord,
                onExportFirstHalf = { exportPayroll(true) },
                onExportSecondHalf = { exportPayroll(false) },
                exportMessage = exportMessage,
                onWorkers = { page = TpMonitorPage.WORKERS },
                onMachines = { page = TpMonitorPage.MACHINES },
                onMaterials = { page = TpMonitorPage.MATERIALS }
            )
            TpMonitorPage.WORKERS -> TpWorkerMonitoring(data, from, to) { selectedWorkerId = it; page = TpMonitorPage.WORKER }
            TpMonitorPage.WORKER -> selectedWorkerId?.let { TpWorkerMonitoringDetail(data, it, from, to) }
            TpMonitorPage.MACHINES -> TpMachineMonitoring(data, from, to) { selectedMachineId = it; page = TpMonitorPage.MACHINE }
            TpMonitorPage.MACHINE -> selectedMachineId?.let { TpMachineMonitoringDetail(data, it, from, to) }
            TpMonitorPage.MATERIALS -> TpMaterialMonitoring(data, from, to) { selectedMaterialId = it; page = TpMonitorPage.MATERIAL }
            TpMonitorPage.MATERIAL -> selectedMaterialId?.let { TpMaterialMonitoringDetail(data, it, from, to) }
        }
    }
}

@Composable
private fun TpMonitoringRoot(
    original: TpData,
    data: TpData,
    from: String,
    to: String,
    preset: TpPeriodPreset,
    filter: TpMonitoringFilter,
    onPreset: (TpPeriodPreset) -> Unit,
    onFrom: (String) -> Unit,
    onTo: (String) -> Unit,
    onFilter: (TpMonitoringFilter) -> Unit,
    canExport: Boolean,
    onExportExcel: () -> Unit,
    onExportWord: () -> Unit,
    onExportFirstHalf: () -> Unit,
    onExportSecondHalf: () -> Unit,
    exportMessage: String?,
    onWorkers: () -> Unit,
    onMachines: () -> Unit,
    onMaterials: () -> Unit
) {
    val receipts = data.receipts.filter { !it.isCancelled && it.date in from..to }
    val periodQuality = data.qualityRounds.filter { it.date in from..to && !it.excludedFromAverage }
    val orders = data.orders.filter { it.status != TpOrderStatus.CANCELLED && it.requestedDate in from..to }
    val produced = receipts.sumOf { it.creditedPieces }
    val planPercent = orders.map { data.orderProgress(it.id) }.takeIf { it.isNotEmpty() }?.average()
    val qualityAverage = periodQuality.map { it.score }.takeIf { it.isNotEmpty() }?.average()
    val activeMachineIds = data.jobs.filter { it.status == TpJobStatus.IN_PROGRESS }.mapNotNull { it.machineId }.toSet()
    val stoppedMachineIds = data.machineDowntimes.filter { it.date in from..to }.map { it.machineId }.toSet()
    val resinOutKg = data.materials.filter { it.type != TpMaterialType.COLOR }.sumOf { material ->
        material.movements.filter { it.kind == TpMaterialMovementKind.OUT && it.createdAt.take(10) in from..to }.sumOf { it.amount }
    }
    val brakKg = data.materials.filter { it.type == TpMaterialType.RECYCLED }.sumOf { material ->
        material.movements.filter {
            it.kind == TpMaterialMovementKind.IN && it.createdAt.take(10) in from..to &&
                it.sourceKind in setOf(TpMaterialSourceKind.BREAKAGE_MACHINE, TpMaterialSourceKind.BREAKAGE_AREA)
        }.sumOf { it.amount }
    }
    val periodAttendance = data.attendance.filter { it.date in from..to }
    val absent = periodAttendance.count { !it.present }
    val shortMaterials = activeMaterialShortages(data)
    val prepWaiting = data.jobs.count { it.resinConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED && it.status != TpJobStatus.COMPLETE }

    val shopOptions = listOf(MonitorOption("", "Barcha")) + original.shops.filterNot { it.archived }.sortedBy { it.name }.map { MonitorOption(it.id, it.name) }
    val shiftOptions = listOf(MonitorOption("", "Barchasi")) + original.shifts.filterNot { it.archived }.sortedBy { it.name }.map { MonitorOption(it.id, it.name) }
    val brigadeOptions = listOf(MonitorOption("", "Barchasi")) + original.brigades.filter { !it.archived && (filter.shopId.isBlank() || it.shopId == filter.shopId) && (filter.shiftId.isBlank() || it.shiftId == filter.shiftId) }.sortedBy { it.name }.map { MonitorOption(it.id, it.name) }
    val machineOptions = listOf(MonitorOption("", "Barchasi")) + original.machines.filter { !it.archived && (filter.shopId.isBlank() || it.shopId == filter.shopId) }.sortedBy { it.number }.map { MonitorOption(it.id, "${it.number}-stanok") }
    val productOptions = listOf(MonitorOption("", "Barchasi")) + original.products.filterNot { it.archived }.sortedBy { it.article }.map { MonitorOption(it.id, "${it.article} • ${it.name}") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Davr", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(
                TpPeriodPreset.TODAY to "Bugun", TpPeriodPreset.YESTERDAY to "Kecha",
                TpPeriodPreset.WEEK to "Hafta", TpPeriodPreset.MONTH to "Oy", TpPeriodPreset.CUSTOM to "Oraliq"
            ).forEach { (value, label) ->
                FilterChip(selected = preset == value, onClick = { onPreset(value) }, label = { Text(label) }, modifier = Modifier.weight(1f))
            }
        }
        if (preset == TpPeriodPreset.CUSTOM) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) { TpDatePickerButton("Dan", from, onFrom) }
                Box(Modifier.weight(1f)) { TpDatePickerButton("Gacha", to, onTo) }
            }
        } else Text("$from — $to", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Text("Filter", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        TpChoice("Sex", filter.shopId, shopOptions, { it.id }, { it.label }) { id ->
            onFilter(filter.copy(shopId = id, brigadeId = "", machineId = ""))
        }
        TpChoice("Smena", filter.shiftId, shiftOptions, { it.id }, { it.label }) { id ->
            onFilter(filter.copy(shiftId = id, brigadeId = ""))
        }
        TpChoice("Brigada", filter.brigadeId, brigadeOptions, { it.id }, { it.label }) { id -> onFilter(filter.copy(brigadeId = id)) }
        TpChoice("Stanok", filter.machineId, machineOptions, { it.id }, { it.label }) { id -> onFilter(filter.copy(machineId = id)) }
        TpChoice("Mahsulot", filter.productId, productOptions, { it.id }, { it.label }) { id -> onFilter(filter.copy(productId = id)) }

        Text("Asosiy KPI", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        TpCard {
            Text("Ishlab chiqarilgan: $produced dona", fontWeight = FontWeight.Bold)
            Text("Reja bajarilishi: ${planPercent?.toInt()?.let { "$it%" } ?: "—"}")
            Text("Brak qabul: ${formatTpNumber(brakKg)} kg")
            Text("Sifat: ${qualityAverage?.toInt()?.let { "$it%" } ?: "—"}")
            Text("Stanoklar: ${activeMachineIds.size} ishda • ${stoppedMachineIds.size} to‘xtash qayd etilgan")
            Text("Seryo/Ftarichka rasxod: ${formatTpNumber(resinOutKg)} kg")
        }

        Text("E’tibor talab qiladi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        TpCard {
            if (absent == 0 && stoppedMachineIds.isEmpty() && shortMaterials.isEmpty() && prepWaiting == 0) {
                Text("Tanlangan scope’da keskin ogohlantirish yo‘q.", color = MaterialTheme.colorScheme.primary)
            } else {
                if (absent > 0) Text("• $absent ishlamagan davomat yozuvi", color = MaterialTheme.colorScheme.error)
                if (stoppedMachineIds.isNotEmpty()) Text("• ${stoppedMachineIds.size} stanokda to‘xtash qaydi", color = MaterialTheme.colorScheme.error)
                if (shortMaterials.isNotEmpty()) Text("• ${shortMaterials.size} material faol reja uchun yetishmaydi", color = MaterialTheme.colorScheme.error)
                if (prepWaiting > 0) Text("• $prepWaiting qorishma tayyorlash/yetkazishni kutmoqda")
            }
        }

        if (canExport) {
            Text("Joriy filtrni eksport", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onExportExcel, modifier = Modifier.weight(1f)) { Text("Excel") }
                OutlinedButton(onClick = onExportWord, modifier = Modifier.weight(1f)) { Text("Word") }
            }
            Text("Ekrandagi davr va barcha aktiv filterlar eksportga ham qo‘llanadi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("TP oylik maosh Excel", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onExportFirstHalf, modifier = Modifier.weight(1f)) { Text("1–15") }
                OutlinedButton(onClick = onExportSecondHalf, modifier = Modifier.weight(1f)) { Text("16–oy oxiri") }
            }
        }
        if (!exportMessage.isNullOrBlank()) Text(exportMessage, color = MaterialTheme.colorScheme.primary)

        MonitoringDirectionCard(
            title = "1. Ishchilar",
            summary = "${data.workers.count { !it.archived }} ishchi • $absent ishlamagan yozuv",
            detail = "Davomat → brigada → ishchi → ishlab chiqarish, qo‘shimcha soat va sifat",
            onClick = onWorkers
        )
        MonitoringDirectionCard(
            title = "2. Stanoklar",
            summary = "${data.machines.count { !it.archived }} stanok • ${activeMachineIds.size} ishda • ${stoppedMachineIds.size} to‘xtash qaydi",
            detail = "Sex → stanok → joriy reja, navbat, qabul va o‘chishlar",
            onClick = onMachines
        )
        MonitoringDirectionCard(
            title = "3. Seryo bo‘limi",
            summary = "${data.materials.count { !it.archived }} material • $prepWaiting tayyorlashda • ${shortMaterials.size} yetishmovchilik",
            detail = "Seryo/krasitel → qoldiq → kirim/chiqim → zakaz va stanoklar",
            onClick = onMaterials
        )
    }
}

private fun TpData.monitoringScope(filter: TpMonitoringFilter): TpData {
    val relevantBrigades = brigades.filter { brigade ->
        (filter.shopId.isBlank() || brigade.shopId == filter.shopId) &&
            (filter.shiftId.isBlank() || brigade.shiftId == filter.shiftId) &&
            (filter.brigadeId.isBlank() || brigade.id == filter.brigadeId)
    }
    val brigadeConstraint = filter.shopId.isNotBlank() || filter.shiftId.isNotBlank() || filter.brigadeId.isNotBlank()
    val brigadeIds = relevantBrigades.map { it.id }.toSet()
    val machineIds = machines.filter { machine ->
        (filter.shopId.isBlank() || machine.shopId == filter.shopId) &&
            (filter.machineId.isBlank() || machine.id == filter.machineId)
    }.map { it.id }.toSet()
    val machineConstraint = filter.shopId.isNotBlank() || filter.machineId.isNotBlank()
    val productOrderIds = orders.filter { filter.productId.isBlank() || it.productId == filter.productId }.map { it.id }.toSet()
    val jobRows = jobs.filter { job ->
        (!brigadeConstraint || (job.brigadeId != null && job.brigadeId in brigadeIds)) &&
            (!machineConstraint || (job.machineId != null && job.machineId in machineIds)) &&
            (filter.productId.isBlank() || job.orderId in productOrderIds)
    }
    val jobIds = jobRows.map { it.id }.toSet()
    val orderIds = jobRows.map { it.orderId }.toSet() + if (filter.productId.isNotBlank()) productOrderIds else emptySet()
    val visibleWorkerIds = if (brigadeConstraint) workers.filter { it.brigadeId in brigadeIds }.map { it.id }.toSet() else workers.map { it.id }.toSet()
    return copy(
        brigades = if (brigadeConstraint) relevantBrigades else brigades,
        machines = if (machineConstraint) machines.filter { it.id in machineIds } else machines,
        workers = workers.filter { it.id in visibleWorkerIds },
        products = if (filter.productId.isBlank()) products else products.filter { it.id == filter.productId },
        orders = if (filter.productId.isBlank() && !brigadeConstraint && !machineConstraint) orders else orders.filter { it.id in orderIds },
        jobs = jobRows,
        attendance = attendance.filter { !brigadeConstraint || it.brigadeId in brigadeIds },
        receipts = receipts.filter { receipt ->
            (!brigadeConstraint || receipt.brigadeId in brigadeIds) &&
                (!machineConstraint || receipt.machineId in machineIds) &&
                (jobIds.isEmpty() && filter.productId.isBlank() || receipt.jobId in jobIds)
        },
        qualityRounds = qualityRounds.filter { row ->
            (!brigadeConstraint || row.brigadeId in brigadeIds) && (!machineConstraint || row.machineId in machineIds) &&
                (jobIds.isEmpty() && filter.productId.isBlank() || row.jobId in jobIds)
        },
        dailyIssues = dailyIssues.filter { issue ->
            (!brigadeConstraint || issue.brigadeId in brigadeIds) &&
                (!machineConstraint || issue.machineId == null || issue.machineId in machineIds) &&
                (filter.productId.isBlank() || issue.orderId in productOrderIds)
        },
        extraHours = extraHours.filter { !brigadeConstraint || it.brigadeId in brigadeIds },
        machineDowntimes = machineDowntimes.filter { row ->
            (!brigadeConstraint || row.brigadeId in brigadeIds) && (!machineConstraint || row.machineId in machineIds)
        },
        seryoCompensations = seryoCompensations.filter { row ->
            (!machineConstraint || row.machineId in machineIds) && (filter.productId.isBlank() || row.productId == filter.productId)
        }
    )
}

@Composable
private fun MonitoringDirectionCard(title: String, summary: String, detail: String, onClick: () -> Unit) {
    TpCard(Modifier.clickable(onClick = onClick)) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(summary, fontWeight = FontWeight.SemiBold)
        Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun TpWorkerMonitoring(data: TpData, from: String, to: String, onWorker: (String) -> Unit) {
    val workers = data.workers.filterNot { it.archived }
    val periodAttendance = data.attendance.filter { it.date in from..to }
    val absent = periodAttendance.count { !it.present }
    val minus = periodAttendance.count { it.present && it.minusHours > 0.0 }
    val totalPiece = data.receipts.filter { !it.isCancelled && it.date in from..to }.sumOf { it.earnedAmount }
    val totalExtra = data.extraHours.filter { it.date in from..to }.sumOf { it.amount }

    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-workers")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Umumiy xulosa", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        TpCard {
            Text("${workers.size} faol ishchi • $absent ishlamagan kun • $minus minus-soatli kun")
            Text("Ishlab chiqarish: $totalPiece so‘m • Qo‘shimcha soat: $totalExtra so‘m")
        }
        data.brigades.filterNot { it.archived }.sortedBy { it.name }.forEach { brigade ->
            val brigadeWorkers = workers.filter { it.brigadeId == brigade.id }
            if (brigadeWorkers.isNotEmpty()) {
                Text(brigade.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                brigadeWorkers.forEach { worker ->
                    val receipts = data.receipts.filter { !it.isCancelled && it.workerId == worker.id && it.date in from..to }
                    val extra = data.extraHours.filter { it.workerId == worker.id && it.date in from..to }.sumOf { it.amount }
                    val earned = receipts.sumOf { it.earnedAmount } + extra
                    val quality = data.qualityRounds.filter { it.workerId == worker.id && it.date in from..to && !it.excludedFromAverage }.map { it.score }.takeIf { it.isNotEmpty() }?.average()
                    TpCard(Modifier.clickable { onWorker(worker.id) }) {
                        Text(worker.name, fontWeight = FontWeight.Bold)
                        Text("Topgan: $earned so‘m${if (extra > 0) " • qo‘shimcha $extra so‘m" else ""}")
                        Text("Qabul: ${receipts.sumOf { it.creditedPieces }} dona • Sifat: ${quality?.toInt()?.let { "$it%" } ?: "—"}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun TpWorkerMonitoringDetail(data: TpData, workerId: String, from: String, to: String) {
    val worker = data.workers.firstOrNull { it.id == workerId } ?: return
    val brigade = data.brigades.firstOrNull { it.id == worker.brigadeId }
    val dates = periodDates(from, to)
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-worker-$workerId")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(worker.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(brigade?.name.orEmpty(), color = MaterialTheme.colorScheme.onSurfaceVariant)
        dates.forEach { date ->
            val attendance = data.attendance.firstOrNull { it.workerId == workerId && it.date == date }
            val piece = data.workerPieceEarned(workerId, date)
            val extra = data.workerExtraEarned(workerId, date)
            val quality = data.workerQuality(workerId, date)
            val efficiency = data.workerEfficiency(workerId, date)
            if (attendance != null || piece > 0 || extra > 0 || quality != null) {
                TpCard {
                    Text(date, fontWeight = FontWeight.Bold)
                    Text(when {
                        attendance == null -> "Davomat yozuvi yo‘q"
                        !attendance.present -> "Ishlamadi"
                        attendance.minusHours > 0 -> "Minus ${formatTpNumber(attendance.minusHours)} soat • ${data.attendanceWorkMinutes(workerId, date)} daqiqa"
                        else -> "To‘liq ishlagan • ${data.attendanceWorkMinutes(workerId, date)} daqiqa"
                    })
                    Text("Ishlab chiqarish: $piece so‘m${if (extra > 0) " • Qo‘shimcha: $extra so‘m" else ""}")
                    Text("Jami: ${piece + extra} so‘m • Samaradorlik: ${efficiency?.toInt()?.let { "$it%" } ?: "—"} • Sifat: ${quality?.toInt()?.let { "$it%" } ?: "—"}")
                }
            }
        }
    }
}

@Composable
private fun TpMachineMonitoring(data: TpData, from: String, to: String, onMachine: (String) -> Unit) {
    val machines = data.machines.filterNot { it.archived }
    val jobs = data.jobs.filter { it.machineId != null && it.status != TpJobStatus.COMPLETE }
    val busyIds = jobs.mapNotNull { it.machineId }.toSet()
    val stops = data.machineDowntimes.filter { it.date in from..to }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-machines")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TpCard {
            Text("${machines.size} stanok • ${busyIds.size} ish/navbat • ${machines.size - busyIds.size} bo‘sh")
            Text("O‘chish: ${stops.size} marta • ${stops.sumOf { it.durationMinutes() }} daqiqa")
        }
        data.shops.filterNot { it.archived }.sortedBy { it.name }.forEach { shop ->
            val shopMachines = machines.filter { it.shopId == shop.id }
            if (shopMachines.isNotEmpty()) {
                Text(shop.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                shopMachines.forEach { machine ->
                    val machineJobs = jobs.filter { it.machineId == machine.id }
                    val receipts = data.receipts.filter { !it.isCancelled && it.machineId == machine.id && it.date in from..to }
                    val downtime = stops.filter { it.machineId == machine.id }
                    TpCard(Modifier.clickable { onMachine(machine.id) }) {
                        Text("${machine.number}-stanok${machine.name.takeIf { it.isNotBlank() }?.let { " • $it" }.orEmpty()}", fontWeight = FontWeight.Bold)
                        if (machineJobs.isEmpty()) Text("Zakaz yo‘q", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        else Text("${machineJobs.count { it.status == TpJobStatus.IN_PROGRESS }} ishda • ${machineJobs.count { it.status != TpJobStatus.IN_PROGRESS }} navbatda • ${minutesLabel(machineJobs.sumOf { it.estimatedMinutes.coerceAtLeast(0) })} ish")
                        Text("Qabul: ${receipts.sumOf { it.creditedPieces }} dona • O‘chish: ${downtime.size} / ${downtime.sumOf { it.durationMinutes() }} daq", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun TpMachineMonitoringDetail(data: TpData, machineId: String, from: String, to: String) {
    val machine = data.machines.firstOrNull { it.id == machineId } ?: return
    val shop = data.shops.firstOrNull { it.id == machine.shopId }
    val jobs = data.jobs.filter { it.machineId == machineId && it.status != TpJobStatus.COMPLETE }.sortedBy { it.priority }
    val stops = data.machineDowntimes.filter { it.machineId == machineId && it.date in from..to }.sortedWith(compareByDescending<TpMachineDowntime> { it.date }.thenByDescending { it.stoppedAt })
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-machine-$machineId")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("${machine.number}-stanok • ${shop?.name.orEmpty()}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Joriy va navbatdagi ishlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (jobs.isEmpty()) Text("Zakaz yo‘q.")
        jobs.forEach { job ->
            val order = data.orders.firstOrNull { it.id == job.orderId }
            TpCard {
                Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.Bold)
                Text(job.outputs.map { it.detailName }.distinct().joinToString())
                Text("Rang ${job.colorCode} • ${minutesLabel(job.estimatedMinutes)} • ${job.status.name}")
                Text(if (job.materialStatus == TpMaterialStatus.DELIVERED) "✓ Seryo yetkazilgan" else "Seryo kutilmoqda", color = if (job.materialStatus == TpMaterialStatus.DELIVERED) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            }
        }
        Text("O‘chishlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (stops.isEmpty()) Text("Tanlangan davrda o‘chish yozuvi yo‘q.")
        stops.forEach { stop -> TpCard {
            Text("${stop.date} • ${stop.stoppedAt}–${stop.startedAt} • ${stop.durationMinutes()} daqiqa", fontWeight = FontWeight.Bold)
            Text(stop.reason)
        } }
    }
}

@Composable
private fun TpMaterialMonitoring(data: TpData, from: String, to: String, onMaterial: (String) -> Unit) {
    val materials = data.materials.filterNot { it.archived }.sortedWith(compareBy<TpMaterial> { it.type }.thenBy { it.code })
    val shortages = activeMaterialShortages(data).toSet()
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-materials")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        val waiting = data.jobs.count { it.resinConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED && it.status != TpJobStatus.COMPLETE }
        TpCard {
            Text("${materials.size} material • $waiting tayyorlash/yetkazishda • ${shortages.size} yetishmovchilik")
        }
        ResinExtraMonitoring(data, from, to)
        materials.forEach { material ->
            val incoming = material.movements.filter { it.kind == TpMaterialMovementKind.IN && it.createdAt.take(10) in from..to }.sumOf { it.amount }
            val outgoing = material.movements.filter { it.kind == TpMaterialMovementKind.OUT && it.createdAt.take(10) in from..to }.sumOf { it.amount }
            val short = shortages.any { it.startsWith(material.code + " ") }
            TpCard(Modifier.clickable { onMaterial(material.id) }) {
                Text("${material.code} • ${material.type.displayName()}", fontWeight = FontWeight.Bold)
                Text("Ostatka: ${formatTpNumber(material.currentStock())} ${material.type.unitLabel()}")
                Text("Prixod: ${formatTpNumber(incoming)} • Rasxod: ${formatTpNumber(outgoing)}", style = MaterialTheme.typography.bodySmall)
                if (short) Text("⚠ Faol reja uchun yetmaydi", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun TpMaterialMonitoringDetail(data: TpData, materialId: String, from: String, to: String) {
    val material = data.materials.firstOrNull { it.id == materialId } ?: return
    val movements = material.movements.filter { it.createdAt.take(10) in from..to }.sortedByDescending { it.createdAt }
    val relatedJobs = data.jobs.filter { job ->
        job.status != TpJobStatus.COMPLETE && when (material.type) {
            TpMaterialType.RESIN, TpMaterialType.RECYCLED -> job.feedstockType == material.type && job.resinCode.equals(material.code, true)
            TpMaterialType.COLOR -> job.colorCode.equals(material.code, true)
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpMonitoring-material-$materialId")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("${material.code} • ${material.type.displayName()}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        TpCard {
            Text("Hozirgi ostatka: ${formatTpNumber(material.currentStock())} ${material.type.unitLabel()}")
            val reserved = relatedJobs.sumOf { if (material.type == TpMaterialType.COLOR) it.totalColorGrams else it.totalResinKg }
            Text("Faol rejalarga kerak: ${formatTpNumber(reserved)}")
            Text("Erkin hisobiy qoldiq: ${formatTpNumber(material.currentStock() - reserved)}")
        }
        Text("Qayerga kerak", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        relatedJobs.forEach { job ->
            val order = data.orders.firstOrNull { it.id == job.orderId }
            val machine = data.machines.firstOrNull { it.id == job.machineId }
            TpCard {
                Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.Bold)
                Text("${machine?.number?.let { "$it-stanok" } ?: "Stanok belgilanmagan"} • ${job.outputs.map { it.detailName }.distinct().joinToString()} • rang ${job.colorCode}")
                Text("Kerak: ${formatTpNumber(if (material.type == TpMaterialType.COLOR) job.totalColorGrams else job.totalResinKg)} ${material.type.unitLabel()}")
            }
        }
        ResinExtraMonitoring(data, from, to, if (material.type == TpMaterialType.RESIN) material.code else null)
        Text("Harakatlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (movements.isEmpty()) Text("Tanlangan davrda harakat yo‘q.")
        movements.forEach { move -> TpCard {
            Text("${if (move.kind == TpMaterialMovementKind.IN) "Prixod" else "Rasxod"}: ${formatTpNumber(move.amount)}", fontWeight = FontWeight.Bold)
            Text(move.createdAt.take(16).replace('T', ' '))
            if (move.note.isNotBlank()) Text(move.note, style = MaterialTheme.typography.bodySmall)
        } }
    }
}

private fun activeMaterialShortages(data: TpData): List<String> {
    val jobs = data.jobs.filter { it.status != TpJobStatus.COMPLETE && it.planConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED }
    val feedstockNeed = jobs.groupBy { it.feedstockType to it.resinCode }.mapValues { (_, rows) -> rows.sumOf { it.totalResinKg } }
    val colorNeed = jobs.filter { it.feedstockType == TpMaterialType.RESIN }.groupBy { it.colorCode }.mapValues { (_, rows) -> rows.sumOf { it.totalColorGrams } }
    return buildList {
        feedstockNeed.forEach { (key, need) ->
            val (type, code) = key
            if (data.materialStock(type, code) + 1e-9 < need) add("$code ${type.displayName().lowercase()}")
        }
        colorNeed.forEach { (code, need) -> if (data.materialStock(TpMaterialType.COLOR, code) + 1e-9 < need) add("$code krasitel") }
    }
}

private fun periodDates(from: String, to: String): List<String> {
    val start = runCatching { LocalDate.parse(from) }.getOrElse { return emptyList() }
    val end = runCatching { LocalDate.parse(to) }.getOrElse { return emptyList() }
    if (end.isBefore(start)) return emptyList()
    val result = mutableListOf<String>()
    var cursor = start
    var guard = 0
    while (!cursor.isAfter(end) && guard < 370) {
        result += cursor.toString()
        cursor = cursor.plusDays(1)
        guard++
    }
    return result.reversed()
}
