package uz.toybola.factory.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.graphics.Color
import uz.toybola.factory.ui.model.AppSettings
import uz.toybola.factory.ui.model.AppThemePreset

private val ToyBlue = Color(0xFF2E86C1)
private val ToyNavy = Color(0xFF142B3C)
private val ToyIce = Color(0xFFF6FAFD)
private val ToySurface = Color(0xFFFFFFFF)
private val ToyYellow = Color(0xFFFFC21C)

@Composable
fun ToyBolaTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val seed = when (settings.themePreset) {
        AppThemePreset.BRAND -> ToyBlue
        AppThemePreset.CALM -> Color(0xFF3A8DBE)
        AppThemePreset.NEUTRAL -> Color(0xFF60798B)
    }

    val colors = if (settings.darkMode) {
        darkColorScheme(
            primary = Color(0xFF78BFF0),
            secondary = ToyYellow,
            background = Color(0xFF0F171D),
            surface = Color(0xFF17232B),
            surfaceVariant = Color(0xFF20313D),
            onPrimary = Color(0xFF06131C),
            onBackground = Color(0xFFF2F7FA),
            onSurface = Color(0xFFF2F7FA),
            onSurfaceVariant = Color(0xFFC6D4DE)
        )
    } else {
        lightColorScheme(
            primary = seed,
            secondary = ToyYellow,
            tertiary = ToyNavy,
            background = ToyIce,
            surface = ToySurface,
            surfaceVariant = Color(0xFFEEF5FA),
            primaryContainer = Color(0xFFE8F4FD),
            secondaryContainer = Color(0xFFFFF2D9),
            onPrimary = Color.White,
            onBackground = ToyNavy,
            onSurface = ToyNavy,
            onSurfaceVariant = Color(0xFF657783)
        )
    }

    val baseDensity = LocalDensity.current
    val scale = settings.uiScalePercent.coerceIn(90, 110) / 100f
    CompositionLocalProvider(
        LocalDensity provides Density(
            density = baseDensity.density * scale,
            fontScale = baseDensity.fontScale * scale
        )
    ) {
        MaterialTheme(colorScheme = colors, content = content)
    }
}
