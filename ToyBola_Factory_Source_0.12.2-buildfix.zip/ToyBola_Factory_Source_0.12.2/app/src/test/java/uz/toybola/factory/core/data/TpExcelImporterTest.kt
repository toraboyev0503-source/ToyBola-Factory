package uz.toybola.factory.core.data

import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class TpExcelImporterTest {
    @Test
    fun parsesStandardTemplateAndKeepsDecimalPrice() {
        val payload = TpExcelImporter.parse(ByteArrayInputStream(testWorkbook()))
        assertEquals(1, payload.productCount)
        assertEquals(1, payload.detailCount)
        assertEquals(1, payload.colorCount)
        assertEquals(104.4, payload.details.single().unitPrice, 0.0001)
        assertEquals(setOf(60, 90, 120), payload.details.single().compatibleCapacities)
        assertEquals(listOf("0760", "PP"), payload.details.single().resinCodes)
        assertEquals("003", payload.colors.single().colorCode)
        assertEquals(1, payload.workerCount)
        assertEquals("Bobur", payload.workers.single().name)
        assertEquals("1-sex kunduzgi", payload.workers.single().brigadeName)
    }



    @Test
    fun acceptsLegacyFtarichkaMarkerWithoutMaterialSheet() {
        val payload = TpExcelImporter.parse(ByteArrayInputStream(testWorkbook(legacyFtarichkaMarker = true)))
        val detail = payload.details.single()
        assertEquals(listOf("0760", "PP"), detail.resinCodes)
        assertEquals(listOf(TP_ANY_RECYCLED_CODE), detail.recycledCodes)
        assertEquals(0, payload.materialCount)
    }

    @Test
    fun stripsExcelQuoteMarkersFromCodes() {
        val payload = TpExcelImporter.parse(ByteArrayInputStream(testWorkbook(quotedCodes = true)))
        assertEquals(listOf("0760", "PP"), payload.details.single().resinCodes)
        assertEquals("003", payload.colors.single().colorCode)
    }

    private fun testWorkbook(quotedCodes: Boolean = false, legacyFtarichkaMarker: Boolean = false): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            fun add(name: String, text: String) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(text.trimIndent().toByteArray())
                zip.closeEntry()
            }
            add("xl/workbook.xml", """
                <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
                  xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
                  <sheets>
                    <sheet name="Mahsulotlar" sheetId="1" r:id="rId1"/>
                    <sheet name="Ranglar" sheetId="2" r:id="rId2"/>
                    <sheet name="Ishchilar" sheetId="3" r:id="rId3"/>
                  </sheets>
                </workbook>
            """)
            add("xl/_rels/workbook.xml.rels", """
                <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
                  <Relationship Id="rId1" Target="worksheets/sheet1.xml" Type="x"/>
                  <Relationship Id="rId2" Target="worksheets/sheet2.xml" Type="x"/>
                  <Relationship Id="rId3" Target="worksheets/sheet3.xml" Type="x"/>
                </Relationships>
            """)
            add("xl/worksheets/sheet1.xml", sheetXml(listOf(
                listOf("Artikul", "Mahsulot nomi", "Detal nomi", "1 mahsulotga nechta", "1 jimda nechta", "1 qopda nechta", "1 jim vaqti (sekund)", "1 jim umumiy og'irligi (g)", "Yaroqsiz qism og'irligi (g)", "Seryo turlari", "1 jim narxi (so'm)", "Stanok sig'imlari"),
                listOf("TB-055 B", "Kamaz", "Tagi", "1", "1", "100", "60", "420.5", "35.5", when {
                    quotedCodes -> "\"0760\",PP"
                    legacyFtarichkaMarker -> "0760,PP,Ftarichka"
                    else -> "0760,PP"
                }, "104.4", "60,90,120")
            )))
            add("xl/worksheets/sheet2.xml", sheetXml(listOf(
                listOf("Artikul", "Detal nomi", "Rang kodi", "Taqsimot ulushi", "25 kg ga krasitel (g)"),
                listOf("TB-055 B", "Tagi", if (quotedCodes) "\"003\"" else "003", "100", "200")
            )))
            add("xl/worksheets/sheet3.xml", sheetXml(listOf(
                listOf("Ishchi ismi", "Brigada"),
                listOf("Bobur", "1-sex kunduzgi")
            )))
        }
        return out.toByteArray()
    }

    private fun sheetXml(rows: List<List<String>>): String = buildString {
        append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
        rows.forEachIndexed { rowIndex, row ->
            append("<row r=\"${rowIndex + 1}\">")
            row.forEachIndexed { columnIndex, value ->
                val ref = columnName(columnIndex) + (rowIndex + 1)
                append("<c r=\"$ref\" t=\"inlineStr\"><is><t>")
                append(value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
                append("</t></is></c>")
            }
            append("</row>")
        }
        append("</sheetData></worksheet>")
    }

    private fun columnName(index: Int): String {
        var n = index + 1
        val out = StringBuilder()
        while (n > 0) {
            val rem = (n - 1) % 26
            out.append(('A'.code + rem).toChar())
            n = (n - 1) / 26
        }
        return out.reverse().toString()
    }
}
