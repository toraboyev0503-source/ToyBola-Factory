package uz.toybola.factory.core.data

import org.junit.Assert.assertEquals
import org.junit.Test

class TpNegativeStockTest {
    @Test
    fun outgoingDeliveryCanRepresentNegativePhysicalStock() {
        val material = TpMaterial(
            id = "resin-0760",
            code = "0760",
            name = "0760",
            type = TpMaterialType.RESIN,
            availableAmount = 0.0,
            movements = listOf(
                TpMaterialMovement(
                    id = "out-50",
                    kind = TpMaterialMovementKind.OUT,
                    amount = 50.0,
                    createdAt = "2026-09-14T17:07:00",
                    sourceKind = TpMaterialSourceKind.JOB_DELIVERY
                )
            )
        )

        assertEquals(-50.0, material.currentStock(), 0.000_001)
    }

    @Test
    fun laterOpeningBalanceImportKeepsDeliveryHistory() {
        val deliveredBeforeImport = TpMaterial(
            id = "resin-0760",
            code = "0760",
            name = "0760",
            type = TpMaterialType.RESIN,
            availableAmount = 0.0,
            movements = listOf(
                TpMaterialMovement(
                    id = "out-50",
                    kind = TpMaterialMovementKind.OUT,
                    amount = 50.0,
                    createdAt = "2026-09-14T17:07:00",
                    sourceKind = TpMaterialSourceKind.JOB_DELIVERY
                )
            )
        )

        val afterImport = deliveredBeforeImport.copy(availableAmount = 120.0)
        assertEquals(70.0, afterImport.currentStock(), 0.000_001)
        assertEquals(1, afterImport.movements.size)
    }
}
