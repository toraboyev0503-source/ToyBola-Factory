package uz.toybola.factory.core.security

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import uz.toybola.factory.ui.model.AppScreen

class AccessControlTest {
    @Test fun everyTpOnlyProfileSkipsAssemblyChannel() {
        AssemblySection.entries.filter { it.name.startsWith("TP_") }.forEach { section ->
            val policy = UserAccessPolicy(userCode = "CUSTOM", role = "CUSTOM",
                sections = mapOf(section to SectionAccess(canRead = true)))
            assertTrue(policy.canReadAnyTp())
            assertFalse(policy.canReadAnyAssembly())
        }
    }
    @Test fun assemblyAndTpChannelsAreIndependent() {
        val policy = UserAccessPolicy(userCode = "CUSTOM", sections = mapOf(
            AssemblySection.BRIGADIR to SectionAccess(canRead = true)))
        assertTrue(policy.canReadAnyAssembly())
        assertFalse(policy.canReadAnyTp())
        assertFalse(UserAccessPolicy.locked().canReadAnyAssembly())
    }

    @Test
    fun assemblyOnlyUserDoesNotRequestTpSnapshot() {
        val policy = UserAccessPolicy(
            userCode = "BRG01",
            role = "BRIGADIR",
            sections = mapOf(AssemblySection.BRIGADIR to SectionAccess(canRead = true, canWrite = true))
        )
        assertFalse(policy.canReadAnyTp())
    }

    @Test
    fun tpRoleRequestsTpSnapshot() {
        val policy = UserAccessPolicy(
            userCode = "TPL01",
            role = "TP_PLAN",
            sections = mapOf(AssemblySection.TP_PLANNING to SectionAccess(canRead = true, canWrite = true))
        )
        assertTrue(policy.canReadAnyTp())
    }

    @Test
    fun adminKeepsTpAccessWhenLegacyPermissionMapHasNoTpKeys() {
        val policy = UserAccessPolicy(userCode = "ADMIN001", role = "ADMIN", sections = emptyMap())
        assertTrue(policy.canReadAnyTp())
    }
    @Test
    fun seryoOnlyUserSeesSeryoButNotTpMain() {
        val policy = UserAccessPolicy(
            userCode = "SERYO01",
            role = "CUSTOM",
            sections = mapOf(AssemblySection.TP_SERYO to SectionAccess(canRead = true, canWrite = true))
        )
        assertTrue(policy.canReadScreen(AppScreen.TP_SERYO))
        assertFalse(policy.canReadScreen(AppScreen.TP_MAIN))
    }

    @Test
    fun tpPlanningUserStillSeesTpMain() {
        val policy = UserAccessPolicy(
            userCode = "TPL01",
            role = "CUSTOM",
            sections = mapOf(AssemblySection.TP_PLANNING to SectionAccess(canRead = true, canWrite = true))
        )
        assertTrue(policy.canReadScreen(AppScreen.TP_MAIN))
    }

}
