# 0.11.0 — Seryo / Ftarichka yangilanishi

## Asosiy o‘zgarishlar
- Seryo → Kundalik qabul qilish: Brak qabul qilish, Qaytgan ftarichka, Brak o‘rniga qorishma.
- Ftarichka Seryo va Krasitel bilan bir qatorda uchinchi material turi. Seryo/Ftarichka kg (1 gram aniqlik), Krasitel gramda.
- Har bir detalga Excel orqali ishlatish mumkin bo‘lgan Ftarichka turlari biriktiriladi.
- Materiallar varag‘i Seryo/Krasitel/Ftarichka master-data va boshlang‘ich ostatkani import qiladi.
- Tayyorlovchi zakazni qisman yetkazadi: Zakaz / Berildi / Qoldi. Qoldiqdan ortiq berish bloklanadi.
- Oddiy seryoda krasitel avtomatik nisbatda; Ftarichkada krasitel 0 g dan boshlanadi, ixtiyoriy qo‘shiladi.
- Har bir yetkazish partiyasi darhol ostatkadan ayriladi.
- Ostatka ekranida oxirgi oldi-berdi sana/vaqti ko‘rinadi. Harakat manbasi auditda saqlanadi.

## Yangilash tartibi
1. GitHub repozitoriyasiga 0.11.0 Source ZIP tarkibini joylang.
2. `.github/workflows/main.yml` ni ushbu paketdagi fayl bilan almashtiring.
3. Actions ichida Android test/lint/APK va Firebase deploy muvaffaqiyatli tugashini tekshiring.
4. APKni mavjud ilovaning ustidan yangilang. Debug imzo o‘zgarmagan.
5. Yangi Excel shablonida `Materiallar` varag‘ini to‘ldiring va `Mahsulotlar` dagi `Ftarichka turlari` ustunini kerakli detallarga kiriting.

## Muhim
Server funksiyalari va Firestore qoidalari ham yangilangan. Faqat APKni yangilab, Firebase deploy qilinmasa yangi sync obyektlari to‘liq ishlamaydi.
