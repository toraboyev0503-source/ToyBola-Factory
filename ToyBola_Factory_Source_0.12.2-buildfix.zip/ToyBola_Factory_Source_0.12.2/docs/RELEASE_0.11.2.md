# 0.11.2 — TP import mosligi va asosiy oyna

- `Materiallar` varag‘i TP importi uchun majburiy emas.
- `Seryo turlari` ichidagi eski `Ftarichka` yozuvi backward-compatible ruxsat markeridir.
- `Ftarichka turlari` mavjud bo‘lsa, aniq ftarichka kodlari ishlatiladi.
- Materiallar varag‘i mavjud bo‘lsa, material kodlari qattiq tekshiriladi.
- Bosh oynada 7. Rahbariyat nazorati va 8. Ma’lumotlar teng o‘lchamli kartalarda bir qatorda turadi.
- Versiya 0.11.2 / versionCode 1102.
