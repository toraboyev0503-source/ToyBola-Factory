# ToyBola Factory 0.11.3

## Tasdiqlangan UI yangilanishlari

Bu versiyada foydalanuvchi tasdiqlagan maketlar implementatsiya uchun asosiy vizual referens sifatida ishlatildi. Referens rasmlar `docs/design/` ichida saqlangan.

- Ilova ikonka, Android 12+ system splash, ichki yuklanish splash va login bitta ToyBola brend tiliga keltirildi.
- Bosh sahifadagi chap hamburger/drawer olib tashlandi. Doimiy pastki panel: **Bosh sahifa / Bildirishnomalar / Sinxronlash / Sozlamalar**.
- Bosh sahifa kartalarida faol bo‘limlar pastel aksent bilan, ishga tushmagan yoki ruxsatsiz bo‘limlar esa xira/desaturatsiya bilan ajratiladi.
- TP bosh sahifasi, Plan sahifasi va Nachalnik zakazlari tasdiqlangan maketlarning joylashuvi, kartalari, ikonkalari va rang tizimiga moslashtirildi.
- Nachalnik zakazida bo‘sh holat, yangi zakaz oynasi va yaratilgan zakaz kartasi yangilandi.

## Seryo: ostatka manfiyga tushishiga ruxsat

Seryo real berilgan bo‘lsa, Excel material master/ostatka hali kiritilmagani operatsiyani bloklamaydi.

- `addJobMaterialBatch` va `addCompensationMaterialBatch` OUT harakati uchun manfiy stockga ruxsat beradi.
- Material kodi masterda topilmasa, 0 boshlang‘ich ostatka bilan vaqtinchalik material yozuvi yaratiladi va OUT movement yoziladi.
- Masalan, `0760` ostatka `0 kg` bo‘lib 50 kg berilsa: **ostatka = -50 kg**, partiya esa **Berildi = 50 kg** sifatida saqlanadi.
- Keyinchalik Excel import shu kodning `availableAmount`/boshlang‘ich ostatkasini yangilaydi; oldingi movement tarixi o‘chirilmaydi.
- Oddiy qo‘lda stock chiqarish operatsiyalarida eski himoya saqlanadi; manfiyga ruxsat faqat Seryo delivery/compensation oqimida yoqilgan.

## Versiya

- `versionCode = 1103`
- `versionName = 0.11.3`
- GitHub Actions APK artifact: `ToyBola-0.11.3-debug-apk`

## Tekshiruv

Repo ichida manfiy ostatka matematikasini tekshiradigan `TpNegativeStockTest` qo‘shildi. GitHub Actions `test`, `lint`, `assembleDebug` bosqichlarini bajaradi.
