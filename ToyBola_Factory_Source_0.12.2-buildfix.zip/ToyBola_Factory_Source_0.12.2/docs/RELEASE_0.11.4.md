# ToyBola Factory 0.11.4

## Maqsad
0.11.3 dizaynini real Android qurilmada tasdiqlangan maketga yaqinlashtirish va render artefaktlarini yo‘qotish.

## Tuzatildi
- Home/TP kartalaridagi kulrang tashqi qatlam + oq ichki to‘rtburchak artefakti.
- Plan action-card laridagi ichki oq to‘rtburchak artefakti.
- Bottom navigation intrinsic width sabab `Sinxronlanmoqda`/`Sozlamalar` kesilishi.
- Bottom nav sinxronlash elementi endi doim `Sinxronlash`; runtime holati top sync pill da.
- Home brend rasmi noto‘g‘ri aspect box ichida siqilishi.
- Home sarlavha va sana collision holati.
- TP approved active/muted visual state.

## Saqlangan
- Seryo ish berishda ostatkani minusga tushirish imkoniyati.
- Firebase/offline/sync/ruxsatlar va mavjud biznes logikasi.

## Version
- versionCode: 1104
- versionName: 0.11.4
- GitHub Actions artifact: ToyBola-0.11.4-debug-apk
