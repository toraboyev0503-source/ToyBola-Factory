# ToyBola Factory 0.12.0

## Scope

0.12.0 implements only the decisions already frozen before the Sborka/Xonadon audit:

- Global architecture: 1–12
- Home and global navigation: 13–24
- Seryo: 25–36
- TP: 37–64

Sborka/Xonadon decisions 65+ are intentionally **not** implemented in this release.

## Compatibility contract

- `applicationId` / package: `uz.toybola.factory` — unchanged.
- Version: `versionCode 1200`, `versionName 0.12.0`.
- Existing ToyBola debug update keystore is preserved byte-for-byte from 0.11.4.
- Existing SharedPreferences snapshots remain readable. 0.12.0 adds a Room snapshot store using transitional dual-write so an in-place update does not require destructive migration.
- Server-authoritative snapshot, tombstone, outbox and recovery semantics are retained.

## Product / navigation

- Home is a module launchpad; management modules are grouped separately.
- Central Module Registry owns module route, launch state, icon/accent and permission visibility.
- Bottom navigation contains four real root destinations: Home, Notifications, Sync Center and Settings.
- Each root preserves its own navigation stack across tab switches and saveable Activity/process recreation.
- Back and notification deep-link behavior follows the natural module hierarchy.
- Unsaved inline TP issue form blocks root-tab switching until the user explicitly stays or leaves.
- Home header shows user/profile scope, date and sync state. Sync status opens Sync Center rather than starting an unrelated duplicate action.

## Sync / notifications / backup

- Unconditional foreground polling was removed; sync is event-driven with existing WorkManager/server fallback retained.
- Sync Center shows pending work, network state, last success/error and manual retry.
- Notifications support New / Important / All filtering and exact-object deep-link routes.
- Full client backup contains Assembly + TP/Seryo + portable UI settings, has SHA-256 payload validation and a restore preview. Device/User codes are deliberately excluded.

## Local storage transition

0.12.0 introduces Room for large client snapshots while keeping SharedPreferences dual-write compatibility. This is a safe transition layer, not a destructive entity-by-entity schema rewrite. A later approved technical phase can normalize individual entities into Room tables.

## Seryo

- `Kundalik amallar`: Brak qabul / Qaytgan ftarichka / Brak o‘rniga qorishma.
- Seryo approval works at detail+color level; approved work can continue independently.
- Preparation/delivery is one chronological queue with partial delivery and date-based history.
- Real production delivery may intentionally make stock negative after an explicit warning. Manual stock-out remains protected from negative stock.
- Unified Stock Center: Ostatka / Kirim / Chiqim, material/date/search filters.
- Operational resin, recycled feedstock and colorant display uses kg consistently.
- Material corrections use reverse movements with mandatory reason and audit history.
- Excel import is Preview → Import; movement history is preserved and repeated master import updates rather than double-appending operational movements.
- Granular Seryo permissions are supported.

## TP

- TP structure: Zakaz va reja / Stanoklar va smena / Qabul / Sifat / Monitoring.
- Permission-aware shortcutting skips redundant intermediate menus.
- Order lifecycle is derived from planning/production state; linked orders are cancelled with reason rather than hard-deleted.
- Plan unit is detail+color.
- Machine planning is decision support. `Boshqa stanok` remains available for experiment/emergency/forced production and requires an auditable reason.
- One machine cannot start two concurrent active jobs; material-delivery prerequisites are checked.
- Receipt flow previews credited output and supports audit-safe edit/cancel.
- Sifat contains Baholash + Kun muammosi only.
- Quality round schedule/count comes from shift master data; Admin can configure separate before/after open-window minutes.
- `Sababli` worker absence is excluded from the average and requires a comment; `Sababsiz` counts as the lowest result.
- Kun muammosi has New → In progress → Resolved/Cancelled lifecycle, assignee/category/media and audit history.
- Monitoring is read-only, has standard period/shop/shift/brigade/machine/product filters, KPI overview, drill-down and current-scope Word/Excel export.
- Referenced master data uses archive semantics rather than destructive delete where applicable.
- TP permissions are action-based; role remains a preset rather than the authority itself.

## Build / verification

GitHub workflow performs Android unit tests, lint and `assembleDebug`, then runs server validation before Firebase deploy. Local environment checks are documented in `docs/CHECKS_0.12.0.txt`.
