# ToyBola Factory 0.12.1

## Build compatibility fix

GitHub Actions 0.12.0 buildida AGP 9.3.1 built-in Kotlin bilan `org.jetbrains.kotlin.kapt` plugin to‘qnashdi. Android Developers tavsiya qilgan moslik yo‘li qo‘llandi:

- root plugin: `com.android.legacy-kapt` version `9.3.1`
- app plugin: `com.android.legacy-kapt`
- Room compiler dependency: `kapt("androidx.room:room-compiler:2.7.2")`
- built-in Kotlin yoqilgan holatda qoldi

Product/UX 1–64 funksional o‘zgarishlari 0.12.0 bilan bir xil. Sborka/Xonadon 65+ kiritilmagan.
