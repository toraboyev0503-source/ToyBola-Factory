# ToyBola Factory 0.12.2 — build fix

GitHub Actions `./gradlew test --stacktrace` jarayonida `:app:kaptDebugKotlin` Room compiler bosqichida to‘xtadi.

Asosiy root cause:

```
Provided Metadata instance has version 2.3.0, while maximum supported version is 2.2.0.
... androidx.room.compiler.processing ...
```

Tuzatish:

- `com.android.legacy-kapt` olib tashlandi.
- `com.google.devtools.ksp` `2.3.12` qo‘shildi.
- `kapt("androidx.room:room-compiler:2.7.2")` → `ksp("androidx.room:room-compiler:2.8.5")`.
- `room-runtime` va `room-ktx` ham `2.8.5` ga bir xil versiyada yangilandi.
- App version: `0.12.2` / `1202`.

Bu build-fix funksional oqimlarni o‘zgartirmaydi.
