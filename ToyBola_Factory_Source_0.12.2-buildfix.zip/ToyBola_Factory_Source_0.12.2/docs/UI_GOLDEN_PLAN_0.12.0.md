# UI golden / screenshot regression plan

Frozen decision 12 requires visual regression coverage for final approved screens.

Actual image goldens are intentionally not fabricated in 0.12.0: final per-screen UX/design specifications (dp/sp/HEX/radius/icon/opacity/animation) have not yet all been approved. Creating a golden from an interim UI would freeze the wrong design.

When a screen becomes final, its verification set will contain at minimum:

1. compact phone / light mode;
2. reference phone / light mode;
3. reference phone / dark mode;
4. large phone where layout materially changes;
5. important empty/loading/error/disabled states.

The existing GitHub workflow remains the gate for compile/test/lint. Screenshot comparison becomes an additional gate when those final baselines are recorded.
