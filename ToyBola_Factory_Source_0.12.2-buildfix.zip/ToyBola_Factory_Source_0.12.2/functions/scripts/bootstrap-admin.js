"use strict";

const crypto = require("crypto");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

initializeApp();
const db = getFirestore();
const auth = getAuth();
const normalize = v => String(v || "").trim().toUpperCase();
const sha256 = v => crypto.createHash("sha256").update(String(v), "utf8").digest("hex");

(async () => {
  const userCode = normalize(process.env.TOYBOLA_ADMIN_USER_CODE);
  const deviceCode = normalize(process.env.TOYBOLA_ADMIN_DEVICE_CODE);
  const displayName = String(process.env.TOYBOLA_ADMIN_NAME || "Bosh administrator").trim();
  if (!userCode || !deviceCode) throw new Error("TOYBOLA_ADMIN_USER_CODE va TOYBOLA_ADMIN_DEVICE_CODE secrets kerak");

  const loginId = sha256(userCode);
  const existing = await db.collection("loginCodes").doc(loginId).get();
  const uid = existing.exists ? existing.get("uid") : `tb_${loginId.slice(0, 28)}`;
  try { await auth.getUser(uid); } catch (e) {
    if (e && e.code === "auth/user-not-found") await auth.createUser({ uid, displayName }); else throw e;
  }
  const permissions = {
    BRIGADIR_READ: true, BRIGADIR_WRITE: true,
    QUALITY_READ: true, QUALITY_WRITE: true,
    DAILY_ISSUE_READ: true, DAILY_ISSUE_WRITE: true,
    MONITORING_READ: true,
    MASTER_DATA_READ: true, MASTER_DATA_WRITE: true,
    TP_ORDER_READ: true, TP_ORDER_WRITE: true,
    TP_PLANNING_READ: true, TP_PLANNING_WRITE: true,
    TP_MACHINE_READ: true, TP_MACHINE_WRITE: true,
    TP_ATTENDANCE_READ: true, TP_ATTENDANCE_WRITE: true,
    TP_EXTRA_HOURS_READ: true, TP_EXTRA_HOURS_WRITE: true,
    TP_SERYO_READ: true, TP_SERYO_WRITE: true,
    TP_RECEIVING_READ: true, TP_RECEIVING_WRITE: true,
    TP_QUALITY_READ: true, TP_QUALITY_WRITE: true,
    TP_DAILY_ISSUE_READ: true, TP_DAILY_ISSUE_WRITE: true,
    TP_MONITORING_READ: true, TP_EXPORT: true,
    TP_MASTER_DATA_READ: true, TP_MASTER_DATA_WRITE: true
  };
  await db.collection("users").doc(uid).set({
    uid, userCode, displayName, role: "ADMIN", enabled: true,
    allBrigades: true, allowedBrigadeIds: [], permissions,
    notifications: ["DAY_STATUS", "ISSUE_SUMMARY"], revision: 1,
    createdAt: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp()
  }, { merge: true });
  await db.collection("loginCodes").doc(loginId).set({
    uid, enabled: true, deviceHashes: [sha256(deviceCode)], updatedAt: FieldValue.serverTimestamp()
  }, { merge: true });
  console.log(`Bootstrap admin tayyor: ${userCode} / uid=${uid}`);
})().catch(err => { console.error(err); process.exit(1); });
