"use strict";
const { equal } = require("./sync-merge");

/** Returns a reason when a scoped operator attempts to change another operator's fields. */
function mutationError(rootKey, before, after, can) {
  if (!after || typeof after !== "object") return "Yozuv noto‘g‘ri";
  if (rootKey === "jobs") {
    if (!Number.isFinite(after.requiredResinKg) || after.requiredResinKg < 0 || !Number.isFinite(after.requiredColorGrams) || after.requiredColorGrams < 0) return "Seryo hisobi noto‘g‘ri";
    const additions = after.resinAdditions || [];
    if (!Array.isArray(additions) || additions.some(row => !row.id || !["MANUAL", "ROUND_25"].includes(row.kind) || !Number.isFinite(row.kilograms) || row.kilograms <= 0 || row.kilograms > 1000000 || row.resinCode !== after.resinCode)) return "Qo‘shimcha seryo noto‘g‘ri";
    if (new Set(additions.map(row => row.id)).size !== additions.length) return "Qo‘shimcha seryo takrorlangan";
    if (!before) return can("TP_PLANNING_WRITE") ? null : "Yangi vazifaga plan ruxsati kerak";
    const batches = after.materialBatches || [];
    if (!Array.isArray(batches) || batches.some(row => !row.id || !["RESIN", "RECYCLED"].includes(row.feedstockType) || !row.feedstockCode || !Number.isFinite(row.feedstockKg) || row.feedstockKg <= 0 || !Number.isFinite(Number(row.colorGrams || 0)) || Number(row.colorGrams || 0) < 0)) return "Qorishma partiyasi noto‘g‘ri";
    if (new Set(batches.map(row => row.id)).size !== batches.length) return "Qorishma partiyasi takrorlangan";
    if (batches.reduce((sum, row) => sum + Number(row.feedstockKg || 0), 0) > Number(after.requiredResinKg || 0) + additions.reduce((sum, row) => sum + Number(row.kilograms || 0), 0) + 0.001) return "Berilgan xomashyo zakazdan ortiq";
    const material = new Set(["resinCode", "feedstockType", "resinSelectedAt", "resinConfirmedAt", "alternativeResin", "resinAdditions", "materialBatches", "materialStatus", "materialShortageOverride", "materialConfirmedAt", "materialDeliveredAt"]);
    for (const key of new Set([...Object.keys(before), ...Object.keys(after)])) {
      if (equal(before[key], after[key])) continue;
      if (material.has(key)) {
        if (!can("TP_SERYO_WRITE") && !can("TP_SERYO_APPROVAL_WRITE") && !can("TP_SERYO_DELIVERY_WRITE") && !can("TP_PLANNING_WRITE")) return "Seryo ruxsati kerak";
      } else if (["status", "startedAt"].includes(key)) {
        if (!can("TP_MACHINE_WRITE") && !can("TP_RECEIVING_WRITE") && !can("TP_PLANNING_WRITE")) return "Stanok yoki qabul ruxsati kerak";
      } else if (!can("TP_PLANNING_WRITE") && !can("TP_MACHINE_WRITE")) return "Plan ruxsati kerak";
    }
  }
  if (rootKey === "orders" && before && !can("TP_ORDER_WRITE") && !can("TP_PLANNING_WRITE")) {
    if (Object.keys(after).some(key => !["status", "completedAt"].includes(key) && !equal(before[key], after[key]))) return "Zakaz maydonlarini o‘zgartirishga ruxsat yo‘q";
  }
  if (rootKey === "materials") {
    if (!Number.isFinite(after.availableAmount)) return "Ostatka noto‘g‘ri";
    if (!['RESIN','COLOR','RECYCLED'].includes(after.type)) return "Material turi noto‘g‘ri";
    if ((after.movements || []).some(row => !Number.isFinite(row.amount) || row.amount <= 0)) return "Material harakati noto‘g‘ri";
  }
  if (rootKey === "seryoCompensations") {
    if (!after.id || !after.machineId || !after.productId || !after.detailId || !Number.isFinite(after.targetKg) || after.targetKg <= 0) return "Brak o‘rniga zakaz noto‘g‘ri";
    const batches = after.batches || [];
    if (!Array.isArray(batches) || batches.some(row => !row.id || !["RESIN", "RECYCLED"].includes(row.feedstockType) || !row.feedstockCode || !Number.isFinite(row.feedstockKg) || row.feedstockKg <= 0 || Number(row.colorGrams || 0) < 0)) return "Brak o‘rniga partiya noto‘g‘ri";
    if (new Set(batches.map(row => row.id)).size !== batches.length) return "Brak o‘rniga partiya takrorlangan";
    if (batches.reduce((sum, row) => sum + Number(row.feedstockKg || 0), 0) > Number(after.targetKg) + 0.001) return "Brak o‘rniga berilgan miqdor zakazdan ortiq";
  }
  if (rootKey === "auditLog" && before && !equal(before, after)) return "Audit yozuvi o‘zgarmasligi kerak";
  return null;
}
module.exports = { mutationError };
