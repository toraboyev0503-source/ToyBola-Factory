package uz.toybola.factory.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.AssemblyDataRepository
import uz.toybola.factory.core.data.TpDataRepository
import uz.toybola.factory.core.firebase.*
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.ui.model.AppStrings

@Composable
fun AppTopBar(
    title: String,
    canGoBack: Boolean,
    onMenu: () -> Unit,
    onBack: () -> Unit,
    subtitle: String? = null,
    showSync: Boolean = true
) {
    val context = LocalContext.current
    val repository = remember(context) { AssemblyDataRepository(context) }
    val tpRepository = remember(context) { TpDataRepository(context) }
    val outbox = remember(context) { AssemblySyncOutbox(context) }
    val tpOutbox = remember(context) { TpSyncOutbox(context) }
    val dataRevision by AssemblyDataEvents.revision.collectAsState()
    val tpDataRevision by TpDataEvents.revision.collectAsState()
    val outboxRevision by SyncOutboxEvents.revision.collectAsState()
    val runtime by SyncStatusEvents.state.collectAsState()
    val syncStrings = AppStrings(AppPreferences(context).loadSettings().language)

    val localData = remember(dataRevision) { repository.load() }
    val localTpData = remember(tpDataRevision, outboxRevision) { tpRepository.load() }
    val pendingCount = remember(outboxRevision, dataRevision, tpDataRevision) { outbox.pending().size + tpOutbox.pending().size }
    val syncedCount = remember(localData, localTpData, pendingCount) {
        (localData.syncableRecordCount() + localTpData.syncableRecordCount() - pendingCount).coerceAtLeast(0)
    }

    Column(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Surface(
                modifier = Modifier.size(48.dp),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                shadowElevation = 1.dp
            ) {
                IconButton(onClick = if (canGoBack) onBack else onMenu) {
                    Icon(if (canGoBack) Icons.AutoMirrored.Rounded.ArrowBack else Icons.Rounded.Menu, contentDescription = null)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (!subtitle.isNullOrBlank()) {
                    Spacer(Modifier.height(2.dp))
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            if (showSync) {
                val text = when {
                    runtime.syncing -> syncStrings.syncing
                    runtime.waitingForNetwork -> "${syncStrings.waitingNetwork} • $pendingCount"
                    runtime.lastError.isNotBlank() -> "${syncStrings.pendingShort}: $pendingCount"
                    runtime.lastSuccessAtMs == 0L -> syncStrings.syncing
                    pendingCount > 0 -> "${syncStrings.pendingShort}: $pendingCount"
                    else -> "${syncStrings.syncedShort}: $syncedCount"
                }
                Surface(
                    modifier = Modifier.clickable(onClick = AppNavigationEvents::requestSyncCenter),
                    shape = RoundedCornerShape(99.dp),
                    color = if (runtime.lastError.isNotBlank()) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Sync, contentDescription = null, modifier = Modifier.size(16.dp), tint = if (runtime.lastError.isNotBlank()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(5.dp))
                        Text(text, style = MaterialTheme.typography.labelMedium, color = if (runtime.lastError.isNotBlank()) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    }
                }
            }
        }
        if (runtime.lastError.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(runtime.lastError, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error, maxLines = 2)
        }
        SyncRecoveryNotice()
        Spacer(Modifier.height(4.dp))
    }
}
