package uz.toybola.factory.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.toybola.factory.R
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AssemblyDataEvents
import uz.toybola.factory.core.firebase.SyncStatusEvents
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.components.SectionCard
import uz.toybola.factory.ui.model.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

private data class HomeCopy(val title: String, val description: String)
private data class HomeModuleStatus(val badge: Int = 0, val warning: String = "")
private data class HomeActivity(
    val title: String,
    val subtitle: String,
    val time: String,
    val sortKey: String,
    val icon: ImageVector,
    val accent: Color
)

@Composable
fun HomeScreen(
    strings: AppStrings,
    accessPolicy: UserAccessPolicy,
    unreadNotifications: Int = 0,
    onOpen: (AppScreen) -> Unit
) {
    var disabledMessage by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val tpRevision by TpDataEvents.revision.collectAsState()
    val assemblyRevision by AssemblyDataEvents.revision.collectAsState()
    val tpData = remember(tpRevision, accessPolicy.revision) { TpDataRepository(context).load().scopedFor(accessPolicy) }
    val assemblyData = remember(assemblyRevision, accessPolicy.revision) { AssemblyDataRepository(context).load().scopedFor(accessPolicy) }
    val brigadeScopeLabel = remember(tpData, assemblyData, accessPolicy.allowedBrigadeIds) {
        val allowed = accessPolicy.allowedBrigadeIds
        when {
            allowed == null -> "Barcha brigadalar"
            allowed.isEmpty() -> ""
            allowed.size == 1 -> {
                val id = allowed.first()
                tpData.brigades.firstOrNull { it.id == id }?.name
                    ?: assemblyData.brigades.firstOrNull { it.id == id }?.name
                    ?: "1 ta brigada"
            }
            else -> "${allowed.size} ta brigada"
        }
    }

    val seryoActions = remember(tpData, accessPolicy.revision) {
        if (accessPolicy.isAdmin() || listOf(AssemblySection.TP_SERYO_APPROVAL, AssemblySection.TP_SERYO_DELIVERY).any(accessPolicy::canRead)) {
            tpData.jobs.count { job ->
                job.planConfirmedAt != null && job.status != TpJobStatus.COMPLETE &&
                    (job.resinConfirmedAt == null || job.materialStatus != TpMaterialStatus.DELIVERED)
            }
        } else 0
    }
    val negativeStock = remember(tpData) { tpData.materials.count { !it.archived && it.currentStock() < -0.0001 } }
    val tpActions = remember(tpData, accessPolicy.revision) {
        var count = 0
        if (accessPolicy.isAdmin() || accessPolicy.canRead(AssemblySection.TP_PLANNING)) {
            count += tpData.orders.count { order ->
                order.status !in setOf(TpOrderStatus.COMPLETE, TpOrderStatus.CANCELLED) &&
                    tpData.jobs.filter { it.orderId == order.id }.let { jobs -> jobs.isEmpty() || jobs.any { it.planConfirmedAt == null } }
            }
        }
        if (accessPolicy.isAdmin() || accessPolicy.canRead(AssemblySection.TP_MACHINE)) {
            count += tpData.jobs.count { it.planConfirmedAt != null && it.materialStatus == TpMaterialStatus.DELIVERED && it.status == TpJobStatus.QUEUED }
        }
        if (accessPolicy.isAdmin() || accessPolicy.canRead(AssemblySection.TP_DAILY_ISSUE)) {
            count += tpData.dailyIssues.count { it.status == TpDailyIssueStatus.NEW || it.status == TpDailyIssueStatus.IN_PROGRESS }
        }
        count
    }
    val statuses = mapOf(
        "SERYO" to HomeModuleStatus(seryoActions, if (negativeStock > 0) "$negativeStock ta manfiy ostatka" else ""),
        "TP" to HomeModuleStatus(tpActions)
    )
    val copies = mapOf(
        "SERYO" to HomeCopy(strings.molding, strings.moldingDesc),
        "TP" to HomeCopy(strings.tp, strings.tpDesc),
        "YTM" to HomeCopy(strings.ytmWarehouse, strings.ytmWarehouseDesc),
        "SPARE" to HomeCopy(strings.sparePartsWarehouse, strings.sparePartsWarehouseDesc),
        "ASSEMBLY" to HomeCopy(strings.assemblyAndHome, strings.assemblyAndHomeDesc),
        "TM_EXP" to HomeCopy(strings.finishedGoods, strings.finishedGoodsDesc),
        "MANAGEMENT" to HomeCopy(strings.managementControl, strings.managementControlDesc),
        "MASTER" to HomeCopy(strings.globalMasterData, strings.globalMasterDataDesc)
    )

    val today = remember { LocalDate.now() }
    val todayIso = today.toString()
    val todayMetrics = remember(tpData, todayIso) { calculateTodayMetrics(tpData, todayIso) }
    val activities = remember(tpData, assemblyData) { buildRecentActivities(tpData, assemblyData) }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxSize()
                .widthIn(max = 760.dp)
                .verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("HomeScreen-dashboard"))
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.statusBarsPadding())
            Spacer(Modifier.height(10.dp))
            HomeIdentityRow(
                strings = strings,
                accessPolicy = accessPolicy,
                unreadNotifications = unreadNotifications,
                onNotifications = { onOpen(AppScreen.NOTIFICATIONS) }
            )
            Spacer(Modifier.height(18.dp))
            HomeWelcomeRow(accessPolicy, brigadeScopeLabel, today)
            Spacer(Modifier.height(20.dp))
            HomeKpiRow(todayMetrics)
            Spacer(Modifier.height(22.dp))
            HomeSectionHeader(title = "Modullar", action = "Barchasini ko‘rish")
            Spacer(Modifier.height(10.dp))
            HomeModuleGrid(
                specs = ModuleRegistry.production,
                copies = copies,
                statuses = statuses,
                policy = accessPolicy,
                onOpen = onOpen,
                onUnlaunched = { disabledMessage = true }
            )
            Spacer(Modifier.height(22.dp))
            HomeSectionHeader(title = "So‘nggi faollik", action = if (activities.isNotEmpty()) "Barchasini ko‘rish" else null)
            Spacer(Modifier.height(10.dp))
            RecentActivityCard(activities)

            val managementVisible = ModuleRegistry.management.any { ModuleRegistry.visible(it, accessPolicy) }
            if (managementVisible) {
                Spacer(Modifier.height(22.dp))
                HomeSectionHeader(title = "Boshqaruv")
                Spacer(Modifier.height(10.dp))
                HomeModuleGrid(
                    specs = ModuleRegistry.management,
                    copies = copies,
                    statuses = statuses,
                    policy = accessPolicy,
                    onOpen = onOpen,
                    onUnlaunched = { disabledMessage = true }
                )
            }
            Spacer(Modifier.height(20.dp))
        }
    }

    if (disabledMessage) {
        AlertDialog(
            onDismissRequest = { disabledMessage = false },
            confirmButton = { TextButton(onClick = { disabledMessage = false }) { Text("OK") } },
            text = { Text(strings.notLaunched) }
        )
    }
}

private data class TodayMetrics(val planned: Int, val completed: Int, val percent: Int)

private fun calculateTodayMetrics(data: TpData, today: String): TodayMetrics {
    val receiptJobIds = data.receipts.asSequence()
        .filter { !it.isCancelled && it.date == today }
        .map { it.jobId }
        .toSet()
    val datedJobIds = data.jobs.asSequence()
        .filter { job ->
            job.startedAt?.startsWith(today) == true ||
                job.planConfirmedAt?.startsWith(today) == true ||
                receiptJobIds.contains(job.id)
        }
        .map { it.id }
        .toSet()

    val relevantJobs = if (datedJobIds.isNotEmpty()) {
        data.jobs.filter { it.id in datedJobIds }
    } else {
        data.jobs.filter { it.planConfirmedAt != null && it.status != TpJobStatus.COMPLETE }.take(24)
    }
    val relevantIds = relevantJobs.mapTo(hashSetOf()) { it.id }
    val planned = relevantJobs.sumOf { job -> job.outputs.sumOf { it.requiredPieces } }
    val completed = data.receipts.asSequence()
        .filter { !it.isCancelled && it.date == today && (relevantIds.isEmpty() || it.jobId in relevantIds) }
        .sumOf { it.creditedPieces }
    val denominator = planned.coerceAtLeast(completed)
    val percent = if (denominator <= 0) 0 else ((completed * 100.0) / denominator).roundToInt().coerceIn(0, 100)
    return TodayMetrics(denominator, completed, percent)
}

@Composable
private fun HomeIdentityRow(
    strings: AppStrings,
    accessPolicy: UserAccessPolicy,
    unreadNotifications: Int,
    onNotifications: () -> Unit
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(R.drawable.toybola_mark),
            contentDescription = strings.appName,
            modifier = Modifier.size(54.dp).clip(RoundedCornerShape(15.dp))
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("ToyBola", fontSize = 22.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
            Text(
                "F a c t o r y",
                fontSize = 10.sp,
                lineHeight = 12.sp,
                fontWeight = FontWeight.Normal,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Box {
            IconButton(onClick = onNotifications, modifier = Modifier.size(44.dp)) {
                Icon(Icons.Rounded.NotificationsNone, contentDescription = strings.notifications, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (unreadNotifications > 0) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = (-5).dp, y = 5.dp)
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.error)
                )
            }
        }
        Spacer(Modifier.width(6.dp))
        val initial = accessPolicy.displayName.ifBlank { accessPolicy.userCode }.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "A"
        Surface(
            modifier = Modifier.size(42.dp),
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(initial, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun HomeWelcomeRow(accessPolicy: UserAccessPolicy, brigadeScopeLabel: String, date: LocalDate) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Xush kelibsiz!", fontSize = 22.sp, lineHeight = 27.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
            Spacer(Modifier.height(3.dp))
            val identity = listOf(
                accessPolicy.displayName.ifBlank { accessPolicy.userCode }.takeIf { it.isNotBlank() },
                accessPolicy.role.takeIf { it.isNotBlank() },
                brigadeScopeLabel.takeIf { it.isNotBlank() && it != "Barcha brigadalar" }
            ).filterNotNull().joinToString(" • ")
            Text(
                if (identity.isBlank()) "Bugungi ishlarimiz muvaffaqiyatli bo‘lsin." else identity,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(12.dp))
        Row(verticalAlignment = Alignment.Top) {
            Icon(Icons.Rounded.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(6.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(formatUzbekDate(date), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                Text(uzbekWeekday(date), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun HomeKpiRow(metrics: TodayMetrics) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        HomeKpiCard(
            modifier = Modifier.weight(1f),
            icon = Icons.Rounded.BarChart,
            iconTint = Color(0xFF4A90E2),
            title = "Bugungi reja",
            value = formatNumber(metrics.planned),
            unit = "dona"
        )
        HomeKpiCard(
            modifier = Modifier.weight(1f),
            icon = Icons.Rounded.CheckCircle,
            iconTint = Color(0xFF4B9A61),
            title = "Bajarilgan",
            value = formatNumber(metrics.completed),
            unit = "dona"
        )
        ProgressKpiCard(Modifier.weight(1f), metrics.percent)
    }
}

@Composable
private fun HomeKpiCard(
    modifier: Modifier,
    icon: ImageVector,
    iconTint: Color,
    title: String,
    value: String,
    unit: String
) {
    Surface(
        modifier = modifier.height(136.dp),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shadowElevation = 1.dp
    ) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(26.dp))
            Spacer(Modifier.height(8.dp))
            Text(title, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text(value, fontSize = 22.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
            Text(unit, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ProgressKpiCard(modifier: Modifier, percent: Int) {
    Surface(
        modifier = modifier.height(136.dp),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shadowElevation = 1.dp
    ) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(74.dp), contentAlignment = Alignment.Center) {
                val track = MaterialTheme.colorScheme.outlineVariant
                val progress = MaterialTheme.colorScheme.primary
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 7.dp.toPx()
                    val inset = stroke / 2f
                    val arcSize = Size(size.width - stroke, size.height - stroke)
                    drawArc(track, -90f, 360f, false, topLeft = androidx.compose.ui.geometry.Offset(inset, inset), size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                    drawArc(progress, -90f, 360f * (percent.coerceIn(0, 100) / 100f), false, topLeft = androidx.compose.ui.geometry.Offset(inset, inset), size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                }
                Text("$percent%", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
            }
            Spacer(Modifier.height(4.dp))
            Text("Bajarilish", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun HomeSectionHeader(title: String, action: String? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 18.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.weight(1f))
        if (!action.isNullOrBlank()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(action, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(3.dp))
                Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun HomeModuleGrid(
    specs: List<FactoryModuleSpec>,
    copies: Map<String, HomeCopy>,
    statuses: Map<String, HomeModuleStatus>,
    policy: UserAccessPolicy,
    onOpen: (AppScreen) -> Unit,
    onUnlaunched: () -> Unit
) {
    val visible = specs.filter { ModuleRegistry.visible(it, policy) }
    visible.chunked(2).forEachIndexed { rowIndex, row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            row.forEach { spec ->
                val copy = copies.getValue(spec.key)
                val status = statuses[spec.key] ?: HomeModuleStatus()
                val enabled = ModuleRegistry.canOpen(spec, policy)
                HomeModuleCard(
                    spec = spec,
                    title = copy.title,
                    description = if (!spec.launched) "${copy.description} • Tez orada" else copy.description,
                    status = status,
                    enabled = enabled,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        when {
                            enabled -> spec.route?.let(onOpen)
                            !spec.launched -> onUnlaunched()
                        }
                    }
                )
            }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
        if (rowIndex < visible.chunked(2).lastIndex) Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun HomeModuleCard(
    spec: FactoryModuleSpec,
    title: String,
    description: String,
    status: HomeModuleStatus,
    enabled: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val accent = if (enabled) spec.accent else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.42f)
    val bg = if (enabled) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.70f)
    Surface(
        modifier = modifier.height(96.dp).clickable(enabled = enabled || !spec.launched, onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = bg,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shadowElevation = if (enabled) 1.dp else 0.dp
    ) {
        Row(Modifier.fillMaxSize()) {
            Box(Modifier.width(4.dp).fillMaxHeight().background(accent))
            Row(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = accent.copy(alpha = 0.12f), modifier = Modifier.size(42.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(spec.icon, contentDescription = null, tint = accent, modifier = Modifier.size(24.dp))
                    }
                }
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(title, fontSize = 13.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold, color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        if (status.badge > 0 && enabled) {
                            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.error) {
                                Text(status.badge.coerceAtMost(99).toString(), color = MaterialTheme.colorScheme.onError, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp))
                            }
                        }
                    }
                    Spacer(Modifier.height(3.dp))
                    Text(description, fontSize = 11.sp, lineHeight = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (status.warning.isNotBlank()) {
                        Text(status.warning, fontSize = 10.sp, color = MaterialTheme.colorScheme.error, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            }
        }
    }
}

private fun buildRecentActivities(tpData: TpData, assemblyData: AssemblyData): List<HomeActivity> {
    val tpItems = tpData.auditLog.takeLast(12).map {
        HomeActivity(
            title = it.action.ifBlank { "TP yangilandi" }.replace('_', ' ').lowercase().replaceFirstChar { c -> c.titlecase() },
            subtitle = it.details.ifBlank { "Texnologik jarayonda o‘zgarish" },
            time = auditTime(it.createdAt),
            sortKey = it.createdAt,
            icon = Icons.Rounded.Settings,
            accent = Color(0xFF4A90E2)
        )
    }
    val assemblyItems = assemblyData.auditLog.takeLast(12).map {
        HomeActivity(
            title = it.action.ifBlank { "Sborka yangilandi" }.replace('_', ' ').lowercase().replaceFirstChar { c -> c.titlecase() },
            subtitle = it.details.ifBlank { "Sborka ma’lumoti yangilandi" },
            time = auditTime(it.dateTime),
            sortKey = it.dateTime,
            icon = Icons.Rounded.Inventory2,
            accent = Color(0xFF55A65A)
        )
    }
    return (tpItems + assemblyItems).sortedByDescending { it.sortKey }.take(2)
}

@Composable
private fun RecentActivityCard(activities: List<HomeActivity>) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shadowElevation = 1.dp
    ) {
        if (activities.isEmpty()) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.History, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(10.dp))
                Text("Hozircha faollik yo‘q", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
                activities.forEachIndexed { index, activity ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = CircleShape, color = activity.accent.copy(alpha = 0.12f), modifier = Modifier.size(42.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(activity.icon, contentDescription = null, tint = activity.accent, modifier = Modifier.size(23.dp))
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(activity.title, fontSize = 13.sp, lineHeight = 17.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(2.dp))
                            Text(activity.subtitle, fontSize = 11.sp, lineHeight = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text(activity.time, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (index != activities.lastIndex) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
            }
        }
    }
}

private fun auditTime(value: String): String {
    if (value.isBlank()) return ""
    val part = value.substringAfter('T', value).substringAfter(' ', value)
    return part.take(5).takeIf { it.count { c -> c == ':' } >= 1 } ?: ""
}

private fun formatNumber(value: Int): String = String.format(Locale.US, "%,d", value).replace(',', ' ')

private fun formatUzbekDate(date: LocalDate): String {
    val months = listOf("yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr")
    return "${date.dayOfMonth} ${months[date.monthValue - 1]}, ${date.year}"
}

private fun uzbekWeekday(date: LocalDate): String = when (date.dayOfWeek.value) {
    1 -> "Dushanba"
    2 -> "Seshanba"
    3 -> "Chorshanba"
    4 -> "Payshanba"
    5 -> "Juma"
    6 -> "Shanba"
    else -> "Yakshanba"
}

@Composable
fun ManagementMonitoringScreen(
    strings: AppStrings,
    onBack: () -> Unit,
    canOpen: (AppScreen) -> Boolean,
    onOpen: (AppScreen) -> Unit
) {
    val items = listOf(
        Triple("TP va Seryo", "Partiya, stanok, brigada, sifat va xomashyo", AppScreen.TP_MONITORING),
        Triple("Sborka", "Ishchi, brigada, sifat va foydalilik", AppScreen.MONITORING)
    )
    Column(Modifier.fillMaxSize()) {
        AppTopBar("Umumiy monitoring", canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items.forEachIndexed { index, item ->
                SectionCard(
                    number = index + 1,
                    title = item.first,
                    description = item.second,
                    enabled = canOpen(item.third),
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { if (canOpen(item.third)) onOpen(item.third) }
                )
            }
        }
    }
}
