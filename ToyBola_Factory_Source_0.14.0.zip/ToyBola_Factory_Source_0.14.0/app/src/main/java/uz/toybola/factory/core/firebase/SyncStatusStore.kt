package uz.toybola.factory.core.firebase

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import uz.toybola.factory.core.data.AssemblyData
import uz.toybola.factory.core.data.TpData

data class SyncRuntimeState(
    val syncing: Boolean = false,
    val waitingForNetwork: Boolean = false,
    val lastSuccessAtMs: Long = 0L,
    /** Persistent attention-level error. Kept blank for the first transient failures. */
    val lastError: String = "",
    /** Most recent transport/server failure, even while automatic retry is still in warning state. */
    val lastFailureMessage: String = "",
    val lastFailureAtMs: Long = 0L,
    val consecutiveFailures: Int = 0
) {
    val needsAttention: Boolean get() = lastError.isNotBlank() && consecutiveFailures >= ATTENTION_FAILURE_THRESHOLD
    val retryingAfterFailure: Boolean get() = !needsAttention && consecutiveFailures > 0 && lastFailureMessage.isNotBlank()

    companion object {
        const val ATTENTION_FAILURE_THRESHOLD = 3
    }
}

object SyncStatusEvents {
    private val _state = MutableStateFlow(SyncRuntimeState())
    val state: StateFlow<SyncRuntimeState> = _state.asStateFlow()

    internal fun set(value: SyncRuntimeState) {
        _state.value = value
    }
}

class SyncStatusStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    init {
        val current = SyncStatusEvents.state.value
        if (current == SyncRuntimeState()) {
            val failures = prefs.getInt(KEY_CONSECUTIVE_FAILURES, 0)
            val lastFailure = prefs.getString(KEY_LAST_FAILURE, "").orEmpty()
            SyncStatusEvents.set(
                SyncRuntimeState(
                    lastSuccessAtMs = prefs.getLong(KEY_LAST_SUCCESS, 0L),
                    lastError = if (failures >= SyncRuntimeState.ATTENTION_FAILURE_THRESHOLD) lastFailure else "",
                    lastFailureMessage = lastFailure,
                    lastFailureAtMs = prefs.getLong(KEY_LAST_FAILURE_AT, 0L),
                    consecutiveFailures = failures
                )
            )
        }
    }

    fun markSyncing() {
        val old = SyncStatusEvents.state.value
        SyncStatusEvents.set(old.copy(syncing = true, waitingForNetwork = false))
    }

    fun markWaitingForNetwork() {
        val old = SyncStatusEvents.state.value
        // Offline is a connectivity state, not a server failure. Do not paint it red.
        SyncStatusEvents.set(old.copy(syncing = false, waitingForNetwork = true, lastError = ""))
    }

    fun markSuccess() {
        val now = System.currentTimeMillis()
        prefs.edit()
            .putLong(KEY_LAST_SUCCESS, now)
            .remove(KEY_LAST_ERROR)
            .remove(KEY_LAST_FAILURE)
            .remove(KEY_LAST_FAILURE_AT)
            .putInt(KEY_CONSECUTIVE_FAILURES, 0)
            .apply()
        SyncStatusEvents.set(
            SyncRuntimeState(
                syncing = false,
                waitingForNetwork = false,
                lastSuccessAtMs = now
            )
        )
    }

    fun markFailure(message: String?) {
        val clean = message.orEmpty().trim().take(300).ifBlank { "Server bilan sinxronlash amalga oshmadi" }
        val old = SyncStatusEvents.state.value
        val failures = (old.consecutiveFailures + 1).coerceAtMost(99)
        val attention = failures >= SyncRuntimeState.ATTENTION_FAILURE_THRESHOLD
        val now = System.currentTimeMillis()
        prefs.edit()
            .putString(KEY_LAST_FAILURE, clean)
            .putLong(KEY_LAST_FAILURE_AT, now)
            .putInt(KEY_CONSECUTIVE_FAILURES, failures)
            .apply()
        if (attention) prefs.edit().putString(KEY_LAST_ERROR, clean).apply() else prefs.edit().remove(KEY_LAST_ERROR).apply()
        SyncStatusEvents.set(
            old.copy(
                syncing = false,
                waitingForNetwork = false,
                lastError = if (attention) clean else "",
                lastFailureMessage = clean,
                lastFailureAtMs = now,
                consecutiveFailures = failures
            )
        )
    }

    companion object {
        private const val PREFS = "toy_bola_sync_status"
        private const val KEY_LAST_SUCCESS = "last_success_ms"
        private const val KEY_LAST_ERROR = "last_error"
        private const val KEY_LAST_FAILURE = "last_failure"
        private const val KEY_LAST_FAILURE_AT = "last_failure_at"
        private const val KEY_CONSECUTIVE_FAILURES = "consecutive_failures"
    }
}

/** Number of local records represented by the server sync layer. */
fun AssemblyData.syncableRecordCount(): Int =
    brigades.size + workers.size + products.size + brigadeFk.size + workerDays.size +
        brigadeDays.size + qualityRounds.size + dailyIssues.size + auditLog.size + 1 // settings/assembly

/** Number of TP/Seryo local records represented by the server sync layer. */
fun TpData.syncableRecordCount(): Int =
    shops.size + shifts.size + brigades.size + machines.size + workers.size + products.size +
        materials.size + orders.size + jobs.size + attendance.size + receipts.size +
        qualityRounds.size + dailyIssues.size + extraHourTypes.size + extraHours.size +
        machineDowntimes.size + seryoCompensations.size + auditLog.size + 1 // settings/tp
