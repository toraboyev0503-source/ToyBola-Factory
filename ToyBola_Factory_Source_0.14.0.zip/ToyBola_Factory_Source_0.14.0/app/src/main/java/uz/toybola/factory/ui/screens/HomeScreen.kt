package uz.toybola.factory.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.toybola.factory.R
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AssemblyDataEvents
import uz.toybola.factory.core.firebase.AssemblySyncOutbox
import uz.toybola.factory.core.firebase.SyncOutboxEvents
import uz.toybola.factory.core.firebase.SyncStatusEvents
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.firebase.TpSyncOutbox
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppNavigationEvents
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.components.SectionCard
import uz.toybola.factory.ui.model.*
import java.time.LocalDate

private data class HomeCopy(val title: String, val description: String)
private data class HomeModuleStatus(val badge: Int = 0, val warning: String = "")
@Composable
fun HomeScreen(
    strings: AppStrings,
    accessPolicy: UserAccessPolicy,
    unreadNotifications: Int = 0,
    onOpen: (AppScreen) -> Unit
) {
    var disabledMessage by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val tpRevision by TpDataEvents.revision.collectAsState()
    val assemblyRevision by AssemblyDataEvents.revision.collectAsState()
    val tpData = remember(tpRevision, accessPolicy.revision) { TpDataRepository(context).load().scopedFor(accessPolicy) }
    val assemblyData = remember(assemblyRevision, accessPolicy.revision) { AssemblyDataRepository(context).load().scopedFor(accessPolicy) }
    val brigadeScopeLabel = remember(tpData, assemblyData, accessPolicy.allowedBrigadeIds) {
        val allowed = accessPolicy.allowedBrigadeIds
        when {
            allowed == null -> "Barcha brigadalar"
            allowed.isEmpty() -> ""
            allowed.size == 1 -> {
                val id = allowed.first()
                tpData.brigades.firstOrNull { it.id == id }?.name
                    ?: assemblyData.brigades.firstOrNull { it.id == id }?.name
                    ?: "1 ta brigada"
            }
            else -> "${allowed.size} ta brigada"
        }
    }

    val seryoActions = remember(tpData, accessPolicy.revision) {
        if (accessPolicy.isAdmin() || listOf(AssemblySection.TP_SERYO_APPROVAL, AssemblySection.TP_SERYO_DELIVERY).any(accessPolicy::canRead)) {
            tpData.jobs.count { job ->
                job.planConfirmedAt != null && job.status != TpJobStatus.COMPLETE &&
                    (job.resinConfirmedAt == null || job.materialStatus != TpMaterialStatus.DELIVERED)
            }
        } else 0
    }
    val negativeStock = remember(tpData) { tpData.materials.count { !it.archived && it.currentStock() < -0.0001 } }
    val tpActions = remember(tpData, accessPolicy.revision) {
        var count = 0
        if (accessPolicy.isAdmin() || accessPolicy.canRead(AssemblySection.TP_PLANNING)) {
            count += tpData.orders.count { order ->
                order.status !in setOf(TpOrderStatus.COMPLETE, TpOrderStatus.CANCELLED) &&
                    tpData.jobs.filter { it.orderId == order.id }.let { jobs -> jobs.isEmpty() || jobs.any { it.planConfirmedAt == null } }
            }
        }
        if (accessPolicy.isAdmin() || accessPolicy.canRead(AssemblySection.TP_MACHINE)) {
            count += tpData.jobs.count { it.planConfirmedAt != null && it.materialStatus == TpMaterialStatus.DELIVERED && it.status == TpJobStatus.QUEUED }
        }
        if (accessPolicy.isAdmin() || accessPolicy.canRead(AssemblySection.TP_DAILY_ISSUE)) {
            count += tpData.dailyIssues.count { it.status == TpDailyIssueStatus.NEW || it.status == TpDailyIssueStatus.IN_PROGRESS }
        }
        count
    }
    val statuses = mapOf(
        "SERYO" to HomeModuleStatus(seryoActions, if (negativeStock > 0) "$negativeStock ta manfiy ostatka" else ""),
        "TP" to HomeModuleStatus(tpActions)
    )
    val copies = mapOf(
        "SERYO" to HomeCopy(strings.molding, strings.moldingDesc),
        "TP" to HomeCopy(strings.tp, strings.tpDesc),
        "YTM" to HomeCopy(strings.ytmWarehouse, strings.ytmWarehouseDesc),
        "SPARE" to HomeCopy(strings.sparePartsWarehouse, strings.sparePartsWarehouseDesc),
        "ASSEMBLY" to HomeCopy(strings.assemblyAndHome, strings.assemblyAndHomeDesc),
        "TM_EXP" to HomeCopy(strings.finishedGoods, strings.finishedGoodsDesc),
        "MANAGEMENT" to HomeCopy(strings.managementControl, strings.managementControlDesc),
        "MASTER" to HomeCopy(strings.globalMasterData, strings.globalMasterDataDesc)
    )

    val today = remember { LocalDate.now() }
    val syncRuntime by SyncStatusEvents.state.collectAsState()
    val outboxRevision by SyncOutboxEvents.revision.collectAsState()
    val assemblyOutbox = remember(context) { AssemblySyncOutbox(context) }
    val tpOutbox = remember(context) { TpSyncOutbox(context) }
    val pendingSync = remember(outboxRevision, tpRevision, assemblyRevision) { assemblyOutbox.pending().size + tpOutbox.pending().size }

    val homeScrollState = uz.toybola.factory.ui.components.rememberRetainedScrollState("HomeScreen-dashboard")
    LaunchedEffect(Unit) {
        AppNavigationEvents.homeReselected.collect { homeScrollState.animateScrollTo(0) }
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxSize()
                .widthIn(max = 760.dp)
                .windowInsetsPadding(WindowInsets.statusBars)
                .verticalScroll(homeScrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            HomeIdentityRow(
                strings = strings,
                accessPolicy = accessPolicy,
                unreadNotifications = unreadNotifications,
                onNotifications = { onOpen(AppScreen.NOTIFICATIONS) }
            )
            Spacer(Modifier.height(12.dp))
            HomeWelcomeRow(accessPolicy, brigadeScopeLabel, today)
            Spacer(Modifier.height(12.dp))
            HomeSyncChip(
                runtime = syncRuntime,
                pending = pendingSync,
                onClick = { onOpen(AppScreen.SYNC_CENTER) }
            )
            Spacer(Modifier.height(18.dp))
            HomeSectionHeader(title = "Modullar")
            Spacer(Modifier.height(10.dp))
            HomeModuleGrid(
                specs = ModuleRegistry.production,
                copies = copies,
                statuses = statuses,
                policy = accessPolicy,
                onOpen = onOpen,
                onUnlaunched = { disabledMessage = true }
            )

            val managementVisible = ModuleRegistry.management.any { ModuleRegistry.visible(it, accessPolicy) }
            if (managementVisible) {
                Spacer(Modifier.height(18.dp))
                HomeSectionHeader(title = "Boshqaruv")
                Spacer(Modifier.height(10.dp))
                HomeModuleGrid(
                    specs = ModuleRegistry.management,
                    copies = copies,
                    statuses = statuses,
                    policy = accessPolicy,
                    onOpen = onOpen,
                    onUnlaunched = { disabledMessage = true }
                )
            }
            Spacer(Modifier.height(12.dp))
        }
    }

    if (disabledMessage) {
        AlertDialog(
            onDismissRequest = { disabledMessage = false },
            confirmButton = { TextButton(onClick = { disabledMessage = false }) { Text("OK") } },
            text = { Text(strings.notLaunched) }
        )
    }
}

@Composable
private fun HomeIdentityRow(
    strings: AppStrings,
    accessPolicy: UserAccessPolicy,
    unreadNotifications: Int,
    onNotifications: () -> Unit
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(R.drawable.toybola_mark),
            contentDescription = strings.appName,
            modifier = Modifier.size(54.dp).clip(RoundedCornerShape(15.dp))
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("ToyBola", fontSize = 22.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
            Text(
                "F a c t o r y",
                fontSize = 10.sp,
                lineHeight = 12.sp,
                fontWeight = FontWeight.Normal,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Box {
            IconButton(onClick = onNotifications, modifier = Modifier.size(44.dp)) {
                Icon(Icons.Rounded.NotificationsNone, contentDescription = strings.notifications, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (unreadNotifications > 0) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = (-5).dp, y = 5.dp)
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.error)
                )
            }
        }
        Spacer(Modifier.width(6.dp))
        val initial = accessPolicy.displayName.ifBlank { accessPolicy.userCode }.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "A"
        Surface(
            modifier = Modifier.size(42.dp),
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(initial, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun HomeWelcomeRow(accessPolicy: UserAccessPolicy, brigadeScopeLabel: String, date: LocalDate) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Xush kelibsiz!", fontSize = 22.sp, lineHeight = 27.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
            Spacer(Modifier.height(3.dp))
            val identity = listOf(
                accessPolicy.displayName.ifBlank { accessPolicy.userCode }.takeIf { it.isNotBlank() },
                accessPolicy.role.takeIf { it.isNotBlank() },
                brigadeScopeLabel.takeIf { it.isNotBlank() && it != "Barcha brigadalar" }
            ).filterNotNull().joinToString(" • ")
            Text(
                if (identity.isBlank()) "Bugungi ishlarimiz muvaffaqiyatli bo‘lsin." else identity,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(12.dp))
        Row(verticalAlignment = Alignment.Top) {
            Icon(Icons.Rounded.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(6.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(formatUzbekDate(date), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                Text(uzbekWeekday(date), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun HomeSyncChip(runtime: uz.toybola.factory.core.firebase.SyncRuntimeState, pending: Int, onClick: () -> Unit) {
    val attention = runtime.needsAttention
    val warning = runtime.waitingForNetwork || runtime.retryingAfterFailure
    val label = when {
        runtime.syncing -> "Sinxronlanmoqda"
        runtime.waitingForNetwork -> if (pending > 0) "Internet yo‘q • $pending ta navbatda" else "Internet yo‘q"
        attention -> "E’tibor kerak"
        runtime.retryingAfterFailure -> "Server bilan aloqa yo‘q • qayta urinmoqda"
        pending > 0 -> "$pending ta navbatda"
        else -> "Sinxronlangan"
    }
    val tint = when {
        attention -> MaterialTheme.colorScheme.error
        warning -> Color(0xFF9A6200)
        else -> MaterialTheme.colorScheme.primary
    }
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(999.dp),
        color = when {
            attention -> MaterialTheme.colorScheme.errorContainer
            warning -> Color(0xFFFFF1D6)
            else -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = .55f)
        },
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        tonalElevation = 0.dp
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Rounded.Sync, contentDescription = null, tint = tint, modifier = Modifier.size(17.dp))
            Text(label, color = tint, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun HomeSectionHeader(title: String, action: String? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 18.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.weight(1f))
        if (!action.isNullOrBlank()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(action, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(3.dp))
                Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun HomeModuleGrid(
    specs: List<FactoryModuleSpec>,
    copies: Map<String, HomeCopy>,
    statuses: Map<String, HomeModuleStatus>,
    policy: UserAccessPolicy,
    onOpen: (AppScreen) -> Unit,
    onUnlaunched: () -> Unit
) {
    val visible = specs.filter { ModuleRegistry.visible(it, policy) }
    visible.chunked(2).forEachIndexed { rowIndex, row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            row.forEach { spec ->
                val copy = copies.getValue(spec.key)
                val status = statuses[spec.key] ?: HomeModuleStatus()
                val enabled = ModuleRegistry.canOpen(spec, policy)
                HomeModuleCard(
                    spec = spec,
                    title = copy.title,
                    description = if (!spec.launched) "${copy.description} • Tez orada" else copy.description,
                    status = status,
                    enabled = enabled,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        when {
                            enabled -> spec.route?.let(onOpen)
                            !spec.launched -> onUnlaunched()
                        }
                    }
                )
            }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
        if (rowIndex < visible.chunked(2).lastIndex) Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun HomeModuleCard(
    spec: FactoryModuleSpec,
    title: String,
    description: String,
    status: HomeModuleStatus,
    enabled: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val accent = if (enabled) spec.accent else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.42f)
    val bg = if (enabled) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.70f)
    Surface(
        modifier = modifier.height(96.dp).clickable(enabled = enabled || !spec.launched, onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = bg,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shadowElevation = if (enabled) 1.dp else 0.dp
    ) {
        Row(Modifier.fillMaxSize()) {
            Box(Modifier.width(4.dp).fillMaxHeight().background(accent))
            Row(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = accent.copy(alpha = 0.12f), modifier = Modifier.size(42.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(spec.icon, contentDescription = null, tint = accent, modifier = Modifier.size(24.dp))
                    }
                }
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(title, fontSize = 13.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold, color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        if (status.badge > 0 && enabled) {
                            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.error) {
                                Text(status.badge.coerceAtMost(99).toString(), color = MaterialTheme.colorScheme.onError, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp))
                            }
                        }
                    }
                    Spacer(Modifier.height(3.dp))
                    Text(description, fontSize = 11.sp, lineHeight = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (status.warning.isNotBlank()) {
                        Text(status.warning, fontSize = 10.sp, color = MaterialTheme.colorScheme.error, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            }
        }
    }
}

private fun formatUzbekDate(date: LocalDate): String {
    val months = listOf("yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr")
    return "${date.dayOfMonth} ${months[date.monthValue - 1]}, ${date.year}"
}

private fun uzbekWeekday(date: LocalDate): String = when (date.dayOfWeek.value) {
    1 -> "Dushanba"
    2 -> "Seshanba"
    3 -> "Chorshanba"
    4 -> "Payshanba"
    5 -> "Juma"
    6 -> "Shanba"
    else -> "Yakshanba"
}

@Composable
fun ManagementMonitoringScreen(
    strings: AppStrings,
    onBack: () -> Unit,
    canOpen: (AppScreen) -> Boolean,
    onOpen: (AppScreen) -> Unit
) {
    val items = listOf(
        Triple("TP va Seryo", "Partiya, stanok, brigada, sifat va xomashyo", AppScreen.TP_MONITORING),
        Triple("Sborka", "Ishchi, brigada, sifat va foydalilik", AppScreen.MONITORING)
    )
    Column(Modifier.fillMaxSize()) {
        AppTopBar("Umumiy monitoring", canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items.forEachIndexed { index, item ->
                SectionCard(
                    number = index + 1,
                    title = item.first,
                    description = item.second,
                    enabled = canOpen(item.third),
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { if (canOpen(item.third)) onOpen(item.third) }
                )
            }
        }
    }
}
