package uz.toybola.factory.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppLanguage
import uz.toybola.factory.ui.model.AppSettings
import uz.toybola.factory.ui.model.AppStrings
import uz.toybola.factory.ui.model.AppThemePreset
import uz.toybola.factory.ui.model.SelectableThemePresets
import uz.toybola.factory.ui.model.normalized

@Composable
fun SettingsScreen(
    strings: AppStrings,
    settings: AppSettings,
    onSettingsChange: (AppSettings) -> Unit,
    showUserManagement: Boolean,
    onUserManagement: () -> Unit,
    onBackupRestore: () -> Unit,
    onLock: () -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        AppTopBar(title = strings.menu, subtitle = "Dastur va kirish sozlamalari", canGoBack = true, onMenu = {}, onBack = onBack)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (showUserManagement) {
                SettingsRow(strings.userManagement) { TextButton(onClick = onUserManagement) { Text(strings.manage) } }
            }
            SettingsRow(strings.backupRestore) { TextButton(onClick = onBackupRestore) { Text(strings.open) } }
            SettingsRow(strings.theme) {
                var open by remember { mutableStateOf(false) }
                TextButton(onClick = { open = true }) { Text(settings.themePreset.displayName(strings)) }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    SelectableThemePresets.forEach { preset ->
                        DropdownMenuItem(text = { Text(preset.displayName(strings)) }, onClick = {
                            open = false
                            onSettingsChange(settings.copy(themePreset = preset, darkMode = preset == AppThemePreset.DARK_CALM))
                        })
                    }
                }
            }
            SettingsRow(strings.languageTitle) {
                var open by remember { mutableStateOf(false) }
                TextButton(onClick = { open = true }) { Text(settings.language.displayName()) }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    AppLanguage.entries.forEach { language ->
                        DropdownMenuItem(text = { Text(language.displayName()) }, onClick = {
                            open = false
                            onSettingsChange(settings.copy(language = language))
                        })
                    }
                }
            }
            SettingsRow(strings.autoLock) {
                var open by remember { mutableStateOf(false) }
                TextButton(onClick = { open = true }) { Text("${settings.autoLockMinutes} ${strings.minutes}") }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    listOf(1, 3, 5, 10, 30).forEach { minute ->
                        DropdownMenuItem(text = { Text("$minute ${strings.minutes}") }, onClick = {
                            open = false
                            onSettingsChange(settings.copy(autoLockMinutes = minute))
                        })
                    }
                }
            }
            SettingsRow(strings.drawerScale) {
                var open by remember { mutableStateOf(false) }
                val label = when (settings.uiScalePercent) { 90 -> "Ixcham"; 110 -> "Katta"; else -> "Standart" }
                TextButton(onClick = { open = true }) { Text(label) }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    listOf(90 to "Ixcham", 100 to "Standart", 110 to "Katta").forEach { (percent, name) ->
                        DropdownMenuItem(text = { Text(name) }, onClick = {
                            open = false
                            onSettingsChange(settings.copy(uiScalePercent = percent))
                        })
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onLock, modifier = Modifier.fillMaxWidth().height(54.dp)) { Text(strings.logout) }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun SettingsRow(title: String, content: @Composable () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        shadowElevation = 1.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

private fun AppLanguage.displayName(): String = when (this) {
    AppLanguage.UZ -> "O‘zbekcha"
    AppLanguage.RU -> "Русский"
    AppLanguage.EN -> "English"
}

private fun AppThemePreset.displayName(strings: AppStrings): String = when (normalized(false)) {
    AppThemePreset.SYSTEM -> strings.systemTheme
    AppThemePreset.LIGHT_CALM -> strings.lightCalmTheme
    AppThemePreset.SOFT_BLUE -> strings.softBlueTheme
    AppThemePreset.DARK_CALM -> strings.darkCalmTheme
    else -> strings.lightCalmTheme
}
