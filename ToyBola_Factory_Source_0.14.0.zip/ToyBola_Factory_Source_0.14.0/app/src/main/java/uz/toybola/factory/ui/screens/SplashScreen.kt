package uz.toybola.factory.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import uz.toybola.factory.R

/**
 * V-002 approved single splash.
 *
 * The image is the frozen visual reference. There is deliberately no timer or artificial wait:
 * once Compose has presented one frame, navigation continues immediately.
 */
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    LaunchedEffect(Unit) {
        withFrameNanos { }
        onFinished()
    }

    Image(
        painter = painterResource(R.drawable.splash_full),
        contentDescription = null,
        modifier = Modifier.fillMaxSize(),
        contentScale = ContentScale.Crop
    )
}
