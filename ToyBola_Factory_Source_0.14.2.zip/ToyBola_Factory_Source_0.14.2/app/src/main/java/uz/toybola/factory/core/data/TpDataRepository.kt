package uz.toybola.factory.core.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import uz.toybola.factory.core.firebase.FirebaseSyncScheduler
import uz.toybola.factory.core.firebase.TpAccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.firebase.TpSyncOutbox
import uz.toybola.factory.core.local.AppSnapshotEntity
import uz.toybola.factory.core.local.ToyBolaRoomStore
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.Locale
import java.util.UUID
import kotlin.math.round

class TpDataRepository(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val accessGuard = TpAccessGuard(appContext)
    private val outbox = TpSyncOutbox(appContext)

    fun load(): TpData = synchronized(RepositoryLock.monitor) {
        val dao = ToyBolaRoomStore.dao(appContext)
        val roomRaw = runCatching { dao.get(ToyBolaRoomStore.TP_KEY)?.payload }.getOrNull()
        val legacyRaw = prefs.getString(KEY_DATA, null)
        val raw = roomRaw ?: legacyRaw
        if (raw == null) return@synchronized defaultData().also(::saveLocal)
        val decoded = runCatching { decode(JSONObject(raw)) }.getOrElse { defaultData() }
        if (roomRaw == null) saveLocal(decoded) // one-time SharedPreferences → Room migration
        return@synchronized decoded
    }

    fun addShop(name: String): Result<Unit> = mutate { data ->
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Sex nomini kiriting" }
        require(data.shops.none { !it.archived && it.name.equals(clean, true) }) { "Bunday sex mavjud" }
        data.copy(shops = data.shops + TpShop(UUID.randomUUID().toString(), clean))
            .audit("TP_SHOP_ADD", details = clean)
    }

    fun updateShift(id: String, name: String, startTime: String, endTime: String, roundTimes: List<String>): Result<Unit> = mutate { data ->
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Smena nomini kiriting" }
        LocalTime.parse(startTime)
        LocalTime.parse(endTime)
        require(roundTimes.isNotEmpty()) { "Kamida bitta sifat raundi bo‘lsin" }
        roundTimes.forEach(LocalTime::parse)
        val updated = data.shifts.map { if (it.id == id) it.copy(name = clean, startTime = startTime, endTime = endTime, roundTimes = roundTimes) else it }
        require(updated.any { it.id == id }) { "Smena topilmadi" }
        data.copy(shifts = updated).audit("TP_SHIFT_UPDATE", details = "$clean $startTime–$endTime / ${roundTimes.joinToString()}")
    }

    fun addBrigade(shopId: String, shiftId: String, name: String): Result<Unit> = mutate { data ->
        require(data.shops.any { it.id == shopId && !it.archived }) { "Sexni tanlang" }
        require(data.shifts.any { it.id == shiftId && !it.archived }) { "Smenani tanlang" }
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Brigada nomini kiriting" }
        val brigade = TpBrigade(UUID.randomUUID().toString(), shopId, shiftId, clean)
        data.copy(brigades = data.brigades + brigade).audit("TP_BRIGADE_ADD", brigade.id, details = clean)
    }

    fun updateBrigade(id: String, shopId: String, shiftId: String, name: String): Result<Unit> = mutate { data ->
        require(data.shops.any { it.id == shopId && !it.archived }) { "Sexni tanlang" }
        require(data.shifts.any { it.id == shiftId && !it.archived }) { "Smenani tanlang" }
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Brigada nomini kiriting" }
        require(data.brigades.any { it.id == id }) { "Brigada topilmadi" }
        data.copy(brigades = data.brigades.map { if (it.id == id) it.copy(shopId = shopId, shiftId = shiftId, name = clean) else it })
            .audit("TP_BRIGADE_UPDATE", id, details = clean)
    }

    fun addMachine(shopId: String, number: Int, name: String, capacity: Int): Result<Unit> = mutate { data ->
        require(data.shops.any { it.id == shopId && !it.archived }) { "Sexni tanlang" }
        require(number > 0) { "Stanok raqami 0 dan katta bo‘lsin" }
        require(capacity > 0) { "Stanok sig‘imini kiriting" }
        require(data.machines.none { !it.archived && it.number == number }) { "Bu stanok raqami mavjud" }
        val machine = TpMachine(UUID.randomUUID().toString(), shopId, number, name.cleanText(), capacity = capacity)
        data.copy(machines = data.machines + machine).audit("TP_MACHINE_ADD", details = "$number / sig‘im $capacity")
    }

    fun updateMachine(id: String, shopId: String, number: Int, name: String, capacity: Int): Result<Unit> = mutate { data ->
        require(data.shops.any { it.id == shopId && !it.archived }) { "Sexni tanlang" }
        require(number > 0) { "Stanok raqami 0 dan katta bo‘lsin" }
        require(capacity > 0) { "Stanok sig‘imini kiriting" }
        require(data.machines.none { it.id != id && !it.archived && it.number == number }) { "Bu stanok raqami mavjud" }
        require(data.machines.any { it.id == id }) { "Stanok topilmadi" }
        data.copy(machines = data.machines.map { if (it.id == id) it.copy(shopId = shopId, number = number, name = name.cleanText(), capacity = capacity) else it })
            .audit("TP_MACHINE_UPDATE", details = "$number / sig‘im $capacity")
    }

    fun addWorker(brigadeId: String, name: String): Result<Unit> = mutate { data ->
        require(data.brigades.any { it.id == brigadeId && !it.archived }) { "Brigadani tanlang" }
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Ishchi ismini kiriting" }
        val worker = TpWorker(UUID.randomUUID().toString(), brigadeId, clean, 0L)
        data.copy(workers = data.workers + worker).audit("TP_WORKER_ADD", brigadeId, details = clean)
    }

    fun updateWorker(id: String, brigadeId: String, name: String): Result<Unit> = mutate { data ->
        require(data.brigades.any { it.id == brigadeId && !it.archived }) { "Brigadani tanlang" }
        val clean = name.cleanText()
        require(clean.isNotBlank()) { "Ishchi ismini kiriting" }
        require(data.workers.any { it.id == id }) { "Ishchi topilmadi" }
        data.copy(workers = data.workers.map {
            if (it.id == id) it.copy(brigadeId = brigadeId, name = clean, dailyTargetAmount = 0L) else it
        }).audit("TP_WORKER_UPDATE", brigadeId, details = clean)
    }

    fun updateDailyTargetAmount(value: Long): Result<Unit> = mutate { data ->
        require(value > 0L) { "Kunlik norma 0 dan katta bo‘lsin" }
        data.copy(settings = data.settings.copy(dailyTargetAmount = value))
            .audit("TP_DAILY_TARGET_UPDATE", details = "$value so‘m")
    }

    fun saveExtraHourType(id: String?, name: String, hourlyRate: Double): Result<Unit> = mutate { data ->
        val cleanName = name.cleanText()
        require(cleanName.isNotBlank()) { "Qo‘shimcha soat turini kiriting" }
        require(hourlyRate.isFinite() && hourlyRate > 0.0) { "Qo‘shimcha soat narxi 0 dan katta bo‘lsin" }
        val cleanId = id?.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
        require(data.extraHourTypes.none { !it.archived && it.id != cleanId && it.name.equals(cleanName, true) }) { "Bunday qo‘shimcha soat turi mavjud" }
        val row = TpExtraHourType(cleanId, cleanName, hourlyRate, false)
        data.copy(extraHourTypes = data.extraHourTypes.filterNot { it.id == cleanId } + row)
            .audit(if (id.isNullOrBlank()) "TP_EXTRA_HOUR_TYPE_ADD" else "TP_EXTRA_HOUR_TYPE_UPDATE", details = "$cleanName = ${formatTpNumber(hourlyRate)} so‘m/soat")
    }

    fun archiveExtraHourType(id: String): Result<Unit> = mutate { data ->
        val row = data.extraHourTypes.firstOrNull { it.id == id } ?: error("Qo‘shimcha soat turi topilmadi")
        data.copy(extraHourTypes = data.extraHourTypes.map { if (it.id == id) it.copy(archived = true) else it })
            .audit("TP_EXTRA_HOUR_TYPE_ARCHIVE", details = row.name)
    }

    fun addWorkerExtraHour(workerId: String, date: String, typeId: String, hours: Double, note: String = ""): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val worker = data.workers.firstOrNull { it.id == workerId && !it.archived } ?: error("Ishchi topilmadi")
        val type = data.extraHourTypes.firstOrNull { it.id == typeId && !it.archived } ?: error("Qo‘shimcha soat turini tanlang")
        require(hours.isFinite() && hours > 0.0 && hours <= 24.0) { "Qo‘shimcha soat 0 dan katta va 24 soatdan oshmasin" }
        val row = TpWorkerExtraHour(
            UUID.randomUUID().toString(), worker.id, worker.brigadeId, date, type.id, type.name,
            hours, type.hourlyRate, note.cleanText(), LocalDateTime.now().toString()
        )
        data.copy(extraHours = data.extraHours + row)
            .audit("TP_EXTRA_HOUR_ADD", worker.brigadeId, date, "${worker.name}: ${formatTpNumber(hours)} soat ${type.name} = ${row.amount} so‘m")
    }

    fun deleteWorkerExtraHour(id: String): Result<Unit> = mutate { data ->
        val row = data.extraHours.firstOrNull { it.id == id } ?: error("Qo‘shimcha soat yozuvi topilmadi")
        data.copy(extraHours = data.extraHours.filterNot { it.id == id })
            .audit("TP_EXTRA_HOUR_DELETE", row.brigadeId, row.date, "${row.typeNameSnapshot}: ${formatTpNumber(row.hours)} soat")
    }

    fun addMachineDowntime(
        machineId: String, brigadeId: String, date: String, stoppedAt: String, startedAt: String, reason: String
    ): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val start = LocalTime.parse(stoppedAt)
        val end = LocalTime.parse(startedAt)
        val cleanReason = reason.cleanText()
        require(cleanReason.isNotBlank()) { "Stanok o‘chish sababini yozish majburiy" }
        val machine = data.machines.firstOrNull { it.id == machineId && !it.archived } ?: error("Stanok topilmadi")
        val brigade = data.brigades.firstOrNull { it.id == brigadeId && !it.archived } ?: error("Brigada topilmadi")
        require(machine.shopId == brigade.shopId) { "Stanok va brigada bir sexda bo‘lsin" }
        require(start != end) { "O‘chgan va yongan vaqt bir xil bo‘lishi mumkin emas" }
        val row = TpMachineDowntime(
            UUID.randomUUID().toString(), machineId, brigadeId, date,
            start.toString(), end.toString(), cleanReason, LocalDateTime.now().toString()
        )
        require(row.durationMinutes() in 1 until (24 * 60)) { "O‘chgan va yongan vaqt oralig‘ini to‘g‘ri kiriting" }
        data.copy(machineDowntimes = data.machineDowntimes + row)
            .audit("TP_MACHINE_DOWNTIME", brigadeId, date, "Stanok ${machine.number}: ${row.stoppedAt}–${row.startedAt}, ${row.durationMinutes()} daq; $cleanReason")
    }

    fun addProduct(article: String, name: String): Result<Unit> = mutate { data ->
        val code = article.trim().uppercase(Locale.ROOT)
        val clean = name.cleanText()
        require(code.isNotBlank() && clean.isNotBlank()) { "Artikul va mahsulot nomini kiriting" }
        require(data.products.none { !it.archived && it.article.equals(code, true) }) { "Bu artikul mavjud" }
        data.copy(products = data.products + TpProduct(UUID.randomUUID().toString(), code, clean))
            .audit("TP_PRODUCT_ADD", details = "$code $clean")
    }

    fun updateProduct(id: String, article: String, name: String): Result<Unit> = mutate { data ->
        val code = article.trim().uppercase(Locale.ROOT)
        val clean = name.cleanText()
        require(code.isNotBlank() && clean.isNotBlank()) { "Artikul va mahsulot nomini kiriting" }
        require(data.products.none { it.id != id && !it.archived && it.article.equals(code, true) }) { "Bu artikul mavjud" }
        require(data.products.any { it.id == id }) { "Mahsulot topilmadi" }
        data.copy(products = data.products.map { if (it.id == id) it.copy(article = code, name = clean) else it })
            .audit("TP_PRODUCT_UPDATE", details = "$code $clean")
    }

    fun saveDetail(productId: String, detail: TpDetail): Result<Unit> = mutate { data ->
        validateDetail(data, detail)
        val product = data.products.firstOrNull { it.id == productId } ?: error("Mahsulot topilmadi")
        val resins = detail.resinOptions()
        val clean = detail.copy(
            name = detail.name.cleanText(),
            moldCode = detail.moldCode.trim().ifBlank { detail.name.cleanText() }.uppercase(Locale.ROOT),
            resinCode = resins.first(),
            resinCodes = resins,
            recycledCodes = detail.recycledOptions(),
            compatibleMachineIds = emptySet(),
            colors = detail.colors.map { it.copy(colorCode = it.colorCode.trim().uppercase(Locale.ROOT)) }
        )
        val details = if (product.details.any { it.id == clean.id }) {
            product.details.map { if (it.id == clean.id) clean else it }
        } else product.details + clean
        data.copy(products = data.products.map { if (it.id == productId) it.copy(details = details) else it })
            .audit("TP_DETAIL_SAVE", details = "${product.article} / ${clean.name}")
    }

    fun validateImportPayload(payload: TpExcelImportPayload): List<String> {
        val data = load()
        val errors = mutableListOf<String>()
        val shopNames = data.shops.filterNot { it.archived }.associateBy { it.name.trim().lowercase(Locale.ROOT) }
        val shiftNames = data.shifts.filterNot { it.archived }.associateBy { it.name.trim().lowercase(Locale.ROOT) }
        payload.brigades.forEachIndexed { index, row ->
            if (shopNames[row.shopName.trim().lowercase(Locale.ROOT)] == null) errors += "Brigadalar ${index + 2}-qator: '${row.shopName}' sex topilmadi"
            if (shiftNames[row.shiftName.trim().lowercase(Locale.ROOT)] == null) errors += "Brigadalar ${index + 2}-qator: '${row.shiftName}' smena topilmadi"
        }
        payload.machines.forEachIndexed { index, row ->
            if (shopNames[row.shopName.trim().lowercase(Locale.ROOT)] == null) errors += "Stanoklar ${index + 2}-qator: '${row.shopName}' sex topilmadi"
        }
        val brigadeNames = (data.brigades.filterNot { it.archived }.map { it.name } + payload.brigades.map { it.name })
            .map { it.trim().lowercase(Locale.ROOT) }.toSet()
        payload.workers.forEachIndexed { index, row ->
            if (row.brigadeName.trim().lowercase(Locale.ROOT) !in brigadeNames) errors += "Ishchilar ${index + 2}-qator: '${row.brigadeName}' brigada topilmadi"
        }
        // `Materiallar` is optional for TP-only imports. If a workbook explicitly carries
        // material master-data, keep strict cross-checks; otherwise import TP data independently.
        if (payload.materials.isNotEmpty()) {
            val materialKeys = (data.materials.filterNot { it.archived }.map { it.type to it.code.trim().uppercase(Locale.ROOT) } +
                payload.materials.map { it.type to it.code.trim().uppercase(Locale.ROOT) }).toSet()
            payload.details.forEachIndexed { index, row ->
                row.resinCodes.forEach { code ->
                    if ((TpMaterialType.RESIN to code.trim().uppercase(Locale.ROOT)) !in materialKeys) {
                        errors += "Mahsulotlar ${index + 2}-qator: seryo '$code' Materiallar varag‘ida topilmadi"
                    }
                }
                row.recycledCodes.filterNot { it == TP_ANY_RECYCLED_CODE }.forEach { code ->
                    if ((TpMaterialType.RECYCLED to code.trim().uppercase(Locale.ROOT)) !in materialKeys) {
                        errors += "Mahsulotlar ${index + 2}-qator: ftarichka '$code' Materiallar varag‘ida topilmadi"
                    }
                }
            }
            payload.colors.forEachIndexed { index, row ->
                val code = row.colorCode.trim().uppercase(Locale.ROOT)
                if ((TpMaterialType.COLOR to code) !in materialKeys) errors += "Ranglar ${index + 2}-qator: krasitel '$code' Materiallar varag‘ida topilmadi"
            }
        }
        return errors.distinct()
    }

    fun importProductWorkbook(payload: TpExcelImportPayload): Result<Unit> = mutate { data ->
        require(payload.details.isNotEmpty()) { "Import uchun mahsulot/detal topilmadi" }
        val validationErrors = validateImportPayload(payload)
        require(validationErrors.isEmpty()) { validationErrors.joinToString("\n") }

        val colorsByDetail = payload.colors.groupBy {
            it.article.trim().uppercase(Locale.ROOT) + "|" + it.detailName.trim().lowercase(Locale.ROOT)
        }
        var products = data.products
        payload.details.groupBy { it.article.trim().uppercase(Locale.ROOT) }.forEach { (article, rows) ->
            val productName = rows.first().productName.cleanText()
            val existingProduct = products.firstOrNull { it.article.equals(article, true) }
            val productId = existingProduct?.id ?: UUID.randomUUID().toString()
            var details = existingProduct?.details.orEmpty()

            rows.forEach { row ->
                val existingDetail = details.firstOrNull { it.name.equals(row.detailName, true) }
                val colors = colorsByDetail[article + "|" + row.detailName.trim().lowercase(Locale.ROOT)].orEmpty().map {
                    TpColorRule(it.colorCode.trim().uppercase(Locale.ROOT), it.share, it.gramsPer25Kg)
                }
                val detailId = existingDetail?.id ?: UUID.randomUUID().toString()
                val detail = TpDetail(
                    id = detailId,
                    name = row.detailName.cleanText(),
                    moldCode = existingDetail?.moldCode?.takeIf { it.isNotBlank() }
                        ?: row.detailName.cleanText().uppercase(Locale.ROOT),
                    requiredPerProduct = row.requiredPerProduct,
                    piecesPerShot = row.piecesPerShot,
                    bagCapacity = row.bagCapacity,
                    cycleSeconds = row.cycleSeconds,
                    grossShotWeightGrams = row.grossShotWeightGrams,
                    unusableShotWeightGrams = row.unusableShotWeightGrams,
                    resinCode = row.resinCodes.first(),
                    unitPrice = row.unitPrice,
                    compatibleMachineIds = emptySet(),
                    compatibleCapacities = row.compatibleCapacities,
                    colors = colors,
                    archived = false,
                    resinCodes = row.resinCodes,
                    recycledCodes = row.recycledCodes
                )
                validateDetail(data, detail)
                details = if (existingDetail == null) details + detail
                else details.map { if (it.id == existingDetail.id) detail else it }
            }

            val product = TpProduct(productId, article, productName, details, archived = false)
            products = if (existingProduct == null) products + product
            else products.map { if (it.id == existingProduct.id) product else it }
        }

        var brigades = data.brigades
        val shopsByName = data.shops.filterNot { it.archived }.associateBy { it.name.trim().lowercase(Locale.ROOT) }
        val shiftsByName = data.shifts.filterNot { it.archived }.associateBy { it.name.trim().lowercase(Locale.ROOT) }
        payload.brigades.forEach { row ->
            val shop = shopsByName.getValue(row.shopName.trim().lowercase(Locale.ROOT))
            val shift = shiftsByName.getValue(row.shiftName.trim().lowercase(Locale.ROOT))
            val existing = brigades.firstOrNull { it.name.equals(row.name, true) }
            val item = existing?.copy(shopId = shop.id, shiftId = shift.id, name = row.name.cleanText(), archived = false)
                ?: TpBrigade(UUID.randomUUID().toString(), shop.id, shift.id, row.name.cleanText())
            brigades = if (existing == null) brigades + item else brigades.map { if (it.id == existing.id) item else it }
        }

        var machines = data.machines
        payload.machines.forEach { row ->
            val shop = shopsByName.getValue(row.shopName.trim().lowercase(Locale.ROOT))
            val existing = machines.firstOrNull { it.number == row.number }
            val item = existing?.copy(shopId = shop.id, number = row.number, name = row.name.cleanText(), capacity = row.capacity, archived = false)
                ?: TpMachine(UUID.randomUUID().toString(), shop.id, row.number, row.name.cleanText(), capacity = row.capacity)
            machines = if (existing == null) machines + item else machines.map { if (it.id == existing.id) item else it }
        }

        var workers = data.workers
        val brigadesByName = brigades.filterNot { it.archived }.associateBy { it.name.trim().lowercase(Locale.ROOT) }
        payload.workers.forEach { row ->
            val brigade = brigadesByName.getValue(row.brigadeName.trim().lowercase(Locale.ROOT))
            val existing = workers.firstOrNull { it.brigadeId == brigade.id && it.name.equals(row.name, true) }
            val item = existing?.copy(name = row.name.cleanText(), dailyTargetAmount = 0L, archived = false)
                ?: TpWorker(UUID.randomUUID().toString(), brigade.id, row.name.cleanText(), 0L)
            workers = if (existing == null) workers + item else workers.map { if (it.id == existing.id) item else it }
        }

        var materials = data.materials
        payload.materials.forEach { row ->
            val code = row.code.trim().uppercase(Locale.ROOT)
            val existing = materials.firstOrNull { it.type == row.type && it.code.equals(code, true) }
            val item = if (existing == null) {
                TpMaterial(UUID.randomUUID().toString(), code, row.name.cleanText().ifBlank { code }, row.type, row.openingAmount, archived = false)
            } else {
                // Import updates master data/opening balance; transaction history is never discarded.
                existing.copy(code = code, name = row.name.cleanText().ifBlank { code }, availableAmount = row.openingAmount, archived = false)
            }
            materials = if (existing == null) materials + item else materials.map { if (it.id == existing.id) item else it }
        }

        data.copy(products = products, brigades = brigades, machines = machines, workers = workers, materials = materials).audit(
            "TP_EXCEL_IMPORT",
            details = "${payload.productCount} mahsulot / ${payload.detailCount} detal / ${payload.colorCount} rang / ${payload.materialCount} material / ${payload.brigadeCount} brigada / ${payload.machineCount} stanok / ${payload.workerCount} ishchi"
        )
    }

    fun deleteProduct(id: String): Result<Unit> = mutate { data ->
        val product = data.products.firstOrNull { it.id == id && !it.archived } ?: error("Mahsulot topilmadi")
        val hasActiveOrder = data.orders.any { it.productId == id && it.status != TpOrderStatus.COMPLETE && it.status != TpOrderStatus.CANCELLED }
        require(!hasActiveOrder) { "Bu mahsulot bo‘yicha faol zakaz bor. Avval zakazni yakunlang yoki bekor qiling." }
        data.copy(products = data.products.map { if (it.id == id) it.copy(archived = true) else it })
            .audit("TP_PRODUCT_ARCHIVE", details = "${product.article} ${product.name}")
    }

    fun deleteMachine(id: String): Result<Unit> = mutate { data ->
        val machine = data.machines.firstOrNull { it.id == id && !it.archived } ?: error("Stanok topilmadi")
        val activeJob = data.jobs.any { it.machineId == id && it.status != TpJobStatus.COMPLETE }
        require(!activeJob) { "Bu stanokda faol vazifa bor. Avval vazifani yakunlang yoki boshqa stanokka o‘tkazing." }
        data.copy(machines = data.machines.map { if (it.id == id) it.copy(archived = true) else it })
            .audit("TP_MACHINE_ARCHIVE", details = "${machine.number}-stanok")
    }

    fun archiveDetail(productId: String, detailId: String, archived: Boolean): Result<Unit> = mutate { data ->
        val product = data.products.firstOrNull { it.id == productId } ?: error("Mahsulot topilmadi")
        require(product.details.any { it.id == detailId }) { "Detal topilmadi" }
        data.copy(products = data.products.map { item ->
            if (item.id == productId) item.copy(details = item.details.map { if (it.id == detailId) it.copy(archived = archived) else it }) else item
        }).audit("TP_DETAIL_ARCHIVE", details = "$detailId=$archived")
    }

    fun setMaterial(code: String, name: String, type: TpMaterialType, availableAmount: Double): Result<Unit> = mutate { data ->
        val normalized = code.trim().uppercase(Locale.ROOT)
        require(normalized.isNotBlank() && name.cleanText().isNotBlank()) { "Kod va nomni kiriting" }
        require(availableAmount >= 0.0 && availableAmount.isFinite()) { "Qoldiq noto‘g‘ri" }
        val current = data.materials.firstOrNull { it.code.equals(normalized, true) && it.type == type }
        val item = current?.copy(name = name.cleanText(), availableAmount = availableAmount)
            ?: TpMaterial(UUID.randomUUID().toString(), normalized, name.cleanText(), type, availableAmount)
        val materials = if (current == null) data.materials + item else data.materials.map { if (it.id == current.id) item else it }
        data.copy(materials = materials).audit("TP_MATERIAL_SAVE", details = "$normalized ${formatTpNumber(availableAmount)}")
    }

    fun addMaterialMovement(
        code: String,
        type: TpMaterialType,
        amount: Double,
        incoming: Boolean,
        note: String = ""
    ): Result<Unit> = mutate { data ->
        val normalized = code.trim().uppercase(Locale.ROOT)
        require(normalized.isNotBlank()) { "Material kodini kiriting" }
        val normalizedAmount = if (type == TpMaterialType.COLOR) amount else normalizeFeedstockKg(amount)
        require(normalizedAmount > 0.0 && normalizedAmount.isFinite()) { "Miqdorni to‘g‘ri kiriting" }
        val existing = data.materials.firstOrNull { !it.archived && it.code.equals(normalized, true) && it.type == type }
        if (!incoming) {
            require(existing != null) { "Bu kod bo‘yicha qoldiq topilmadi" }
            require(existing.currentStock() + 1e-9 >= normalizedAmount) {
                "Ostatka yetarli emas: ${formatTpNumber(existing.currentStock())}"
            }
        }
        val movement = TpMaterialMovement(
            id = UUID.randomUUID().toString(),
            kind = if (incoming) TpMaterialMovementKind.IN else TpMaterialMovementKind.OUT,
            amount = normalizedAmount,
            createdAt = LocalDateTime.now().toString(),
            note = note.cleanText(), sourceKind = TpMaterialSourceKind.MANUAL,
            createdBy = uz.toybola.factory.core.preferences.AppPreferences(appContext).setup()?.userCode.orEmpty()
        )
        val material = existing?.copy(movements = existing.movements + movement)
            ?: TpMaterial(
                id = UUID.randomUUID().toString(), code = normalized, name = normalized, type = type,
                availableAmount = 0.0, movements = listOf(movement)
            )
        val materials = if (existing == null) data.materials + material
        else data.materials.map { if (it.id == existing.id) material else it }
        data.copy(materials = materials).audit(
            if (incoming) "TP_MATERIAL_IN" else "TP_MATERIAL_OUT",
            recordDate = movement.createdAt.take(10),
            details = "$normalized ${formatTpNumber(normalizedAmount)} ${type.unitLabel()}${movement.note.takeIf { it.isNotBlank() }?.let { ": $it" }.orEmpty()}"
        )
    }

    fun increaseAllDetailPrices(percent: Double): Result<Unit> = mutate { data ->
        require(percent.isFinite() && percent > -100.0 && percent <= 1000.0) { "Foizni to‘g‘ri kiriting" }
        val factor = 1.0 + percent / 100.0
        val products = data.products.map { product ->
            product.copy(details = product.details.map { detail ->
                detail.copy(unitPrice = (round(detail.unitPrice * factor * 100.0) / 100.0).coerceAtLeast(0.0))
            })
        }
        data.copy(products = products, settings = data.settings.copy(priceRevision = data.settings.priceRevision + 1))
            .audit("TP_PRICE_BULK", details = "$percent%")
    }

    fun createOrder(
        firstBatchNumber: String,
        productId: String,
        quantity: Int,
        priority: Int,
        note: String
    ): Result<Unit> = mutate { data ->
        val product = data.products.firstOrNull { it.id == productId && !it.archived } ?: error("Mahsulotni tanlang")
        require(quantity > 0) { "Zakaz soni 0 dan katta bo‘lsin" }
        require(priority in 1..3) { "Ustuvorlikni tanlang" }
        val productOrders = data.orders.filter { it.productId == product.id }
        val requestedBatch = firstBatchNumber.trim()
        val batch = when {
            productOrders.isEmpty() -> requestedBatch.also { require(it.isNotBlank()) { "Bu mahsulot uchun birinchi partiya raqamini kiriting" } }
            requestedBatch.isNotBlank() -> requestedBatch
            else -> nextBatchNumberForProduct(productOrders.map { it.batchNumber })
        }
        require(productOrders.none { it.batchNumber.equals(batch, true) }) {
            "Bu mahsulotda $batch-partiya allaqachon mavjud"
        }
        val now = LocalDateTime.now().toString()
        val orderDate = now.take(10)
        val order = TpOrder(
            id = UUID.randomUUID().toString(), batchNumber = batch, productId = product.id,
            articleSnapshot = product.article, productNameSnapshot = product.name, quantity = quantity,
            priority = priority, requestedDate = orderDate, note = note.cleanText(),
            status = TpOrderStatus.NEW, createdAt = now
        )
        data.copy(orders = data.orders + order, settings = data.settings.copy(firstBatchEntered = true))
            .audit("TP_ORDER_ADD", recordDate = orderDate, details = "$batch ${product.article} × $quantity / ${tpPriorityLabel(priority)}")
    }

    fun updateOrder(orderId: String, productId: String, quantity: Int, priority: Int, note: String): Result<Unit> = mutate { data ->
        val old = data.orders.firstOrNull { it.id == orderId } ?: error("Zakaz topilmadi")
        val product = data.products.firstOrNull { it.id == productId && !it.archived } ?: error("Mahsulotni tanlang")
        require(quantity > 0) { "Zakaz soni 0 dan katta bo‘lsin" }
        require(priority in 1..3) { "Ustuvorlikni tanlang" }
        val orderJobs = data.jobs.filter { it.orderId == orderId }
        val hasStartedWork = data.receipts.any { !it.isCancelled && it.orderId == orderId } || orderJobs.any {
            it.status == TpJobStatus.IN_PROGRESS || it.status == TpJobStatus.COMPLETE || it.materialStatus != TpMaterialStatus.PLANNED
        }
        val structureChanged = old.productId != productId || old.quantity != quantity
        require(!structureChanged || (old.planApprovedAt == null && !hasStartedWork)) {
            "Jarayonga topshirilgan yoki quyish boshlangan zakazda mahsulot/miqdorni o‘zgartirib bo‘lmaydi. Ustuvorlik va izohni o‘zgartiring."
        }
        val updated = old.copy(
            productId = product.id,
            articleSnapshot = product.article,
            productNameSnapshot = product.name,
            quantity = quantity,
            priority = priority,
            note = note.cleanText()
        )
        var result = data.copy(orders = data.orders.map { if (it.id == orderId) updated else it })
        if (structureChanged && orderJobs.isNotEmpty()) {
            val oldByKey = orderJobs.associateBy { it.moldCode.uppercase(Locale.ROOT) to it.colorCode.uppercase(Locale.ROOT) }
            val rebuilt = buildPlanJobs(result, updated) { UUID.randomUUID().toString() }.map { fresh ->
                val previous = oldByKey[fresh.moldCode.uppercase(Locale.ROOT) to fresh.colorCode.uppercase(Locale.ROOT)]
                val machine = previous?.machineId?.let { id -> result.machines.firstOrNull { it.id == id } }
                val keepAssignment = machine != null && fresh.acceptsMachine(machine, result)
                fresh.copy(
                    id = previous?.id ?: fresh.id,
                    machineId = previous?.machineId?.takeIf { keepAssignment },
                    brigadeId = previous?.brigadeId?.takeIf { keepAssignment },
                    shiftId = previous?.shiftId?.takeIf { keepAssignment },
                    status = if (keepAssignment) TpJobStatus.QUEUED else TpJobStatus.UNASSIGNED
                )
            }
            result = result.copy(jobs = data.jobs.filterNot { it.orderId == orderId } + rebuilt)
        } else if (orderJobs.isNotEmpty() && old.priority != priority) {
            val slots = orderJobs.sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id })
            val base = priority * 100
            val reprioritized = slots.mapIndexed { index, job -> job.id to (base + index + 1) }.toMap()
            result = result.copy(jobs = result.jobs.map { job -> reprioritized[job.id]?.let { job.copy(priority = it) } ?: job })
        }
        result.refreshOrderStatus(orderId)
            .audit("TP_ORDER_UPDATE", recordDate = old.createdAt.take(10), details = "${old.batchNumber}: ${product.article} × $quantity / ${tpPriorityLabel(priority)}")
    }

    fun deleteOrder(orderId: String): Result<Unit> = mutate { data ->
        val order = data.orders.firstOrNull { it.id == orderId } ?: error("Zakaz topilmadi")
        require(data.jobs.none { it.orderId == orderId }) { "Jarayoni boshlangan zakaz o‘chirilmaydi. Bekor qilishdan foydalaning." }
        require(data.receipts.none { !it.isCancelled && it.orderId == orderId }) { "Qabul yozuvi bor zakaz o‘chirilmaydi. Bekor qilishdan foydalaning." }
        data.copy(orders = data.orders.filterNot { it.id == orderId })
            .audit("TP_ORDER_DELETE", recordDate = order.createdAt.take(10), details = "${order.batchNumber} ${order.articleSnapshot}")
    }

    fun cancelOrder(orderId: String, reason: String, cancelledBy: String = ""): Result<Unit> = mutate { data ->
        val order = data.orders.firstOrNull { it.id == orderId } ?: error("Zakaz topilmadi")
        require(order.status != TpOrderStatus.COMPLETE) { "Yakunlangan zakazni bekor qilib bo‘lmaydi" }
        require(order.status != TpOrderStatus.CANCELLED) { "Zakaz allaqachon bekor qilingan" }
        val cleanReason = reason.cleanText()
        require(cleanReason.isNotBlank()) { "Bekor qilish sababini kiriting" }
        val now = LocalDateTime.now().toString()
        data.copy(
            orders = data.orders.map { if (it.id == orderId) it.copy(status = TpOrderStatus.CANCELLED, cancelledAt = now, cancelReason = cleanReason, cancelledBy = cancelledBy.cleanText()) else it },
            jobs = data.jobs.map { if (it.orderId == orderId && it.status != TpJobStatus.COMPLETE) it.copy(status = TpJobStatus.HOLD) else it }
        ).audit("TP_ORDER_CANCEL", recordDate = order.requestedDate, details = "${order.batchNumber}: $cleanReason")
    }

    fun generateOrderPlan(orderId: String): Result<Unit> = mutate { data ->
        val order = data.orders.firstOrNull { it.id == orderId } ?: error("Zakaz topilmadi")
        require(order.planApprovedAt == null) { "Bu zakaz jarayonga topshirilgan" }
        require(data.jobs.none { it.orderId == orderId }) { "Bu zakaz uchun plan yaratilgan" }
        val jobs = buildPlanJobs(data, order) { UUID.randomUUID().toString() }
        require(jobs.isNotEmpty()) { "Plan vazifalari hosil bo‘lmadi" }
        data.copy(
            jobs = data.jobs + jobs,
            orders = data.orders.map { if (it.id == orderId) it.copy(status = TpOrderStatus.PLANNING) else it }
        ).audit("TP_PLAN_GENERATE", recordDate = order.requestedDate, details = "${order.batchNumber}: ${jobs.size} vazifa")
    }

    fun assignJob(jobId: String, machineId: String, brigadeId: String, priority: Int, allowIncompatible: Boolean = false, overrideReason: String = ""): Result<Unit> = mutate { data ->
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        val order = data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        require(order.planApprovedAt == null) { "Tasdiqlangan planda stanokni o‘zgartirib bo‘lmaydi" }
        val machine = data.machines.firstOrNull { it.id == machineId && !it.archived } ?: error("Stanok topilmadi")
        val brigade = data.brigades.firstOrNull { it.id == brigadeId && !it.archived } ?: error("Brigada topilmadi")
        require(machine.shopId == brigade.shopId) { "Stanok va brigada bir sexda bo‘lsin" }
        val compatible = job.acceptsMachine(machine, data)
        val cleanOverrideReason = overrideReason.cleanText()
        require(compatible || (allowIncompatible && cleanOverrideReason.isNotBlank())) { "Bu stanok mos emas. ‘Boshqa’ tanlovida sabab majburiy." }
        require(priority in 1..9999) { "Ustuvorlik noto‘g‘ri" }
        val now = LocalDateTime.now().toString()
        val updatedJobs = data.jobs.map {
            if (it.id == jobId) it.copy(
                machineId = machineId, brigadeId = brigadeId, shiftId = brigade.shiftId,
                priority = priority, status = TpJobStatus.QUEUED,
                machineOverride = !compatible,
                machineOverrideReason = if (!compatible) cleanOverrideReason else "",
                machineOverrideAt = if (!compatible) now else null
            ) else it
        }
        val orderReady = updatedJobs.filter { it.orderId == job.orderId }.all { it.machineId != null }
        data.copy(
            jobs = updatedJobs,
            orders = data.orders.map { if (it.id == job.orderId && orderReady) it.copy(status = TpOrderStatus.READY) else it }
        ).audit(if (compatible) "TP_JOB_ASSIGN" else "TP_JOB_ASSIGN_OVERRIDE", brigadeId, details = "Stanok ${machine.number} / ${job.moldCode}${if (!compatible) "; Boshqa: $cleanOverrideReason" else ""}")
    }

    fun assignMoldJobs(
        orderId: String,
        moldCode: String,
        machineId: String,
        editReason: String = "",
        allowIncompatible: Boolean = false,
        overrideReason: String = ""
    ): Result<Unit> = mutate { data ->
        val order = data.orders.firstOrNull { it.id == orderId } ?: error("Zakaz topilmadi")
        val machine = data.machines.firstOrNull { it.id == machineId && !it.archived } ?: error("Stanok topilmadi")
        val target = data.jobs.filter { it.orderId == orderId && it.moldCode == moldCode }
        val targetIds = target.map { it.id }.toSet()
        val waitMinutes = data.jobs.filter { it.machineId == machineId && it.status != TpJobStatus.COMPLETE && it.id !in targetIds }
            .sumOf { it.estimatedMinutes.coerceAtLeast(0) }
        val brigade = data.autoBrigadeForMachine(machineId, waitMinutes)
            ?: error("Bu stanok sexi uchun smenaga mos brigada topilmadi")
        require(target.isNotEmpty()) { "Detal/qolip vazifalari topilmadi" }
        val compatible = target.all { it.acceptsMachine(machine, data) }
        val cleanOverrideReason = overrideReason.cleanText()
        require(compatible || (allowIncompatible && cleanOverrideReason.isNotBlank())) { "Bu stanok ushbu detal sig‘imiga mos emas. ‘Boshqa’ uchun sabab kiriting." }
        val editingConfirmedPlan = target.any { it.planConfirmedAt != null } || order.planApprovedAt != null
        if (editingConfirmedPlan) {
            val reason = editReason.cleanText()
            require(reason.isNotBlank()) { "Tasdiqlangan planni tahrirlash uchun sharh majburiy" }
            require(target.none { it.status == TpJobStatus.IN_PROGRESS || it.status == TpJobStatus.COMPLETE }) { "Boshlangan yoki tugagan detal rejasini tahrirlab bo‘lmaydi" }
            require(data.receipts.none { receipt -> !receipt.isCancelled && receipt.orderId == orderId && target.any { job -> receipt.jobId == job.id } }) { "Qabul yozuvi bor detal rejasini tahrirlab bo‘lmaydi" }
        }
        val ids = targetIds
        val now = LocalDateTime.now().toString()
        val reason = editReason.cleanText()
        val updatedJobs = data.jobs.map { job ->
            if (job.id in ids) job.copy(
                machineId = machineId,
                brigadeId = brigade.id,
                shiftId = brigade.shiftId,
                status = TpJobStatus.QUEUED,
                planConfirmedAt = if (editingConfirmedPlan) null else job.planConfirmedAt,
                planEditedAt = if (editingConfirmedPlan) now else job.planEditedAt,
                planEditReason = if (editingConfirmedPlan) reason else job.planEditReason,
                resinSelectedAt = if (editingConfirmedPlan) null else job.resinSelectedAt,
                resinConfirmedAt = if (editingConfirmedPlan) null else job.resinConfirmedAt,
                materialShortageOverride = if (editingConfirmedPlan) false else job.materialShortageOverride,
                materialStatus = if (editingConfirmedPlan) TpMaterialStatus.PLANNED else job.materialStatus,
                materialConfirmedAt = if (editingConfirmedPlan) null else job.materialConfirmedAt,
                materialDeliveredAt = if (editingConfirmedPlan) null else job.materialDeliveredAt,
                startedAt = if (editingConfirmedPlan) null else job.startedAt,
                machineOverride = !compatible,
                machineOverrideReason = if (!compatible) cleanOverrideReason else "",
                machineOverrideAt = if (!compatible) now else null
            ) else job
        }
        val orderReady = updatedJobs.filter { it.orderId == orderId }.all { it.machineId != null }
        val updatedOrder = if (editingConfirmedPlan) {
            order.copy(status = TpOrderStatus.PLANNING, planApprovedAt = null)
        } else if (orderReady) order.copy(status = TpOrderStatus.READY) else order.copy(status = TpOrderStatus.PLANNING)
        data.copy(
            jobs = updatedJobs,
            orders = data.orders.map { if (it.id == orderId) updatedOrder else it }
        ).audit(
            if (editingConfirmedPlan) "TP_PLAN_EDIT" else "TP_MOLD_ASSIGN", brigade.id, order.requestedDate,
            "$moldCode → stanok ${machine.number}${if (!compatible) "; Boshqa: $cleanOverrideReason" else ""}${if (editingConfirmedPlan) "; sabab: $reason" else ""}"
        )
    }

    fun confirmPlannedMold(orderId: String, moldCode: String): Result<Unit> = mutate { data ->
        val order = data.orders.firstOrNull { it.id == orderId } ?: error("Zakaz topilmadi")
        val target = data.jobs.filter { it.orderId == orderId && it.moldCode == moldCode }
        require(target.isNotEmpty()) { "Detal/qolip vazifalari topilmadi" }
        require(target.all { it.machineId != null && it.brigadeId != null && it.shiftId != null }) { "Avval ushbu detal uchun stanokni rejalang" }
        require(target.none { it.planConfirmedAt != null }) { "Bu detal rejasi allaqachon tasdiqlangan" }
        val now = LocalDateTime.now().toString()
        val targetIds = target.map { it.id }.toSet()
        val jobs = data.jobs.map { if (it.id in targetIds) it.copy(planConfirmedAt = now) else it }
        val allConfirmed = jobs.filter { it.orderId == orderId }.isNotEmpty() && jobs.filter { it.orderId == orderId }.all { it.planConfirmedAt != null }
        val updatedOrder = order.copy(
            status = if (allConfirmed) TpOrderStatus.APPROVED else TpOrderStatus.PLANNING,
            planApprovedAt = if (allConfirmed) now else null
        )
        data.copy(jobs = jobs, orders = data.orders.map { if (it.id == orderId) updatedOrder else it })
            .audit("TP_PLAN_DETAIL_APPROVE", target.firstOrNull()?.brigadeId, order.requestedDate, "$moldCode tasdiqlandi${if (allConfirmed) "; zakaz to‘liq tasdiqlandi" else ""}")
    }

    fun setColorPosition(jobId: String, position: Int): Result<Unit> = mutate { data ->
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Rang vazifasi topilmadi")
        data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        require(data.jobs.filter { it.orderId == job.orderId && it.moldCode == job.moldCode }.none { it.planConfirmedAt != null }) { "Tasdiqlangan detal rejasida rang navbatini o‘zgartirish uchun avval rejani tahrirlang" }
        val siblings = data.jobs.filter { it.orderId == job.orderId && it.moldCode == job.moldCode }
            .sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id })
        require(position in 1..siblings.size) { "Tartib raqami noto‘g‘ri" }
        val reordered = siblings.toMutableList().apply {
            val currentIndex = indexOfFirst { it.id == jobId }
            val moving = removeAt(currentIndex)
            add(position - 1, moving)
        }
        val slots = siblings.map { it.priority }.sorted()
        val newPriority = reordered.mapIndexed { index, item -> item.id to slots[index] }.toMap()
        data.copy(jobs = data.jobs.map { item -> newPriority[item.id]?.let { item.copy(priority = it) } ?: item })
            .audit("TP_COLOR_ORDER", job.brigadeId, details = "${job.moldCode}/${job.colorCode} → $position")
    }

    fun setJobResin(jobId: String, resinCode: String, allowAlternative: Boolean = false): Result<Unit> =
        setJobFeedstock(jobId, TpMaterialType.RESIN, resinCode, allowAlternative)

    fun setJobFeedstock(jobId: String, type: TpMaterialType, code: String, allowAlternative: Boolean = false): Result<Unit> = mutate { data ->
        require(type == TpMaterialType.RESIN || type == TpMaterialType.RECYCLED) { "Xomashyo turi noto‘g‘ri" }
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Rang vazifasi topilmadi")
        data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        require(job.planConfirmedAt != null) { "Plan beruvchi avval shu detal rejasini tasdiqlasin" }
        require(job.resinConfirmedAt == null) { "Seryo buyurtmasi allaqachon tasdiqlangan" }
        val outputDetails = job.outputs.mapNotNull { output ->
            data.products.asSequence().flatMap { it.details.asSequence() }.firstOrNull { it.id == output.detailId }
        }
        val resinOptionSets = outputDetails.map { it.resinOptions().toSet() }
        val resinAllowed = if (resinOptionSets.isEmpty()) emptySet() else resinOptionSets.drop(1).fold(resinOptionSets.first()) { acc, set -> acc intersect set }
        val selected = code.trim().uppercase(Locale.ROOT)
        val globallyKnown = when (type) {
            TpMaterialType.RESIN -> selected in data.allResinCodes()
            TpMaterialType.RECYCLED -> data.materials.any { !it.archived && it.type == TpMaterialType.RECYCLED && it.code.equals(selected, true) }
            else -> false
        }
        val allowed = when (type) {
            TpMaterialType.RESIN -> selected in resinAllowed
            TpMaterialType.RECYCLED -> globallyKnown && outputDetails.isNotEmpty() && outputDetails.all { it.acceptsRecycled(selected) }
            else -> false
        }
        require(allowed || (allowAlternative && globallyKnown && type == TpMaterialType.RESIN)) {
            if (type == TpMaterialType.RECYCLED) "Bu detal uchun ruxsat etilgan ftarichkani tanlang" else "Seryoni ro‘yxatdan tanlang"
        }
        val now = LocalDateTime.now().toString()
        data.copy(jobs = data.jobs.map {
            if (it.id == jobId) it.copy(
                resinCode = selected,
                feedstockType = type,
                resinSelectedAt = now,
                alternativeResin = type == TpMaterialType.RESIN && selected !in resinAllowed,
                resinAdditions = if (type == TpMaterialType.RESIN) it.resinAdditions.map { extra -> extra.copy(resinCode = selected) } else emptyList()
            ) else it
        }).audit("TP_JOB_FEEDSTOCK", job.brigadeId, details = "${job.moldCode}/${job.colorCode}: ${type.displayName()} $selected")
    }

    fun addJobResin(jobId: String, kind: TpResinAdditionKind, kilograms: Double = 0.0): Result<Unit> = mutate { data ->
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        require(job.planConfirmedAt != null && job.resinSelectedAt != null) { "Avval seryo turini tanlang" }
        require(job.feedstockType == TpMaterialType.RESIN) { "Qo‘shimcha seryo faqat oddiy seryo tanlanganda qo‘shiladi" }
        require(job.resinConfirmedAt == null && job.materialStatus == TpMaterialStatus.PLANNED) { "Tasdiqlangan seryoni o‘zgartirib bo‘lmaydi" }
        val amount = if (kind == TpResinAdditionKind.ROUND_25) resinRoundUpAddition(job.totalResinKg) else resinKg(kilograms)
        if (kind == TpResinAdditionKind.ROUND_25 && amount == 0.0) return@mutate data
        require(amount > 0.0 && amount <= 1_000_000.0) { "Qo‘shimcha kg 0 dan katta bo‘lsin (aniqlik: 0.001 kg)" }
        val extra = TpResinAddition(
            UUID.randomUUID().toString(), job.resinCode, amount, kind, LocalDateTime.now().toString(),
            uz.toybola.factory.core.preferences.AppPreferences(appContext).setup()?.userCode.orEmpty()
        )
        data.copy(jobs = data.jobs.map { if (it.id == jobId) it.copy(resinAdditions = it.resinAdditions + extra) else it })
            .audit("TP_RESIN_ADDITION", job.brigadeId, details = "${job.outputs.joinToString { it.detailName }} • ${job.resinCode}: +${formatTpNumber(amount)} kg • ${kind.name}")
    }

    fun confirmJobResin(jobId: String, acceptShortage: Boolean): Result<Unit> = mutate { data ->
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        val order = data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        require(job.planConfirmedAt != null) { "Plan beruvchi avval shu detal rejasini tasdiqlasin" }
        require(job.resinSelectedAt != null && job.resinCode.isNotBlank()) { "Avval seryo turini tanlang" }
        require(job.resinConfirmedAt == null) { "Bu detal/rang seryosi allaqachon tasdiqlangan" }
        val feedstockStock = data.materialStock(job.feedstockType, job.resinCode)
        val colorStock = data.materialStock(TpMaterialType.COLOR, job.colorCode)
        val shortages = buildList {
            if (feedstockStock + 1e-9 < job.totalResinKg) add("${job.resinCode} ${job.feedstockType.displayName().lowercase()}: kerak ${formatTpNumber(job.totalResinKg)} kg / bor ${formatTpNumber(feedstockStock)} kg")
            if (job.feedstockType == TpMaterialType.RESIN && colorStock + 1e-9 < job.totalColorGrams) add("${job.colorCode} krasitel: kerak ${formatTpNumber(job.totalColorGrams)} g / bor ${formatTpNumber(colorStock)} g")
        }
        require(shortages.isEmpty() || acceptShortage) { "OSTATKA_YETMAYDI\n" + shortages.joinToString("\n") }
        val now = LocalDateTime.now().toString()
        data.copy(jobs = data.jobs.map { row ->
            if (row.id == jobId) row.copy(
                resinConfirmedAt = now,
                materialShortageOverride = shortages.isNotEmpty() && acceptShortage
            ) else row
        }).audit(
            "TP_RESIN_JOB_APPROVE", job.brigadeId, order.requestedDate,
            "${order.batchNumber}: ${job.outputs.joinToString { it.detailName }}/${job.colorCode} ${job.resinCode} tasdiqlandi${if (shortages.isNotEmpty()) " / qoldiq ogohlantirishi qabul qilindi" else ""}"
        )
    }

    fun confirmOrderResins(orderId: String, acceptShortage: Boolean): Result<Unit> = mutate { data ->
        val order = data.orders.firstOrNull { it.id == orderId } ?: error("Zakaz topilmadi")
        val orderJobs = data.jobs.filter { it.orderId == orderId }
        require(orderJobs.isNotEmpty() && orderJobs.all { it.planConfirmedAt != null }) { "Plan beruvchi avval barcha detal rejalarini tasdiqlasin" }
        require(orderJobs.isNotEmpty()) { "Seryo uchun vazifalar topilmadi" }
        require(orderJobs.all { it.resinCode.isNotBlank() && it.resinSelectedAt != null }) { "Har bir detal/rang uchun seryo turini tanlang" }
        val feedstockNeed = orderJobs.groupBy { it.feedstockType to it.resinCode.uppercase(Locale.ROOT) }
            .mapValues { (_, rows) -> rows.sumOf { it.totalResinKg } }
        val colorNeed = orderJobs.filter { it.feedstockType == TpMaterialType.RESIN }
            .groupBy { it.colorCode.uppercase(Locale.ROOT) }.mapValues { (_, rows) -> rows.sumOf { it.totalColorGrams } }
        val shortages = buildList {
            feedstockNeed.forEach { (key, need) ->
                val (type, code) = key
                val stock = data.materialStock(type, code)
                if (stock + 1e-9 < need) add("$code ${type.displayName().lowercase()}: kerak ${formatTpNumber(need)} kg / bor ${formatTpNumber(stock)} kg")
            }
            colorNeed.forEach { (code, need) ->
                val stock = data.materialStock(TpMaterialType.COLOR, code)
                if (stock + 1e-9 < need) add("$code krasitel: kerak ${formatTpNumber(need)} g / bor ${formatTpNumber(stock)} g")
            }
        }
        require(shortages.isEmpty() || acceptShortage) { "OSTATKA_YETMAYDI\n" + shortages.joinToString("\n") }
        val now = LocalDateTime.now().toString()
        data.copy(jobs = data.jobs.map { job ->
            if (job.orderId == orderId) job.copy(
                resinConfirmedAt = now,
                materialShortageOverride = shortages.isNotEmpty() && acceptShortage
            ) else job
        }).audit("TP_RESIN_APPROVE", recordDate = order.requestedDate, details = "${order.batchNumber}: seryo tasdiqlandi${if (shortages.isNotEmpty()) " / qoldiq ogohlantirishi qabul qilindi" else ""}")
    }

    fun approveOrderPlan(orderId: String): Result<Unit> = mutate { data ->
        val order = data.orders.firstOrNull { it.id == orderId } ?: error("Zakaz topilmadi")
        require(order.planApprovedAt == null) { "Plan allaqachon jarayonga topshirilgan" }
        val orderJobs = data.jobs.filter { it.orderId == orderId }
        require(orderJobs.isNotEmpty()) { "Avval plan hisobini yarating" }
        require(orderJobs.all { it.machineId != null && it.brigadeId != null && it.shiftId != null }) {
            "Jarayonni boshlashdan oldin barcha detal/ranglarga stanok va brigada tanlang"
        }
        val now = LocalDateTime.now().toString()
        data.copy(
            jobs = data.jobs.map { if (it.orderId == orderId) it.copy(planConfirmedAt = it.planConfirmedAt ?: now) else it },
            orders = data.orders.map { if (it.id == orderId) it.copy(status = TpOrderStatus.APPROVED, planApprovedAt = now) else it }
        ).audit("TP_PLAN_APPROVE", recordDate = order.requestedDate, details = "${order.batchNumber}: ${orderJobs.size} vazifa jarayonga topshirildi")
    }

    fun setJobPriority(jobId: String, priority: Int): Result<Unit> = mutate { data ->
        require(priority in 1..9999) { "Ustuvorlik noto‘g‘ri" }
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        data.copy(jobs = data.jobs.map { if (it.id == jobId) it.copy(priority = priority) else it })
            .audit("TP_JOB_PRIORITY", job.brigadeId, details = "${job.moldCode}: $priority")
    }

    fun setJobStatus(jobId: String, status: TpJobStatus): Result<Unit> = mutate { data ->
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        val order = data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        if (status == TpJobStatus.IN_PROGRESS || status == TpJobStatus.COMPLETE) {
            require(job.planConfirmedAt != null) { "Plan beruvchi avval shu detal rejasini tasdiqlasin" }
        }
        if (status == TpJobStatus.IN_PROGRESS) {
            require(job.materialStatus == TpMaterialStatus.DELIVERED) { "Seryo stanokka yetkazilmaguncha ishni boshlab bo‘lmaydi" }
            val machineId = job.machineId ?: error("Avval stanok belgilang")
            require(data.jobs.none { it.id != jobId && it.machineId == machineId && it.status == TpJobStatus.IN_PROGRESS }) {
                "Bu stanokda boshqa aktiv ish bor. Avval uni yakunlang yoki To‘xtagan holatiga o‘tkazing."
            }
        }
        require(job.machineId != null || status == TpJobStatus.HOLD || status == TpJobStatus.UNASSIGNED) { "Avval stanok belgilang" }
        if (status == TpJobStatus.COMPLETE) {
            val unfinished = job.outputs.filter { output ->
                data.receipts.filter { !it.isCancelled && it.jobId == jobId && it.detailId == output.detailId }
                    .sumOf { it.creditedPieces } < output.requiredPieces
            }
            require(unfinished.isEmpty()) {
                "Vazifa faqat qabul qilingan barcha detallar reja soniga yetganda yakunlanadi"
            }
        }
        val now = LocalDateTime.now().toString()
        var updated = data.copy(jobs = data.jobs.map {
            if (it.id == jobId) it.copy(status = status, startedAt = if (status == TpJobStatus.IN_PROGRESS) (it.startedAt ?: now) else it.startedAt) else it
        })
        updated = updated.refreshOrderStatus(job.orderId)
        updated.audit("TP_JOB_STATUS", job.brigadeId, details = "${job.moldCode}: ${status.name}")
    }

    fun confirmMaterial(jobId: String, delivered: Boolean): Result<Unit> = mutate { data ->
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        val order = data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        require(job.planConfirmedAt != null) { "Plan beruvchi avval shu detal rejasini tasdiqlasin" }
        require(job.resinConfirmedAt != null) { "Seryo brigadiri avval seryo turini tanlab tasdiqlasin" }
        require(job.machineId != null) { "Vazifa stanokka biriktirilmagan" }
        if (job.materialStatus == TpMaterialStatus.DELIVERED) return@mutate data

        val now = LocalDateTime.now().toString()
        val status = if (delivered) TpMaterialStatus.DELIVERED else TpMaterialStatus.CONFIRMED
        val updated = job.copy(
            materialStatus = status,
            materialConfirmedAt = job.materialConfirmedAt ?: now,
            materialDeliveredAt = if (delivered) now else job.materialDeliveredAt
        )
        var materials = data.materials
        if (delivered) {
            fun consume(code: String, type: TpMaterialType, amount: Double) {
                if (amount <= 0.0) return
                val existing = materials.firstOrNull { !it.archived && it.type == type && it.code.equals(code, true) }
                val material = if (existing != null) {
                    existing
                } else {
                    require(job.materialShortageOverride) { "$code bo‘yicha ostatka topilmadi" }
                    TpMaterial(
                        id = UUID.randomUUID().toString(),
                        code = code.uppercase(Locale.ROOT),
                        name = code.uppercase(Locale.ROOT),
                        type = type,
                        availableAmount = 0.0
                    ).also { created -> materials = materials + created }
                }
                if (!job.materialShortageOverride) {
                    require(material.currentStock() + 1e-9 >= amount) {
                        "$code ostatkasi yetarli emas: ${formatTpNumber(material.currentStock())}"
                    }
                }
                val movement = TpMaterialMovement(
                    id = "job-${job.id}-${type.name}", kind = TpMaterialMovementKind.OUT, amount = amount,
                    createdAt = now, note = "${order.batchNumber} • ${job.moldCode} • stanokka chiqdi", sourceJobId = job.id
                )
                materials = materials.map { item ->
                    if (item.id == material.id) material.copy(movements = material.movements + movement) else item
                }
            }
            consume(job.resinCode, job.feedstockType, job.totalResinKg)
            if (job.feedstockType == TpMaterialType.RESIN) consume(job.colorCode, TpMaterialType.COLOR, job.totalColorGrams)
        }
        data.copy(
            jobs = data.jobs.map { if (it.id == jobId) updated else it },
            materials = materials
        ).audit(if (delivered) "TP_MATERIAL_DELIVER" else "TP_MATERIAL_CONFIRM", job.brigadeId, details = job.moldCode)
    }

    fun receiveRecycled(
        recycledCode: String,
        kilograms: Double,
        sourceKind: TpMaterialSourceKind,
        machineId: String? = null,
        sourceArea: String = "",
        productId: String? = null,
        detailId: String? = null,
        note: String = ""
    ): Result<Unit> = mutate { data ->
        require(sourceKind in setOf(TpMaterialSourceKind.BREAKAGE_MACHINE, TpMaterialSourceKind.BREAKAGE_AREA, TpMaterialSourceKind.RETURNED_RECYCLED)) {
            "Qabul turi noto‘g‘ri"
        }
        val machine = machineId?.let { id -> data.machines.firstOrNull { it.id == id && !it.archived } ?: error("Stanok topilmadi") }
        val amount = normalizeFeedstockKg(kilograms)
        require(amount > 0.0) { "Og‘irlikni kiriting" }
        val user = uz.toybola.factory.core.preferences.AppPreferences(appContext).setup()?.userCode.orEmpty()
        val operationNote = note.cleanText().ifBlank {
            when (sourceKind) {
                TpMaterialSourceKind.BREAKAGE_MACHINE -> "Brak qabul qilindi"
                TpMaterialSourceKind.BREAKAGE_AREA -> "Brak qabul qilindi: ${sourceArea.cleanText()}"
                TpMaterialSourceKind.RETURNED_RECYCLED -> "Stanokdan qaytgan ftarichka qabul qilindi"
                else -> "Ftarichka qabul qilindi"
            }
        }
        data.withMaterialMovement(
            type = TpMaterialType.RECYCLED, code = recycledCode, kind = TpMaterialMovementKind.IN, amount = amount,
            note = operationNote, sourceKind = sourceKind, sourceMachineId = machine?.id, sourceShopId = machine?.shopId,
            sourceArea = sourceArea, productId = productId, detailId = detailId, createdBy = user
        ).audit("TP_RECYCLED_RECEIVE", details = "${recycledCode.uppercase(Locale.ROOT)} +${formatTpNumber(amount)} kg • $operationNote")
    }

    fun reverseMaterialMovement(materialId: String, movementId: String, reason: String): Result<Unit> = mutate { data ->
        val material = data.materials.firstOrNull { it.id == materialId } ?: error("Material topilmadi")
        val original = material.movements.firstOrNull { it.id == movementId } ?: error("Oldi-berdi yozuvi topilmadi")
        val cleanReason = reason.cleanText()
        require(cleanReason.length >= 3) { "Tuzatish sababini kiriting" }
        require(material.movements.none { it.note.contains("REV:$movementId") }) { "Bu yozuv allaqachon qaytarilgan" }
        val reverseKind = if (original.kind == TpMaterialMovementKind.IN) TpMaterialMovementKind.OUT else TpMaterialMovementKind.IN
        val user = uz.toybola.factory.core.preferences.AppPreferences(appContext).setup()?.userCode.orEmpty()
        data.withMaterialMovement(
            type = material.type, code = material.code, kind = reverseKind, amount = original.amount,
            note = "REV:$movementId • $cleanReason", sourceJobId = original.sourceJobId, sourceKind = TpMaterialSourceKind.MANUAL,
            sourceMachineId = original.sourceMachineId, sourceShopId = original.sourceShopId, sourceArea = original.sourceArea,
            productId = original.productId, detailId = original.detailId, createdBy = user,
            allowNegativeStock = true, createMissingMaterial = true
        ).audit("TP_MATERIAL_REVERSE", details = "${material.code}: ${formatTpNumber(original.amount)} ${material.type.unitLabel()} • $cleanReason")
    }

    fun createSeryoCompensation(
        machineId: String,
        productId: String,
        detailId: String,
        colorCode: String,
        kilograms: Double,
        sourceJobId: String? = null
    ): Result<Unit> = mutate { data ->
        val machine = data.machines.firstOrNull { it.id == machineId && !it.archived } ?: error("Stanokni tanlang")
        val product = data.products.firstOrNull { it.id == productId && !it.archived } ?: error("Mahsulot topilmadi")
        val detail = product.details.firstOrNull { it.id == detailId && !it.archived } ?: error("Detal topilmadi")
        val amount = normalizeFeedstockKg(kilograms)
        require(amount > 0.0) { "Beriladigan seryo kilogrammini kiriting" }
        val color = colorCode.trim().uppercase(Locale.ROOT).ifBlank { detail.colors.firstOrNull()?.colorCode.orEmpty() }
        require(detail.colors.any { it.colorCode.equals(color, true) }) { "Detal rangini tanlang" }
        val sourceJob = sourceJobId?.let { id -> data.jobs.firstOrNull { it.id == id && it.machineId == machineId } }
        val defaultType = sourceJob?.feedstockType?.takeIf { it != TpMaterialType.COLOR } ?: TpMaterialType.RESIN
        val defaultCode = sourceJob?.resinCode?.takeIf { it.isNotBlank() } ?: detail.resinOptions().firstOrNull().orEmpty()
        require(defaultCode.isNotBlank()) { "Detal uchun seryo turi topilmadi" }
        val now = LocalDateTime.now().toString()
        val user = uz.toybola.factory.core.preferences.AppPreferences(appContext).setup()?.userCode.orEmpty()
        val order = TpSeryoCompensationOrder(
            id = UUID.randomUUID().toString(), machineId = machine.id, shopId = machine.shopId, sourceJobId = sourceJobId,
            productId = product.id, detailId = detail.id, articleSnapshot = product.article, productNameSnapshot = product.name,
            detailNameSnapshot = detail.name, colorCode = color, targetKg = amount,
            defaultFeedstockType = defaultType, defaultFeedstockCode = defaultCode.trim().uppercase(Locale.ROOT),
            createdAt = now, createdBy = user
        )
        data.copy(seryoCompensations = data.seryoCompensations + order)
            .audit("TP_SERYO_COMPENSATION_ADD", details = "${machine.number}-stanok • ${product.name}/${detail.name} • ${formatTpNumber(amount)} kg")
    }

    fun addJobMaterialBatch(
        jobId: String,
        type: TpMaterialType,
        code: String,
        kilograms: Double,
        recycledColorGrams: Double = 0.0
    ): Result<Unit> = mutate { data ->
        require(type == TpMaterialType.RESIN || type == TpMaterialType.RECYCLED) { "Xomashyo turini tanlang" }
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        val order = data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        val machine = job.machineId?.let { id -> data.machines.firstOrNull { it.id == id } } ?: error("Stanok belgilanmagan")
        require(job.resinConfirmedAt != null) { "Seryo brigadiri avval xomashyoni tasdiqlasin" }
        val amount = normalizeFeedstockKg(kilograms)
        require(amount > 0.0) { "Beriladigan kilogrammni kiriting" }
        val remaining = job.remainingFeedstockKg()
        require(amount <= remaining + 1e-9) { "Zakaz qoldig‘i ${formatTpNumber(remaining)} kg. Bundan ortiq berib bo‘lmaydi" }
        val normalizedCode = code.trim().uppercase(Locale.ROOT)
        val outputDetails = job.outputs.mapNotNull { output ->
            data.products.asSequence().flatMap { it.details.asSequence() }.firstOrNull { it.id == output.detailId }
        }
        val allowed = if (type == TpMaterialType.RESIN) {
            val sets = outputDetails.map { it.resinOptions().toSet() }
            normalizedCode in (if (sets.isEmpty()) emptySet() else sets.drop(1).fold(sets.first()) { acc, set -> acc intersect set }) || normalizedCode in data.allResinCodes()
        } else {
            outputDetails.isNotEmpty() && outputDetails.all { it.acceptsRecycled(normalizedCode) }
        }
        require(allowed) {
            if (type == TpMaterialType.RECYCLED) "Bu detalga ruxsat etilgan ftarichkani tanlang" else "Seryo turini tanlang"
        }
        val colorGrams = if (type == TpMaterialType.RESIN) {
            if (job.totalResinKg > 0.0) job.totalColorGrams * amount / job.totalResinKg else 0.0
        } else recycledColorGrams.also { require(it.isFinite() && it >= 0.0) { "Krasitel grammni to‘g‘ri kiriting" } }
        val user = uz.toybola.factory.core.preferences.AppPreferences(appContext).setup()?.userCode.orEmpty()
        val now = LocalDateTime.now().toString()
        var updated = data.withMaterialMovement(
            type, normalizedCode, TpMaterialMovementKind.OUT, amount,
            "${order.batchNumber} • ${job.outputs.joinToString { it.detailName }} • ${machine.number}-stanokka chiqdi",
            sourceJobId = job.id, sourceKind = TpMaterialSourceKind.JOB_DELIVERY, sourceMachineId = machine.id,
            sourceShopId = machine.shopId, productId = order.productId, detailId = job.outputs.firstOrNull()?.detailId, createdBy = user,
            allowNegativeStock = true, createMissingMaterial = true
        )
        if (colorGrams > 0.0) {
            updated = updated.withMaterialMovement(
                TpMaterialType.COLOR, job.colorCode, TpMaterialMovementKind.OUT, colorGrams,
                "${order.batchNumber} • ${job.outputs.joinToString { it.detailName }} • ${machine.number}-stanokka krasitel",
                sourceJobId = job.id, sourceKind = TpMaterialSourceKind.JOB_DELIVERY, sourceMachineId = machine.id,
                sourceShopId = machine.shopId, productId = order.productId, detailId = job.outputs.firstOrNull()?.detailId, createdBy = user,
                allowNegativeStock = true, createMissingMaterial = true
            )
        }
        val batch = TpMaterialBatch(UUID.randomUUID().toString(), type, normalizedCode, amount, if (colorGrams > 0.0) job.colorCode else "", colorGrams, now, user)
        val updatedJob = job.copy(
            materialBatches = job.materialBatches + batch,
            materialStatus = if (remaining - amount <= 1e-9) TpMaterialStatus.DELIVERED else TpMaterialStatus.CONFIRMED,
            materialConfirmedAt = job.materialConfirmedAt ?: now,
            materialDeliveredAt = if (remaining - amount <= 1e-9) now else job.materialDeliveredAt
        )
        updated.copy(jobs = updated.jobs.map { if (it.id == job.id) updatedJob else it })
            .audit("TP_MATERIAL_BATCH", job.brigadeId, details = "${machine.number}-stanok • ${type.displayName()} $normalizedCode ${formatTpNumber(amount)} kg • qoldi ${formatTpNumber((remaining - amount).coerceAtLeast(0.0))} kg")
    }

    fun addCompensationMaterialBatch(
        compensationId: String,
        type: TpMaterialType,
        code: String,
        kilograms: Double,
        recycledColorGrams: Double = 0.0
    ): Result<Unit> = mutate { data ->
        require(type == TpMaterialType.RESIN || type == TpMaterialType.RECYCLED) { "Xomashyo turini tanlang" }
        val comp = data.seryoCompensations.firstOrNull { it.id == compensationId } ?: error("Brak o‘rniga zakaz topilmadi")
        require(!comp.isComplete()) { "Bu zakaz allaqachon yopilgan" }
        val machine = data.machines.firstOrNull { it.id == comp.machineId } ?: error("Stanok topilmadi")
        val detail = data.products.asSequence().flatMap { it.details.asSequence() }.firstOrNull { it.id == comp.detailId } ?: error("Detal topilmadi")
        val amount = normalizeFeedstockKg(kilograms)
        require(amount > 0.0) { "Beriladigan kilogrammni kiriting" }
        val remaining = comp.remainingKg()
        require(amount <= remaining + 1e-9) { "Zakaz qoldig‘i ${formatTpNumber(remaining)} kg. Bundan ortiq berib bo‘lmaydi" }
        val normalizedCode = code.trim().uppercase(Locale.ROOT)
        val allowed = if (type == TpMaterialType.RESIN) {
            normalizedCode in detail.resinOptions() || normalizedCode in data.allResinCodes()
        } else detail.acceptsRecycled(normalizedCode)
        require(allowed) { "Xomashyo turini ro‘yxatdan tanlang" }
        val gramsPer25 = detail.colors.firstOrNull { it.colorCode.equals(comp.colorCode, true) }?.gramsPer25Kg ?: 0.0
        val colorGrams = if (type == TpMaterialType.RESIN) gramsPer25 * amount / 25.0 else recycledColorGrams
        require(colorGrams.isFinite() && colorGrams >= 0.0) { "Krasitel grammni to‘g‘ri kiriting" }
        val user = uz.toybola.factory.core.preferences.AppPreferences(appContext).setup()?.userCode.orEmpty()
        val now = LocalDateTime.now().toString()
        var updated = data.withMaterialMovement(
            type, normalizedCode, TpMaterialMovementKind.OUT, amount,
            "Brak o‘rniga • ${comp.productNameSnapshot}/${comp.detailNameSnapshot} • ${machine.number}-stanok",
            sourceJobId = comp.sourceJobId, sourceKind = TpMaterialSourceKind.COMPENSATION_DELIVERY, sourceMachineId = machine.id,
            sourceShopId = machine.shopId, productId = comp.productId, detailId = comp.detailId, createdBy = user,
            allowNegativeStock = true, createMissingMaterial = true
        )
        if (colorGrams > 0.0) {
            updated = updated.withMaterialMovement(
                TpMaterialType.COLOR, comp.colorCode, TpMaterialMovementKind.OUT, colorGrams,
                "Brak o‘rniga krasitel • ${machine.number}-stanok", sourceJobId = comp.sourceJobId,
                sourceKind = TpMaterialSourceKind.COMPENSATION_DELIVERY, sourceMachineId = machine.id, sourceShopId = machine.shopId,
                productId = comp.productId, detailId = comp.detailId, createdBy = user,
                allowNegativeStock = true, createMissingMaterial = true
            )
        }
        val batch = TpMaterialBatch(UUID.randomUUID().toString(), type, normalizedCode, amount, if (colorGrams > 0.0) comp.colorCode else "", colorGrams, now, user)
        val completed = remaining - amount <= 1e-9
        val next = comp.copy(batches = comp.batches + batch, completedAt = if (completed) now else null)
        updated.copy(seryoCompensations = updated.seryoCompensations.map { if (it.id == comp.id) next else it })
            .audit("TP_SERYO_COMPENSATION_BATCH", details = "${machine.number}-stanok • ${type.displayName()} $normalizedCode ${formatTpNumber(amount)} kg • qoldi ${formatTpNumber((remaining - amount).coerceAtLeast(0.0))} kg")
    }

    fun setAttendance(workerId: String, date: String, present: Boolean, minusHours: Double): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val worker = data.workers.firstOrNull { it.id == workerId && !it.archived } ?: error("Ishchi topilmadi")
        val brigade = data.brigades.firstOrNull { it.id == worker.brigadeId } ?: error("Brigada topilmadi")
        val shift = data.shifts.firstOrNull { it.id == brigade.shiftId } ?: error("Brigada smenasi topilmadi")
        require(minusHours.isFinite() && minusHours >= 0.0) { "Minus soatni to‘g‘ri kiriting" }
        val standardMinutes = shift.durationMinutes()
        val minusMinutes = kotlin.math.round(minusHours * 60.0).toInt()
        require(minusMinutes <= standardMinutes) { "Minus soat smena davomiyligidan katta bo‘lishi mumkin emas" }
        val workMinutes = if (present) (standardMinutes - minusMinutes).coerceAtLeast(0) else 0
        val normalizedMinus = if (present) minusHours else 0.0
        val id = "${workerId}_$date"
        val attendance = TpAttendance(id, worker.id, worker.brigadeId, brigade.shiftId, date, present, workMinutes, LocalDateTime.now().toString(), normalizedMinus)
        val values = data.attendance.filterNot { it.id == id } + attendance
        data.copy(attendance = values).audit("TP_ATTENDANCE", worker.brigadeId, date, "${worker.name}: $present / minus ${formatTpNumber(normalizedMinus)} soat / $workMinutes daqiqa")
    }

    fun addReceipt(
        jobId: String,
        detailId: String,
        workerId: String,
        date: String,
        completedBags: Int,
        remainderAfter: Int,
        receiverName: String
    ): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        val order = data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        require(job.planConfirmedAt != null) { "Plan beruvchi avval shu detal rejasini tasdiqlasin" }
        val output = job.outputs.firstOrNull { it.detailId == detailId } ?: error("Detal topilmadi")
        val worker = data.workers.firstOrNull { it.id == workerId && !it.archived } ?: error("Ishchi topilmadi")
        val machineId = job.machineId ?: error("Stanok belgilanmagan")
        val brigadeId = job.brigadeId ?: error("Brigada belgilanmagan")
        val shiftId = job.shiftId ?: error("Smena belgilanmagan")
        require(worker.brigadeId == brigadeId) { "Ishchi boshqa brigadaga tegishli" }
        require(receiverName.cleanText().isNotBlank()) { "Qabul qiluvchi ismini kiriting" }
        val carry = data.openRemainder(jobId, detailId)
        val credited = calculateReceiptCredit(output.bagCapacity, carry, completedBags, remainderAfter)
        val now = LocalDateTime.now().toString()
        val receipt = TpReceipt(
            id = UUID.randomUUID().toString(), jobId = job.id, orderId = job.orderId,
            detailId = output.detailId, detailNameSnapshot = output.detailName,
            machineId = machineId, workerId = worker.id, workerNameSnapshot = worker.name,
            brigadeId = brigadeId, shiftId = shiftId, date = date, colorCode = job.colorCode,
            completedBags = completedBags, bagCapacity = output.bagCapacity,
            carryInPieces = carry, remainderAfter = remainderAfter, creditedPieces = credited,
            unitPriceSnapshot = output.unitPrice, receiverName = receiverName.cleanText(), createdAt = now,
            piecesPerShotSnapshot = output.piecesPerShot
        )
        var updated = data.copy(
            receipts = data.receipts + receipt,
            jobs = data.jobs.map {
                if (it.id == jobId && it.status == TpJobStatus.QUEUED) it.copy(status = TpJobStatus.IN_PROGRESS, startedAt = it.startedAt ?: now) else it
            }
        )
        val produced = updated.receipts.filter { !it.isCancelled && it.jobId == jobId && it.detailId == detailId }.sumOf { it.creditedPieces }
        val allDone = job.outputs.all { planned ->
            updated.receipts.filter { !it.isCancelled && it.jobId == jobId && it.detailId == planned.detailId }.sumOf { it.creditedPieces } >= planned.requiredPieces
        }
        if (allDone) updated = updated.copy(jobs = updated.jobs.map { if (it.id == jobId) it.copy(status = TpJobStatus.COMPLETE) else it })
        updated = updated.refreshOrderStatus(job.orderId)
        updated.audit("TP_RECEIPT", brigadeId, date, "${output.detailName}: +$credited (jami $produced), qoldiq $remainderAfter")
    }

    fun updateReceipt(
        receiptId: String,
        workerId: String,
        date: String,
        completedBags: Int,
        remainderAfter: Int,
        editorName: String,
        reason: String
    ): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val current = data.receipts.firstOrNull { it.id == receiptId } ?: error("Qabul yozuvi topilmadi")
        val job = data.jobs.firstOrNull { it.id == current.jobId } ?: error("Vazifa topilmadi")
        val output = job.outputs.firstOrNull { it.detailId == current.detailId } ?: error("Detal topilmadi")
        val worker = data.workers.firstOrNull { it.id == workerId && !it.archived } ?: error("Ishchi topilmadi")
        require(worker.brigadeId == current.brigadeId) { "Ishchi boshqa brigadaga tegishli" }
        val cleanEditor = editorName.cleanText()
        val cleanReason = reason.cleanText()
        require(cleanEditor.isNotBlank()) { "Tahrir qiluvchi aniqlanmadi" }
        require(current.receiverName.equals(cleanEditor, true)) { "Faqat o‘zingiz qabul qilgan yozuvni tahrirlashingiz mumkin" }
        require(cleanReason.isNotBlank()) { "Tahrirlash izohi majburiy" }
        val now = LocalDateTime.now().toString()
        val baseUpdated = current.copy(
            workerId = worker.id, workerNameSnapshot = worker.name, date = date,
            completedBags = completedBags, remainderAfter = remainderAfter,
            updatedAt = now, updatedBy = cleanEditor, editReason = cleanReason
        )
        val chain = data.receipts.filter { !it.isCancelled && it.jobId == current.jobId && it.detailId == current.detailId }
            .map { if (it.id == receiptId) baseUpdated else it }
            .sortedBy { it.createdAt }
        var carry = 0
        val recalculated = chain.map { row ->
            val credited = calculateReceiptCredit(output.bagCapacity, carry, row.completedBags, row.remainderAfter)
            val fixed = row.copy(carryInPieces = carry, creditedPieces = credited)
            carry = row.remainderAfter
            fixed
        }
        val byId = recalculated.associateBy { it.id }
        val finalEdited = byId.getValue(receiptId)
        data.copy(receipts = data.receipts.map { byId[it.id] ?: it })
            .audit(
                "TP_RECEIPT_EDIT", current.brigadeId, date,
                "${current.detailNameSnapshot}: ${current.creditedPieces}→${finalEdited.creditedPieces} dona; ${current.workerNameSnapshot}→${worker.name}; sabab: $cleanReason"
            )
    }

    fun deleteReceipt(receiptId: String, editorName: String, reason: String): Result<Unit> = mutate { data ->
        val current = data.receipts.firstOrNull { it.id == receiptId } ?: error("Qabul yozuvi topilmadi")
        require(!current.isCancelled) { "Qabul yozuvi allaqachon bekor qilingan" }
        val cleanEditor = editorName.cleanText()
        val cleanReason = reason.cleanText()
        require(cleanEditor.isNotBlank()) { "Bekor qiluvchi aniqlanmadi" }
        require(current.receiverName.equals(cleanEditor, true)) { "Faqat o‘zingiz qabul qilgan yozuvni bekor qilishingiz mumkin" }
        require(cleanReason.isNotBlank()) { "Bekor qilish sababi majburiy" }
        val job = data.jobs.firstOrNull { it.id == current.jobId } ?: error("Vazifa topilmadi")
        val output = job.outputs.firstOrNull { it.detailId == current.detailId } ?: error("Detal topilmadi")
        val cancelled = current.copy(cancelledAt = LocalDateTime.now().toString(), cancelledBy = cleanEditor, cancelReason = cleanReason)
        val activeChain = data.receipts.filter { !it.isCancelled && it.jobId == current.jobId && it.detailId == current.detailId && it.id != receiptId }
            .sortedBy { it.createdAt }
        var carry = 0
        val recalculated = activeChain.map { row ->
            val credited = calculateReceiptCredit(output.bagCapacity, carry, row.completedBags, row.remainderAfter)
            val fixed = row.copy(carryInPieces = carry, creditedPieces = credited)
            carry = row.remainderAfter
            fixed
        }
        val byId = recalculated.associateBy { it.id }
        var updated = data.copy(receipts = data.receipts.map { row ->
            when {
                row.id == receiptId -> cancelled
                row.id in byId -> byId.getValue(row.id)
                else -> row
            }
        })
        val allDone = job.outputs.all { planned ->
            updated.receipts.filter { !it.isCancelled && it.jobId == job.id && it.detailId == planned.detailId }.sumOf { it.creditedPieces } >= planned.requiredPieces
        }
        if (!allDone && job.status == TpJobStatus.COMPLETE) {
            updated = updated.copy(jobs = updated.jobs.map { if (it.id == job.id) it.copy(status = TpJobStatus.IN_PROGRESS) else it })
        }
        updated = updated.refreshOrderStatus(job.orderId)
        updated.audit("TP_RECEIPT_CANCEL", current.brigadeId, current.date, "${current.detailNameSnapshot}: ${current.creditedPieces} dona; sabab: $cleanReason")
    }

    fun saveQualityRound(
        jobId: String,
        workerId: String,
        date: String,
        round: Int,
        score: Int,
        issue: String,
        checkedBy: String,
        absenceType: String = ""
    ): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val job = data.jobs.firstOrNull { it.id == jobId } ?: error("Vazifa topilmadi")
        val order = data.orders.firstOrNull { it.id == job.orderId } ?: error("Zakaz topilmadi")
        require(job.planConfirmedAt != null) { "Plan beruvchi avval shu detal rejasini tasdiqlasin" }
        val brigadeId = job.brigadeId ?: error("Brigada belgilanmagan")
        val shiftId = job.shiftId ?: error("Smena belgilanmagan")
        val machineId = job.machineId ?: error("Stanok belgilanmagan")
        require(data.workers.any { it.id == workerId && it.brigadeId == brigadeId }) { "Ishchini tanlang" }
        val absence = absenceType.trim().uppercase()
        require(absence in setOf("", "EXCUSED", "UNEXCUSED")) { "Ishchi holati noto‘g‘ri" }
        require(score in 0..100) { "Baho 0–100 oralig‘ida bo‘lsin" }
        if (absence == "EXCUSED") require(issue.cleanText().isNotBlank()) { "Sababli holatda izoh majburiy" }
        val shift = data.shifts.firstOrNull { it.id == shiftId } ?: error("Smena topilmadi")
        require(round in 1..shift.roundTimes.size) { "Raund raqami noto‘g‘ri" }
        val scheduled = LocalTime.parse(shift.roundTimes[round - 1])
        val selectedDate = LocalDate.parse(date)
        val nowDate = LocalDate.now()
        val nowTime = LocalTime.now()
        require(selectedDate == nowDate) { "Sifat raundi faqat amaldagi kunda baholanadi" }
        val scheduledMinutes = scheduled.hour * 60 + scheduled.minute
        val nowMinutes = nowTime.hour * 60 + nowTime.minute
        val signedDelta = ((nowMinutes - scheduledMinutes + 720 + 1440) % 1440) - 720
        val before = data.settings.qualityRoundBeforeMinutes.coerceIn(0, 240)
        val after = data.settings.qualityRoundAfterMinutes.coerceIn(0, 240)
        require(signedDelta in -before..after) {
            "Bu raund belgilangan vaqtdan $before daqiqa oldin va $after daqiqa keyingacha baholanadi"
        }
        require(checkedBy.cleanText().isNotBlank()) { "Tekshiruvchi ismini kiriting" }
        val id = "${jobId}_${workerId}_${date}_$round"
        val record = TpQualityRound(
            id, brigadeId, shiftId, machineId, workerId, jobId, date, round,
            shift.roundTimes[round - 1], if (absence == "UNEXCUSED") 0 else score, issue.cleanText(), checkedBy.cleanText(), LocalDateTime.now().toString(),
            absenceType = absence, excludedFromAverage = absence == "EXCUSED"
        )
        data.copy(qualityRounds = data.qualityRounds.filterNot { it.id == id } + record)
            .audit("TP_QUALITY", brigadeId, date, "${machineId}: $round / $score")
    }

    fun setQualityRoundWindowMinutes(minutes: Int): Result<Unit> =
        setQualityRoundWindowMinutes(minutes, minutes)

    fun setQualityRoundWindowMinutes(beforeMinutes: Int, afterMinutes: Int): Result<Unit> = mutate { data ->
        require(beforeMinutes in 0..240 && afterMinutes in 0..240) { "Sifat raundi oynasi 0–240 daqiqa oralig‘ida bo‘lsin" }
        require(beforeMinutes + afterMinutes > 0) { "Raund oynasi 0 daqiqa bo‘lib qolmasin" }
        data.copy(settings = data.settings.copy(
            qualityRoundWindowMinutes = maxOf(beforeMinutes, afterMinutes),
            qualityRoundBeforeMinutes = beforeMinutes,
            qualityRoundAfterMinutes = afterMinutes
        )).audit("TP_QUALITY_WINDOW", details = "-$beforeMinutes / +$afterMinutes daqiqa")
    }

    fun addDailyIssue(
        brigadeId: String, date: String, machineId: String?, orderId: String?, title: String, note: String,
        issueId: String = UUID.randomUUID().toString(), imageUrls: List<String> = emptyList(), imagePaths: List<String> = emptyList(),
        category: String = "", assignee: String = "", createdBy: String = ""
    ): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val cleanTitle = title.cleanText()
        val cleanNote = note.cleanText()
        require(cleanTitle.isNotBlank() && cleanNote.isNotBlank()) { "Muammo nomi va izohini kiriting" }
        require(data.brigades.any { it.id == brigadeId }) { "Brigadani tanlang" }
        val urls = imageUrls.filter { it.isNotBlank() }.distinct().take(10)
        val paths = imagePaths.filter { it.isNotBlank() }.distinct().take(10)
        require(urls.size <= 10 && paths.size <= 10) { "Bitta muammoga ko‘pi bilan 10 ta rasm qo‘shiladi" }
        val issue = TpDailyIssue(
            id = issueId, brigadeId = brigadeId, date = date, machineId = machineId, orderId = orderId,
            title = cleanTitle, note = cleanNote, createdAt = LocalDateTime.now().toString(),
            imageUrl = urls.firstOrNull().orEmpty(), imagePath = paths.firstOrNull().orEmpty(), imageUrls = urls, imagePaths = paths,
            status = TpDailyIssueStatus.NEW, category = category.cleanText(), assignee = assignee.cleanText(), createdBy = createdBy.cleanText()
        )
        data.copy(dailyIssues = data.dailyIssues + issue).audit("TP_DAILY_ISSUE", brigadeId, date, cleanTitle)
    }

    fun updateDailyIssueStatus(issueId: String, status: TpDailyIssueStatus, note: String = ""): Result<Unit> = mutate { data ->
        val issue = data.dailyIssues.firstOrNull { it.id == issueId } ?: error("Muammo topilmadi")
        val cleanNote = note.cleanText()
        if (status == TpDailyIssueStatus.CANCELLED) require(cleanNote.isNotBlank()) { "Bekor qilish sababini kiriting" }
        val now = LocalDateTime.now().toString()
        val updated = issue.copy(
            status = status,
            updatedAt = now,
            resolvedAt = if (status == TpDailyIssueStatus.RESOLVED) now else issue.resolvedAt,
            cancelledAt = if (status == TpDailyIssueStatus.CANCELLED) now else issue.cancelledAt,
            resolutionNote = cleanNote.ifBlank { issue.resolutionNote }
        )
        data.copy(dailyIssues = data.dailyIssues.map { if (it.id == issueId) updated else it })
            .audit("TP_DAILY_ISSUE_STATUS", issue.brigadeId, issue.date, "${issue.title}: ${status.name}${if (cleanNote.isNotBlank()) "; $cleanNote" else ""}")
    }

    fun replaceFromServer(data: TpData) = synchronized(RepositoryLock.monitor) {
        saveLocal(normalize(data))
        TpDataEvents.notifyChanged()
    }

    /** Merge a versioned portable backup without discarding newer local rows. Incoming rows win on matching IDs. */
    fun mergeFromBackup(incoming: TpData): TpData = synchronized(RepositoryLock.monitor) {
        val before = load()
        fun <T> merge(local: List<T>, remote: List<T>, id: (T) -> String): List<T> {
            val map = linkedMapOf<String, T>()
            local.forEach { map[id(it)] = it }
            remote.forEach { map[id(it)] = it }
            return map.values.toList()
        }
        val merged = normalize(before.copy(
            shops = merge(before.shops, incoming.shops) { it.id },
            shifts = merge(before.shifts, incoming.shifts) { it.id },
            brigades = merge(before.brigades, incoming.brigades) { it.id },
            machines = merge(before.machines, incoming.machines) { it.id },
            workers = merge(before.workers, incoming.workers) { it.id },
            products = merge(before.products, incoming.products) { it.id },
            materials = merge(before.materials, incoming.materials) { it.id },
            orders = merge(before.orders, incoming.orders) { it.id },
            jobs = merge(before.jobs, incoming.jobs) { it.id },
            attendance = merge(before.attendance, incoming.attendance) { it.id },
            receipts = merge(before.receipts, incoming.receipts) { it.id },
            qualityRounds = merge(before.qualityRounds, incoming.qualityRounds) { it.id },
            dailyIssues = merge(before.dailyIssues, incoming.dailyIssues) { it.id },
            extraHourTypes = merge(before.extraHourTypes, incoming.extraHourTypes) { it.id },
            extraHours = merge(before.extraHours, incoming.extraHours) { it.id },
            machineDowntimes = merge(before.machineDowntimes, incoming.machineDowntimes) { it.id },
            seryoCompensations = merge(before.seryoCompensations, incoming.seryoCompensations) { it.id },
            auditLog = merge(before.auditLog, incoming.auditLog) { it.id }.takeLast(3000),
            settings = incoming.settings
        ))
        saveLocal(merged)
        outbox.recordDiff(before, merged) { encodeForSync(before) }
        TpDataEvents.notifyChanged()
        FirebaseSyncScheduler.enqueue(appContext)
        merged
    }

    fun encodeForSync(data: TpData): String = encode(data).toString()
    fun decodeForSync(raw: String): TpData = normalize(decode(JSONObject(raw)))

    private fun validateDetail(data: TpData, detail: TpDetail) {
        require(detail.name.cleanText().isNotBlank()) { "Detal nomini kiriting" }
        require(detail.requiredPerProduct > 0 && detail.piecesPerShot > 0) { "Detal va jim sonlari 0 dan katta bo‘lsin" }
        require(detail.bagCapacity > 0) { "Qop sig‘imini kiriting" }
        require(detail.cycleSeconds > 0) { "Sikl vaqtini kiriting" }
        require(detail.grossShotWeightGrams > 0.0 && detail.unusableShotWeightGrams in 0.0..detail.grossShotWeightGrams) { "Og‘irlikni to‘g‘ri kiriting" }
        require(detail.resinOptions().isNotEmpty()) { "Kamida bitta seryo turini kiriting" }
        require(detail.unitPrice.isFinite() && detail.unitPrice >= 0.0) { "1 jim narxini to‘g‘ri kiriting" }
        require(detail.compatibleCapacities.isNotEmpty() && detail.compatibleCapacities.all { it > 0 }) { "Detal tushadigan stanok sig‘imlarini kiriting" }
        require(detail.colors.isNotEmpty()) { "Kamida bitta rang kiriting" }
        require(detail.colors.all { it.colorCode.isNotBlank() && it.share > 0.0 && it.gramsPer25Kg >= 0.0 }) { "Rang taqsimoti noto‘g‘ri" }
        require(detail.colors.map { it.colorCode.trim().uppercase(Locale.ROOT) }.distinct().size == detail.colors.size) { "Bir detalda rang kodi takrorlanmasin" }
    }

    private fun TpData.withMaterialMovement(
        type: TpMaterialType,
        code: String,
        kind: TpMaterialMovementKind,
        amount: Double,
        note: String,
        sourceJobId: String? = null,
        sourceKind: TpMaterialSourceKind = TpMaterialSourceKind.MANUAL,
        sourceMachineId: String? = null,
        sourceShopId: String? = null,
        sourceArea: String = "",
        productId: String? = null,
        detailId: String? = null,
        createdBy: String = "",
        allowNegativeStock: Boolean = false,
        createMissingMaterial: Boolean = false
    ): TpData {
        val normalizedCode = code.trim().uppercase(Locale.ROOT)
        require(normalizedCode.isNotBlank()) { "Materialni tanlang" }
        val normalizedAmount = if (type == TpMaterialType.COLOR) {
            require(amount.isFinite() && amount > 0.0) { "Miqdorni to‘g‘ri kiriting" }
            amount
        } else normalizeFeedstockKg(amount).also { require(it > 0.0) { "Miqdorni to‘g‘ri kiriting" } }

        val product = productId?.let { id -> products.firstOrNull { it.id == id } }
        val detail = detailId?.let { id -> products.asSequence().flatMap { it.details.asSequence() }.firstOrNull { it.id == id } }
        val movement = TpMaterialMovement(
            id = UUID.randomUUID().toString(), kind = kind, amount = normalizedAmount,
            createdAt = LocalDateTime.now().toString(), note = note.cleanText(), sourceJobId = sourceJobId,
            sourceKind = sourceKind, sourceMachineId = sourceMachineId, sourceShopId = sourceShopId,
            sourceArea = sourceArea.cleanText(), productId = productId, detailId = detailId,
            articleSnapshot = product?.article.orEmpty(), productNameSnapshot = product?.name.orEmpty(),
            detailNameSnapshot = detail?.name.orEmpty(), createdBy = createdBy.cleanText()
        )

        val material = materials.firstOrNull { !it.archived && it.type == type && it.code.equals(normalizedCode, true) }
        if (material == null) {
            require(createMissingMaterial) {
                "${type.displayName()} turi topilmadi: $normalizedCode. Avval Excel orqali materiallarni import qiling"
            }
            // Seryo brigadiri real xomashyoni bergan bo‘lsa, Excel ostatka hali kiritilmagan
            // holatda ham oldi-berdi yo‘qolmasligi kerak. 0 dan OUT yozuvi yaratiladi va ostatka
            // manfiy qiymatga tushadi. Keyingi Excel import shu kodning boshlang‘ich ostatkasini
            // yangilaydi, movement tarixi esa saqlanib qoladi.
            val created = TpMaterial(
                id = UUID.randomUUID().toString(),
                code = normalizedCode,
                name = normalizedCode,
                type = type,
                availableAmount = 0.0,
                archived = false,
                movements = listOf(movement)
            )
            return copy(materials = materials + created)
        }

        if (kind == TpMaterialMovementKind.OUT && !allowNegativeStock) {
            require(material.currentStock() + 1e-9 >= normalizedAmount) {
                "$normalizedCode ostatkasi yetarli emas: ${formatTpNumber(material.currentStock())} ${type.unitLabel()}"
            }
        }
        return copy(materials = materials.map { item ->
            if (item.id == material.id) item.copy(movements = item.movements + movement) else item
        })
    }

    private fun TpData.refreshOrderStatus(orderId: String): TpData {
        val orderJobs = jobs.filter { it.orderId == orderId }
        val order = orders.firstOrNull { it.id == orderId } ?: return this
        if (order.status == TpOrderStatus.CANCELLED) return this
        // Business completion is receipt-driven: a machine task being marked complete is not enough.
        val receiptComplete = orderJobs.isNotEmpty() && orderProgress(orderId) >= 99.999
        val realMoldingStarted = orderJobs.any { !it.startedAt.isNullOrBlank() }
        val status = when {
            receiptComplete -> TpOrderStatus.COMPLETE
            realMoldingStarted -> TpOrderStatus.IN_PROGRESS
            order.planApprovedAt != null -> TpOrderStatus.APPROVED
            orderJobs.isNotEmpty() && orderJobs.all { it.machineId != null } -> TpOrderStatus.READY
            orderJobs.isNotEmpty() -> TpOrderStatus.PLANNING
            else -> TpOrderStatus.NEW
        }
        val completedAt = if (status == TpOrderStatus.COMPLETE) (order.completedAt ?: LocalDateTime.now().toString()) else null
        return copy(orders = orders.map { if (it.id == orderId) it.copy(status = status, completedAt = completedAt) else it })
    }

    private fun TpData.audit(action: String, brigadeId: String? = null, recordDate: String? = null, details: String): TpData = copy(
        auditLog = (auditLog + TpAuditEntry(UUID.randomUUID().toString(), action, brigadeId, recordDate, details, LocalDateTime.now().toString())).takeLast(3000)
    )

    fun resetTpForFreshImportLocal() = synchronized(RepositoryLock.monitor) {
        val current = load()
        val currentTarget = current.globalDailyTargetAmount()
        val clean = defaultData().copy(
            shops = current.shops,
            shifts = current.shifts,
            brigades = current.brigades.map { it.copy(archived = true) },
            settings = TpSettings(dailyTargetAmount = currentTarget)
        )
        saveLocal(clean)
        outbox.clear()
        outbox.recordDiff(current, clean) { encodeForSync(current) }
        TpDataEvents.notifyChanged()
        FirebaseSyncScheduler.enqueue(appContext)
    }

    private fun mutate(block: (TpData) -> TpData): Result<Unit> = runCatching { synchronized(RepositoryLock.monitor) {
        val before = load()
        val after = normalize(block(before))
        accessGuard.validate(before, after)
        saveLocal(after)
        outbox.recordDiff(before, after) { encodeForSync(before) }
        TpDataEvents.notifyChanged()
        FirebaseSyncScheduler.enqueue(appContext)
    } }

    private fun saveLocal(data: TpData) {
        val raw = encode(data).toString()
        ToyBolaRoomStore.dao(appContext).put(AppSnapshotEntity(ToyBolaRoomStore.TP_KEY, raw, System.currentTimeMillis()))
        // 0.12 dual-write keeps rollback compatibility while Room migration settles.
        prefs.edit().putString(KEY_DATA, raw).commit()
    }

    private fun normalize(data: TpData): TpData {
        val resolvedDailyTarget = data.settings.dailyTargetAmount.takeIf { it > 0L }
            ?: data.workers.firstOrNull { it.dailyTargetAmount > 0L }?.dailyTargetAmount
            ?: 100_000L
        return data.copy(
        shops = data.shops.distinctBy { it.id }, shifts = data.shifts.distinctBy { it.id },
        brigades = data.brigades.distinctBy { it.id }, machines = data.machines.distinctBy { it.id },
        products = data.products.distinctBy { it.id },
        materials = data.materials.distinctBy { it.id }.map { it.copy(movements = it.movements.distinctBy { movement -> movement.id }) }, orders = data.orders.distinctBy { it.id },
        jobs = data.jobs.distinctBy { it.id }.map { it.copy(materialBatches = it.materialBatches.distinctBy { batch -> batch.id }) },
        attendance = data.attendance.distinctBy { it.id },
        receipts = data.receipts.distinctBy { it.id }, qualityRounds = data.qualityRounds.distinctBy { it.id },
        dailyIssues = data.dailyIssues.distinctBy { it.id },
        extraHourTypes = data.extraHourTypes.distinctBy { it.id },
        extraHours = data.extraHours.distinctBy { it.id },
        machineDowntimes = data.machineDowntimes.distinctBy { it.id },
        seryoCompensations = data.seryoCompensations.distinctBy { it.id }.map { it.copy(batches = it.batches.distinctBy { batch -> batch.id }) },
        auditLog = data.auditLog.distinctBy { it.id }.takeLast(3000),
        workers = data.workers.distinctBy { it.id }.map { it.copy(dailyTargetAmount = 0L, defaultWorkMinutes = 0) },
        settings = data.settings.copy(dailyTargetAmount = resolvedDailyTarget)
    )
    }

    private fun defaultData(): TpData {
        val shops = (1..3).map { TpShop("tp-shop-$it", "$it-sex") }
        val shifts = listOf(
            TpShift("tp-shift-day", "Kunduzgi", "07:40", "19:00", listOf("10:00", "13:00", "16:00")),
            TpShift("tp-shift-night", "Tungi", "19:00", "07:00", listOf("22:00", "02:00"))
        )
        return TpData(shops = shops, shifts = shifts, settings = TpSettings(dailyTargetAmount = 100_000L))
    }

    private fun encode(data: TpData): JSONObject = JSONObject().apply {
        put("shops", array(data.shops) { o, item -> o.put("id", item.id).put("name", item.name).put("archived", item.archived) })
        put("shifts", array(data.shifts) { o, item -> o.put("id", item.id).put("name", item.name).put("startTime", item.startTime).put("endTime", item.endTime).put("roundTimes", strings(item.roundTimes)).put("archived", item.archived) })
        put("brigades", array(data.brigades) { o, item -> o.put("id", item.id).put("shopId", item.shopId).put("shiftId", item.shiftId).put("name", item.name).put("archived", item.archived) })
        put("machines", array(data.machines) { o, item -> o.put("id", item.id).put("shopId", item.shopId).put("number", item.number).put("name", item.name).put("archived", item.archived).put("capacity", item.capacity) })
        put("workers", array(data.workers) { o, item -> o.put("id", item.id).put("brigadeId", item.brigadeId).put("name", item.name).put("dailyTargetAmount", item.dailyTargetAmount).put("archived", item.archived) })
        put("products", array(data.products) { o, product ->
            o.put("id", product.id).put("article", product.article).put("name", product.name).put("archived", product.archived)
                .put("details", array(product.details) { d, detail ->
                    d.put("id", detail.id).put("name", detail.name).put("moldCode", detail.moldCode)
                        .put("requiredPerProduct", detail.requiredPerProduct).put("piecesPerShot", detail.piecesPerShot)
                        .put("bagCapacity", detail.bagCapacity).put("cycleSeconds", detail.cycleSeconds)
                        .put("grossShotWeightGrams", detail.grossShotWeightGrams).put("unusableShotWeightGrams", detail.unusableShotWeightGrams)
                        .put("resinCode", detail.resinCode).put("resinCodes", strings(detail.resinOptions())).put("recycledCodes", strings(detail.recycledOptions())).put("unitPrice", detail.unitPrice)
                        .put("compatibleMachineIds", strings(emptySet<String>()))
                        .put("compatibleCapacities", JSONArray().apply { detail.compatibleCapacities.sorted().forEach { value -> put(value) } })
                        .put("colors", array(detail.colors) { c, color -> c.put("colorCode", color.colorCode).put("share", color.share).put("gramsPer25Kg", color.gramsPer25Kg) })
                        .put("archived", detail.archived)
                })
        })
        put("materials", array(data.materials) { o, item ->
            o.put("id", item.id).put("code", item.code).put("name", item.name).put("type", item.type.name)
                .put("availableAmount", item.availableAmount).put("archived", item.archived)
                .put("movements", array(item.movements) { m, movement ->
                    m.put("id", movement.id).put("kind", movement.kind.name).put("amount", movement.amount)
                        .put("createdAt", movement.createdAt).put("note", movement.note).putNullable("sourceJobId", movement.sourceJobId)
                        .put("sourceKind", movement.sourceKind.name).putNullable("sourceMachineId", movement.sourceMachineId)
                        .putNullable("sourceShopId", movement.sourceShopId).put("sourceArea", movement.sourceArea)
                        .putNullable("productId", movement.productId).putNullable("detailId", movement.detailId)
                        .put("articleSnapshot", movement.articleSnapshot).put("productNameSnapshot", movement.productNameSnapshot)
                        .put("detailNameSnapshot", movement.detailNameSnapshot).put("createdBy", movement.createdBy)
                })
        })
        put("orders", array(data.orders) { o, order ->
            o.put("id", order.id).put("batchNumber", order.batchNumber).put("productId", order.productId)
                .put("articleSnapshot", order.articleSnapshot).put("productNameSnapshot", order.productNameSnapshot)
                .put("quantity", order.quantity).put("priority", order.priority).put("requestedDate", order.requestedDate)
                .put("note", order.note).put("status", order.status.name).put("createdAt", order.createdAt)
            if (order.completedAt == null) o.put("completedAt", JSONObject.NULL) else o.put("completedAt", order.completedAt)
            if (order.planApprovedAt == null) o.put("planApprovedAt", JSONObject.NULL) else o.put("planApprovedAt", order.planApprovedAt)
            o.putNullable("cancelledAt", order.cancelledAt).put("cancelReason", order.cancelReason).put("cancelledBy", order.cancelledBy)
        })
        put("jobs", array(data.jobs) { o, job ->
            o.put("id", job.id).put("orderId", job.orderId).put("moldCode", job.moldCode).put("colorCode", job.colorCode)
                .put("outputs", array(job.outputs) { d, output -> d.put("detailId", output.detailId).put("detailName", output.detailName).put("requiredPieces", output.requiredPieces).put("plannedPieces", output.plannedPieces).put("piecesPerShot", output.piecesPerShot).put("bagCapacity", output.bagCapacity).put("unitPrice", output.unitPrice) })
                .put("requiredShots", job.requiredShots).put("cycleSeconds", job.cycleSeconds).put("estimatedMinutes", job.estimatedMinutes)
                .put("resinCode", job.resinCode).put("requiredResinKg", job.requiredResinKg).put("requiredColorGrams", job.requiredColorGrams)
                .put("compatibleMachineIds", strings(job.compatibleMachineIds)).putNullable("machineId", job.machineId)
                .putNullable("brigadeId", job.brigadeId).putNullable("shiftId", job.shiftId).put("priority", job.priority)
                .put("status", job.status.name).put("materialStatus", job.materialStatus.name)
                .putNullable("planConfirmedAt", job.planConfirmedAt).putNullable("planEditedAt", job.planEditedAt).put("planEditReason", job.planEditReason)
                .put("alternativeResin", job.alternativeResin).put("feedstockType", job.feedstockType.name)
                .put("resinAdditions", array(job.resinAdditions) { a, extra ->
                    a.put("id", extra.id).put("resinCode", extra.resinCode).put("kilograms", extra.kilograms)
                        .put("kind", extra.kind.name).put("createdAt", extra.createdAt).put("createdBy", extra.createdBy)
                })
                .put("materialBatches", array(job.materialBatches) { b, batch ->
                    b.put("id", batch.id).put("feedstockType", batch.feedstockType.name).put("feedstockCode", batch.feedstockCode)
                        .put("feedstockKg", batch.feedstockKg).put("colorCode", batch.colorCode).put("colorGrams", batch.colorGrams)
                        .put("createdAt", batch.createdAt).put("createdBy", batch.createdBy)
                })
                .putNullable("resinSelectedAt", job.resinSelectedAt).putNullable("resinConfirmedAt", job.resinConfirmedAt).put("materialShortageOverride", job.materialShortageOverride)
                .putNullable("materialConfirmedAt", job.materialConfirmedAt).putNullable("materialDeliveredAt", job.materialDeliveredAt)
                .putNullable("startedAt", job.startedAt)
                .put("machineOverride", job.machineOverride).put("machineOverrideReason", job.machineOverrideReason).putNullable("machineOverrideAt", job.machineOverrideAt)
        })
        put("attendance", array(data.attendance) { o, item -> o.put("id", item.id).put("workerId", item.workerId).put("brigadeId", item.brigadeId).put("shiftId", item.shiftId).put("date", item.date).put("present", item.present).put("workMinutes", item.workMinutes).put("updatedAt", item.updatedAt).put("minusHours", item.minusHours) })
        put("receipts", array(data.receipts) { o, receipt ->
            o.put("id", receipt.id).put("jobId", receipt.jobId).put("orderId", receipt.orderId).put("detailId", receipt.detailId)
                .put("detailNameSnapshot", receipt.detailNameSnapshot).put("machineId", receipt.machineId).put("workerId", receipt.workerId)
                .put("workerNameSnapshot", receipt.workerNameSnapshot).put("brigadeId", receipt.brigadeId).put("shiftId", receipt.shiftId)
                .put("date", receipt.date).put("colorCode", receipt.colorCode).put("completedBags", receipt.completedBags)
                .put("bagCapacity", receipt.bagCapacity).put("carryInPieces", receipt.carryInPieces).put("remainderAfter", receipt.remainderAfter)
                .put("creditedPieces", receipt.creditedPieces).put("unitPriceSnapshot", receipt.unitPriceSnapshot)
                .put("receiverName", receipt.receiverName).put("createdAt", receipt.createdAt)
                .put("piecesPerShotSnapshot", receipt.piecesPerShotSnapshot)
                .putNullable("updatedAt", receipt.updatedAt).put("updatedBy", receipt.updatedBy).put("editReason", receipt.editReason)
                .putNullable("cancelledAt", receipt.cancelledAt).put("cancelledBy", receipt.cancelledBy).put("cancelReason", receipt.cancelReason)
        })
        put("qualityRounds", array(data.qualityRounds) { o, item -> o.put("id", item.id).put("brigadeId", item.brigadeId).put("shiftId", item.shiftId).put("machineId", item.machineId).put("workerId", item.workerId).put("jobId", item.jobId).put("date", item.date).put("round", item.round).put("scheduledTime", item.scheduledTime).put("score", item.score).put("issue", item.issue).put("checkedBy", item.checkedBy).put("checkedAt", item.checkedAt).put("absenceType", item.absenceType).put("excludedFromAverage", item.excludedFromAverage) })
        put("dailyIssues", array(data.dailyIssues) { o, item ->
            o.put("id", item.id).put("brigadeId", item.brigadeId).put("date", item.date).putNullable("machineId", item.machineId).putNullable("orderId", item.orderId)
                .put("title", item.title).put("note", item.note).put("createdAt", item.createdAt)
                .put("imageUrl", item.imageUrl).put("imagePath", item.imagePath)
                .put("imageUrls", strings(item.allImageUrls())).put("imagePaths", strings(item.allImagePaths()))
                .put("status", item.status.name).put("category", item.category).put("assignee", item.assignee).put("createdBy", item.createdBy)
                .putNullable("updatedAt", item.updatedAt).putNullable("resolvedAt", item.resolvedAt).putNullable("cancelledAt", item.cancelledAt)
                .put("resolutionNote", item.resolutionNote)
        })
        put("extraHourTypes", array(data.extraHourTypes) { o, item ->
            o.put("id", item.id).put("name", item.name).put("hourlyRate", item.hourlyRate).put("archived", item.archived)
        })
        put("extraHours", array(data.extraHours) { o, item ->
            o.put("id", item.id).put("workerId", item.workerId).put("brigadeId", item.brigadeId).put("date", item.date)
                .put("typeId", item.typeId).put("typeNameSnapshot", item.typeNameSnapshot).put("hours", item.hours)
                .put("hourlyRateSnapshot", item.hourlyRateSnapshot).put("note", item.note).put("createdAt", item.createdAt)
        })
        put("machineDowntimes", array(data.machineDowntimes) { o, item ->
            o.put("id", item.id).put("machineId", item.machineId).put("brigadeId", item.brigadeId).put("date", item.date)
                .put("stoppedAt", item.stoppedAt).put("startedAt", item.startedAt).put("reason", item.reason).put("createdAt", item.createdAt)
        })
        put("seryoCompensations", array(data.seryoCompensations) { o, item ->
            o.put("id", item.id).put("machineId", item.machineId).put("shopId", item.shopId).putNullable("sourceJobId", item.sourceJobId)
                .put("productId", item.productId).put("detailId", item.detailId).put("articleSnapshot", item.articleSnapshot)
                .put("productNameSnapshot", item.productNameSnapshot).put("detailNameSnapshot", item.detailNameSnapshot)
                .put("colorCode", item.colorCode).put("targetKg", item.targetKg).put("defaultFeedstockType", item.defaultFeedstockType.name)
                .put("defaultFeedstockCode", item.defaultFeedstockCode).put("createdAt", item.createdAt).put("createdBy", item.createdBy)
                .putNullable("completedAt", item.completedAt)
                .put("batches", array(item.batches) { b, batch ->
                    b.put("id", batch.id).put("feedstockType", batch.feedstockType.name).put("feedstockCode", batch.feedstockCode)
                        .put("feedstockKg", batch.feedstockKg).put("colorCode", batch.colorCode).put("colorGrams", batch.colorGrams)
                        .put("createdAt", batch.createdAt).put("createdBy", batch.createdBy)
                })
        })
        put("auditLog", array(data.auditLog) { o, item -> o.put("id", item.id).put("action", item.action).putNullable("brigadeId", item.brigadeId).putNullable("recordDate", item.recordDate).put("details", item.details).put("createdAt", item.createdAt) })
        put("settings", JSONObject()
            .put("firstBatchEntered", data.settings.firstBatchEntered)
            .put("priceRevision", data.settings.priceRevision)
            .put("dailyTargetAmount", data.globalDailyTargetAmount())
            .put("qualityRoundWindowMinutes", data.settings.qualityRoundWindowMinutes)
            .put("qualityRoundBeforeMinutes", data.settings.qualityRoundBeforeMinutes)
            .put("qualityRoundAfterMinutes", data.settings.qualityRoundAfterMinutes))
    }

    private fun decode(root: JSONObject): TpData = TpData(
        shops = root.arr("shops").objects().map { TpShop(it.text("id"), it.text("name"), it.optBoolean("archived")) },
        shifts = root.arr("shifts").objects().map { TpShift(it.text("id"), it.text("name"), it.text("startTime", "07:40"), it.text("endTime", "19:00"), it.arr("roundTimes").stringValues(), it.optBoolean("archived")) },
        brigades = root.arr("brigades").objects().map { TpBrigade(it.text("id"), it.text("shopId"), it.text("shiftId"), it.text("name"), it.optBoolean("archived")) },
        machines = root.arr("machines").objects().map { TpMachine(it.text("id"), it.text("shopId"), it.optInt("number"), it.text("name"), it.optBoolean("archived"), it.optInt("capacity", 0)) },
        workers = root.arr("workers").objects().map { TpWorker(it.text("id"), it.text("brigadeId"), it.text("name"), it.optLong("dailyTargetAmount"), it.optInt("defaultWorkMinutes", 0), it.optBoolean("archived")) },
        products = root.arr("products").objects().map { product ->
            TpProduct(product.text("id"), product.text("article"), product.text("name"), product.arr("details").objects().map { detail ->
                TpDetail(
                    id = detail.text("id"), name = detail.text("name"), moldCode = detail.text("moldCode"),
                    requiredPerProduct = detail.optInt("requiredPerProduct"), piecesPerShot = detail.optInt("piecesPerShot"),
                    bagCapacity = detail.optInt("bagCapacity"), cycleSeconds = detail.optInt("cycleSeconds"),
                    grossShotWeightGrams = detail.optDouble("grossShotWeightGrams"), unusableShotWeightGrams = detail.optDouble("unusableShotWeightGrams"),
                    resinCode = detail.text("resinCode"), unitPrice = detail.optDouble("unitPrice"),
                    compatibleMachineIds = emptySet(),
                    compatibleCapacities = detail.arr("compatibleCapacities").intValues().filter { it > 0 }.toSet(),
                    colors = detail.arr("colors").objects().map { TpColorRule(it.text("colorCode"), it.optDouble("share"), it.optDouble("gramsPer25Kg")) },
                    archived = detail.optBoolean("archived"),
                    resinCodes = detail.arr("resinCodes").stringValues().ifEmpty { listOf(detail.text("resinCode")) },
                    recycledCodes = detail.arr("recycledCodes").stringValues()
                )
            }, product.optBoolean("archived"))
        },
        materials = root.arr("materials").objects().map { material ->
            TpMaterial(
                id = material.text("id"), code = material.text("code"), name = material.text("name", material.text("code")),
                type = material.enum("type", TpMaterialType.RESIN), availableAmount = material.optDouble("availableAmount"),
                archived = material.optBoolean("archived"), movements = material.arr("movements").objects().map { movement ->
                    TpMaterialMovement(
                        id = movement.text("id"), kind = movement.enum("kind", TpMaterialMovementKind.IN),
                        amount = movement.optDouble("amount"), createdAt = movement.text("createdAt"),
                        note = movement.text("note"), sourceJobId = movement.nullableText("sourceJobId"),
                        sourceKind = movement.enum("sourceKind", TpMaterialSourceKind.MANUAL),
                        sourceMachineId = movement.nullableText("sourceMachineId"), sourceShopId = movement.nullableText("sourceShopId"),
                        sourceArea = movement.text("sourceArea"), productId = movement.nullableText("productId"), detailId = movement.nullableText("detailId"),
                        articleSnapshot = movement.text("articleSnapshot"), productNameSnapshot = movement.text("productNameSnapshot"),
                        detailNameSnapshot = movement.text("detailNameSnapshot"), createdBy = movement.text("createdBy")
                    )
                }
            )
        },
        orders = root.arr("orders").objects().map { TpOrder(it.text("id"), it.text("batchNumber"), it.text("productId"), it.text("articleSnapshot"), it.text("productNameSnapshot"), it.optInt("quantity"), it.optInt("priority", 1), it.text("requestedDate", isoToday()), it.text("note"), it.enum("status", TpOrderStatus.NEW), it.text("createdAt"), it.nullableText("completedAt"), it.nullableText("planApprovedAt"), it.nullableText("cancelledAt"), it.text("cancelReason"), it.text("cancelledBy")) },
        jobs = root.arr("jobs").objects().map { job ->
            TpPlanJob(
                id = job.text("id"), orderId = job.text("orderId"), moldCode = job.text("moldCode"), colorCode = job.text("colorCode"),
                outputs = job.arr("outputs").objects().map { TpJobOutput(it.text("detailId"), it.text("detailName"), it.optInt("requiredPieces"), it.optInt("plannedPieces"), it.optInt("piecesPerShot"), it.optInt("bagCapacity"), it.optDouble("unitPrice")) },
                requiredShots = job.optInt("requiredShots"), cycleSeconds = job.optInt("cycleSeconds"), estimatedMinutes = job.optInt("estimatedMinutes"),
                resinCode = job.text("resinCode"), requiredResinKg = job.optDouble("requiredResinKg"), requiredColorGrams = job.optDouble("requiredColorGrams"),
                compatibleMachineIds = job.arr("compatibleMachineIds").stringValues().toSet(), machineId = job.nullableText("machineId"),
                brigadeId = job.nullableText("brigadeId"), shiftId = job.nullableText("shiftId"), priority = job.optInt("priority"),
                status = job.enum("status", TpJobStatus.UNASSIGNED), materialStatus = job.enum("materialStatus", TpMaterialStatus.PLANNED),
                planConfirmedAt = job.nullableText("planConfirmedAt"), planEditedAt = job.nullableText("planEditedAt"), planEditReason = job.text("planEditReason"),
                alternativeResin = job.optBoolean("alternativeResin"),
                feedstockType = job.enum("feedstockType", TpMaterialType.RESIN),
                resinAdditions = job.arr("resinAdditions").objects().map { extra ->
                    TpResinAddition(extra.text("id"), extra.text("resinCode"), extra.optDouble("kilograms"),
                        extra.enum("kind", TpResinAdditionKind.MANUAL), extra.text("createdAt"), extra.text("createdBy"))
                },
                materialBatches = job.arr("materialBatches").objects().map { batch ->
                    TpMaterialBatch(
                        id = batch.text("id"), feedstockType = batch.enum("feedstockType", TpMaterialType.RESIN),
                        feedstockCode = batch.text("feedstockCode"), feedstockKg = batch.optDouble("feedstockKg"),
                        colorCode = batch.text("colorCode"), colorGrams = batch.optDouble("colorGrams"),
                        createdAt = batch.text("createdAt"), createdBy = batch.text("createdBy")
                    )
                },
                resinSelectedAt = job.nullableText("resinSelectedAt"), resinConfirmedAt = job.nullableText("resinConfirmedAt"), materialShortageOverride = job.optBoolean("materialShortageOverride", false),
                materialConfirmedAt = job.nullableText("materialConfirmedAt"), materialDeliveredAt = job.nullableText("materialDeliveredAt"),
                startedAt = job.nullableText("startedAt"),
                machineOverride = job.optBoolean("machineOverride", false), machineOverrideReason = job.text("machineOverrideReason"), machineOverrideAt = job.nullableText("machineOverrideAt")
            )
        },
        attendance = root.arr("attendance").objects().map { TpAttendance(it.text("id"), it.text("workerId"), it.text("brigadeId"), it.text("shiftId"), it.text("date"), it.optBoolean("present"), it.optInt("workMinutes"), it.text("updatedAt"), if (it.has("minusHours")) it.optDouble("minusHours") else -1.0) },
        receipts = root.arr("receipts").objects().map { TpReceipt(
            it.text("id"), it.text("jobId"), it.text("orderId"), it.text("detailId"), it.text("detailNameSnapshot"), it.text("machineId"),
            it.text("workerId"), it.text("workerNameSnapshot"), it.text("brigadeId"), it.text("shiftId"), it.text("date"), it.text("colorCode"),
            it.optInt("completedBags"), it.optInt("bagCapacity"), it.optInt("carryInPieces"), it.optInt("remainderAfter"), it.optInt("creditedPieces"),
            it.optDouble("unitPriceSnapshot"), it.text("receiverName"), it.text("createdAt"), it.optInt("piecesPerShotSnapshot", 1).coerceAtLeast(1),
            it.nullableText("updatedAt"), it.text("updatedBy"), it.text("editReason"),
            it.nullableText("cancelledAt"), it.text("cancelledBy"), it.text("cancelReason")
        ) },
        qualityRounds = root.arr("qualityRounds").objects().map { TpQualityRound(it.text("id"), it.text("brigadeId"), it.text("shiftId"), it.text("machineId"), it.text("workerId"), it.text("jobId"), it.text("date"), it.optInt("round"), it.text("scheduledTime"), it.optInt("score"), it.text("issue"), it.text("checkedBy"), it.text("checkedAt"), it.text("absenceType"), it.optBoolean("excludedFromAverage")) },
        dailyIssues = root.arr("dailyIssues").objects().map { issue ->
            val legacyUrl = issue.text("imageUrl")
            val legacyPath = issue.text("imagePath")
            val urls = issue.arr("imageUrls").stringValues().ifEmpty { listOfNotNull(legacyUrl.takeIf { it.isNotBlank() }) }
            val paths = issue.arr("imagePaths").stringValues().ifEmpty { listOfNotNull(legacyPath.takeIf { it.isNotBlank() }) }
            TpDailyIssue(
                issue.text("id"), issue.text("brigadeId"), issue.text("date"), issue.nullableText("machineId"), issue.nullableText("orderId"),
                issue.text("title"), issue.text("note"), issue.text("createdAt"), legacyUrl, legacyPath, urls, paths,
                issue.enum("status", TpDailyIssueStatus.NEW), issue.text("category"), issue.text("assignee"), issue.text("createdBy"),
                issue.nullableText("updatedAt"), issue.nullableText("resolvedAt"), issue.nullableText("cancelledAt"), issue.text("resolutionNote")
            )
        },
        extraHourTypes = root.arr("extraHourTypes").objects().map {
            TpExtraHourType(it.text("id"), it.text("name"), it.optDouble("hourlyRate"), it.optBoolean("archived"))
        },
        extraHours = root.arr("extraHours").objects().map {
            TpWorkerExtraHour(it.text("id"), it.text("workerId"), it.text("brigadeId"), it.text("date"), it.text("typeId"),
                it.text("typeNameSnapshot"), it.optDouble("hours"), it.optDouble("hourlyRateSnapshot"), it.text("note"), it.text("createdAt"))
        },
        machineDowntimes = root.arr("machineDowntimes").objects().map {
            TpMachineDowntime(it.text("id"), it.text("machineId"), it.text("brigadeId"), it.text("date"),
                it.text("stoppedAt"), it.text("startedAt"), it.text("reason"), it.text("createdAt"))
        },
        seryoCompensations = root.arr("seryoCompensations").objects().map { item ->
            TpSeryoCompensationOrder(
                id = item.text("id"), machineId = item.text("machineId"), shopId = item.text("shopId"),
                sourceJobId = item.nullableText("sourceJobId"), productId = item.text("productId"), detailId = item.text("detailId"),
                articleSnapshot = item.text("articleSnapshot"), productNameSnapshot = item.text("productNameSnapshot"),
                detailNameSnapshot = item.text("detailNameSnapshot"), colorCode = item.text("colorCode"),
                targetKg = item.optDouble("targetKg"), defaultFeedstockType = item.enum("defaultFeedstockType", TpMaterialType.RESIN),
                defaultFeedstockCode = item.text("defaultFeedstockCode"),
                batches = item.arr("batches").objects().map { batch ->
                    TpMaterialBatch(
                        id = batch.text("id"), feedstockType = batch.enum("feedstockType", TpMaterialType.RESIN),
                        feedstockCode = batch.text("feedstockCode"), feedstockKg = batch.optDouble("feedstockKg"),
                        colorCode = batch.text("colorCode"), colorGrams = batch.optDouble("colorGrams"),
                        createdAt = batch.text("createdAt"), createdBy = batch.text("createdBy")
                    )
                },
                createdAt = item.text("createdAt"), createdBy = item.text("createdBy"), completedAt = item.nullableText("completedAt")
            )
        },
        auditLog = root.arr("auditLog").objects().map { TpAuditEntry(it.text("id"), it.text("action"), it.nullableText("brigadeId"), it.nullableText("recordDate"), it.text("details"), it.text("createdAt")) },
        settings = root.optJSONObject("settings")?.let { rawSettings ->
            val legacyWindow = rawSettings.optInt("qualityRoundWindowMinutes", 60).coerceIn(0, 240)
            TpSettings(
                firstBatchEntered = rawSettings.optBoolean("firstBatchEntered"),
                priceRevision = rawSettings.optInt("priceRevision"),
                dailyTargetAmount = rawSettings.optLong("dailyTargetAmount"),
                qualityRoundWindowMinutes = legacyWindow,
                qualityRoundBeforeMinutes = rawSettings.optInt("qualityRoundBeforeMinutes", legacyWindow).coerceIn(0, 240),
                qualityRoundAfterMinutes = rawSettings.optInt("qualityRoundAfterMinutes", legacyWindow).coerceIn(0, 240)
            )
        } ?: TpSettings()
    )

    private fun <T> array(values: Iterable<T>, block: (JSONObject, T) -> Unit): JSONArray = JSONArray().apply {
        values.forEach { value -> put(JSONObject().also { block(it, value) }) }
    }

    private fun strings(values: Iterable<String>): JSONArray = JSONArray().apply { values.forEach { value -> put(value) } }
    private fun JSONArray.intValues(): List<Int> = (0 until length()).mapNotNull { index -> optInt(index).takeIf { it > 0 } }
    private fun JSONObject.putNullable(key: String, value: String?): JSONObject = put(key, value ?: JSONObject.NULL)

    companion object {
        private const val PREFS_NAME = "toy_bola_tp_data_v1"
        private const val KEY_DATA = "tp_data"
    }
}

private fun String.cleanText(): String = trim().replace(Regex("\\s+"), " ")
private fun JSONObject.arr(key: String): JSONArray = optJSONArray(key) ?: JSONArray()
private fun JSONArray.objects(): List<JSONObject> = buildList {
    repeat(length()) { index -> optJSONObject(index)?.let(::add) }
}
private fun JSONArray.stringValues(): List<String> = buildList {
    repeat(length()) { index -> optString(index, "").trim().takeIf { it.isNotBlank() }?.let(::add) }
}
private fun JSONObject.text(key: String, fallback: String = ""): String = optString(key, fallback).takeUnless { it == "null" } ?: fallback
private fun JSONObject.nullableText(key: String): String? = if (isNull(key)) null else optString(key).takeIf { it.isNotBlank() }
private inline fun <reified T : Enum<T>> JSONObject.enum(key: String, fallback: T): T = runCatching { enumValueOf<T>(optString(key)) }.getOrDefault(fallback)
