package uz.toybola.factory.core.data

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.ui.model.AppLanguage
import uz.toybola.factory.ui.model.AppSettings
import uz.toybola.factory.ui.model.AppThemePreset
import uz.toybola.factory.ui.model.normalized
import java.security.MessageDigest
import java.time.Instant

/**
 * Versioned portable backup for the full ToyBola client dataset.
 *
 * Device/User codes are deliberately excluded: restoring a backup must never bind a different
 * physical device to an old login. Only portable UI settings are included with Assembly + TP data.
 */
class WholeAppBackupRepository(context: Context) {
    private val appContext = context.applicationContext
    private val assembly = AssemblyDataRepository(appContext)
    private val tp = TpDataRepository(appContext)
    private val preferences = AppPreferences(appContext)

    data class Summary(
        val assemblyRecords: Int,
        val tpOrders: Int,
        val tpJobs: Int,
        val tpReceipts: Int,
        val tpIssues: Int,
        val materials: Int
    )

    data class Preview(
        val summary: Summary,
        val appVersion: String,
        val exportedAt: String,
        val settings: AppSettings?,
        val checksumVerified: Boolean = true
    )

    private data class ParsedBackup(
        val assemblyPayload: String,
        val tpPayload: String,
        val importedAssembly: AssemblyData,
        val importedTp: TpData,
        val settings: AppSettings?,
        val appVersion: String,
        val exportedAt: String
    )

    fun summary(): Summary = summaryOf(assembly.load(), tp.load())

    fun exportTo(uri: Uri): Result<Summary> = runCatching {
        val assemblyData = assembly.load()
        val tpData = tp.load()
        val settings = preferences.loadSettings()
        val assemblyPayload = assembly.encodeForSync(assemblyData)
        val tpPayload = tp.encodeForSync(tpData)
        val settingsPayload = encodeSettings(settings).toString()
        val digestSource = digestSource(assemblyPayload, tpPayload, settingsPayload, SCHEMA_VERSION)
        val envelope = JSONObject().apply {
            put("format", FORMAT)
            put("schemaVersion", SCHEMA_VERSION)
            put("appVersion", "0.14.1")
            put("exportedAt", Instant.now().toString())
            put("payloadSha256", sha256(digestSource))
            put("assemblyPayload", assemblyPayload)
            put("tpPayload", tpPayload)
            put("settings", JSONObject(settingsPayload))
        }
        appContext.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(envelope.toString()) }
            ?: error("Backup faylini yozib bo‘lmadi")
        summaryOf(assemblyData, tpData)
    }

    /** Validates format/checksum and shows exactly what will be restored, without mutating data. */
    fun preview(uri: Uri): Result<Preview> = runCatching {
        val parsed = parse(uri)
        Preview(
            summary = summaryOf(parsed.importedAssembly, parsed.importedTp),
            appVersion = parsed.appVersion,
            exportedAt = parsed.exportedAt,
            settings = parsed.settings
        )
    }

    fun importAndMerge(uri: Uri): Result<Summary> = runCatching {
        // Parse and checksum-validate the whole envelope before touching any local data.
        val parsed = parse(uri)
        val mergedAssembly = assembly.mergeFromBackup(parsed.importedAssembly)
        val mergedTp = tp.mergeFromBackup(parsed.importedTp)
        parsed.settings?.let(preferences::saveSettings)
        summaryOf(mergedAssembly, mergedTp)
    }

    private fun parse(uri: Uri): ParsedBackup {
        val raw = appContext.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            ?: error("Backup faylini o‘qib bo‘lmadi")
        val root = JSONObject(raw)
        require(root.optString("format") == FORMAT) { "Bu ToyBola to‘liq backup fayli emas" }
        val schema = root.optInt("schemaVersion", 0)
        require(schema in 1..SCHEMA_VERSION) { "Backup formati qo‘llab-quvvatlanmaydi" }
        val assemblyPayload = root.optString("assemblyPayload")
        val tpPayload = root.optString("tpPayload")
        require(assemblyPayload.isNotBlank() && tpPayload.isNotBlank()) { "Backup ichida ma’lumot yetarli emas" }
        val settingsObject = root.optJSONObject("settings")
        val settingsPayload = settingsObject?.toString().orEmpty()
        val expected = root.optString("payloadSha256")
        val actual = sha256(digestSource(assemblyPayload, tpPayload, settingsPayload, schema))
        require(expected.isNotBlank() && expected.equals(actual, ignoreCase = true)) { "Backup fayli buzilgan yoki to‘liq ko‘chmagan" }
        val importedAssembly = assembly.decodeForSync(assemblyPayload)
        val importedTp = tp.decodeForSync(tpPayload)
        return ParsedBackup(
            assemblyPayload = assemblyPayload,
            tpPayload = tpPayload,
            importedAssembly = importedAssembly,
            importedTp = importedTp,
            settings = settingsObject?.let(::decodeSettings),
            appVersion = root.optString("appVersion", "noma’lum"),
            exportedAt = root.optString("exportedAt", "")
        )
    }

    private fun digestSource(assemblyPayload: String, tpPayload: String, settingsPayload: String, schema: Int): String =
        if (schema <= 1) "$assemblyPayload\n---TP---\n$tpPayload"
        else "$assemblyPayload\n---TP---\n$tpPayload\n---SETTINGS---\n$settingsPayload"

    private fun encodeSettings(settings: AppSettings): JSONObject = JSONObject().apply {
        put("language", settings.language.name)
        put("darkMode", settings.darkMode)
        put("themePreset", settings.themePreset.name)
        put("autoLockMinutes", settings.autoLockMinutes)
        put("uiScalePercent", settings.uiScalePercent)
    }

    private fun decodeSettings(raw: JSONObject): AppSettings {
        val current = preferences.loadSettings()
        val legacyDark = raw.optBoolean("darkMode", current.darkMode)
        val restoredTheme = runCatching {
            AppThemePreset.valueOf(raw.optString("themePreset", current.themePreset.name))
        }.getOrDefault(current.themePreset).normalized(legacyDark)
        return current.copy(
            language = runCatching { AppLanguage.valueOf(raw.optString("language", current.language.name)) }.getOrDefault(current.language),
            darkMode = restoredTheme == AppThemePreset.DARK_CALM,
            themePreset = restoredTheme,
            autoLockMinutes = raw.optInt("autoLockMinutes", current.autoLockMinutes).coerceIn(0, 120),
            uiScalePercent = raw.optInt("uiScalePercent", current.uiScalePercent).let { value ->
                when {
                    value <= 95 -> 90
                    value >= 105 -> 110
                    else -> 100
                }
            }
        )
    }

    private fun summaryOf(a: AssemblyData, t: TpData): Summary = Summary(
        assemblyRecords = a.brigades.size + a.workers.size + a.products.size + a.workerDays.size + a.qualityRounds.size + a.dailyIssues.size,
        tpOrders = t.orders.size,
        tpJobs = t.jobs.size,
        tpReceipts = t.receipts.size,
        tpIssues = t.dailyIssues.size,
        materials = t.materials.size
    )

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it.toInt() and 0xff) }

    companion object {
        const val DEFAULT_FILE_NAME = "ToyBola_full_backup_0.14.1.json"
        private const val FORMAT = "TOYBOLA_FULL_BACKUP"
        private const val SCHEMA_VERSION = 2
    }
}
