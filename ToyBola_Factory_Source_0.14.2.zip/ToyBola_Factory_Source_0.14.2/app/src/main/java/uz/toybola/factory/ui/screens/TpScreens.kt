package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.components.SectionCard
import uz.toybola.factory.ui.model.AppScreen
import uz.toybola.factory.ui.model.AppStrings
import uz.toybola.factory.ui.navigation.TpNavigationTargetState
import java.time.LocalDate

private data class TpMainItem(
    val title: String,
    val description: String,
    val screen: AppScreen,
    val badge: Int = 0,
    val accent: Color,
    val icon: ImageVector
)

@Composable
fun TpMainScreen(
    strings: AppStrings,
    onBack: () -> Unit,
    canOpen: (AppScreen) -> Boolean,
    onOpen: (AppScreen) -> Unit
) {
    val context = LocalContext.current
    val revision by TpDataEvents.revision.collectAsState()
    val policy = remember(revision) { AccessGuard(context).currentPolicy() }
    val data = remember(revision, policy.revision) { TpDataRepository(context).load().scopedFor(policy) }
    val plannerPendingBadge = if (policy.isAdmin() || policy.canRead(AssemblySection.TP_PLANNING)) {
        data.orders.count { order ->
            order.status !in setOf(TpOrderStatus.COMPLETE, TpOrderStatus.CANCELLED) &&
                data.jobs.filter { it.orderId == order.id }.let { jobs -> jobs.isEmpty() || jobs.any { it.planConfirmedAt == null } }
        }
    } else 0
    val machinePendingBadge = if (policy.isAdmin() || policy.canRead(AssemblySection.TP_MACHINE)) {
        data.jobs.filter { it.planConfirmedAt != null && it.materialStatus == TpMaterialStatus.DELIVERED && it.status == TpJobStatus.QUEUED }
            .groupBy { "${it.orderId}|${it.moldCode}|${it.machineId}" }.size
    } else 0
    val operational = listOf(
        TpMainItem("Buyurtma va reja", "Buyurtmalar va rejalash", AppScreen.TP_PLAN, plannerPendingBadge, Color(0xFF2F8FE5), Icons.Rounded.Assignment),
        TpMainItem("Stanoklar va smena", "Stanoklar, davomat va qo‘shimcha soatlar", AppScreen.TP_SHIFT, machinePendingBadge, Color(0xFF7657E8), Icons.Rounded.PrecisionManufacturing),
        TpMainItem("Qabul", "Detal qabuli", AppScreen.TP_RECEIVING, accent = Color(0xFF12A982), icon = Icons.Rounded.Inventory2),
        TpMainItem("Sifat", "Baholash va kun muammosi", AppScreen.TP_QUALITY, accent = Color(0xFFED7A2E), icon = Icons.Rounded.VerifiedUser),
        TpMainItem("Monitoring", "Read-only natijalar va KPI", AppScreen.TP_MONITORING, accent = Color(0xFF7C65D8), icon = Icons.Rounded.BarChart)
    ).filter { canOpen(it.screen) }

    Column(Modifier.fillMaxSize()) {
        AppTopBar("TP", canGoBack = true, onMenu = {}, onBack = onBack, subtitle = "Zakaz, reja, stanok, qabul va sifat")
        Column(
            Modifier.fillMaxSize()
                .verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-main"))
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            operational.chunked(2).forEachIndexed { rowIndex, row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEachIndexed { index, item ->
                        SectionCard(
                            number = rowIndex * 2 + index + 1,
                            title = item.title,
                            description = item.description,
                            enabled = true,
                            visuallyActive = true,
                            badgeCount = item.badge,
                            modifier = if (row.size == 1) Modifier.fillMaxWidth() else Modifier.weight(1f),
                            accentColor = item.accent,
                            icon = item.icon,
                            onClick = { onOpen(item.screen) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
            if (canOpen(AppScreen.TP_MASTER_DATA)) {
                Spacer(Modifier.height(6.dp))
                Text("Boshqaruv", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(10.dp))
                SectionCard(
                    number = 6,
                    title = "Ma’lumotlar",
                    description = "TP master-data markazi",
                    enabled = true,
                    visuallyActive = true,
                    modifier = Modifier.fillMaxWidth(),
                    accentColor = Color(0xFF718394),
                    icon = Icons.Rounded.Storage,
                    onClick = { onOpen(AppScreen.TP_MASTER_DATA) }
                )
            }
        }
    }
}

private enum class TpPlanPage { ROOT, ORDERS, PLANNING, HISTORY }
private enum class TpShiftPage { MACHINES, ATTENDANCE, EXTRA_HOURS }

@Composable
fun TpPlanScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val eventRevision by TpDataEvents.revision.collectAsState()
    var localRevision by remember { mutableIntStateOf(0) }
    val policy = remember(eventRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(eventRevision, localRevision, policy.revision) { repository.load().scopedFor(policy) }
    val available = buildList {
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_ORDER)) {
            add(TpPlanPage.ORDERS)
            add(TpPlanPage.HISTORY)
        }
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_PLANNING)) add(TpPlanPage.PLANNING)
    }
    var page by remember { mutableStateOf(if (available.size == 1) available.first() else TpPlanPage.ROOT) }
    fun refresh() { localRevision++ }
    fun back() { if (page == TpPlanPage.ROOT || available.size == 1) onBack() else page = TpPlanPage.ROOT }
    BackHandler { back() }

    val title = when (page) {
        TpPlanPage.ROOT -> "Buyurtma va reja"
        TpPlanPage.ORDERS -> "Buyurtmalar"
        TpPlanPage.PLANNING -> "Rejalash"
        TpPlanPage.HISTORY -> "Buyurtmalar tarixi"
    }
    Column(Modifier.fillMaxSize()) {
        AppTopBar(title, canGoBack = true, onMenu = {}, onBack = ::back, subtitle = if (page == TpPlanPage.ROOT) "Buyurtma va reja" else null)
        when (page) {
            TpPlanPage.ROOT -> TpPlanRoot(policy, data) { page = it }
            TpPlanPage.ORDERS -> TpOrdersPage(data, repository, policy, ::refresh)
            TpPlanPage.PLANNING -> TpPlanningPage(data, repository, policy, ::refresh)
            TpPlanPage.HISTORY -> TpOrderHistoryPage(data)
        }
    }
}

@Composable
private fun TpPlanRoot(policy: UserAccessPolicy, data: TpData, onOpen: (TpPlanPage) -> Unit) {
    data class Item(val page: TpPlanPage, val title: String, val description: String, val accent: Color, val icon: ImageVector, val badge: Int = 0)
    val plannerBadge = data.orders.count { order ->
        order.status !in setOf(TpOrderStatus.COMPLETE, TpOrderStatus.CANCELLED) &&
            data.jobs.filter { it.orderId == order.id }.let { jobs -> jobs.isEmpty() || jobs.any { it.planConfirmedAt == null } }
    }
    val items = buildList {
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_ORDER)) add(Item(TpPlanPage.ORDERS, "Buyurtmalar", "Buyurtma berish va quyish boshlanganini kuzatish", Color(0xFF2F8FE5), Icons.Rounded.Assignment))
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_PLANNING)) add(Item(TpPlanPage.PLANNING, "Rejalash", "Detal + rang bo‘yicha reja va tasdiq", Color(0xFF12A982), Icons.Rounded.CalendarMonth, plannerBadge))
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_ORDER)) add(Item(TpPlanPage.HISTORY, "Buyurtmalar tarixi", "Quyib bo‘lingan va bekor qilingan buyurtmalar", Color(0xFF718394), Icons.Rounded.History))
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpPlan-root")).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Kerakli vazifani tanlang.", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        items.forEach { item ->
            val cardColor = MaterialTheme.colorScheme.surface
            val iconBg = item.accent.copy(alpha = 0.13f)
            Surface(modifier = Modifier.fillMaxWidth().clickable { onOpen(item.page) }, shape = RoundedCornerShape(16.dp), color = cardColor, border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), shadowElevation = 1.dp, tonalElevation = 0.dp) {
                Row(Modifier.fillMaxWidth().heightIn(min = 94.dp).padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(shape = RoundedCornerShape(16.dp), color = iconBg, tonalElevation = 0.dp) {
                        Icon(item.icon, contentDescription = null, tint = item.accent, modifier = Modifier.padding(12.dp).size(27.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text(item.title, color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(3.dp))
                        Text(item.description, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, lineHeight = 17.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    if (item.badge > 0) Badge(containerColor = MaterialTheme.colorScheme.error, contentColor = MaterialTheme.colorScheme.onError) { Text(item.badge.coerceAtMost(99).toString(), fontSize = 10.sp) }
                    Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = item.accent, modifier = Modifier.size(21.dp))
                }
            }
        }
    }
}

@Composable
fun TpShiftScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val eventRevision by TpDataEvents.revision.collectAsState()
    var localRevision by remember { mutableIntStateOf(0) }
    val policy = remember(eventRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(eventRevision, localRevision, policy.revision) { repository.load().scopedFor(policy) }
    val tabs = buildList {
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_MACHINE)) add(TpShiftPage.MACHINES)
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_ATTENDANCE)) add(TpShiftPage.ATTENDANCE)
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_EXTRA_HOURS)) add(TpShiftPage.EXTRA_HOURS)
    }
    var page by remember { mutableStateOf(tabs.firstOrNull() ?: TpShiftPage.MACHINES) }
    fun refresh() { localRevision++ }
    Column(Modifier.fillMaxSize()) {
        AppTopBar("Stanoklar va smena", canGoBack = true, onMenu = {}, onBack = onBack, subtitle = "Stanoklar, davomat va qo‘shimcha soatlar")
        if (tabs.size > 1) {
            ScrollableTabRow(selectedTabIndex = tabs.indexOf(page).coerceAtLeast(0), edgePadding = 12.dp) {
                tabs.forEach { tab ->
                    Tab(selected = tab == page, onClick = { page = tab }, text = { Text(when (tab) { TpShiftPage.MACHINES -> "Stanoklar"; TpShiftPage.ATTENDANCE -> "Davomat"; TpShiftPage.EXTRA_HOURS -> "Qo‘shimcha soatlar" }) })
                }
            }
        }
        when (page) {
            TpShiftPage.MACHINES -> TpMachineQueuePage(data, repository, policy, ::refresh)
            TpShiftPage.ATTENDANCE -> TpAttendancePage(data, repository, policy, ::refresh)
            TpShiftPage.EXTRA_HOURS -> TpExtraHoursPage(data, repository, policy, ::refresh)
        }
    }
}

@Composable
private fun TpOrdersPage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_ORDER)
    var showAdd by remember { mutableStateOf(false) }
    var editOrder by remember { mutableStateOf<TpOrder?>(null) }
    var deleteOrder by remember { mutableStateOf<TpOrder?>(null) }
    var cancelReason by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    fun moldingStartedAt(orderId: String): String? = data.jobs.asSequence()
        .filter { it.orderId == orderId }
        .mapNotNull { it.startedAt }
        .minOrNull()

    val active = data.orders.filter { it.status != TpOrderStatus.COMPLETE && it.status != TpOrderStatus.CANCELLED }
    val activeComparator = compareBy<TpOrder> { it.priority }.thenBy { it.createdAt }
    val notStarted = active.filter { moldingStartedAt(it.id) == null }.sortedWith(activeComparator)
    val started = active.filter { moldingStartedAt(it.id) != null }.sortedWith(activeComparator)

    @Composable
    fun ActiveOrderCard(order: TpOrder, startedAt: String?) {
        val progress = data.orderProgress(order.id).coerceIn(0.0, 100.0)
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            shadowElevation = 1.dp,
            tonalElevation = 0.dp
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text("${order.articleSnapshot} • ${order.productNameSnapshot}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Partiya ${order.batchNumber} • ${order.quantity} dona", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("${progress.toInt()}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
                LinearProgressIndicator(
                    progress = { (progress / 100.0).toFloat() },
                    modifier = Modifier.fillMaxWidth(),
                    trackColor = MaterialTheme.colorScheme.outlineVariant
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(shape = RoundedCornerShape(11.dp), color = tpPriorityColor(order.priority).copy(alpha = .16f)) {
                        Text(tpPriorityLabel(order.priority), Modifier.padding(horizontal = 10.dp, vertical = 5.dp), fontWeight = FontWeight.SemiBold)
                    }
                    Text("Berildi: ${order.createdAt.take(16).replace('T', ' ')}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (!startedAt.isNullOrBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Rounded.PlayCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Text("Boshlangan: ${startedAt.take(16).replace('T', ' ')}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                    }
                }
                if (order.note.isNotBlank()) Text("Izoh: ${order.note}", style = MaterialTheme.typography.bodySmall)
                if (canWrite) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { editOrder = order }, Modifier.weight(1f)) {
                            Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(5.dp)); Text("Tahrirlash")
                        }
                        OutlinedButton(
                            onClick = { cancelReason = ""; deleteOrder = order },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(5.dp)); Text("Bekor/O‘chirish")
                        }
                    }
                }
            }
        }
    }

    Column(
        Modifier.fillMaxSize()
            .verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-orders"))
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (canWrite) {
            Button(
                onClick = { showAdd = true },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null)
                Spacer(Modifier.width(7.dp))
                Text("Yangi buyurtma", fontWeight = FontWeight.Bold)
            }
        }

        Text("Quyish boshlanmagan · ${notStarted.size}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (notStarted.isEmpty()) {
            Text("Boshlanishni kutayotgan buyurtma yo‘q.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else notStarted.forEach { ActiveOrderCard(it, null) }

        HorizontalDivider(Modifier.padding(vertical = 6.dp))

        Text("Quyish boshlangan · ${started.size}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (started.isEmpty()) {
            Text("Hozir quyilayotgan buyurtma yo‘q.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else started.forEach { order -> ActiveOrderCard(order, moldingStartedAt(order.id)) }

        TpError(error)
    }

    if (showAdd) {
        TpOrderDialog(data = data, initial = null, onDismiss = { showAdd = false }) { batch, productId, quantity, priority, note ->
            val result = repo.createOrder(batch, productId, quantity, priority, note)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { showAdd = false; refresh() }
            result.isSuccess
        }
    }

    editOrder?.let { order ->
        TpOrderDialog(data = data, initial = order, onDismiss = { editOrder = null }) { _, productId, quantity, priority, note ->
            val result = repo.updateOrder(order.id, productId, quantity, priority, note)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { editOrder = null; refresh() }
            result.isSuccess
        }
    }

    deleteOrder?.let { order ->
        val hasLinkedProcess = data.jobs.any { it.orderId == order.id } || data.receipts.any { it.orderId == order.id }
        AlertDialog(
            onDismissRequest = { deleteOrder = null; cancelReason = "" },
            title = { Text(if (hasLinkedProcess) "Buyurtmani bekor qilish" else "Buyurtmani o‘chirish") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (hasLinkedProcess)
                        "${order.batchNumber} • ${order.articleSnapshot} jarayonga ulangan. Buyurtma o‘chirilmaydi; bekor qilingan holatda tarixda qoladi."
                    else "${order.batchNumber} • ${order.articleSnapshot} hali jarayonga ulanmagan. Uni butunlay o‘chirish mumkin.")
                    if (hasLinkedProcess) TpField(cancelReason, { cancelReason = it }, "Bekor qilish sababi *", singleLine = false)
                }
            },
            confirmButton = { TextButton(enabled = !hasLinkedProcess || cancelReason.isNotBlank(), onClick = {
                val result = if (hasLinkedProcess) repo.cancelOrder(order.id, cancelReason, policy.displayName) else repo.deleteOrder(order.id)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { deleteOrder = null; cancelReason = ""; refresh() }
            }) { Text(if (hasLinkedProcess) "Bekor qilish" else "O‘chirish", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { deleteOrder = null; cancelReason = "" }) { Text("Ortga") } }
        )
    }
}

private enum class TpOrderHistoryMode { COMPLETE, CANCELLED }

@Composable
private fun TpOrderHistoryPage(data: TpData) {
    var mode by remember { mutableStateOf(TpOrderHistoryMode.COMPLETE) }
    var query by remember { mutableStateOf("") }
    var fromDate by remember { mutableStateOf("") }
    var toDate by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf<TpOrder?>(null) }

    fun startedAt(orderId: String): String? = data.jobs.asSequence().filter { it.orderId == orderId }.mapNotNull { it.startedAt }.minOrNull()
    fun endAt(order: TpOrder): String = when (mode) {
        TpOrderHistoryMode.COMPLETE -> order.completedAt.orEmpty()
        TpOrderHistoryMode.CANCELLED -> order.cancelledAt.orEmpty()
    }
    val source = when (mode) {
        TpOrderHistoryMode.COMPLETE -> data.orders.filter { it.status == TpOrderStatus.COMPLETE }
        TpOrderHistoryMode.CANCELLED -> data.orders.filter { it.status == TpOrderStatus.CANCELLED }
    }
    val normalized = query.trim().lowercase()
    val visible = source.filter { order ->
        val date = endAt(order).take(10).ifBlank { order.requestedDate }
        val matchesQuery = normalized.isBlank() || listOf(order.articleSnapshot, order.productNameSnapshot, order.batchNumber).any { it.lowercase().contains(normalized) }
        val after = fromDate.isBlank() || date >= fromDate
        val before = toDate.isBlank() || date <= toDate
        matchesQuery && after && before
    }.sortedByDescending { endAt(it).ifBlank { it.createdAt } }

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("tp-order-history")).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == TpOrderHistoryMode.COMPLETE, onClick = { mode = TpOrderHistoryMode.COMPLETE }, label = { Text("Yakunlangan") }, modifier = Modifier.weight(1f))
            FilterChip(selected = mode == TpOrderHistoryMode.CANCELLED, onClick = { mode = TpOrderHistoryMode.CANCELLED }, label = { Text("Bekor qilingan") }, modifier = Modifier.weight(1f))
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Artikul, mahsulot yoki partiya") },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) }
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = fromDate, onValueChange = { fromDate = it.take(10) }, label = { Text("Dan") }, placeholder = { Text("YYYY-MM-DD") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(value = toDate, onValueChange = { toDate = it.take(10) }, label = { Text("Gacha") }, placeholder = { Text("YYYY-MM-DD") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        if (visible.isEmpty()) Text("Bu filtr bo‘yicha buyurtma yo‘q.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        visible.forEach { order ->
            Surface(
                modifier = Modifier.fillMaxWidth().clickable { detail = order },
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                tonalElevation = 0.dp
            ) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${order.articleSnapshot} • ${order.productNameSnapshot}", fontWeight = FontWeight.Bold)
                    Text("Partiya ${order.batchNumber} • ${order.quantity} dona", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (mode == TpOrderHistoryMode.COMPLETE) {
                        Text("Yakunlandi: ${order.completedAt.orEmpty().take(16).replace('T', ' ')}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text("Bekor qilindi: ${order.cancelledAt.orEmpty().take(16).replace('T', ' ')}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    detail?.let { order ->
        val started = startedAt(order.id)
        val finished = order.completedAt ?: order.cancelledAt
        val durationLabel = if (started.isNullOrBlank() || finished.isNullOrBlank()) null else runCatching {
            val a = java.time.LocalDateTime.parse(started)
            val b = java.time.LocalDateTime.parse(finished)
            minutesLabel(java.time.Duration.between(a, b).toMinutes().coerceAtLeast(0).toInt())
        }.getOrNull()
        val jobs = data.jobs.filter { it.orderId == order.id }
        AlertDialog(
            onDismissRequest = { detail = null },
            title = { Text("${order.articleSnapshot} • Partiya ${order.batchNumber}") },
            text = {
                Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text(order.productNameSnapshot, fontWeight = FontWeight.Bold)
                    Text("Buyurtma: ${order.quantity} dona")
                    Text("Berildi: ${order.createdAt.take(16).replace('T', ' ')}")
                    Text("Quyish boshlandi: ${started?.take(16)?.replace('T', ' ') ?: "boshlanmagan"}")
                    if (order.status == TpOrderStatus.COMPLETE) Text("Yakunlandi: ${order.completedAt.orEmpty().take(16).replace('T', ' ')}")
                    if (order.status == TpOrderStatus.CANCELLED) {
                        Text("Bekor qilindi: ${order.cancelledAt.orEmpty().take(16).replace('T', ' ')}", color = MaterialTheme.colorScheme.error)
                        if (order.cancelReason.isNotBlank()) Text("Sabab: ${order.cancelReason}")
                    }
                    if (!durationLabel.isNullOrBlank()) Text("Umumiy davomiylik: $durationLabel")
                    HorizontalDivider()
                    Text("Detal / rang", fontWeight = FontWeight.Bold)
                    jobs.sortedWith(compareBy<TpPlanJob> { it.moldCode }.thenBy { it.colorCode }).forEach { job ->
                        val received = job.outputs.sumOf { out -> data.receipts.filter { !it.isCancelled && it.jobId == job.id && it.detailId == out.detailId }.sumOf { it.creditedPieces } }
                        val required = job.outputs.sumOf { it.requiredPieces }
                        Text("${job.outputs.joinToString { it.detailName }} • ${job.colorCode} • $received/$required dona", style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { detail = null }) { Text("Yopish") } }
        )
    }
}


@Composable
private fun TpOrderDialog(
    data: TpData,
    initial: TpOrder?,
    onDismiss: () -> Unit,
    onSave: (String, String, Int, Int, String) -> Boolean
) {
    val products = data.products.filter { !it.archived && it.details.any { detail -> !detail.archived } }.sortedBy { it.article }
    var productId by remember(initial?.id) { mutableStateOf(initial?.productId ?: products.firstOrNull()?.id.orEmpty()) }
    fun suggestedFor(id: String): String = nextBatchNumberForProduct(data.orders.filter { it.productId == id }.map { it.batchNumber })
    var batch by remember(initial?.id) { mutableStateOf(initial?.batchNumber ?: suggestedFor(productId)) }
    var quantity by remember(initial?.id) { mutableStateOf(initial?.quantity?.toString().orEmpty()) }
    var priority by remember(initial?.id) { mutableIntStateOf(initial?.priority?.coerceIn(1, 3) ?: 2) }
    var note by remember(initial?.id) { mutableStateOf(initial?.note.orEmpty()) }
    var validation by remember { mutableStateOf<String?>(null) }
    var confirmBatchOverride by remember { mutableStateOf(false) }

    val productHistory = remember(data.orders, productId) { data.orders.filter { it.productId == productId } }
    val suggestedBatch = remember(data.orders, productId) { suggestedFor(productId) }

    LaunchedEffect(productId, initial?.id) {
        if (initial == null) batch = suggestedFor(productId)
    }

    fun commit(): Boolean {
        val qty = quantity.toIntOrNull()
        validation = when {
            productId.isBlank() || qty == null || qty <= 0 -> "Majburiy maydonlarni to‘ldiring"
            batch.trim().isBlank() -> "Partiya raqamini kiriting"
            productHistory.any { it.id != initial?.id && it.batchNumber.equals(batch.trim(), true) } -> "Bu mahsulotda ${batch.trim()}-partiya allaqachon mavjud"
            else -> null
        }
        return if (validation == null) onSave(batch.trim(), productId, qty!!, priority, note) else false
    }

    fun save() {
        val qty = quantity.toIntOrNull()
        validation = when {
            productId.isBlank() || qty == null || qty <= 0 -> "Majburiy maydonlarni to‘ldiring"
            initial == null && batch.trim().isBlank() -> "Partiya raqamini kiriting"
            else -> null
        }
        if (validation != null) return
        val changedAutomaticBatch = initial == null && suggestedBatch.isNotBlank() && batch.trim() != suggestedBatch
        if (changedAutomaticBatch) confirmBatchOverride = true
        else if (commit()) onDismiss()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (initial == null) "Yangi buyurtma" else "Buyurtmani tahrirlash",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer) {
                    IconButton(onClick = onDismiss, modifier = Modifier.size(38.dp)) {
                        Icon(Icons.Rounded.Close, contentDescription = "Yopish")
                    }
                }
            }
        },
        text = {
            Column(
                Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (products.isEmpty()) Text("Avval mahsulot va uning detallarini kiriting.", color = MaterialTheme.colorScheme.error)
                TpChoice("Mahsulot", productId, products, { it.id }, { "${it.article} — ${it.name}" }) { productId = it }
                if (initial != null) {
                    Text("Partiya: ${initial.batchNumber}", fontWeight = FontWeight.Bold)
                } else {
                    TpField(batch, { batch = it }, if (productHistory.isEmpty()) "Birinchi partiya raqami" else "Partiya raqami")
                    Text(
                        if (productHistory.isEmpty()) "Bu mahsulot uchun boshlang‘ich partiya bir marta kiritiladi."
                        else "Avtomatik tavsiya: $suggestedBatch. Zarurat bo‘lsa qo‘lda o‘zgartirish mumkin.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TpField(quantity, { quantity = digitsOnly(it) }, "Buyurtma soni", KeyboardType.Number)
                Text("Ustuvorlik", fontWeight = FontWeight.Bold)
                TpPriorityButtons(priority) { priority = it }
                TpField(note, { note = it }, "Izoh", singleLine = false)
                TpError(validation)
            }
        },
        confirmButton = {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f).height(48.dp)) { Text("Bekor qilish") }
                Button(enabled = products.isNotEmpty(), onClick = ::save, modifier = Modifier.weight(1f).height(48.dp)) {
                    Text("Saqlash", fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {}
    )

    if (confirmBatchOverride) {
        AlertDialog(
            onDismissRequest = { confirmBatchOverride = false },
            title = { Text("Partiya raqamini o‘zgartirish") },
            text = { Text("Dastur $suggestedBatch ni tavsiya qildi. ${batch.trim()} partiya raqamini ataylab saqlaysizmi?") },
            confirmButton = { TextButton(onClick = {
                confirmBatchOverride = false
                if (commit()) onDismiss()
            }) { Text("Ha, saqlash") } },
            dismissButton = { TextButton(onClick = { confirmBatchOverride = false }) { Text("Ortga") } }
        )
    }
}

@Composable
private fun TpPriorityButtons(selected: Int, onSelect: (Int) -> Unit) {
    val values = listOf(
        Triple(1, "Eng zaril", Color(0xFFC62828)),
        Triple(2, "Zaril", Color(0xFFFFC107)),
        Triple(3, "Keyinroq", Color(0xFF2E7D32))
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        values.forEach { (value, label, color) ->
            val content = if (value == 2) Color.Black else Color.White
            Button(
                onClick = { onSelect(value) },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = color.copy(alpha = if (selected == value) 1f else 0.45f),
                    contentColor = content
                )
            ) { Text(if (selected == value) "✓ $label" else label, style = MaterialTheme.typography.labelSmall) }
        }
    }
}

@Composable
private fun TpOrderSummary(data: TpData, order: TpOrder) {
    val progress = data.orderProgress(order.id)
    val forecast = data.orderForecastMinutes(order.id)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("${order.batchNumber} • ${order.articleSnapshot}", fontWeight = FontWeight.Bold)
            Text("${order.productNameSnapshot} — ${order.quantity} dona")
        }
        Text("${progress.toInt()}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = tpPriorityColor(order.priority).copy(alpha = 0.16f)
        ) {
            Text(tpPriorityLabel(order.priority), modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontWeight = FontWeight.SemiBold)
        }
        Text("Holat: ${orderStatusLabel(order.status)}", style = MaterialTheme.typography.bodySmall)
    }
    Text("Zakaz berildi: ${order.createdAt.take(16).replace('T', ' ')}", style = MaterialTheme.typography.bodySmall)
    Text(
        if (forecast > 0) "Taxminiy to‘liq quyish: ${minutesLabel(forecast)}" else "Taxminiy muddat: ma’lumot yetarli emas",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    if (order.note.isNotBlank()) Text("Izoh: ${order.note}", style = MaterialTheme.typography.bodySmall)
    if (order.completedAt != null) Text("Yakunlandi: ${order.completedAt.take(16).replace('T', ' ')}", style = MaterialTheme.typography.bodySmall)
}

private fun tpPriorityColor(priority: Int): Color = when (priority.coerceIn(1, 3)) {
    1 -> Color(0xFFC62828)
    2 -> Color(0xFFFFC107)
    else -> Color(0xFF2E7D32)
}

private enum class TpPlannerMode { ORDERS, MACHINES }

@Composable
private fun PlannerModeButton(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(48.dp),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 2.dp else 1.dp,
            if (selected) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.outline.copy(alpha = 0.68f)
        ),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = .62f)
            else MaterialTheme.colorScheme.surface,
            contentColor = if (selected) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurfaceVariant
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = if (selected) 1.dp else 0.dp)
    ) {
        Text(
            text,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun TpPlanningPage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_PLANNING)
    var mode by remember { mutableStateOf(TpPlannerMode.ORDERS) }
    var selectedOrderId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        TpNavigationTargetState.consumeOrderId()?.takeIf { target -> data.orders.any { it.id == target } }?.let { selectedOrderId = it }
    }
    var expandedDetails by remember { mutableStateOf<Set<String>>(emptySet()) }
    var assignMold by remember { mutableStateOf<String?>(null) }
    var openColorMenu by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    val visibleOrders = data.orders.filter { it.status != TpOrderStatus.COMPLETE && it.status != TpOrderStatus.CANCELLED }
    fun orderPlanDone(order: TpOrder): Boolean {
        val jobs = data.jobs.filter { it.orderId == order.id }
        return jobs.isNotEmpty() && jobs.all { it.planConfirmedAt != null }
    }
    val pendingOrders = visibleOrders.filterNot(::orderPlanDone)
        .sortedWith(compareBy<TpOrder> { it.priority }.thenBy { it.createdAt })
    val approvedOrders = visibleOrders.filter(::orderPlanDone)
        .sortedWith(compareBy<TpOrder> { it.planApprovedAt.orEmpty() }.thenBy { it.createdAt })
    val selectedOrder = data.orders.firstOrNull { it.id == selectedOrderId }

    BackHandler(enabled = selectedOrder != null || mode == TpPlannerMode.MACHINES) {
        if (selectedOrder != null) {
            selectedOrderId = null; expandedDetails = emptySet(); assignMold = null; openColorMenu = null
        } else mode = TpPlannerMode.ORDERS
    }

    LaunchedEffect(selectedOrderId) {
        val orderId = selectedOrderId ?: return@LaunchedEffect
        val order = data.orders.firstOrNull { it.id == orderId } ?: return@LaunchedEffect
        if (canWrite && order.status != TpOrderStatus.COMPLETE && data.jobs.none { it.orderId == orderId }) {
            val result = repo.generateOrderPlan(orderId)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) refresh()
        }
    }

    Column(Modifier.fillMaxSize()) {
        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            tonalElevation = 0.dp,
            shadowElevation = 1.dp
        ) {
            Row(
                Modifier.fillMaxWidth().padding(6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PlannerModeButton(
                    text = "Buyurtmalar bo‘yicha",
                    selected = mode == TpPlannerMode.ORDERS,
                    modifier = Modifier.weight(1f),
                    onClick = { mode = TpPlannerMode.ORDERS }
                )
                PlannerModeButton(
                    text = "Stanoklar bo‘yicha",
                    selected = mode == TpPlannerMode.MACHINES,
                    modifier = Modifier.weight(1f),
                    onClick = { mode = TpPlannerMode.MACHINES; selectedOrderId = null }
                )
            }
        }
        if (mode == TpPlannerMode.MACHINES) {
            TpPlannerMachinesView(data, repo, canWrite, refresh)
            return@Column
        }

        val scrollKey = selectedOrder?.let { "tp-planning-order-${it.id}" } ?: "tp-planning-list"
        Column(
            Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState(scrollKey)).navigationBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (selectedOrder == null) {
                Text("Buyurtmalarni detalma-detal rejalang. Tasdiqlangan detal darhol Seryo brigadiriga o‘tadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Tasdiqlanmagan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (pendingOrders.isEmpty()) Text("Ko‘rib chiqilishi kerak bo‘lgan buyurtma yo‘q.")
                pendingOrders.forEach { order ->
                    val jobs = data.jobs.filter { it.orderId == order.id }
                    val remaining = if (jobs.isEmpty()) data.products.firstOrNull { it.id == order.productId }?.details?.count { !it.archived } ?: 0
                    else jobs.groupBy { it.moldCode }.count { (_, rows) -> rows.any { it.planConfirmedAt == null } }
                    TpCard(Modifier.clickable { selectedOrderId = order.id }) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f)) { TpOrderSummary(data, order) }
                            if (remaining > 0) Surface(shape = RoundedCornerShape(999.dp), color = MaterialTheme.colorScheme.error) {
                                Text(remaining.toString(), Modifier.padding(horizontal = 8.dp, vertical = 3.dp), color = MaterialTheme.colorScheme.onError, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text("Tasdiqlanmagan detal: $remaining", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                Text("Tasdiqlangan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (approvedOrders.isEmpty()) Text("Hali barcha detallari tasdiqlangan buyurtma yo‘q.")
                approvedOrders.forEach { order -> TpCard(Modifier.clickable { selectedOrderId = order.id }) { TpOrderSummary(data, order) } }
            } else {
                OutlinedButton(onClick = { selectedOrderId = null; expandedDetails = emptySet() }) { Text("‹ Buyurtmalar") }
                TpCard { TpOrderSummary(data, selectedOrder) }
                val product = data.products.firstOrNull { it.id == selectedOrder.productId }
                val details = product?.details?.filterNot { it.archived }.orEmpty().sortedWith(compareBy<TpDetail> { detail ->
                    val rows = data.jobs.filter { it.orderId == selectedOrder.id && it.outputs.any { out -> out.detailId == detail.id } }
                    rows.isNotEmpty() && rows.all { it.planConfirmedAt != null }
                }.thenBy { it.name })
                if (details.isEmpty()) Text("Mahsulot detallari topilmadi.", color = MaterialTheme.colorScheme.error)
                details.forEach { detail ->
                    val detailJobs = data.jobs.filter { job -> job.orderId == selectedOrder.id && job.outputs.any { it.detailId == detail.id } }
                        .sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id })
                    val confirmed = detailJobs.isNotEmpty() && detailJobs.all { it.planConfirmedAt != null }
                    val machineIds = detailJobs.mapNotNull { it.machineId }.distinct()
                    val machineLabel = when {
                        detailJobs.isEmpty() -> "Stanok"
                        machineIds.size == 1 -> {
                            val machine = data.machines.firstOrNull { it.id == machineIds.first() }
                            val shop = machine?.let { m -> data.shops.firstOrNull { it.id == m.shopId }?.name }.orEmpty()
                            if (machine == null) "Stanok" else "${machine.number} • ${shop.ifBlank { "Sex" }}"
                        }
                        machineIds.isEmpty() -> "Stanok"
                        else -> "Aralash"
                    }
                    val total = selectedOrder.quantity * detail.requiredPerProduct
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = if (confirmed) MaterialTheme.colorScheme.primaryContainer.copy(alpha = .55f) else MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .62f)),
                        tonalElevation = 0.dp,
                        shadowElevation = 2.dp
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Column(Modifier.weight(1f)) {
                                    Text(detail.name, fontWeight = FontWeight.Bold)
                                    Text("Jami: $total dona", color = MaterialTheme.colorScheme.primary)
                                    if (confirmed) Text("✓ Rejalangan va tasdiqlangan", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                                }
                                OutlinedButton(enabled = canWrite && detailJobs.isNotEmpty(), onClick = { assignMold = detail.moldCode }) {
                                    Text(if (confirmed) "Tahrirlash • $machineLabel" else machineLabel)
                                }
                            }
                            val assignedMachineId = machineIds.singleOrNull()?.takeIf { id -> detailJobs.all { it.machineId == id } }
                            if (assignedMachineId != null) {
                                val targetIds = detailJobs.map { it.id }.toSet()
                                val wait = data.jobs.filter { it.machineId == assignedMachineId && it.status != TpJobStatus.COMPLETE && it.id !in targetIds && it.planConfirmedAt != null }.sumOf { it.estimatedMinutes }
                                Text(if (wait > 0) "Boshlanishi taxminan ${minutesLabel(wait)} dan keyin" else "Stanok bo‘sh — boshlash mumkin", style = MaterialTheme.typography.bodySmall)
                            }
                            if (!confirmed && detailJobs.isNotEmpty() && detailJobs.all { it.machineId != null && it.brigadeId != null && it.shiftId != null }) {
                                OutlinedButton(enabled = canWrite, onClick = {
                                    val result = repo.confirmPlannedMold(selectedOrder.id, detail.moldCode)
                                    error = result.exceptionOrNull()?.message
                                    if (result.isSuccess) refresh()
                                }, modifier = Modifier.fillMaxWidth()) { Text("✓ Shu detalni tasdiqlash") }
                            }
                            OutlinedButton(onClick = { expandedDetails = if (detail.id in expandedDetails) expandedDetails - detail.id else expandedDetails + detail.id }, modifier = Modifier.fillMaxWidth()) {
                                Text(if (detail.id in expandedDetails) "▲ Ranglarni yopish" else "▼ Ranglarni ko‘rish")
                            }
                            if (detail.id in expandedDetails) {
                                detailJobs.forEachIndexed { index, job ->
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Text("${job.colorCode} — ${job.outputs.firstOrNull { it.detailId == detail.id }?.requiredPieces ?: 0} dona", Modifier.weight(1f))
                                        if (!confirmed && canWrite) Box {
                                            OutlinedButton(onClick = { openColorMenu = job.id }) { Text("${index + 1}") }
                                            DropdownMenu(expanded = openColorMenu == job.id, onDismissRequest = { openColorMenu = null }) {
                                                detailJobs.indices.forEach { pos -> DropdownMenuItem(text = { Text("${pos + 1}-navbat") }, onClick = {
                                                    openColorMenu = null
                                                    val result = repo.setColorPosition(job.id, pos + 1)
                                                    error = result.exceptionOrNull()?.message
                                                    if (result.isSuccess) refresh()
                                                }) }
                                            }
                                        } else Text("${index + 1}")
                                    }
                                }
                            }
                        }
                    }
                }
                val remaining = data.jobs.filter { it.orderId == selectedOrder.id }.groupBy { it.moldCode }.count { (_, rows) -> rows.any { it.planConfirmedAt == null } }
                if (remaining > 0) Text("Tasdiqlanmagan detal: $remaining. Har bir detal tasdiqlangach Seryoga alohida yuboriladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                else Text("✓ Barcha detallar rejalandi. Zakaz avtomatik tasdiqlanganlar ro‘yxatiga o‘tdi.", color = MaterialTheme.colorScheme.primary)
            }
            TpError(error)
        }
    }

    val order = selectedOrder
    val mold = assignMold
    if (order != null && mold != null) {
        val target = data.jobs.filter { it.orderId == order.id && it.moldCode == mold }
        val editing = target.any { it.planConfirmedAt != null }
        TpMachinePickerDialog(
            data = data, order = order, moldCode = mold, editing = editing,
            onDismiss = { assignMold = null },
            onSave = { machineId, reason, override, overrideReason ->
                val result = repo.assignMoldJobs(order.id, mold, machineId, reason, override, overrideReason)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { assignMold = null; refresh() }
                result.isSuccess
            }
        )
    }
}

@Composable
private fun TpPlannerMachinesView(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    var shopId by remember(shops) { mutableStateOf(shops.firstOrNull()?.id.orEmpty()) }
    var selectedMachineId by remember { mutableStateOf<String?>(null) }
    var showMachineOrders by remember { mutableStateOf(false) }
    var selectedOrderId by remember { mutableStateOf<String?>(null) }
    var assignMold by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val machines = data.machines.filter { !it.archived && (shopId.isBlank() || it.shopId == shopId) }
    fun remaining(machineId: String): Int = data.jobs.filter { it.machineId == machineId && it.planConfirmedAt != null && it.status != TpJobStatus.COMPLETE }.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
    fun lastActivity(machineId: String): String = data.jobs.filter { it.machineId == machineId }.mapNotNull { it.startedAt ?: it.materialDeliveredAt ?: it.planEditedAt ?: it.planConfirmedAt }.maxOrNull().orEmpty()
    fun compatibleOrders(machine: TpMachine): List<TpOrder> = data.orders
        .filter { it.status != TpOrderStatus.COMPLETE && it.status != TpOrderStatus.CANCELLED }
        .filter { order ->
            val orderJobs = data.jobs.filter { it.orderId == order.id }
            val candidates = if (orderJobs.isEmpty()) {
                var previewIndex = 0
                buildPlanJobs(data, order) { "preview-${order.id}-${previewIndex++}" }
            } else orderJobs.filter { it.status != TpJobStatus.COMPLETE && it.planConfirmedAt == null }
            candidates.any { it.acceptsMachine(machine, data) }
        }
        .sortedWith(compareBy<TpOrder> { it.priority }.thenBy { it.createdAt })
    val idle = machines.filter { remaining(it.id) == 0 }.sortedWith(compareBy<TpMachine> { lastActivity(it.id) }.thenBy { it.number })
    val busy = machines.filter { remaining(it.id) > 0 }.sortedWith(compareBy<TpMachine> { remaining(it.id) }.thenBy { it.number })
    val selectedMachine = machines.firstOrNull { it.id == selectedMachineId }

    BackHandler(enabled = selectedMachineId != null) { selectedMachineId = null; showMachineOrders = false; selectedOrderId = null; assignMold = null }
    LaunchedEffect(selectedOrderId) {
        val id = selectedOrderId ?: return@LaunchedEffect
        if (data.jobs.none { it.orderId == id } && canWrite) {
            val result = repo.generateOrderPlan(id); error = result.exceptionOrNull()?.message; if (result.isSuccess) refresh()
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("tp-planner-machines")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (selectedMachine == null) {
            Text("Sex", fontWeight = FontWeight.Bold)
            TpFilterRow(shops, shopId, { it.id }, { it.name }) { shopId = it }
            Text("Ishsiz stanoklar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (idle.isEmpty()) Text("Ishsiz stanok yo‘q.")
            idle.forEach { machine ->
                val compatibleCount = compatibleOrders(machine).size
                TpCard(Modifier.clickable { selectedMachineId = machine.id; showMachineOrders = false }) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${machine.number}-stanok", fontWeight = FontWeight.Bold)
                            Text("Ishsiz • eng oxirgi faoliyat: ${lastActivity(machine.id).take(16).replace('T',' ').ifBlank { "noma’lum" }}")
                        }
                        OutlinedButton(onClick = { selectedMachineId = machine.id; showMachineOrders = compatibleCount > 0 }) {
                            Text(if (compatibleCount > 0) "Mos zakaz: $compatibleCount" else "Mos zakaz yo‘q")
                        }
                    }
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Text("Ishi bor stanoklar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            busy.forEach { machine ->
                val mins = remaining(machine.id)
                val compatibleCount = compatibleOrders(machine).size
                TpCard(Modifier.clickable { selectedMachineId = machine.id; showMachineOrders = false }) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${machine.number}-stanok", fontWeight = FontWeight.Bold)
                            Text("Ishi: ${minutesLabel(mins)}", color = if (mins <= 1080) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                            if (mins <= 1080) Text("⚠ 18 soat yoki undan kam ish qolgan", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                        OutlinedButton(onClick = { selectedMachineId = machine.id; showMachineOrders = compatibleCount > 0 }) {
                            Text(if (compatibleCount > 0) "Mos zakaz: $compatibleCount" else "Mos zakaz yo‘q")
                        }
                    }
                }
            }
        } else {
            TextButton(onClick = { selectedMachineId = null; showMachineOrders = false; selectedOrderId = null }) { Text("‹ Stanoklar") }
            TpCard {
                Text("${selectedMachine.number}-stanok", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Jami rejalangan ish: ${minutesLabel(remaining(selectedMachine.id))}")
                val queue = data.jobs.filter { it.machineId == selectedMachine.id && it.planConfirmedAt != null && it.status != TpJobStatus.COMPLETE }.sortedBy { it.priority }
                queue.take(5).forEach { job ->
                    val order = data.orders.firstOrNull { it.id == job.orderId }
                    Text("• ${order?.articleSnapshot.orEmpty()} • ${job.outputs.joinToString { it.detailName }} • ${job.colorCode}", style = MaterialTheme.typography.bodySmall)
                }
            }
            OutlinedButton(onClick = { showMachineOrders = !showMachineOrders; if (!showMachineOrders) selectedOrderId = null }, modifier = Modifier.fillMaxWidth()) {
                Text(if (showMachineOrders) "Buyurtmalarni yopish" else "Buyurtmalar")
            }
            if (showMachineOrders) {
            Text("Buyurtmalar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            val orders = compatibleOrders(selectedMachine)
            if (selectedOrderId == null) {
                if (orders.isEmpty()) Text("Bu stanok uchun normal mos buyurtma yo‘q.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                orders.forEach { order ->
                    TpCard(Modifier.clickable { selectedOrderId = order.id }) { TpOrderSummary(data, order); Text("Shu stanokka mos detallarni ko‘rish", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
                }
            } else {
                val order = data.orders.firstOrNull { it.id == selectedOrderId }
                OutlinedButton(onClick = { selectedOrderId = null }) { Text("‹ Buyurtmalar") }
                if (order != null) {
                    TpCard { TpOrderSummary(data, order) }
                    val groups = data.jobs.filter { it.orderId == order.id && it.status != TpJobStatus.COMPLETE }.groupBy { it.moldCode }
                    val compatible = groups.filterValues { rows -> rows.all { it.acceptsMachine(selectedMachine, data) } }
                    val incompatible = groups.filterKeys { it !in compatible.keys }
                    compatible.forEach { (mold, rows) ->
                        val names = rows.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString()
                        val plannedMachine = rows.mapNotNull { it.machineId }.distinct().singleOrNull()
                        val plannedNumber = data.machines.firstOrNull { it.id == plannedMachine }?.number
                        val confirmed = rows.all { it.planConfirmedAt != null }
                        TpCard {
                            Text(names.ifBlank { mold }, fontWeight = FontWeight.Bold)
                            Text(if (plannedMachine == selectedMachine.id) "Shu stanokka rejalangan${if (confirmed) " • tasdiqlangan" else ""}" else if (plannedMachine != null) "Rejalangan: ${plannedNumber ?: "?"}-stanok" else "Rejalanmagan")
                            if (canWrite) OutlinedButton(onClick = { assignMold = mold }, Modifier.fillMaxWidth()) { Text(if (plannedMachine == null) "Shu stanokka rejalash" else "Planni tahrirlash") }
                            if (!confirmed && plannedMachine == selectedMachine.id && rows.all { it.brigadeId != null }) OutlinedButton(onClick = { val r=repo.confirmPlannedMold(order.id,mold); error=r.exceptionOrNull()?.message; if(r.isSuccess) refresh() }, Modifier.fillMaxWidth()) { Text("✓ Tasdiqlash") }
                        }
                    }
                    if (incompatible.isNotEmpty()) {
                        HorizontalDivider(); Text("⚠ Bu stanokka tushmaydigan detallar", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                        incompatible.forEach { (_, rows) -> Text("• ${rows.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString()}", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            }
            TpError(error)
        }
    }
    val order = data.orders.firstOrNull { it.id == selectedOrderId }
    val mold = assignMold
    if (selectedMachine != null && order != null && mold != null) {
        val target = data.jobs.filter { it.orderId == order.id && it.moldCode == mold }
        TpFixedMachineAssignDialog(data, order, target, selectedMachine, target.any { it.machineId != null }, onDismiss = { assignMold = null }) { reason ->
            val r = repo.assignMoldJobs(order.id, mold, selectedMachine.id, reason); error = r.exceptionOrNull()?.message
            if (r.isSuccess) { assignMold = null; refresh() }; r.isSuccess
        }
    }
}

private fun commonJobResinOptions(data: TpData, job: TpPlanJob): List<String> {
    val sets = job.outputs.mapNotNull { output ->
        data.products.asSequence().flatMap { it.details.asSequence() }
            .firstOrNull { it.id == output.detailId }?.resinOptions()?.toSet()
    }
    if (sets.isEmpty()) return listOfNotNull(job.resinCode.takeIf { it.isNotBlank() })
    return sets.drop(1).fold(sets.first()) { acc, set -> acc intersect set }.sorted()
}

@Composable
private fun TpMachinePickerDialog(
    data: TpData,
    order: TpOrder,
    moldCode: String,
    editing: Boolean = false,
    onDismiss: () -> Unit,
    onSave: (String, String, Boolean, String) -> Boolean
) {
    val targetJobs = data.jobs.filter { it.orderId == order.id && it.moldCode == moldCode }
    val targetIds = targetJobs.map { it.id }.toSet()
    fun availability(machineId: String): Int = data.jobs
        .filter { it.machineId == machineId && it.status != TpJobStatus.COMPLETE && it.id !in targetIds }
        .sumOf { it.estimatedMinutes }
    val allMachines = data.machines.filterNot { it.archived }.sortedWith(compareBy<TpMachine> { availability(it.id) }.thenBy { it.number })
    val machines = allMachines.filter { machine -> targetJobs.isNotEmpty() && targetJobs.all { it.acceptsMachine(machine, data) } }
    val otherMachines = allMachines.filter { it !in machines }
    val currentMachineId = targetJobs.mapNotNull { it.machineId }.distinct().singleOrNull()
    val currentWasOverride = targetJobs.any { it.machineOverride }
    var otherMode by remember(order.id, moldCode) { mutableStateOf(currentWasOverride) }
    var machineId by remember(order.id, moldCode) { mutableStateOf(currentMachineId ?: machines.firstOrNull()?.id.orEmpty()) }
    val selectedMachine = allMachines.firstOrNull { it.id == machineId }
    var infoMachine by remember { mutableStateOf<TpMachine?>(null) }
    var editReason by remember(order.id, moldCode, editing) { mutableStateOf("") }
    var overrideReason by remember(order.id, moldCode) { mutableStateOf(targetJobs.firstOrNull { it.machineOverride }?.machineOverrideReason.orEmpty()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Stanok tanlash") },
        text = {
            Column(Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val detailNames = targetJobs.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString()
                if (detailNames.isNotBlank()) Text("Detal: $detailNames", fontWeight = FontWeight.Bold)
                if (machines.isEmpty() && !otherMode) {
                    Text("Mos stanok topilmadi. Tajriba yoki majburiy ishlab chiqarish uchun ‘Boshqa stanok’ni tanlash mumkin.", color = MaterialTheme.colorScheme.error)
                } else if (!otherMode) {
                    Text("Bo‘sh stanoklar tepada. Band stanoklar eng tez bo‘shaydiganidan boshlab tartiblangan.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val freeMachines = machines.filter { availability(it.id) == 0 }
                    val busyMachines = machines.filter { availability(it.id) > 0 }
                    if (freeMachines.isNotEmpty()) Text("Bo‘sh stanoklar", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    (freeMachines + busyMachines).forEachIndexed { index, machine ->
                        if (index == freeMachines.size && busyMachines.isNotEmpty()) {
                            Text("Band stanoklar", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        val wait = availability(machine.id)
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable { machineId = machine.id },
                            shape = RoundedCornerShape(14.dp),
                            tonalElevation = if (machine.id == machineId) 4.dp else 1.dp
                        ) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                RadioButton(selected = machine.id == machineId, onClick = { machineId = machine.id })
                                Column(Modifier.weight(1f)) {
                                    val shopName = data.shops.firstOrNull { it.id == machine.shopId }?.name.orEmpty()
                                    Text("${machine.number}-stanok • ${shopName.ifBlank { "Sex" }}${if (machine.capacity > 0) " • sig‘im ${machine.capacity}" else ""}", fontWeight = FontWeight.Bold)
                                    Text(if (wait == 0) "Bo‘sh" else "Band • taxminan ${minutesLabel(wait)} dan keyin bo‘shaydi", color = if (wait == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                TextButton(onClick = { infoMachine = machine }) { Text("Ma’lumot") }
                            }
                        }
                    }
                    selectedMachine?.let { machine ->
                        val wait = availability(machine.id)
                        Text(if (wait == 0) "Tanlangan stanokda ishni darhol boshlash mumkin." else "Tanlangan stanokda boshlanish: taxminan ${minutesLabel(wait)} dan keyin.", fontWeight = FontWeight.SemiBold)
                        val targetIdsForAuto = targetJobs.map { it.id }.toSet()
                        val waitForAuto = data.jobs.filter { it.machineId == machine.id && it.status != TpJobStatus.COMPLETE && it.id !in targetIdsForAuto }.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
                        val autoBrigade = data.autoBrigadeForMachine(machine.id, waitForAuto)
                        if (autoBrigade != null) {
                            val shift = data.shifts.firstOrNull { it.id == autoBrigade.shiftId }
                            Text("Brigada avtomatik: ${autoBrigade.name}${shift?.name?.let { " • $it" }.orEmpty()}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        } else Text("Bu sex uchun smenaga mos brigada topilmadi.", color = MaterialTheme.colorScheme.error)
                        if (editing) {
                            TpField(editReason, { editReason = it }, "Tahrirlash sharhi *", singleLine = false)
                            Text("Tasdiqlangan/rejalangan detalni o‘zgartirish sababi majburiy.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                } else {
                    Text("Boshqa stanok", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                    Text("Bu istisno tajriba, favqulodda yoki majburiy ishlab chiqarish uchun. Sabab audit tarixida saqlanadi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    otherMachines.forEach { machine ->
                        val wait = availability(machine.id)
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable { machineId = machine.id },
                            shape = RoundedCornerShape(14.dp),
                            tonalElevation = if (machine.id == machineId) 4.dp else 1.dp
                        ) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                RadioButton(selected = machine.id == machineId, onClick = { machineId = machine.id })
                                Column(Modifier.weight(1f)) {
                                    val shopName = data.shops.firstOrNull { it.id == machine.shopId }?.name.orEmpty()
                                    Text("${machine.number}-stanok • ${shopName.ifBlank { "Sex" }}", fontWeight = FontWeight.Bold)
                                    Text(if (wait == 0) "Bo‘sh • moslik istisnosi" else "Band • ${minutesLabel(wait)} dan keyin • moslik istisnosi", color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                    TpField(overrideReason, { overrideReason = it }, "Boshqa stanok sababi *", singleLine = false)
                    selectedMachine?.let { machine ->
                        val wait = availability(machine.id)
                        val autoBrigade = data.autoBrigadeForMachine(machine.id, wait)
                        if (autoBrigade == null) Text("Bu stanok sexi uchun smenaga mos brigada topilmadi.", color = MaterialTheme.colorScheme.error)
                    }
                    if (editing) TpField(editReason, { editReason = it }, "Tahrirlash sharhi *", singleLine = false)
                }
                TextButton(onClick = {
                    otherMode = !otherMode
                    machineId = if (otherMode) otherMachines.firstOrNull()?.id.orEmpty() else machines.firstOrNull()?.id.orEmpty()
                }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (otherMode) "← Tavsiya etilgan stanoklar" else "Boshqa stanok")
                }
            }
        },
        confirmButton = { TextButton(enabled = machineId.isNotBlank() && selectedMachine?.let { machine ->
            val ids = targetJobs.map { it.id }.toSet()
            val wait = data.jobs.filter { it.machineId == machine.id && it.status != TpJobStatus.COMPLETE && it.id !in ids }.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
            data.autoBrigadeForMachine(machine.id, wait) != null
        } == true && (!editing || editReason.isNotBlank()) && (!otherMode || overrideReason.isNotBlank()), onClick = {
            if (onSave(machineId, editReason, otherMode, overrideReason)) onDismiss()
        }) { Text(if (editing) "Tahrirlash" else "Tanlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )

    infoMachine?.let { machine ->
        val current = data.activeJobsForMachine(machine.id).firstOrNull { it.id !in targetIds }
        val currentOrder = current?.let { job -> data.orders.firstOrNull { it.id == job.orderId } }
        AlertDialog(
            onDismissRequest = { infoMachine = null },
            title = { Text("${machine.number}-stanok") },
            text = {
                if (current == null) Text("Hozir bo‘sh.") else Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Hozir band", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                    Text("Partiya: ${currentOrder?.batchNumber.orEmpty()}")
                    Text("Artikul: ${currentOrder?.articleSnapshot.orEmpty()}")
                    Text("Mahsulot: ${currentOrder?.productNameSnapshot.orEmpty()}")
                    Text("Detal: ${current.outputs.joinToString { it.detailName }}")
                    Text("Rang: ${current.colorCode}")
                    if (current.resinCode.isNotBlank()) Text("Seryo: ${current.resinCode}")
                    Text("Holat: ${jobStatusLabel(current.status)}")
                    Text("Taxminiy vazifa vaqti: ${minutesLabel(current.estimatedMinutes)}")
                }
            },
            confirmButton = { TextButton(onClick = { infoMachine = null }) { Text("Yopish") } }
        )
    }
}

@Composable
private fun TpFixedMachineAssignDialog(
    data: TpData,
    order: TpOrder,
    targetJobs: List<TpPlanJob>,
    machine: TpMachine,
    editing: Boolean,
    onDismiss: () -> Unit,
    onSave: (String) -> Boolean
) {
    val targetIds = targetJobs.map { it.id }.toSet()
    val waitMinutes = data.jobs.filter { it.machineId == machine.id && it.status != TpJobStatus.COMPLETE && it.id !in targetIds }.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
    val autoBrigade = data.autoBrigadeForMachine(machine.id, waitMinutes)
    var reason by remember(machine.id, order.id, editing) { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${machine.number}-stanokka rejalash") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${order.articleSnapshot} • ${order.productNameSnapshot}", fontWeight = FontWeight.Bold)
            Text(targetJobs.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString())
            if (autoBrigade != null) {
                val shift = data.shifts.firstOrNull { it.id == autoBrigade.shiftId }
                Text("Brigada avtomatik: ${autoBrigade.name}${shift?.name?.let { " • $it" }.orEmpty()}", color = MaterialTheme.colorScheme.primary)
            } else Text("Bu sex uchun smenaga mos brigada topilmadi.", color = MaterialTheme.colorScheme.error)
            Text(if (waitMinutes <= 0) "Stanok bo‘sh — reja hozirgi smenadan boshlanadi." else "Stanok band — navbatdagi ish taxminan ${minutesLabel(waitMinutes)} dan keyin boshlanadi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (editing) TpField(reason, { reason = it }, "Tahrirlash sharhi *", singleLine = false)
        } },
        confirmButton = { TextButton(enabled = autoBrigade != null && (!editing || reason.isNotBlank()), onClick = { if (onSave(reason)) onDismiss() }) { Text("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

@Composable
private fun TpMachineQueuePage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_MACHINE)
    var error by remember { mutableStateOf<String?>(null) }
    var expandedMachineId by remember { mutableStateOf<String?>(null) }
    var downtimeMachine by remember { mutableStateOf<TpMachine?>(null) }
    val allowedBrigadeIds = data.brigades.filterNot { it.archived }.map { it.id }.toSet()
    val allowedShopIds = data.brigades.filterNot { it.archived }.map { it.shopId }.toSet()
    val machines = data.machines.filter { !it.archived && (policy.isAdmin() || it.shopId in allowedShopIds) }.sortedBy { it.number }
    val visibleJobs = data.jobs.filter {
        it.planConfirmedAt != null && it.machineId != null && it.status != TpJobStatus.COMPLETE &&
            (policy.isAdmin() || it.brigadeId in allowedBrigadeIds)
    }
    val jobsByMachine = visibleJobs.groupBy { it.machineId.orEmpty() }
    val busyMachines = machines.filter { jobsByMachine[it.id].orEmpty().isNotEmpty() }.sortedWith(compareBy<TpMachine> { machine ->
        jobsByMachine[machine.id].orEmpty().none { it.status == TpJobStatus.IN_PROGRESS }
    }.thenBy { machine -> jobsByMachine[machine.id].orEmpty().minOfOrNull { it.priority } ?: Int.MAX_VALUE }.thenBy { it.number })
    val idleMachines = machines.filter { jobsByMachine[it.id].orEmpty().isEmpty() }.sortedBy { it.number }
    val today = LocalDate.now().toString()

    @Composable
    fun MachineCard(machine: TpMachine, jobs: List<TpPlanJob>) {
        val shop = data.shops.firstOrNull { it.id == machine.shopId }
        val isIdle = jobs.isEmpty()
        val expanded = expandedMachineId == machine.id
        val todayStops = data.machineDowntimes.filter { it.machineId == machine.id && it.date == today }
        TpCard {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${machine.number}-stanok • ${shop?.name.orEmpty()}", fontWeight = FontWeight.Bold)
                    if (isIdle) {
                        Text("Zakaz yo‘q", color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold)
                    } else {
                        val active = jobs.filter { it.status == TpJobStatus.IN_PROGRESS }
                        val queued = jobs.filter { it.status != TpJobStatus.IN_PROGRESS }
                        Text("${active.size} ishda • ${queued.size} navbatda")
                        val remaining = jobs.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
                        Text("Taxminiy ish: ${minutesLabel(remaining)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        val delivered = jobs.count { it.materialStatus == TpMaterialStatus.DELIVERED }
                        if (delivered > 0) Text("✓ Seryo yetkazilgan: $delivered/${jobs.size}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    }
                    if (todayStops.isNotEmpty()) {
                        Text("Bugun o‘chish: ${todayStops.size} marta • ${todayStops.sumOf { it.durationMinutes() }} daqiqa", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
                if (!isIdle) TextButton(onClick = { expandedMachineId = if (expanded) null else machine.id }) { Text(if (expanded) "▲" else "▼") }
            }
            if (canWrite) OutlinedButton(onClick = { downtimeMachine = machine }, Modifier.fillMaxWidth()) { Text("+ Stanok o‘chgan vaqtini kiritish") }
            if (expanded) {
                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                jobs.sortedWith(compareBy<TpPlanJob> { it.status != TpJobStatus.IN_PROGRESS }.thenBy { it.priority }).forEach { job ->
                    val order = data.orders.firstOrNull { it.id == job.orderId }
                    val delivered = job.materialStatus == TpMaterialStatus.DELIVERED
                    val started = job.status == TpJobStatus.IN_PROGRESS
                    Surface(
                        Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = if (started) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .45f)
                    ) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.SemiBold)
                            Text(job.outputs.map { it.detailName }.distinct().joinToString())
                            Text("Rang ${job.colorCode} • Seryo ${job.resinCode}")
                            val completeReady = job.outputs.all { output ->
                                data.receipts.filter { !it.isCancelled && it.jobId == job.id && it.detailId == output.detailId }.sumOf { it.creditedPieces } >= output.requiredPieces
                            }
                            Text("Holat: ${jobOperationalStatusLabel(job, completeReady)}", fontWeight = FontWeight.SemiBold, color = when {
                                job.status == TpJobStatus.HOLD -> MaterialTheme.colorScheme.error
                                completeReady && job.status == TpJobStatus.IN_PROGRESS -> MaterialTheme.colorScheme.primary
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            })
                            Text(tpBrigadirTimingLabel(job), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(if (delivered) "✓ Seryo yetkazilgan" else "Seryo yetkazilmagan", color = if (delivered) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                            if (canWrite && job.status == TpJobStatus.QUEUED) Button(
                                enabled = delivered,
                                onClick = {
                                    error = repo.setJobStatus(job.id, TpJobStatus.IN_PROGRESS).exceptionOrNull()?.message
                                    if (error == null) refresh()
                                }, modifier = Modifier.fillMaxWidth()
                            ) { Text("Boshlash") }
                            if (canWrite && job.status == TpJobStatus.HOLD) Button(
                                enabled = delivered,
                                onClick = {
                                    error = repo.setJobStatus(job.id, TpJobStatus.IN_PROGRESS).exceptionOrNull()?.message
                                    if (error == null) refresh()
                                }, modifier = Modifier.fillMaxWidth()
                            ) { Text("Davom ettirish") }
                            if (started) {
                                Text("Boshlangan: ${job.startedAt?.take(16)?.replace('T', ' ') ?: "—"}")
                                if (canWrite && !completeReady) OutlinedButton(onClick = {
                                    error = repo.setJobStatus(job.id, TpJobStatus.HOLD).exceptionOrNull()?.message
                                    if (error == null) refresh()
                                }, Modifier.fillMaxWidth()) { Text("To‘xtatish") }
                                if (canWrite && completeReady) Button(onClick = {
                                    error = repo.setJobStatus(job.id, TpJobStatus.COMPLETE).exceptionOrNull()?.message
                                    if (error == null) refresh()
                                }, Modifier.fillMaxWidth()) { Text("${job.colorCode} ni yakunlash") }
                            }
                        }
                    }
                }
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-machine-queue"))
            .navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Zakazi bor stanoklar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (busyMachines.isEmpty()) Text("Hozir zakazi bor stanok yo‘q.")
        busyMachines.forEach { machine -> MachineCard(machine, jobsByMachine[machine.id].orEmpty()) }
        HorizontalDivider(Modifier.padding(vertical = 6.dp))
        Text("Zakazi yo‘q stanoklar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (idleMachines.isEmpty()) Text("Barcha stanoklarda zakaz bor.")
        idleMachines.forEach { machine -> MachineCard(machine, emptyList()) }
        TpError(error)
    }

    downtimeMachine?.let { machine ->
        val matchingBrigades = data.brigades.filter { !it.archived && it.shopId == machine.shopId }.sortedBy { it.name }
        var brigadeId by remember(machine.id) { mutableStateOf(matchingBrigades.firstOrNull()?.id.orEmpty()) }
        var date by remember(machine.id) { mutableStateOf(today) }
        var stoppedAt by remember(machine.id) { mutableStateOf("") }
        var startedAt by remember(machine.id) { mutableStateOf("") }
        var reason by remember(machine.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { downtimeMachine = null },
            title = { Text("${machine.number}-stanok • o‘chish vaqti") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Stanok bir kunda bir necha marta o‘chishi mumkin. Har bir holat alohida saqlanadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                TpChoice("Brigada", brigadeId, matchingBrigades, { it.id }, { it.name }) { brigadeId = it }
                TpDatePickerButton("Sana", date) { date = it }
                TpField(stoppedAt, { stoppedAt = it.filter { ch -> ch.isDigit() || ch == ':' }.take(5) }, "O‘chgan vaqt (HH:mm)")
                TpField(startedAt, { startedAt = it.filter { ch -> ch.isDigit() || ch == ':' }.take(5) }, "Yongan vaqt (HH:mm)")
                TpField(reason, { reason = it }, "Sabab / izoh *", singleLine = false)
            } },
            confirmButton = { TextButton(enabled = stoppedAt.length == 5 && startedAt.length == 5 && reason.isNotBlank() && brigadeId.isNotBlank(), onClick = {
                val result = repo.addMachineDowntime(machine.id, brigadeId, date, stoppedAt, startedAt, reason)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { downtimeMachine = null; refresh() }
            }) { Text("Saqlash") } },
            dismissButton = { TextButton(onClick = { downtimeMachine = null }) { Text("Bekor qilish") } }
        )
    }
}

@Composable
private fun TpAttendancePage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_ATTENDANCE)
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    var shopId by remember { mutableStateOf("") }
    val brigades = data.brigades.filterNot { it.archived }.filter { shopId.isBlank() || it.shopId == shopId }.sortedBy { it.name }
    var brigadeId by remember(shopId) { mutableStateOf("") }
    var editWorker by remember { mutableStateOf<TpWorker?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val visibleBrigadeIds = brigades.map { it.id }.toSet()
    val workers = data.workers.filter { !it.archived && it.brigadeId in visibleBrigadeIds && (brigadeId.isBlank() || it.brigadeId == brigadeId) }.sortedBy { it.name }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-screen-6")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Davomatni TP plan beruvchi kiritadi. Ish vaqti smena davomiyligidan minus soatni ayirish orqali avtomatik hisoblanadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        TpField(date, { date = it }, "Sana (YYYY-MM-DD)")
        TpChoice("Bo‘lim", shopId, listOf(TpShop("", "Barcha bo‘limlar")) + shops, { it.id }, { it.name }) { shopId = it }
        TpChoice("Brigada", brigadeId, listOf(TpBrigade("", "", "", "Barcha brigadalar")) + brigades, { it.id }, { it.name }) { brigadeId = it }
        if (workers.isEmpty()) Text("Tanlangan filtrda ishchi yo‘q.")
        val fullWorkers = workers.filter { worker -> data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }.let { day -> day == null || (day.present && day.minusHours <= 0.0) } }
        val minusWorkers = workers.filter { worker -> data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }?.let { it.present && it.minusHours > 0.0 } == true }
        val absentWorkers = workers.filter { worker -> data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }?.present == false }
        val groups = listOf("To‘liq ishlagan" to fullWorkers, "Minus soati bor" to minusWorkers, "Ishlamagan" to absentWorkers)
        groups.forEachIndexed { groupIndex, (groupTitle, groupWorkers) ->
            if (groupIndex > 0) HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Text(groupTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (groupWorkers.isEmpty()) Text("—", color = MaterialTheme.colorScheme.onSurfaceVariant)
            groupWorkers.forEach { worker ->
                val day = data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }
                val actualMinutes = if (day == null) data.workerStandardMinutes(worker.id) else data.attendanceWorkMinutes(worker.id, date)
                TpCard(Modifier.clickable(enabled = canWrite) { editWorker = worker }) {
                    Text(worker.name, fontWeight = FontWeight.Bold)
                    Text(data.brigades.firstOrNull { it.id == worker.brigadeId }?.name.orEmpty(), style = MaterialTheme.typography.bodySmall)
                    Text(when {
                        day == null -> "To‘liq ishlagan (standart) • ${data.workerStandardMinutes(worker.id)} daqiqa"
                        !day.present -> "Ishlamadi"
                        day.minusHours > 0.0 -> "Minus ${formatTpNumber(day.minusHours)} soat • hisobdagi ish vaqti $actualMinutes daqiqa"
                        else -> "To‘liq ishlagan • $actualMinutes daqiqa"
                    })
                    Text("Umumiy kunlik norma: ${data.globalDailyTargetAmount()} so‘m", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        TpError(error)
    }
    editWorker?.let { worker ->
        val existing = data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }
        var present by remember(worker.id, date) { mutableStateOf(existing?.present ?: true) }
        var minusHours by remember(worker.id, date) { mutableStateOf(existing?.minusHours?.takeIf { it > 0.0 }?.let(::formatTpNumber) ?: "") }
        val standardMinutes = data.workerStandardMinutes(worker.id)
        val parsedMinus = minusHours.toDoubleOrNull() ?: 0.0
        val calculated = if (present) (standardMinutes - kotlin.math.round(parsedMinus * 60.0).toInt()).coerceAtLeast(0) else 0
        AlertDialog(
            onDismissRequest = { editWorker = null },
            title = { Text(worker.name) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Smena bo‘yicha standart: ${minutesLabel(standardMinutes)}")
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Ishda", Modifier.weight(1f)); Switch(present, { present = it; if (!it) minusHours = "" }) }
                TpField(minusHours, { minusHours = decimalInput(it) }, "Minus soat", KeyboardType.Decimal, enabled = present)
                Text("Hisoblanadigan ish vaqti: ${minutesLabel(calculated)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Masalan 1 soat = 60 daqiqa, 1.5 soat = 90 daqiqa.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } },
            confirmButton = { TextButton(onClick = {
                val result = repo.setAttendance(worker.id, date, present, minusHours.toDoubleOrNull() ?: 0.0)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { editWorker = null; refresh() }
            }) { Text("Saqlash") } },
            dismissButton = { TextButton(onClick = { editWorker = null }) { Text("Bekor qilish") } }
        )
    }
}

@Composable
private fun TpExtraHoursPage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_EXTRA_HOURS)
    val brigades = data.brigades.filterNot { it.archived }.sortedBy { it.name }
    var brigadeId by remember(brigades) { mutableStateOf(brigades.firstOrNull()?.id.orEmpty()) }
    var selectedDate by remember { mutableStateOf(LocalDate.now().toString()) }
    var editType by remember { mutableStateOf<TpExtraHourType?>(null) }
    var showTypeDialog by remember { mutableStateOf(false) }
    var selectedWorker by remember { mutableStateOf<TpWorker?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val visibleBrigades = brigades.take(6)
    if (brigadeId.isBlank() && visibleBrigades.isNotEmpty()) brigadeId = visibleBrigades.first().id
    val workers = data.workers.filter { !it.archived && it.brigadeId == brigadeId }.sortedBy { it.name }
    val types = data.extraHourTypes.filterNot { it.archived }.sortedBy { it.name }

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpExtraHours"))
            .navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Qo‘shimcha soat turlari va narxlari", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Qo‘shimcha soat yozuvi bo‘lmasa ishchi ma’lumoti to‘liq hisoblanadi; bu majburiy maydon emas.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (canWrite) Button(onClick = { editType = null; showTypeDialog = true }, Modifier.fillMaxWidth()) { Text("+ Qo‘shimcha soat turi / narxi") }
        if (types.isEmpty()) Text("Hali qo‘shimcha soat turi kiritilmagan.")
        types.forEach { type ->
            TpCard(Modifier.clickable(enabled = canWrite) { editType = type; showTypeDialog = true }) {
                Text(type.name, fontWeight = FontWeight.Bold)
                Text("${formatTpNumber(type.hourlyRate)} so‘m / soat")
            }
        }
        HorizontalDivider()
        Text("Brigada", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (visibleBrigades.isNotEmpty()) TpFilterRow(visibleBrigades, brigadeId, { it.id }, { it.name }) { brigadeId = it }
        if (brigades.size > 6) Text("Birinchi 6 ta faol brigada ko‘rsatildi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        TpDatePickerButton("Sana", selectedDate) { selectedDate = it }
        Text("Ishchilar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (workers.isEmpty()) Text("Tanlangan brigadada ishchi yo‘q.")
        workers.forEach { worker ->
            val rows = data.extraHours.filter { it.workerId == worker.id && it.date == selectedDate }
            val extra = rows.sumOf { it.amount }
            TpCard(Modifier.clickable(enabled = canWrite && types.isNotEmpty()) { selectedWorker = worker }) {
                Text(worker.name, fontWeight = FontWeight.Bold)
                if (rows.isNotEmpty()) {
                    Text("Qo‘shimcha: ${rows.sumOf { it.hours }.let(::formatTpNumber)} soat • $extra so‘m", color = MaterialTheme.colorScheme.primary)
                    rows.forEach { row -> Text("${row.typeNameSnapshot}: ${formatTpNumber(row.hours)} soat × ${formatTpNumber(row.hourlyRateSnapshot)} = ${row.amount} so‘m", style = MaterialTheme.typography.bodySmall) }
                } else Text("Qo‘shimcha soat yo‘q", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Jami topgan: ${data.workerEarned(worker.id, selectedDate)} so‘m", style = MaterialTheme.typography.bodySmall)
            }
        }
        TpError(error)
    }

    if (showTypeDialog) {
        var name by remember(editType?.id) { mutableStateOf(editType?.name.orEmpty()) }
        var rate by remember(editType?.id) { mutableStateOf(editType?.hourlyRate?.let(::formatTpNumber).orEmpty()) }
        AlertDialog(
            onDismissRequest = { showTypeDialog = false },
            title = { Text(if (editType == null) "Qo‘shimcha soat turi" else "Tur va narxni tahrirlash") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TpField(name, { name = it }, "Turi")
                TpField(rate, { rate = decimalInput(it) }, "1 soat narxi (so‘m)", KeyboardType.Decimal)
            } },
            confirmButton = { TextButton(onClick = {
                val result = repo.saveExtraHourType(editType?.id, name, rate.toDoubleOrNull() ?: 0.0)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { showTypeDialog = false; refresh() }
            }) { Text("Saqlash") } },
            dismissButton = { TextButton(onClick = { showTypeDialog = false }) { Text("Bekor qilish") } }
        )
    }

    selectedWorker?.let { worker ->
        var date by remember(worker.id) { mutableStateOf(selectedDate) }
        var typeId by remember(worker.id, types) { mutableStateOf(types.firstOrNull()?.id.orEmpty()) }
        var hours by remember(worker.id) { mutableStateOf("") }
        var note by remember(worker.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { selectedWorker = null },
            title = { Text(worker.name) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TpDatePickerButton("Sana", date) { date = it }
                TpChoice("Qo‘shimcha soat turi", typeId, types, { it.id }, { "${it.name} • ${formatTpNumber(it.hourlyRate)} so‘m/soat" }) { typeId = it }
                TpField(hours, { hours = decimalInput(it) }, "Qo‘shimcha soat", KeyboardType.Decimal)
                TpField(note, { note = it }, "Izoh (ixtiyoriy)", singleLine = false)
                val rate = types.firstOrNull { it.id == typeId }?.hourlyRate ?: 0.0
                val amount = (hours.toDoubleOrNull() ?: 0.0) * rate
                if (amount > 0) Text("Hisob: ${amount.toLong()} so‘m", color = MaterialTheme.colorScheme.primary)
            } },
            confirmButton = { TextButton(onClick = {
                val result = repo.addWorkerExtraHour(worker.id, date, typeId, hours.toDoubleOrNull() ?: 0.0, note)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { selectedDate = date; selectedWorker = null; refresh() }
            }) { Text("Saqlash") } },
            dismissButton = { TextButton(onClick = { selectedWorker = null }) { Text("Bekor qilish") } }
        )
    }
}

@Composable
internal fun TpNavRow(title: String, badgeCount: Int = 0, onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            if (badgeCount > 0) {
                Surface(shape = RoundedCornerShape(999.dp), color = MaterialTheme.colorScheme.error) {
                    Text(badgeCount.coerceAtMost(999).toString(), Modifier.padding(horizontal = 8.dp, vertical = 2.dp), color = MaterialTheme.colorScheme.onError, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(8.dp))
            }
            Text("›", style = MaterialTheme.typography.headlineSmall)
        }
    }
}

@Composable
internal fun TpCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outline.copy(alpha = 0.62f)
        ),
        tonalElevation = 0.dp,
        shadowElevation = 2.dp
    ) {
        Column(
            Modifier.padding(horizontal = 14.dp, vertical = 13.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            content = content
        )
    }
}

@Composable
internal fun TpField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    enabled: Boolean = true
) {
    val numeric = keyboardType == KeyboardType.Number || keyboardType == KeyboardType.Decimal
    var focusedBefore by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        modifier = Modifier.fillMaxWidth().onFocusChanged { state ->
            if (numeric && state.isFocused && !focusedBefore && value.trim() in setOf("0", "0.0", "0.00")) onChange("")
            focusedBefore = state.isFocused
        },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType), singleLine = singleLine, enabled = enabled
    )
}

@Composable
internal fun <T> TpChoice(
    label: String,
    selectedId: String,
    options: List<T>,
    id: (T) -> String,
    text: (T) -> String,
    onSelect: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val selected = options.firstOrNull { id(it) == selectedId }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: ${selected?.let(text) ?: "Tanlang"}", Modifier.weight(1f))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(text(option)) }, onClick = { open = false; onSelect(id(option)) }) }
        }
    }
}

@Composable
internal fun TpError(message: String?) {
    if (!message.isNullOrBlank()) Text(message, color = MaterialTheme.colorScheme.error)
}

internal fun digitsOnly(value: String): String = value.filter(Char::isDigit)
internal fun decimalInput(value: String): String {
    var separator = false
    return buildString {
        value.forEach { char ->
            if (char.isDigit()) append(char)
            else if ((char == '.' || char == ',') && !separator) { append('.'); separator = true }
        }
    }
}
private fun tpBrigadirTimingLabel(job: TpPlanJob): String {
    val planned = minutesLabel(job.estimatedMinutes.coerceAtLeast(0))
    val started = job.startedAt?.let { runCatching { java.time.LocalDateTime.parse(it) }.getOrNull() }
        ?: return "Taxminiy davomiylik: $planned"
    val finish = started.plusMinutes(job.estimatedMinutes.coerceAtLeast(0).toLong())
    val remaining = java.time.Duration.between(java.time.LocalDateTime.now(), finish).toMinutes().coerceAtLeast(0L).toInt()
    val finishTime = finish.format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"))
    return "Taxminiy tugash: $finishTime • qolgan ${minutesLabel(remaining)}"
}

internal fun minutesLabel(minutes: Int): String = "${minutes / 60} soat ${minutes % 60} daqiqa"
internal fun orderStatusLabel(status: TpOrderStatus): String = when (status) {
    TpOrderStatus.NEW -> "Yangi"
    TpOrderStatus.PLANNING, TpOrderStatus.READY, TpOrderStatus.APPROVED -> "Rejalashda"
    TpOrderStatus.IN_PROGRESS -> "Ishlab chiqarishda"
    TpOrderStatus.COMPLETE -> "Yakunlangan"
    TpOrderStatus.CANCELLED -> "Bekor qilingan"
}
internal fun jobStatusLabel(status: TpJobStatus): String = when (status) {
    TpJobStatus.UNASSIGNED -> "Taqsimlanmagan"; TpJobStatus.QUEUED -> "Navbatda"; TpJobStatus.IN_PROGRESS -> "Ishda"
    TpJobStatus.COMPLETE -> "Yakunlangan"; TpJobStatus.HOLD -> "To‘xtagan"
}

internal fun jobOperationalStatusLabel(job: TpPlanJob, completeReady: Boolean = false): String = when {
    job.status == TpJobStatus.COMPLETE -> "Yakunlangan"
    job.status == TpJobStatus.HOLD -> "To‘xtagan"
    job.status == TpJobStatus.IN_PROGRESS && completeReady -> "Yakunlashga tayyor"
    job.status == TpJobStatus.IN_PROGRESS -> "Ishda"
    job.planConfirmedAt != null && job.materialStatus != TpMaterialStatus.DELIVERED -> "Seryo kutilmoqda"
    job.status == TpJobStatus.QUEUED && job.materialStatus == TpMaterialStatus.DELIVERED -> "Boshlashga tayyor"
    else -> jobStatusLabel(job.status)
}
internal fun materialStatusLabel(status: TpMaterialStatus): String = when (status) {
    TpMaterialStatus.PLANNED -> "Tayyorlanmagan"; TpMaterialStatus.CONFIRMED -> "Tayyor"; TpMaterialStatus.DELIVERED -> "Stanokka chiqarilgan"
}
