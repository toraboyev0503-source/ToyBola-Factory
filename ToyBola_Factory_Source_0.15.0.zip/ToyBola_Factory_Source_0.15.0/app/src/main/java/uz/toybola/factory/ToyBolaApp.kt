package uz.toybola.factory

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.toybola.factory.core.data.AssemblyDataRepository
import uz.toybola.factory.core.data.TpDataRepository
import uz.toybola.factory.core.firebase.*
import uz.toybola.factory.core.notifications.NotificationInboxRepository
import uz.toybola.factory.core.notifications.NotificationRouteState
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.canReadScreen
import uz.toybola.factory.ui.navigation.TpNavigationTargetState
import uz.toybola.factory.ui.navigation.NavigationGuardState
import uz.toybola.factory.ui.components.AppNavigationEvents
import uz.toybola.factory.ui.components.GlobalBottomBar
import uz.toybola.factory.ui.model.AppScreen
import uz.toybola.factory.ui.model.AppStrings
import uz.toybola.factory.ui.screens.*
import uz.toybola.factory.ui.theme.ToyBolaTheme

private enum class RootTab { HOME, NOTIFICATIONS, SYNC, SETTINGS }

private val RootTabSaver = Saver<RootTab, String>(
    save = { it.name },
    restore = { runCatching { RootTab.valueOf(it) }.getOrDefault(RootTab.HOME) }
)

private fun screenStackSaver(default: AppScreen) = listSaver<SnapshotStateList<AppScreen>, String>(
    save = { stack -> stack.map { it.name } },
    restore = { names ->
        mutableStateListOf<AppScreen>().apply {
            addAll(names.mapNotNull { runCatching { AppScreen.valueOf(it) }.getOrNull() })
            if (isEmpty()) add(default)
        }
    }
)

@Composable
fun ToyBolaApp(
    preferences: AppPreferences,
    assemblyDataRepository: AssemblyDataRepository,
    tpDataRepository: TpDataRepository,
    notificationInboxRepository: NotificationInboxRepository
) {
    var settings by remember { mutableStateOf(preferences.loadSettings()) }
    val serverAuthRepository = remember { ServerAuthRepository(preferences.appContext) }
    val initialUserCode = remember { preferences.setup()?.userCode.orEmpty() }
    val initialCachedPolicy = remember(initialUserCode) { serverAuthRepository.cachedPolicy(initialUserCode) }
    var authenticated by remember { mutableStateOf(initialCachedPolicy != null && preferences.isUnlockSessionValid(settings.autoLockMinutes)) }
    var authScreen by remember { mutableStateOf(AppScreen.SPLASH) }
    var currentRoot by rememberSaveable(stateSaver = RootTabSaver) { mutableStateOf(RootTab.HOME) }
    val homeStack = rememberSaveable(saver = screenStackSaver(AppScreen.HOME)) { mutableStateListOf(AppScreen.HOME) }
    val notificationsStack = rememberSaveable(saver = screenStackSaver(AppScreen.NOTIFICATIONS)) { mutableStateListOf(AppScreen.NOTIFICATIONS) }
    val syncStack = rememberSaveable(saver = screenStackSaver(AppScreen.SYNC_CENTER)) { mutableStateListOf(AppScreen.SYNC_CENTER) }
    val settingsStack = rememberSaveable(saver = screenStackSaver(AppScreen.SETTINGS)) { mutableStateListOf(AppScreen.SETTINGS) }
    var lastPersistedInteraction by remember { mutableLongStateOf(0L) }
    var unreadNotifications by remember { mutableStateOf(notificationInboxRepository.unreadCount()) }
    val notificationRoute by NotificationRouteState.route
    val serverPolicyEvent by ServerPolicyEvents.revision.collectAsState()
    val syncRuntime by SyncStatusEvents.state.collectAsState()
    val firestoreSyncListener = remember { FirestoreSyncListener(preferences.appContext) }
    val lifecycleOwner = LocalLifecycleOwner.current
    var accessPolicy by remember { mutableStateOf(initialCachedPolicy ?: UserAccessPolicy.locked(initialUserCode)) }
    // When a user opens an object from the in-app notification inbox, Back should return
    // to that inbox after the natural module parent instead of walking through an artificial Home chain.
    var deepLinkReturnRoot by remember { mutableStateOf<RootTab?>(null) }
    val navigationBlockers by NavigationGuardState.blockers
    var pendingRootSwitch by remember { mutableStateOf<RootTab?>(null) }

    fun stackFor(root: RootTab = currentRoot) = when (root) {
        RootTab.HOME -> homeStack
        RootTab.NOTIFICATIONS -> notificationsStack
        RootTab.SYNC -> syncStack
        RootTab.SETTINGS -> settingsStack
    }

    fun switchRoot(root: RootTab) {
        currentRoot = root
        if (root == RootTab.NOTIFICATIONS) unreadNotifications = notificationInboxRepository.unreadCount()
    }

    fun rootScreen(root: RootTab): AppScreen = when (root) {
        RootTab.HOME -> AppScreen.HOME
        RootTab.NOTIFICATIONS -> AppScreen.NOTIFICATIONS
        RootTab.SYNC -> AppScreen.SYNC_CENTER
        RootTab.SETTINGS -> AppScreen.SETTINGS
    }

    fun activateRoot(root: RootTab) {
        // Bottom navigation is authoritative: one tap always lands on the selected root screen.
        val targetStack = stackFor(root)
        targetStack.clear()
        targetStack.add(rootScreen(root))
        switchRoot(root)
    }

    fun requestRootSwitch(root: RootTab) {
        val targetStack = stackFor(root)
        val alreadyAtRoot = root == currentRoot && targetStack.size == 1 && targetStack.lastOrNull() == rootScreen(root)
        if (alreadyAtRoot) {
            if (root == RootTab.HOME) AppNavigationEvents.requestHomeTop()
            return
        }
        if (navigationBlockers.isNotEmpty()) pendingRootSwitch = root else activateRoot(root)
    }

    fun push(screen: AppScreen) {
        if (!accessPolicy.canReadScreen(screen)) return
        when (screen) {
            AppScreen.HOME -> switchRoot(RootTab.HOME)
            AppScreen.NOTIFICATIONS -> switchRoot(RootTab.NOTIFICATIONS)
            AppScreen.SYNC_CENTER -> switchRoot(RootTab.SYNC)
            AppScreen.SETTINGS -> switchRoot(RootTab.SETTINGS)
            else -> {
                val stack = stackFor()
                if (stack.lastOrNull() != screen) stack.add(screen)
            }
        }
    }

    fun pop() {
        val stack = stackFor()
        if (stack.size > 1) {
            stack.removeAt(stack.lastIndex)
            if (currentRoot == RootTab.HOME && stack.size == 1 && stack.lastOrNull() == AppScreen.HOME) {
                deepLinkReturnRoot?.let { target ->
                    deepLinkReturnRoot = null
                    switchRoot(target)
                }
            }
        } else if (currentRoot != RootTab.HOME) {
            switchRoot(RootTab.HOME)
        }
    }

    fun resetHome(vararg screens: AppScreen) {
        homeStack.clear()
        homeStack.add(AppScreen.HOME)
        screens.filter { accessPolicy.canReadScreen(it) }.forEach { homeStack.add(it) }
        switchRoot(RootTab.HOME)
    }

    fun finishAuthentication(policy: UserAccessPolicy, resetNavigation: Boolean) {
        accessPolicy = policy
        authenticated = true
        val now = System.currentTimeMillis()
        lastPersistedInteraction = now
        preferences.markSessionUnlocked(now)
        if (resetNavigation) {
            homeStack.clear(); homeStack.add(AppScreen.HOME)
            notificationsStack.clear(); notificationsStack.add(AppScreen.NOTIFICATIONS)
            syncStack.clear(); syncStack.add(AppScreen.SYNC_CENTER)
            settingsStack.clear(); settingsStack.add(AppScreen.SETTINGS)
            deepLinkReturnRoot = null
            switchRoot(RootTab.HOME)
        } else {
            // Restored root stacks survive Activity/process recreation after the same user's daily unlock.
            val stack = stackFor()
            while (stack.size > 1 && !policy.canReadScreen(stack.last())) stack.removeAt(stack.lastIndex)
            if (stack.isEmpty()) { homeStack.clear(); homeStack.add(AppScreen.HOME); switchRoot(RootTab.HOME) }
        }
        FirebaseSyncScheduler.ensurePeriodic(preferences.appContext)
        FirebaseSyncScheduler.enqueue(preferences.appContext)
    }

    fun lock() {
        NavigationGuardState.clear()
        pendingRootSwitch = null
        authenticated = false
        preferences.clearUnlockSession()
        authScreen = if (preferences.hasSetup()) AppScreen.LOGIN else AppScreen.SETUP
    }

    fun openNotificationRoute(route: String, returnRoot: RootTab? = null) {
        val parts = route.split('|')
        val base = parts.firstOrNull().orEmpty()
        val params = parts.drop(1).mapNotNull { token ->
            val i = token.indexOf('='); if (i <= 0) null else token.substring(0, i) to token.substring(i + 1)
        }.toMap()
        TpNavigationTargetState.set(orderId = params["order"], jobId = params["job"], issueId = params["issue"])
        var handled = false
        fun openIfAllowed(screen: AppScreen, vararg hierarchy: AppScreen) {
            if (accessPolicy.canReadScreen(screen)) {
                resetHome(*hierarchy)
                handled = true
            }
        }
        when (base) {
            "TP_PLAN" -> openIfAllowed(AppScreen.TP_PLAN, AppScreen.TP_MAIN, AppScreen.TP_PLAN)
            "TP_SERYO" -> openIfAllowed(AppScreen.TP_SERYO, AppScreen.TP_SERYO)
            "TP_MACHINE" -> openIfAllowed(AppScreen.TP_SHIFT, AppScreen.TP_MAIN, AppScreen.TP_SHIFT)
            "TP_RECEIVING" -> openIfAllowed(AppScreen.TP_RECEIVING, AppScreen.TP_MAIN, AppScreen.TP_RECEIVING)
            "TP_QUALITY" -> openIfAllowed(AppScreen.TP_QUALITY, AppScreen.TP_MAIN, AppScreen.TP_QUALITY)
            "TP_MONITORING" -> openIfAllowed(AppScreen.TP_MONITORING, AppScreen.TP_MAIN, AppScreen.TP_MONITORING)
            "BRIGADIR" -> openIfAllowed(AppScreen.BRIGADIR, AppScreen.ASSEMBLY_ENTRY, AppScreen.ASSEMBLY, AppScreen.BRIGADIR)
            "QUALITY" -> openIfAllowed(AppScreen.QUALITY, AppScreen.ASSEMBLY_ENTRY, AppScreen.ASSEMBLY, AppScreen.QUALITY)
            "MONITORING" -> openIfAllowed(AppScreen.MONITORING, AppScreen.ASSEMBLY_ENTRY, AppScreen.ASSEMBLY, AppScreen.MONITORING)
            "DAILY_ISSUE" -> openIfAllowed(AppScreen.DAILY_ISSUE, AppScreen.ASSEMBLY_ENTRY, AppScreen.ASSEMBLY, AppScreen.DAILY_ISSUE)
        }
        deepLinkReturnRoot = if (handled) returnRoot else null
        unreadNotifications = notificationInboxRepository.unreadCount()
    }

    DisposableEffect(lifecycleOwner, authenticated, settings.autoLockMinutes) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> if (authenticated) {
                    preferences.markSessionBackgrounded()
                    if (settings.autoLockMinutes == 0) lock()
                }
                Lifecycle.Event.ON_START -> if (authenticated && !preferences.isUnlockSessionValid(settings.autoLockMinutes)) {
                    lock()
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(authenticated) {
        if (authenticated) {
            serverAuthRepository.refreshPolicy()
                .onSuccess { refreshed -> accessPolicy = refreshed }
                .onFailure { error ->
                    val message = error.message.orEmpty()
                    if (message.contains("o‘chirilgan", ignoreCase = true) || message.contains("disabled", ignoreCase = true)) lock()
                }
        }
    }

    LaunchedEffect(notificationRoute, authenticated) {
        if (authenticated && notificationRoute != null) {
            openNotificationRoute(notificationRoute.orEmpty())
            NotificationRouteState.clear()
        }
    }

    LaunchedEffect(authenticated) {
        if (authenticated) AppNavigationEvents.openSyncCenter.collect { requestRootSwitch(RootTab.SYNC) }
    }

    DisposableEffect(authenticated, accessPolicy.uid) {
        if (authenticated) firestoreSyncListener.start(accessPolicy.uid) else firestoreSyncListener.stop()
        onDispose { firestoreSyncListener.stop() }
    }

    // Event-driven foreground sync only. The former unconditional 30-second polling loop is intentionally removed.
    LaunchedEffect(authenticated, lifecycleOwner) {
        if (authenticated) lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            FirebaseSyncScheduler.foregroundRequests.collect {
                delay(350)
                withContext(Dispatchers.IO) { FirebaseSyncCoordinator(preferences.appContext).syncNow() }
            }
        }
    }

    LaunchedEffect(serverPolicyEvent, authenticated) {
        if (authenticated && serverPolicyEvent > 0L) {
            serverAuthRepository.refreshPolicy()
                .onSuccess { refreshed ->
                    accessPolicy = refreshed
                    val stack = stackFor()
                    val currentScreen = stack.lastOrNull()
                    if (currentScreen != null && !refreshed.canReadScreen(currentScreen)) {
                        homeStack.clear(); homeStack.add(AppScreen.HOME); switchRoot(RootTab.HOME)
                    }
                }
                .onFailure { error ->
                    val message = error.message.orEmpty()
                    if (message.contains("o‘chirilgan", ignoreCase = true) || message.contains("disabled", ignoreCase = true)) lock()
                }
        }
    }

    ToyBolaTheme(settings) {
        val strings = AppStrings(settings.language)
        val current = if (authenticated) stackFor().lastOrNull() ?: AppScreen.HOME else authScreen
        // Global fallback: child screens with their own BackHandler get first chance; otherwise
        // Android Back always pops exactly one app-navigation level. Only Home root falls through
        // to the normal Android background/exit behaviour.
        BackHandler(enabled = authenticated && (stackFor().size > 1 || currentRoot != RootTab.HOME)) { pop() }

        Surface(
            color = MaterialTheme.colorScheme.background,
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
                .pointerInput(authenticated) {
                    if (authenticated) {
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            val now = System.currentTimeMillis()
        lastPersistedInteraction = now
        preferences.markSessionUnlocked(now)
                        }
                    }
                }
        ) {
            val showBottomBar = authenticated
            Scaffold(
                containerColor = androidx.compose.ui.graphics.Color.Transparent,
                bottomBar = {
                    if (showBottomBar) {
                        GlobalBottomBar(
                            strings = strings,
                            current = when (currentRoot) {
                                RootTab.HOME -> AppScreen.HOME
                                RootTab.NOTIFICATIONS -> AppScreen.NOTIFICATIONS
                                RootTab.SYNC -> AppScreen.SYNC_CENTER
                                RootTab.SETTINGS -> AppScreen.SETTINGS
                            },
                            unreadNotifications = unreadNotifications,
                            syncing = syncRuntime.syncing,
                            onHome = { deepLinkReturnRoot = null; requestRootSwitch(RootTab.HOME) },
                            onNotifications = { deepLinkReturnRoot = null; requestRootSwitch(RootTab.NOTIFICATIONS) },
                            onSync = { deepLinkReturnRoot = null; requestRootSwitch(RootTab.SYNC) },
                            onSettings = { deepLinkReturnRoot = null; requestRootSwitch(RootTab.SETTINGS) }
                        )
                    }
                }
            ) { innerPadding ->
                Box(Modifier.fillMaxSize().padding(if (showBottomBar) innerPadding else PaddingValues(0.dp))) {
                    when (current) {
                        AppScreen.SPLASH -> SplashScreen {
                            val code = preferences.setup()?.userCode.orEmpty()
                            authScreen = if (preferences.hasSetup() && serverAuthRepository.cachedPolicy(code) != null) AppScreen.LOGIN else AppScreen.SETUP
                        }
                        AppScreen.SETUP -> SetupScreen(
                            strings = strings,
                            onServerLogin = serverAuthRepository::signInWithCodes,
                            onAuthenticated = { deviceCode, userCode, policy ->
                                preferences.saveSetup(deviceCode, userCode)
                                finishAuthentication(policy, resetNavigation = true)
                            }
                        )
                        AppScreen.LOGIN -> LoginScreen(
                            strings = strings,
                            savedSetup = preferences.setup(),
                            profileLabel = listOf(accessPolicy.displayName, accessPolicy.role).filter { it.isNotBlank() }.joinToString(" • "),
                            cachedPolicy = serverAuthRepository.cachedPolicy(preferences.setup()?.userCode.orEmpty()),
                            onAuthenticated = { policy -> finishAuthentication(policy, resetNavigation = false) },
                            onChangeSetup = { preferences.clearUnlockSession(); authScreen = AppScreen.SETUP }
                        )
                        AppScreen.HOME -> HomeScreen(
                            strings = strings,
                            accessPolicy = accessPolicy,
                            unreadNotifications = unreadNotifications,
                            onOpen = { screen ->
                                if (screen == AppScreen.TP_MAIN) push(preferredTpEntry(accessPolicy)) else push(screen)
                            }
                        )
                        AppScreen.SETTINGS -> SettingsScreen(
                            strings = strings,
                            settings = settings,
                            onSettingsChange = {
                                settings = it
                                preferences.saveSettings(it)
                            },
                            showUserManagement = accessPolicy.isAdmin(),
                            onUserManagement = { push(AppScreen.USER_ADMIN) },
                            onBackupRestore = { push(AppScreen.BACKUP_RESTORE) },
                            onLock = ::lock,
                            onBack = ::pop
                        )
                        AppScreen.SYNC_CENTER -> SyncCenterScreen(strings, ::pop)
                        AppScreen.MANAGEMENT -> ManagementMonitoringScreen(strings, ::pop, { accessPolicy.canReadScreen(it) }, ::push)
                        AppScreen.NOTIFICATIONS -> NotificationsScreen(
                            strings = strings,
                            repository = notificationInboxRepository,
                            onBack = {
                                unreadNotifications = notificationInboxRepository.unreadCount()
                                pop()
                            },
                            onOpenRoute = { route -> openNotificationRoute(route, RootTab.NOTIFICATIONS) }
                        )
                        AppScreen.TP_MAIN -> TpMainScreen(strings, ::pop, { accessPolicy.canReadScreen(it) }, ::push)
                        AppScreen.TP_PLAN -> TpPlanScreen(strings, tpDataRepository, ::pop)
                        AppScreen.TP_SHIFT -> TpShiftScreen(strings, tpDataRepository, ::pop)
                        AppScreen.TP_ATTENDANCE -> TpAttendanceScreen(strings, tpDataRepository, ::pop)
                        AppScreen.TP_SERYO -> TpSeryoScreen(strings, tpDataRepository, ::pop)
                        AppScreen.TP_RECEIVING -> TpReceivingScreen(strings, tpDataRepository, ::pop)
                        AppScreen.TP_QUALITY -> TpQualityScreen(strings, tpDataRepository, ::pop)
                        AppScreen.TP_MONITORING -> TpMonitoringScreen(strings, tpDataRepository, ::pop)
                        AppScreen.TP_MASTER_DATA -> TpMasterDataScreen(strings, tpDataRepository, ::pop)
                        AppScreen.ASSEMBLY_ENTRY -> AssemblyEntryScreen(strings, onBack = ::pop) { push(AppScreen.ASSEMBLY) }
                        AppScreen.ASSEMBLY -> AssemblyMainScreen(strings = strings, onBack = ::pop, canOpen = { screen -> accessPolicy.canReadScreen(screen) }, onOpen = ::push)
                        AppScreen.BRIGADIR -> BrigadirScreen(strings, assemblyDataRepository, ::pop)
                        AppScreen.QUALITY -> QualityScreen(strings, assemblyDataRepository, ::pop)
                        AppScreen.DAILY_ISSUE -> DailyIssueScreen(strings, assemblyDataRepository, ::pop)
                        AppScreen.MONITORING -> MonitoringScreen(strings, assemblyDataRepository, ::pop, isAdmin = accessPolicy.isAdmin())
                        AppScreen.MASTER_DATA -> MasterDataScreen(strings, assemblyDataRepository, ::pop)
                        AppScreen.USER_ADMIN -> UserManagementScreen(
                            strings = strings,
                            assemblyRepository = assemblyDataRepository,
                            tpRepository = tpDataRepository,
                            onBack = ::pop,
                            currentUid = accessPolicy.uid,
                            onSelfDeviceCodeReset = { userCode, deviceCode -> preferences.saveSetup(deviceCode, userCode) }
                        )
                        AppScreen.BACKUP_RESTORE -> BackupRestoreScreen(
                            strings = strings,
                            repository = assemblyDataRepository,
                            isAdmin = accessPolicy.isAdmin(),
                            allowedBrigadeIds = accessPolicy.allowedBrigadeIds,
                            onBack = ::pop
                        )
                    }
                }
            }

            val requestedRoot = pendingRootSwitch
            if (requestedRoot != null) {
                AlertDialog(
                    onDismissRequest = { pendingRootSwitch = null },
                    title = { Text("Saqlanmagan ma’lumot") },
                    text = { Text("Joriy formadagi saqlanmagan ma’lumotlar yo‘qoladi. Bo‘limni almashtirasizmi?") },
                    confirmButton = {
                        TextButton(onClick = {
                            pendingRootSwitch = null
                            NavigationGuardState.clear()
                            activateRoot(requestedRoot)
                        }) { Text("Chiqish") }
                    },
                    dismissButton = { TextButton(onClick = { pendingRootSwitch = null }) { Text("Qolish") } }
                )
            }
        }
    }
}

private fun preferredTpEntry(policy: UserAccessPolicy): AppScreen {
    if (policy.isAdmin()) return AppScreen.TP_MAIN
    val candidates = buildList {
        if (policy.canRead(AssemblySection.TP_ORDER) || policy.canRead(AssemblySection.TP_PLANNING)) add(AppScreen.TP_PLAN)
        if (policy.canRead(AssemblySection.TP_MACHINE)) add(AppScreen.TP_SHIFT)
        if (policy.canRead(AssemblySection.TP_ATTENDANCE)) add(AppScreen.TP_ATTENDANCE)
        if (policy.canRead(AssemblySection.TP_RECEIVING)) add(AppScreen.TP_RECEIVING)
        if (policy.canRead(AssemblySection.TP_QUALITY) || policy.canRead(AssemblySection.TP_DAILY_ISSUE)) add(AppScreen.TP_QUALITY)
        if (policy.canRead(AssemblySection.TP_MONITORING)) add(AppScreen.TP_MONITORING)
        if (policy.canRead(AssemblySection.TP_MASTER_DATA)) add(AppScreen.TP_MASTER_DATA)
    }.distinct()
    return candidates.singleOrNull() ?: AppScreen.TP_MAIN
}
