package uz.toybola.factory.core.firebase

import android.content.Context
import com.google.firebase.functions.FirebaseFunctions
import uz.toybola.factory.core.data.AssemblyData
import uz.toybola.factory.core.data.AssemblyDataRepository

data class ServerSnapshotResult(
    val data: AssemblyData,
    val hasSettings: Boolean,
    val counts: Map<String, Int>,
    val tombstones: Set<String>
)

/**
 * Authoritative server -> client bootstrap/sync bridge.
 *
 * Reads are performed by a callable Cloud Function after it validates the signed-in user's
 * server-side role, permissions and brigade scope. This avoids a legacy Firestore document
 * blocking a fresh-install bootstrap with PERMISSION_DENIED while preserving scope checks on
 * the trusted server.
 */
class ServerSnapshotRepository(context: Context) {
    private val repository = AssemblyDataRepository(context.applicationContext)
    private val functions = FirebaseFunctions.getInstance("europe-west1")

    suspend fun download(): Result<ServerSnapshotResult> = runCatching {
        val response = functions.getHttpsCallable("getAssemblySnapshot")
            .call(mapOf("clientVersion" to "0.15.0"))
            .awaitResult()
        val root = response.data as? Map<*, *> ?: error("Server snapshot javobi noto‘g‘ri")
        val payload = root["payload"]?.toString().orEmpty()
        require(payload.isNotBlank()) { "Server snapshot bo‘sh" }
        val bytes = payload.toByteArray(Charsets.UTF_8)
        require(bytes.size <= MAX_PAYLOAD_BYTES) {
            "Server snapshot juda katta (${bytes.size / 1024} KB). Server ma’lumotini bo‘lib yuklash kerak."
        }
        val counts = (root["counts"] as? Map<*, *>).orEmpty().mapNotNull { (k, v) ->
            val key = k?.toString() ?: return@mapNotNull null
            key to ((v as? Number)?.toInt() ?: 0)
        }.toMap()
        ServerSnapshotResult(
            data = repository.decodeForSync(payload),
            hasSettings = root["hasSettings"] == true,
            counts = counts,
            tombstones = (root["tombstones"] as? List<*>)
                .orEmpty().mapNotNull { it?.toString() }.filter { it.contains(':') }.toSet()
        )
    }

    companion object {
        private const val MAX_PAYLOAD_BYTES = 8 * 1024 * 1024
    }
}
