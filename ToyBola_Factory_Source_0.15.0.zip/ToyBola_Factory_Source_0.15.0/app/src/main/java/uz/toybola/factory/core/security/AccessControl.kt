package uz.toybola.factory.core.security

import uz.toybola.factory.ui.model.AppScreen
import uz.toybola.factory.core.data.AssemblyData
import uz.toybola.factory.core.data.TpData

enum class AssemblySection {
    BRIGADIR,
    QUALITY,
    DAILY_ISSUE,
    MONITORING,
    MASTER_DATA,
    TP_ORDER,
    TP_PLANNING,
    TP_MACHINE,
    TP_ATTENDANCE,
    TP_EXTRA_HOURS,
    TP_SERYO,
    TP_SERYO_APPROVAL,
    TP_SERYO_DELIVERY,
    TP_SERYO_RECEIPT,
    TP_SERYO_STOCK,
    TP_SERYO_IMPORT,
    TP_RECEIVING,
    TP_QUALITY,
    TP_DAILY_ISSUE,
    TP_MONITORING,
    TP_EXPORT,
    TP_MASTER_DATA
}

data class SectionAccess(
    val canRead: Boolean = false,
    val canWrite: Boolean = false
)

data class UserAccessPolicy(
    val uid: String = "",
    val userCode: String,
    val displayName: String = "",
    val role: String = "",
    /** null = all brigades; otherwise only listed brigade IDs are in scope. */
    val allowedBrigadeIds: Set<String>? = emptySet(),
    val sections: Map<AssemblySection, SectionAccess> = emptyMap(),
    val notificationKeys: Set<String> = emptySet(),
    val revision: Long = 0L,
    val source: String = "server"
) {
    fun canRead(section: AssemblySection): Boolean = sections[section]?.canRead == true
    fun canWrite(section: AssemblySection): Boolean = sections[section]?.canWrite == true
    fun canAccessBrigade(brigadeId: String): Boolean = allowedBrigadeIds?.contains(brigadeId) ?: true
    fun isAdmin(): Boolean = role.equals("ADMIN", true)
    fun canWriteDailyIssue(): Boolean = isAdmin() || canWrite(AssemblySection.DAILY_ISSUE)

    companion object {
        fun locked(userCode: String = ""): UserAccessPolicy = UserAccessPolicy(
            userCode = userCode,
            allowedBrigadeIds = emptySet(),
            sections = AssemblySection.entries.associateWith { SectionAccess(false, false) },
            source = "locked"
        )
    }
}

fun AppScreen.toAssemblySectionOrNull(): AssemblySection? = when (this) {
    AppScreen.BRIGADIR -> AssemblySection.BRIGADIR
    AppScreen.QUALITY -> AssemblySection.QUALITY
    AppScreen.DAILY_ISSUE -> AssemblySection.DAILY_ISSUE
    AppScreen.MONITORING -> AssemblySection.MONITORING
    AppScreen.MASTER_DATA -> AssemblySection.MASTER_DATA
    else -> null
}

fun UserAccessPolicy.canReadScreen(screen: AppScreen): Boolean = when (screen) {
    AppScreen.USER_ADMIN -> isAdmin()
    AppScreen.ASSEMBLY_ENTRY, AppScreen.ASSEMBLY -> isAdmin() || listOf(
        AssemblySection.BRIGADIR, AssemblySection.QUALITY, AssemblySection.DAILY_ISSUE, AssemblySection.MONITORING, AssemblySection.MASTER_DATA
    ).any(::canRead)
    AppScreen.MANAGEMENT -> isAdmin() || canRead(AssemblySection.MONITORING) || canRead(AssemblySection.TP_MONITORING)
    AppScreen.TP_MAIN -> isAdmin() || AssemblySection.entries.any {
        it.name.startsWith("TP_") && it != AssemblySection.TP_SERYO && canRead(it)
    }
    AppScreen.TP_PLAN -> isAdmin() || listOf(
        AssemblySection.TP_ORDER, AssemblySection.TP_PLANNING
    ).any(::canRead)
    AppScreen.TP_SHIFT -> isAdmin() || canRead(AssemblySection.TP_MACHINE)
    AppScreen.TP_ATTENDANCE -> isAdmin() || canRead(AssemblySection.TP_ATTENDANCE)
    AppScreen.TP_SERYO -> isAdmin() || canRead(AssemblySection.TP_SERYO) || listOf(
        AssemblySection.TP_SERYO_APPROVAL, AssemblySection.TP_SERYO_DELIVERY, AssemblySection.TP_SERYO_RECEIPT,
        AssemblySection.TP_SERYO_STOCK, AssemblySection.TP_SERYO_IMPORT
    ).any { canRead(it) || canWrite(it) }
    AppScreen.TP_RECEIVING -> isAdmin() || canRead(AssemblySection.TP_RECEIVING)
    AppScreen.TP_QUALITY -> isAdmin() || canRead(AssemblySection.TP_QUALITY) || canRead(AssemblySection.TP_DAILY_ISSUE)
    AppScreen.TP_MONITORING -> isAdmin() || canRead(AssemblySection.TP_MONITORING)
    AppScreen.TP_MASTER_DATA -> isAdmin() || canRead(AssemblySection.TP_MASTER_DATA)
    else -> screen.toAssemblySectionOrNull()?.let(::canRead) ?: true
}

fun UserAccessPolicy.canReadAnyTp(): Boolean = isAdmin() || AssemblySection.entries.any {
    it.name.startsWith("TP_") && (canRead(it) || canWrite(it))
}

fun UserAccessPolicy.canSeryoApproval(): Boolean = isAdmin() || canWrite(AssemblySection.TP_SERYO_APPROVAL) || canWrite(AssemblySection.TP_SERYO)
fun UserAccessPolicy.canSeryoDelivery(): Boolean = isAdmin() || canWrite(AssemblySection.TP_SERYO_DELIVERY) || canWrite(AssemblySection.TP_SERYO)
fun UserAccessPolicy.canSeryoReceipt(): Boolean = isAdmin() || canWrite(AssemblySection.TP_SERYO_RECEIPT) || canWrite(AssemblySection.TP_SERYO)
fun UserAccessPolicy.canSeryoStock(): Boolean = isAdmin() || canWrite(AssemblySection.TP_SERYO_STOCK) || canWrite(AssemblySection.TP_SERYO)
fun UserAccessPolicy.canSeryoImport(): Boolean = isAdmin() || canWrite(AssemblySection.TP_SERYO_IMPORT) || canWrite(AssemblySection.TP_SERYO) || canWrite(AssemblySection.TP_MASTER_DATA)

/** Channels are independent: a TP-only account must never request the Sborka endpoint. */
fun UserAccessPolicy.canReadAnyAssembly(): Boolean = isAdmin() || AssemblySection.entries.any {
    !it.name.startsWith("TP_") && canRead(it)
}

/**
 * Hides cached records outside the current server policy before UI rendering.
 * This prevents stale data from a previous broader login from briefly appearing
 * while the current account is waiting for its first server refresh.
 */
fun AssemblyData.scopedFor(policy: UserAccessPolicy): AssemblyData {
    val allowed = policy.allowedBrigadeIds ?: return this
    return copy(
        brigades = brigades.filter { it.id in allowed },
        machines = machines.filter { it.shopId in allowedShopIds },
        workers = workers.filter { it.brigadeId in allowed },
        products = products.filter { it.brigadeId in allowed },
        brigadeFk = brigadeFk.filter { it.brigadeId in allowed },
        workerDays = workerDays.filter { it.brigadeId in allowed },
        brigadeDays = brigadeDays.filter { it.brigadeId in allowed },
        qualityRounds = qualityRounds.filter { it.brigadeId in allowed },
        dailyIssues = dailyIssues.filter { it.brigadeId in allowed },
        auditLog = auditLog.filter { it.brigadeId != null && it.brigadeId in allowed }
    )
}

fun TpData.scopedFor(policy: UserAccessPolicy): TpData {
    val allowed = policy.allowedBrigadeIds ?: return this
    val allowedShopIds = brigades.filter { it.id in allowed }.map { it.shopId }.toSet()
    val canSeeUnassigned = policy.canRead(AssemblySection.TP_ORDER) || policy.canRead(AssemblySection.TP_PLANNING)
    val scopedJobs = jobs.filter { job ->
        job.brigadeId?.let { it in allowed } == true || (job.brigadeId == null && canSeeUnassigned)
    }
    val visibleOrderIds = scopedJobs.map { it.orderId }.toSet()
    val canSeeAllOrders = policy.isAdmin() || policy.canRead(AssemblySection.TP_ORDER) ||
        policy.canRead(AssemblySection.TP_PLANNING) || policy.canRead(AssemblySection.TP_MONITORING)
    return copy(
        brigades = brigades.filter { it.id in allowed },
        machines = machines.filter { it.shopId in allowedShopIds },
        workers = workers.filter { it.brigadeId in allowed },
        orders = if (canSeeAllOrders) orders else orders.filter { it.id in visibleOrderIds },
        jobs = scopedJobs,
        attendance = attendance.filter { it.brigadeId in allowed },
        receipts = receipts.filter { it.brigadeId in allowed },
        qualityRounds = qualityRounds.filter { it.brigadeId in allowed },
        dailyIssues = dailyIssues.filter { it.brigadeId in allowed },
        extraHours = extraHours.filter { it.brigadeId in allowed },
        brigadeShiftSelections = brigadeShiftSelections.filter { it.brigadeId in allowed },
        machineWorkerAssignments = machineWorkerAssignments.filter { it.brigadeId in allowed },
        machineDowntimes = machineDowntimes.filter { it.brigadeId in allowed },
        auditLog = auditLog.filter { it.brigadeId == null || it.brigadeId in allowed }
    )
}
