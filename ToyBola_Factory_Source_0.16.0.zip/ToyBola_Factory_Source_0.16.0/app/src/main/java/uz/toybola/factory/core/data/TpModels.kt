package uz.toybola.factory.core.data

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.roundToLong
import kotlin.math.roundToInt

enum class TpMaterialType { RESIN, COLOR, RECYCLED }
enum class TpMaterialMovementKind { IN, OUT }
enum class TpOrderStatus { NEW, PLANNING, READY, APPROVED, IN_PROGRESS, COMPLETE, CANCELLED }
enum class TpJobStatus { UNASSIGNED, QUEUED, IN_PROGRESS, COMPLETE, HOLD }
enum class TpDailyIssueStatus { NEW, IN_PROGRESS, RESOLVED, CANCELLED }
enum class TpMaterialStatus { PLANNED, CONFIRMED, DELIVERED }

data class TpShop(
    val id: String,
    val name: String,
    val archived: Boolean = false
)

data class TpShift(
    val id: String,
    val name: String,
    val startTime: String,
    val endTime: String,
    val roundTimes: List<String>,
    val archived: Boolean = false
) {
    fun durationMinutes(): Int {
        val start = LocalTime.parse(startTime)
        val end = LocalTime.parse(endTime)
        val raw = Duration.between(start, end).toMinutes()
        return (if (raw <= 0) raw + 24 * 60 else raw).toInt()
    }
}

internal fun resolveTpAssignmentDateTime(recordDate: LocalDate, shift: TpShift, time: LocalTime): LocalDateTime {
    val shiftStart = LocalTime.parse(shift.startTime)
    val shiftEnd = LocalTime.parse(shift.endTime)
    val overnight = !shiftEnd.isAfter(shiftStart)
    val actualDate = if (overnight && !time.isAfter(shiftEnd)) recordDate.plusDays(1) else recordDate
    return actualDate.atTime(time)
}

internal fun parseTpAssignmentDateTime(recordDate: String, value: String): LocalDateTime =
    runCatching { LocalDateTime.parse(value) }.getOrElse { LocalDate.parse(recordDate).atTime(LocalTime.parse(value)) }

data class TpBrigade(
    val id: String,
    val shopId: String,
    val shiftId: String,
    val name: String,
    val archived: Boolean = false
)

data class TpMachine(
    val id: String,
    val shopId: String,
    val number: Int,
    val name: String = "",
    val archived: Boolean = false,
    /** Injection/moulding machine clamp/capacity class. 0 keeps legacy data unrestricted until configured. */
    val capacity: Int = 0
)

data class TpWorker(
    val id: String,
    val brigadeId: String,
    val name: String,
    /** Legacy per-worker value kept only for backward JSON compatibility. Calculations use TpSettings.dailyTargetAmount. */
    val dailyTargetAmount: Long = 0L,
    /** Legacy field kept only for backward JSON compatibility; calculations use the brigade shift duration. */
    val defaultWorkMinutes: Int = 0,
    val archived: Boolean = false
)

data class TpColorRule(
    val colorCode: String,
    val share: Double,
    val gramsPer25Kg: Double
)

/**
 * A detail is one required component of a finished toy. Details that come from the same mould
 * share [moldCode]. Each detail still keeps its own output-per-shot and product requirement.
 */
data class TpDetail(
    val id: String,
    val name: String,
    val moldCode: String,
    val requiredPerProduct: Int,
    val piecesPerShot: Int,
    val bagCapacity: Int,
    val cycleSeconds: Int,
    val grossShotWeightGrams: Double,
    val unusableShotWeightGrams: Double,
    val resinCode: String,
    val unitPrice: Double,
    val compatibleMachineIds: Set<String>,
    /** Allowed machine capacity classes such as 60/90/120. Empty is tolerated only for legacy records until configured. */
    val compatibleCapacities: Set<Int> = emptySet(),
    val colors: List<TpColorRule>,
    val archived: Boolean = false,
    /** Allowed resin/raw-material codes for this detail. [resinCode] is kept as the legacy/default code. */
    val resinCodes: List<String> = emptyList(),
    /** Recycled/secondary feedstock types allowed for this detail. Empty means ftarichka is not allowed. */
    val recycledCodes: List<String> = emptyList()
) {
    fun estimatedPiecesIn12Hours(): Int = if (cycleSeconds > 0) (12 * 60 * 60 / cycleSeconds) * piecesPerShot else 0
}

data class TpProduct(
    val id: String,
    val article: String,
    val name: String,
    val details: List<TpDetail> = emptyList(),
    val archived: Boolean = false
)

data class TpMaterialMovement(
    val id: String,
    val kind: TpMaterialMovementKind,
    val amount: Double,
    val createdAt: String,
    val note: String = "",
    val sourceJobId: String? = null,
    val sourceKind: TpMaterialSourceKind = TpMaterialSourceKind.MANUAL,
    val sourceMachineId: String? = null,
    val sourceShopId: String? = null,
    val sourceArea: String = "",
    val productId: String? = null,
    val detailId: String? = null,
    val articleSnapshot: String = "",
    val productNameSnapshot: String = "",
    val detailNameSnapshot: String = "",
    val createdBy: String = ""
)

data class TpMaterial(
    val id: String,
    val code: String,
    val name: String,
    val type: TpMaterialType,
    /** Legacy/opening balance. New stock changes are stored in [movements]. */
    val availableAmount: Double,
    val archived: Boolean = false,
    val movements: List<TpMaterialMovement> = emptyList()
)

data class TpOrder(
    val id: String,
    val batchNumber: String,
    val productId: String,
    val articleSnapshot: String,
    val productNameSnapshot: String,
    val quantity: Int,
    val priority: Int,
    val requestedDate: String,
    val note: String,
    val status: TpOrderStatus,
    val createdAt: String,
    val completedAt: String? = null,
    /** Set only when the planner presses “Jarayonni boshlash”. */
    val planApprovedAt: String? = null,
    val cancelledAt: String? = null,
    val cancelReason: String = "",
    val cancelledBy: String = ""
)

data class TpJobOutput(
    val detailId: String,
    val detailName: String,
    val requiredPieces: Int,
    val plannedPieces: Int,
    val piecesPerShot: Int,
    val bagCapacity: Int,
    val unitPrice: Double
) {
    val extraPieces: Int get() = (plannedPieces - requiredPieces).coerceAtLeast(0)
}

data class TpPlanJob(
    val id: String,
    val orderId: String,
    val moldCode: String,
    val colorCode: String,
    val outputs: List<TpJobOutput>,
    val requiredShots: Int,
    val cycleSeconds: Int,
    val estimatedMinutes: Int,
    val resinCode: String,
    val requiredResinKg: Double,
    val requiredColorGrams: Double,
    val compatibleMachineIds: Set<String>,
    val machineId: String? = null,
    val brigadeId: String? = null,
    val shiftId: String? = null,
    val priority: Int,
    val status: TpJobStatus = TpJobStatus.UNASSIGNED,
    val materialStatus: TpMaterialStatus = TpMaterialStatus.PLANNED,
    /** Plan beruvchi ushbu detal/qolipni alohida tasdiqlagan vaqt. */
    val planConfirmedAt: String? = null,
    /** Tasdiqlangan plan keyin tahrirlangan bo‘lsa auditga qulay vaqt va sabab. */
    val planEditedAt: String? = null,
    val planEditReason: String = "",
    /** Seryo brigadiri ushbu rang/detal uchun seryo turini ongli ravishda tanlagan vaqt. */
    val resinSelectedAt: String? = null,
    /** Seryo brigadiri barcha tanlovlarni tasdiqlab buyurtmani yordamchilarga topshirgan vaqt. */
    val resinConfirmedAt: String? = null,
    /** Qoldiq yetishmasa ham brigadir ogohlantirishni ko‘rib davom etishni tasdiqlagan. */
    val materialShortageOverride: Boolean = false,
    val materialConfirmedAt: String? = null,
    val materialDeliveredAt: String? = null,
    /** TP brigadir “Boshlash”ni bosgan vaqt; ishdagi vazifalarni tartiblash uchun. */
    val startedAt: String? = null,
    val alternativeResin: Boolean = false,
    val resinAdditions: List<TpResinAddition> = emptyList(),
    /** Primary material chosen by the Seryo brigadir. Legacy records default to ordinary resin. */
    val feedstockType: TpMaterialType = TpMaterialType.RESIN,
    /** Every partial physical delivery. The requested kg is reduced only by these batches. */
    val materialBatches: List<TpMaterialBatch> = emptyList(),
    /** Planner intentionally selected a normally incompatible machine via “Boshqa”. */
    val machineOverride: Boolean = false,
    val machineOverrideReason: String = "",
    val machineOverrideAt: String? = null
)

data class TpAttendance(
    val id: String,
    val workerId: String,
    val brigadeId: String,
    val shiftId: String,
    val date: String,
    val present: Boolean,
    /** Legacy/backward-compatible snapshot. New UI edits [minusHours] instead of minutes. */
    val workMinutes: Int,
    val updatedAt: String,
    /** Hours deducted from the brigade shift duration. 1.5 = 90 minutes. Negative means legacy record. */
    val minusHours: Double = -1.0
)

/**
 * Closing state for one attendance date + shift. The state is intentionally separate from worker rows:
 * a shift can be closed even when every worker used the default full-attendance value and therefore
 * no explicit [TpAttendance] row exists.
 */
data class TpAttendanceDayState(
    val id: String,
    val date: String,
    val shiftId: String,
    val closedAt: String? = null,
    val closedBy: String = "",
    val closeReason: String = "",
    val reopenedAt: String? = null,
    val reopenedBy: String = "",
    val reopenCount: Int = 0,
    val note: String = "",
    val updatedAt: String = ""
) {
    val isClosed: Boolean get() = !closedAt.isNullOrBlank()
    val isReopened: Boolean get() = !isClosed && reopenCount > 0
}

/**
 * [completedBags] is the number of physically closed bags. [creditedPieces] excludes the pieces
 * already credited to the previous shift's open bag, preventing a 30 + 70 bag becoming 30 + 100.
 */
data class TpReceipt(
    val id: String,
    val jobId: String,
    val orderId: String,
    val detailId: String,
    val detailNameSnapshot: String,
    val machineId: String,
    val workerId: String,
    val workerNameSnapshot: String,
    val brigadeId: String,
    val shiftId: String,
    val date: String,
    val colorCode: String,
    val completedBags: Int,
    val bagCapacity: Int,
    val carryInPieces: Int,
    val remainderAfter: Int,
    val creditedPieces: Int,
    val unitPriceSnapshot: Double,
    val receiverName: String,
    val createdAt: String,
    /** Price is per mould shot (jim), so receipt pieces must be converted back to shot-equivalent. */
    val piecesPerShotSnapshot: Int = 1,
    val updatedAt: String? = null,
    val updatedBy: String = "",
    val editReason: String = "",
    val cancelledAt: String? = null,
    val cancelledBy: String = "",
    val cancelReason: String = ""
) {
    val isCancelled: Boolean get() = cancelledAt != null
    val earnedAmount: Long get() = calculatePieceWorkAmount(creditedPieces, piecesPerShotSnapshot, unitPriceSnapshot)
}

data class TpQualityRound(
    val id: String,
    val brigadeId: String,
    val shiftId: String,
    val machineId: String,
    val workerId: String,
    val jobId: String,
    val date: String,
    val round: Int,
    val scheduledTime: String,
    val score: Int,
    val issue: String,
    val checkedBy: String,
    val checkedAt: String,
    /** "", EXCUSED or UNEXCUSED. Excused rounds are excluded from the worker average. */
    val absenceType: String = "",
    val excludedFromAverage: Boolean = false
)

data class TpDailyIssue(
    val id: String,
    val brigadeId: String,
    val date: String,
    val machineId: String?,
    val orderId: String?,
    val title: String,
    val note: String,
    val createdAt: String,
    val imageUrl: String = "",
    val imagePath: String = "",
    val imageUrls: List<String> = emptyList(),
    val imagePaths: List<String> = emptyList(),
    val status: TpDailyIssueStatus = TpDailyIssueStatus.NEW,
    val category: String = "",
    val assignee: String = "",
    val createdBy: String = "",
    val updatedAt: String? = null,
    val resolvedAt: String? = null,
    val cancelledAt: String? = null,
    val resolutionNote: String = ""
) {
    fun allImageUrls(): List<String> = (imageUrls + imageUrl).filter { it.isNotBlank() }.distinct().take(10)
    fun allImagePaths(): List<String> = (imagePaths + imagePath).filter { it.isNotBlank() }.distinct().take(10)
}

data class TpAuditEntry(
    val id: String,
    val action: String,
    val brigadeId: String? = null,
    val recordDate: String? = null,
    val details: String,
    val createdAt: String
)


data class TpExtraHourType(
    val id: String,
    val name: String,
    val hourlyRate: Double,
    val archived: Boolean = false
)

data class TpWorkerExtraHour(
    val id: String,
    val workerId: String,
    val brigadeId: String,
    val date: String,
    val typeId: String,
    val typeNameSnapshot: String,
    val hours: Double,
    val hourlyRateSnapshot: Double,
    val note: String = "",
    val createdAt: String
) {
    val amount: Long get() = (hours.coerceAtLeast(0.0) * hourlyRateSnapshot.coerceAtLeast(0.0)).roundToLong()
}

data class TpBrigadeShiftSelection(
    val id: String,
    val brigadeId: String,
    val date: String,
    val shiftId: String,
    val selectedAt: String,
    val selectedBy: String = ""
)

data class TpMachineWorkerAssignment(
    val id: String,
    val machineId: String,
    val brigadeId: String,
    val shiftId: String,
    val date: String,
    val workerId: String? = null,
    val workerNameSnapshot: String,
    /** BRIGADE, LOANED or OTHER. OTHER still points at a known worker when workerId is present. */
    val source: String = "BRIGADE",
    /** ISO local date-time in new records; legacy HH:mm values remain readable. */
    val startedAt: String,
    /** ISO local date-time in new records; null while the assignment is active. */
    val endedAt: String? = null,
    val note: String = "",
    val createdAt: String,
    val updatedAt: String? = null
) {
    val isActive: Boolean get() = endedAt.isNullOrBlank()
}

data class TpMachineDowntime(
    val id: String,
    val machineId: String,
    val brigadeId: String,
    val date: String,
    val stoppedAt: String,
    /** Blank while the machine is still stopped. */
    val startedAt: String = "",
    val reason: String,
    val createdAt: String,
    val note: String = "",
    val correctedAt: String? = null,
    val correctionReason: String = ""
) {
    val isActive: Boolean get() = startedAt.isBlank()

    fun durationMinutes(referenceTime: LocalTime = LocalTime.now()): Int {
        val start = runCatching { LocalTime.parse(stoppedAt) }.getOrNull() ?: return 0
        val end = if (startedAt.isBlank()) referenceTime else runCatching { LocalTime.parse(startedAt) }.getOrNull() ?: return 0
        val raw = Duration.between(start, end).toMinutes()
        return (if (raw < 0) raw + 24 * 60 else raw).toInt().coerceAtLeast(0)
    }
}

data class TpSettings(
    val firstBatchEntered: Boolean = false,
    val priceRevision: Int = 0,
    /** One TP/Seryo daily earnings target shared by every worker. */
    val dailyTargetAmount: Long = 0L,
    /** Legacy symmetric window retained so old 0.11.x snapshots decode without loss. */
    val qualityRoundWindowMinutes: Int = 60,
    /** Independent quality-entry allowance before the configured round time. */
    val qualityRoundBeforeMinutes: Int = qualityRoundWindowMinutes,
    /** Independent quality-entry allowance after the configured round time. */
    val qualityRoundAfterMinutes: Int = qualityRoundWindowMinutes
)

data class TpData(
    val shops: List<TpShop> = emptyList(),
    val shifts: List<TpShift> = emptyList(),
    val brigades: List<TpBrigade> = emptyList(),
    val machines: List<TpMachine> = emptyList(),
    val workers: List<TpWorker> = emptyList(),
    val products: List<TpProduct> = emptyList(),
    val materials: List<TpMaterial> = emptyList(),
    val orders: List<TpOrder> = emptyList(),
    val jobs: List<TpPlanJob> = emptyList(),
    val attendance: List<TpAttendance> = emptyList(),
    val attendanceDays: List<TpAttendanceDayState> = emptyList(),
    val receipts: List<TpReceipt> = emptyList(),
    val qualityRounds: List<TpQualityRound> = emptyList(),
    val dailyIssues: List<TpDailyIssue> = emptyList(),
    val extraHourTypes: List<TpExtraHourType> = emptyList(),
    val extraHours: List<TpWorkerExtraHour> = emptyList(),
    val brigadeShiftSelections: List<TpBrigadeShiftSelection> = emptyList(),
    val machineWorkerAssignments: List<TpMachineWorkerAssignment> = emptyList(),
    val machineDowntimes: List<TpMachineDowntime> = emptyList(),
    val seryoCompensations: List<TpSeryoCompensationOrder> = emptyList(),
    val auditLog: List<TpAuditEntry> = emptyList(),
    val settings: TpSettings = TpSettings()
) {
    fun orderProgress(orderId: String): Double {
        val orderJobs = jobs.filter { it.orderId == orderId }
        val required = orderJobs.sumOf { job -> job.outputs.sumOf { it.requiredPieces } }
        if (required <= 0) return 0.0
        val received = orderJobs.sumOf { job ->
            job.outputs.sumOf { output ->
                receipts.filter { !it.isCancelled && it.jobId == job.id && it.detailId == output.detailId }
                    .sumOf { it.creditedPieces }
                    .coerceAtMost(output.requiredPieces)
            }
        }
        return received * 100.0 / required
    }

    fun openRemainder(jobId: String, detailId: String): Int = receipts
        .filter { !it.isCancelled && it.jobId == jobId && it.detailId == detailId }
        .maxByOrNull { it.createdAt }
        ?.remainderAfter
        ?: 0

    fun workerPieceEarned(workerId: String, date: String): Long = receipts
        .filter { !it.isCancelled && it.workerId == workerId && it.date == date }
        .sumOf { it.earnedAmount }

    fun workerExtraEarned(workerId: String, date: String): Long = extraHours
        .filter { it.workerId == workerId && it.date == date }
        .sumOf { it.amount }

    fun workerEarned(workerId: String, date: String): Long = workerPieceEarned(workerId, date) + workerExtraEarned(workerId, date)

    fun workerQuality(workerId: String, date: String): Double? = qualityRounds
        .filter { it.workerId == workerId && it.date == date && !it.excludedFromAverage }
        .map { it.score }
        .takeIf { it.isNotEmpty() }
        ?.average()

    fun brigadeShiftIdForDate(brigadeId: String, date: String): String =
        brigadeShiftSelections.firstOrNull { it.brigadeId == brigadeId && it.date == date }?.shiftId
            ?: brigades.firstOrNull { it.id == brigadeId }?.shiftId.orEmpty()

    fun workerStandardMinutes(workerId: String, date: String? = null): Int {
        val worker = workers.firstOrNull { it.id == workerId } ?: return 0
        val shiftId = date?.let { brigadeShiftIdForDate(worker.brigadeId, it) }
            ?: brigades.firstOrNull { it.id == worker.brigadeId }?.shiftId.orEmpty()
        return shifts.firstOrNull { it.id == shiftId }?.durationMinutes() ?: 0
    }

    fun globalDailyTargetAmount(): Long = settings.dailyTargetAmount.takeIf { it > 0L }
        ?: workers.firstOrNull { it.dailyTargetAmount > 0L }?.dailyTargetAmount
        ?: 100_000L

    fun attendanceDay(date: String, shiftId: String): TpAttendanceDayState? =
        attendanceDays.firstOrNull { it.date == date && it.shiftId == shiftId }

    fun attendanceWorkMinutes(workerId: String, date: String): Int {
        val day = attendance.firstOrNull { it.workerId == workerId && it.date == date } ?: return 0
        val standardMinutes = workerStandardMinutes(workerId, date)
        if (!day.present || standardMinutes <= 0) return 0
        return if (day.minusHours >= 0.0) {
            val minusMinutes = (day.minusHours.coerceAtLeast(0.0) * 60.0).roundToInt()
            (standardMinutes - minusMinutes).coerceIn(0, standardMinutes)
        } else {
            day.workMinutes.coerceIn(0, standardMinutes)
        }
    }

    fun workerEfficiency(workerId: String, date: String): Double? {
        if (workers.none { it.id == workerId }) return null
        val day = attendance.firstOrNull { it.workerId == workerId && it.date == date } ?: return null
        val standardMinutes = workerStandardMinutes(workerId)
        val dailyTarget = globalDailyTargetAmount()
        val actualMinutes = attendanceWorkMinutes(workerId, date)
        if (!day.present || actualMinutes <= 0 || dailyTarget <= 0 || standardMinutes <= 0) return null
        val target = dailyTarget.toDouble() * actualMinutes / standardMinutes
        return if (target > 0) workerEarned(workerId, date) * 100.0 / target else null
    }

    fun workerUsefulness(workerId: String, date: String): Double? {
        val efficiency = workerEfficiency(workerId, date) ?: return null
        val quality = workerQuality(workerId, date) ?: return null
        return (efficiency + quality) / 2.0
    }

    fun activeJobsForMachine(machineId: String): List<TpPlanJob> = jobs
        .filter { it.machineId == machineId && it.status != TpJobStatus.COMPLETE }
        .sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id })

    fun machineDowntimeMinutes(machineId: String, date: String): Int = machineDowntimes
        .filter { it.machineId == machineId && it.date == date }
        .sumOf { runCatching { it.durationMinutes() }.getOrDefault(0) }
}


fun TpMaterial.currentStock(): Double = availableAmount + movements.sumOf { movement ->
    if (movement.kind == TpMaterialMovementKind.IN) movement.amount else -movement.amount
}

fun TpMaterial.dayIncoming(date: String): Double = movements
    .filter { it.kind == TpMaterialMovementKind.IN && it.createdAt.take(10) == date }
    .sumOf { it.amount }

fun TpMaterial.dayOutgoing(date: String): Double = movements
    .filter { it.kind == TpMaterialMovementKind.OUT && it.createdAt.take(10) == date }
    .sumOf { it.amount }

fun TpMaterial.openingStock(date: String): Double = availableAmount + movements
    .filter { it.createdAt.take(10) < date }
    .sumOf { if (it.kind == TpMaterialMovementKind.IN) it.amount else -it.amount }

fun TpMaterial.closingStock(date: String): Double = openingStock(date) + dayIncoming(date) - dayOutgoing(date)

fun TpData.materialStock(type: TpMaterialType, code: String): Double = materials
    .firstOrNull { !it.archived && it.type == type && it.code.equals(code, true) }
    ?.currentStock() ?: 0.0


fun tpPriorityLabel(priority: Int): String = when (priority.coerceIn(1, 3)) {
    1 -> "Eng zaril"
    2 -> "Zaril"
    else -> "Keyinroq"
}

fun TpDetail.resinOptions(): List<String> = (resinCodes.ifEmpty { listOf(resinCode) })
    .map { it.trim().uppercase(Locale.ROOT) }
    .filter { it.isNotBlank() }
    .distinct()

fun TpDetail.acceptsMachine(machine: TpMachine): Boolean {
    if (machine.archived) return false
    return compatibleCapacities.isEmpty() || (machine.capacity > 0 && machine.capacity in compatibleCapacities)
}

fun TpPlanJob.acceptsMachine(machine: TpMachine, data: TpData): Boolean {
    if (machine.archived) return false
    val detailCaps = outputs.mapNotNull { output ->
        data.products.asSequence().flatMap { it.details.asSequence() }
            .firstOrNull { it.id == output.detailId }?.compatibleCapacities
    }.filter { it.isNotEmpty() }
    if (detailCaps.isEmpty()) return true
    val common = detailCaps.drop(1).fold(detailCaps.first()) { acc, set -> acc intersect set }
    return machine.capacity > 0 && machine.capacity in common
}

fun TpData.machineAvailabilityMinutes(machineId: String, excludingOrderId: String? = null): Int = jobs
    .filter { it.machineId == machineId && it.status != TpJobStatus.COMPLETE && it.orderId != excludingOrderId }
    .sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id })
    .sumOf { it.estimatedMinutes.coerceAtLeast(0) }

/**
 * Planner no longer chooses a brigade manually. The brigade is derived from the machine shop and
 * the shift that will be active when the newly queued mould is expected to start. If the machine is
 * idle, [delayMinutes] is zero and the current shift is used.
 */
fun TpData.autoBrigadeForMachine(machineId: String, delayMinutes: Int = 0): TpBrigade? {
    val machine = machines.firstOrNull { it.id == machineId && !it.archived } ?: return null
    val targetTime = LocalDateTime.now().plusMinutes(delayMinutes.coerceAtLeast(0).toLong()).toLocalTime()
    fun TpShift.contains(time: LocalTime): Boolean {
        val start = runCatching { LocalTime.parse(startTime) }.getOrNull() ?: return false
        val end = runCatching { LocalTime.parse(endTime) }.getOrNull() ?: return false
        return if (start < end) !time.isBefore(start) && time < end else !time.isBefore(start) || time < end
    }
    val shiftIds = shifts.filter { !it.archived && it.contains(targetTime) }.map { it.id }.toSet()
    return brigades.filter { !it.archived && it.shopId == machine.shopId }
        .sortedBy { it.name.lowercase(Locale.ROOT) }
        .firstOrNull { it.shiftId in shiftIds }
        ?: brigades.filter { !it.archived && it.shopId == machine.shopId }.sortedBy { it.name.lowercase(Locale.ROOT) }.firstOrNull()
}

fun TpData.orderForecastMinutes(orderId: String): Int {
    val order = orders.firstOrNull { it.id == orderId } ?: return 0
    val planned = jobs.filter { it.orderId == orderId }
    val sourceJobs = if (planned.isNotEmpty()) planned else runCatching {
        buildPlanJobs(this, order) { "forecast-${order.id}-${System.nanoTime()}" }
    }.getOrDefault(emptyList())
    if (sourceJobs.isEmpty()) return 0

    // Greedy optimistic forecast: each unassigned color job uses the compatible machine that can
    // finish it earliest; assigned jobs respect the machine queue already planned before them.
    val virtualLoads = machines.filterNot { it.archived }.associate { it.id to machineAvailabilityMinutes(it.id, orderId) }.toMutableMap()
    var completion = 0
    sourceJobs.sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id }).forEach { job ->
        val assigned = job.machineId?.let { id -> machines.firstOrNull { it.id == id && job.acceptsMachine(it, this) } }
        val candidates = if (assigned != null) listOf(assigned) else machines.filter { job.acceptsMachine(it, this) }
        val machine = candidates.minWithOrNull(compareBy<TpMachine> { virtualLoads[it.id] ?: 0 }.thenBy { it.number })
            ?: return 0
        val finish = run {
            val start = virtualLoads[machine.id] ?: 0
            val end = start + job.estimatedMinutes
            virtualLoads[machine.id] = end
            end
        }
        completion = maxOf(completion, finish)
    }
    return completion
}

fun allocateByColor(total: Int, colors: List<TpColorRule>): Map<String, Int> {
    if (total <= 0) return emptyMap()
    val valid = colors.filter { it.colorCode.isNotBlank() && it.share > 0.0 }
    if (valid.isEmpty()) return mapOf("000" to total)
    val sum = valid.sumOf { it.share }
    val raw = valid.map { rule -> rule to total * rule.share / sum }
    val base = raw.associate { (rule, value) -> rule.colorCode to value.toInt() }.toMutableMap()
    var remaining = total - base.values.sum()
    raw.sortedByDescending { (_, value) -> value - value.toInt() }.forEach { (rule, _) ->
        if (remaining > 0) {
            base[rule.colorCode] = base.getValue(rule.colorCode) + 1
            remaining--
        }
    }
    return base
}

fun nextBatchNumber(previous: String): String {
    val match = Regex("^(.*?)(\\d+)$").matchEntire(previous.trim())
    if (match != null) {
        val prefix = match.groupValues[1]
        val digits = match.groupValues[2]
        val next = digits.toLongOrNull()?.plus(1) ?: return "${previous.trim()}-2"
        return prefix + next.toString().padStart(digits.length, '0')
    }
    return "${previous.trim()}-2"
}

/**
 * Returns the next batch number for one concrete product.
 * Numeric suffixes are compared by value so product batch history, not global order creation time,
 * drives the suggestion. Different products are intentionally independent.
 */
fun nextBatchNumberForProduct(existing: List<String>): String {
    val clean = existing.map { it.trim() }.filter { it.isNotBlank() }
    if (clean.isEmpty()) return ""
    val parsed = clean.mapNotNull { raw ->
        val match = Regex("^(.*?)(\\d+)$").matchEntire(raw) ?: return@mapNotNull null
        val digits = match.groupValues[2]
        val number = digits.toLongOrNull() ?: return@mapNotNull null
        Triple(raw, number, digits.length)
    }
    val base = parsed.maxWithOrNull(compareBy<Triple<String, Long, Int>> { it.second }.thenBy { it.first })?.first
        ?: clean.last()
    return nextBatchNumber(base)
}

fun calculateReceiptCredit(
    bagCapacity: Int,
    carryInPieces: Int,
    completedBags: Int,
    remainderAfter: Int
): Int {
    require(bagCapacity > 0) { "Qop sig‘imi 0 dan katta bo‘lsin" }
    require(carryInPieces in 0 until bagCapacity) { "Oldingi qoldiq noto‘g‘ri" }
    require(completedBags >= 0) { "Qop soni manfiy bo‘lmasin" }
    require(remainderAfter in 0 until bagCapacity) { "Yangi qoldiq qop sig‘imidan kam bo‘lsin" }
    val credited = completedBags * bagCapacity - carryInPieces + remainderAfter
    require(credited > 0) { "Yangi ishlab chiqarilgan son 0 dan katta bo‘lsin" }
    return credited
}

fun calculatePieceWorkAmount(pieces: Int, piecesPerShot: Int, pricePerShot: Double): Long {
    if (pieces <= 0 || piecesPerShot <= 0 || pricePerShot <= 0.0) return 0L
    return (pieces.toDouble() / piecesPerShot.toDouble() * pricePerShot).roundToLong()
}

fun buildPlanJobs(data: TpData, order: TpOrder, idFactory: () -> String): List<TpPlanJob> {
    val product = data.products.firstOrNull { it.id == order.productId } ?: error("Mahsulot topilmadi")
    require(product.details.any { !it.archived }) { "Mahsulot detallari kiritilmagan" }
    var sequence = 0
    return product.details.filterNot { it.archived }.groupBy { it.moldCode.ifBlank { it.id } }.flatMap { (moldCode, details) ->
        val resinSets = details.map { it.resinOptions().toSet() }
        require(resinSets.all { it.isNotEmpty() }) { "$moldCode qolipidagi har bir detal uchun seryo turini kiriting" }
        val commonResins = resinSets.drop(1).fold(resinSets.first()) { acc, set -> acc intersect set }.sorted()
        require(commonResins.isNotEmpty()) {
            "$moldCode qolipida birga chiqadigan detallar uchun umumiy seryo turi topilmadi"
        }
        val colorSignatures = details.map { detail ->
            detail.colors.sortedBy { it.colorCode.uppercase(Locale.ROOT) }
                .map { Triple(it.colorCode.trim().uppercase(Locale.ROOT), it.share, it.gramsPer25Kg) }
        }
        require(colorSignatures.distinct().size == 1) {
            "$moldCode qolipida birga chiqadigan detallar rang taqsimoti bir xil bo‘lsin"
        }
        val allocations = details.associateWith { detail ->
            allocateByColor(order.quantity * detail.requiredPerProduct, detail.colors)
        }
        val colorCodes = allocations.values.flatMap { it.keys }.distinct()
        colorCodes.mapNotNull { colorCode ->
            val requiredByDetail = details.mapNotNull { detail ->
                val required = allocations.getValue(detail)[colorCode] ?: 0
                if (required > 0) detail to required else null
            }
            if (requiredByDetail.isEmpty()) return@mapNotNull null
            val shots = requiredByDetail.maxOf { (detail, required) ->
                ceil(required.toDouble() / detail.piecesPerShot.coerceAtLeast(1)).toInt()
            }
            val outputs = requiredByDetail.map { (detail, required) ->
                TpJobOutput(
                    detailId = detail.id,
                    detailName = detail.name,
                    requiredPieces = required,
                    plannedPieces = shots * detail.piecesPerShot,
                    piecesPerShot = detail.piecesPerShot,
                    bagCapacity = detail.bagCapacity,
                    unitPrice = detail.unitPrice
                )
            }
            val reference = requiredByDetail.first().first
            val cycleSeconds = details.maxOf { it.cycleSeconds }
            val grossGrams = details.maxOf { it.grossShotWeightGrams }
            val resinKg = shots * grossGrams / 1000.0
            val colorRule = reference.colors.firstOrNull { it.colorCode == colorCode }
            val colorGrams = resinKg / 25.0 * (colorRule?.gramsPer25Kg ?: 0.0)
            val capacitySets = details.map { it.compatibleCapacities }.filter { it.isNotEmpty() }
            val capacityIntersection = capacitySets.drop(1).fold(capacitySets.firstOrNull().orEmpty()) { result, set -> result intersect set }
            require(capacitySets.size < 2 || capacityIntersection.isNotEmpty()) {
                "$moldCode qolipidagi detallar uchun umumiy stanok sig‘imi topilmadi"
            }
            sequence++
            TpPlanJob(
                id = idFactory(),
                orderId = order.id,
                moldCode = moldCode,
                colorCode = colorCode,
                outputs = outputs,
                requiredShots = shots,
                cycleSeconds = cycleSeconds,
                estimatedMinutes = ceil(shots * cycleSeconds / 60.0).toInt(),
                resinCode = commonResins.first(),
                requiredResinKg = roundMaterial(resinKg),
                requiredColorGrams = roundMaterial(colorGrams),
                compatibleMachineIds = emptySet(),
                priority = order.priority * 100 + sequence
            )
        }
    }
}

/** Operational UI standard: all resin/recycled/colorant quantities are shown in kilograms.
 * Internally COLOR remains stored in grams for backward compatibility with existing data and recipes. */
fun TpMaterialType.operationalKg(internalAmount: Double): Double = if (this == TpMaterialType.COLOR) internalAmount / 1000.0 else internalAmount
fun TpMaterial.operationalStockKg(): Double = type.operationalKg(currentStock())

fun formatTpNumber(value: Double): String = BigDecimal.valueOf(value)
    .setScale(3, RoundingMode.HALF_UP)
    .stripTrailingZeros()
    .toPlainString()

private fun roundMaterial(value: Double): Double = BigDecimal.valueOf(value)
    .setScale(3, RoundingMode.HALF_UP)
    .toDouble()

fun isoToday(): String = LocalDate.now().toString()
