package uz.toybola.factory.core.firebase

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.BackoffPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

object FirebaseSyncScheduler {
    private const val UNIQUE_WORK = "toybola_server_sync"
    private val signals = Channel<Unit>(Channel.CONFLATED)
    val foregroundRequests = signals.receiveAsFlow()
    val generation = AtomicLong(0)

    fun enqueue(context: Context) {
        generation.incrementAndGet()
        signals.trySend(Unit)
        val request = OneTimeWorkRequestBuilder<FirebaseSyncWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(context.applicationContext)
            .enqueueUniqueWork(UNIQUE_WORK, ExistingWorkPolicy.KEEP, request)
    }

    fun ensurePeriodic(context: Context) {
        val request = PeriodicWorkRequestBuilder<FirebaseSyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
            "toybola_periodic_sync", ExistingPeriodicWorkPolicy.KEEP, request
        )
    }
}
