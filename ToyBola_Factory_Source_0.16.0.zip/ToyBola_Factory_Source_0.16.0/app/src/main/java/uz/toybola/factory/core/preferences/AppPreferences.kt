package uz.toybola.factory.core.preferences

import android.content.Context
import uz.toybola.factory.ui.model.AppLanguage
import uz.toybola.factory.ui.model.AppSettings
import uz.toybola.factory.ui.model.AppThemePreset
import uz.toybola.factory.ui.model.UserSetup
import uz.toybola.factory.ui.model.normalized
import java.util.Locale

class AppPreferences(context: Context) {
    val appContext: Context = context.applicationContext
    private val prefs = appContext.getSharedPreferences("toy_bola_prefs", Context.MODE_PRIVATE)

    // 0.1.0 -> 0.2.0 migration: old app PIN hash is ignored and removed on next setup save.
    fun hasSetup(): Boolean = prefs.getString(KEY_DEVICE_CODE, "").orEmpty().isNotBlank() &&
        prefs.getString(KEY_USER_CODE, "").orEmpty().isNotBlank()

    fun saveSetup(deviceCode: String, userCode: String) {
        prefs.edit()
            .putString(KEY_DEVICE_CODE, deviceCode.trim().uppercase(Locale.ROOT))
            .putString(KEY_USER_CODE, userCode.trim().uppercase(Locale.ROOT))
            .remove(KEY_PIN_HASH_LEGACY)
            .apply()
    }

    fun setup(): UserSetup? {
        if (!hasSetup()) return null
        return UserSetup(
            deviceCode = prefs.getString(KEY_DEVICE_CODE, "").orEmpty(),
            userCode = prefs.getString(KEY_USER_CODE, "").orEmpty()
        )
    }

    fun validateCodes(deviceCode: String, userCode: String): Boolean {
        val setup = setup() ?: return false
        return setup.deviceCode.equals(deviceCode.trim(), ignoreCase = true) &&
            setup.userCode.equals(userCode.trim(), ignoreCase = true)
    }


    fun markSessionUnlocked(nowMs: Long = System.currentTimeMillis()) {
        prefs.edit().putLong(KEY_SESSION_ACTIVITY, nowMs).remove(KEY_SESSION_BACKGROUND).apply()
    }

    fun markSessionActivity(nowMs: Long = System.currentTimeMillis()) {
        prefs.edit().putLong(KEY_SESSION_ACTIVITY, nowMs).apply()
    }

    fun markSessionBackgrounded(nowMs: Long = System.currentTimeMillis()) {
        prefs.edit().putLong(KEY_SESSION_BACKGROUND, nowMs).putLong(KEY_SESSION_ACTIVITY, nowMs).apply()
    }

    fun clearUnlockSession() {
        prefs.edit().remove(KEY_SESSION_ACTIVITY).remove(KEY_SESSION_BACKGROUND).apply()
    }

    fun isUnlockSessionValid(autoLockMinutes: Int, nowMs: Long = System.currentTimeMillis()): Boolean {
        if (!hasSetup() || autoLockMinutes <= 0) return false
        val last = maxOf(prefs.getLong(KEY_SESSION_ACTIVITY, 0L), prefs.getLong(KEY_SESSION_BACKGROUND, 0L))
        if (last <= 0L || nowMs < last) return false
        return nowMs - last < autoLockMinutes * 60_000L
    }

    fun loadSettings(): AppSettings {
        val language = runCatching {
            AppLanguage.valueOf(prefs.getString(KEY_LANGUAGE, AppLanguage.UZ.name).orEmpty())
        }.getOrDefault(AppLanguage.UZ)
        val legacyDark = prefs.getBoolean(KEY_DARK, false)
        val preset = if (prefs.contains(KEY_THEME)) {
            runCatching {
                AppThemePreset.valueOf(prefs.getString(KEY_THEME, AppThemePreset.SYSTEM.name).orEmpty())
            }.getOrDefault(AppThemePreset.SYSTEM).normalized(legacyDark)
        } else {
            AppThemePreset.SYSTEM
        }
        return AppSettings(
            language = language,
            darkMode = preset == AppThemePreset.DARK_CALM,
            themePreset = preset,
            autoLockMinutes = prefs.getInt(KEY_LOCK_MINUTES, 5),
            uiScalePercent = prefs.getInt(KEY_UI_SCALE, 100).coerceIn(90, 110),
            drawerScalePercent = prefs.getInt(KEY_DRAWER_SCALE, 80).coerceIn(70, 110)
        )
    }

    fun saveSettings(settings: AppSettings) {
        prefs.edit()
            .putString(KEY_LANGUAGE, settings.language.name)
            .putBoolean(KEY_DARK, settings.themePreset.normalized(settings.darkMode) == AppThemePreset.DARK_CALM)
            .putString(KEY_THEME, settings.themePreset.normalized(settings.darkMode).name)
            .putInt(KEY_LOCK_MINUTES, settings.autoLockMinutes)
            .putInt(KEY_UI_SCALE, settings.uiScalePercent.coerceIn(90, 110))
            .putInt(KEY_DRAWER_SCALE, settings.drawerScalePercent.coerceIn(70, 110))
            .apply()
    }

    companion object {
        private const val KEY_DEVICE_CODE = "device_code"
        private const val KEY_USER_CODE = "user_code"
        private const val KEY_PIN_HASH_LEGACY = "pin_hash"
        private const val KEY_LANGUAGE = "language"
        private const val KEY_DARK = "dark_mode"
        private const val KEY_THEME = "theme"
        private const val KEY_LOCK_MINUTES = "lock_minutes"
        private const val KEY_DRAWER_SCALE = "drawer_scale_percent"
        private const val KEY_UI_SCALE = "ui_scale_percent"
        private const val KEY_SESSION_ACTIVITY = "unlock_session_activity_ms"
        private const val KEY_SESSION_BACKGROUND = "unlock_session_background_ms"
    }
}
