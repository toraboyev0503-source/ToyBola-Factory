package uz.toybola.factory.ui.components

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/** Cross-cutting navigation requests emitted by shared UI such as the global sync status pill. */
object AppNavigationEvents {
    private val _openSyncCenter = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val openSyncCenter = _openSyncCenter.asSharedFlow()

    private val _homeReselected = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val homeReselected = _homeReselected.asSharedFlow()

    fun requestSyncCenter() {
        _openSyncCenter.tryEmit(Unit)
    }

    fun requestHomeTop() {
        _homeReselected.tryEmit(Unit)
    }
}
