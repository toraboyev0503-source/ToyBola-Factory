package uz.toybola.factory.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.toybola.factory.ui.model.AppScreen
import uz.toybola.factory.ui.model.AppStrings

@Composable
fun GlobalBottomBar(
    strings: AppStrings,
    current: AppScreen,
    unreadNotifications: Int,
    syncing: Boolean,
    onHome: () -> Unit,
    onNotifications: () -> Unit,
    onSync: () -> Unit,
    onSettings: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            shadowElevation = 2.dp,
            tonalElevation = 0.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp)
                    .padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BottomItem(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Home,
                    label = strings.homeNav,
                    selected = current.isHomeRootScreen(),
                    onClick = onHome
                )
                BottomItem(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Notifications,
                    label = strings.notifications,
                    selected = current == AppScreen.NOTIFICATIONS,
                    badgeCount = unreadNotifications,
                    onClick = onNotifications
                )
                BottomItem(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Sync,
                    label = strings.syncNav,
                    selected = current == AppScreen.SYNC_CENTER,
                    rotatingHint = syncing,
                    onClick = onSync
                )
                BottomItem(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Settings,
                    label = strings.menu,
                    selected = current == AppScreen.SETTINGS,
                    onClick = onSettings
                )
            }
        }
    }
}

@Composable
private fun BottomItem(
    modifier: Modifier,
    icon: ImageVector,
    label: String,
    selected: Boolean,
    badgeCount: Int = 0,
    rotatingHint: Boolean = false,
    onClick: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    val tint = when {
        selected -> primary
        rotatingHint -> primary.copy(alpha = 0.82f)
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f) else Color.Transparent,
        tonalElevation = 0.dp,
        modifier = modifier.padding(horizontal = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp, vertical = 7.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(contentAlignment = Alignment.TopEnd) {
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
                if (badgeCount > 0) {
                    Badge(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError,
                        modifier = Modifier.offset(x = 8.dp, y = (-5).dp)
                    ) {
                        Text(
                            badgeCount.coerceAtMost(99).toString(),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                label,
                color = tint,
                fontSize = 10.sp,
                lineHeight = 12.sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

private fun AppScreen.isHomeRootScreen(): Boolean = this !in setOf(
    AppScreen.NOTIFICATIONS, AppScreen.SYNC_CENTER, AppScreen.SETTINGS, AppScreen.USER_ADMIN, AppScreen.BACKUP_RESTORE,
    AppScreen.SPLASH, AppScreen.SETUP, AppScreen.LOGIN
)
