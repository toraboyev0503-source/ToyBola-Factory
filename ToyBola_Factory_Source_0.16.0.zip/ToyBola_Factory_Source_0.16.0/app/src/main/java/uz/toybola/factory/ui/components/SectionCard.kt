package uz.toybola.factory.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Neutral, low-elevation card from the frozen 0.13 Design System. */
@Composable
fun SectionCard(
    number: Int?,
    title: String,
    description: String,
    enabled: Boolean,
    badgeCount: Int = 0,
    modifier: Modifier = Modifier,
    accentColor: Color = Color(0xFF4A90E2),
    icon: ImageVector? = null,
    visuallyActive: Boolean = enabled,
    onClick: () -> Unit
) {
    val surface = MaterialTheme.colorScheme.surface
    val muted = MaterialTheme.colorScheme.surfaceVariant
    val titleColor = if (visuallyActive) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.58f)
    val secondaryColor = if (visuallyActive) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.46f)
    val accent = if (visuallyActive) accentColor else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.36f)

    Surface(
        modifier = modifier
            .heightIn(min = 112.dp)
            .clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = if (visuallyActive) surface else muted,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        tonalElevation = 0.dp,
        shadowElevation = if (visuallyActive) 1.dp else 0.dp
    ) {
        Row(Modifier.fillMaxSize()) {
            Box(Modifier.width(4.dp).fillMaxHeight()) {
                Surface(modifier = Modifier.fillMaxSize(), color = accent, content = {})
            }
            Column(
                modifier = Modifier.weight(1f).padding(14.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    if (icon != null) {
                        Surface(shape = RoundedCornerShape(10.dp), color = accent.copy(alpha = 0.12f)) {
                            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.padding(8.dp).size(22.dp))
                        }
                    }
                    if (number != null) {
                        Spacer(Modifier.weight(1f))
                        Text(number.toString().padStart(2, '0'), color = accent, fontWeight = FontWeight.Medium, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(title, color = titleColor, fontSize = 16.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Text(description, color = secondaryColor, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            if (badgeCount > 0 && enabled) {
                Surface(
                    modifier = Modifier.padding(top = 8.dp, end = 8.dp),
                    shape = RoundedCornerShape(99.dp),
                    color = MaterialTheme.colorScheme.error
                ) {
                    Text(
                        badgeCount.coerceAtMost(99).toString(),
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                        color = MaterialTheme.colorScheme.onError,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
