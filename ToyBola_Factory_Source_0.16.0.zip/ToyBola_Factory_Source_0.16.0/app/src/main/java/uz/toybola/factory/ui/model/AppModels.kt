package uz.toybola.factory.ui.model

enum class AppLanguage { UZ, RU, EN }

/**
 * D-047 frozen theme choices. BRAND/CALM/NEUTRAL remain only so 0.12.x preferences
 * and backups can still be read safely; UI never offers the legacy values.
 */
enum class AppThemePreset {
    SYSTEM,
    LIGHT_CALM,
    SOFT_BLUE,
    DARK_CALM,
    BRAND,
    CALM,
    NEUTRAL
}

val SelectableThemePresets: List<AppThemePreset> = listOf(
    AppThemePreset.SYSTEM,
    AppThemePreset.LIGHT_CALM,
    AppThemePreset.SOFT_BLUE,
    AppThemePreset.DARK_CALM
)

fun AppThemePreset.normalized(darkMode: Boolean = false): AppThemePreset = when (this) {
    AppThemePreset.BRAND, AppThemePreset.CALM, AppThemePreset.NEUTRAL ->
        if (darkMode) AppThemePreset.DARK_CALM else AppThemePreset.LIGHT_CALM
    else -> this
}

data class UserSetup(
    val deviceCode: String,
    val userCode: String
)

data class AppSettings(
    val language: AppLanguage = AppLanguage.UZ,
    // Kept for backward backup/preferences compatibility. New themes are represented by themePreset.
    val darkMode: Boolean = false,
    val themePreset: AppThemePreset = AppThemePreset.SYSTEM,
    val autoLockMinutes: Int = 5,
    // Whole-interface scale. Legacy drawerScalePercent is retained only for backward compatibility.
    val uiScalePercent: Int = 100,
    val drawerScalePercent: Int = 80
)

enum class AppScreen {
    SPLASH,
    SETUP,
    LOGIN,
    HOME,
    MANAGEMENT,
    NOTIFICATIONS,
    SETTINGS,
    SYNC_CENTER,
    TP_MAIN,
    TP_PLAN,
    TP_SHIFT,
    TP_ATTENDANCE,
    TP_SERYO,
    TP_RECEIVING,
    TP_QUALITY,
    TP_MONITORING,
    TP_MASTER_DATA,
    ASSEMBLY_ENTRY,
    ASSEMBLY,
    BRIGADIR,
    QUALITY,
    DAILY_ISSUE,
    MONITORING,
    MASTER_DATA,
    USER_ADMIN,
    BACKUP_RESTORE
}
