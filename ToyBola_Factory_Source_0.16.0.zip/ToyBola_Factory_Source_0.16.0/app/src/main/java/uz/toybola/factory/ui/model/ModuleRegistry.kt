package uz.toybola.factory.ui.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.canReadScreen

data class FactoryModuleSpec(
    val number: Int,
    val key: String,
    val launched: Boolean,
    val route: AppScreen?,
    val accent: Color,
    val icon: ImageVector
)

/** Single source of truth for Home module launch state, route and visual identity. */
object ModuleRegistry {
    val production = listOf(
        FactoryModuleSpec(1, "SERYO", true, AppScreen.TP_SERYO, Color(0xFF4A90E2), Icons.Rounded.Settings),
        FactoryModuleSpec(2, "TP", true, AppScreen.TP_MAIN, Color(0xFF4A90E2), Icons.Rounded.Inventory2),
        FactoryModuleSpec(3, "YTM", false, null, Color(0xFF55A65A), Icons.Rounded.Warehouse),
        FactoryModuleSpec(4, "SPARE", false, null, Color(0xFFF29A2E), Icons.Rounded.Inventory2),
        FactoryModuleSpec(5, "ASSEMBLY", true, AppScreen.ASSEMBLY_ENTRY, Color(0xFF8665E8), Icons.Rounded.Groups),
        FactoryModuleSpec(6, "TM_EXP", false, null, Color(0xFFEF5A60), Icons.Rounded.LocalShipping)
    )
    val management = listOf(
        FactoryModuleSpec(7, "MANAGEMENT", true, AppScreen.MANAGEMENT, Color(0xFF5B86A6), Icons.Rounded.BarChart),
        FactoryModuleSpec(8, "MASTER", true, AppScreen.MASTER_DATA, Color(0xFF718394), Icons.Rounded.Description)
    )
    val all = production + management

    fun visible(spec: FactoryModuleSpec, policy: UserAccessPolicy): Boolean {
        if (!spec.launched) return true
        if (policy.isAdmin()) return true
        val route = spec.route ?: return true
        return policy.canReadScreen(route)
    }

    fun canOpen(spec: FactoryModuleSpec, policy: UserAccessPolicy): Boolean =
        spec.launched && spec.route != null && (policy.isAdmin() || policy.canReadScreen(spec.route))
}
