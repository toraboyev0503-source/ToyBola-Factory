package uz.toybola.factory.ui.navigation

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** One-shot object targets carried by notification/deep-link routes. */
object TpNavigationTargetState {
    var orderId by mutableStateOf<String?>(null)
        private set
    var jobId by mutableStateOf<String?>(null)
        private set
    var issueId by mutableStateOf<String?>(null)
        private set
    var attendanceDate by mutableStateOf<String?>(null)
        private set

    fun set(orderId: String? = null, jobId: String? = null, issueId: String? = null, attendanceDate: String? = null) {
        this.orderId = orderId?.takeIf { it.isNotBlank() }
        this.jobId = jobId?.takeIf { it.isNotBlank() }
        this.issueId = issueId?.takeIf { it.isNotBlank() }
        this.attendanceDate = attendanceDate?.takeIf { it.isNotBlank() }
    }

    fun consumeOrderId(): String? = orderId.also { orderId = null }
    fun consumeJobId(): String? = jobId.also { jobId = null }
    fun consumeIssueId(): String? = issueId.also { issueId = null }
    fun consumeAttendanceDate(): String? = attendanceDate.also { attendanceDate = null }
}
