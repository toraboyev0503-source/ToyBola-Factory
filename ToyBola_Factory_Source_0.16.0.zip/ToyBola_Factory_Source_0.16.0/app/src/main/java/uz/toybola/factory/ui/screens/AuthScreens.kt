package uz.toybola.factory.ui.screens

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import uz.toybola.factory.R
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.ui.model.AppStrings
import uz.toybola.factory.ui.model.UserSetup
import java.util.Locale

@Composable
fun SetupScreen(
    strings: AppStrings,
    onServerLogin: suspend (String, String, Boolean) -> Result<UserAccessPolicy>,
    onAuthenticated: (String, String, UserAccessPolicy) -> Unit
) {
    var deviceCode by remember { mutableStateOf("") }
    var userCode by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    fun authenticate() {
        scope.launch {
            loading = true
            error = null
            val result = onServerLogin(deviceCode, userCode, false)
            loading = false
            result.onSuccess { onAuthenticated(deviceCode, userCode, it) }
                .onFailure { error = it.message ?: "Serverga kirib bo‘lmadi" }
        }
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) authenticate() else error = strings.phoneLockFailed
    }

    fun requestPhoneLock() {
        error = when {
            deviceCode.isBlank() || userCode.isBlank() -> strings.required
            else -> null
        }
        if (error != null || loading) return
        val keyguard = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!keyguard.isDeviceSecure) {
            error = strings.phoneLockNotSet
            return
        }
        val intent = keyguard.createConfirmDeviceCredentialIntent(strings.confirmPhoneLock, strings.confirmPhoneLockDesc)
        if (intent == null) error = strings.phoneLockUnavailable else launcher.launch(intent)
    }

    AuthContainer(title = strings.firstSetup, subtitle = strings.setupHint) {
        OutlinedTextField(
            value = deviceCode,
            onValueChange = { deviceCode = it.uppercase(Locale.ROOT) },
            enabled = !loading,
            modifier = Modifier.fillMaxWidth(),
            label = { Text(strings.deviceCode) },
            singleLine = true
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = userCode,
            onValueChange = { userCode = it.uppercase(Locale.ROOT) },
            enabled = !loading,
            modifier = Modifier.fillMaxWidth(),
            label = { Text(strings.userCode) },
            singleLine = true
        )
        if (error != null) {
            Spacer(Modifier.height(8.dp))
            Text(error.orEmpty(), color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(18.dp))
        Button(onClick = ::requestPhoneLock, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
            if (loading) {
                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text("Server tekshirilmoqda…")
            } else Text(strings.confirmWithPhoneLock)
        }
    }
}

/**
 * Daily unlock is local and fast: the server codes are used only while linking/changing a profile.
 * The cached server policy remains authoritative for the UI and is refreshed in background after unlock.
 */
@Composable
fun LoginScreen(
    strings: AppStrings,
    savedSetup: UserSetup?,
    profileLabel: String,
    cachedPolicy: UserAccessPolicy?,
    onAuthenticated: (UserAccessPolicy) -> Unit,
    onChangeSetup: () -> Unit
) {
    val deviceCode = savedSetup?.deviceCode.orEmpty()
    val userCode = savedSetup?.userCode.orEmpty()
    var error by remember(deviceCode, userCode) { mutableStateOf<String?>(null) }
    var completed by remember(deviceCode, userCode) { mutableStateOf(false) }
    val context = LocalContext.current

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val policy = cachedPolicy
            if (policy == null) {
                error = "Profil ma’lumoti topilmadi. Profilni qayta ulang."
            } else if (!completed) {
                completed = true
                onAuthenticated(policy)
            }
        } else {
            error = strings.phoneLockFailed
        }
    }

    fun requestLogin() {
        if (completed) return
        if (deviceCode.isBlank() || userCode.isBlank() || cachedPolicy == null) {
            error = "Profilni qayta ulash kerak."
            return
        }
        val keyguard = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!keyguard.isDeviceSecure) {
            error = strings.phoneLockNotSet
            return
        }
        val intent = keyguard.createConfirmDeviceCredentialIntent(strings.confirmPhoneLock, strings.confirmPhoneLockDesc)
        if (intent == null) error = strings.phoneLockUnavailable else launcher.launch(intent)
    }

    LaunchedEffect(deviceCode, userCode, cachedPolicy?.revision) {
        if (deviceCode.isNotBlank() && userCode.isNotBlank() && cachedPolicy != null) {
            delay(120)
            requestLogin()
        }
    }

    AuthContainer(title = strings.login, subtitle = "Telefon qulfi bilan xavfsiz va tez kirish.") {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .58f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            tonalElevation = 0.dp
        ) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                Text(profileLabel.ifBlank { userCode }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(3.dp))
                Text("Qurilma sozlangan", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (error != null) {
            Spacer(Modifier.height(10.dp))
            Text(error.orEmpty(), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = ::requestLogin, enabled = !completed && cachedPolicy != null, modifier = Modifier.fillMaxWidth()) {
            Text(strings.confirmWithPhoneLock)
        }
        Spacer(Modifier.height(6.dp))
        TextButton(onClick = onChangeSetup, enabled = !completed, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text("Profilni almashtirish")
        }
    }
}

@Composable
private fun AuthContainer(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .imePadding()
            .padding(horizontal = 22.dp, vertical = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().widthIn(max = 460.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.toybola_mark),
                contentDescription = null,
                modifier = Modifier
                    .size(78.dp)
                    .clip(RoundedCornerShape(22.dp))
            )
            Spacer(Modifier.height(10.dp))
            Text("ToyBola", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            Text(
                "F a c t o r y",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(24.dp))
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.70f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(18.dp))
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                tonalElevation = 0.dp,
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(18.dp), content = content)
            }
        }
    }
}
