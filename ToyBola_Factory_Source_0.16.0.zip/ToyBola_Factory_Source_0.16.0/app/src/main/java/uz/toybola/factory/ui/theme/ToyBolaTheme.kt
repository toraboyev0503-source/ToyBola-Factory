package uz.toybola.factory.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import uz.toybola.factory.ui.model.AppSettings
import uz.toybola.factory.ui.model.AppThemePreset
import uz.toybola.factory.ui.model.normalized

object ToyBolaColors {
    val LightBackground = Color(0xFFF5F7F8)
    val LightSurface = Color(0xFFFFFFFF)
    val LightPrimary = Color(0xFF3F6173)
    val LightPrimarySoft = Color(0xFFDCE8ED)
    val LightText = Color(0xFF1D2529)
    val LightBorder = Color(0xFFD9E0E4)

    val SoftBlueBackground = Color(0xFFEDF6FD)
    val SoftBlueSurface = Color(0xFFFBFDFF)
    val SoftBluePrimary = Color(0xFF347FB8)
    val SoftBluePrimarySoft = Color(0xFFDCECF8)
    val SoftBlueText = Color(0xFF192B38)
    val SoftBlueBorder = Color(0xFFD5E4EE)

    val DarkBackground = Color(0xFF11181C)
    val DarkSurface = Color(0xFF182126)
    val DarkPrimary = Color(0xFF9FBBC8)
    val DarkText = Color(0xFFE7ECEF)
    val DarkBorder = Color(0xFF2B373D)

    val Success = Color(0xFF3F8F62)
    val Warning = Color(0xFFD18A27)
    val Error = Color(0xFFB94A48)
}

data class ToyBolaVisualMode(
    val preset: AppThemePreset,
    val isDark: Boolean
)

val LocalToyBolaVisualMode = staticCompositionLocalOf {
    ToyBolaVisualMode(AppThemePreset.LIGHT_CALM, false)
}

private val LightCalmScheme = lightColorScheme(
    primary = ToyBolaColors.LightPrimary,
    onPrimary = Color.White,
    primaryContainer = ToyBolaColors.LightPrimarySoft,
    onPrimaryContainer = Color(0xFF243D4A),
    secondary = Color(0xFF617D8B),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE7EEF1),
    onSecondaryContainer = Color(0xFF30454F),
    tertiary = ToyBolaColors.Success,
    background = ToyBolaColors.LightBackground,
    onBackground = ToyBolaColors.LightText,
    surface = ToyBolaColors.LightSurface,
    onSurface = ToyBolaColors.LightText,
    surfaceVariant = Color(0xFFF0F3F4),
    onSurfaceVariant = Color(0xFF66757D),
    outline = ToyBolaColors.LightBorder,
    outlineVariant = Color(0xFFE7ECEE),
    error = ToyBolaColors.Error,
    errorContainer = Color(0xFFF9E5E4),
    onErrorContainer = Color(0xFF6E2B2A)
)

private val SoftBlueScheme = lightColorScheme(
    primary = ToyBolaColors.SoftBluePrimary,
    onPrimary = Color.White,
    primaryContainer = ToyBolaColors.SoftBluePrimarySoft,
    onPrimaryContainer = Color(0xFF173F5D),
    secondary = Color(0xFF5B7D96),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE3EFF7),
    onSecondaryContainer = Color(0xFF29485C),
    tertiary = ToyBolaColors.Success,
    background = ToyBolaColors.SoftBlueBackground,
    onBackground = ToyBolaColors.SoftBlueText,
    surface = ToyBolaColors.SoftBlueSurface,
    onSurface = ToyBolaColors.SoftBlueText,
    surfaceVariant = Color(0xFFE8F2F8),
    onSurfaceVariant = Color(0xFF617787),
    outline = ToyBolaColors.SoftBlueBorder,
    outlineVariant = Color(0xFFE4EEF4),
    error = ToyBolaColors.Error,
    errorContainer = Color(0xFFF9E5E4),
    onErrorContainer = Color(0xFF6E2B2A)
)

private val DarkCalmScheme = darkColorScheme(
    primary = ToyBolaColors.DarkPrimary,
    onPrimary = Color(0xFF16262E),
    primaryContainer = Color(0xFF253A44),
    onPrimaryContainer = Color(0xFFDCE9EF),
    secondary = Color(0xFFADC0C9),
    onSecondary = Color(0xFF213038),
    secondaryContainer = Color(0xFF26363E),
    onSecondaryContainer = Color(0xFFDCE5E9),
    tertiary = Color(0xFF8CCFA4),
    background = ToyBolaColors.DarkBackground,
    onBackground = ToyBolaColors.DarkText,
    surface = ToyBolaColors.DarkSurface,
    onSurface = ToyBolaColors.DarkText,
    surfaceVariant = Color(0xFF213039),
    onSurfaceVariant = Color(0xFFB5C2C8),
    outline = ToyBolaColors.DarkBorder,
    outlineVariant = Color(0xFF243038),
    error = Color(0xFFFFB4AB),
    errorContainer = Color(0xFF663735),
    onErrorContainer = Color(0xFFFFDAD6)
)

private val ToyTypography = Typography(
    headlineSmall = androidx.compose.ui.text.TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        lineHeight = 28.sp
    ),
    titleLarge = androidx.compose.ui.text.TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        lineHeight = 24.sp
    ),
    titleMedium = androidx.compose.ui.text.TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    bodyLarge = androidx.compose.ui.text.TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 23.sp
    ),
    bodyMedium = androidx.compose.ui.text.TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    bodySmall = androidx.compose.ui.text.TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 17.sp
    ),
    labelLarge = androidx.compose.ui.text.TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 18.sp
    ),
    labelMedium = androidx.compose.ui.text.TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
)

private val ToyShapes = Shapes(
    extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(10.dp),
    small = androidx.compose.foundation.shape.RoundedCornerShape(10.dp),
    medium = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
    large = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
    extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(20.dp)
)

@Composable
fun ToyBolaTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val normalized = settings.themePreset.normalized(settings.darkMode)
    val systemDark = isSystemInDarkTheme()
    val mode = when (normalized) {
        AppThemePreset.SYSTEM -> ToyBolaVisualMode(AppThemePreset.SYSTEM, systemDark)
        AppThemePreset.DARK_CALM -> ToyBolaVisualMode(AppThemePreset.DARK_CALM, true)
        AppThemePreset.SOFT_BLUE -> ToyBolaVisualMode(AppThemePreset.SOFT_BLUE, false)
        else -> ToyBolaVisualMode(AppThemePreset.LIGHT_CALM, false)
    }
    val colors = when {
        mode.isDark -> DarkCalmScheme
        normalized == AppThemePreset.SOFT_BLUE -> SoftBlueScheme
        else -> LightCalmScheme
    }

    val baseDensity = LocalDensity.current
    val scale = settings.uiScalePercent.coerceIn(90, 110) / 100f
    val view = LocalView.current
    val context = LocalContext.current
    SideEffect {
        context.findActivity()?.window?.let { window ->
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !mode.isDark
                isAppearanceLightNavigationBars = !mode.isDark
            }
        }
    }
    CompositionLocalProvider(
        LocalDensity provides Density(
            density = baseDensity.density * scale,
            fontScale = baseDensity.fontScale * scale
        ),
        LocalToyBolaVisualMode provides mode
    ) {
        MaterialTheme(
            colorScheme = colors,
            typography = ToyTypography,
            shapes = ToyShapes,
            content = content
        )
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
