package uz.toybola.factory.core.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import uz.toybola.factory.core.data.AssemblyData
import uz.toybola.factory.core.data.Brigade
import uz.toybola.factory.core.data.TpBrigade
import uz.toybola.factory.core.data.TpData
import uz.toybola.factory.core.data.TpMachine
import uz.toybola.factory.core.data.TpWorker
import uz.toybola.factory.core.data.Worker
import uz.toybola.factory.ui.model.AppScreen

class AccessControlTest {
    @Test fun everyTpOnlyProfileSkipsAssemblyChannel() {
        AssemblySection.entries.filter { it.name.startsWith("TP_") }.forEach { section ->
            val policy = UserAccessPolicy(userCode = "CUSTOM", role = "CUSTOM",
                sections = mapOf(section to SectionAccess(canRead = true)))
            assertTrue(policy.canReadAnyTp())
            assertFalse(policy.canReadAnyAssembly())
        }
    }
    @Test fun assemblyAndTpChannelsAreIndependent() {
        val policy = UserAccessPolicy(userCode = "CUSTOM", sections = mapOf(
            AssemblySection.BRIGADIR to SectionAccess(canRead = true)))
        assertTrue(policy.canReadAnyAssembly())
        assertFalse(policy.canReadAnyTp())
        assertFalse(UserAccessPolicy.locked().canReadAnyAssembly())
    }

    @Test
    fun assemblyOnlyUserDoesNotRequestTpSnapshot() {
        val policy = UserAccessPolicy(
            userCode = "BRG01",
            role = "BRIGADIR",
            sections = mapOf(AssemblySection.BRIGADIR to SectionAccess(canRead = true, canWrite = true))
        )
        assertFalse(policy.canReadAnyTp())
    }

    @Test
    fun tpRoleRequestsTpSnapshot() {
        val policy = UserAccessPolicy(
            userCode = "TPL01",
            role = "TP_PLAN",
            sections = mapOf(AssemblySection.TP_PLANNING to SectionAccess(canRead = true, canWrite = true))
        )
        assertTrue(policy.canReadAnyTp())
    }

    @Test
    fun adminKeepsTpAccessWhenLegacyPermissionMapHasNoTpKeys() {
        val policy = UserAccessPolicy(userCode = "ADMIN001", role = "ADMIN", sections = emptyMap())
        assertTrue(policy.canReadAnyTp())
    }
    @Test
    fun seryoOnlyUserSeesSeryoButNotTpMain() {
        val policy = UserAccessPolicy(
            userCode = "SERYO01",
            role = "CUSTOM",
            sections = mapOf(AssemblySection.TP_SERYO to SectionAccess(canRead = true, canWrite = true))
        )
        assertTrue(policy.canReadScreen(AppScreen.TP_SERYO))
        assertFalse(policy.canReadScreen(AppScreen.TP_MAIN))
    }

    @Test
    fun tpPlanningUserStillSeesTpMain() {
        val policy = UserAccessPolicy(
            userCode = "TPL01",
            role = "CUSTOM",
            sections = mapOf(AssemblySection.TP_PLANNING to SectionAccess(canRead = true, canWrite = true))
        )
        assertTrue(policy.canReadScreen(AppScreen.TP_MAIN))
    }

    @Test
    fun assemblyScopeFiltersBrigadesAndWorkersWithoutTpMachineData() {
        val policy = UserAccessPolicy(userCode = "BRG01", allowedBrigadeIds = setOf("b1"))
        val scoped = AssemblyData(
            brigades = listOf(Brigade("b1", "B1"), Brigade("b2", "B2")),
            workers = listOf(
                Worker("w1", "b1", "W1", "2026-01-01"),
                Worker("w2", "b2", "W2", "2026-01-01")
            )
        ).scopedFor(policy)

        assertEquals(listOf("b1"), scoped.brigades.map { it.id })
        assertEquals(listOf("w1"), scoped.workers.map { it.id })
    }

    @Test
    fun tpScopeFiltersMachinesByAllowedBrigadeShops() {
        val policy = UserAccessPolicy(userCode = "TPB01", allowedBrigadeIds = setOf("b1"))
        val scoped = TpData(
            brigades = listOf(
                TpBrigade("b1", "s1", "shift", "B1"),
                TpBrigade("b2", "s2", "shift", "B2")
            ),
            machines = listOf(
                TpMachine("m1", "s1", 1),
                TpMachine("m2", "s2", 2)
            ),
            workers = listOf(
                TpWorker("w1", "b1", "W1"),
                TpWorker("w2", "b2", "W2")
            )
        ).scopedFor(policy)

        assertEquals(listOf("b1"), scoped.brigades.map { it.id })
        assertEquals(listOf("m1"), scoped.machines.map { it.id })
        assertEquals(listOf("w1"), scoped.workers.map { it.id })
    }

}
