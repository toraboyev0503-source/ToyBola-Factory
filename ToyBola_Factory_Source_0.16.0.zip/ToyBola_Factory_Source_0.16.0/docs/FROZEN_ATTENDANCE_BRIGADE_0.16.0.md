# ToyBola Factory 0.16.0 — FROZEN Davomat + Brigada boshqaruvi

Tasdiqlangan qarorlar o‘zboshimchalik bilan o‘zgartirilmaydi.

## TP → Davomat

- **DA-001** — `KUN | TUN` ixcham segmented control. `Barchasi` smena filtri yo‘q.
- **DA-002** — Sana yozilmaydi. Default = kechagi sana. Calendar/date picker ishlatiladi; kelajak sana tanlanmaydi; yopilgan kun read-only.
- **DA-003** — 08:50 da 09:00 deadline uchun bildirishnoma. 09:00 dan keyin ochiq davomat `Yopilmagan · muddat o‘tgan`; avtomatik yopilmaydi. Kechikib yopishda sabab majburiy.
- **DA-004** — `Ochiq / Yopilgan / Yopilmagan` holati ixcham va doim ko‘rinadi.
- **DA-005** — `Kunni yopish` tasdiqlash oqimi. Yopilgach read-only. Kim/qachon yopgani va sabab auditda saqlanadi.
- **DA-006** — Davomadchi yopilgan kunni o‘zi qayta ocha oladi. Qayta ochishning o‘zi sabab talab qilmaydi. Qayta ochilgandan keyin xodim davomatini o‘zgartirishda sabab majburiy; qayta yopishda ham sabab majburiy. Audit saqlanadi.
- **DA-007** — Katta Bo‘lim/Brigada/Sana/Smena bloklari o‘rniga ixcham context satri + yuqori o‘ngdagi floating control. Tashqariga tegilganda panel yopiladi.
- **DA-008** — Izoh filtr paneliga qo‘shilmaydi; alohida ixcham action orqali ochiladi.

## Brigada boshqaruvi

- **BR-039** — Birinchi ishchi uchun default vaqt: KUN `07:40`, TUN `19:00`; brigadir o‘zgartira oladi.
- **BR-040** — Keyingi ishchi uchun default = joriy vaqt; brigadir o‘zgartira oladi.
- **BR-041** — Vaqt `HH : MM`; soat va daqiqa alohida, ixcham, teng maydonlar; numeric keyboard; `00–23` / `00–59` validatsiya.
- **BR-042** — Yangi worker assignment vaqtlarida to‘liq sana+vaqt saqlanadi; UI ixcham `HH:mm` ko‘rsatadi. Tungi smena midnight’dan o‘tganda avvalgi smena business date’i saqlanadi. Legacy `HH:mm` yozuvlari backward-compatible o‘qiladi.
- **BR-043** — Ishchi ro‘yxati scroll qiladi, lekin tasdiqlash action’i scroll bilan yo‘qolmaydi; dialogning fixed action/footer qismida turadi.
