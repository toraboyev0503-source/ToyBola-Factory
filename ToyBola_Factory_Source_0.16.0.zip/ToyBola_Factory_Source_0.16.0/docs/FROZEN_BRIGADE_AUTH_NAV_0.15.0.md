# ToyBola 0.15.0 — Frozen Brigade/Auth/Nav decisions

Implemented from the user-approved BR-001–BR-038, AUTH-001–AUTH-008 and NAV-005–NAV-009 decisions.

## Brigada boshqaruvi
- `Stanoklar va smena` renamed to `Brigada boshqaruvi`.
- TP `Davomat` is now a separate TP main destination; the old machine/attendance/extra-hours tabs are removed from Brigade management.
- Brigade-scoped users see only their permitted brigade and its shop machines. A helper uses their own account with the same brigade scope; no temporary-brigadir impersonation flow is added.
- Daily shift choice is `KUN | TUN`; it is stored per brigade/date and changing an already-selected shift requires confirmation.
- Machine cards use two layers: operational essentials first, details/history on expand.
- First layer includes shop/machine, running/stopped state, active worker(s), current/next product/article/detail/color, remaining `jim`, estimated remaining time, plan and material readiness.
- Second layer includes resin type, next order, plan/material readiness, today downtime and worker history.
- Worker assignments support multiple simultaneous workers, brigade workers, `Yonlanma`, and `Boshqa` workers. Start/end times can be entered retroactively.
- Replacing a worker closes current active assignment(s) at the entered time; an explicit “add another worker” option preserves existing workers.
- Downtime reasons: Qolip almashdi, Sozlash, Shnek tiqildi, Remont, Rang almashdi, Boshqa. Stop/start times are manual so delayed entry remains accurate; note is optional.
- Active downtime is visible on the machine card. Closing uses `Ishga tushdi`. Past records are corrected (not deleted) with a mandatory correction reason and audit entry.

## Authentication / lock
- Device/User codes are server-validated only while first linking or intentionally changing a profile.
- Daily unlock uses Android device credentials and cached server policy; server policy refresh runs in background and does not block entry.
- Auto-lock is based on time spent outside the app, not idle time while reading the screen.
- Options: Darhol, 1, 5, 15, 30 minutes.
- Returning before timeout keeps the session open. After timeout, only Android device lock is requested.
- Session timing is persisted so Activity/process recreation does not force a new code check inside the configured window.

## Navigation
- Bottom navigation remains authoritative.
- Android Back closes child/modal handlers first; otherwise it pops exactly one app navigation level.
- Only Home root falls through to Android exit/background behavior.
- Existing retained scroll/navigation state is preserved.
