# ToyBola 0.14.2 frozen polish decisions

Base: successful 0.14.1 build.

## Splash / icon
- P-001: approved launcher icon remains unchanged.
- P-002R: splash uses the icon's inner T mark only; no second outer frame. Outside the T mark is one continuous brand background.
- P-003: splash background uses the same calm blue brand family.
- P-004: compact splash composition: T mark + ToyBola + Factory; no artificial delay.

## Login / daily unlock
- P-005: simplified centered brand block.
- P-006: rebalance logo/title/subtitle/profile/action spacing.
- P-007: device credential prompt opens automatically for configured daily login.
- P-008: manual button remains as fallback/retry.
- P-009: make entry faster while preserving security; do independent non-critical work after auth and parallelize server/device checks.
- P-010: lighter, clearer auth loading state.

## Home polish
- P-011: reduce mockup/artificial feel; improve contrast/depth/visual hierarchy.
- P-012: polish Home header alignment, sizing and spacing.
- P-013: module cards get production-grade border/elevation/icon/badge/disabled treatment.

## TP Rejalash visual consistency
- P-014: Buyurtmalar bo'yicha / Stanoklar bo'yicha selectors get clear framed styling.
- P-015: planning list/detail items use framed cards.
- P-016: TP internal screens share one card/section visual language.
