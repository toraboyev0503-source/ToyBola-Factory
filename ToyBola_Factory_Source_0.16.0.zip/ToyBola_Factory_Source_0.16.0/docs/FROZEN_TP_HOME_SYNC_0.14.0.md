# ToyBola 0.14.0 — Frozen TP / Home / Sync decisions

Base: 0.13.0 (successful build)

This release implements only the decisions approved after 0.13.0 for TP Buyurtma va reja, Rejalash, global Sync, root navigation, and Home cleanup. Sborka/Xonadon next-stage decisions are not included.

## Buyurtmalar — NZ-001..NZ-022
- The section is named **Buyurtmalar**; parent is **Buyurtma va reja**.
- Purpose: create orders and see whether actual molding has started.
- Active list has exactly two visual groups: **Quyish boshlanmagan** above a divider and **Quyish boshlangan** below it.
- An order becomes “Quyish boshlangan” only when the first real machine job gets `startedAt`.
- The card shows the first actual molding start timestamp when available.
- Completed orders leave the active screen automatically and move to **Buyurtmalar tarixi**.
- Completion is based on real receipt progress reaching the required amount, not merely a machine task button.
- History defaults to completed orders; cancelled orders are available by filter. History is read-only.
- History search supports article/product/batch and a date range.
- Batch numbering is per product, keyed by stable product ID. One product never increments another product’s batch.
- The first batch for a product is entered once; following values are suggested automatically from that product’s highest real batch.
- The automatic batch may be manually changed with confirmation; duplicate batch number for the same product is blocked.

## Rejalash — RJ-001..RJ-008
- Existing planning workflow is preserved.
- Equal-level action controls use one consistent outlined/framed visual treatment with selected/unselected/disabled states.
- Machine list shows **Mos zakaz: N** or **Mos zakaz yo‘q**.
- Compatible count includes only active, unfinished, normally-compatible order/detail/color work.
- “Boshqa stanok” exception remains possible but does not count as normal compatibility.
- Tapping the compatible-order indicator opens compatible candidates ordered by priority then creation time.
- Compatibility indicator updates from current repository state.

## Sync — SY-001..SY-008
- Sync stays automatic and event-driven, with WorkManager fallback and manual Sync Center action.
- Network availability is not treated as successful sync.
- User-visible states distinguish Syncing / Pending / Offline / Server unavailable / Attention required / Synced.
- Red error is reserved for repeated real failures, not a first transient failure.
- Automatic retries use backoff; connected WorkManager resumes pending work when network returns.
- Outbox records remain until a successful server sync.

## Root navigation — NAV-001..NAV-004
- Bottom Home / Notifications / Sync / Settings are true root actions.
- Tapping Home from anywhere immediately resets the Home stack to the Home root.
- Other root buttons immediately switch to their root.
- Unsaved forms still block root switching until the user confirms discard.

## Home — HM-001..HM-009
- Remove Bugungi reja / Bajarildi / Bajarilish KPI block.
- Remove So‘nggi faollik.
- Home becomes a clean module launchpad: identity/profile/date/sync + modules + actionable badges + management group.
- Header uses system WindowInsets and adaptive spacing; no large fixed blank top area.
- Layout remains constrained on wide devices and scrollable/adaptive on smaller devices.
