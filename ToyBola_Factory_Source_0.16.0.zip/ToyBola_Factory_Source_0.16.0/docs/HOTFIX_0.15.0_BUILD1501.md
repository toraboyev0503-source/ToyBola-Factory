# ToyBola Factory 0.15.0 — build 1501 hotfix

## Fixed

- `AccessControl.kt` no longer tries to filter a non-existent `machines` field inside `AssemblyData.scopedFor()`.
- TP machine scoping remains in `TpData.scopedFor()`, where machines and brigade `shopId` data actually exist.
- `versionCode` increased from `1500` to `1501`; `versionName` remains `0.15.0` for update compatibility.

## Regression coverage

`AccessControlTest.kt` now verifies:

1. Assembly scope filters brigades/workers by `allowedBrigadeIds` without depending on TP machine data.
2. TP scope keeps only machines belonging to shops of allowed brigades.

## Verification performed in this workspace

- Isolated Kotlin compile of real `AppModels.kt`, `AssemblyModels.kt`, `TpModels.kt`, supporting TP data files, and patched `AccessControl.kt`: PASS.
- Isolated compile of `AccessControlTest.kt` with temporary JUnit API stubs: PASS.
- Scope smoke test: PASS (`SCOPE_SMOKE_OK`).
- `functions/npm run check`: PASS, 21/21 tests.

## Environment limitation

The current workspace does not contain the Android SDK or Gradle 9.5.0 distribution, and external binary download is unavailable here. Therefore full Android `./gradlew test`, `./gradlew lint`, and `./gradlew assembleDebug` must be run by the included GitHub Actions workflow. The workflow already performs those three checks in that order.
