# ToyBola Factory 0.12.3 — AuthScreen Kotlin compile fix

GitHub Actions 0.12.2 buildi KSP bosqichidan muvaffaqiyatli o‘tib, `:app:compileDebugKotlin` bosqichida `AuthScreens.kt` faylida to‘xtadi.

Aniq xatolar:
- `TextButton` unresolved reference;
- `Modifier.align(...)` unresolved reference;
- natijaviy `@Composable invocations can only happen...` xatosi.

Tuzatish:
- `androidx.compose.material3.TextButton` import qilindi;
- `AuthContainer(..., content)` parametri `@Composable ColumnScope.() -> Unit` ko‘rinishiga o‘tkazildi;
- ichki `Column` content receiver’ni to‘g‘ridan-to‘g‘ri ishlatadi.

Bu patch funksional Product/UX qarorlarini o‘zgartirmaydi. KSP/Room konfiguratsiyasi 0.12.2 dagidek qoladi.

Versiya: 0.12.3 / versionCode 1203.
