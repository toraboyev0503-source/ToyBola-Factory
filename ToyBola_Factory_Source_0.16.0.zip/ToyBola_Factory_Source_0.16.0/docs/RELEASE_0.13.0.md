# ToyBola Factory 0.13.0 — Design System + approved Home themes

Base: **0.12.3-buildfix** (known successful GitHub build).

## Scope
This release implements the frozen visual/design pass D-001…D-064 and the exact visual approvals V-001…V-005. Functional architecture decisions 1–64 remain intact. Sborka/Xonadon decisions 65+ are intentionally not implemented in this release.

## Approved visual assets
- Launcher icon: exact user-approved image, preserved under `docs/design-references/launcher-icon-approved.png` and used to generate launcher densities/adaptive assets.
- Splash: single approved splash under `docs/design-references/splash-approved.png`; no artificial startup delay.
- Home Light Calm: reference stored under `docs/design-references/home-light-approved.png`.
- Home Dark Calm: reference stored under `docs/design-references/home-dark-approved.png`.
- Home Soft Blue: reference stored under `docs/design-references/home-soft-blue-approved.png`.

## Main implementation
- New theme selector: System / Light Calm / Soft Blue / Dark Calm.
- Theme changes apply live and persist.
- Legacy BRAND/CALM/NEUTRAL preference/backup values remain readable and migrate safely.
- Light Calm, Soft Blue, and Dark Calm palettes, typography, radii, borders, compact elevations and UI scale rules centralized in `ToyBolaTheme`.
- Home rebuilt around the approved dashboard composition while using real app data for KPIs, badges and recent activity.
- Module cards use neutral surfaces with restrained module accents.
- Bottom navigation, top bars, reusable section cards, auth surfaces and visible TP surfaces aligned to the new calm design system.
- Android 13+ monochrome launcher icon added.
- Package name, server sync, Room, permissions, backup/recovery, notifications, frozen TP/Seryo behavior and signing key are preserved.

## Version
- `versionCode = 1300`
- `versionName = 0.13.0`
- applicationId: `uz.toybola.factory`

## Verification note
The source was statically validated in the preparation environment and server tests passed. A full Android Gradle `test`, `lint`, and `assembleDebug` must still be run by the included GitHub Actions workflow; the preparation environment does not have the project Android/Gradle dependency graph available for a truthful full local build claim.
