# ToyBola Factory 0.14.0

Base: successful 0.13.0.

## Implemented
- NZ-001..NZ-022 — Buyurtmalar lifecycle, history, product-specific batch numbering.
- RJ-001..RJ-008 — framed planning controls and machine compatible-order indicator.
- SY-001..SY-008 — automatic sync status/retry refinement.
- NAV-001..NAV-004 — authoritative bottom-root navigation.
- HM-001..HM-009 — simplified adaptive Home launchpad.

## Preserved
- applicationId `uz.toybola.factory`
- existing debug signing keystore
- Room data / migration / backup-recovery compatibility
- TP/Seryo and earlier frozen functional decisions not superseded above
- 0.13.0 visual themes/icon/splash

Sborka/Xonadon next-stage functional decisions are not included in this release.
