# ToyBola Factory 0.14.1

Compile hotfix over 0.14.0.

## Fix
`TpData.refreshOrderStatus()` now resolves the order as non-null before reading `completedAt` / `planApprovedAt`. If the referenced order does not exist, the function returns the current data unchanged.

This fixes the GitHub Actions error:
`Only safe (?.) or non-null asserted (!!.) calls are allowed on a nullable receiver of type 'TpOrder?'.`

## Compatibility
- versionCode: 1401
- versionName: 0.14.1
- package/applicationId unchanged
- signing material unchanged
- 0.14.0 functional decisions unchanged
