# ToyBola Factory 0.15.0

Major TP brigadir workflow update.

- Brigada boshqaruvi replaces the old Stanoklar va smena tabbed screen.
- Daily KUN/TUN selection, machine worker assignment history, multi-worker support and structured downtime tracking.
- Two-layer machine cards with remaining jim/time, material readiness and next-order context.
- Davomat moved to its own TP destination; extra-hours removed from the brigadir surface.
- Daily authentication no longer waits for Device/User code server validation; local Android lock is used after initial profile link, with background policy refresh.
- Auto-lock timeout now follows app background duration and supports Darhol/1/5/15/30 minutes.
- Global Back fallback fixed so nested screens pop one level instead of closing the app.
- New TP sync records: brigadeShiftSelections and machineWorkerAssignments.

Version: 0.15.0 (versionCode 1500)
