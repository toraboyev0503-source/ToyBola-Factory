# ToyBola Factory 0.16.0

## Asosiy o‘zgarishlar

### TP Davomat
- KUN/TUN smena tanlovi va default kechagi sana.
- Future-disabled Android date picker.
- Compact context panel: bo‘lim, brigada, sana, smena.
- Alohida izoh action’i.
- Sana+smena bo‘yicha close/reopen state va audit.
- 09:00 dan keyingi yopishda sabab majburiy.
- Qayta ochilgan davomatda worker o‘zgarishi va qayta yopish uchun sabab majburiy.
- 08:50 notification deep-link bilan Davomatga olib kiradi.
- Yopilgan davomat read-only.

### Brigada boshqaruvi
- Birinchi worker default: KUN 07:40 / TUN 19:00.
- Keyingi worker default: amaldagi vaqt.
- Compact numeric HH:MM editor.
- Worker assignment vaqtlarini full local date-time ko‘rinishida saqlash.
- Midnight’dan keyingi TUN smenasi avvalgi business date ostida davom etadi.
- Legacy HH:mm assignment yozuvlari backward-compatible.
- Ishchi tanlash confirmation fixed dialog action’ga ko‘chirildi.

### Sync/server
- Yangi `attendanceDays` root va `tpAttendanceDays` collection.
- Outbox/baseline/merge/access-guard qo‘llab-quvvatlaydi.
- Server apply/snapshot/delete oqimlari qo‘llab-quvvatlaydi.
