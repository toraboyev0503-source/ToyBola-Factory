# ToyBola Design Decision Log

Base version: ToyBola 0.12.3 buildfix
Purpose: Record all newly approved visual/design decisions after 0.12.3, to be implemented later in code.

## Process
- Assistant proposes grouped design decisions.
- User approves/rejects.
- Approved decisions are frozen and appended here.
- Implementation happens later based on this log.

## Current focus
1. App icon
2. Splash / opening image
3. App visual themes and general UI language

## Frozen decisions
- D-001 — ACCEPTED/FROZEN: Overall visual direction is simple, calm, broadly suitable, low-fatigue, modern, and appropriate for a production/factory management app. Avoid flashy, childish, overly decorative, or game-like visuals.
- D-003 — ACCEPTED/FROZEN: Use one single splash screen only. Keep it clean and brand-led; no multi-stage opening sequence.
- D-004 — ACCEPTED/FROZEN: Keep the theme system restrained and calm, centered on Light Calm, Soft Blue, and Dark Calm style families rather than many decorative themes.

## Pending clarification
- D-002 — NOT FROZEN YET: User replied “2” to the icon-direction item. Need to clarify whether this means reject or choose a second icon direction.

## Frozen decisions — Design pass

- D-001 = ACCEPTED — Overall visual direction: simple, calm, universal, low-fatigue, modern industrial management app.
- D-002 = SUPERSEDED — Original icon proposal was not frozen; replaced by D-006–D-008.
- D-003 = ACCEPTED — One splash screen only.
- D-004 = ACCEPTED — Theme family: Light Calm, Soft Blue, Dark Calm.
- D-005 = ACCEPTED — Primary brand color: muted deep blue.
- D-006 = ACCEPTED — App icon: no text; simple T + industrial/geometric symbol.
- D-007 = ACCEPTED — Minimal icon detail; no crowded factory/gear/person imagery.
- D-008 = ACCEPTED — Full adaptive icon set: foreground, background, monochrome.
- D-009 = ACCEPTED — Single clean splash with logo/wordmark and optional small ToyBola Factory label.
- D-010 = ACCEPTED — Splash motion limited to subtle 200–350 ms fade.
- D-011 = ACCEPTED — Light theme uses off-white background, white cards.
- D-012 = ACCEPTED — Dark theme uses dark blue-gray, not pure black.
- D-013 = ACCEPTED — One primary + neutral family; semantic green/yellow/red only for status/warnings.
- D-014 = ACCEPTED — Module colors used only as small accents, not full-screen themes.
- D-015 = ACCEPTED — Cards: 12–16dp radius, minimal shadow, subtle border/background separation.
- D-016 = ACCEPTED — Buttons: solid primary / tonal or outline secondary; no gradients/3D.
- D-017 = ACCEPTED — Typography: Android system/Roboto family, no decorative font.
- D-018 = ACCEPTED — Limit typography to 4–5 standard levels.
- D-019 = ACCEPTED — One consistent rounded Material icon family.
- D-020 = ACCEPTED — Compact top bar; no persistent oversized logo/title.
- D-021 = ACCEPTED — 4-root bottom navigation with subtle selected tonal state.
- D-022 = ACCEPTED — Motion limited to fade, crossfade, short slide; no large scale/jump effects.
- D-023 = ACCEPTED — Unified input/form field size, radius, label and spacing system.
- D-024 = ACCEPTED — Unified status chip component.
- D-025 = ACCEPTED — Dialog for small confirmations; sheet/full-screen for longer choice/form flows.
- D-026 = ACCEPTED — Standard density compact but not cramped; minimum 48dp touch targets.


## Frozen decisions — Final design system pass

- D-027 = ACCEPTED — Light Calm palette: Background #F5F7F8, Surface #FFFFFF, Primary #3F6173, Primary soft #DCE8ED, Text #1D2529, Border #D9E0E4.
- D-028 = ACCEPTED — Dark Calm palette: Background #11181C, Surface #182126, Primary #9FBBC8, Text #E7ECEF, Border #2B373D.
- D-029 = ACCEPTED — Soft Blue remains a restrained Light-theme alternative with a slightly blue-tinted background and near-white surfaces.
- D-030 = ACCEPTED — Wordmark: “ToyBola” with smaller “Factory”; no extra slogan.
- D-031 = ACCEPTED — Splash uses one deep-blue brand background with centered white mark/wordmark.
- D-032 = ACCEPTED — No decorative background images, textures, patterns, or gradients in normal app screens.
- D-033 = ACCEPTED — Home module cards stay neutral; module color appears only as a small accent/icon/badge.
- D-034 = ACCEPTED — Selected states use subtle tonal background plus primary icon/text, not large saturated blocks.
- D-035 = ACCEPTED — Focused input changes border/label to primary only; no glow/shadow effects.
- D-036 = ACCEPTED — Destructive actions use semantic red; red is not used as ordinary decoration.
- D-037 = ACCEPTED — Badges are compact; show count or small status dot/icon only.
- D-038 = ACCEPTED — Numeric production data use tabular numerals and right alignment where appropriate.
- D-039 = ACCEPTED — Long lists/tables use mobile-first compact rows, subtle dividers, stronger key values, muted metadata.
- D-040 = ACCEPTED — Empty states use a small icon + short sentence + optional one action; no large illustration.
- D-041 = ACCEPTED — Prefer skeleton/small progress over blocking full-screen spinners where possible.
- D-042 = ACCEPTED — User-facing errors are concise and actionable; technical details stay in logs/audit.
- D-043 = ACCEPTED — Routine success feedback uses snackbar rather than modal dialogs.
- D-044 = ACCEPTED — Monitoring charts use restrained palette: one primary + optional comparison color; semantic warning colors only when meaningful.
- D-045 = ACCEPTED — Core spacing grid: 4/8/12/16/24/32dp.
- D-046 = ACCEPTED — Accessibility: status is never color-only; combine color with icon/text and verify contrast in light/dark.
- D-047 = ACCEPTED — Default theme = System; user can select Light Calm / Soft Blue / Dark Calm / System.
- D-048 = ACCEPTED — Theme changes apply immediately without app restart and persist.
- D-049 = ACCEPTED — Launcher icon background uses brand primary #3F6173.
- D-050 = ACCEPTED/FROZEN — Icon mark option 1: a simple white geometric “T” symbol, with only a subtle industrial/geometric-block character. No separate gear, factory, machine, or other pictogram. The mark stays flat, minimal, and clearly readable at small sizes.
- D-051 = ACCEPTED — Icon mark occupies about 55–60% of icon area with generous safe-space for adaptive masks.
- D-052 = ACCEPTED — No inner rounded-square/circle container; one background + one foreground mark.
- D-053 = ACCEPTED — Android 13+ monochrome themed icon uses the same core mark.
- D-054 = ACCEPTED — Splash composition: #3F6173 background, centered white ToyBola mark, “ToyBola” + smaller “Factory”, nothing else.
- D-055 = ACCEPTED — No artificial splash delay; proceed as soon as app is ready.
- D-056 = ACCEPTED — Main font weights: 400 / 500 / 600; 700+ used rarely or not at all.
- D-057 = ACCEPTED — Typography scale: 22sp screen title, 18sp section title, 16sp important/button, 14sp body, 12sp metadata.
- D-058 = ACCEPTED — Radius system: card 16dp, button/input 12dp, small component 10dp, chip pill.
- D-059 = ACCEPTED — Elevation is minimal: cards 0–1dp, floating elements max 2–3dp.
- D-060 = ACCEPTED — Large ToyBola branding is limited to icon, splash, login/setup, and optionally compact Home identity; not repeated on internal screens.
- D-061 = ACCEPTED — Module accents stay soft and separate from semantic status colors.
- D-062 = ACCEPTED — Compact / Standard / Large UI scale remains; default Standard; spacing and component sizes scale along with text.
- D-063 = ACCEPTED — Wide-screen/tablet layouts use max content width and selective two-column layouts; phone portrait remains the primary reference.
- D-064 = ACCEPTED — Design-system decision phase closes after icon-mark clarification and final visual approval of launcher icon, splash, Home Light, Home Dark, and optional Soft Blue.

## Frozen visual approvals — implementation references

- V-001 = ACCEPTED/FROZEN — Launcher icon uses the exact user-provided approved image saved as `docs/design-references/launcher-icon-approved.png`. This visual approval supersedes any earlier icon-shape assumptions that conflict with the approved image.
- V-002 = ACCEPTED/FROZEN — Splash uses the approved single-screen visual saved as `docs/design-references/splash-approved.png`. Keep a single splash only and do not add an artificial wait.
- V-003 = ACCEPTED/FROZEN — Home — Light Calm must match the approved reference `docs/design-references/home-light-approved.png` as closely as practical in Android/Compose while keeping live app data and frozen functional behavior.
- V-004 = ACCEPTED/FROZEN — Home — Dark Calm must match `docs/design-references/home-dark-approved.png` as closely as practical in Android/Compose while keeping live app data and frozen functional behavior.
- V-005 = ACCEPTED/FROZEN — Soft Blue must match `docs/design-references/home-soft-blue-approved.png` as closely as practical in Android/Compose while keeping live app data and frozen functional behavior.

Implementation baseline: ToyBola Factory 0.12.3-buildfix. Target design implementation version: 0.13.0 / versionCode 1300.
