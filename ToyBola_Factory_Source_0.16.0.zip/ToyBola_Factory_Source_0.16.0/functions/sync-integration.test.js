"use strict";
const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const vm = require("node:vm");

function harness() {
 const rows = new Map();
 const stamp = { __stamp: true };
 const copy = value => value == null ? value : JSON.parse(JSON.stringify(value));
 function resolve(value, old) {
   if (value && value.__increment != null) return Number(old || 0) + value.__increment;
   if (value && value.__stamp) return { seconds: 1, nanoseconds: 1 };
   if (Array.isArray(value)) return copy(value);
   if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).map(([k,v]) => [k, resolve(v, old && old[k])]));
   return value;
 }
 const apply = (ref, data, options) => rows.set(ref.path, options?.merge ? {...rows.get(ref.path), ...resolve(data, rows.get(ref.path))} : resolve(data, rows.get(ref.path)));
 const snapshot = ref => ({
   id: ref.id, ref, exists: rows.has(ref.path),
   data: () => copy(rows.get(ref.path)), get: key => copy(rows.get(ref.path)?.[key])
 });
 function doc(path) {
   return { path, id: path.split("/").at(-1),
     get: async () => snapshot(doc(path)),
     set: async (data, options) => apply(doc(path), data, options),
     delete: async () => rows.delete(path),
     collection: name => collection(path + "/" + name)
   };
 }
 function collection(path, filters = [], limit = Infinity) {
   return {
     doc: id => doc(path + "/" + id),
     where: (field, op, value) => collection(path, [...filters, [field,op,value]], limit),
     limit: size => collection(path, filters, size),
     get: async () => {
       const docs = [...rows.keys()].filter(key => key.startsWith(path + "/") && key.slice(path.length+1).indexOf("/") < 0)
         .map(doc).map(snapshot).filter(snap => filters.every(([field,op,value]) => op === "in" ? value.includes(snap.get(field)) : snap.get(field) === value)).slice(0, limit);
       return { docs, empty: docs.length === 0, size: docs.length };
     },
     add: async data => { const ref = doc(path + "/" + (rows.size+1)); apply(ref, data); return ref; }
   };
 }
 function batch() {
   const writes=[];
   const api={ set:(ref,data,options)=>{writes.push(()=>apply(ref,data,options));return api;},
     create:(ref,data)=>{writes.push(()=>{assert.equal(rows.has(ref.path),false);apply(ref,data);});return api;},
     delete:ref=>{writes.push(()=>rows.delete(ref.path));return api;},
     commit:async()=>writes.forEach(write=>write()) };
   return api;
 }
 const db={collection, batch, runTransaction:async action=>{
   const writes=batch(); let started=false;
   const tx={get:async ref=>{assert.equal(started,false,"transaction reads precede writes");return snapshot(ref);},
     getAll:async(...refs)=>{assert.equal(started,false);return refs.map(snapshot);},
     set:(...args)=>{started=true;writes.set(...args);},
     delete:(...args)=>{started=true;writes.delete(...args);}
   };
   const result=await action(tx); await writes.commit(); return result;
 }};
 class HttpsError extends Error { constructor(code,message,details){super(message);this.code=code;this.details=details;} }
 const register=(...args)=>args.at(-1);
 const auth={setCustomUserClaims:async()=>{},createUser:async()=>{},updateUser:async()=>{},deleteUser:async()=>{},revokeRefreshTokens:async()=>{}};
 const modules={
   "firebase-functions/v2":{setGlobalOptions:()=>{}},
   "firebase-functions/v2/https":{onCall:register,HttpsError},
   "firebase-functions/v2/scheduler":{onSchedule:register},
   "firebase-functions/v2/firestore":{onDocumentWritten:register},
   "firebase-admin/app":{initializeApp:()=>{}},
   "firebase-admin/auth":{getAuth:()=>auth},
   "firebase-admin/firestore":{getFirestore:()=>db,FieldValue:{serverTimestamp:()=>stamp,increment:n=>({__increment:n})}},
   "firebase-admin/messaging":{getMessaging:()=>({sendEachForMulticast:async()=>({responses:[]})})}
 };
 const exports={};
 vm.runInNewContext(fs.readFileSync(__dirname+"/index.js","utf8"),{exports,require:name=>modules[name] || require(name),Buffer,console}, {filename:"index.js"});
 const put=(path,data)=>rows.set(path,copy(data));
 const user=(permissions,allBrigades=true,allowedBrigadeIds=[])=>put("users/u",{enabled:true,role:"CUSTOM",userCode:"USR-1",allBrigades,allowedBrigadeIds,permissions});
 const call=(name,data={})=>exports[name]({auth:{uid:"u",token:{}},data});
 return {rows,put,user,call};
}
function job(overrides={}) {
 return {id:"j",orderId:"o",moldCode:"m",colorCode:"001",machineId:"one",brigadeId:"b",status:"ASSIGNED",
 resinCode:"001",requiredResinKg:257.3,requiredColorGrams:2058.4,resinConfirmedAt:null,materialStatus:"PLANNED",...overrides};
}
const record=(key,item)=>({payload:JSON.stringify({[key]:[item]}),brigadeId:item.brigadeId||""});
const args=(keys,payload,base={})=>({keys,payload:JSON.stringify(payload),baseItems:JSON.stringify(base),syncEpoch:0});
test("TP-only login can bootstrap without Sborka permissions",async()=>{
 const h=harness();h.user({TP_SERYO_READ:true});
 h.put("tpJobs/j",record("jobs",job()));h.put("tpOrders/o",record("orders",{id:"o"}));
 const result=await h.call("getTpSnapshot");
 assert.equal(JSON.parse(result.payload).jobs.length,1);
 await assert.rejects(h.call("getAssemblySnapshot"),e=>e.code==="permission-denied");
});
test("transaction keeps another device's new plan field",async()=>{
 const h=harness();h.user({TP_SERYO_READ:true,TP_SERYO_WRITE:true});
 const base=job();h.put("tpJobs/j",record("jobs",job({machineId:"two"})));
 await h.call("applyTpWrites",args(["TP_JOB:j"],{jobs:[job({resinConfirmedAt:"now"})]},{"TP_JOB:j":base}));
 const result=JSON.parse(h.rows.get("tpJobs/j").payload).jobs[0];
 assert.equal(result.machineId,"two");assert.equal(result.resinConfirmedAt,"now");
 assert.equal(h.rows.get("tpJobs/j").machineId,"two");
});
test("read-only account cannot write",async()=>{
 const h=harness();h.user({TP_SERYO_READ:true});
 await assert.rejects(h.call("applyTpWrites",args(["TP_JOB:j"],{jobs:[job()]})),e=>e.code==="permission-denied");
 assert.equal(h.rows.has("tpJobs/j"),false);
});
test("Seryo permission cannot change planning fields",async()=>{
 const h=harness();h.user({TP_SERYO_WRITE:true});const base=job();h.put("tpJobs/j",record("jobs",base));
 await assert.rejects(h.call("applyTpWrites",args(["TP_JOB:j"],{jobs:[job({machineId:"hijack"})]},{"TP_JOB:j":base})),e=>e.code==="failed-precondition");
 assert.equal(JSON.parse(h.rows.get("tpJobs/j").payload).jobs[0].machineId,"one");
});
test("same-field conflict rejects the whole related batch",async()=>{
 const h=harness();h.user({TP_SERYO_WRITE:true});
 const base=job();h.put("tpJobs/j",record("jobs",job({resinCode:"003"})));
 const material={id:"mat",code:"001",type:"RESIN",availableAmount:0,movements:[]};
 const result=await h.call("applyTpWrites",args(["TP_JOB:j","TP_MATERIAL:mat"],{jobs:[job({resinCode:"002"})],materials:[material]},{"TP_JOB:j":base,"TP_MATERIAL:mat":null}));
 assert.equal(result.rejected.length,2);assert.equal(h.rows.has("tpMaterials/mat"),false);
 assert.equal(JSON.parse(h.rows.get("tpJobs/j").payload).jobs[0].resinCode,"003");
});
test("authoritative order tombstone blocks a stale NEW child id",async()=>{
 const h=harness();h.user({TP_PLANNING_WRITE:true});
 const hash=require("crypto").createHash("sha256").update("tpOrders/o").digest("hex");
 h.put("syncTombstones/"+hash,{channel:"tp",targetKey:"TP_ORDER:o"});
 const result=await h.call("applyTpWrites",args(["TP_JOB:j"],{jobs:[job()]},{"TP_JOB:j":null}));
 assert.equal(result.discarded.length,1);assert.equal(h.rows.has("tpJobs/j"),false);
});
test("reset epoch rejects objects that never reached the server",async()=>{
 const h=harness();h.user({TP_ORDER_WRITE:true});h.put("syncState/tp",{epoch:2});
 await assert.rejects(h.call("applyTpWrites",args(["TP_ORDER:o"],{orders:[{id:"o"}]},{"TP_ORDER:o":null})),e=>e.code==="unavailable");
 assert.equal(h.rows.has("tpOrders/o"),false);
});
test("actual existing brigade scope cannot be bypassed in the submitted payload",async()=>{
 const h=harness();h.user({TP_PLANNING_WRITE:true},false,["allowed"]);
 h.put("tpJobs/j",record("jobs",job({brigadeId:"forbidden"})));
 await assert.rejects(h.call("applyTpWrites",args(["TP_JOB:j"],{jobs:[job({brigadeId:"allowed"})]},{"TP_JOB:j":job()})),e=>e.code==="permission-denied");
});
test("user creation without a role uses only explicit department permissions",async()=>{
 const h=harness();h.put("users/u",{enabled:true,role:"ADMIN",allBrigades:true,permissions:{}});
 const result=await h.call("adminCreateUser",{displayName:"Seryo operator",allBrigades:true,permissions:{HOME_MOLDING:true,TP_SERYO_READ:true}});
 assert.equal(result.user.role,"CUSTOM");assert.match(result.credentials.userCode,/^USR-/);
 assert.equal(result.user.permissions.TP_SERYO_READ,true);assert.equal(result.user.permissions.TP_SERYO_WRITE,false);
 assert.equal(result.user.permissions.BRIGADIR_READ,false);
});
test("bulk reset creates tombstones atomically for master-data too",async()=>{
 const h=harness();h.put("users/u",{enabled:true,role:"ADMIN",allBrigades:true,permissions:{}});
 h.put("tpMaterials/m",record("materials",{id:"m",code:"001",availableAmount:0,movements:[]}));
 await h.call("adminResetTpData");
 assert.equal(h.rows.has("tpMaterials/m"),false);
 assert.ok([...h.rows.values()].some(row=>row.targetKey==="TP_MATERIAL:m"));
 assert.equal(h.rows.get("syncState/tp").epoch,1);assert.equal(h.rows.get("syncState/tp").resetting,false);
});
test("Sborka brigadir cannot overwrite the quality close with a stale local day",async()=>{
 const h=harness(); h.user({BRIGADIR_WRITE:true});
 h.put("brigadeDays/b_2026-09-05",{brigadeId:"b",date:"2026-09-05",qualityClosed:true,qualityClosedAt:"2026-09-05T18:00",qualityLateReason:"saved"});
 await h.call("applyAssemblyWrites",{keys:["BRIGADE_DAY:b|2026-09-05"],payload:JSON.stringify({brigadeDays:[{brigadeId:"b",date:"2026-09-05",brigadirClosedAt:"2026-09-05T18:01",qualityClosedAt:null}]})});
 const day=h.rows.get("brigadeDays/b_2026-09-05");
 assert.equal(day.qualityClosedAt,"2026-09-05T18:00");assert.equal(day.qualityLateReason,"saved");assert.equal(day.fullyClosed,true);
});
test("Sborka deleted daily issue stays deleted inside the write transaction",async()=>{
 const h=harness();h.user({DAILY_ISSUE_WRITE:true});
 const hash=require("crypto").createHash("sha256").update("dailyIssues/i").digest("hex");
 h.put("syncTombstones/"+hash,{channel:"assembly",targetKey:"DAILY_ISSUE:i"});
 await h.call("applyAssemblyWrites",{keys:["DAILY_ISSUE:i"],payload:JSON.stringify({dailyIssues:[{id:"i",brigadeId:"b",date:"2026-09-05"}]})});
 assert.equal(h.rows.has("dailyIssues/i"),false);
});
test("delete wins over an upsert in the same TP request, regardless of order",async()=>{
 const h=harness();h.user({TP_ORDER_WRITE:true});
 h.put("tpOrders/o",record("orders",{id:"o",quantity:1}));
 await h.call("applyTpWrites",args(["TP_ORDER_DELETE:o","TP_ORDER:o"],{orders:[{id:"o",quantity:2}]},{"TP_ORDER:o":{id:"o",quantity:1}}));
 assert.equal(h.rows.has("tpOrders/o"),false);
});
test("delete wins over an upsert in the same Sborka request",async()=>{
 const h=harness();h.user({DAILY_ISSUE_WRITE:true});
 h.put("dailyIssues/i",record("dailyIssues",{id:"i",brigadeId:"b"}));
 await h.call("applyAssemblyWrites",{keys:["DAILY_ISSUE_DELETE:i","DAILY_ISSUE:i"],payload:JSON.stringify({dailyIssues:[{id:"i",brigadeId:"b",note:"stale"}]})});
 assert.equal(h.rows.has("dailyIssues/i"),false);
});
test("attendance day close state syncs independently from worker rows",async()=>{
 const h=harness();h.user({TP_ATTENDANCE_READ:true,TP_ATTENDANCE_WRITE:true});
 const item={id:"2026-09-23_tp-shift-day",date:"2026-09-23",shiftId:"tp-shift-day",closedAt:"2026-09-24T08:55:00",closedBy:"Davomadchi",closeReason:"",reopenedAt:null,reopenedBy:"",reopenCount:0,note:"",updatedAt:"2026-09-24T08:55:00"};
 const result=await h.call("applyTpWrites",args(["TP_ATTENDANCE_DAY:"+item.id],{attendanceDays:[item]},{["TP_ATTENDANCE_DAY:"+item.id]:null}));
 assert.equal(result.applied.length,1);
 assert.equal(h.rows.get("tpAttendanceDays/"+item.id).shiftId,"tp-shift-day");
 const snapshot=JSON.parse((await h.call("getTpSnapshot")).payload);
 assert.equal(snapshot.attendanceDays.length,1);assert.equal(snapshot.attendanceDays[0].closedBy,"Davomadchi");
});
