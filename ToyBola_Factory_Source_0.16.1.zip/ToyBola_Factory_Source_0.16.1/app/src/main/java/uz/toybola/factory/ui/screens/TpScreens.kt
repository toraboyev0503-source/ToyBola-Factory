package uz.toybola.factory.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.components.SectionCard
import uz.toybola.factory.ui.model.AppScreen
import uz.toybola.factory.ui.model.AppStrings
import uz.toybola.factory.ui.navigation.TpNavigationTargetState
import java.time.LocalDate

private data class TpMainItem(
    val title: String,
    val description: String,
    val screen: AppScreen,
    val badge: Int = 0,
    val accent: Color,
    val icon: ImageVector
)

@Composable
fun TpMainScreen(
    strings: AppStrings,
    onBack: () -> Unit,
    canOpen: (AppScreen) -> Boolean,
    onOpen: (AppScreen) -> Unit
) {
    val context = LocalContext.current
    val revision by TpDataEvents.revision.collectAsState()
    val policy = remember(revision) { AccessGuard(context).currentPolicy() }
    val data = remember(revision, policy.revision) { TpDataRepository(context).load().scopedFor(policy) }
    val plannerPendingBadge = if (policy.isAdmin() || policy.canRead(AssemblySection.TP_PLANNING)) {
        data.orders.count { order ->
            order.status !in setOf(TpOrderStatus.COMPLETE, TpOrderStatus.CANCELLED) &&
                data.jobs.filter { it.orderId == order.id }.let { jobs -> jobs.isEmpty() || jobs.any { it.planConfirmedAt == null } }
        }
    } else 0
    val machinePendingBadge = if (policy.isAdmin() || policy.canRead(AssemblySection.TP_MACHINE)) {
        data.jobs.filter { it.planConfirmedAt != null && it.materialStatus == TpMaterialStatus.DELIVERED && it.status == TpJobStatus.QUEUED }
            .groupBy { "${it.orderId}|${it.moldCode}|${it.machineId}" }.size
    } else 0
    val operational = listOf(
        TpMainItem("Buyurtma va reja", "Buyurtmalar va rejalash", AppScreen.TP_PLAN, plannerPendingBadge, Color(0xFF2F8FE5), Icons.Rounded.Assignment),
        TpMainItem("Brigada boshqaruvi", "Stanoklar, ishchilar va smena", AppScreen.TP_SHIFT, machinePendingBadge, Color(0xFF7657E8), Icons.Rounded.PrecisionManufacturing),
        TpMainItem("Davomat", "Ish vaqti va davomat", AppScreen.TP_ATTENDANCE, accent = Color(0xFF5C7C8A), icon = Icons.Rounded.HowToReg),
        TpMainItem("Qabul", "Detal qabuli", AppScreen.TP_RECEIVING, accent = Color(0xFF12A982), icon = Icons.Rounded.Inventory2),
        TpMainItem("Sifat", "Baholash va kun muammosi", AppScreen.TP_QUALITY, accent = Color(0xFFED7A2E), icon = Icons.Rounded.VerifiedUser),
        TpMainItem("Monitoring", "Read-only natijalar va KPI", AppScreen.TP_MONITORING, accent = Color(0xFF7C65D8), icon = Icons.Rounded.BarChart)
    ).filter { canOpen(it.screen) }

    Column(Modifier.fillMaxSize()) {
        AppTopBar("TP", canGoBack = true, onMenu = {}, onBack = onBack, subtitle = "Zakaz, reja, brigada, qabul va sifat")
        Column(
            Modifier.fillMaxSize()
                .verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-main"))
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            operational.chunked(2).forEachIndexed { rowIndex, row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEachIndexed { index, item ->
                        SectionCard(
                            number = rowIndex * 2 + index + 1,
                            title = item.title,
                            description = item.description,
                            enabled = true,
                            visuallyActive = true,
                            badgeCount = item.badge,
                            modifier = if (row.size == 1) Modifier.fillMaxWidth() else Modifier.weight(1f),
                            accentColor = item.accent,
                            icon = item.icon,
                            onClick = { onOpen(item.screen) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
            if (canOpen(AppScreen.TP_MASTER_DATA)) {
                Spacer(Modifier.height(6.dp))
                Text("Boshqaruv", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(10.dp))
                SectionCard(
                    number = 7,
                    title = "Ma’lumotlar",
                    description = "TP master-data markazi",
                    enabled = true,
                    visuallyActive = true,
                    modifier = Modifier.fillMaxWidth(),
                    accentColor = Color(0xFF718394),
                    icon = Icons.Rounded.Storage,
                    onClick = { onOpen(AppScreen.TP_MASTER_DATA) }
                )
            }
        }
    }
}

private enum class TpPlanPage { ROOT, ORDERS, PLANNING, HISTORY }

@Composable
fun TpPlanScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val eventRevision by TpDataEvents.revision.collectAsState()
    var localRevision by remember { mutableIntStateOf(0) }
    val policy = remember(eventRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(eventRevision, localRevision, policy.revision) { repository.load().scopedFor(policy) }
    val available = buildList {
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_ORDER)) {
            add(TpPlanPage.ORDERS)
            add(TpPlanPage.HISTORY)
        }
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_PLANNING)) add(TpPlanPage.PLANNING)
    }
    var page by remember { mutableStateOf(if (available.size == 1) available.first() else TpPlanPage.ROOT) }
    fun refresh() { localRevision++ }
    fun back() { if (page == TpPlanPage.ROOT || available.size == 1) onBack() else page = TpPlanPage.ROOT }
    BackHandler { back() }

    val title = when (page) {
        TpPlanPage.ROOT -> "Buyurtma va reja"
        TpPlanPage.ORDERS -> "Buyurtmalar"
        TpPlanPage.PLANNING -> "Rejalash"
        TpPlanPage.HISTORY -> "Buyurtmalar tarixi"
    }
    Column(Modifier.fillMaxSize()) {
        AppTopBar(title, canGoBack = true, onMenu = {}, onBack = ::back, subtitle = if (page == TpPlanPage.ROOT) "Buyurtma va reja" else null)
        when (page) {
            TpPlanPage.ROOT -> TpPlanRoot(policy, data) { page = it }
            TpPlanPage.ORDERS -> TpOrdersPage(data, repository, policy, ::refresh)
            TpPlanPage.PLANNING -> TpPlanningPage(data, repository, policy, ::refresh)
            TpPlanPage.HISTORY -> TpOrderHistoryPage(data)
        }
    }
}

@Composable
private fun TpPlanRoot(policy: UserAccessPolicy, data: TpData, onOpen: (TpPlanPage) -> Unit) {
    data class Item(val page: TpPlanPage, val title: String, val description: String, val accent: Color, val icon: ImageVector, val badge: Int = 0)
    val plannerBadge = data.orders.count { order ->
        order.status !in setOf(TpOrderStatus.COMPLETE, TpOrderStatus.CANCELLED) &&
            data.jobs.filter { it.orderId == order.id }.let { jobs -> jobs.isEmpty() || jobs.any { it.planConfirmedAt == null } }
    }
    val items = buildList {
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_ORDER)) add(Item(TpPlanPage.ORDERS, "Buyurtmalar", "Buyurtma berish va quyish boshlanganini kuzatish", Color(0xFF2F8FE5), Icons.Rounded.Assignment))
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_PLANNING)) add(Item(TpPlanPage.PLANNING, "Rejalash", "Detal + rang bo‘yicha reja va tasdiq", Color(0xFF12A982), Icons.Rounded.CalendarMonth, plannerBadge))
        if (policy.isAdmin() || policy.canRead(AssemblySection.TP_ORDER)) add(Item(TpPlanPage.HISTORY, "Buyurtmalar tarixi", "Quyib bo‘lingan va bekor qilingan buyurtmalar", Color(0xFF718394), Icons.Rounded.History))
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpPlan-root")).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Kerakli vazifani tanlang.", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        items.forEach { item ->
            val cardColor = MaterialTheme.colorScheme.surface
            val iconBg = item.accent.copy(alpha = 0.13f)
            Surface(modifier = Modifier.fillMaxWidth().clickable { onOpen(item.page) }, shape = RoundedCornerShape(16.dp), color = cardColor, border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), shadowElevation = 1.dp, tonalElevation = 0.dp) {
                Row(Modifier.fillMaxWidth().heightIn(min = 94.dp).padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(shape = RoundedCornerShape(16.dp), color = iconBg, tonalElevation = 0.dp) {
                        Icon(item.icon, contentDescription = null, tint = item.accent, modifier = Modifier.padding(12.dp).size(27.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text(item.title, color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(3.dp))
                        Text(item.description, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, lineHeight = 17.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    if (item.badge > 0) Badge(containerColor = MaterialTheme.colorScheme.error, contentColor = MaterialTheme.colorScheme.onError) { Text(item.badge.coerceAtMost(99).toString(), fontSize = 10.sp) }
                    Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = item.accent, modifier = Modifier.size(21.dp))
                }
            }
        }
    }
}

@Composable
fun TpShiftScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val eventRevision by TpDataEvents.revision.collectAsState()
    var localRevision by remember { mutableIntStateOf(0) }
    val policy = remember(eventRevision) { AccessGuard(context).currentPolicy() }
    val fullData = remember(eventRevision, localRevision, policy.revision) { repository.load() }
    val data = remember(fullData, policy.revision) { fullData.scopedFor(policy) }
    fun refresh() { localRevision++ }
    BackHandler { onBack() }
    Column(Modifier.fillMaxSize()) {
        AppTopBar("Brigada boshqaruvi", canGoBack = true, onMenu = {}, onBack = onBack, subtitle = "Stanoklar, ishchilar va smena")
        TpMachineQueuePage(data, fullData.workers, repository, policy, ::refresh)
    }
}

@Composable
fun TpAttendanceScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val eventRevision by TpDataEvents.revision.collectAsState()
    var localRevision by remember { mutableIntStateOf(0) }
    val policy = remember(eventRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(eventRevision, localRevision, policy.revision) { repository.load().scopedFor(policy) }
    fun refresh() { localRevision++ }
    BackHandler { onBack() }
    Column(Modifier.fillMaxSize()) {
        AppTopBar("Davomat", canGoBack = true, onMenu = {}, onBack = onBack, subtitle = "Ish vaqti va davomat")
        TpAttendancePage(data, repository, policy, ::refresh)
    }
}

@Composable
private fun TpOrdersPage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_ORDER)
    var showAdd by remember { mutableStateOf(false) }
    var editOrder by remember { mutableStateOf<TpOrder?>(null) }
    var deleteOrder by remember { mutableStateOf<TpOrder?>(null) }
    var cancelReason by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    fun moldingStartedAt(orderId: String): String? = data.jobs.asSequence()
        .filter { it.orderId == orderId }
        .mapNotNull { it.startedAt }
        .minOrNull()

    val active = data.orders.filter { it.status != TpOrderStatus.COMPLETE && it.status != TpOrderStatus.CANCELLED }
    val activeComparator = compareBy<TpOrder> { it.priority }.thenBy { it.createdAt }
    val notStarted = active.filter { moldingStartedAt(it.id) == null }.sortedWith(activeComparator)
    val started = active.filter { moldingStartedAt(it.id) != null }.sortedWith(activeComparator)

    @Composable
    fun ActiveOrderCard(order: TpOrder, startedAt: String?) {
        val progress = data.orderProgress(order.id).coerceIn(0.0, 100.0)
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            shadowElevation = 1.dp,
            tonalElevation = 0.dp
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text("${order.articleSnapshot} • ${order.productNameSnapshot}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Partiya ${order.batchNumber} • ${order.quantity} dona", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("${progress.toInt()}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
                LinearProgressIndicator(
                    progress = { (progress / 100.0).toFloat() },
                    modifier = Modifier.fillMaxWidth(),
                    trackColor = MaterialTheme.colorScheme.outlineVariant
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(shape = RoundedCornerShape(11.dp), color = tpPriorityColor(order.priority).copy(alpha = .16f)) {
                        Text(tpPriorityLabel(order.priority), Modifier.padding(horizontal = 10.dp, vertical = 5.dp), fontWeight = FontWeight.SemiBold)
                    }
                    Text("Berildi: ${order.createdAt.take(16).replace('T', ' ')}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (!startedAt.isNullOrBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Rounded.PlayCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Text("Boshlangan: ${startedAt.take(16).replace('T', ' ')}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                    }
                }
                if (order.note.isNotBlank()) Text("Izoh: ${order.note}", style = MaterialTheme.typography.bodySmall)
                if (canWrite) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { editOrder = order }, Modifier.weight(1f)) {
                            Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(5.dp)); Text("Tahrirlash")
                        }
                        OutlinedButton(
                            onClick = { cancelReason = ""; deleteOrder = order },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(5.dp)); Text("Bekor/O‘chirish")
                        }
                    }
                }
            }
        }
    }

    Column(
        Modifier.fillMaxSize()
            .verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-orders"))
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (canWrite) {
            Button(
                onClick = { showAdd = true },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null)
                Spacer(Modifier.width(7.dp))
                Text("Yangi buyurtma", fontWeight = FontWeight.Bold)
            }
        }

        Text("Quyish boshlanmagan · ${notStarted.size}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (notStarted.isEmpty()) {
            Text("Boshlanishni kutayotgan buyurtma yo‘q.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else notStarted.forEach { ActiveOrderCard(it, null) }

        HorizontalDivider(Modifier.padding(vertical = 6.dp))

        Text("Quyish boshlangan · ${started.size}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (started.isEmpty()) {
            Text("Hozir quyilayotgan buyurtma yo‘q.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else started.forEach { order -> ActiveOrderCard(order, moldingStartedAt(order.id)) }

        TpError(error)
    }

    if (showAdd) {
        TpOrderDialog(data = data, initial = null, onDismiss = { showAdd = false }) { batch, productId, quantity, priority, note ->
            val result = repo.createOrder(batch, productId, quantity, priority, note)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { showAdd = false; refresh() }
            result.isSuccess
        }
    }

    editOrder?.let { order ->
        TpOrderDialog(data = data, initial = order, onDismiss = { editOrder = null }) { _, productId, quantity, priority, note ->
            val result = repo.updateOrder(order.id, productId, quantity, priority, note)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) { editOrder = null; refresh() }
            result.isSuccess
        }
    }

    deleteOrder?.let { order ->
        val hasLinkedProcess = data.jobs.any { it.orderId == order.id } || data.receipts.any { it.orderId == order.id }
        AlertDialog(
            onDismissRequest = { deleteOrder = null; cancelReason = "" },
            title = { Text(if (hasLinkedProcess) "Buyurtmani bekor qilish" else "Buyurtmani o‘chirish") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (hasLinkedProcess)
                        "${order.batchNumber} • ${order.articleSnapshot} jarayonga ulangan. Buyurtma o‘chirilmaydi; bekor qilingan holatda tarixda qoladi."
                    else "${order.batchNumber} • ${order.articleSnapshot} hali jarayonga ulanmagan. Uni butunlay o‘chirish mumkin.")
                    if (hasLinkedProcess) TpField(cancelReason, { cancelReason = it }, "Bekor qilish sababi *", singleLine = false)
                }
            },
            confirmButton = { TextButton(enabled = !hasLinkedProcess || cancelReason.isNotBlank(), onClick = {
                val result = if (hasLinkedProcess) repo.cancelOrder(order.id, cancelReason, policy.displayName) else repo.deleteOrder(order.id)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { deleteOrder = null; cancelReason = ""; refresh() }
            }) { Text(if (hasLinkedProcess) "Bekor qilish" else "O‘chirish", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { deleteOrder = null; cancelReason = "" }) { Text("Ortga") } }
        )
    }
}

private enum class TpOrderHistoryMode { COMPLETE, CANCELLED }

@Composable
private fun TpOrderHistoryPage(data: TpData) {
    var mode by remember { mutableStateOf(TpOrderHistoryMode.COMPLETE) }
    var query by remember { mutableStateOf("") }
    var fromDate by remember { mutableStateOf("") }
    var toDate by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf<TpOrder?>(null) }

    fun startedAt(orderId: String): String? = data.jobs.asSequence().filter { it.orderId == orderId }.mapNotNull { it.startedAt }.minOrNull()
    fun endAt(order: TpOrder): String = when (mode) {
        TpOrderHistoryMode.COMPLETE -> order.completedAt.orEmpty()
        TpOrderHistoryMode.CANCELLED -> order.cancelledAt.orEmpty()
    }
    val source = when (mode) {
        TpOrderHistoryMode.COMPLETE -> data.orders.filter { it.status == TpOrderStatus.COMPLETE }
        TpOrderHistoryMode.CANCELLED -> data.orders.filter { it.status == TpOrderStatus.CANCELLED }
    }
    val normalized = query.trim().lowercase()
    val visible = source.filter { order ->
        val date = endAt(order).take(10).ifBlank { order.requestedDate }
        val matchesQuery = normalized.isBlank() || listOf(order.articleSnapshot, order.productNameSnapshot, order.batchNumber).any { it.lowercase().contains(normalized) }
        val after = fromDate.isBlank() || date >= fromDate
        val before = toDate.isBlank() || date <= toDate
        matchesQuery && after && before
    }.sortedByDescending { endAt(it).ifBlank { it.createdAt } }

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("tp-order-history")).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == TpOrderHistoryMode.COMPLETE, onClick = { mode = TpOrderHistoryMode.COMPLETE }, label = { Text("Yakunlangan") }, modifier = Modifier.weight(1f))
            FilterChip(selected = mode == TpOrderHistoryMode.CANCELLED, onClick = { mode = TpOrderHistoryMode.CANCELLED }, label = { Text("Bekor qilingan") }, modifier = Modifier.weight(1f))
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Artikul, mahsulot yoki partiya") },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) }
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = fromDate, onValueChange = { fromDate = it.take(10) }, label = { Text("Dan") }, placeholder = { Text("YYYY-MM-DD") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(value = toDate, onValueChange = { toDate = it.take(10) }, label = { Text("Gacha") }, placeholder = { Text("YYYY-MM-DD") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        if (visible.isEmpty()) Text("Bu filtr bo‘yicha buyurtma yo‘q.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        visible.forEach { order ->
            Surface(
                modifier = Modifier.fillMaxWidth().clickable { detail = order },
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                tonalElevation = 0.dp
            ) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${order.articleSnapshot} • ${order.productNameSnapshot}", fontWeight = FontWeight.Bold)
                    Text("Partiya ${order.batchNumber} • ${order.quantity} dona", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (mode == TpOrderHistoryMode.COMPLETE) {
                        Text("Yakunlandi: ${order.completedAt.orEmpty().take(16).replace('T', ' ')}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text("Bekor qilindi: ${order.cancelledAt.orEmpty().take(16).replace('T', ' ')}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    detail?.let { order ->
        val started = startedAt(order.id)
        val finished = order.completedAt ?: order.cancelledAt
        val durationLabel = if (started.isNullOrBlank() || finished.isNullOrBlank()) null else runCatching {
            val a = java.time.LocalDateTime.parse(started)
            val b = java.time.LocalDateTime.parse(finished)
            minutesLabel(java.time.Duration.between(a, b).toMinutes().coerceAtLeast(0).toInt())
        }.getOrNull()
        val jobs = data.jobs.filter { it.orderId == order.id }
        AlertDialog(
            onDismissRequest = { detail = null },
            title = { Text("${order.articleSnapshot} • Partiya ${order.batchNumber}") },
            text = {
                Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text(order.productNameSnapshot, fontWeight = FontWeight.Bold)
                    Text("Buyurtma: ${order.quantity} dona")
                    Text("Berildi: ${order.createdAt.take(16).replace('T', ' ')}")
                    Text("Quyish boshlandi: ${started?.take(16)?.replace('T', ' ') ?: "boshlanmagan"}")
                    if (order.status == TpOrderStatus.COMPLETE) Text("Yakunlandi: ${order.completedAt.orEmpty().take(16).replace('T', ' ')}")
                    if (order.status == TpOrderStatus.CANCELLED) {
                        Text("Bekor qilindi: ${order.cancelledAt.orEmpty().take(16).replace('T', ' ')}", color = MaterialTheme.colorScheme.error)
                        if (order.cancelReason.isNotBlank()) Text("Sabab: ${order.cancelReason}")
                    }
                    if (!durationLabel.isNullOrBlank()) Text("Umumiy davomiylik: $durationLabel")
                    HorizontalDivider()
                    Text("Detal / rang", fontWeight = FontWeight.Bold)
                    jobs.sortedWith(compareBy<TpPlanJob> { it.moldCode }.thenBy { it.colorCode }).forEach { job ->
                        val received = job.outputs.sumOf { out -> data.receipts.filter { !it.isCancelled && it.jobId == job.id && it.detailId == out.detailId }.sumOf { it.creditedPieces } }
                        val required = job.outputs.sumOf { it.requiredPieces }
                        Text("${job.outputs.joinToString { it.detailName }} • ${job.colorCode} • $received/$required dona", style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { detail = null }) { Text("Yopish") } }
        )
    }
}


@Composable
private fun TpOrderDialog(
    data: TpData,
    initial: TpOrder?,
    onDismiss: () -> Unit,
    onSave: (String, String, Int, Int, String) -> Boolean
) {
    val products = data.products.filter { !it.archived && it.details.any { detail -> !detail.archived } }.sortedBy { it.article }
    var productId by remember(initial?.id) { mutableStateOf(initial?.productId ?: products.firstOrNull()?.id.orEmpty()) }
    fun suggestedFor(id: String): String = nextBatchNumberForProduct(data.orders.filter { it.productId == id }.map { it.batchNumber })
    var batch by remember(initial?.id) { mutableStateOf(initial?.batchNumber ?: suggestedFor(productId)) }
    var quantity by remember(initial?.id) { mutableStateOf(initial?.quantity?.toString().orEmpty()) }
    var priority by remember(initial?.id) { mutableIntStateOf(initial?.priority?.coerceIn(1, 3) ?: 2) }
    var note by remember(initial?.id) { mutableStateOf(initial?.note.orEmpty()) }
    var validation by remember { mutableStateOf<String?>(null) }
    var confirmBatchOverride by remember { mutableStateOf(false) }

    val productHistory = remember(data.orders, productId) { data.orders.filter { it.productId == productId } }
    val suggestedBatch = remember(data.orders, productId) { suggestedFor(productId) }

    LaunchedEffect(productId, initial?.id) {
        if (initial == null) batch = suggestedFor(productId)
    }

    fun commit(): Boolean {
        val qty = quantity.toIntOrNull()
        validation = when {
            productId.isBlank() || qty == null || qty <= 0 -> "Majburiy maydonlarni to‘ldiring"
            batch.trim().isBlank() -> "Partiya raqamini kiriting"
            productHistory.any { it.id != initial?.id && it.batchNumber.equals(batch.trim(), true) } -> "Bu mahsulotda ${batch.trim()}-partiya allaqachon mavjud"
            else -> null
        }
        return if (validation == null) onSave(batch.trim(), productId, qty!!, priority, note) else false
    }

    fun save() {
        val qty = quantity.toIntOrNull()
        validation = when {
            productId.isBlank() || qty == null || qty <= 0 -> "Majburiy maydonlarni to‘ldiring"
            initial == null && batch.trim().isBlank() -> "Partiya raqamini kiriting"
            else -> null
        }
        if (validation != null) return
        val changedAutomaticBatch = initial == null && suggestedBatch.isNotBlank() && batch.trim() != suggestedBatch
        if (changedAutomaticBatch) confirmBatchOverride = true
        else if (commit()) onDismiss()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (initial == null) "Yangi buyurtma" else "Buyurtmani tahrirlash",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer) {
                    IconButton(onClick = onDismiss, modifier = Modifier.size(38.dp)) {
                        Icon(Icons.Rounded.Close, contentDescription = "Yopish")
                    }
                }
            }
        },
        text = {
            Column(
                Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (products.isEmpty()) Text("Avval mahsulot va uning detallarini kiriting.", color = MaterialTheme.colorScheme.error)
                TpChoice("Mahsulot", productId, products, { it.id }, { "${it.article} — ${it.name}" }) { productId = it }
                if (initial != null) {
                    Text("Partiya: ${initial.batchNumber}", fontWeight = FontWeight.Bold)
                } else {
                    TpField(batch, { batch = it }, if (productHistory.isEmpty()) "Birinchi partiya raqami" else "Partiya raqami")
                    Text(
                        if (productHistory.isEmpty()) "Bu mahsulot uchun boshlang‘ich partiya bir marta kiritiladi."
                        else "Avtomatik tavsiya: $suggestedBatch. Zarurat bo‘lsa qo‘lda o‘zgartirish mumkin.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TpField(quantity, { quantity = digitsOnly(it) }, "Buyurtma soni", KeyboardType.Number)
                Text("Ustuvorlik", fontWeight = FontWeight.Bold)
                TpPriorityButtons(priority) { priority = it }
                TpField(note, { note = it }, "Izoh", singleLine = false)
                TpError(validation)
            }
        },
        confirmButton = {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f).height(48.dp)) { Text("Bekor qilish") }
                Button(enabled = products.isNotEmpty(), onClick = ::save, modifier = Modifier.weight(1f).height(48.dp)) {
                    Text("Saqlash", fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {}
    )

    if (confirmBatchOverride) {
        AlertDialog(
            onDismissRequest = { confirmBatchOverride = false },
            title = { Text("Partiya raqamini o‘zgartirish") },
            text = { Text("Dastur $suggestedBatch ni tavsiya qildi. ${batch.trim()} partiya raqamini ataylab saqlaysizmi?") },
            confirmButton = { TextButton(onClick = {
                confirmBatchOverride = false
                if (commit()) onDismiss()
            }) { Text("Ha, saqlash") } },
            dismissButton = { TextButton(onClick = { confirmBatchOverride = false }) { Text("Ortga") } }
        )
    }
}

@Composable
private fun TpPriorityButtons(selected: Int, onSelect: (Int) -> Unit) {
    val values = listOf(
        Triple(1, "Eng zaril", Color(0xFFC62828)),
        Triple(2, "Zaril", Color(0xFFFFC107)),
        Triple(3, "Keyinroq", Color(0xFF2E7D32))
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        values.forEach { (value, label, color) ->
            val content = if (value == 2) Color.Black else Color.White
            Button(
                onClick = { onSelect(value) },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = color.copy(alpha = if (selected == value) 1f else 0.45f),
                    contentColor = content
                )
            ) { Text(if (selected == value) "✓ $label" else label, style = MaterialTheme.typography.labelSmall) }
        }
    }
}

@Composable
private fun TpOrderSummary(data: TpData, order: TpOrder) {
    val progress = data.orderProgress(order.id)
    val forecast = data.orderForecastMinutes(order.id)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("${order.batchNumber} • ${order.articleSnapshot}", fontWeight = FontWeight.Bold)
            Text("${order.productNameSnapshot} — ${order.quantity} dona")
        }
        Text("${progress.toInt()}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = tpPriorityColor(order.priority).copy(alpha = 0.16f)
        ) {
            Text(tpPriorityLabel(order.priority), modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontWeight = FontWeight.SemiBold)
        }
        Text("Holat: ${orderStatusLabel(order.status)}", style = MaterialTheme.typography.bodySmall)
    }
    Text("Zakaz berildi: ${order.createdAt.take(16).replace('T', ' ')}", style = MaterialTheme.typography.bodySmall)
    Text(
        if (forecast > 0) "Taxminiy to‘liq quyish: ${minutesLabel(forecast)}" else "Taxminiy muddat: ma’lumot yetarli emas",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    if (order.note.isNotBlank()) Text("Izoh: ${order.note}", style = MaterialTheme.typography.bodySmall)
    if (order.completedAt != null) Text("Yakunlandi: ${order.completedAt.take(16).replace('T', ' ')}", style = MaterialTheme.typography.bodySmall)
}

private fun tpPriorityColor(priority: Int): Color = when (priority.coerceIn(1, 3)) {
    1 -> Color(0xFFC62828)
    2 -> Color(0xFFFFC107)
    else -> Color(0xFF2E7D32)
}

private enum class TpPlannerMode { ORDERS, MACHINES }

@Composable
private fun PlannerModeButton(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(48.dp),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 2.dp else 1.dp,
            if (selected) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.outline.copy(alpha = 0.68f)
        ),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = .62f)
            else MaterialTheme.colorScheme.surface,
            contentColor = if (selected) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurfaceVariant
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = if (selected) 1.dp else 0.dp)
    ) {
        Text(
            text,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun TpPlanningPage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_PLANNING)
    var mode by remember { mutableStateOf(TpPlannerMode.ORDERS) }
    var selectedOrderId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        TpNavigationTargetState.consumeOrderId()?.takeIf { target -> data.orders.any { it.id == target } }?.let { selectedOrderId = it }
    }
    var expandedDetails by remember { mutableStateOf<Set<String>>(emptySet()) }
    var assignMold by remember { mutableStateOf<String?>(null) }
    var openColorMenu by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    val visibleOrders = data.orders.filter { it.status != TpOrderStatus.COMPLETE && it.status != TpOrderStatus.CANCELLED }
    fun orderPlanDone(order: TpOrder): Boolean {
        val jobs = data.jobs.filter { it.orderId == order.id }
        return jobs.isNotEmpty() && jobs.all { it.planConfirmedAt != null }
    }
    val pendingOrders = visibleOrders.filterNot(::orderPlanDone)
        .sortedWith(compareBy<TpOrder> { it.priority }.thenBy { it.createdAt })
    val approvedOrders = visibleOrders.filter(::orderPlanDone)
        .sortedWith(compareBy<TpOrder> { it.planApprovedAt.orEmpty() }.thenBy { it.createdAt })
    val selectedOrder = data.orders.firstOrNull { it.id == selectedOrderId }

    BackHandler(enabled = selectedOrder != null || mode == TpPlannerMode.MACHINES) {
        if (selectedOrder != null) {
            selectedOrderId = null; expandedDetails = emptySet(); assignMold = null; openColorMenu = null
        } else mode = TpPlannerMode.ORDERS
    }

    LaunchedEffect(selectedOrderId) {
        val orderId = selectedOrderId ?: return@LaunchedEffect
        val order = data.orders.firstOrNull { it.id == orderId } ?: return@LaunchedEffect
        if (canWrite && order.status != TpOrderStatus.COMPLETE && data.jobs.none { it.orderId == orderId }) {
            val result = repo.generateOrderPlan(orderId)
            error = result.exceptionOrNull()?.message
            if (result.isSuccess) refresh()
        }
    }

    Column(Modifier.fillMaxSize()) {
        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            tonalElevation = 0.dp,
            shadowElevation = 1.dp
        ) {
            Row(
                Modifier.fillMaxWidth().padding(6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PlannerModeButton(
                    text = "Buyurtmalar bo‘yicha",
                    selected = mode == TpPlannerMode.ORDERS,
                    modifier = Modifier.weight(1f),
                    onClick = { mode = TpPlannerMode.ORDERS }
                )
                PlannerModeButton(
                    text = "Stanoklar bo‘yicha",
                    selected = mode == TpPlannerMode.MACHINES,
                    modifier = Modifier.weight(1f),
                    onClick = { mode = TpPlannerMode.MACHINES; selectedOrderId = null }
                )
            }
        }
        if (mode == TpPlannerMode.MACHINES) {
            TpPlannerMachinesView(data, repo, canWrite, refresh)
            return@Column
        }

        val scrollKey = selectedOrder?.let { "tp-planning-order-${it.id}" } ?: "tp-planning-list"
        Column(
            Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState(scrollKey)).navigationBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (selectedOrder == null) {
                Text("Buyurtmalarni detalma-detal rejalang. Tasdiqlangan detal darhol Seryo brigadiriga o‘tadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Tasdiqlanmagan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (pendingOrders.isEmpty()) Text("Ko‘rib chiqilishi kerak bo‘lgan buyurtma yo‘q.")
                pendingOrders.forEach { order ->
                    val jobs = data.jobs.filter { it.orderId == order.id }
                    val remaining = if (jobs.isEmpty()) data.products.firstOrNull { it.id == order.productId }?.details?.count { !it.archived } ?: 0
                    else jobs.groupBy { it.moldCode }.count { (_, rows) -> rows.any { it.planConfirmedAt == null } }
                    TpCard(Modifier.clickable { selectedOrderId = order.id }) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f)) { TpOrderSummary(data, order) }
                            if (remaining > 0) Surface(shape = RoundedCornerShape(999.dp), color = MaterialTheme.colorScheme.error) {
                                Text(remaining.toString(), Modifier.padding(horizontal = 8.dp, vertical = 3.dp), color = MaterialTheme.colorScheme.onError, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text("Tasdiqlanmagan detal: $remaining", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                Text("Tasdiqlangan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (approvedOrders.isEmpty()) Text("Hali barcha detallari tasdiqlangan buyurtma yo‘q.")
                approvedOrders.forEach { order -> TpCard(Modifier.clickable { selectedOrderId = order.id }) { TpOrderSummary(data, order) } }
            } else {
                OutlinedButton(onClick = { selectedOrderId = null; expandedDetails = emptySet() }) { Text("‹ Buyurtmalar") }
                TpCard { TpOrderSummary(data, selectedOrder) }
                val product = data.products.firstOrNull { it.id == selectedOrder.productId }
                val details = product?.details?.filterNot { it.archived }.orEmpty().sortedWith(compareBy<TpDetail> { detail ->
                    val rows = data.jobs.filter { it.orderId == selectedOrder.id && it.outputs.any { out -> out.detailId == detail.id } }
                    rows.isNotEmpty() && rows.all { it.planConfirmedAt != null }
                }.thenBy { it.name })
                if (details.isEmpty()) Text("Mahsulot detallari topilmadi.", color = MaterialTheme.colorScheme.error)
                details.forEach { detail ->
                    val detailJobs = data.jobs.filter { job -> job.orderId == selectedOrder.id && job.outputs.any { it.detailId == detail.id } }
                        .sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id })
                    val confirmed = detailJobs.isNotEmpty() && detailJobs.all { it.planConfirmedAt != null }
                    val machineIds = detailJobs.mapNotNull { it.machineId }.distinct()
                    val machineLabel = when {
                        detailJobs.isEmpty() -> "Stanok"
                        machineIds.size == 1 -> {
                            val machine = data.machines.firstOrNull { it.id == machineIds.first() }
                            val shop = machine?.let { m -> data.shops.firstOrNull { it.id == m.shopId }?.name }.orEmpty()
                            if (machine == null) "Stanok" else "${machine.number} • ${shop.ifBlank { "Sex" }}"
                        }
                        machineIds.isEmpty() -> "Stanok"
                        else -> "Aralash"
                    }
                    val total = selectedOrder.quantity * detail.requiredPerProduct
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = if (confirmed) MaterialTheme.colorScheme.primaryContainer.copy(alpha = .55f) else MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .62f)),
                        tonalElevation = 0.dp,
                        shadowElevation = 2.dp
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Column(Modifier.weight(1f)) {
                                    Text(detail.name, fontWeight = FontWeight.Bold)
                                    Text("Jami: $total dona", color = MaterialTheme.colorScheme.primary)
                                    if (confirmed) Text("✓ Rejalangan va tasdiqlangan", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                                }
                                OutlinedButton(enabled = canWrite && detailJobs.isNotEmpty(), onClick = { assignMold = detail.moldCode }) {
                                    Text(if (confirmed) "Tahrirlash • $machineLabel" else machineLabel)
                                }
                            }
                            val assignedMachineId = machineIds.singleOrNull()?.takeIf { id -> detailJobs.all { it.machineId == id } }
                            if (assignedMachineId != null) {
                                val targetIds = detailJobs.map { it.id }.toSet()
                                val wait = data.jobs.filter { it.machineId == assignedMachineId && it.status != TpJobStatus.COMPLETE && it.id !in targetIds && it.planConfirmedAt != null }.sumOf { it.estimatedMinutes }
                                Text(if (wait > 0) "Boshlanishi taxminan ${minutesLabel(wait)} dan keyin" else "Stanok bo‘sh — boshlash mumkin", style = MaterialTheme.typography.bodySmall)
                            }
                            if (!confirmed && detailJobs.isNotEmpty() && detailJobs.all { it.machineId != null && it.brigadeId != null && it.shiftId != null }) {
                                OutlinedButton(enabled = canWrite, onClick = {
                                    val result = repo.confirmPlannedMold(selectedOrder.id, detail.moldCode)
                                    error = result.exceptionOrNull()?.message
                                    if (result.isSuccess) refresh()
                                }, modifier = Modifier.fillMaxWidth()) { Text("✓ Shu detalni tasdiqlash") }
                            }
                            OutlinedButton(onClick = { expandedDetails = if (detail.id in expandedDetails) expandedDetails - detail.id else expandedDetails + detail.id }, modifier = Modifier.fillMaxWidth()) {
                                Text(if (detail.id in expandedDetails) "▲ Ranglarni yopish" else "▼ Ranglarni ko‘rish")
                            }
                            if (detail.id in expandedDetails) {
                                detailJobs.forEachIndexed { index, job ->
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Text("${job.colorCode} — ${job.outputs.firstOrNull { it.detailId == detail.id }?.requiredPieces ?: 0} dona", Modifier.weight(1f))
                                        if (!confirmed && canWrite) Box {
                                            OutlinedButton(onClick = { openColorMenu = job.id }) { Text("${index + 1}") }
                                            DropdownMenu(expanded = openColorMenu == job.id, onDismissRequest = { openColorMenu = null }) {
                                                detailJobs.indices.forEach { pos -> DropdownMenuItem(text = { Text("${pos + 1}-navbat") }, onClick = {
                                                    openColorMenu = null
                                                    val result = repo.setColorPosition(job.id, pos + 1)
                                                    error = result.exceptionOrNull()?.message
                                                    if (result.isSuccess) refresh()
                                                }) }
                                            }
                                        } else Text("${index + 1}")
                                    }
                                }
                            }
                        }
                    }
                }
                val remaining = data.jobs.filter { it.orderId == selectedOrder.id }.groupBy { it.moldCode }.count { (_, rows) -> rows.any { it.planConfirmedAt == null } }
                if (remaining > 0) Text("Tasdiqlanmagan detal: $remaining. Har bir detal tasdiqlangach Seryoga alohida yuboriladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                else Text("✓ Barcha detallar rejalandi. Zakaz avtomatik tasdiqlanganlar ro‘yxatiga o‘tdi.", color = MaterialTheme.colorScheme.primary)
            }
            TpError(error)
        }
    }

    val order = selectedOrder
    val mold = assignMold
    if (order != null && mold != null) {
        val target = data.jobs.filter { it.orderId == order.id && it.moldCode == mold }
        val editing = target.any { it.planConfirmedAt != null }
        TpMachinePickerDialog(
            data = data, order = order, moldCode = mold, editing = editing,
            onDismiss = { assignMold = null },
            onSave = { machineId, reason, override, overrideReason ->
                val result = repo.assignMoldJobs(order.id, mold, machineId, reason, override, overrideReason)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { assignMold = null; refresh() }
                result.isSuccess
            }
        )
    }
}

@Composable
private fun TpPlannerMachinesView(data: TpData, repo: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    var shopId by remember(shops) { mutableStateOf(shops.firstOrNull()?.id.orEmpty()) }
    var selectedMachineId by remember { mutableStateOf<String?>(null) }
    var showMachineOrders by remember { mutableStateOf(false) }
    var selectedOrderId by remember { mutableStateOf<String?>(null) }
    var assignMold by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val machines = data.machines.filter { !it.archived && (shopId.isBlank() || it.shopId == shopId) }
    fun remaining(machineId: String): Int = data.jobs.filter { it.machineId == machineId && it.planConfirmedAt != null && it.status != TpJobStatus.COMPLETE }.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
    fun lastActivity(machineId: String): String = data.jobs.filter { it.machineId == machineId }.mapNotNull { it.startedAt ?: it.materialDeliveredAt ?: it.planEditedAt ?: it.planConfirmedAt }.maxOrNull().orEmpty()
    fun compatibleOrders(machine: TpMachine): List<TpOrder> = data.orders
        .filter { it.status != TpOrderStatus.COMPLETE && it.status != TpOrderStatus.CANCELLED }
        .filter { order ->
            val orderJobs = data.jobs.filter { it.orderId == order.id }
            val candidates = if (orderJobs.isEmpty()) {
                var previewIndex = 0
                buildPlanJobs(data, order) { "preview-${order.id}-${previewIndex++}" }
            } else orderJobs.filter { it.status != TpJobStatus.COMPLETE && it.planConfirmedAt == null }
            candidates.any { it.acceptsMachine(machine, data) }
        }
        .sortedWith(compareBy<TpOrder> { it.priority }.thenBy { it.createdAt })
    val idle = machines.filter { remaining(it.id) == 0 }.sortedWith(compareBy<TpMachine> { lastActivity(it.id) }.thenBy { it.number })
    val busy = machines.filter { remaining(it.id) > 0 }.sortedWith(compareBy<TpMachine> { remaining(it.id) }.thenBy { it.number })
    val selectedMachine = machines.firstOrNull { it.id == selectedMachineId }

    BackHandler(enabled = selectedMachineId != null) { selectedMachineId = null; showMachineOrders = false; selectedOrderId = null; assignMold = null }
    LaunchedEffect(selectedOrderId) {
        val id = selectedOrderId ?: return@LaunchedEffect
        if (data.jobs.none { it.orderId == id } && canWrite) {
            val result = repo.generateOrderPlan(id); error = result.exceptionOrNull()?.message; if (result.isSuccess) refresh()
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("tp-planner-machines")).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (selectedMachine == null) {
            Text("Sex", fontWeight = FontWeight.Bold)
            TpFilterRow(shops, shopId, { it.id }, { it.name }) { shopId = it }
            Text("Ishsiz stanoklar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (idle.isEmpty()) Text("Ishsiz stanok yo‘q.")
            idle.forEach { machine ->
                val compatibleCount = compatibleOrders(machine).size
                TpCard(Modifier.clickable { selectedMachineId = machine.id; showMachineOrders = false }) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${machine.number}-stanok", fontWeight = FontWeight.Bold)
                            Text("Ishsiz • eng oxirgi faoliyat: ${lastActivity(machine.id).take(16).replace('T',' ').ifBlank { "noma’lum" }}")
                        }
                        OutlinedButton(onClick = { selectedMachineId = machine.id; showMachineOrders = compatibleCount > 0 }) {
                            Text(if (compatibleCount > 0) "Mos zakaz: $compatibleCount" else "Mos zakaz yo‘q")
                        }
                    }
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Text("Ishi bor stanoklar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            busy.forEach { machine ->
                val mins = remaining(machine.id)
                val compatibleCount = compatibleOrders(machine).size
                TpCard(Modifier.clickable { selectedMachineId = machine.id; showMachineOrders = false }) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${machine.number}-stanok", fontWeight = FontWeight.Bold)
                            Text("Ishi: ${minutesLabel(mins)}", color = if (mins <= 1080) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                            if (mins <= 1080) Text("⚠ 18 soat yoki undan kam ish qolgan", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                        OutlinedButton(onClick = { selectedMachineId = machine.id; showMachineOrders = compatibleCount > 0 }) {
                            Text(if (compatibleCount > 0) "Mos zakaz: $compatibleCount" else "Mos zakaz yo‘q")
                        }
                    }
                }
            }
        } else {
            TextButton(onClick = { selectedMachineId = null; showMachineOrders = false; selectedOrderId = null }) { Text("‹ Stanoklar") }
            TpCard {
                Text("${selectedMachine.number}-stanok", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Jami rejalangan ish: ${minutesLabel(remaining(selectedMachine.id))}")
                val queue = data.jobs.filter { it.machineId == selectedMachine.id && it.planConfirmedAt != null && it.status != TpJobStatus.COMPLETE }.sortedBy { it.priority }
                queue.take(5).forEach { job ->
                    val order = data.orders.firstOrNull { it.id == job.orderId }
                    Text("• ${order?.articleSnapshot.orEmpty()} • ${job.outputs.joinToString { it.detailName }} • ${job.colorCode}", style = MaterialTheme.typography.bodySmall)
                }
            }
            OutlinedButton(onClick = { showMachineOrders = !showMachineOrders; if (!showMachineOrders) selectedOrderId = null }, modifier = Modifier.fillMaxWidth()) {
                Text(if (showMachineOrders) "Buyurtmalarni yopish" else "Buyurtmalar")
            }
            if (showMachineOrders) {
            Text("Buyurtmalar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            val orders = compatibleOrders(selectedMachine)
            if (selectedOrderId == null) {
                if (orders.isEmpty()) Text("Bu stanok uchun normal mos buyurtma yo‘q.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                orders.forEach { order ->
                    TpCard(Modifier.clickable { selectedOrderId = order.id }) { TpOrderSummary(data, order); Text("Shu stanokka mos detallarni ko‘rish", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
                }
            } else {
                val order = data.orders.firstOrNull { it.id == selectedOrderId }
                OutlinedButton(onClick = { selectedOrderId = null }) { Text("‹ Buyurtmalar") }
                if (order != null) {
                    TpCard { TpOrderSummary(data, order) }
                    val groups = data.jobs.filter { it.orderId == order.id && it.status != TpJobStatus.COMPLETE }.groupBy { it.moldCode }
                    val compatible = groups.filterValues { rows -> rows.all { it.acceptsMachine(selectedMachine, data) } }
                    val incompatible = groups.filterKeys { it !in compatible.keys }
                    compatible.forEach { (mold, rows) ->
                        val names = rows.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString()
                        val plannedMachine = rows.mapNotNull { it.machineId }.distinct().singleOrNull()
                        val plannedNumber = data.machines.firstOrNull { it.id == plannedMachine }?.number
                        val confirmed = rows.all { it.planConfirmedAt != null }
                        TpCard {
                            Text(names.ifBlank { mold }, fontWeight = FontWeight.Bold)
                            Text(if (plannedMachine == selectedMachine.id) "Shu stanokka rejalangan${if (confirmed) " • tasdiqlangan" else ""}" else if (plannedMachine != null) "Rejalangan: ${plannedNumber ?: "?"}-stanok" else "Rejalanmagan")
                            if (canWrite) OutlinedButton(onClick = { assignMold = mold }, Modifier.fillMaxWidth()) { Text(if (plannedMachine == null) "Shu stanokka rejalash" else "Planni tahrirlash") }
                            if (!confirmed && plannedMachine == selectedMachine.id && rows.all { it.brigadeId != null }) OutlinedButton(onClick = { val r=repo.confirmPlannedMold(order.id,mold); error=r.exceptionOrNull()?.message; if(r.isSuccess) refresh() }, Modifier.fillMaxWidth()) { Text("✓ Tasdiqlash") }
                        }
                    }
                    if (incompatible.isNotEmpty()) {
                        HorizontalDivider(); Text("⚠ Bu stanokka tushmaydigan detallar", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                        incompatible.forEach { (_, rows) -> Text("• ${rows.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString()}", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            }
            TpError(error)
        }
    }
    val order = data.orders.firstOrNull { it.id == selectedOrderId }
    val mold = assignMold
    if (selectedMachine != null && order != null && mold != null) {
        val target = data.jobs.filter { it.orderId == order.id && it.moldCode == mold }
        TpFixedMachineAssignDialog(data, order, target, selectedMachine, target.any { it.machineId != null }, onDismiss = { assignMold = null }) { reason ->
            val r = repo.assignMoldJobs(order.id, mold, selectedMachine.id, reason); error = r.exceptionOrNull()?.message
            if (r.isSuccess) { assignMold = null; refresh() }; r.isSuccess
        }
    }
}

private fun commonJobResinOptions(data: TpData, job: TpPlanJob): List<String> {
    val sets = job.outputs.mapNotNull { output ->
        data.products.asSequence().flatMap { it.details.asSequence() }
            .firstOrNull { it.id == output.detailId }?.resinOptions()?.toSet()
    }
    if (sets.isEmpty()) return listOfNotNull(job.resinCode.takeIf { it.isNotBlank() })
    return sets.drop(1).fold(sets.first()) { acc, set -> acc intersect set }.sorted()
}

@Composable
private fun TpMachinePickerDialog(
    data: TpData,
    order: TpOrder,
    moldCode: String,
    editing: Boolean = false,
    onDismiss: () -> Unit,
    onSave: (String, String, Boolean, String) -> Boolean
) {
    val targetJobs = data.jobs.filter { it.orderId == order.id && it.moldCode == moldCode }
    val targetIds = targetJobs.map { it.id }.toSet()
    fun availability(machineId: String): Int = data.jobs
        .filter { it.machineId == machineId && it.status != TpJobStatus.COMPLETE && it.id !in targetIds }
        .sumOf { it.estimatedMinutes }
    val allMachines = data.machines.filterNot { it.archived }.sortedWith(compareBy<TpMachine> { availability(it.id) }.thenBy { it.number })
    val machines = allMachines.filter { machine -> targetJobs.isNotEmpty() && targetJobs.all { it.acceptsMachine(machine, data) } }
    val otherMachines = allMachines.filter { it !in machines }
    val currentMachineId = targetJobs.mapNotNull { it.machineId }.distinct().singleOrNull()
    val currentWasOverride = targetJobs.any { it.machineOverride }
    var otherMode by remember(order.id, moldCode) { mutableStateOf(currentWasOverride) }
    var machineId by remember(order.id, moldCode) { mutableStateOf(currentMachineId ?: machines.firstOrNull()?.id.orEmpty()) }
    val selectedMachine = allMachines.firstOrNull { it.id == machineId }
    var infoMachine by remember { mutableStateOf<TpMachine?>(null) }
    var editReason by remember(order.id, moldCode, editing) { mutableStateOf("") }
    var overrideReason by remember(order.id, moldCode) { mutableStateOf(targetJobs.firstOrNull { it.machineOverride }?.machineOverrideReason.orEmpty()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Stanok tanlash") },
        text = {
            Column(Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val detailNames = targetJobs.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString()
                if (detailNames.isNotBlank()) Text("Detal: $detailNames", fontWeight = FontWeight.Bold)
                if (machines.isEmpty() && !otherMode) {
                    Text("Mos stanok topilmadi. Tajriba yoki majburiy ishlab chiqarish uchun ‘Boshqa stanok’ni tanlash mumkin.", color = MaterialTheme.colorScheme.error)
                } else if (!otherMode) {
                    Text("Bo‘sh stanoklar tepada. Band stanoklar eng tez bo‘shaydiganidan boshlab tartiblangan.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val freeMachines = machines.filter { availability(it.id) == 0 }
                    val busyMachines = machines.filter { availability(it.id) > 0 }
                    if (freeMachines.isNotEmpty()) Text("Bo‘sh stanoklar", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    (freeMachines + busyMachines).forEachIndexed { index, machine ->
                        if (index == freeMachines.size && busyMachines.isNotEmpty()) {
                            Text("Band stanoklar", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        val wait = availability(machine.id)
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable { machineId = machine.id },
                            shape = RoundedCornerShape(14.dp),
                            tonalElevation = if (machine.id == machineId) 4.dp else 1.dp
                        ) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                RadioButton(selected = machine.id == machineId, onClick = { machineId = machine.id })
                                Column(Modifier.weight(1f)) {
                                    val shopName = data.shops.firstOrNull { it.id == machine.shopId }?.name.orEmpty()
                                    Text("${machine.number}-stanok • ${shopName.ifBlank { "Sex" }}${if (machine.capacity > 0) " • sig‘im ${machine.capacity}" else ""}", fontWeight = FontWeight.Bold)
                                    Text(if (wait == 0) "Bo‘sh" else "Band • taxminan ${minutesLabel(wait)} dan keyin bo‘shaydi", color = if (wait == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                TextButton(onClick = { infoMachine = machine }) { Text("Ma’lumot") }
                            }
                        }
                    }
                    selectedMachine?.let { machine ->
                        val wait = availability(machine.id)
                        Text(if (wait == 0) "Tanlangan stanokda ishni darhol boshlash mumkin." else "Tanlangan stanokda boshlanish: taxminan ${minutesLabel(wait)} dan keyin.", fontWeight = FontWeight.SemiBold)
                        val targetIdsForAuto = targetJobs.map { it.id }.toSet()
                        val waitForAuto = data.jobs.filter { it.machineId == machine.id && it.status != TpJobStatus.COMPLETE && it.id !in targetIdsForAuto }.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
                        val autoBrigade = data.autoBrigadeForMachine(machine.id, waitForAuto)
                        if (autoBrigade != null) {
                            val shift = data.shifts.firstOrNull { it.id == autoBrigade.shiftId }
                            Text("Brigada avtomatik: ${autoBrigade.name}${shift?.name?.let { " • $it" }.orEmpty()}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        } else Text("Bu sex uchun smenaga mos brigada topilmadi.", color = MaterialTheme.colorScheme.error)
                        if (editing) {
                            TpField(editReason, { editReason = it }, "Tahrirlash sharhi *", singleLine = false)
                            Text("Tasdiqlangan/rejalangan detalni o‘zgartirish sababi majburiy.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                } else {
                    Text("Boshqa stanok", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                    Text("Bu istisno tajriba, favqulodda yoki majburiy ishlab chiqarish uchun. Sabab audit tarixida saqlanadi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    otherMachines.forEach { machine ->
                        val wait = availability(machine.id)
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable { machineId = machine.id },
                            shape = RoundedCornerShape(14.dp),
                            tonalElevation = if (machine.id == machineId) 4.dp else 1.dp
                        ) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                RadioButton(selected = machine.id == machineId, onClick = { machineId = machine.id })
                                Column(Modifier.weight(1f)) {
                                    val shopName = data.shops.firstOrNull { it.id == machine.shopId }?.name.orEmpty()
                                    Text("${machine.number}-stanok • ${shopName.ifBlank { "Sex" }}", fontWeight = FontWeight.Bold)
                                    Text(if (wait == 0) "Bo‘sh • moslik istisnosi" else "Band • ${minutesLabel(wait)} dan keyin • moslik istisnosi", color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                    TpField(overrideReason, { overrideReason = it }, "Boshqa stanok sababi *", singleLine = false)
                    selectedMachine?.let { machine ->
                        val wait = availability(machine.id)
                        val autoBrigade = data.autoBrigadeForMachine(machine.id, wait)
                        if (autoBrigade == null) Text("Bu stanok sexi uchun smenaga mos brigada topilmadi.", color = MaterialTheme.colorScheme.error)
                    }
                    if (editing) TpField(editReason, { editReason = it }, "Tahrirlash sharhi *", singleLine = false)
                }
                TextButton(onClick = {
                    otherMode = !otherMode
                    machineId = if (otherMode) otherMachines.firstOrNull()?.id.orEmpty() else machines.firstOrNull()?.id.orEmpty()
                }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (otherMode) "← Tavsiya etilgan stanoklar" else "Boshqa stanok")
                }
            }
        },
        confirmButton = { TextButton(enabled = machineId.isNotBlank() && selectedMachine?.let { machine ->
            val ids = targetJobs.map { it.id }.toSet()
            val wait = data.jobs.filter { it.machineId == machine.id && it.status != TpJobStatus.COMPLETE && it.id !in ids }.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
            data.autoBrigadeForMachine(machine.id, wait) != null
        } == true && (!editing || editReason.isNotBlank()) && (!otherMode || overrideReason.isNotBlank()), onClick = {
            if (onSave(machineId, editReason, otherMode, overrideReason)) onDismiss()
        }) { Text(if (editing) "Tahrirlash" else "Tanlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )

    infoMachine?.let { machine ->
        val current = data.activeJobsForMachine(machine.id).firstOrNull { it.id !in targetIds }
        val currentOrder = current?.let { job -> data.orders.firstOrNull { it.id == job.orderId } }
        AlertDialog(
            onDismissRequest = { infoMachine = null },
            title = { Text("${machine.number}-stanok") },
            text = {
                if (current == null) Text("Hozir bo‘sh.") else Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Hozir band", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                    Text("Partiya: ${currentOrder?.batchNumber.orEmpty()}")
                    Text("Artikul: ${currentOrder?.articleSnapshot.orEmpty()}")
                    Text("Mahsulot: ${currentOrder?.productNameSnapshot.orEmpty()}")
                    Text("Detal: ${current.outputs.joinToString { it.detailName }}")
                    Text("Rang: ${current.colorCode}")
                    if (current.resinCode.isNotBlank()) Text("Seryo: ${current.resinCode}")
                    Text("Holat: ${jobStatusLabel(current.status)}")
                    Text("Taxminiy vazifa vaqti: ${minutesLabel(current.estimatedMinutes)}")
                }
            },
            confirmButton = { TextButton(onClick = { infoMachine = null }) { Text("Yopish") } }
        )
    }
}

@Composable
private fun TpFixedMachineAssignDialog(
    data: TpData,
    order: TpOrder,
    targetJobs: List<TpPlanJob>,
    machine: TpMachine,
    editing: Boolean,
    onDismiss: () -> Unit,
    onSave: (String) -> Boolean
) {
    val targetIds = targetJobs.map { it.id }.toSet()
    val waitMinutes = data.jobs.filter { it.machineId == machine.id && it.status != TpJobStatus.COMPLETE && it.id !in targetIds }.sumOf { it.estimatedMinutes.coerceAtLeast(0) }
    val autoBrigade = data.autoBrigadeForMachine(machine.id, waitMinutes)
    var reason by remember(machine.id, order.id, editing) { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${machine.number}-stanokka rejalash") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${order.articleSnapshot} • ${order.productNameSnapshot}", fontWeight = FontWeight.Bold)
            Text(targetJobs.flatMap { it.outputs }.map { it.detailName }.distinct().joinToString())
            if (autoBrigade != null) {
                val shift = data.shifts.firstOrNull { it.id == autoBrigade.shiftId }
                Text("Brigada avtomatik: ${autoBrigade.name}${shift?.name?.let { " • $it" }.orEmpty()}", color = MaterialTheme.colorScheme.primary)
            } else Text("Bu sex uchun smenaga mos brigada topilmadi.", color = MaterialTheme.colorScheme.error)
            Text(if (waitMinutes <= 0) "Stanok bo‘sh — reja hozirgi smenadan boshlanadi." else "Stanok band — navbatdagi ish taxminan ${minutesLabel(waitMinutes)} dan keyin boshlanadi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (editing) TpField(reason, { reason = it }, "Tahrirlash sharhi *", singleLine = false)
        } },
        confirmButton = { TextButton(enabled = autoBrigade != null && (!editing || reason.isNotBlank()), onClick = { if (onSave(reason)) onDismiss() }) { Text("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

@Composable
private fun TpMachineQueuePage(
    data: TpData,
    allWorkers: List<TpWorker>,
    repo: TpDataRepository,
    policy: UserAccessPolicy,
    refresh: () -> Unit
) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_MACHINE)
    var error by remember { mutableStateOf<String?>(null) }
    var expandedMachineId by remember { mutableStateOf<String?>(null) }
    var workerMachine by remember { mutableStateOf<TpMachine?>(null) }
    var downtimeMachine by remember { mutableStateOf<TpMachine?>(null) }
    var endDowntime by remember { mutableStateOf<TpMachineDowntime?>(null) }
    var correctDowntime by remember { mutableStateOf<TpMachineDowntime?>(null) }
    var pendingShiftChange by remember { mutableStateOf<TpShift?>(null) }
    val brigades = data.brigades.filterNot { it.archived }.sortedBy { it.name.lowercase() }
    var brigadeId by remember(brigades) { mutableStateOf(brigades.firstOrNull()?.id.orEmpty()) }
    if (brigadeId.isBlank() && brigades.isNotEmpty()) brigadeId = brigades.first().id
    val brigade = brigades.firstOrNull { it.id == brigadeId }
    val activeShifts = data.shifts.filterNot { it.archived }
    val dayShift = activeShifts.firstOrNull { shift ->
        val n = shift.name.lowercase()
        n.contains("kun") || n.contains("kunduz") || n.contains("day") || n.contains("den")
    } ?: activeShifts.firstOrNull { runCatching { java.time.LocalTime.parse(it.startTime).hour in 5..17 }.getOrDefault(false) }
    val nightShift = activeShifts.firstOrNull { shift ->
        val n = shift.name.lowercase()
        n.contains("tun") || n.contains("tungi") || n.contains("night") || n.contains("noch")
    } ?: activeShifts.firstOrNull { it.id != dayShift?.id }
    // A night shift keeps the previous calendar date as its business date until its configured end time.
    // This lets a 19:00 -> 03:00 worker replacement remain in one shift while timestamps still store the real date.
    val calendarToday = LocalDate.now()
    val previousDate = calendarToday.minusDays(1)
    val continuePreviousNight = nightShift?.let { shift ->
        val start = runCatching { java.time.LocalTime.parse(shift.startTime) }.getOrNull()
        val end = runCatching { java.time.LocalTime.parse(shift.endTime) }.getOrNull()
        val overnight = start != null && end != null && !end.isAfter(start)
        val previousSelected = data.brigadeShiftSelections.any {
            it.brigadeId == brigadeId && it.date == previousDate.toString() && it.shiftId == shift.id
        }
        overnight && previousSelected && end != null && !java.time.LocalTime.now().isAfter(end)
    } == true
    val today = (if (continuePreviousNight) previousDate else calendarToday).toString()
    val shiftSelection = data.brigadeShiftSelections.firstOrNull { it.brigadeId == brigadeId && it.date == today }
    val selectedShiftId = shiftSelection?.shiftId.orEmpty()
    val machines = data.machines.filter { !it.archived && (brigade == null || it.shopId == brigade.shopId) }.sortedBy { it.number }
    val jobsByMachine = data.jobs.filter {
        it.planConfirmedAt != null && it.machineId != null && it.status != TpJobStatus.COMPLETE &&
            (brigadeId.isBlank() || it.brigadeId == brigadeId)
    }.groupBy { it.machineId.orEmpty() }

    fun saveShift(shift: TpShift?) {
        if (shift == null || brigadeId.isBlank()) return
        error = repo.setBrigadeShift(brigadeId, today, shift.id, policy.displayName).exceptionOrNull()?.message
        if (error == null) refresh()
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-machine-queue-v2"))
            .navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (brigades.isEmpty()) {
            Text("Sizga biriktirilgan brigada topilmadi.", color = MaterialTheme.colorScheme.error)
            return@Column
        }
        if (brigades.size > 1) {
            TpChoice("Brigada", brigadeId, brigades, { it.id }, { it.name }) { brigadeId = it }
        } else {
            Text(brigade?.name.orEmpty(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Bugungi smena", fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedShiftId.isNotBlank() && selectedShiftId == dayShift?.id,
                        onClick = { if (canWrite) { if (selectedShiftId.isNotBlank() && selectedShiftId != dayShift?.id) pendingShiftChange = dayShift else saveShift(dayShift) } },
                        enabled = canWrite && dayShift != null,
                        label = { Text("KUN", fontWeight = FontWeight.Bold) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = selectedShiftId.isNotBlank() && selectedShiftId == nightShift?.id,
                        onClick = { if (canWrite) { if (selectedShiftId.isNotBlank() && selectedShiftId != nightShift?.id) pendingShiftChange = nightShift else saveShift(nightShift) } },
                        enabled = canWrite && nightShift != null,
                        label = { Text("TUN", fontWeight = FontWeight.Bold) },
                        modifier = Modifier.weight(1f)
                    )
                }
                if (selectedShiftId.isBlank()) {
                    Text("Ishchi biriktirishdan oldin KUN yoki TUN smenasini belgilang.", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        Text("Stanoklar · ${machines.size}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (machines.isEmpty()) Text("Bu brigada sexiga biriktirilgan stanok topilmadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)

        machines.forEach { machine ->
            val shop = data.shops.firstOrNull { it.id == machine.shopId }
            val jobs = jobsByMachine[machine.id].orEmpty().sortedWith(compareBy<TpPlanJob> { it.status != TpJobStatus.IN_PROGRESS }.thenBy { it.priority })
            val activeJob = jobs.firstOrNull { it.status == TpJobStatus.IN_PROGRESS }
            val nextJob = jobs.firstOrNull { it.status != TpJobStatus.IN_PROGRESS }
            val displayJob = activeJob ?: nextJob
            val activeAssignments = data.machineWorkerAssignments.filter {
                it.machineId == machine.id && it.brigadeId == brigadeId && it.date == today && it.isActive
            }.sortedBy { it.startedAt }
            val workerHistory = data.machineWorkerAssignments.filter {
                it.machineId == machine.id && it.brigadeId == brigadeId && it.date == today
            }.sortedByDescending { it.startedAt }
            val activeStop = data.machineDowntimes.firstOrNull { it.machineId == machine.id && it.brigadeId == brigadeId && it.isActive }
            val plannedStop = activeStop?.reason?.let { it in setOf("Qolip almashdi", "Rang almashdi", "Sozlash") } == true
            val todayStops = data.machineDowntimes.filter { it.machineId == machine.id && it.brigadeId == brigadeId && it.date == today }
            val expanded = expandedMachineId == machine.id
            val order = displayJob?.let { job -> data.orders.firstOrNull { it.id == job.orderId } }
            val remainingShots = displayJob?.let { job -> tpRemainingShots(data, job) } ?: 0
            val remainingMinutes = displayJob?.let { job -> kotlin.math.ceil(remainingShots * job.cycleSeconds / 60.0).toInt() } ?: 0

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (activeStop != null) (if (plannedStop) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error).copy(alpha = .55f) else MaterialTheme.colorScheme.outlineVariant
                ),
                shadowElevation = 1.dp
            ) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${shop?.name.orEmpty()} · ${machine.number}-stanok", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text(if (machine.capacity > 0) "${machine.capacity} klass" else machine.name.ifBlank { "Stanok" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = when {
                                activeStop != null -> if (plannedStop) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.errorContainer
                                activeJob != null -> MaterialTheme.colorScheme.primaryContainer
                                else -> MaterialTheme.colorScheme.surfaceVariant
                            }
                        ) {
                            Text(
                                when {
                                    activeStop != null -> "TO‘XTAGAN · ${minutesCompact(activeStop.durationMinutes())}"
                                    activeJob != null -> "ISHDA"
                                    nextJob != null -> "NAVBATDA"
                                    else -> "BO‘SH"
                                },
                                Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            Icons.Rounded.Group,
                            contentDescription = null,
                            modifier = Modifier.padding(top = 3.dp).size(19.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(7.dp))
                        Column(
                            Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            if (activeAssignments.isEmpty()) {
                                Text(
                                    "Ishchi biriktirilmagan",
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.error
                                )
                            } else {
                                activeAssignments.forEach { assignment ->
                                    Text(
                                        assignment.workerNameSnapshot,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                        if (canWrite) {
                            val workerActionLabel = when (activeAssignments.size) {
                                0 -> "Ishchi qo‘shish"
                                1 -> "Ishchi"
                                else -> "Ishchilar · ${activeAssignments.size}"
                            }
                            TextButton(
                                enabled = selectedShiftId.isNotBlank(),
                                onClick = { workerMachine = machine }
                            ) { Text(workerActionLabel, maxLines = 1) }
                        }
                    }

                    if (activeStop != null) {
                        Surface(shape = RoundedCornerShape(12.dp), color = (if (plannedStop) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.errorContainer).copy(alpha = .72f)) {
                            Column(Modifier.fillMaxWidth().padding(11.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(activeStop.reason, fontWeight = FontWeight.Bold)
                                Text("O‘chdi: ${activeStop.stoppedAt}${activeStop.note.takeIf { it.isNotBlank() }?.let { " · $it" }.orEmpty()}", style = MaterialTheme.typography.bodySmall)
                                if (canWrite) Button(onClick = { endDowntime = activeStop }, Modifier.fillMaxWidth()) { Text("Ishga tushdi") }
                            }
                        }
                    }

                    if (displayJob != null && order != null) {
                        Text(if (activeJob != null) "Hozir chiqmoqda" else "Navbatdagi ish", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${order.articleSnapshot} · ${order.productNameSnapshot}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("${displayJob.outputs.joinToString { it.detailName }} · ${displayJob.colorCode}")
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .62f)) {
                                Text("Qoldi: $remainingShots jim", Modifier.padding(horizontal = 9.dp, vertical = 5.dp), fontWeight = FontWeight.SemiBold)
                            }
                            Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                                Text("≈ ${minutesLabel(remainingMinutes)}", Modifier.padding(horizontal = 9.dp, vertical = 5.dp), fontWeight = FontWeight.SemiBold)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            AssistChip(onClick = {}, enabled = false, label = { Text("Plan ✓") })
                            AssistChip(
                                onClick = {}, enabled = false,
                                label = { Text(if (displayJob.materialStatus == TpMaterialStatus.DELIVERED) "Seryo ✓" else "Seryo kutilmoqda") }
                            )
                        }
                    } else {
                        Text("Hozirgi plan yo‘q", color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold)
                    }

                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        if (canWrite && activeStop == null) {
                            OutlinedButton(onClick = { downtimeMachine = machine }) { Text("To‘xtatish") }
                        }
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { expandedMachineId = if (expanded) null else machine.id }) {
                            Text(if (expanded) "Yopish" else "Batafsil")
                            Spacer(Modifier.width(4.dp))
                            Icon(if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, contentDescription = null)
                        }
                    }

                    if (expanded) {
                        HorizontalDivider()
                        Text("Batafsil", fontWeight = FontWeight.Bold)
                        if (displayJob != null) {
                            Text("Seryo turi: ${displayJob.feedstockType.displayName()} · ${displayJob.resinCode.ifBlank { "—" }}")
                            Text("Plan: ${if (displayJob.planConfirmedAt != null) "bor" else "yo‘q"} · Seryo: ${materialStatusLabel(displayJob.materialStatus)}")
                        }
                        if (nextJob != null && nextJob.id != activeJob?.id) {
                            val nextOrder = data.orders.firstOrNull { it.id == nextJob.orderId }
                            Text("Keyingi zakaz", fontWeight = FontWeight.SemiBold)
                            Text("${nextOrder?.articleSnapshot.orEmpty()} · ${nextOrder?.productNameSnapshot.orEmpty()}")
                            Text("${nextJob.outputs.joinToString { it.detailName }} · ${nextJob.colorCode}", style = MaterialTheme.typography.bodySmall)
                            Text("Plan ✓ · ${if (nextJob.materialStatus == TpMaterialStatus.DELIVERED) "Seryo ✓" else "Seryo kutilmoqda"}", style = MaterialTheme.typography.bodySmall)
                        } else if (activeJob != null) {
                            Text("Keyingi zakaz yo‘q", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        val closedStops = todayStops.filterNot { it.isActive }
                        Text("Bugungi to‘xtash: ${todayStops.size} ta · ${minutesCompact(todayStops.sumOf { it.durationMinutes() })}", style = MaterialTheme.typography.bodySmall)
                        closedStops.takeLast(4).forEach { stop ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("${stop.stoppedAt}–${stop.startedAt} · ${stop.reason} · ${minutesCompact(stop.durationMinutes())}", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                if (canWrite) TextButton(onClick = { correctDowntime = stop }) { Text("Tuzatish") }
                            }
                        }
                        Text("Bugungi ishchi tarixi: ${workerHistory.size} yozuv", style = MaterialTheme.typography.bodySmall)
                        workerHistory.take(6).forEach { row ->
                            Text("${row.workerNameSnapshot}: ${assignmentTimeLabel(row.startedAt)}–${row.endedAt?.let(::assignmentTimeLabel) ?: "hozir"}${if (row.source == "LOANED") " · Yonlanma" else ""}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
        TpError(error)
    }

    pendingShiftChange?.let { shift ->
        AlertDialog(
            onDismissRequest = { pendingShiftChange = null },
            title = { Text("Smenani o‘zgartirish") },
            text = { Text("Bugungi smena allaqachon belgilangan. Uni ${if (shift.id == dayShift?.id) "KUN" else "TUN"} ga o‘zgartirasizmi? Mavjud yozuvlar auditda saqlanadi.") },
            confirmButton = { TextButton(onClick = { saveShift(shift); pendingShiftChange = null }) { Text("O‘zgartirish") } },
            dismissButton = { TextButton(onClick = { pendingShiftChange = null }) { Text("Bekor qilish") } }
        )
    }

    workerMachine?.let { machine ->
        val active = data.machineWorkerAssignments.filter { it.machineId == machine.id && it.brigadeId == brigadeId && it.date == today && it.isActive }
        val assignmentHistory = data.machineWorkerAssignments.filter { it.machineId == machine.id && it.brigadeId == brigadeId && it.date == today }
        val ownWorkers = allWorkers.filter { !it.archived && it.brigadeId == brigadeId }.sortedBy { it.name }
        var showAll by remember(machine.id) { mutableStateOf(false) }
        val suggestedStart = when {
            assignmentHistory.isNotEmpty() -> java.time.LocalTime.now().withSecond(0).withNano(0).toString()
            selectedShiftId == dayShift?.id -> "07:40"
            selectedShiftId == nightShift?.id -> "19:00"
            else -> java.time.LocalTime.now().withSecond(0).withNano(0).toString()
        }
        var startTime by remember(machine.id, selectedShiftId, assignmentHistory.size) { mutableStateOf(suggestedStart) }
        var selectedWorkerId by remember(machine.id) { mutableStateOf<String?>(null) }
        var selectedName by remember(machine.id) { mutableStateOf("") }
        var selectedSource by remember(machine.id) { mutableStateOf("BRIGADE") }
        var addExtra by remember(machine.id) { mutableStateOf(false) }
        var endingAssignment by remember(machine.id) { mutableStateOf<TpMachineWorkerAssignment?>(null) }
        var endTime by remember(machine.id) { mutableStateOf(java.time.LocalTime.now().withSecond(0).withNano(0).toString()) }
        AlertDialog(
            onDismissRequest = { workerMachine = null },
            title = { Text("${machine.number}-stanok · Ishchilar") },
            text = {
                Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    if (active.isNotEmpty()) {
                        Text("Hozir ishlayapti", fontWeight = FontWeight.Bold)
                        active.forEach { row ->
                            Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .55f)) {
                                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) { Text(row.workerNameSnapshot, fontWeight = FontWeight.SemiBold); Text("${assignmentTimeLabel(row.startedAt)} dan", style = MaterialTheme.typography.bodySmall) }
                                    TextButton(onClick = { endingAssignment = row; endTime = java.time.LocalTime.now().withSecond(0).withNano(0).toString() }) { Text("Tugatish") }
                                }
                            }
                        }
                    }
                    if (endingAssignment != null) {
                        Text("${endingAssignment?.workerNameSnapshot}: tugash vaqti", fontWeight = FontWeight.SemiBold)
                        CompactTimeEditor(endTime, { endTime = it }, "Tugash vaqti")
                        Button(onClick = {
                            val row = endingAssignment
                            if (row != null) {
                                error = repo.endMachineWorkerAssignment(row.id, endTime).exceptionOrNull()?.message
                                if (error == null) { endingAssignment = null; refresh() }
                            }
                        }, enabled = isValidClockTime(endTime), modifier = Modifier.fillMaxWidth()) { Text("Vaqtni saqlash") }
                    }
                    HorizontalDivider()
                    Text(if (active.isEmpty()) "Ishchi tanlang" else "Ishchini almashtirish yoki qo‘shish", fontWeight = FontWeight.Bold)
                    CompactTimeEditor(startTime, { startTime = it }, "Boshlagan vaqt")
                    ownWorkers.forEach { worker ->
                        val alreadyActive = active.any { it.workerId == worker.id }
                        OutlinedButton(
                            onClick = { selectedWorkerId = worker.id; selectedName = worker.name; selectedSource = "BRIGADE" },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !alreadyActive
                        ) {
                            Text(worker.name, Modifier.weight(1f))
                            if (alreadyActive) Text("Faol") else if (selectedWorkerId == worker.id) Text("✓")
                        }
                    }
                    OutlinedButton(onClick = { selectedWorkerId = null; selectedName = "Yonlanma"; selectedSource = "LOANED" }, Modifier.fillMaxWidth()) {
                        Text("Yonlanma", Modifier.weight(1f)); if (selectedSource == "LOANED" && selectedName == "Yonlanma") Text("✓")
                    }
                    OutlinedButton(onClick = { showAll = !showAll }, Modifier.fillMaxWidth()) { Text(if (showAll) "Boshqa ishchilarni yopish" else "Boshqa…") }
                    if (showAll) {
                        allWorkers.filter { !it.archived && it.brigadeId != brigadeId }.sortedBy { it.name }.forEach { worker ->
                            val alreadyActive = active.any { it.workerId == worker.id }
                            OutlinedButton(
                                onClick = { selectedWorkerId = worker.id; selectedName = worker.name; selectedSource = "OTHER" },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !alreadyActive
                            ) {
                                Text(worker.name, Modifier.weight(1f))
                                if (alreadyActive) Text("Faol") else if (selectedWorkerId == worker.id) Text("✓")
                            }
                        }
                    }
                    if (active.isNotEmpty()) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(addExtra, { addExtra = it }); Text("Mavjud ishchilarni qoldirib, yana ishchi qo‘shish") }
                    }
                    TpError(error)
                }
            },
            confirmButton = {
                Button(
                    enabled = selectedName.isNotBlank() && isValidClockTime(startTime) && selectedShiftId.isNotBlank(),
                    onClick = {
                        error = repo.addMachineWorkerAssignment(
                            machine.id, brigadeId, selectedShiftId, today, selectedWorkerId, selectedName, selectedSource, startTime,
                            replaceExisting = active.isNotEmpty() && !addExtra
                        ).exceptionOrNull()?.message
                        if (error == null) { workerMachine = null; refresh() }
                    }
                ) { Text(if (active.isNotEmpty() && !addExtra) "Almashtirish" else "Ishchini qo‘shish") }
            },
            dismissButton = { TextButton(onClick = { workerMachine = null }) { Text("Yopish") } }
        )
    }

    downtimeMachine?.let { machine ->
        val reasons = listOf("Qolip almashdi", "Sozlash", "Shnek tiqildi", "Remont", "Rang almashdi", "Boshqa")
        var stoppedAt by remember(machine.id) { mutableStateOf(java.time.LocalTime.now().withSecond(0).withNano(0).toString()) }
        var reason by remember(machine.id) { mutableStateOf(reasons.first()) }
        var note by remember(machine.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { downtimeMachine = null },
            title = { Text("${machine.number}-stanok · To‘xtatish") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                TpField(stoppedAt, { stoppedAt = timeInput(it) }, "O‘chgan vaqt (HH:mm)")
                Text("Sabab", fontWeight = FontWeight.SemiBold)
                reasons.chunked(2).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { row.forEach { item -> FilterChip(selected = reason == item, onClick = { reason = item }, label = { Text(item) }) } } }
                TpField(note, { note = it }, "Izoh (ixtiyoriy)", singleLine = false)
            } },
            confirmButton = { TextButton(enabled = stoppedAt.length == 5 && brigadeId.isNotBlank(), onClick = {
                error = repo.startMachineDowntime(machine.id, brigadeId, today, stoppedAt, reason, note).exceptionOrNull()?.message
                if (error == null) { downtimeMachine = null; refresh() }
            }) { Text("Saqlash") } },
            dismissButton = { TextButton(onClick = { downtimeMachine = null }) { Text("Bekor qilish") } }
        )
    }

    endDowntime?.let { stop ->
        var startedAt by remember(stop.id) { mutableStateOf(java.time.LocalTime.now().withSecond(0).withNano(0).toString()) }
        AlertDialog(
            onDismissRequest = { endDowntime = null },
            title = { Text("Stanok ishga tushdi") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("O‘chgan: ${stop.stoppedAt} · ${stop.reason}"); TpField(startedAt, { startedAt = timeInput(it) }, "Yongan vaqt (HH:mm)") } },
            confirmButton = { TextButton(enabled = startedAt.length == 5, onClick = {
                error = repo.endMachineDowntime(stop.id, startedAt).exceptionOrNull()?.message
                if (error == null) { endDowntime = null; refresh() }
            }) { Text("Saqlash") } },
            dismissButton = { TextButton(onClick = { endDowntime = null }) { Text("Bekor qilish") } }
        )
    }

    correctDowntime?.let { stop ->
        val reasons = listOf("Qolip almashdi", "Sozlash", "Shnek tiqildi", "Remont", "Rang almashdi", "Boshqa")
        var stoppedAt by remember(stop.id) { mutableStateOf(stop.stoppedAt) }
        var startedAt by remember(stop.id) { mutableStateOf(stop.startedAt) }
        var reason by remember(stop.id) { mutableStateOf(stop.reason) }
        var note by remember(stop.id) { mutableStateOf(stop.note) }
        var correctionReason by remember(stop.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { correctDowntime = null },
            title = { Text("To‘xtash yozuvini tuzatish") },
            text = { Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Yozuv o‘chirilmaydi. Tuzatish sababi auditda saqlanadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                TpField(stoppedAt, { stoppedAt = timeInput(it) }, "O‘chgan vaqt")
                TpField(startedAt, { startedAt = timeInput(it) }, "Yongan vaqt")
                reasons.forEach { item -> FilterChip(selected = reason == item, onClick = { reason = item }, label = { Text(item) }) }
                TpField(note, { note = it }, "Izoh (ixtiyoriy)", singleLine = false)
                TpField(correctionReason, { correctionReason = it }, "Tuzatish sababi *", singleLine = false)
            } },
            confirmButton = { TextButton(enabled = stoppedAt.length == 5 && startedAt.length == 5 && correctionReason.isNotBlank(), onClick = {
                error = repo.correctMachineDowntime(stop.id, stoppedAt, startedAt, reason, note, correctionReason).exceptionOrNull()?.message
                if (error == null) { correctDowntime = null; refresh() }
            }) { Text("Saqlash") } },
            dismissButton = { TextButton(onClick = { correctDowntime = null }) { Text("Bekor qilish") } }
        )
    }
}

private fun tpRemainingShots(data: TpData, job: TpPlanJob): Int = job.outputs.maxOfOrNull { output ->
    val received = data.receipts.filter { !it.isCancelled && it.jobId == job.id && it.detailId == output.detailId }.sumOf { it.creditedPieces }
    val missing = (output.requiredPieces - received).coerceAtLeast(0)
    kotlin.math.ceil(missing.toDouble() / output.piecesPerShot.coerceAtLeast(1)).toInt()
} ?: 0

private fun minutesCompact(minutes: Int): String = when {
    minutes < 60 -> "$minutes daq"
    minutes % 60 == 0 -> "${minutes / 60} soat"
    else -> "${minutes / 60} soat ${minutes % 60} daq"
}

private fun timeInput(value: String): String = value.filter { it.isDigit() || it == ':' }.take(5)

private fun isValidClockTime(value: String): Boolean = runCatching { java.time.LocalTime.parse(value) }.isSuccess

private fun assignmentTimeLabel(value: String): String =
    runCatching { java.time.LocalDateTime.parse(value).toLocalTime().toString() }
        .recoverCatching { java.time.LocalTime.parse(value).toString() }
        .getOrDefault(value)

@Composable
private fun CompactTimeEditor(value: String, onValueChange: (String) -> Unit, label: String) {
    val parts = value.split(":", limit = 2)
    val hour = parts.getOrElse(0) { "" }
    val minute = parts.getOrElse(1) { "" }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                value = hour, onValueChange = { raw ->
                    val h = raw.filter(Char::isDigit).take(2)
                    onValueChange("$h:$minute")
                },
                modifier = Modifier.width(78.dp), singleLine = true,
                label = { Text("Soat") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            Text(":", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = minute, onValueChange = { raw ->
                    val m = raw.filter(Char::isDigit).take(2)
                    onValueChange("$hour:$m")
                },
                modifier = Modifier.width(78.dp), singleLine = true,
                label = { Text("Daq") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        }
    }
}

@Composable
private fun TpAttendancePage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val context = LocalContext.current
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_ATTENDANCE)
    val deepLinkedDate = remember { TpNavigationTargetState.consumeAttendanceDate() }
    var date by remember {
        mutableStateOf(
            deepLinkedDate?.let { runCatching { LocalDate.parse(it) }.getOrNull() }?.takeIf { it.isBefore(LocalDate.now()) }?.toString()
                ?: LocalDate.now().minusDays(1).toString()
        )
    }
    val activeShifts = data.shifts.filterNot { it.archived }
    val dayShift = activeShifts.firstOrNull { shift ->
        shift.name.lowercase().let { it.contains("kun") || it.contains("kunduz") || it.contains("day") || it.contains("den") }
    } ?: activeShifts.firstOrNull { runCatching { java.time.LocalTime.parse(it.startTime).hour in 5..17 }.getOrDefault(false) }
    val nightShift = activeShifts.firstOrNull { shift ->
        shift.id != dayShift?.id && shift.name.lowercase().let { it.contains("tun") || it.contains("tungi") || it.contains("night") || it.contains("noch") }
    } ?: activeShifts.firstOrNull { it.id != dayShift?.id }
    var shiftId by remember(activeShifts) { mutableStateOf(dayShift?.id ?: nightShift?.id.orEmpty()) }
    val selectedShift = activeShifts.firstOrNull { it.id == shiftId }
    val shiftLabel = when (shiftId) {
        dayShift?.id -> "KUN"
        nightShift?.id -> "TUN"
        else -> selectedShift?.name.orEmpty().ifBlank { "Smena" }
    }

    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    var shopId by remember { mutableStateOf("") }
    val brigades = data.brigades.filterNot { it.archived }
        .filter { data.brigadeShiftIdForDate(it.id, date) == shiftId && (shopId.isBlank() || it.shopId == shopId) }
        .sortedBy { it.name }
    var brigadeId by remember(shopId, shiftId) { mutableStateOf("") }
    val visibleBrigadeIds = brigades.map { it.id }.toSet()
    val workers = data.workers.filter {
        !it.archived && it.brigadeId in visibleBrigadeIds && (brigadeId.isBlank() || it.brigadeId == brigadeId)
    }.sortedBy { it.name }

    val dayState = data.attendanceDay(date, shiftId)
    val selectedDate = runCatching { LocalDate.parse(date) }.getOrElse { LocalDate.now().minusDays(1) }
    val deadline = selectedDate.plusDays(1).atTime(9, 0)
    val overdue = dayState?.isClosed != true && !java.time.LocalDateTime.now().isBefore(deadline)
    val statusIcon = if (dayState?.isClosed == true) Icons.Rounded.Lock else if (overdue) Icons.Rounded.WarningAmber else Icons.Rounded.LockOpen

    var filtersOpen by remember { mutableStateOf(false) }
    var noteOpen by remember { mutableStateOf(false) }
    var noteText by remember(dayState?.id, dayState?.updatedAt) { mutableStateOf(dayState?.note.orEmpty()) }
    var closeDialog by remember { mutableStateOf(false) }
    var closeReason by remember { mutableStateOf("") }
    var reopenDialog by remember { mutableStateOf(false) }
    var editWorker by remember { mutableStateOf<TpWorker?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    fun openDatePicker() {
        val current = runCatching { LocalDate.parse(date) }.getOrElse { LocalDate.now().minusDays(1) }
        android.app.DatePickerDialog(
            context,
            { _, year, month, day -> date = LocalDate.of(year, month + 1, day).toString() },
            current.year, current.monthValue - 1, current.dayOfMonth
        ).apply {
            datePicker.maxDate = java.time.ZoneId.systemDefault().let { zone ->
                LocalDate.now().atStartOfDay(zone).toInstant().toEpochMilli() - 1L
            }
        }.show()
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpScreens-attendance-v2"))
            .navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 7.dp, bottom = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                val shopText = shops.firstOrNull { it.id == shopId }?.name ?: "Barcha bo‘limlar"
                val brigadeText = brigades.firstOrNull { it.id == brigadeId }?.name ?: "Barcha brigadalar"
                val compactDate = runCatching { LocalDate.parse(date).format(java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy")) }.getOrDefault(date)
                Text("$shopText · $brigadeText · $compactDate · $shiftLabel", Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                Box {
                    IconButton(onClick = { filtersOpen = true }) { Icon(Icons.Rounded.Tune, contentDescription = "Filtrlar") }
                    DropdownMenu(expanded = filtersOpen, onDismissRequest = { filtersOpen = false }) {
                        Column(Modifier.width(310.dp).padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Text("Davomat konteksti", fontWeight = FontWeight.Bold)
                            TpChoice("Bo‘lim", shopId, listOf(TpShop("", "Barcha bo‘limlar")) + shops, { it.id }, { it.name }) {
                                shopId = it; brigadeId = ""
                            }
                            TpChoice("Brigada", brigadeId, listOf(TpBrigade("", "", shiftId, "Barcha brigadalar")) + brigades, { it.id }, { it.name }) { brigadeId = it }
                            OutlinedButton(onClick = { filtersOpen = false; openDatePicker() }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Rounded.CalendarMonth, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Sana: $compactDate", Modifier.weight(1f))
                            }
                            Text("Smena", fontWeight = FontWeight.SemiBold)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = shiftId == dayShift?.id,
                                    enabled = dayShift != null,
                                    onClick = { dayShift?.let { shiftId = it.id; brigadeId = "" } },
                                    label = { Text("KUN", fontWeight = FontWeight.Bold) },
                                    modifier = Modifier.weight(1f)
                                )
                                FilterChip(
                                    selected = shiftId == nightShift?.id,
                                    enabled = nightShift != null,
                                    onClick = { nightShift?.let { shiftId = it.id; brigadeId = "" } },
                                    label = { Text("TUN", fontWeight = FontWeight.Bold) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }

        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val compactActions = maxWidth < 420.dp
            val closedTime = dayState?.closedAt?.let { value ->
                runCatching {
                    java.time.LocalDateTime.parse(value).toLocalTime()
                        .format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"))
                }.getOrNull()
            }
            val displayStatusText = when {
                dayState?.isClosed == true -> "Yopilgan${closedTime?.let { " · $it" }.orEmpty()}"
                overdue -> if (compactActions) "Muddat o‘tgan" else "Yopilmagan · muddat o‘tgan"
                dayState?.isReopened == true -> "Qayta ochilgan"
                else -> "Ochiq"
            }
            val actionText = when {
                dayState?.isClosed == true -> if (compactActions) "Ochish" else "Qayta ochish"
                dayState?.isReopened == true -> if (compactActions) "Yopish" else "Qayta yopish"
                else -> if (compactActions) "Yopish" else "Kunni yopish"
            }

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                AssistChip(
                    onClick = {},
                    label = { Text(displayStatusText, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    leadingIcon = { Icon(statusIcon, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )

                if (compactActions) {
                    IconButton(
                        onClick = { noteText = dayState?.note.orEmpty(); noteOpen = true },
                        enabled = shiftId.isNotBlank()
                    ) {
                        BadgedBox(
                            badge = { if (!dayState?.note.isNullOrBlank()) Badge() }
                        ) {
                            Icon(Icons.Rounded.ChatBubbleOutline, contentDescription = "Izoh")
                        }
                    }
                } else {
                    AssistChip(
                        onClick = { noteText = dayState?.note.orEmpty(); noteOpen = true },
                        label = { Text(if (dayState?.note.isNullOrBlank()) "Izoh" else "Izoh •", maxLines = 1) },
                        leadingIcon = { Icon(Icons.Rounded.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        enabled = shiftId.isNotBlank()
                    )
                }

                if (canWrite && shiftId.isNotBlank()) {
                    if (dayState?.isClosed == true) {
                        OutlinedButton(onClick = { reopenDialog = true }) {
                            Text(actionText, maxLines = 1)
                        }
                    } else {
                        Button(onClick = { closeReason = ""; closeDialog = true }) {
                            Text(actionText, maxLines = 1)
                        }
                    }
                }
            }
        }
        if (workers.isEmpty()) Text("Tanlangan filtrda ishchi yo‘q.", color = MaterialTheme.colorScheme.onSurfaceVariant)

        val fullWorkers = workers.filter { worker -> data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }.let { day -> day == null || (day.present && day.minusHours <= 0.0) } }
        val minusWorkers = workers.filter { worker -> data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }?.let { it.present && it.minusHours > 0.0 } == true }
        val absentWorkers = workers.filter { worker -> data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }?.present == false }
        val groups = listOf("To‘liq ishlagan" to fullWorkers, "Minus soati bor" to minusWorkers, "Ishlamagan" to absentWorkers)
        groups.forEachIndexed { groupIndex, (groupTitle, groupWorkers) ->
            if (groupIndex > 0) HorizontalDivider(Modifier.padding(vertical = 4.dp))
            Text(groupTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (groupWorkers.isEmpty()) Text("—", color = MaterialTheme.colorScheme.onSurfaceVariant)
            groupWorkers.forEach { worker ->
                val day = data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }
                val actualMinutes = if (day == null) data.workerStandardMinutes(worker.id, date) else data.attendanceWorkMinutes(worker.id, date)
                TpCard(Modifier.clickable(enabled = canWrite && dayState?.isClosed != true) { editWorker = worker }) {
                    Text(worker.name, fontWeight = FontWeight.Bold)
                    Text(data.brigades.firstOrNull { it.id == worker.brigadeId }?.name.orEmpty(), style = MaterialTheme.typography.bodySmall)
                    Text(when {
                        day == null -> "To‘liq ishlagan (standart) • ${data.workerStandardMinutes(worker.id, date)} daqiqa"
                        !day.present -> "Ishlamadi"
                        day.minusHours > 0.0 -> "Minus ${formatTpNumber(day.minusHours)} soat • hisobdagi ish vaqti $actualMinutes daqiqa"
                        else -> "To‘liq ishlagan • $actualMinutes daqiqa"
                    })
                    Text("Umumiy kunlik norma: ${data.globalDailyTargetAmount()} so‘m", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        TpError(error)
    }

    if (noteOpen) {
        AlertDialog(
            onDismissRequest = { noteOpen = false },
            title = { Text("$date · $shiftLabel · Izoh") },
            text = { TpField(noteText, { noteText = it }, "Izoh", singleLine = false, enabled = dayState?.isClosed != true && canWrite) },
            confirmButton = {
                if (canWrite && dayState?.isClosed != true) TextButton(onClick = {
                    val result = repo.updateAttendanceDayNote(date, shiftId, noteText, policy.displayName)
                    error = result.exceptionOrNull()?.message
                    if (result.isSuccess) { noteOpen = false; refresh() }
                }) { Text("Saqlash") }
                else TextButton(onClick = { noteOpen = false }) { Text("Yopish") }
            },
            dismissButton = { if (canWrite && dayState?.isClosed != true) TextButton(onClick = { noteOpen = false }) { Text("Bekor qilish") } }
        )
    }

    if (closeDialog) {
        val reasonRequired = overdue || (dayState?.reopenCount ?: 0) > 0
        AlertDialog(
            onDismissRequest = { closeDialog = false },
            title = { Text("$date · $shiftLabel davomatini yopish") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Yopilgandan keyin ma’lumotlar read-only bo‘ladi. Kerak bo‘lsa davomadchi keyin qayta ochishi mumkin.")
                if (reasonRequired) TpField(closeReason, { closeReason = it }, if (overdue) "Kechikib yopish sababi *" else "Qayta yopish sababi *", singleLine = false)
            } },
            confirmButton = { TextButton(enabled = !reasonRequired || closeReason.isNotBlank(), onClick = {
                val result = repo.closeAttendanceDay(date, shiftId, policy.displayName, closeReason)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { closeDialog = false; refresh() }
            }) { Text("Yopish") } },
            dismissButton = { TextButton(onClick = { closeDialog = false }) { Text("Bekor qilish") } }
        )
    }

    if (reopenDialog) {
        AlertDialog(
            onDismissRequest = { reopenDialog = false },
            title = { Text("Davomatni qayta ochish") },
            text = { Text("$date · $shiftLabel qayta ochiladi. Keyingi xodim ma’lumoti o‘zgarishida sabab yozish majburiy bo‘ladi.") },
            confirmButton = { TextButton(onClick = {
                val result = repo.reopenAttendanceDay(date, shiftId, policy.displayName)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { reopenDialog = false; refresh() }
            }) { Text("Qayta ochish") } },
            dismissButton = { TextButton(onClick = { reopenDialog = false }) { Text("Bekor qilish") } }
        )
    }

    editWorker?.let { worker ->
        val existing = data.attendance.firstOrNull { it.workerId == worker.id && it.date == date }
        var present by remember(worker.id, date) { mutableStateOf(existing?.present ?: true) }
        var minusHours by remember(worker.id, date) { mutableStateOf(existing?.minusHours?.takeIf { it > 0.0 }?.let(::formatTpNumber) ?: "") }
        var editReason by remember(worker.id, date, dayState?.reopenCount) { mutableStateOf("") }
        val standardMinutes = data.workerStandardMinutes(worker.id, date)
        val parsedMinus = minusHours.toDoubleOrNull() ?: 0.0
        val calculated = if (present) (standardMinutes - kotlin.math.round(parsedMinus * 60.0).toInt()).coerceAtLeast(0) else 0
        val reasonRequired = dayState?.isReopened == true
        AlertDialog(
            onDismissRequest = { editWorker = null },
            title = { Text(worker.name) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Smena bo‘yicha standart: ${minutesLabel(standardMinutes)}")
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Ishda", Modifier.weight(1f)); Switch(present, { present = it; if (!it) minusHours = "" }) }
                TpField(minusHours, { minusHours = decimalInput(it) }, "Minus soat", KeyboardType.Decimal, enabled = present)
                Text("Hisoblanadigan ish vaqti: ${minutesLabel(calculated)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (reasonRequired) TpField(editReason, { editReason = it }, "O‘zgartirish sababi *", singleLine = false)
            } },
            confirmButton = { TextButton(enabled = !reasonRequired || editReason.isNotBlank(), onClick = {
                val result = repo.setAttendance(worker.id, date, present, minusHours.toDoubleOrNull() ?: 0.0, policy.displayName, editReason)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { editWorker = null; refresh() }
            }) { Text("Saqlash") } },
            dismissButton = { TextButton(onClick = { editWorker = null }) { Text("Bekor qilish") } }
        )
    }
}

@Composable
private fun TpExtraHoursPage(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, refresh: () -> Unit) {
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_EXTRA_HOURS)
    val brigades = data.brigades.filterNot { it.archived }.sortedBy { it.name }
    var brigadeId by remember(brigades) { mutableStateOf(brigades.firstOrNull()?.id.orEmpty()) }
    var selectedDate by remember { mutableStateOf(LocalDate.now().toString()) }
    var editType by remember { mutableStateOf<TpExtraHourType?>(null) }
    var showTypeDialog by remember { mutableStateOf(false) }
    var selectedWorker by remember { mutableStateOf<TpWorker?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val visibleBrigades = brigades.take(6)
    if (brigadeId.isBlank() && visibleBrigades.isNotEmpty()) brigadeId = visibleBrigades.first().id
    val workers = data.workers.filter { !it.archived && it.brigadeId == brigadeId }.sortedBy { it.name }
    val types = data.extraHourTypes.filterNot { it.archived }.sortedBy { it.name }

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpExtraHours"))
            .navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Qo‘shimcha soat turlari va narxlari", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Qo‘shimcha soat yozuvi bo‘lmasa ishchi ma’lumoti to‘liq hisoblanadi; bu majburiy maydon emas.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (canWrite) Button(onClick = { editType = null; showTypeDialog = true }, Modifier.fillMaxWidth()) { Text("+ Qo‘shimcha soat turi / narxi") }
        if (types.isEmpty()) Text("Hali qo‘shimcha soat turi kiritilmagan.")
        types.forEach { type ->
            TpCard(Modifier.clickable(enabled = canWrite) { editType = type; showTypeDialog = true }) {
                Text(type.name, fontWeight = FontWeight.Bold)
                Text("${formatTpNumber(type.hourlyRate)} so‘m / soat")
            }
        }
        HorizontalDivider()
        Text("Brigada", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (visibleBrigades.isNotEmpty()) TpFilterRow(visibleBrigades, brigadeId, { it.id }, { it.name }) { brigadeId = it }
        if (brigades.size > 6) Text("Birinchi 6 ta faol brigada ko‘rsatildi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        TpDatePickerButton("Sana", selectedDate) { selectedDate = it }
        Text("Ishchilar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (workers.isEmpty()) Text("Tanlangan brigadada ishchi yo‘q.")
        workers.forEach { worker ->
            val rows = data.extraHours.filter { it.workerId == worker.id && it.date == selectedDate }
            val extra = rows.sumOf { it.amount }
            TpCard(Modifier.clickable(enabled = canWrite && types.isNotEmpty()) { selectedWorker = worker }) {
                Text(worker.name, fontWeight = FontWeight.Bold)
                if (rows.isNotEmpty()) {
                    Text("Qo‘shimcha: ${rows.sumOf { it.hours }.let(::formatTpNumber)} soat • $extra so‘m", color = MaterialTheme.colorScheme.primary)
                    rows.forEach { row -> Text("${row.typeNameSnapshot}: ${formatTpNumber(row.hours)} soat × ${formatTpNumber(row.hourlyRateSnapshot)} = ${row.amount} so‘m", style = MaterialTheme.typography.bodySmall) }
                } else Text("Qo‘shimcha soat yo‘q", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Jami topgan: ${data.workerEarned(worker.id, selectedDate)} so‘m", style = MaterialTheme.typography.bodySmall)
            }
        }
        TpError(error)
    }

    if (showTypeDialog) {
        var name by remember(editType?.id) { mutableStateOf(editType?.name.orEmpty()) }
        var rate by remember(editType?.id) { mutableStateOf(editType?.hourlyRate?.let(::formatTpNumber).orEmpty()) }
        AlertDialog(
            onDismissRequest = { showTypeDialog = false },
            title = { Text(if (editType == null) "Qo‘shimcha soat turi" else "Tur va narxni tahrirlash") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TpField(name, { name = it }, "Turi")
                TpField(rate, { rate = decimalInput(it) }, "1 soat narxi (so‘m)", KeyboardType.Decimal)
            } },
            confirmButton = { TextButton(onClick = {
                val result = repo.saveExtraHourType(editType?.id, name, rate.toDoubleOrNull() ?: 0.0)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { showTypeDialog = false; refresh() }
            }) { Text("Saqlash") } },
            dismissButton = { TextButton(onClick = { showTypeDialog = false }) { Text("Bekor qilish") } }
        )
    }

    selectedWorker?.let { worker ->
        var date by remember(worker.id) { mutableStateOf(selectedDate) }
        var typeId by remember(worker.id, types) { mutableStateOf(types.firstOrNull()?.id.orEmpty()) }
        var hours by remember(worker.id) { mutableStateOf("") }
        var note by remember(worker.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { selectedWorker = null },
            title = { Text(worker.name) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TpDatePickerButton("Sana", date) { date = it }
                TpChoice("Qo‘shimcha soat turi", typeId, types, { it.id }, { "${it.name} • ${formatTpNumber(it.hourlyRate)} so‘m/soat" }) { typeId = it }
                TpField(hours, { hours = decimalInput(it) }, "Qo‘shimcha soat", KeyboardType.Decimal)
                TpField(note, { note = it }, "Izoh (ixtiyoriy)", singleLine = false)
                val rate = types.firstOrNull { it.id == typeId }?.hourlyRate ?: 0.0
                val amount = (hours.toDoubleOrNull() ?: 0.0) * rate
                if (amount > 0) Text("Hisob: ${amount.toLong()} so‘m", color = MaterialTheme.colorScheme.primary)
            } },
            confirmButton = { TextButton(onClick = {
                val result = repo.addWorkerExtraHour(worker.id, date, typeId, hours.toDoubleOrNull() ?: 0.0, note)
                error = result.exceptionOrNull()?.message
                if (result.isSuccess) { selectedDate = date; selectedWorker = null; refresh() }
            }) { Text("Saqlash") } },
            dismissButton = { TextButton(onClick = { selectedWorker = null }) { Text("Bekor qilish") } }
        )
    }
}

@Composable
internal fun TpNavRow(title: String, badgeCount: Int = 0, onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            if (badgeCount > 0) {
                Surface(shape = RoundedCornerShape(999.dp), color = MaterialTheme.colorScheme.error) {
                    Text(badgeCount.coerceAtMost(999).toString(), Modifier.padding(horizontal = 8.dp, vertical = 2.dp), color = MaterialTheme.colorScheme.onError, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(8.dp))
            }
            Text("›", style = MaterialTheme.typography.headlineSmall)
        }
    }
}

@Composable
internal fun TpCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outline.copy(alpha = 0.62f)
        ),
        tonalElevation = 0.dp,
        shadowElevation = 2.dp
    ) {
        Column(
            Modifier.padding(horizontal = 14.dp, vertical = 13.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            content = content
        )
    }
}

@Composable
internal fun TpField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    enabled: Boolean = true
) {
    val numeric = keyboardType == KeyboardType.Number || keyboardType == KeyboardType.Decimal
    var focusedBefore by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        modifier = Modifier.fillMaxWidth().onFocusChanged { state ->
            if (numeric && state.isFocused && !focusedBefore && value.trim() in setOf("0", "0.0", "0.00")) onChange("")
            focusedBefore = state.isFocused
        },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType), singleLine = singleLine, enabled = enabled
    )
}

@Composable
internal fun <T> TpChoice(
    label: String,
    selectedId: String,
    options: List<T>,
    id: (T) -> String,
    text: (T) -> String,
    onSelect: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val selected = options.firstOrNull { id(it) == selectedId }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: ${selected?.let(text) ?: "Tanlang"}", Modifier.weight(1f))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(text(option)) }, onClick = { open = false; onSelect(id(option)) }) }
        }
    }
}

@Composable
internal fun TpError(message: String?) {
    if (!message.isNullOrBlank()) Text(message, color = MaterialTheme.colorScheme.error)
}

internal fun digitsOnly(value: String): String = value.filter(Char::isDigit)
internal fun decimalInput(value: String): String {
    var separator = false
    return buildString {
        value.forEach { char ->
            if (char.isDigit()) append(char)
            else if ((char == '.' || char == ',') && !separator) { append('.'); separator = true }
        }
    }
}
private fun tpBrigadirTimingLabel(job: TpPlanJob): String {
    val planned = minutesLabel(job.estimatedMinutes.coerceAtLeast(0))
    val started = job.startedAt?.let { runCatching { java.time.LocalDateTime.parse(it) }.getOrNull() }
        ?: return "Taxminiy davomiylik: $planned"
    val finish = started.plusMinutes(job.estimatedMinutes.coerceAtLeast(0).toLong())
    val remaining = java.time.Duration.between(java.time.LocalDateTime.now(), finish).toMinutes().coerceAtLeast(0L).toInt()
    val finishTime = finish.format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"))
    return "Taxminiy tugash: $finishTime • qolgan ${minutesLabel(remaining)}"
}

internal fun minutesLabel(minutes: Int): String = "${minutes / 60} soat ${minutes % 60} daqiqa"
internal fun orderStatusLabel(status: TpOrderStatus): String = when (status) {
    TpOrderStatus.NEW -> "Yangi"
    TpOrderStatus.PLANNING, TpOrderStatus.READY, TpOrderStatus.APPROVED -> "Rejalashda"
    TpOrderStatus.IN_PROGRESS -> "Ishlab chiqarishda"
    TpOrderStatus.COMPLETE -> "Yakunlangan"
    TpOrderStatus.CANCELLED -> "Bekor qilingan"
}
internal fun jobStatusLabel(status: TpJobStatus): String = when (status) {
    TpJobStatus.UNASSIGNED -> "Taqsimlanmagan"; TpJobStatus.QUEUED -> "Navbatda"; TpJobStatus.IN_PROGRESS -> "Ishda"
    TpJobStatus.COMPLETE -> "Yakunlangan"; TpJobStatus.HOLD -> "To‘xtagan"
}

internal fun jobOperationalStatusLabel(job: TpPlanJob, completeReady: Boolean = false): String = when {
    job.status == TpJobStatus.COMPLETE -> "Yakunlangan"
    job.status == TpJobStatus.HOLD -> "To‘xtagan"
    job.status == TpJobStatus.IN_PROGRESS && completeReady -> "Yakunlashga tayyor"
    job.status == TpJobStatus.IN_PROGRESS -> "Ishda"
    job.planConfirmedAt != null && job.materialStatus != TpMaterialStatus.DELIVERED -> "Seryo kutilmoqda"
    job.status == TpJobStatus.QUEUED && job.materialStatus == TpMaterialStatus.DELIVERED -> "Boshlashga tayyor"
    else -> jobStatusLabel(job.status)
}
internal fun materialStatusLabel(status: TpMaterialStatus): String = when (status) {
    TpMaterialStatus.PLANNED -> "Tayyorlanmagan"; TpMaterialStatus.CONFIRMED -> "Tayyor"; TpMaterialStatus.DELIVERED -> "Stanokka chiqarilgan"
}
