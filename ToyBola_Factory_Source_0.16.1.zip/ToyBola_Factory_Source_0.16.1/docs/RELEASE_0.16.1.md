# ToyBola Factory 0.16.1

## Asosiy o‘zgarishlar

### Davomat
- DA-009–DA-012 implement qilindi.
- Status/Izoh/Yopish qatori responsive va kompakt.
- `Kunni yopish` tor ekranda vertikal siqilmaydi.
- Izoh mavjudligi badge bilan ko‘rsatiladi; matn preview’i asosiy ro‘yxatni pastga itarmaydi.
- Yopilgan holatda yopilgan vaqt ko‘rinadi; qayta ochilganda `Qayta yopish` action’i ishlatiladi.

### Brigada boshqaruvi
- BR-044–BR-046 implement qilindi.
- Faol ishchilar stanok kartasida pastma-past ko‘rinadi.
- Action `Ishchi qo‘shish / Ishchi / Ishchilar · N` ga moslashadi.
- Duplicate active worker assignment UI va repository darajasida bloklanadi.

## Versiya
- versionCode: 1601
- versionName: 0.16.1
