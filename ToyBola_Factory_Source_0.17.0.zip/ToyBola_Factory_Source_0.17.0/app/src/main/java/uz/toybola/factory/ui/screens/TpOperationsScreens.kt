@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package uz.toybola.factory.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.firebase.AccessGuard
import uz.toybola.factory.core.firebase.DailyIssueImageStorage
import uz.toybola.factory.core.firebase.TpDataEvents
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.core.security.scopedFor
import uz.toybola.factory.core.security.canSeryoApproval
import uz.toybola.factory.core.security.canSeryoDelivery
import uz.toybola.factory.core.security.canSeryoReceipt
import uz.toybola.factory.core.security.canSeryoStock
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.components.IssueImageBlock
import uz.toybola.factory.ui.components.IssueImageGallery
import uz.toybola.factory.ui.components.IssueImagePickerButton
import uz.toybola.factory.ui.model.AppStrings
import uz.toybola.factory.ui.navigation.TpNavigationTargetState
import uz.toybola.factory.ui.navigation.NavigationGuardState
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.ZoneOffset
import java.util.UUID

private enum class TpSeryoPage { ROOT, DAILY, ORDERS, PREPARATION, STOCK }
private enum class TpDailyPage { ROOT, BREAKAGE, RETURNED, COMPENSATION }
private enum class TpStockPage { BALANCE, IN, OUT }

@Composable
fun TpSeryoScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val serverRevision by TpDataEvents.revision.collectAsState()
    var revision by remember { mutableIntStateOf(0) }
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(serverRevision, revision, policy.revision) { repository.load().scopedFor(policy) }
    val canApprove = policy.canSeryoApproval()
    val canDeliver = policy.canSeryoDelivery()
    val canReceive = policy.canSeryoReceipt()
    val canStock = policy.canSeryoStock()
    var page by remember { mutableStateOf(TpSeryoPage.ROOT) }
    var stockPage by remember { mutableStateOf(TpStockPage.BALANCE) }
    var dailyPage by remember { mutableStateOf(TpDailyPage.ROOT) }
    LaunchedEffect(Unit) {
        val targetJob = TpNavigationTargetState.consumeJobId()
        if (targetJob != null && data.jobs.any { it.id == targetJob }) page = TpSeryoPage.PREPARATION
    }
    fun refresh() { revision++ }
    fun goBackOneLevel() {
        when {
            page == TpSeryoPage.DAILY && dailyPage != TpDailyPage.ROOT -> dailyPage = TpDailyPage.ROOT
            page != TpSeryoPage.ROOT -> page = TpSeryoPage.ROOT
            else -> onBack()
        }
    }
    BackHandler(enabled = page != TpSeryoPage.ROOT || dailyPage != TpDailyPage.ROOT) { goBackOneLevel() }

    Column(Modifier.fillMaxSize()) {
        AppTopBar("Seryo", canGoBack = true, onMenu = {}, onBack = ::goBackOneLevel)
        when (page) {
            TpSeryoPage.ROOT -> Column(
                Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpSeryo-root"))
                    .navigationBarsPadding().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val orderBadge = data.jobs.count { it.planConfirmedAt != null && it.resinConfirmedAt == null && it.status != TpJobStatus.COMPLETE }
                val prepBadge = data.jobs.count { it.resinConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED && it.status != TpJobStatus.COMPLETE }
                TpNavRow("1. Kundalik amallar") { page = TpSeryoPage.DAILY; dailyPage = TpDailyPage.ROOT }
                TpNavRow("2. Buyurtma", orderBadge) { page = TpSeryoPage.ORDERS }
                TpNavRow("3. Tayyorlash va yetkazish", prepBadge + data.seryoCompensations.count { !it.isComplete() }) { page = TpSeryoPage.PREPARATION }
                TpNavRow("4. Ostatka markazi") { page = TpSeryoPage.STOCK; stockPage = TpStockPage.BALANCE }
                val negative = data.materials.count { !it.archived && data.materialStock(it.type, it.code) < -0.000001 }
                if (negative > 0) Text("⚠ Minus ostatka: $negative ta material", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            }
            TpSeryoPage.DAILY -> when (dailyPage) {
                TpDailyPage.ROOT -> TpSeryoDailyRoot({ dailyPage = TpDailyPage.BREAKAGE }, { dailyPage = TpDailyPage.RETURNED }, { dailyPage = TpDailyPage.COMPENSATION })
                TpDailyPage.BREAKAGE -> TpBreakageReceivePage(data, repository, canReceive, ::refresh)
                TpDailyPage.RETURNED -> TpReturnedRecycledPage(data, repository, canReceive, ::refresh)
                TpDailyPage.COMPENSATION -> TpSeryoCompensationPage(data, repository, canReceive, ::refresh)
            }
            TpSeryoPage.ORDERS -> TpSeryoOrders(data, repository, canApprove, ::refresh)
            TpSeryoPage.PREPARATION -> TpMaterialPreparationV2Page(data, repository, canDeliver, ::refresh)
            TpSeryoPage.STOCK -> Column(Modifier.fillMaxSize()) {
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                    val tabs = listOf(TpStockPage.BALANCE to "Ostatka", TpStockPage.IN to "Kirim", TpStockPage.OUT to "Chiqim")
                    tabs.forEachIndexed { index, (tab, label) ->
                        SegmentedButton(selected = stockPage == tab, onClick = { stockPage = tab }, shape = SegmentedButtonDefaults.itemShape(index, tabs.size)) { Text(label) }
                    }
                }
                when (stockPage) {
                    TpStockPage.BALANCE -> TpMaterialBalancePage(data)
                    TpStockPage.IN -> TpMaterialMovementPage(data, repository, canStock, incoming = true, refresh = ::refresh)
                    TpStockPage.OUT -> TpMaterialMovementPage(data, repository, canStock, incoming = false, refresh = ::refresh)
                }
            }
        }
    }
}

@Composable
private fun TpSeryoOrders(data: TpData, repository: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var selectedOrderId by remember { mutableStateOf<String?>(null) }
    var expandedOrderId by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var shortageJobId by remember { mutableStateOf<String?>(null) }
    var alternativeJobId by remember { mutableStateOf<String?>(null) }
    var extraJobId by remember { mutableStateOf<String?>(null) }
    val today = LocalDate.now().toString()
    var historyDate by remember { mutableStateOf(today) }
    fun historyEventAt(order: TpOrder): String {
        val delivered = data.jobs.filter { it.orderId == order.id }.mapNotNull { it.materialDeliveredAt }.maxOrNull().orEmpty()
        return order.cancelledAt?.takeIf { it.isNotBlank() } ?: delivered.ifBlank { order.createdAt }
    }
    val historyOrders = data.orders.filter {
        it.status in setOf(TpOrderStatus.COMPLETE, TpOrderStatus.CANCELLED) && historyEventAt(it).startsWith(historyDate)
    }.sortedByDescending(::historyEventAt)
    val orders = data.orders.filter { order ->
        order.status != TpOrderStatus.COMPLETE && order.status != TpOrderStatus.CANCELLED &&
            data.jobs.any { it.orderId == order.id && it.planConfirmedAt != null }
    }
    val pending = orders.filter { order ->
        val all = data.jobs.filter { it.orderId == order.id }
        all.any { it.planConfirmedAt != null && it.resinConfirmedAt == null } || all.any { it.planConfirmedAt == null }
    }.sortedWith(compareBy<TpOrder> { it.priority }.thenBy { it.createdAt })
    val confirmed = orders.filter { order ->
        val jobs = data.jobs.filter { it.orderId == order.id }
        jobs.isNotEmpty() && jobs.all { it.planConfirmedAt != null && it.resinConfirmedAt != null }
    }.sortedByDescending { order -> data.jobs.filter { it.orderId == order.id }.maxOfOrNull { it.resinConfirmedAt.orEmpty() }.orEmpty() }
    val selected = orders.firstOrNull { it.id == selectedOrderId }

    BackHandler(enabled = selected != null) { selectedOrderId = null }
    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState(if (selected == null) "TpSeryo-order-list" else "TpSeryo-order-${selected.id}"))
            .navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (selected == null) {
            Text("Seryo brigadiri", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Plan tasdiqlangan zakazlar. Har bir detal/rang seryosi alohida tasdiqlanadi; tasdiqlangan vazifa darhol tayyorlovchiga o‘tadi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Tasdiqlash kerak", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (pending.isEmpty()) Text("Tasdiqlashni kutayotgan zakaz yo‘q.")
            pending.forEach { order ->
                val waiting = data.jobs.filter { it.orderId == order.id && it.planConfirmedAt != null && it.resinConfirmedAt == null }
                TpCard {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).clickable { selectedOrderId = order.id }) {
                            TpSeryoOrderSummary(data, order)
                            Text("Tasdiqlanmagan: ${waiting.size} ta", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
                        }
                        TextButton(onClick = { expandedOrderId = if (expandedOrderId == order.id) null else order.id }) {
                            Text(if (expandedOrderId == order.id) "▲" else "▼", style = MaterialTheme.typography.titleLarge)
                        }
                    }
                    if (expandedOrderId == order.id) {
                        HorizontalDivider(Modifier.padding(vertical = 6.dp))
                        waiting.sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id }).forEach { job ->
                            Text("• ${job.outputs.joinToString { it.detailName }} • rang ${job.colorCode}", style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { selectedOrderId = order.id }) { Text("Seryoni tanlash") }
                    }
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Text("Tasdiqlangan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (confirmed.isEmpty()) Text("Hali to‘liq tasdiqlangan zakaz yo‘q.")
            confirmed.forEach { order ->
                TpCard(Modifier.clickable { selectedOrderId = order.id }) {
                    TpSeryoOrderSummary(data, order)
                    Text("✓ Barcha detal/ranglar yordamchilarga topshirilgan", color = MaterialTheme.colorScheme.primary)
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Text("Tarix", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { historyDate = LocalDate.parse(historyDate).minusDays(1).toString() }) { Text("‹") }
                Text(historyDate, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.SemiBold)
                OutlinedButton(enabled = historyDate < today, onClick = { historyDate = LocalDate.parse(historyDate).plusDays(1).coerceAtMost(LocalDate.now()).toString() }) { Text("›") }
                TextButton(enabled = historyDate != today, onClick = { historyDate = today }) { Text("Bugun") }
            }
            if (historyOrders.isEmpty()) Text("$historyDate sanasida yakunlangan yoki bekor qilingan zakaz yo‘q.")
            historyOrders.forEach { order ->
                TpCard {
                    TpSeryoOrderSummary(data, order)
                    Text(
                        if (order.status == TpOrderStatus.CANCELLED) "Bekor qilingan${order.cancelReason.takeIf { it.isNotBlank() }?.let { ": $it" }.orEmpty()}" else "Yakunlangan",
                        color = if (order.status == TpOrderStatus.CANCELLED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        } else {
            TextButton(onClick = { selectedOrderId = null }) { Text("‹ Buyurtmalar") }
            TpCard { TpSeryoOrderSummary(data, selected) }
            val jobs = data.jobs.filter { it.orderId == selected.id && it.planConfirmedAt != null }.sortedWith(compareBy<TpPlanJob> { it.priority }.thenBy { it.id })
            jobs.forEach { job ->
                val machine = data.machines.firstOrNull { it.id == job.machineId }
                val shop = machine?.let { m -> data.shops.firstOrNull { it.id == m.shopId } }
                val options = seryoOptionsForJob(data, job)
                val recycledOptions = recycledOptionsForJob(data, job)
                TpCard {
                    Text(job.outputs.joinToString { it.detailName }, fontWeight = FontWeight.Bold)
                    Text("Rang ${job.colorCode} • ${job.outputs.sumOf { it.requiredPieces }} dona")
                    Text("Stanok: ${machine?.number ?: 0} • ${shop?.name.orEmpty()}")
                    Text("Kerak: ${formatTpNumber(job.totalResinKg)} kg xomashyo • krasitel alohida hisoblanadi")
                    if (job.totalResinKg > 0) Text("Seryo ishlatilsa: 25 kg ga ${formatTpNumber((job.totalColorGrams * 25.0 / job.totalResinKg) / 1000.0)} kg krasitel", style = MaterialTheme.typography.bodySmall)
                    if (job.resinConfirmedAt == null && canWrite) {
                        Text("Oddiy seryo", fontWeight = FontWeight.SemiBold)
                        TpChoice("Seryo turi", if (job.resinSelectedAt != null && job.feedstockType == TpMaterialType.RESIN) job.resinCode else "", options, { it }, { code ->
                            "$code • ostatka ${formatTpNumber(data.materialStock(TpMaterialType.RESIN, code))} kg"
                        }) { selectedCode ->
                            error = repository.setJobFeedstock(job.id, TpMaterialType.RESIN, selectedCode).exceptionOrNull()?.message
                            if (error == null) refresh()
                        }
                        if (recycledOptions.isNotEmpty()) {
                            Text("yoki Ftarichka", fontWeight = FontWeight.SemiBold)
                            TpChoice("Ftarichka turi", if (job.resinSelectedAt != null && job.feedstockType == TpMaterialType.RECYCLED) job.resinCode else "", recycledOptions, { it }, { code ->
                                "$code • ostatka ${formatTpNumber(data.materialStock(TpMaterialType.RECYCLED, code))} kg"
                            }) { selectedCode ->
                                error = repository.setJobFeedstock(job.id, TpMaterialType.RECYCLED, selectedCode).exceptionOrNull()?.message
                                if (error == null) refresh()
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { alternativeJobId = job.id }, enabled = job.feedstockType == TpMaterialType.RESIN, modifier = Modifier.weight(1f)) { Text("Boshqa seryo") }
                            OutlinedButton(onClick = { extraJobId = job.id }, enabled = job.resinSelectedAt != null && job.feedstockType == TpMaterialType.RESIN, modifier = Modifier.weight(1f)) { Text("+ Qo‘shimcha") }
                        }
                        if (job.alternativeResin) Text("Boshqa seryo: " + job.resinCode, color = MaterialTheme.colorScheme.primary)
                        if (job.feedstockType == TpMaterialType.RESIN) ResinAdditionSummary(job)
                        if (job.resinSelectedAt != null && job.resinCode.isNotBlank()) {
                            val feedstockStock = data.materialStock(job.feedstockType, job.resinCode)
                            val colorStock = data.materialStock(TpMaterialType.COLOR, job.colorCode)
                            val shortage = feedstockStock + 1e-9 < job.totalResinKg || (job.feedstockType == TpMaterialType.RESIN && colorStock + 1e-9 < job.totalColorGrams)
                            if (shortage) Text(
                                "⚠ Ostatka yetmaydi: ${job.resinCode} ${formatTpNumber(feedstockStock)} kg${if (job.feedstockType == TpMaterialType.RESIN) " • ${job.colorCode} ${formatTpNumber(TpMaterialType.COLOR.operationalKg(colorStock))} kg" else ""}",
                                color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall
                            )
                            Button(onClick = {
                                if (shortage) shortageJobId = job.id
                                else {
                                    error = repository.confirmJobResin(job.id, false).exceptionOrNull()?.message
                                    if (error == null) refresh()
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("✓ Shu detal/rangni tasdiqlash") }
                        }
                    } else {
                        Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.padding(10.dp)) {
                                Text(if (job.resinConfirmedAt != null) "✓ ${job.feedstockType.displayName()} ${job.resinCode} tasdiqlangan — tayyorlovchiga yuborildi" else "Xomashyo tanlanishi va tasdiqlanishi kutilmoqda", fontWeight = FontWeight.SemiBold)
                                if (job.feedstockType == TpMaterialType.RESIN) ResinAdditionSummary(job)
                            }
                        }
                    }
                }
            }
            val remaining = jobs.count { it.resinConfirmedAt == null }
            if (remaining == 0 && jobs.isNotEmpty()) {
                Text("✓ Zakazning barcha detali tasdiqlandi", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            } else Text("Tasdiqlanmagan detal/rang: $remaining ta", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        TpError(error)
    }

    alternativeJobId?.let { jobId ->
        AlternativeResinDialog(data, onDismiss = { alternativeJobId = null }) { code ->
            val result = repository.setJobResin(jobId, code, allowAlternative = true)
            if (result.isSuccess) { refresh(); alternativeJobId = null }
            result.exceptionOrNull()?.message
        }
    }
    extraJobId?.let { jobId ->
        val job = data.jobs.firstOrNull { it.id == jobId }
        if (job != null) ResinExtraDialog(job, onDismiss = { extraJobId = null }) { kind, amount ->
            val result = repository.addJobResin(jobId, kind, amount)
            if (result.isSuccess) { refresh(); extraJobId = null }
            result.exceptionOrNull()?.message
        }
    }

    shortageJobId?.let { jobId ->
        val job = data.jobs.firstOrNull { it.id == jobId }
        if (job != null) {
            val resinStock = data.materialStock(job.feedstockType, job.resinCode)
            val colorStock = data.materialStock(TpMaterialType.COLOR, job.colorCode)
            AlertDialog(
                onDismissRequest = { shortageJobId = null },
                title = { Text("Ostatka yetarli emas") },
                text = { Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    if (resinStock + 1e-9 < job.totalResinKg) Text("• ${job.resinCode}: kerak ${formatTpNumber(job.totalResinKg)} kg, bor ${formatTpNumber(resinStock)} kg", color = MaterialTheme.colorScheme.error)
                    if (job.feedstockType == TpMaterialType.RESIN && colorStock + 1e-9 < job.totalColorGrams) Text("• ${job.colorCode}: kerak ${formatTpNumber(TpMaterialType.COLOR.operationalKg(job.totalColorGrams))} kg, bor ${formatTpNumber(TpMaterialType.COLOR.operationalKg(colorStock))} kg", color = MaterialTheme.colorScheme.error)
                    Text("Baribir tasdiqlasangiz aynan shu detal/rang tayyorlovchi oynasiga o‘tadi.")
                } },
                confirmButton = { TextButton(onClick = {
                    error = repository.confirmJobResin(jobId, true).exceptionOrNull()?.message
                    if (error == null) refresh()
                    shortageJobId = null
                }) { Text("Baribir tasdiqlash") } },
                dismissButton = { TextButton(onClick = { shortageJobId = null }) { Text("Bekor qilish") } }
            )
        }
    }
}

@Composable
private fun TpSeryoOrderSummary(data: TpData, order: TpOrder) {
    val progress = data.orderProgress(order.id)
    Text("${order.batchNumber} • ${order.articleSnapshot}", fontWeight = FontWeight.Bold)
    Text(order.productNameSnapshot)
    Text("${order.quantity} dona • ${tpPriorityLabel(order.priority)}")
    Text("Plan tasdiq: ${order.planApprovedAt?.take(16)?.replace('T', ' ') ?: "—"}", style = MaterialTheme.typography.bodySmall)
    if (progress > 0) Text("Bajarilish: ${progress.toInt()}%", color = MaterialTheme.colorScheme.primary)
}

private fun seryoOptionsForJob(data: TpData, job: TpPlanJob): List<String> {
    val sets = job.outputs.mapNotNull { output ->
        data.products.asSequence().flatMap { it.details.asSequence() }.firstOrNull { it.id == output.detailId }?.resinOptions()?.toSet()
    }
    if (sets.isEmpty()) return listOfNotNull(job.resinCode.takeIf { it.isNotBlank() })
    return sets.drop(1).fold(sets.first()) { acc, set -> acc intersect set }.sorted()
}

private fun recycledOptionsForJob(data: TpData, job: TpPlanJob): List<String> {
    val details = job.outputs.mapNotNull { output ->
        data.products.asSequence().flatMap { it.details.asSequence() }.firstOrNull { it.id == output.detailId }
    }
    if (details.isEmpty()) return emptyList()
    if (details.any { !it.allowsAnyRecycled() && it.explicitRecycledOptions().isEmpty() }) return emptyList()
    val explicitSets = details.filterNot { it.allowsAnyRecycled() }.map { detail -> detail.explicitRecycledOptions().map { it.uppercase() }.toSet() }
    val allowed = if (explicitSets.isEmpty()) null else explicitSets.drop(1).fold(explicitSets.first()) { acc, set -> acc intersect set }
    // Keep the same order as Ostatka/master-data, as requested by the warehouse flow.
    return data.materials.asSequence()
        .filter { !it.archived && it.type == TpMaterialType.RECYCLED && (allowed == null || it.code.uppercase() in allowed) }
        .map { it.code }
        .distinct()
        .toList()
}

private fun orderMaterialShortages(data: TpData, orderId: String): List<String> {
    val jobs = data.jobs.filter { it.orderId == orderId }
    val resin = jobs.groupBy { it.resinCode }.mapValues { (_, rows) -> rows.sumOf { it.totalResinKg } }
    val color = jobs.groupBy { it.colorCode }.mapValues { (_, rows) -> rows.sumOf { it.totalColorGrams } }
    return buildList {
        resin.forEach { (code, need) ->
            val stock = data.materialStock(TpMaterialType.RESIN, code)
            if (stock + 1e-9 < need) add("$code seryo — kerak ${formatTpNumber(need)} kg, bor ${formatTpNumber(stock)} kg")
        }
        color.forEach { (code, need) ->
            val stock = data.materialStock(TpMaterialType.COLOR, code)
            if (stock + 1e-9 < need) add("$code krasitel — kerak ${formatTpNumber(TpMaterialType.COLOR.operationalKg(need))} kg, bor ${formatTpNumber(TpMaterialType.COLOR.operationalKg(stock))} kg")
        }
    }
}

@Composable
private fun TpMaterialPreparationPage(data: TpData, repository: TpDataRepository, canWrite: Boolean, refresh: () -> Unit) {
    var error by remember { mutableStateOf<String?>(null) }
    val today = LocalDate.now().toString()
    val pending = data.jobs.filter {
        it.planConfirmedAt != null && it.resinConfirmedAt != null && it.materialStatus != TpMaterialStatus.DELIVERED && it.status != TpJobStatus.COMPLETE
    }.sortedWith(compareBy<TpPlanJob> { it.resinConfirmedAt.orEmpty() }.thenBy { it.priority })
    val done = data.jobs.filter {
        it.planConfirmedAt != null && it.materialStatus == TpMaterialStatus.DELIVERED && it.materialDeliveredAt?.take(10) == today
    }.sortedByDescending { it.materialDeliveredAt.orEmpty() }

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpSeryo-preparation"))
            .navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Tayyorlash kerak", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Eng oldin tushgan buyurtma tepada. Tayyorlanmagan vazifa bajarilguncha shu ro‘yxatda qoladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (pending.isEmpty()) Text("Tayyorlanadigan qorishma yo‘q.")
        pending.forEach { job -> PreparationCard(data, job, canWrite, onDelivered = {
            error = repository.confirmMaterial(job.id, delivered = true).exceptionOrNull()?.message
            if (error == null) refresh()
        }) }
        HorizontalDivider(Modifier.padding(vertical = 6.dp))
        Text("Tayyorlandi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Faqat bugungi yetkazilganlar ko‘rinadi. Birinchi tayyorlangan eng pastda, yangilari uning tepasiga qo‘shiladi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (done.isEmpty()) Text("Bugun hali yetkazilgan vazifa yo‘q.")
        done.forEach { job -> PreparationCard(data, job, false, onDelivered = {}) }
        TpError(error)
    }
}

@Composable
private fun PreparationCard(data: TpData, job: TpPlanJob, canDeliver: Boolean, onDelivered: () -> Unit) {
    val order = data.orders.firstOrNull { it.id == job.orderId }
    val machine = data.machines.firstOrNull { it.id == job.machineId }
    val shop = machine?.let { m -> data.shops.firstOrNull { it.id == m.shopId } }
    val resinStock = data.materialStock(TpMaterialType.RESIN, job.resinCode)
    val colorStock = data.materialStock(TpMaterialType.COLOR, job.colorCode)
    TpCard {
        Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.Bold)
        Text(job.outputs.joinToString { it.detailName })
        Text("${machine?.number ?: 0}-stanok • ${shop?.name.orEmpty()} • rang ${job.colorCode}")
        PreparationQuantity("Seryo", job.resinCode, job.totalResinKg)
        PreparationQuantity("Krasitel", job.colorCode, job.totalColorGrams / 1000.0)
        if (job.materialStatus != TpMaterialStatus.DELIVERED && (resinStock + 1e-9 < job.totalResinKg || colorStock + 1e-9 < job.totalColorGrams)) {
            Text("⚠ Ostatka kam: seryo ${formatTpNumber(resinStock)} kg • krasitel ${formatTpNumber(TpMaterialType.COLOR.operationalKg(colorStock))} kg", color = MaterialTheme.colorScheme.error)
        }
        job.materialDeliveredAt?.let { Text("Yetkazildi: ${it.take(16).replace('T', ' ')}", color = MaterialTheme.colorScheme.primary) }
        if (canDeliver) Button(onClick = onDelivered, modifier = Modifier.fillMaxWidth()) { Text("Yetkazildi") }
    }
}

@Composable
private fun TpMaterialMovementPage(
    data: TpData,
    repository: TpDataRepository,
    canWrite: Boolean,
    incoming: Boolean,
    refresh: () -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var reverseTarget by remember { mutableStateOf<Pair<TpMaterial, TpMaterialMovement>?>(null) }
    val movements = data.materials.flatMap { material ->
        material.movements.filter { movement -> movement.kind == if (incoming) TpMaterialMovementKind.IN else TpMaterialMovementKind.OUT }
            .map { movement -> material to movement }
    }.sortedByDescending { it.second.createdAt }
    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState(if (incoming) "TpSeryo-prixod" else "TpSeryo-rasxod"))
            .navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(if (incoming) "Prixod" else "Rasxod", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Sana va vaqt avtomatik qayd etiladi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (canWrite) Button(onClick = { showDialog = true }, Modifier.fillMaxWidth()) { Text(if (incoming) "+ Prixod kiritish" else "+ Rasxod kiritish") }
        if (!message.isNullOrBlank()) Text(message!!, color = if (message!!.startsWith("Saqlandi")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
        if (movements.isEmpty()) Text("Hali yozuv yo‘q.")
        movements.take(150).forEach { (material, movement) ->
            TpCard {
                Text("${material.code} • ${material.type.displayName()}", fontWeight = FontWeight.Bold)
                Text("${formatTpNumber(material.type.operationalKg(movement.amount))} kg")
                Text(movement.createdAt.take(16).replace('T', ' '), style = MaterialTheme.typography.bodySmall)
                if (movement.sourceJobId != null) Text("Stanokka chiqarilgan", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (movement.note.isNotBlank()) Text(movement.note, style = MaterialTheme.typography.bodySmall)
                val reversed = material.movements.any { it.note.contains("REV:${movement.id}") }
                when {
                    movement.note.startsWith("REV:") -> Text("↩ Teskari tranzaksiya", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    reversed -> Text("↩ Bekor qilingan", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    canWrite -> TextButton(onClick = { reverseTarget = material to movement }) { Text("Tuzatish / bekor qilish") }
                }
            }
        }
    }
    reverseTarget?.let { (material, movement) ->
        MovementReverseDialog(material, movement, onDismiss = { reverseTarget = null }) { reason ->
            val result = repository.reverseMaterialMovement(material.id, movement.id, reason)
            message = result.exceptionOrNull()?.message ?: "Saqlandi — teskari tranzaksiya yaratildi"
            if (result.isSuccess) { reverseTarget = null; refresh() }
        }
    }
    if (showDialog) TpMaterialMovementDialog(data, incoming, onDismiss = { showDialog = false }) { code, type, amount, note ->
        val result = repository.addMaterialMovement(code, type, amount, incoming, note)
        message = result.exceptionOrNull()?.message ?: "Saqlandi"
        if (result.isSuccess) refresh()
        result.isSuccess
    }
}

@Composable
private fun TpMaterialMovementDialog(
    data: TpData,
    incoming: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, TpMaterialType, Double, String) -> Boolean
) {
    var type by remember { mutableStateOf(TpMaterialType.RESIN) }
    var code by remember { mutableStateOf(data.materials.firstOrNull { !it.archived && it.type == TpMaterialType.RESIN }?.code.orEmpty()) }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (incoming) "Prixod" else "Rasxod") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                TpMaterialType.entries.forEachIndexed { index, option ->
                    SegmentedButton(
                        selected = type == option,
                        onClick = {
                            type = option
                            if (!incoming) code = data.materials.firstOrNull { !it.archived && it.type == option }?.code.orEmpty()
                        },
                        shape = SegmentedButtonDefaults.itemShape(index, TpMaterialType.entries.size)
                    ) { Text(option.displayName()) }
                }
            }
            if (incoming) TpField(code, { code = it.uppercase() }, "Kod")
            else TpChoice(
                label = "Kod", selectedId = code,
                options = data.materials.filter { !it.archived && it.type == type }.sortedBy { it.code },
                id = { it.code }, text = { "${it.code} • ostatka ${formatTpNumber(it.operationalStockKg())} kg" }
            ) { code = it }
            TpField(amount, { amount = decimalInput(it) }, "Miqdor (kg)", KeyboardType.Decimal)
            TpField(note, { note = it }, "Izoh (ixtiyoriy)", singleLine = false)
        } },
        confirmButton = { TextButton(onClick = {
            val parsedKg = amount.toDoubleOrNull()
            val internalAmount = parsedKg?.let { if (type == TpMaterialType.COLOR) it * 1000.0 else it }
            if (internalAmount != null && onSave(code, type, internalAmount, note)) onDismiss()
        }) { Text("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

@Composable
private fun TpMaterialBalancePage(data: TpData) {
    val context = LocalContext.current
    val now = remember { LocalDate.now() }
    var type by remember { mutableStateOf(TpMaterialType.RESIN) }
    var year by remember { mutableIntStateOf(now.year) }
    var month by remember { mutableIntStateOf(now.monthValue) }
    var day by remember { mutableIntStateOf(now.dayOfMonth) }
    var search by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf("CODE") }
    var descending by remember { mutableStateOf(false) }
    var exportMessage by remember { mutableStateOf<String?>(null) }

    val safeDay = if (month > 0) day.coerceAtMost(YearMonth.of(year, month).lengthOfMonth()) else 0
    if (safeDay != day) day = safeDay
    val period = remember(year, month, safeDay) { tpStockPeriod(year, month.takeIf { it > 0 }, safeDay.takeIf { month > 0 && it > 0 }) }
    val materials = data.materials.filter { !it.archived && it.type == type && it.code.contains(search.trim(), ignoreCase = true) }
    val sortedMaterials = materials.let { source ->
        val comparator = when (sort) {
            "IN" -> compareBy<TpMaterial> { it.periodIncoming(period) }
            "OUT" -> compareBy<TpMaterial> { it.periodOutgoing(period) }
            "STOCK" -> compareBy<TpMaterial> { it.closingAt(period.to) }
            else -> compareBy<TpMaterial> { it.code }
        }
        if (descending) source.sortedWith(comparator.reversed()) else source.sortedWith(comparator)
    }
    val report = remember(data, type, period, search) { buildTpStockBalanceReport(data, type, period, search) }
    val xlsxLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) { uri ->
        if (uri != null) exportMessage = runCatching { context.contentResolver.openOutputStream(uri)?.use { TpXlsxExporter.write(it, report.asTable()) } ?: error("Fayl ochilmadi"); "Excel saqlandi" }.getOrElse { it.message ?: "Excel saqlanmadi" }
    }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) exportMessage = runCatching { context.contentResolver.openOutputStream(uri)?.use { TpStockPdfExporter.write(it, report) } ?: error("Fayl ochilmadi"); "PDF saqlandi" }.getOrElse { it.message ?: "PDF saqlanmadi" }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpSeryo-balance"))
            .navigationBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Text("Ostatka", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            TpMaterialType.entries.forEachIndexed { index, option ->
                SegmentedButton(type == option, { type = option }, SegmentedButtonDefaults.itemShape(index, TpMaterialType.entries.size)) { Text(option.displayName()) }
            }
        }
        TpStockPeriodSelector(year, month, safeDay, onChange = { y, m, d -> year = y; month = m; day = d })
        Text("Davr: ${period.label}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        TpField(search, { search = it }, "Kod bo‘yicha qidiruv")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(Modifier.weight(1f)) {
                TpChoice("Tartib", sort, listOf("CODE" to "Kod", "IN" to "Prixod", "OUT" to "Rasxod", "STOCK" to "Ostatka"), { it.first }, { it.second }) { sort = it }
            }
            OutlinedButton(onClick = { descending = !descending }) { Text(if (descending) "↓" else "↑") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { xlsxLauncher.launch("ToyBola_${type.displayName()}_${period.label.replace('.', '-')}.xlsx") }, Modifier.weight(1f)) { Text("Excel") }
            OutlinedButton(onClick = { pdfLauncher.launch("ToyBola_${type.displayName()}_${period.label.replace('.', '-')}.pdf") }, Modifier.weight(1f)) { Text("PDF") }
        }
        exportMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
        Text("${type.displayName()} oldi-berdi", fontWeight = FontWeight.Bold)
        Text("Barcha miqdorlar kg da.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        StockHeaderRow()
        sortedMaterials.forEachIndexed { index, material ->
            StockDataRow(
                index + 1, material.code,
                type.operationalKg(material.periodIncoming(period)),
                type.operationalKg(material.periodOutgoing(period)),
                type.operationalKg(material.closingAt(period.to))
            )
            material.movements.maxByOrNull { it.createdAt }?.let { last ->
                Text("Oxirgi oldi-berdi: ${last.createdAt.take(16).replace('T', ' ')} • ${if (last.kind == TpMaterialMovementKind.IN) "Prixod" else "Rasxod"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            HorizontalDivider()
        }
        if (sortedMaterials.isEmpty()) Text("Mos yozuv topilmadi.")
        Text("Ostatka — tanlangan davrning yakuniy holati.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun TpStockPeriodSelector(year: Int, month: Int, day: Int, onChange: (Int, Int, Int) -> Unit) {
    val current = LocalDate.now()
    val years = (current.year - 5..current.year + 1).toList().reversed()
    val months = listOf(0 to "Barcha oylar") + (1..12).map { it to "%02d".format(it) }
    val days = if (month > 0) listOf(0 to "Barcha kunlar") + (1..YearMonth.of(year, month).lengthOfMonth()).map { it to it.toString() } else listOf(0 to "—")
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.weight(1f)) { TpChoice("Yil", year.toString(), years, { it.toString() }, { it.toString() }) { selected -> onChange(selected.toInt(), month, day) } }
        Box(Modifier.weight(1f)) { TpChoice("Oy", month.toString(), months, { it.first.toString() }, { it.second }) { selected -> val m = selected.toInt(); onChange(year, m, if (m == 0) 0 else day.coerceAtMost(YearMonth.of(year, m).lengthOfMonth())) } }
        Box(Modifier.weight(1f)) { TpChoice("Kun", day.toString(), days, { it.first.toString() }, { it.second }) { selected -> onChange(year, month, selected.toInt()) } }
    }
}

@Composable
private fun StockHeaderRow() {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("№", Modifier.weight(.34f), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text("Kod", Modifier.weight(1.08f), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text("Prixod", Modifier.weight(.92f), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text("Rasxod", Modifier.weight(.92f), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text("Ostatka", Modifier.weight(1.02f), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
    HorizontalDivider()
}

@Composable
private fun StockDataRow(index: Int, code: String, incoming: Double, outgoing: Double, stock: Double) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(index.toString(), Modifier.weight(.34f), fontSize = 10.sp, maxLines = 1)
        Text(code, Modifier.weight(1.08f), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Text(formatTpNumber(incoming), Modifier.weight(.92f), fontSize = 10.sp, maxLines = 1)
        Text(formatTpNumber(outgoing), Modifier.weight(.92f), fontSize = 10.sp, maxLines = 1)
        Text(formatTpNumber(stock), Modifier.weight(1.02f), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun TpSeryoMonitoring(data: TpData) {
    val today = LocalDate.now().toString()
    val pendingJobs = data.jobs.filter { it.planConfirmedAt != null && it.status != TpJobStatus.COMPLETE && it.materialStatus != TpMaterialStatus.DELIVERED }
    val feedstockNeeds = pendingJobs.groupBy { it.feedstockType to it.resinCode }.mapValues { (_, rows) -> rows.sumOf { it.requiredResinKg } }
    val colorNeeds = pendingJobs.filter { it.feedstockType == TpMaterialType.RESIN }
        .groupBy { it.colorCode }.mapValues { (_, rows) -> rows.sumOf { it.requiredColorGrams } }
    val shortages = (feedstockNeeds.map { (key, need) -> Triple(key.first, key.second, need) } +
        colorNeeds.map { Triple(TpMaterialType.COLOR, it.key, it.value) })
        .filter { (type, code, need) -> data.materialStock(type, code) + 1e-9 < need }
    val todayInResin = data.materials.filter { it.type == TpMaterialType.RESIN }.sumOf { it.dayIncoming(today) }
    val todayOutResin = data.materials.filter { it.type == TpMaterialType.RESIN }.sumOf { it.dayOutgoing(today) }
    val todayInRecycled = data.materials.filter { it.type == TpMaterialType.RECYCLED }.sumOf { it.dayIncoming(today) }
    val todayOutRecycled = data.materials.filter { it.type == TpMaterialType.RECYCLED }.sumOf { it.dayOutgoing(today) }
    val todayInColor = data.materials.filter { it.type == TpMaterialType.COLOR }.sumOf { it.dayIncoming(today) }
    val todayOutColor = data.materials.filter { it.type == TpMaterialType.COLOR }.sumOf { it.dayOutgoing(today) }
    val recent = data.materials.flatMap { material -> material.movements.map { movement -> material to movement } }.sortedByDescending { it.second.createdAt }.take(20)
    Column(
        Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpSeryo-monitoring"))
            .navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Seryo monitoring", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TpCard(Modifier.weight(1f)) { Text("${pendingJobs.size}", fontWeight = FontWeight.Bold); Text("Faol vazifa") }
            TpCard(Modifier.weight(1f)) { Text("${shortages.size}", fontWeight = FontWeight.Bold); Text("Yetishmovchilik") }
        }
        TpCard { Text("Bugungi seryo", fontWeight = FontWeight.Bold); Text("Prixod ${formatTpNumber(todayInResin)} kg • Rasxod ${formatTpNumber(todayOutResin)} kg") }
        TpCard { Text("Bugungi ftarichka", fontWeight = FontWeight.Bold); Text("Prixod ${formatTpNumber(todayInRecycled)} kg • Rasxod ${formatTpNumber(todayOutRecycled)} kg") }
        TpCard { Text("Bugungi krasitel", fontWeight = FontWeight.Bold); Text("Prixod ${formatTpNumber(TpMaterialType.COLOR.operationalKg(todayInColor))} kg • Rasxod ${formatTpNumber(TpMaterialType.COLOR.operationalKg(todayOutColor))} kg") }
        Text("Holat", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Seryosi tasdiqlanmagan: ${pendingJobs.count { it.resinConfirmedAt == null }} • Tayyorlashda: ${pendingJobs.count { it.resinConfirmedAt != null }}")
        if (shortages.isNotEmpty()) {
            Text("Yetishmayotganlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
            shortages.sortedByDescending { it.third - data.materialStock(it.first, it.second) }.forEach { (type, code, need) ->
                val stock = data.materialStock(type, code)
                TpCard {
                    val needKg = type.operationalKg(need)
                    val stockKg = type.operationalKg(stock)
                    Text(code, fontWeight = FontWeight.Bold)
                    Text("Kerak ${formatTpNumber(needKg)} kg • Bor ${formatTpNumber(stockKg)} kg")
                    Text("Yetmaydi ${formatTpNumber((needKg - stockKg).coerceAtLeast(0.0))} kg", color = MaterialTheme.colorScheme.error)
                }
            }
        }
        Text("Oxirgi harakatlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        recent.forEach { (material, movement) -> Text("${movement.createdAt.take(16).replace('T', ' ')} • ${material.code} • ${if (movement.kind == TpMaterialMovementKind.IN) "+" else "−"}${formatTpNumber(material.type.operationalKg(movement.amount))} kg", style = MaterialTheme.typography.bodySmall) }
    }
}

private fun tpReceivingRecordDate(shift: TpShift?): String {
    val today = LocalDate.now()
    if (shift == null) return today.toString()
    val start = runCatching { LocalTime.parse(shift.startTime) }.getOrNull() ?: return today.toString()
    val end = runCatching { LocalTime.parse(shift.endTime) }.getOrNull() ?: return today.toString()
    val overnight = !end.isAfter(start)
    return if (overnight && !LocalTime.now().isAfter(end)) today.minusDays(1).toString() else today.toString()
}

@Composable
fun TpReceivingScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val serverRevision by TpDataEvents.revision.collectAsState()
    var revision by remember { mutableIntStateOf(0) }
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(serverRevision, revision, policy.revision) { repository.load().scopedFor(policy) }
    val canWrite = policy.isAdmin() || policy.canWrite(AssemblySection.TP_RECEIVING)
    val shifts = data.shifts.filterNot { it.archived }.sortedBy { it.startTime }
    val scopedShiftId = data.brigades.filterNot { it.archived }.map { it.shiftId }.filter { it.isNotBlank() }.distinct().singleOrNull()
    var shiftId by remember(shifts, scopedShiftId) { mutableStateOf(scopedShiftId ?: shifts.firstOrNull()?.id.orEmpty()) }
    var selectedMachineId by remember { mutableStateOf<String?>(null) }
    var receiptMachineId by remember { mutableStateOf<String?>(null) }
    var receiptJobId by remember { mutableStateOf<String?>(null) }
    var editReceiptId by remember { mutableStateOf<String?>(null) }
    var deleteReceiptId by remember { mutableStateOf<String?>(null) }
    var cancelReceiptReason by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    val activeBrigadeIds = data.brigades.filter { !it.archived && it.shiftId == shiftId }.map { it.id }.toSet()
    val jobs = data.jobs.filter { it.brigadeId in activeBrigadeIds && it.machineId != null && it.status == TpJobStatus.IN_PROGRESS }
    val machines = data.machines.filter { !it.archived && jobs.any { job -> job.machineId == it.id } }
    val listScroll = rememberScrollState()
    val recordDate = tpReceivingRecordDate(shifts.firstOrNull { it.id == shiftId })

    fun openReceipt(machineId: String, machineJobs: List<TpPlanJob>) {
        val first = machineJobs.firstOrNull() ?: return
        receiptMachineId = machineId
        receiptJobId = first.id
    }

    BackHandler(enabled = selectedMachineId != null) { selectedMachineId = null }
    Column(Modifier.fillMaxSize()) {
        AppTopBar("Qabul qilish", canGoBack = true, onMenu = {}, onBack = { if (selectedMachineId != null) selectedMachineId = null else onBack() })
        if (selectedMachineId == null) {
            Column(
                Modifier.fillMaxSize().verticalScroll(listScroll).navigationBarsPadding().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Smena", fontWeight = FontWeight.Bold)
                TpFilterRow(shifts, shiftId, { it.id }, { shift ->
                    when {
                        shift.name.contains("kun", true) -> "KUN"
                        shift.name.contains("tun", true) -> "TUN"
                        else -> shift.name
                    }
                }) { shiftId = it }

                message?.let { msg ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (msg.startsWith("Qabul")) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
                    ) {
                        Text(
                            msg,
                            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                            color = if (msg.startsWith("Qabul")) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                if (machines.isEmpty()) {
                    Text("Tanlangan smenada ishlab turgan stanok yo‘q.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    val grouped = machines.groupBy { it.shopId }.entries.sortedBy { entry ->
                        data.shops.firstOrNull { it.id == entry.key }?.name.orEmpty()
                    }
                    grouped.forEach { (shopId, shopMachines) ->
                        val shopName = data.shops.firstOrNull { it.id == shopId }?.name?.ifBlank { "Sex" } ?: "Sex"
                        Surface(
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = .65f)
                        ) {
                            Text(
                                shopName,
                                Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }

                        shopMachines.sortedBy { it.number }.forEach { machine ->
                            val machineJobs = jobs.filter { it.machineId == machine.id }.sortedBy { it.startedAt.orEmpty() }
                            val current = machineJobs.firstOrNull()
                            val order = current?.let { job -> data.orders.firstOrNull { it.id == job.orderId } }
                            val activeAssignments = current?.let { job ->
                                data.machineWorkerAssignments.filter {
                                    it.machineId == machine.id && it.brigadeId == job.brigadeId && it.shiftId == shiftId &&
                                        it.date == recordDate && it.isActive
                                }.sortedBy { it.startedAt }
                            }.orEmpty()
                            val workerNames = activeAssignments.map { it.workerNameSnapshot }.filter { it.isNotBlank() }.distinct()
                            val required = current?.outputs?.sumOf { it.requiredPieces } ?: 0
                            val produced = current?.let { job ->
                                data.receipts.filter { !it.isCancelled && it.jobId == job.id }.sumOf { it.creditedPieces }
                            } ?: 0
                            val remaining = (required - produced).coerceAtLeast(0)
                            val over = (produced - required).coerceAtLeast(0)

                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(18.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                shadowElevation = 1.dp
                            ) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(verticalAlignment = Alignment.Top) {
                                        Column(
                                            Modifier.weight(1f).clickable { selectedMachineId = machine.id },
                                            verticalArrangement = Arrangement.spacedBy(3.dp)
                                        ) {
                                            Text("${machine.number}-stanok", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            Text(
                                                listOf(order?.articleSnapshot.orEmpty(), order?.productNameSnapshot.orEmpty()).filter { it.isNotBlank() }.joinToString(" • "),
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            current?.let { job ->
                                                Text(
                                                    "${job.outputs.joinToString { it.detailName }} • rang ${job.colorCode}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                        if (canWrite && machineJobs.isNotEmpty()) {
                                            FilledTonalButton(onClick = { openReceipt(machine.id, machineJobs) }) {
                                                Text("＋ Qabul", fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }

                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .55f))
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text("Ishchi", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text(
                                                if (workerNames.isEmpty()) "Biriktirilmagan" else workerNames.joinToString(", "),
                                                fontWeight = FontWeight.SemiBold,
                                                color = if (workerNames.isEmpty()) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text("Qolgan", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text(
                                                if (over > 0) "+$over ortiq" else "$remaining dona",
                                                fontWeight = FontWeight.Bold,
                                                color = if (over > 0) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            val machine = data.machines.firstOrNull { it.id == selectedMachineId }
            val machineJobs = jobs.filter { it.machineId == selectedMachineId }.sortedBy { it.startedAt.orEmpty() }
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TextButton(onClick = { selectedMachineId = null }) { Text("‹ Stanoklar") }
                Text("${machine?.number ?: 0}-stanok", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                machineJobs.forEach { job ->
                    val order = data.orders.firstOrNull { it.id == job.orderId }
                    TpCard {
                        Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.Bold)
                        Text("${job.outputs.joinToString { it.detailName }} • rang ${job.colorCode}")
                        Text("Seryo ${job.resinCode} • ${materialStatusLabel(job.materialStatus)}")
                    }
                }
                if (canWrite && machineJobs.isNotEmpty()) {
                    FilledTonalButton(
                        onClick = { openReceipt(selectedMachineId!!, machineJobs) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp)
                    ) { Text("＋ Qabul", fontWeight = FontWeight.Bold) }
                }
                Text("Qabul tarixi", fontWeight = FontWeight.Bold)
                data.receipts.filter { !it.isCancelled && it.machineId == selectedMachineId }.sortedByDescending { it.createdAt }.take(30).forEach { r ->
                    TpCard {
                        Text("${r.workerNameSnapshot} • ${r.detailNameSnapshot} • ${r.creditedPieces} dona", fontWeight = FontWeight.Bold)
                        Text("${r.date} • ${r.completedBags} to‘liq qop • chala ${r.remainderAfter}")
                        val jimLabel = if (r.defaultPiecesPerShotSnapshot != r.piecesPerShotSnapshot) {
                            "Jim ${r.piecesPerShotSnapshot} (default ${r.defaultPiecesPerShotSnapshot})"
                        } else "Jim ${r.piecesPerShotSnapshot}"
                        Text(jimLabel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (r.updatedAt != null) Text("Tahrirlangan: ${r.updatedAt.take(16).replace('T', ' ')} • ${r.editReason}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (canWrite && r.receiverName.equals(policy.displayName, true)) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            TextButton(onClick = { editReceiptId = r.id }) { Text("Tahrirlash") }
                            TextButton(onClick = { cancelReceiptReason = ""; deleteReceiptId = r.id }) { Text("Bekor qilish", color = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
            }
        }
    }

    receiptJobId?.let { initialJobId ->
        val targetJobs = jobs.filter { it.machineId == receiptMachineId }
        if (targetJobs.isNotEmpty()) {
            TpReceiptDialog(data, targetJobs, initialJobId, policy.displayName, onDismiss = {
                receiptJobId = null
                receiptMachineId = null
            }) { jobId, detailId, workerId, date, bags, remainder, receiver, piecesPerShot ->
                val result = repository.addReceipt(jobId, detailId, workerId, date, bags, remainder, receiver, piecesPerShot)
                message = result.exceptionOrNull()?.message ?: "Qabul qilindi"
                if (result.isSuccess) {
                    receiptJobId = null
                    receiptMachineId = null
                    revision++
                }
                result.isSuccess
            }
        } else {
            receiptJobId = null
            receiptMachineId = null
        }
    }
    editReceiptId?.let { receiptId ->
        data.receipts.firstOrNull { it.id == receiptId }?.let { receipt ->
            TpReceiptEditDialog(data, receipt, policy.displayName, onDismiss = { editReceiptId = null }) { workerId, date, bags, remainder, reason, piecesPerShot ->
                val result = repository.updateReceipt(receipt.id, workerId, date, bags, remainder, policy.displayName, reason, piecesPerShot)
                message = result.exceptionOrNull()?.message ?: "Qabul tahrirlandi"
                if (result.isSuccess) { editReceiptId = null; revision++ }
                result.isSuccess
            }
        }
    }
    deleteReceiptId?.let { receiptId ->
        val receipt = data.receipts.firstOrNull { it.id == receiptId }
        if (receipt != null) AlertDialog(
            onDismissRequest = { deleteReceiptId = null; cancelReceiptReason = "" },
            title = { Text("Qabul yozuvini bekor qilish") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${receipt.workerNameSnapshot} • ${receipt.detailNameSnapshot} • ${receipt.creditedPieces} dona yozuvi tarixda qoladi, lekin hisob-kitobdan chiqariladi.")
                TpField(cancelReceiptReason, { cancelReceiptReason = it }, "Bekor qilish sababi *", singleLine = false)
            } },
            confirmButton = { TextButton(enabled = cancelReceiptReason.isNotBlank(), onClick = {
                val result = repository.deleteReceipt(receipt.id, policy.displayName, cancelReceiptReason)
                message = result.exceptionOrNull()?.message ?: "Qabul yozuvi bekor qilindi"
                if (result.isSuccess) { deleteReceiptId = null; cancelReceiptReason = ""; revision++ }
            }) { Text("Bekor qilish", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { deleteReceiptId = null; cancelReceiptReason = "" }) { Text("Ortga") } }
        ) else deleteReceiptId = null
    }
}

@Composable
private fun TpReceiptDialog(
    data: TpData,
    jobs: List<TpPlanJob>,
    initialJobId: String,
    receiverDisplayName: String,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, Int, Int, String, Int) -> Boolean
) {
    var jobId by remember { mutableStateOf(initialJobId) }
    val job = jobs.firstOrNull { it.id == jobId } ?: jobs.firstOrNull()
    var detailId by remember(jobId) { mutableStateOf(job?.outputs?.firstOrNull()?.detailId.orEmpty()) }
    val output = job?.outputs?.firstOrNull { it.detailId == detailId }
    val machineId = job?.machineId.orEmpty()
    val brigadeWorkers = data.workers.filter { !it.archived && it.brigadeId == job?.brigadeId }.sortedBy { it.name }
    val fallbackDate = tpReceivingRecordDate(data.shifts.firstOrNull { it.id == job?.shiftId })
    val activeAssignments = if (job == null) emptyList() else data.machineWorkerAssignments.filter {
        it.machineId == machineId && it.brigadeId == job.brigadeId && it.shiftId == job.shiftId && it.date == fallbackDate && it.isActive
    }.sortedByDescending { it.startedAt }
    val assignmentDate = activeAssignments.firstOrNull()?.date ?: fallbackDate
    val assignedIds = activeAssignments.mapNotNull { it.workerId }.toSet()
    val assignedWorkers = data.workers.filter { !it.archived && it.id in assignedIds }.sortedBy { it.name }
    val workers = if (assignedWorkers.isNotEmpty()) assignedWorkers else brigadeWorkers
    var workerId by remember(jobId, workers.map { it.id }) { mutableStateOf(workers.singleOrNull()?.id ?: workers.firstOrNull()?.id.orEmpty()) }
    var bags by remember { mutableStateOf("") }
    var remainder by remember(jobId, detailId) { mutableStateOf("0") }
    var piecesPerShot by remember(jobId, detailId, output?.piecesPerShot) { mutableIntStateOf(output?.piecesPerShot?.coerceAtLeast(1) ?: 1) }
    var showShotDialog by remember { mutableStateOf(false) }
    var confirmOverPlan by remember { mutableStateOf(false) }
    val carry = job?.let { data.openRemainder(it.id, detailId) } ?: 0
    val preview = if (output != null) runCatching {
        calculateReceiptCredit(output.bagCapacity, carry, bags.toIntOrNull() ?: 0, remainder.toIntOrNull() ?: 0)
    }.getOrNull() else null
    val alreadyProduced = if (job == null || output == null) 0 else data.receipts.filter {
        !it.isCancelled && it.jobId == job.id && it.detailId == output.detailId
    }.sumOf { it.creditedPieces }
    val remainingPlan = ((output?.requiredPieces ?: 0) - alreadyProduced).coerceAtLeast(0)
    val overPlanBy = ((preview ?: 0) - remainingPlan).coerceAtLeast(0)
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(jobId, detailId, output?.detailId) {
        if (output != null) runCatching { focusRequester.requestFocus() }
    }

    fun saveNow(): Boolean {
        val currentJob = job ?: return false
        val currentOutput = output ?: return false
        if (workerId.isBlank() || preview == null) return false
        return onSave(
            currentJob.id,
            currentOutput.detailId,
            workerId,
            assignmentDate,
            bags.toIntOrNull() ?: 0,
            remainder.toIntOrNull() ?: 0,
            receiverDisplayName.ifBlank { "Qabul qiluvchi" },
            piecesPerShot
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Qabul qilish") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (jobs.size > 1) TpChoice(
                    "Vazifa", jobId, jobs, { it.id }, { row ->
                        val order = data.orders.firstOrNull { it.id == row.orderId }
                        "${order?.articleSnapshot.orEmpty()} • ${row.outputs.joinToString { it.detailName }} • ${row.colorCode}"
                    }
                ) { jobId = it }
                if (job != null && job.outputs.size > 1) TpChoice("Detal", detailId, job.outputs, { it.detailId }, { it.detailName }) { detailId = it }

                job?.let { row ->
                    val order = data.orders.firstOrNull { it.id == row.orderId }
                    Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.Bold)
                            Text("${output?.detailName.orEmpty()} • rang ${row.colorCode}", style = MaterialTheme.typography.bodySmall)
                            Text("Sana: $assignmentDate • Qabul qiluvchi: ${receiverDisplayName.ifBlank { "—" }}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                when {
                    workers.isEmpty() -> Text("Bu brigadada faol ishchi topilmadi.", color = MaterialTheme.colorScheme.error)
                    workers.size == 1 -> {
                        Text("Ishchi", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .55f)) {
                            Text(workers.first().name, Modifier.fillMaxWidth().padding(12.dp), fontWeight = FontWeight.Bold)
                        }
                    }
                    else -> {
                        Text(if (assignedWorkers.isNotEmpty()) "Stanokka biriktirilgan ishchilar" else "Ishchi tanlang", fontWeight = FontWeight.Bold)
                        workers.forEach { worker ->
                            FilterChip(
                                selected = workerId == worker.id,
                                onClick = { workerId = worker.id },
                                label = { Text(worker.name, Modifier.fillMaxWidth()) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
                if (assignedWorkers.isEmpty() && workers.isNotEmpty()) {
                    Text("Stanokka faol ishchi biriktirilmagan. Brigada ro‘yxatidan tanlanmoqda.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
                }

                output?.let { out ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Jimdagi detal soni", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                if (piecesPerShot == out.piecesPerShot) "$piecesPerShot dona" else "$piecesPerShot dona • default ${out.piecesPerShot}",
                                fontWeight = FontWeight.Bold,
                                color = if (piecesPerShot == out.piecesPerShot) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.tertiary
                            )
                        }
                        OutlinedButton(onClick = { showShotDialog = true }) { Text("O‘zgartirish") }
                    }

                    Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = .45f)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Oldingi chala", fontWeight = FontWeight.SemiBold)
                                Text("$carry / ${out.bagCapacity} dona", fontWeight = FontWeight.Bold)
                            }
                            LinearProgressIndicator(
                                progress = { if (out.bagCapacity > 0) carry.toFloat() / out.bagCapacity.toFloat() else 0f },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TpField(
                        bags, { bags = digitsOnly(it) }, "To‘liq qop", KeyboardType.Number,
                        modifier = Modifier.weight(1f).focusRequester(focusRequester)
                    )
                    TpField(
                        remainder, { remainder = digitsOnly(it) }, "Chala", KeyboardType.Number,
                        modifier = Modifier.weight(1f)
                    )
                }

                output?.let { out ->
                    val planRequired = out.requiredPieces
                    val after = alreadyProduced + (preview ?: 0)
                    val remainingAfter = (planRequired - after).coerceAtLeast(0)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column { Text("Reja", style = MaterialTheme.typography.labelSmall); Text("$planRequired", fontWeight = FontWeight.Bold) }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("Qabul", style = MaterialTheme.typography.labelSmall); Text("$alreadyProduced", fontWeight = FontWeight.Bold) }
                        Column(horizontalAlignment = Alignment.End) { Text("Qoladi", style = MaterialTheme.typography.labelSmall); Text("$remainingAfter", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }
                    }
                    if (preview != null) {
                        val shots = preview.toDouble() / piecesPerShot.coerceAtLeast(1).toDouble()
                        val earned = calculatePieceWorkAmount(preview, piecesPerShot, out.unitPrice)
                        Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .55f)) {
                            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("Ishchiga yoziladi: $preview dona", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                Text("Hisob: ${formatTpNumber(shots)} jim • ${earned} so‘m", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            }
                        }
                    } else {
                        Text("Qop sonlarini tekshiring", color = MaterialTheme.colorScheme.error)
                    }
                    if (overPlanBy > 0) {
                        Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.tertiaryContainer) {
                            Text(
                                "Rejadan $overPlanBy dona ortiq qabul qilinadi. Qabul qilishda alohida tasdiq so‘raladi.",
                                Modifier.fillMaxWidth().padding(10.dp),
                                color = MaterialTheme.colorScheme.onTertiaryContainer,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = job != null && output != null && workerId.isNotBlank() && preview != null, onClick = {
                if (overPlanBy > 0) confirmOverPlan = true else if (saveNow()) onDismiss()
            }) { Text("Qabul qilish", fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )

    if (showShotDialog && output != null) {
        var temp by remember(piecesPerShot, output.detailId) { mutableIntStateOf(piecesPerShot) }
        AlertDialog(
            onDismissRequest = { showShotDialog = false },
            title = { Text("Jimdagi detal soni") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Default: ${output.piecesPerShot} dona")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        FilledTonalButton(onClick = { if (temp > 1) temp-- }) { Text("−", style = MaterialTheme.typography.titleLarge) }
                        Text("$temp", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        FilledTonalButton(onClick = { if (temp < output.piecesPerShot) temp++ }) { Text("+", style = MaterialTheme.typography.titleLarge) }
                    }
                    Text("Bu o‘zgarish faqat shu qabul uchun. Detalning master default qiymati o‘zgarmaydi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(onClick = { piecesPerShot = temp.coerceIn(1, output.piecesPerShot.coerceAtLeast(1)); showShotDialog = false }) { Text("Tasdiqlash") } },
            dismissButton = { TextButton(onClick = { showShotDialog = false }) { Text("Bekor qilish") } }
        )
    }

    if (confirmOverPlan && overPlanBy > 0) {
        AlertDialog(
            onDismissRequest = { confirmOverPlan = false },
            title = { Text("Rejadan ortiq qabul") },
            text = { Text("Ushbu qabul rejadan $overPlanBy dona ortiq. Baribir qabul qilasizmi?") },
            confirmButton = { TextButton(onClick = { if (saveNow()) { confirmOverPlan = false; onDismiss() } }) { Text("Baribir qabul qilish", fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = { confirmOverPlan = false }) { Text("Ortga") } }
        )
    }
}

@Composable
private fun TpReceiptEditDialog(
    data: TpData,
    receipt: TpReceipt,
    editorName: String,
    onDismiss: () -> Unit,
    onSave: (String, String, Int, Int, String, Int) -> Boolean
) {
    val workers = data.workers.filter { !it.archived && it.brigadeId == receipt.brigadeId }.sortedBy { it.name }
    var workerId by remember(receipt.id) { mutableStateOf(receipt.workerId) }
    var date by remember(receipt.id) { mutableStateOf(receipt.date) }
    var bags by remember(receipt.id) { mutableStateOf(receipt.completedBags.toString()) }
    var remainder by remember(receipt.id) { mutableStateOf(receipt.remainderAfter.toString()) }
    var piecesPerShot by remember(receipt.id) { mutableStateOf(receipt.piecesPerShotSnapshot.toString()) }
    var reason by remember(receipt.id) { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Qabulni tahrirlash") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${receipt.detailNameSnapshot} • rang ${receipt.colorCode}", fontWeight = FontWeight.Bold)
            Text("Qabul qiluvchi: $editorName", style = MaterialTheme.typography.bodySmall)
            TpChoice("Ishchi", workerId, workers, { it.id }, { it.name }) { workerId = it }
            TpDatePickerButton("Sana", date) { date = it }
            TpField(bags, { bags = digitsOnly(it) }, "To‘liq qop soni", KeyboardType.Number)
            TpField(remainder, { remainder = digitsOnly(it) }, "Chala qopdagi dona", KeyboardType.Number)
            TpField(piecesPerShot, { piecesPerShot = digitsOnly(it) }, "Jimdagi detal soni (default ${receipt.defaultPiecesPerShotSnapshot})", KeyboardType.Number)
            TpField(reason, { reason = it }, "Tahrirlash sababi *", singleLine = false)
            Text("Tahrir sababi audit tarixida saqlanadi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } },
        confirmButton = { TextButton(enabled = reason.isNotBlank(), onClick = {
            if (onSave(workerId, date, bags.toIntOrNull() ?: 0, remainder.toIntOrNull() ?: 0, reason, piecesPerShot.toIntOrNull() ?: receipt.piecesPerShotSnapshot)) onDismiss()
        }) { Text("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

private enum class TpQualityPage { ROOT, EVALUATION, ISSUE }

@Composable
fun TpQualityScreen(strings: AppStrings, repository: TpDataRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val serverRevision by TpDataEvents.revision.collectAsState()
    var revision by remember { mutableIntStateOf(0) }
    val policy = remember(serverRevision) { AccessGuard(context).currentPolicy() }
    val data = remember(serverRevision, revision, policy.revision) { repository.load().scopedFor(policy) }
    val canReadQuality = policy.isAdmin() || policy.canRead(AssemblySection.TP_QUALITY)
    val canReadIssue = policy.isAdmin() || policy.canRead(AssemblySection.TP_DAILY_ISSUE)
    val canWriteQuality = policy.isAdmin() || policy.canWrite(AssemblySection.TP_QUALITY)
    val canWriteIssue = policy.isAdmin() || policy.canWrite(AssemblySection.TP_DAILY_ISSUE)
    val availablePages = buildList {
        if (canReadQuality) add(TpQualityPage.EVALUATION)
        if (canReadIssue) add(TpQualityPage.ISSUE)
    }
    var page by remember(policy.revision) { mutableStateOf(if (availablePages.size == 1) availablePages.first() else TpQualityPage.ROOT) }

    fun goBackOneLevel() {
        when {
            availablePages.size == 1 -> onBack()
            page != TpQualityPage.ROOT -> page = TpQualityPage.ROOT
            else -> onBack()
        }
    }
    BackHandler { goBackOneLevel() }

    Column(Modifier.fillMaxSize()) {
        AppTopBar("TP sifat", canGoBack = true, onMenu = {}, onBack = ::goBackOneLevel)
        when (page) {
            TpQualityPage.ROOT -> Column(
                Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpQuality-root"))
                    .navigationBarsPadding().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (canReadQuality) TpNavRow("1. Baholash") { page = TpQualityPage.EVALUATION }
                if (canReadIssue) TpNavRow("2. Kun muammosi") { page = TpQualityPage.ISSUE }
            }
            TpQualityPage.EVALUATION -> Column(
                Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpQuality-evaluation"))
                    .navigationBarsPadding().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TpQualityMachineBoard(data, repository, policy, canWriteQuality) { revision++ }
            }
            TpQualityPage.ISSUE -> Column(
                Modifier.fillMaxSize().verticalScroll(uz.toybola.factory.ui.components.rememberRetainedScrollState("TpQuality-issue"))
                    .navigationBarsPadding().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TpDailyIssueForm(data, repository, canWriteIssue, policy.displayName) { revision++ }
            }
        }
    }
}

@Composable
private fun TpQualityMonitoring(data: TpData) {
    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    val shifts = data.shifts.filterNot { it.archived }.sortedBy { it.name }
    var shopId by remember(shops) { mutableStateOf(shops.firstOrNull()?.id.orEmpty()) }
    var shiftId by remember(shifts) { mutableStateOf(shifts.firstOrNull()?.id.orEmpty()) }
    val brigadeIds = data.brigades.filter { !it.archived && it.shopId == shopId && it.shiftId == shiftId }.map { it.id }.toSet()
    val workers = data.workers.filter { !it.archived && it.brigadeId in brigadeIds }.sortedBy { it.name }
    val rounds = data.qualityRounds.filter { it.brigadeId in brigadeIds }
    Text("Sex", fontWeight = FontWeight.Bold)
    TpFilterRow(shops, shopId, { it.id }, { it.name }) { shopId = it }
    Text("Smena", fontWeight = FontWeight.Bold)
    TpFilterRow(shifts, shiftId, { it.id }, { it.name }) { shiftId = it }
    Text("Ishchilar kesimida", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    if (workers.isEmpty()) Text("Tanlangan sex va smenada ishchi yo‘q.")
    workers.forEach { worker ->
        val rows = rounds.filter { it.workerId == worker.id }
        val scoredRows = rows.filterNot { it.excludedFromAverage }
        val average = if (scoredRows.isEmpty()) 0.0 else scoredRows.map { it.score }.average()
        val problems = scoredRows.count { it.score < 75 }
        val onTime = rows.count { row ->
            runCatching {
                val scheduled = java.time.LocalTime.parse(row.scheduledTime)
                val checked = java.time.LocalDateTime.parse(row.checkedAt)
                kotlin.math.abs(java.time.Duration.between(scheduled, checked.toLocalTime()).toMinutes()) <= 60L
            }.getOrDefault(false)
        }
        TpCard {
            Text(worker.name, fontWeight = FontWeight.Bold)
            Text("Baholangan raundlar: ${rows.size} • O‘z vaqtida: $onTime")
            Text("Sifat o‘rtachasi: ${if (scoredRows.isEmpty()) "—" else "${average.toInt()}%"} • Muammoli baho: $problems")
            rows.maxByOrNull { it.checkedAt }?.let { Text("Oxirgi tekshiruv: ${it.date} • ${it.round}-raund • ${scoreLabel(it.score)}", style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
private fun TpQualityMachineBoard(data: TpData, repo: TpDataRepository, policy: UserAccessPolicy, canWrite: Boolean, refresh: () -> Unit) {
    val activeBrigades = data.brigades.filterNot { it.archived }
    val scopedShopIds = activeBrigades.map { it.shopId }.filter { it.isNotBlank() }.toSet()
    val scopedShiftIds = activeBrigades.map { it.shiftId }.filter { it.isNotBlank() }.toSet()
    val shops = data.shops.filterNot { it.archived }.filter { scopedShopIds.isEmpty() || it.id in scopedShopIds }.sortedBy { it.name }
    val shifts = data.shifts.filterNot { it.archived }.filter { scopedShiftIds.isEmpty() || it.id in scopedShiftIds }.sortedBy { it.name }
    var shopId by remember(shops) { mutableStateOf(shops.firstOrNull()?.id.orEmpty()) }
    var shiftId by remember(shifts) { mutableStateOf(shifts.firstOrNull()?.id.orEmpty()) }
    var selectedJobId by remember { mutableStateOf<String?>(null) }
    var selectedRound by remember { mutableIntStateOf(1) }
    var message by remember { mutableStateOf<String?>(null) }
    val shift = shifts.firstOrNull { it.id == shiftId }
    val roundTimes = shift?.roundTimes.orEmpty()
    val roundBeforeMinutes = data.settings.qualityRoundBeforeMinutes.coerceIn(0, 240)
    val roundAfterMinutes = data.settings.qualityRoundAfterMinutes.coerceIn(0, 240)

    LaunchedEffect(shiftId, roundTimes) {
        selectedRound = tpRecommendedQualityRound(roundTimes)
    }

    val brigadeIds = data.brigades.filter { !it.archived && it.shopId == shopId && it.shiftId == shiftId }.map { it.id }.toSet()
    val jobs = data.jobs.filter { it.brigadeId in brigadeIds && it.machineId != null && it.status == TpJobStatus.IN_PROGRESS }
        .sortedBy { data.machines.firstOrNull { m -> m.id == it.machineId }?.number ?: Int.MAX_VALUE }

    if (shops.size > 1) {
        Text("Sex", fontWeight = FontWeight.Bold)
        TpFilterRow(shops, shopId, { it.id }, { it.name }) { shopId = it }
    } else shops.firstOrNull()?.let { Text("Sex: ${it.name}", fontWeight = FontWeight.SemiBold) }
    if (shifts.size > 1) {
        Text("Smena", fontWeight = FontWeight.Bold)
        TpFilterRow(shifts, shiftId, { it.id }, { it.name }) { shiftId = it }
    } else shifts.firstOrNull()?.let { Text("Smena: ${it.name}", fontWeight = FontWeight.SemiBold) }

    Text("Raundlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    if (roundTimes.isEmpty()) {
        Text("Bu smenaga sifat raund vaqtlari belgilanmagan.", color = MaterialTheme.colorScheme.error)
    } else {
        roundTimes.chunked(3).forEachIndexed { chunkIndex, chunk ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                chunk.forEachIndexed { innerIndex, time ->
                    val roundNo = chunkIndex * 3 + innerIndex + 1
                    FilterChip(
                        selected = selectedRound == roundNo,
                        onClick = { selectedRound = roundNo; message = null },
                        label = { Text("$roundNo • $time") },
                        modifier = Modifier.weight(1f)
                    )
                }
                repeat(3 - chunk.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        val selectedTime = roundTimes.getOrNull(selectedRound - 1)
        if (selectedTime != null) {
            val open = tpQualityRoundIsOpen(selectedTime, roundBeforeMinutes, roundAfterMinutes)
            Text(
                if (open) "$selectedRound-raund • $selectedTime • baholash ochiq (−$roundBeforeMinutes / +$roundAfterMinutes daqiqa)"
                else "$selectedRound-raund • $selectedTime • hozir baholash oynasi yopiq",
                color = if (open) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }

    Text("Stanoklar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    if (jobs.isEmpty()) Text("Tanlangan sex va smenada baholanadigan stanok yo‘q.")
    val selectedTime = roundTimes.getOrNull(selectedRound - 1)
    val selectedRoundOpen = selectedTime?.let { tpQualityRoundIsOpen(it, roundBeforeMinutes, roundAfterMinutes) } == true
    val today = LocalDate.now().toString()
    val machineEntries = jobs.groupBy { it.machineId!! }.entries.sortedBy { (id, _) -> data.machines.firstOrNull { it.id == id }?.number }
    val pendingEntries = machineEntries.filter { (machineId, _) -> data.qualityRounds.none { it.machineId == machineId && it.date == today && it.round == selectedRound } }
    val doneEntries = machineEntries.filter { (machineId, _) -> data.qualityRounds.any { it.machineId == machineId && it.date == today && it.round == selectedRound } }
    fun openMachine(machineId: String, machineJobs: List<TpPlanJob>) {
        val job = machineJobs.first()
        when {
            !canWrite -> message = "Baholash uchun yozish ruxsati kerak"
            !selectedRoundOpen -> message = "Tanlangan raund −$roundBeforeMinutes / +$roundAfterMinutes daqiqa oynasida baholanadi"
            else -> selectedJobId = job.id
        }
    }
    if (pendingEntries.isEmpty()) Text("Bu raundda baholanmagan stanok qolmadi.")
    pendingEntries.forEach { (machineId, machineJobs) ->
        val machine = data.machines.firstOrNull { it.id == machineId }
        val job = machineJobs.first()
        val order = data.orders.firstOrNull { it.id == job.orderId }
        Surface(Modifier.fillMaxWidth().clickable { openMachine(machineId, machineJobs) }, shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${machine?.number ?: 0}-stanok", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}")
                    Text("${job.outputs.joinToString { it.detailName }} • ${job.colorCode}", style = MaterialTheme.typography.bodySmall)
                }
                Text("›", style = MaterialTheme.typography.headlineSmall)
            }
        }
    }
    HorizontalDivider(Modifier.padding(vertical = 6.dp))
    Text("Baholangan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    if (doneEntries.isEmpty()) Text("Hali baholangan stanok yo‘q.")
    doneEntries.forEach { (machineId, machineJobs) ->
        val machine = data.machines.firstOrNull { it.id == machineId }
        val job = machineJobs.first()
        val order = data.orders.firstOrNull { it.id == job.orderId }
        val selectedScore = data.qualityRounds.firstOrNull { it.machineId == machineId && it.date == today && it.round == selectedRound }
        Surface(Modifier.fillMaxWidth().clickable { openMachine(machineId, machineJobs) }, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .55f)) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${machine?.number ?: 0}-stanok", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}")
                    Text("${job.outputs.joinToString { it.detailName }} • ${job.colorCode}", style = MaterialTheme.typography.bodySmall)
                    if (selectedScore != null) Text("${selectedScore.score}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
                Text("✓", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }
        }
    }
    message?.let { Text(it, color = if (it.startsWith("Baholash")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
    selectedJobId?.let { id ->
        val job = jobs.firstOrNull { it.id == id }
        if (job != null) TpQualityEvaluationDialog(data, job, policy.displayName, selectedRound, onDismiss = { selectedJobId = null }) { workerId, date, round, score, issue, checker, absence ->
            val result = repo.saveQualityRound(job.id, workerId, date, round, score, issue, checker, absence)
            message = result.exceptionOrNull()?.message ?: "Baholash saqlandi"
            if (result.isSuccess) { selectedJobId = null; refresh() }
            result.isSuccess
        }
    }
}

@Composable
private fun TpQualityEvaluationDialog(
    data: TpData,
    job: TpPlanJob,
    checkerDisplayName: String,
    preferredRound: Int,
    onDismiss: () -> Unit,
    onSave: (String, String, Int, Int, String, String, String) -> Boolean
) {
    val machine = data.machines.firstOrNull { it.id == job.machineId }
    val order = data.orders.firstOrNull { it.id == job.orderId }
    val workers = data.workers.filter { !it.archived && it.brigadeId == job.brigadeId }.sortedBy { it.name }
    val shift = data.shifts.firstOrNull { it.id == job.shiftId }
    var workerId by remember { mutableStateOf(workers.firstOrNull()?.id.orEmpty()) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    val eligibleRounds = remember(date, shift?.roundTimes, data.settings.qualityRoundBeforeMinutes, data.settings.qualityRoundAfterMinutes) {
        if (date != LocalDate.now().toString()) emptyList() else shift?.roundTimes.orEmpty().mapIndexedNotNull { index, time ->
            val within = runCatching {
                tpQualityRoundIsOpen(time, data.settings.qualityRoundBeforeMinutes, data.settings.qualityRoundAfterMinutes)
            }.getOrDefault(false)
            if (within) (index + 1) to time else null
        }
    }
    var round by remember(eligibleRounds, preferredRound) { mutableIntStateOf(if (eligibleRounds.any { it.first == preferredRound }) preferredRound else eligibleRounds.firstOrNull()?.first ?: 0) }
    var grade by remember { mutableIntStateOf(0) }
    var absence by remember { mutableStateOf("") }
    var issue by remember { mutableStateOf("") }
    val score = when (grade) { 1 -> 100; 2 -> 75; 3 -> 50; 4 -> 0; else -> 0 }
    val valid = workerId.isNotBlank() && eligibleRounds.any { it.first == round } && when (absence) {
        "EXCUSED" -> issue.isNotBlank()
        "UNEXCUSED" -> true
        else -> grade in 1..4 && (grade <= 2 || issue.isNotBlank())
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${machine?.number ?: 0}-stanok • Baholash") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${order?.articleSnapshot.orEmpty()} • ${order?.productNameSnapshot.orEmpty()}", fontWeight = FontWeight.Bold)
            Text("${job.outputs.joinToString { it.detailName }} • rang ${job.colorCode}")
            TpChoice("Ishchi", workerId, workers, { it.id }, { it.name }) { workerId = it }
            TpDatePickerButton("Sana", date) { date = it }
            if (eligibleRounds.isEmpty()) {
                Text("Hozir baholash uchun ochiq raund yo‘q. Raund belgilangan vaqt atrofidagi sozlangan oynada ochiladi.", color = MaterialTheme.colorScheme.error)
            } else {
                TpChoice("Raund", round.toString(), eligibleRounds, { it.first.toString() }, { "${it.first}-raund • ${it.second} • −${data.settings.qualityRoundBeforeMinutes} / +${data.settings.qualityRoundAfterMinutes} daqiqa" }) { round = it.toInt() }
            }
            Text("Ishchi holati", fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = absence.isBlank(), onClick = { absence = "" }, label = { Text("Mavjud") }, modifier = Modifier.weight(1f))
                FilterChip(selected = absence == "EXCUSED", onClick = { absence = "EXCUSED"; grade = 0 }, label = { Text("Sababli") }, modifier = Modifier.weight(1f))
                FilterChip(selected = absence == "UNEXCUSED", onClick = { absence = "UNEXCUSED"; grade = 0 }, label = { Text("Sababsiz") }, modifier = Modifier.weight(1f))
            }
            if (absence.isBlank()) Text("Baho", fontWeight = FontWeight.Bold)
            if (absence.isBlank()) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (1..4).forEach { value -> FilterChip(selected = grade == value, onClick = { grade = value }, label = { Text(value.toString()) }, modifier = Modifier.weight(1f)) }
            }
            if (absence.isBlank() && grade > 0) Text("${scoreLabel(score)} • $score%", color = if (grade <= 2) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            if (absence == "EXCUSED") Text("Sababli — o‘rtachaga ta’sir qilmaydi. Izoh majburiy.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            if (absence == "UNEXCUSED") Text("Sababsiz — ushbu raund 0% hisoblanadi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            TpField(issue, { issue = it }, if (grade >= 3 || absence == "EXCUSED") "Muammo/izoh *" else "Muammo/izoh", singleLine = false)
            if (absence.isBlank() && grade >= 3) Text("3 yoki 4 bahoda izoh majburiy.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        } },
        confirmButton = { TextButton(enabled = valid, onClick = { if (onSave(workerId, date, round, if (absence == "UNEXCUSED") 0 else score, issue, checkerDisplayName.ifBlank { "Sifat nazoratchisi" }, absence)) onDismiss() }) { Text("Saqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

private fun tpQualityRoundIsOpen(time: String, beforeMinutes: Int, afterMinutes: Int): Boolean = runCatching {
    val scheduled = java.time.LocalTime.parse(time)
    val now = java.time.LocalTime.now()
    val scheduledMinutes = scheduled.hour * 60 + scheduled.minute
    val nowMinutes = now.hour * 60 + now.minute
    val signedDelta = ((nowMinutes - scheduledMinutes + 720 + 1440) % 1440) - 720
    signedDelta in -beforeMinutes.coerceIn(0, 240)..afterMinutes.coerceIn(0, 240)
}.getOrDefault(false)

private fun tpRecommendedQualityRound(times: List<String>): Int {
    if (times.isEmpty()) return 1
    val now = java.time.LocalTime.now()
    return times.mapIndexed { index, value ->
        val distance = runCatching {
            val t = java.time.LocalTime.parse(value)
            val raw = kotlin.math.abs(java.time.Duration.between(t, now).toMinutes())
            minOf(raw, 24L * 60L - raw)
        }.getOrDefault(Long.MAX_VALUE)
        index + 1 to distance
    }.minByOrNull { it.second }?.first ?: 1
}

private fun scoreLabel(score: Int): String = when { score >= 100 -> "1"; score >= 75 -> "2"; score >= 50 -> "3"; else -> "4" }

@Composable
private fun TpDailyIssueForm(data: TpData, repo: TpDataRepository, canWrite: Boolean, authorName: String, refresh: () -> Unit) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val imageStorage = remember { DailyIssueImageStorage(context) }
    val shops = data.shops.filterNot { it.archived }.sortedBy { it.name }
    val shifts = data.shifts.filterNot { it.archived }.sortedBy { it.name }
    var shopId by remember(shops) { mutableStateOf(shops.firstOrNull()?.id.orEmpty()) }
    var shiftId by remember(shifts) { mutableStateOf(shifts.firstOrNull()?.id.orEmpty()) }
    val brigades = data.brigades.filter { !it.archived && it.shopId == shopId && it.shiftId == shiftId }
    val brigadeIds = brigades.map { it.id }.toSet()
    val machines = data.machines.filter { !it.archived && it.shopId == shopId }.sortedBy { it.number }
    var machineId by remember(shopId) { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var title by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var assignee by remember { mutableStateOf("") }
    var issueId by remember { mutableStateOf(UUID.randomUUID().toString()) }
    val selectedImages = remember(issueId) { mutableStateListOf<Uri>() }
    var saving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var cancelIssueId by remember { mutableStateOf<String?>(null) }
    var cancelReason by remember { mutableStateOf("") }
    val hasUnsavedIssue = title.isNotBlank() || note.isNotBlank() || category.isNotBlank() || assignee.isNotBlank() || selectedImages.isNotEmpty()
    DisposableEffect(hasUnsavedIssue) {
        NavigationGuardState.mark("tp_daily_issue", hasUnsavedIssue)
        onDispose { NavigationGuardState.mark("tp_daily_issue", false) }
    }
    Text("Sex", fontWeight = FontWeight.Bold); TpFilterRow(shops, shopId, { it.id }, { it.name }) { shopId = it; machineId = "" }
    Text("Smena", fontWeight = FontWeight.Bold); TpFilterRow(shifts, shiftId, { it.id }, { it.name }) { shiftId = it }
    TpChoice("Stanok (ixtiyoriy)", machineId, listOf<TpMachine?>(null) + machines, { it?.id.orEmpty() }, { it?.let { m -> "${m.number}-stanok" } ?: "Belgilanmagan" }) { machineId = it }
    TpDatePickerButton("Sana", date) { date = it }
    TpField(title, { title = it }, "Muammo nomi")
    TpField(category, { category = it }, "Kategoriya (ixtiyoriy)")
    TpField(assignee, { assignee = it }, "Javobgar (ixtiyoriy)")
    TpField(note, { note = it }, "Batafsil izoh", singleLine = false)
    IssueImagePickerButton(hasImage = selectedImages.isNotEmpty(), enabled = canWrite && !saving && selectedImages.size < 10, onSelected = { uri ->
        if (selectedImages.size < 10) selectedImages.add(uri) else message = "Ko‘pi bilan 10 ta rasm qo‘shiladi"
    })
    if (selectedImages.isNotEmpty()) Text("Rasmlar: ${selectedImages.size} / 10", style = MaterialTheme.typography.bodySmall)
    selectedImages.forEachIndexed { index, uri ->
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(8.dp)) {
            AsyncImage(model = uri, contentDescription = "Tanlangan rasm", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(150.dp))
            TextButton(enabled = !saving, onClick = { selectedImages.removeAt(index) }) { Text("Olib tashlash") }
        } }
    }
    val selectedJob = data.jobs.firstOrNull { it.machineId == machineId && it.status == TpJobStatus.IN_PROGRESS }
    val brigadeId = selectedJob?.brigadeId ?: brigades.firstOrNull()?.id.orEmpty()
    val orderId = selectedJob?.orderId
    Button(enabled = canWrite && brigadeId.isNotBlank() && title.isNotBlank() && note.isNotBlank() && !saving, onClick = {
        coroutineScope.launch {
            saving = true
            runCatching {
                val refs = selectedImages.map { imageStorage.upload(it, "tp", issueId) }
                repo.addDailyIssue(brigadeId, date, machineId.ifBlank { null }, orderId, title, note, issueId, refs.map { it.url }, refs.map { it.path }, category, assignee, authorName).getOrThrow()
            }.onSuccess { message = "Kun muammosi saqlandi"; title = ""; note = ""; category = ""; assignee = ""; selectedImages.clear(); issueId = UUID.randomUUID().toString(); refresh() }
                .onFailure { message = it.message ?: "Muammoni saqlab bo‘lmadi" }
            saving = false
        }
    }, modifier = Modifier.fillMaxWidth()) { Text(if (saving) "Saqlanmoqda…" else "Muammoni saqlash") }
    message?.let { Text(it, color = if (it.startsWith("Kun")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
    HorizontalDivider()
    data.dailyIssues.filter { it.date == date && it.brigadeId in brigadeIds }.sortedByDescending { it.createdAt }.forEach { issue ->
        val machine = data.machines.firstOrNull { it.id == issue.machineId }
        TpCard {
            Text(issue.title, fontWeight = FontWeight.Bold)
            Text(when (issue.status) {
                TpDailyIssueStatus.NEW -> "Yangi"
                TpDailyIssueStatus.IN_PROGRESS -> "Jarayonda"
                TpDailyIssueStatus.RESOLVED -> "Hal qilindi"
                TpDailyIssueStatus.CANCELLED -> "Bekor qilingan"
            }, color = when (issue.status) {
                TpDailyIssueStatus.NEW -> MaterialTheme.colorScheme.error
                TpDailyIssueStatus.IN_PROGRESS -> MaterialTheme.colorScheme.primary
                else -> MaterialTheme.colorScheme.onSurfaceVariant
            }, style = MaterialTheme.typography.labelLarge)
            if (machine != null) Text("${machine.number}-stanok", color = MaterialTheme.colorScheme.primary)
            if (issue.category.isNotBlank()) Text("Kategoriya: ${issue.category}", style = MaterialTheme.typography.bodySmall)
            if (issue.assignee.isNotBlank()) Text("Javobgar: ${issue.assignee}", style = MaterialTheme.typography.bodySmall)
            if (issue.createdBy.isNotBlank()) Text("Muallif: ${issue.createdBy}", style = MaterialTheme.typography.bodySmall)
            Text(issue.note)
            if (issue.allImageUrls().isNotEmpty()) IssueImageGallery(issue.allImageUrls(), issue.allImagePaths())
            Text(issue.createdAt.take(16).replace('T', ' '), style = MaterialTheme.typography.bodySmall)
            if (issue.resolutionNote.isNotBlank()) Text("Izoh: ${issue.resolutionNote}", style = MaterialTheme.typography.bodySmall)
            if (canWrite && issue.status != TpDailyIssueStatus.RESOLVED && issue.status != TpDailyIssueStatus.CANCELLED) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (issue.status == TpDailyIssueStatus.NEW) OutlinedButton(onClick = {
                        repo.updateDailyIssueStatus(issue.id, TpDailyIssueStatus.IN_PROGRESS).onFailure { message = it.message }
                        refresh()
                    }, modifier = Modifier.weight(1f)) { Text("Jarayonda") }
                    Button(onClick = {
                        repo.updateDailyIssueStatus(issue.id, TpDailyIssueStatus.RESOLVED).onFailure { message = it.message }
                        refresh()
                    }, modifier = Modifier.weight(1f)) { Text("Hal qilindi") }
                }
                TextButton(onClick = { cancelIssueId = issue.id; cancelReason = "" }, modifier = Modifier.fillMaxWidth()) {
                    Text("Bekor qilish", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
    if (cancelIssueId != null) {
        AlertDialog(
            onDismissRequest = { cancelIssueId = null; cancelReason = "" },
            title = { Text("Kun muammosini bekor qilish") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Yozuv o‘chirilmaydi. Bekor qilingan holat va sabab audit tarixida qoladi.")
                    OutlinedTextField(
                        value = cancelReason,
                        onValueChange = { cancelReason = it },
                        label = { Text("Sabab") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = cancelReason.trim().isNotBlank(),
                    onClick = {
                        val id = cancelIssueId ?: return@TextButton
                        repo.updateDailyIssueStatus(id, TpDailyIssueStatus.CANCELLED, cancelReason)
                            .onSuccess { message = "Kun muammosi bekor qilindi" }
                            .onFailure { message = it.message ?: "Bekor qilib bo‘lmadi" }
                        cancelIssueId = null
                        cancelReason = ""
                        refresh()
                    }
                ) { Text("Bekor qilish", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { cancelIssueId = null; cancelReason = "" }) { Text("Qaytish") } }
        )
    }
}

@Composable
internal fun <T> TpFilterRow(items: List<T>, selectedId: String, id: (T) -> String, label: (T) -> String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEach { item -> FilterChip(selected = id(item) == selectedId, onClick = { onSelect(id(item)) }, label = { Text(label(item), maxLines = 1) }, modifier = Modifier.weight(1f)) }
    }
}

@Composable
internal fun TpDatePickerButton(label: String, value: String, onDate: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) { Text("$label: $value", Modifier.weight(1f)) }
    if (open) {
        val initial = runCatching { LocalDate.parse(value) }.getOrDefault(LocalDate.now())
        val state = rememberDatePickerState(initialSelectedDateMillis = initial.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
        DatePickerDialog(
            onDismissRequest = { open = false },
            confirmButton = { TextButton(onClick = {
                state.selectedDateMillis?.let { millis -> onDate(Instant.ofEpochMilli(millis).atZone(ZoneOffset.UTC).toLocalDate().toString()) }
                open = false
            }) { Text("Tanlash") } },
            dismissButton = { TextButton(onClick = { open = false }) { Text("Bekor qilish") } }
        ) { DatePicker(state = state) }
    }
}
