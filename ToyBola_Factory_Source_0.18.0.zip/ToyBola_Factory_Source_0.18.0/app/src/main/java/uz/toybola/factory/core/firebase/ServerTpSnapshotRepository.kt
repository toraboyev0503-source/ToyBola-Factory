package uz.toybola.factory.core.firebase

import android.content.Context
import com.google.firebase.functions.FirebaseFunctions
import uz.toybola.factory.core.data.TpData
import uz.toybola.factory.core.data.TpDataRepository

data class ServerTpSnapshotResult(
    val data: TpData,
    val hasData: Boolean,
    val hasSettings: Boolean,
    val counts: Map<String, Int>,
    val tombstones: Set<String>,
    val syncEpoch: Long = 0L
)

class ServerTpSnapshotRepository(context: Context) {
    private val repository = TpDataRepository(context.applicationContext)
    private val functions = FirebaseFunctions.getInstance("europe-west1")

    suspend fun download(): Result<ServerTpSnapshotResult> = runCatching {
        val response = functions.getHttpsCallable("getTpSnapshot")
            .call(mapOf("clientVersion" to "0.18.0"))
            .awaitResult()
        val root = response.data as? Map<*, *> ?: error("TP server snapshot javobi noto‘g‘ri")
        require(((root["syncProtocol"] as? Number)?.toInt() ?: 0) >= 2) { "TP serverini 0.11.0 ga yangilash kerak. GitHub Actions Firebase deploy tugashini tekshiring." }
        val payload = root["payload"]?.toString().orEmpty()
        require(payload.isNotBlank()) { "TP server snapshot bo‘sh" }
        require(payload.toByteArray(Charsets.UTF_8).size <= MAX_PAYLOAD_BYTES) { "TP server snapshot juda katta" }
        val counts = (root["counts"] as? Map<*, *>).orEmpty().mapNotNull { (key, value) ->
            key?.toString()?.let { it to ((value as? Number)?.toInt() ?: 0) }
        }.toMap()
        ServerTpSnapshotResult(
            data = repository.decodeForSync(payload),
            syncEpoch = (root["syncEpoch"] as? Number)?.toLong() ?: 0L,
            hasData = root["hasData"] == true,
            hasSettings = root["hasSettings"] == true,
            counts = counts,
            tombstones = (root["tombstones"] as? List<*>)
                .orEmpty().mapNotNull { it?.toString() }.filter { it.contains(':') }.toSet()
        )
    }

    companion object { private const val MAX_PAYLOAD_BYTES = 8 * 1024 * 1024 }
}
