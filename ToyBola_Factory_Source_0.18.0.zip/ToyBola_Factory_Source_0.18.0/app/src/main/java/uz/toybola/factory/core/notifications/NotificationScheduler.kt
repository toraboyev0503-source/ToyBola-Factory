package uz.toybola.factory.core.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import uz.toybola.factory.core.data.AssemblyDataRepository
import uz.toybola.factory.core.data.TpDataRepository
import uz.toybola.factory.core.firebase.ServerPolicyCache
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.core.security.AssemblySection
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

object NotificationScheduler {
    const val EXTRA_TYPE = "notification_type"
    const val EXTRA_DATE = "notification_date"

    const val QUALITY_ROUND_1 = "quality_round_1"
    const val QUALITY_ROUND_2 = "quality_round_2"
    const val QUALITY_ROUND_3 = "quality_round_3"
    const val QUALITY_CLOSE = "quality_close"
    const val ISSUE_SUMMARY = "issue_summary"
    const val BRIGADIR_REMINDER = "brigadir_reminder"
    const val BRIGADIR_DEADLINE = "brigadir_deadline"
    const val ATTENDANCE_REMINDER = "attendance_reminder"
    const val TP_QUALITY_ROUND_PREFIX = "tp_quality_round:"

    fun scheduleUpcoming(context: Context, repository: AssemblyDataRepository, days: Int = 4) {
        val appContext = context.applicationContext
        val userCode = AppPreferences(appContext).setup()?.userCode.orEmpty()
        val policy = ServerPolicyCache(appContext).load(userCode) ?: return
        val qualityUser = policy.canWrite(AssemblySection.QUALITY) || policy.role.equals("QUALITY", true)
        val brigadirUser = policy.canWrite(AssemblySection.BRIGADIR) || policy.role.equals("BRIGADIR", true)
        val attendanceUser = policy.canWrite(AssemblySection.TP_ATTENDANCE)
        val tpQualityUser = policy.isAdmin() || policy.canWrite(AssemblySection.TP_QUALITY) || policy.role.equals("TP_QUALITY", true)
        val issueWatcher = "ISSUE_SUMMARY" in policy.notificationKeys
        val tpData = TpDataRepository(appContext).load()
        val allTpTypes = tpData.shifts.filterNot { it.archived }.flatMap { shift -> shift.roundTimes.indices.map { index -> tpQualityReminderType(shift.id, index + 1) } }
        cancelManagedUpcoming(appContext, 14, allTpTypes)
        if (!qualityUser && !brigadirUser && !attendanceUser && !tpQualityUser && !issueWatcher) return

        val data = repository.load()
        val tpShiftIds = tpData.brigades.filter { !it.archived && policy.canAccessBrigade(it.id) }.map { it.shiftId }.toSet()
        val tpShifts = tpData.shifts.filter { !it.archived && it.id in tpShiftIds }
        val today = LocalDate.now()
        // Always seed today's 08:50 reminder for yesterday as well. This covers a reboot/app launch
        // on the deadline morning even when no alarm had been scheduled the day before.
        if (attendanceUser) schedule(appContext, today.atTime(8, 50), ATTENDANCE_REMINDER, today.minusDays(1))
        repeat(days.coerceIn(1, 14)) { offset ->
            val date = today.plusDays(offset.toLong())
            if (qualityUser) {
                val times = data.roundTimesAt(date.toString())
                schedule(appContext, date.atTime(LocalTime.parse(times.first)), QUALITY_ROUND_1, date)
                schedule(appContext, date.atTime(LocalTime.parse(times.second)), QUALITY_ROUND_2, date)
                schedule(appContext, date.atTime(LocalTime.parse(times.third)), QUALITY_ROUND_3, date)
                schedule(appContext, date.atTime(17, 50), QUALITY_CLOSE, date)
            }
            if (issueWatcher) schedule(appContext, date.atTime(18, 0), ISSUE_SUMMARY, date)
            if (brigadirUser) {
                schedule(appContext, date.plusDays(1).atTime(8, 50), BRIGADIR_REMINDER, date)
                schedule(appContext, date.plusDays(1).atTime(9, 0), BRIGADIR_DEADLINE, date)
            }
            if (attendanceUser) schedule(appContext, date.plusDays(1).atTime(8, 50), ATTENDANCE_REMINDER, date)
            if (tpQualityUser) {
                tpShifts.forEach { shift ->
                    shift.roundTimes.forEachIndexed { index, roundTime ->
                        tpQualityRoundDateTime(date, shift.startTime, shift.endTime, roundTime)?.let { roundAt ->
                            schedule(appContext, roundAt.minusMinutes(30), tpQualityReminderType(shift.id, index + 1), date)
                        }
                    }
                }
            }
        }
    }

    fun tpQualityReminderType(shiftId: String, round: Int): String = "$TP_QUALITY_ROUND_PREFIX$shiftId:$round"

    private fun tpQualityRoundDateTime(date: LocalDate, startText: String, endText: String, roundText: String): LocalDateTime? = runCatching {
        val start = LocalTime.parse(startText)
        val end = LocalTime.parse(endText)
        val round = LocalTime.parse(roundText)
        val overnight = !end.isAfter(start)
        val roundDate = if (overnight && !round.isAfter(end)) date.plusDays(1) else date
        roundDate.atTime(round)
    }.getOrNull()

    private fun cancelManagedUpcoming(context: Context, days: Int, extraTypes: List<String> = emptyList()) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val today = LocalDate.now()
        val types = listOf(
            QUALITY_ROUND_1, QUALITY_ROUND_2, QUALITY_ROUND_3, QUALITY_CLOSE,
            ISSUE_SUMMARY, BRIGADIR_REMINDER, BRIGADIR_DEADLINE, ATTENDANCE_REMINDER
        ) + extraTypes
        repeat(days.coerceIn(1, 30)) { offset ->
            val date = today.plusDays(offset.toLong())
            types.forEach { type ->
                val pending = PendingIntent.getBroadcast(
                    context,
                    ("$type|$date").hashCode(),
                    Intent(context, NotificationReceiver::class.java),
                    PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
                )
                if (pending != null) {
                    alarm.cancel(pending)
                    pending.cancel()
                }
            }
        }
    }

    private fun schedule(context: Context, whenAt: LocalDateTime, type: String, recordDate: LocalDate) {
        val now = LocalDateTime.now()
        if (!whenAt.isAfter(now)) return
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, NotificationReceiver::class.java).apply {
            putExtra(EXTRA_TYPE, type)
            putExtra(EXTRA_DATE, recordDate.toString())
        }
        val requestCode = ("$type|$recordDate").hashCode()
        val pending = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val millis = whenAt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending)
    }
}
