package uz.toybola.factory.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import uz.toybola.factory.ui.model.AppLanguage
import uz.toybola.factory.ui.model.AppSettings
import uz.toybola.factory.ui.model.AppStrings
import uz.toybola.factory.ui.model.AppThemePreset
import uz.toybola.factory.ui.model.SelectableThemePresets
import uz.toybola.factory.ui.model.normalized

/**
 * Global settings drawer.
 *
 * The status/navigation safe areas are intentionally outside the scaled density so system-bar
 * clearance never shrinks. Only the drawer's own content is scaled.
 */
@Composable
fun GlobalDrawer(
    strings: AppStrings,
    settings: AppSettings,
    onSettingsChange: (AppSettings) -> Unit,
    unreadNotifications: Int,
    onNotifications: () -> Unit,
    showUserManagement: Boolean,
    onUserManagement: () -> Unit,
    onBackupRestore: () -> Unit,
    onLock: () -> Unit
) {
    val baseDensity = LocalDensity.current
    val scale = settings.drawerScalePercent.coerceIn(70, 110) / 100f
    val scaledDensity = remember(baseDensity.density, baseDensity.fontScale, scale) {
        Density(
            density = baseDensity.density * scale,
            fontScale = baseDensity.fontScale
        )
    }

    Column(
        modifier = Modifier
            .fillMaxHeight()
            .fillMaxWidth()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        CompositionLocalProvider(LocalDensity provides scaledDensity) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
            ) {
                Text(strings.menu, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))

                SettingBox(title = strings.notifications) {
                    TextButton(onClick = onNotifications) {
                        Text(if (unreadNotifications > 0) strings.notificationCount(unreadNotifications) else strings.open)
                    }
                }

                if (showUserManagement) {
                    SettingBox(title = strings.userManagement) {
                        TextButton(onClick = onUserManagement) { Text(strings.manage) }
                    }
                }

                SettingBox(title = strings.backupRestore) {
                    TextButton(onClick = onBackupRestore) { Text(strings.open) }
                }

                SettingBox(title = strings.theme) {
                    var open by remember { mutableStateOf(false) }
                    TextButton(onClick = { open = true }) {
                        Text(settings.themePreset.displayName(strings))
                    }
                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                        SelectableThemePresets.forEach { preset ->
                            DropdownMenuItem(
                                text = { Text(preset.displayName(strings)) },
                                onClick = {
                                    open = false
                                    onSettingsChange(settings.copy(themePreset = preset, darkMode = preset == AppThemePreset.DARK_CALM))
                                }
                            )
                        }
                    }
                }

                SettingBox(title = strings.languageTitle) {
                    var open by remember { mutableStateOf(false) }
                    TextButton(onClick = { open = true }) { Text(settings.language.displayName()) }
                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                        AppLanguage.entries.forEach { language ->
                            DropdownMenuItem(
                                text = { Text(language.displayName()) },
                                onClick = {
                                    open = false
                                    onSettingsChange(settings.copy(language = language))
                                }
                            )
                        }
                    }
                }

                SettingBox(title = strings.autoLock) {
                    var open by remember { mutableStateOf(false) }
                    TextButton(onClick = { open = true }) {
                        Text("${settings.autoLockMinutes} ${strings.minutes}")
                    }
                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                        listOf(1, 3, 5, 10, 30).forEach { minute ->
                            DropdownMenuItem(
                                text = { Text("$minute ${strings.minutes}") },
                                onClick = {
                                    open = false
                                    onSettingsChange(settings.copy(autoLockMinutes = minute))
                                }
                            )
                        }
                    }
                }

                SettingBox(title = strings.drawerScale) {
                    var open by remember { mutableStateOf(false) }
                    TextButton(onClick = { open = true }) {
                        Text("${settings.drawerScalePercent}%")
                    }
                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                        listOf(70, 80, 90, 100, 110).forEach { percent ->
                            DropdownMenuItem(
                                text = { Text("$percent%") },
                                onClick = {
                                    open = false
                                    onSettingsChange(settings.copy(drawerScalePercent = percent))
                                }
                            )
                        }
                    }
                }

                Spacer(Modifier.weight(1f))
                HorizontalDivider()
                Button(onClick = onLock, modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) {
                    Text(strings.logout)
                }
            }
        }
    }
}

@Composable
private fun SettingBox(title: String, content: @Composable () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        shape = RoundedCornerShape(18.dp),
        tonalElevation = 1.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            content()
        }
    }
}

private fun AppLanguage.displayName(): String = when (this) {
    AppLanguage.UZ -> "O‘zbekcha"
    AppLanguage.RU -> "Русский"
    AppLanguage.EN -> "English"
}

private fun AppThemePreset.displayName(strings: AppStrings): String = when (normalized(false)) {
    AppThemePreset.SYSTEM -> strings.systemTheme
    AppThemePreset.LIGHT_CALM -> strings.lightCalmTheme
    AppThemePreset.SOFT_BLUE -> strings.softBlueTheme
    AppThemePreset.DARK_CALM -> strings.darkCalmTheme
    else -> strings.lightCalmTheme
}
