package uz.toybola.factory.core.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

class TpModelsTest {
    @Test
    fun colorAllocationKeepsExactOrderTotal() {
        val result = allocateByColor(
            2_000,
            listOf(
                TpColorRule("001", 35.0, 200.0),
                TpColorRule("002", 35.0, 200.0),
                TpColorRule("003", 30.0, 400.0)
            )
        )
        assertEquals(mapOf("001" to 700, "002" to 700, "003" to 600), result)
        assertEquals(2_000, result.values.sum())
    }

    @Test
    fun pairedMouldUsesOneShotCountForBothOutputs() {
        val product = TpProduct(
            id = "p1", article = "TB-055", name = "B Kamaz",
            details = listOf(
                detail("cab", "Kabina", "M-1", required = 2_000, perShot = 4),
                detail("bumper", "Banfer", "M-1", required = 2_000, perShot = 4)
            )
        )
        val order = TpOrder("o1", "P-0001", product.id, product.article, product.name, 1, 1, "2026-08-23", "", TpOrderStatus.NEW, "2026-08-23T08:00")
        val jobs = buildPlanJobs(TpData(products = listOf(product)), order) { "job" }
        assertEquals(1, jobs.size)
        assertEquals(500, jobs.single().requiredShots)
        assertEquals(2, jobs.single().outputs.size)
        assertEquals(2_000, jobs.single().outputs[0].plannedPieces)
        assertEquals(50.0, jobs.single().requiredResinKg, 0.0001)
    }

    @Test
    fun legacyMachineIdsDoNotRestrictCapacityBasedCompatibility() {
        val d = detail("cab", "Kabina", "M-1", required = 1, perShot = 1)
            .copy(compatibleMachineIds = setOf("old-machine"), compatibleCapacities = setOf(60))
        assertTrue(d.acceptsMachine(TpMachine("new-machine", "shop", 1, capacity = 60)))
        assertTrue(!d.acceptsMachine(TpMachine("wrong-capacity", "shop", 2, capacity = 90)))
    }

    @Test
    fun machineCapacityFiltersEligibleMachines() {
        val d = detail("wheel", "Balon", "M-60", required = 1, perShot = 1)
            .copy(compatibleCapacities = setOf(60, 90))
        assertTrue(d.acceptsMachine(TpMachine("m60", "shop", 1, capacity = 60)))
        assertTrue(d.acceptsMachine(TpMachine("m90", "shop", 2, capacity = 90)))
        assertTrue(!d.acceptsMachine(TpMachine("m120", "shop", 3, capacity = 120)))
        assertTrue(!d.acceptsMachine(TpMachine("legacy", "shop", 4, capacity = 0)))
    }

    @Test
    fun pairedMouldRejectsConflictingCapacityClasses() {
        val first = detail("cab", "Kabina", "M-1", required = 1, perShot = 1).copy(compatibleCapacities = setOf(60))
        val second = detail("bumper", "Banfer", "M-1", required = 1, perShot = 1).copy(compatibleCapacities = setOf(90))
        val product = TpProduct("p1", "TB-055", "B Kamaz", listOf(first, second))
        val order = TpOrder("o1", "P-1", "p1", "TB-055", "B Kamaz", 1, 1, "2026-08-24", "", TpOrderStatus.NEW, "now")
        try {
            buildPlanJobs(TpData(products = listOf(product)), order) { "job" }
            fail("Conflicting capacity sets must be rejected")
        } catch (error: IllegalArgumentException) {
            assertTrue(error.message.orEmpty().contains("umumiy stanok sig‘imi"))
        }
    }

    @Test
    fun orderForecastUsesSoonestCompatibleMachine() {
        val d = detail("wheel", "Balon", "M-60", required = 1, perShot = 1)
            .copy(cycleSeconds = 60, compatibleCapacities = setOf(60))
        val product = TpProduct("p", "TB-1", "Toy", listOf(d))
        val order = TpOrder("o", "P-1", "p", "TB-1", "Toy", 10, 1, "2026-08-24", "", TpOrderStatus.NEW, "now")
        val busy = TpPlanJob(
            id = "busy", orderId = "other", moldCode = "X", colorCode = "001", outputs = emptyList(),
            requiredShots = 30, cycleSeconds = 60, estimatedMinutes = 30, resinCode = "S1",
            requiredResinKg = 0.0, requiredColorGrams = 0.0, compatibleMachineIds = emptySet(),
            machineId = "m1", priority = 1
        )
        val data = TpData(
            products = listOf(product), orders = listOf(order), jobs = listOf(busy),
            machines = listOf(
                TpMachine("m1", "shop", 1, capacity = 60),
                TpMachine("m2", "shop", 2, capacity = 60)
            )
        )
        assertEquals(10, data.orderForecastMinutes("o"))
    }


    @Test
    fun detailCanOfferMultipleResinsAndPlanUsesCommonOption() {
        val first = detail("cab", "Kabina", "M-1", required = 1, perShot = 1)
            .copy(resinCodes = listOf("PP", "PE"), compatibleCapacities = setOf(60))
        val second = detail("bumper", "Banfer", "M-1", required = 1, perShot = 1)
            .copy(resinCodes = listOf("ABS", "PE"), compatibleCapacities = setOf(60))
        val product = TpProduct("p1", "TB-055", "B Kamaz", listOf(first, second))
        val order = TpOrder("o1", "P-1", "p1", "TB-055", "B Kamaz", 1, 1, "2026-08-24", "", TpOrderStatus.NEW, "now")
        val jobs = buildPlanJobs(TpData(products = listOf(product)), order) { "job" }
        assertEquals("PE", jobs.single().resinCode)
    }

    @Test
    fun pieceWorkPriceIsCalculatedPerShotNotPerPiece() {
        assertEquals(12_500L, calculatePieceWorkAmount(pieces = 100, piecesPerShot = 4, pricePerShot = 500.0))
        assertEquals(12_625L, calculatePieceWorkAmount(pieces = 101, piecesPerShot = 4, pricePerShot = 500.0))
    }

    @Test
    fun reducedMouldPathCountPaysByActualShots() {
        assertEquals(7_000L, calculatePieceWorkAmount(pieces = 560, piecesPerShot = 8, pricePerShot = 100.0))
        assertEquals(8_000L, calculatePieceWorkAmount(pieces = 560, piecesPerShot = 7, pricePerShot = 100.0))
    }

    @Test
    fun partialBagCreditsOnlyNewShiftPieces() {
        assertEquals(30, calculateReceiptCredit(100, 0, 0, 30))
        assertEquals(70, calculateReceiptCredit(100, 30, 1, 0))
        assertEquals(170, calculateReceiptCredit(100, 30, 2, 0))
    }

    @Test
    fun batchNumberPreservesPrefixAndPadding() {
        assertEquals("TP-0002", nextBatchNumber("TP-0001"))
        assertEquals("26", nextBatchNumber("25"))
        assertEquals("AVGUST-2", nextBatchNumber("AVGUST"))
    }

    @Test
    fun productBatchSuggestionUsesHighestNumericSuffixWithinThatProductHistory() {
        assertEquals("14", nextBatchNumberForProduct(listOf("11", "13", "12")))
        assertEquals("TP-0010", nextBatchNumberForProduct(listOf("TP-0009", "TP-0007")))
        assertEquals("", nextBatchNumberForProduct(emptyList()))
    }

    @Test
    fun workerUsefulnessCombinesAdjustedNormAndQuality() {
        val worker = TpWorker("w", "b", "Bobur", 100_000)
        val data = TpData(
            shifts = listOf(TpShift("s", "Kunduzgi", "08:00", "18:00", listOf("10:00"))),
            brigades = listOf(TpBrigade("b", "shop", "s", "Brigada")),
            workers = listOf(worker),
            attendance = listOf(TpAttendance("w_d", "w", "b", "s", "2026-08-23", true, 300, "now")),
            receipts = listOf(TpReceipt("r", "j", "o", "d", "Detal", "m", "w", "Bobur", "b", "s", "2026-08-23", "001", 1, 100, 0, 0, 100, 500.0, "Ali", "now")),
            qualityRounds = listOf(TpQualityRound("q", "b", "s", "m", "w", "j", "2026-08-23", 1, "10:00", 80, "", "Sifat", "now"))
        )
        assertEquals(100.0, data.workerEfficiency("w", "2026-08-23")!!, 0.001)
        assertEquals(90.0, data.workerUsefulness("w", "2026-08-23")!!, 0.001)
    }


    @Test
    fun minusHoursReducesShiftMinutesBeforeEfficiencyCalculation() {
        val data = TpData(
            shifts = listOf(TpShift("s", "Kunduzgi", "08:00", "18:00", listOf("10:00"))),
            brigades = listOf(TpBrigade("b", "shop", "s", "Brigada")),
            workers = listOf(TpWorker("w", "b", "Bobur")),
            attendance = listOf(TpAttendance("a", "w", "b", "s", "2026-08-23", true, 480, "now", minusHours = 2.0)),
            receipts = listOf(TpReceipt("r", "j", "o", "d", "Detal", "m", "w", "Bobur", "b", "s", "2026-08-23", "001", 1, 100, 0, 0, 100, 800.0, "Ali", "now")),
            settings = TpSettings(dailyTargetAmount = 100_000)
        )
        assertEquals(480, data.attendanceWorkMinutes("w", "2026-08-23"))
        assertEquals(100.0, data.workerEfficiency("w", "2026-08-23")!!, 0.001)
    }

    @Test
    fun globalDailyTargetOverridesLegacyWorkerTarget() {
        val data = TpData(
            shifts = listOf(TpShift("s", "Kunduzgi", "08:00", "18:00", listOf("10:00"))),
            brigades = listOf(TpBrigade("b", "shop", "s", "Brigada")),
            workers = listOf(TpWorker("w", "b", "Bobur", 50_000)),
            attendance = listOf(TpAttendance("a", "w", "b", "s", "2026-08-23", true, 600, "now")),
            receipts = listOf(TpReceipt("r", "j", "o", "d", "Detal", "m", "w", "Bobur", "b", "s", "2026-08-23", "001", 1, 100, 0, 0, 100, 1000.0, "Ali", "now")),
            settings = TpSettings(dailyTargetAmount = 100_000)
        )
        assertEquals(100.0, data.workerEfficiency("w", "2026-08-23")!!, 0.001)
    }

    @Test
    fun excelExporterCreatesRequiredWorkbookEntries() {
        val bytes = ByteArrayOutputStream().also { output ->
            TpXlsxExporter.write(output, TpReportTable("Hisobot", listOf("Davr"), listOf("A"), listOf(listOf("1"))))
        }.toByteArray()
        val entries = mutableSetOf<String>()
        ZipInputStream(bytes.inputStream()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                entries += entry.name
            }
        }
        assertTrue("xl/workbook.xml" in entries)
        assertTrue("xl/worksheets/sheet1.xml" in entries)
    }

    @Test
    fun reportIncludesAbsentOutputWorkerAndMaterialByActualDeliveryDate() {
        val worker = TpWorker("w", "b", "Bobur", 100_000)
        val job = TpPlanJob(
            id = "j", orderId = "o", moldCode = "M-1", colorCode = "001", outputs = emptyList(),
            requiredShots = 10, cycleSeconds = 60, estimatedMinutes = 10, resinCode = "S1",
            requiredResinKg = 5.0, requiredColorGrams = 100.0, compatibleMachineIds = emptySet(),
            machineId = "m", brigadeId = "b", shiftId = "s", priority = 1,
            materialStatus = TpMaterialStatus.DELIVERED,
            materialConfirmedAt = "2026-08-01T10:00", materialDeliveredAt = "2026-08-23T10:00"
        )
        val data = TpData(
            shifts = listOf(TpShift("s", "Kunduzgi", "08:00", "18:00", listOf("10:00"))),
            brigades = listOf(TpBrigade("b", "shop", "s", "Bahodir A")),
            workers = listOf(worker), jobs = listOf(job),
            attendance = listOf(TpAttendance("a", "w", "b", "s", "2026-08-23", true, 600, "now"))
        )
        val report = buildTpReport(data, "2026-08-23", "2026-08-23", null)
        assertTrue(report.rows.any { it.firstOrNull() == "ISHCHI" && it.getOrNull(2) == "Bobur" })
        assertTrue(report.rows.any { it.firstOrNull() == "SERYO" && it.getOrNull(2) == "S1" })
    }

    @Test
    fun fractionalShotPriceIsPreservedInSalaryCalculation() {
        assertEquals(2610L, calculatePieceWorkAmount(pieces = 100, piecesPerShot = 4, pricePerShot = 104.4))
    }

    @Test
    fun fractionalShotPriceFormattingKeepsOnlyMeaningfulDecimals() {
        assertEquals("104", formatTpNumber(104.0))
        assertEquals("104.4", formatTpNumber(104.4))
        assertEquals("0.15", formatTpNumber(0.15000000000000002))
    }

    @Test
    fun materialLedgerCalculatesDailyOpeningIncomingOutgoingAndClosing() {
        val material = TpMaterial(
            id = "m", code = "02", name = "02", type = TpMaterialType.RESIN, availableAmount = 100.0,
            movements = listOf(
                TpMaterialMovement("a", TpMaterialMovementKind.IN, 20.0, "2026-08-24T09:00:00"),
                TpMaterialMovement("b", TpMaterialMovementKind.OUT, 15.0, "2026-08-25T10:00:00"),
                TpMaterialMovement("c", TpMaterialMovementKind.IN, 5.0, "2026-08-25T12:00:00")
            )
        )
        assertEquals(120.0, material.openingStock("2026-08-25"), 0.0001)
        assertEquals(5.0, material.dayIncoming("2026-08-25"), 0.0001)
        assertEquals(15.0, material.dayOutgoing("2026-08-25"), 0.0001)
        assertEquals(110.0, material.closingStock("2026-08-25"), 0.0001)
    }


    @Test
    fun attendanceUsesDailyBrigadeShiftSelectionWithLegacyFallback() {
        val data = TpData(
            shifts = listOf(
                TpShift("day", "KUN", "07:40", "19:00", emptyList()),
                TpShift("night", "TUN", "19:00", "07:40", emptyList())
            ),
            brigades = listOf(TpBrigade("b", "shop", "day", "1-brigada")),
            workers = listOf(TpWorker("w", "b", "Worker")),
            brigadeShiftSelections = listOf(
                TpBrigadeShiftSelection("b|2026-09-23", "b", "2026-09-23", "night", "2026-09-23T18:50", "Brigadir")
            )
        )
        assertEquals("night", data.brigadeShiftIdForDate("b", "2026-09-23"))
        assertEquals("day", data.brigadeShiftIdForDate("b", "2026-09-22"))
        assertEquals(760, data.workerStandardMinutes("w", "2026-09-23"))
        assertEquals(680, data.workerStandardMinutes("w", "2026-09-22"))
    }

    @Test
    fun overnightWorkerAssignmentStoresRealCalendarDate() {
        val shift = TpShift("night", "TUN", "19:00", "07:00", emptyList())
        val recordDate = java.time.LocalDate.parse("2026-09-23")
        assertEquals(
            java.time.LocalDateTime.parse("2026-09-23T19:00"),
            resolveTpAssignmentDateTime(recordDate, shift, java.time.LocalTime.parse("19:00"))
        )
        assertEquals(
            java.time.LocalDateTime.parse("2026-09-24T03:15"),
            resolveTpAssignmentDateTime(recordDate, shift, java.time.LocalTime.parse("03:15"))
        )
        assertEquals(
            java.time.LocalDateTime.parse("2026-09-23T19:00"),
            parseTpAssignmentDateTime("2026-09-23", "19:00")
        )
        assertEquals(
            java.time.LocalDateTime.parse("2026-09-24T03:15"),
            parseTpAssignmentDateTime("2026-09-23", "2026-09-24T03:15")
        )
    }

    @Test
    fun attendanceDayStateTracksClosedAndReopenedShiftIndependentlyFromWorkerRows() {
        val closed = TpAttendanceDayState(
            id = "2026-09-23_s-day",
            date = "2026-09-23",
            shiftId = "s-day",
            closedAt = "2026-09-24T08:55:00",
            closedBy = "Davomadchi"
        )
        assertTrue(closed.isClosed)
        assertTrue(!closed.isReopened)

        val reopened = closed.copy(closedAt = null, closedBy = "", reopenedAt = "2026-09-24T09:10:00", reopenCount = 1)
        val data = TpData(attendanceDays = listOf(reopened))
        assertTrue(!reopened.isClosed)
        assertTrue(reopened.isReopened)
        assertEquals(reopened, data.attendanceDay("2026-09-23", "s-day"))
        assertEquals(null, data.attendanceDay("2026-09-23", "s-night"))
    }

    private fun detail(id: String, name: String, mold: String, required: Int, perShot: Int) = TpDetail(
        id = id, name = name, moldCode = mold, requiredPerProduct = required,
        piecesPerShot = perShot, bagCapacity = 100, cycleSeconds = 60,
        grossShotWeightGrams = 100.0, unusableShotWeightGrams = 5.0,
        resinCode = "S1", unitPrice = 100.0, compatibleMachineIds = emptySet(),
        colors = listOf(TpColorRule("001", 1.0, 200.0))
    )
    @Test
    fun duplicateActiveWorkerOnSameMachineIsDetected() {
        val active = TpMachineWorkerAssignment(
            id = "a1",
            machineId = "m1",
            brigadeId = "b1",
            shiftId = "s1",
            date = "2026-09-24",
            workerId = "w1",
            workerNameSnapshot = "Worker 1",
            startedAt = "2026-09-24T07:40",
            createdAt = "2026-09-24T07:40"
        )
        val ended = active.copy(id = "a2", endedAt = "2026-09-24T09:00")
        assertTrue(listOf(active).hasActiveMachineWorker("m1", "b1", "2026-09-24", "w1"))
        assertTrue(!listOf(ended).hasActiveMachineWorker("m1", "b1", "2026-09-24", "w1"))
        assertTrue(!listOf(active).hasActiveMachineWorker("m2", "b1", "2026-09-24", "w1"))
    }

}
