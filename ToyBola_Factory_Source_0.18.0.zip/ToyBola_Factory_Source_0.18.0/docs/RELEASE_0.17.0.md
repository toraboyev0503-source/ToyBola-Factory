# ToyBola Factory 0.17.0

## TP → Qabul UX yangilanishi

- Stanok kartasiga bevosita `+ Qabul` tugmasi qo‘shildi.
- KUN/TUN smenalari saqlandi; TUN smenasida yarim tundan keyingi qabul sana jihatdan smena boshlangan ish kuniga yoziladi.
- Stanoklar sexlar bo‘yicha guruhlanadi (`1-sex`, `2-sex`, ...).
- Stanokka aktiv biriktirilgan ishchilar kartada ko‘rinadi.
- Bitta ishchi bo‘lsa avtomatik tanlanadi; bir nechta biriktirilgan ishchi bo‘lsa faqat shu ishchilar orasidan tanlanadi.
- Biriktirish topilmasa brigada ishchilari fallback sifatida ko‘rsatiladi.
- Vazifa/detal bitta bo‘lsa avtomatik, ko‘p bo‘lsa tanlov orqali aniqlanadi.
- Sana va qabul qiluvchi avtomatik.
- `Chala` default 0; `To‘liq qop` maydoniga avtomatik fokus beriladi.
- Reja / Qabul / Qoladi ko‘rsatkichlari qo‘shildi.
- Rejadan ortiq qabul mumkin; oldin ogohlantirish va alohida tasdiq chiqadi.
- Oldingi chala progress ko‘rinishida beriladi.
- `Saqlash` o‘rniga `Qabul qilish` ishlatiladi.
- Qabuldan keyin stanoklar ro‘yxatidagi scroll holati saqlanadi.

## Jim soni va ish haqi

- Har qabulda detalning master `default jimdagi detal soni` saqlanadi.
- Qabul qiluvchi shu qabul uchun amaldagi jim sonini vaqtincha kamaytirishi mumkin (masalan 8 → 7).
- Master default o‘zgarmaydi.
- Ish haqi qabul paytidagi amaldagi jim soni bo‘yicha hisoblanadi.
- Tarixda default va amaldagi jim soni ko‘rinadi.
- Qabulni tahrirlashda jim sonini ham tuzatish mumkin.

## Moslik

- Eski qabul yozuvlarida yangi `defaultPiecesPerShotSnapshot` bo‘lmasa, mavjud `piecesPerShotSnapshot` default sifatida olinadi.
- Debug signing avvalgi `toybola-debug.keystore` bilan saqlangan, shuning uchun debug APK oldingi debug o‘rnatish ustiga update bo‘lib o‘rnatilishi mumkin.
