# ToyBola Factory 0.18.0

## TP → Sifat UX yangilanishi

- `Baholash` va `Kun muammosi` alohida oraliq menyu o‘rniga yuqori tablarga ko‘chirildi; `Baholash` default ochiladi.
- Baholash ekranidan Sex filtri olib tashlandi; stanoklar `1-sex`, `2-sex`, ... guruhlari bilan ko‘rinadi.
- KUN/TUN smena tanlovi saqlandi.
- Joriy sifat raundi avtomatik tavsiya qilinadi; hali ochilmagan raundlar disabled, eski raundlar natijalarni ko‘rish uchun ochiladi.
- Yuqorida raund progressi `baholandi / jami` va qolgan baholash sonini ko‘rsatadi.
- Barcha ishchilar baholanganda raund avtomatik `yakunlandi` holatini ko‘rsatadi.
- Baholanmagan stanoklar tepada, to‘liq baholanganlar pastda yig‘ilgan (`collapsed`) guruhda turadi.

## Stanok va ishchi oqimi

- Sifat baholash faqat stanokka brigadir tomonidan faol biriktirilgan ishchilarni oladi.
- Bitta ishchi bo‘lsa karta orqali to‘g‘ridan baholashga o‘tiladi.
- Bir nechta ishchi bo‘lsa har biri alohida baholanadi va stanok kartasi `1/3`, `2/3`, `3/3` progressini ko‘rsatadi.
- Sana, smena va raund baholash dialogida qayta so‘ralmaydi; dastur avtomatik oladi.
- TUN smenasida yarim tundan keyingi baholash smena boshlangan ish kuniga yoziladi.

## Tez baholash

- Katta tugmalar: `1 A’lo`, `2 Yaxshi`, `3 Qoniqarsiz`, `4 Yomon`.
- `A’lo` va `Yaxshi` bir bosishda saqlanadi.
- Tez saqlashdan keyin Snackbar orqali `Bekor qilish` (Undo) mavjud.
- Undo server sync uchun `TP_QUALITY_DELETE` bilan to‘liq qo‘llab-quvvatlandi.
- `Ishchi mavjud emas` → `Sababli / Sababsiz` oqimi saqlandi; Sababli holatda sabab majburiy.

## Muammoli baholar

- 3–4 bahoda standart muammo turlari:
  - Erigan
  - Ablo chala kesilgan
  - Rangi yomon chiqqan
  - Soni xato solingan
  - Boshqa
- `Boshqa` tanlansa muammo turi qo‘lda yoziladi.
- 3–4 bahoda batafsil izoh majburiy.
- `Saqlash + Kun muammosiga aylantirish` bilan baho va Kun muammosi bir oqimda yoziladi.

## Kun muammosi

- Stanok kartasidan `+ Kun muammosi` bosilganda stanok/vazifa konteksti avtomatik olinadi.
- Sana va muallif avtomatik.
- Kategoriya free-text o‘rniga preset: `Stanok`, `Forma`, `Material`, `Sifat`, `Boshqa`.
- Javobgar preset: `Brigadir`, `Mexanik`, `Seryo`, `Forma`, `Elektrik`, `Boshqa`.
- `Boshqa` variantlarida qo‘lda kiritish maydoni ochiladi.

## Bildirishnoma

- TP Sifat yozish huquqi bor foydalanuvchiga har raund boshlanishidan 30 daqiqa oldin lokal bildirishnoma rejalashtiriladi.
- Bildirishnoma KUN/TUN smenasi va raund raqamini ko‘rsatadi va bosilganda TP → Sifat ekranini ochadi.
- Telefon qayta yoqilganda va ilova yangilanganda eslatmalar qayta rejalashtiriladi.
