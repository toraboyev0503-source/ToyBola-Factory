# Toy Bola Factory Management System — Android 0.2.0

0.2.0 — birinchi funksional Sborka ma'lumotlari versiyasi.

## Asosiy o‘zgarishlar
- Barcha asosiy ekranlarda status bar / notch / navigation bar safe-area qo‘llab-quvvatlanadi.
- Ilova alohida PIN saqlamaydi. Qurilma kodi + foydalanuvchi kodi tekshirilgach Android telefonning o‘z ekran qulfi (PIN/parol/pattern) bilan tasdiqlanadi.
- Eski 0.1.0 foydalanuvchi kodi va qurilma kodi saqlanib qoladi; eski app PIN hash ishlatilmaydi.
- Avtomatik bloklash telefon qulfi bilan qayta autentifikatsiya talab qiladi.
- Sborka → Ma’lumot ishlaydi: Brigadalar, Ishchilar, Mahsulotlar, F/K, Ish vaqti, sifat raund vaqtlari, samaradorlik normativi, monitoring mezonlari, yig‘uv bosqichlari, Arxiv, yangi yilga normativlarni tayyorlash.
- Mahsulot narxi, F/K va normativlar amal qilish sanasi bilan tarixiy saqlanadi.
- Arxiv o‘chirmaydi: yozuvni oddiy ro‘yxatdan yashiradi va qayta tiklash mumkin.

## GitHub Actions
Workflow repository rootida Android loyiha bo‘lsa bevosita, aks holda `ToyBola_Factory_Source_*.zip` ichidan eng yangi versiyani topib ochadi.

Build ketma-ketligi:
1. JDK 17
2. Android SDK 36 / Build Tools 36.0.0
3. Gradle 9.5.0 wrapper
4. Unit tests
5. Android lint
6. assembleDebug
7. app-debug.apk artifact

## Hozirgi chegarasi
Brigadir, Sifat, Kun muammosi va Monitoringning kundalik operatsion ekranlari keyingi versiyalarda ulanadi. 0.2.0 da ularning ma’lumot manbasi bo‘ladigan Sborka master data ishlaydi.

## Debug signing
0.2.0 dan boshlab GitHub Actions debug APK uchun loyiha ichidagi faqat testga mo‘ljallangan barqaror debug kalit ishlatiladi. Bu 0.2.0 va keyingi debug buildlarni bir-birining ustidan update qilishga yordam beradi. Ushbu kalit final/production release uchun ishlatilmaydi.
