package uz.toybola.factory.core.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.Year
import java.util.UUID
import java.util.Locale

class AssemblyDataRepository(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    @Synchronized
    fun load(): AssemblyData {
        val raw = prefs.getString(KEY_DATA, null) ?: return defaultData().also(::save)
        return runCatching { decode(JSONObject(raw)) }.getOrElse { defaultData().also(::save) }
    }

    @Synchronized
    fun addBrigade(name: String): Result<Unit> = mutate { data ->
        val clean = name.normalizeHumanText()
        require(clean.isNotBlank()) { "Brigada nomi bo‘sh bo‘lmasin" }
        require(data.brigades.none { !it.archived && it.name.equals(clean, true) }) { "Bunday brigada mavjud" }
        data.copy(brigades = data.brigades + Brigade(UUID.randomUUID().toString(), clean))
    }

    @Synchronized
    fun renameBrigade(id: String, name: String): Result<Unit> = mutate { data ->
        val clean = name.normalizeHumanText()
        require(clean.isNotBlank()) { "Brigada nomi bo‘sh bo‘lmasin" }
        require(data.brigades.none { it.id != id && !it.archived && it.name.equals(clean, true) }) { "Bunday brigada mavjud" }
        data.copy(brigades = data.brigades.map { if (it.id == id) it.copy(name = clean) else it })
    }

    @Synchronized
    fun archiveBrigade(id: String, archived: Boolean): Result<Unit> = mutate { data ->
        val target = data.brigades.firstOrNull { it.id == id } ?: return@mutate data
        if (!archived) {
            require(data.brigades.none { it.id != id && !it.archived && it.name.equals(target.name, true) }) { "Shu nomli faol brigada mavjud" }
        }
        data.copy(brigades = data.brigades.map { if (it.id == id) it.copy(archived = archived) else it })
    }

    @Synchronized
    fun addWorker(brigadeId: String, name: String, startDate: String): Result<Unit> = mutate { data ->
        require(data.brigades.any { it.id == brigadeId && !it.archived }) { "Brigada tanlang" }
        val clean = name.normalizeHumanText()
        require(clean.isNotBlank()) { "Ishchi ismini kiriting" }
        LocalDate.parse(startDate)
        data.copy(workers = data.workers + Worker(UUID.randomUUID().toString(), brigadeId, clean, startDate))
    }

    @Synchronized
    fun updateWorker(id: String, brigadeId: String, name: String, startDate: String): Result<Unit> = mutate { data ->
        require(data.brigades.any { it.id == brigadeId && !it.archived }) { "Brigada tanlang" }
        val clean = name.normalizeHumanText()
        require(clean.isNotBlank()) { "Ishchi ismini kiriting" }
        LocalDate.parse(startDate)
        data.copy(workers = data.workers.map {
            if (it.id == id) it.copy(brigadeId = brigadeId, name = clean, startDate = startDate) else it
        })
    }

    @Synchronized
    fun archiveWorker(id: String, archived: Boolean): Result<Unit> = mutate { data ->
        data.copy(workers = data.workers.map { if (it.id == id) it.copy(archived = archived) else it })
    }

    @Synchronized
    fun addProduct(
        brigadeId: String,
        article: String,
        name: String,
        price: Long,
        stages: List<String>
    ): Result<Unit> = mutate { data ->
        validateProduct(data, null, brigadeId, article, name, price)
        val today = LocalDate.now().toString()
        data.copy(products = data.products + Product(
            id = UUID.randomUUID().toString(),
            brigadeId = brigadeId,
            article = article.trim().uppercase(Locale.ROOT),
            name = name.normalizeHumanText(),
            priceHistory = listOf(PriceVersion(price, today)),
            stages = stages.cleanStages()
        ))
    }

    @Synchronized
    fun updateProduct(
        id: String,
        brigadeId: String,
        article: String,
        name: String,
        price: Long,
        stages: List<String>
    ): Result<Unit> = mutate { data ->
        validateProduct(data, id, brigadeId, article, name, price)
        val today = LocalDate.now().toString()
        data.copy(products = data.products.map { product ->
            if (product.id != id) return@map product
            val priceHistory = if (product.currentPrice != price) {
                product.priceHistory.filterNot { it.effectiveFrom == today } + PriceVersion(price, today)
            } else product.priceHistory
            product.copy(
                brigadeId = brigadeId,
                article = article.trim().uppercase(Locale.ROOT),
                name = name.normalizeHumanText(),
                priceHistory = priceHistory,
                stages = stages.cleanStages()
            )
        })
    }

    @Synchronized
    fun archiveProduct(id: String, archived: Boolean): Result<Unit> = mutate { data ->
        val target = data.products.firstOrNull { it.id == id } ?: return@mutate data
        if (!archived) {
            require(data.products.none { it.id != id && !it.archived && it.article.equals(target.article, true) }) { "Shu artikulli faol mahsulot mavjud" }
        }
        data.copy(products = data.products.map { if (it.id == id) it.copy(archived = archived) else it })
    }

    @Synchronized
    fun setBrigadeFk(brigadeId: String, value: Long, effectiveFrom: String = LocalDate.now().toString()): Result<Unit> = mutate { data ->
        require(value > 0) { "F/K 0 dan katta bo‘lsin" }
        LocalDate.parse(effectiveFrom)
        val existing = data.brigadeFk.firstOrNull { it.brigadeId == brigadeId }
        val updated = if (existing == null) {
            data.brigadeFk + BrigadeFkHistory(brigadeId, listOf(LongVersion(value, effectiveFrom)))
        } else {
            data.brigadeFk.map {
                if (it.brigadeId == brigadeId) it.copy(
                    versions = it.versions.filterNot { v -> v.effectiveFrom == effectiveFrom } + LongVersion(value, effectiveFrom)
                ) else it
            }
        }
        data.copy(brigadeFk = updated)
    }

    @Synchronized
    fun setWorkHours(value: Int, effectiveFrom: String = LocalDate.now().toString()): Result<Unit> = mutate { data ->
        require(value in 1..24) { "Ish vaqti 1–24 soat bo‘lsin" }
        LocalDate.parse(effectiveFrom)
        data.copy(workHours = data.workHours.upsert(IntVersion(value, effectiveFrom)))
    }

    @Synchronized
    fun setEfficiencyNorm(value: Int, effectiveFrom: String = LocalDate.now().toString()): Result<Unit> = mutate { data ->
        require(value in 1..200) { "Normativ 1–200% oralig‘ida bo‘lsin" }
        LocalDate.parse(effectiveFrom)
        data.copy(efficiencyNorm = data.efficiencyNorm.upsert(IntVersion(value, effectiveFrom)))
    }

    @Synchronized
    fun setRoundTimes(first: String, second: String, third: String, effectiveFrom: String = LocalDate.now().toString()): Result<Unit> = mutate { data ->
        listOf(first, second, third).forEach { java.time.LocalTime.parse(it) }
        LocalDate.parse(effectiveFrom)
        data.copy(roundTimes = data.roundTimes.filterNot { it.effectiveFrom == effectiveFrom } +
            RoundTimesVersion(first, second, third, effectiveFrom))
    }

    @Synchronized
    fun setMonitoringWeights(
        brigadir: BrigadirWeights,
        quality: QualityWeights,
        effectiveFrom: String = LocalDate.now().toString()
    ): Result<Unit> = mutate { data ->
        require(brigadir.total == 100) { "Brigadir mezonlari jami 100% bo‘lsin" }
        require(quality.total == 100) { "Sifat mezonlari jami 100% bo‘lsin" }
        LocalDate.parse(effectiveFrom)
        data.copy(monitoringWeights = data.monitoringWeights.filterNot { it.effectiveFrom == effectiveFrom } +
            MonitoringWeightsVersion(brigadir, quality, effectiveFrom))
    }

    @Synchronized
    fun prepareNextYear(): Result<Int> = mutateWithValue { data ->
        val nextYear = Year.now().value + 1
        if (nextYear in data.preparedYears) return@mutateWithValue data to nextYear
        val effective = "$nextYear-01-01"

        var updated = data
        updated = updated.copy(
            workHours = updated.workHours.upsert(IntVersion(updated.currentWorkHours(), effective)),
            efficiencyNorm = updated.efficiencyNorm.upsert(IntVersion(updated.currentEfficiencyNorm(), effective)),
            roundTimes = updated.roundTimes.filterNot { it.effectiveFrom == effective } + updated.currentRoundTimes().copy(effectiveFrom = effective),
            monitoringWeights = updated.monitoringWeights.filterNot { it.effectiveFrom == effective } + updated.currentMonitoringWeights().copy(effectiveFrom = effective),
            brigadeFk = updated.brigadeFk.map { fk ->
                fk.current?.let { current ->
                    fk.copy(versions = fk.versions.filterNot { it.effectiveFrom == effective } + LongVersion(current, effective))
                } ?: fk
            },
            preparedYears = (updated.preparedYears + nextYear).distinct().sorted()
        )
        updated to nextYear
    }

    private fun validateProduct(data: AssemblyData, currentId: String?, brigadeId: String, article: String, name: String, price: Long) {
        require(data.brigades.any { it.id == brigadeId && !it.archived }) { "Brigada tanlang" }
        require(article.trim().isNotBlank()) { "Artikul kiriting" }
        require(name.trim().isNotBlank()) { "Mahsulot nomini kiriting" }
        require(price > 0) { "Narx 0 dan katta bo‘lsin" }
        require(data.products.none { it.id != currentId && !it.archived && it.article.equals(article.trim(), true) }) {
            "Bu artikul avval kiritilgan"
        }
    }

    private fun List<String>.cleanStages(): List<String> = map { it.normalizeHumanText() }.filter { it.isNotBlank() }.distinct()

    private fun String.normalizeHumanText(): String {
        val input = trim().replace(Regex("\\s+"), " ")
        if (input.isBlank()) return input
        val out = StringBuilder(input.length + 8)
        var capitalizeNext = true
        var i = 0
        while (i < input.length) {
            val ch = input[i]
            if (ch.isWhitespace()) {
                if (out.isNotEmpty() && out.last() != ' ') out.append(' ')
                i++
                continue
            }
            val actual = if (capitalizeNext && ch.isLetter()) ch.uppercaseChar() else ch
            out.append(actual)
            capitalizeNext = false
            if (ch == '.' || ch == '!' || ch == '?') {
                capitalizeNext = true
                if (i + 1 < input.length && !input[i + 1].isWhitespace()) out.append(' ')
            } else if (ch == ',' || ch == ';' || ch == ':') {
                if (i + 1 < input.length && !input[i + 1].isWhitespace()) out.append(' ')
            }
            i++
        }
        return out.toString().trim()
    }

    private fun List<IntVersion>.upsert(value: IntVersion): List<IntVersion> =
        filterNot { it.effectiveFrom == value.effectiveFrom } + value

    private fun defaultData(): AssemblyData = AssemblyData(
        workHours = listOf(IntVersion(10, "2000-01-01")),
        efficiencyNorm = listOf(IntVersion(85, "2000-01-01")),
        roundTimes = listOf(RoundTimesVersion("10:00", "13:00", "16:00", "2000-01-01")),
        monitoringWeights = listOf(MonitoringWeightsVersion(BrigadirWeights(), QualityWeights(), "2000-01-01"))
    )

    private inline fun mutate(transform: (AssemblyData) -> AssemblyData): Result<Unit> = runCatching {
        save(transform(load()))
    }

    private inline fun <T> mutateWithValue(transform: (AssemblyData) -> Pair<AssemblyData, T>): Result<T> = runCatching {
        val (updated, value) = transform(load())
        save(updated)
        value
    }

    private fun save(data: AssemblyData) {
        prefs.edit().putString(KEY_DATA, encode(data).toString()).apply()
    }

    private fun encode(data: AssemblyData): JSONObject = JSONObject().apply {
        put("brigades", JSONArray().apply { data.brigades.forEach { put(JSONObject().apply {
            put("id", it.id); put("name", it.name); put("archived", it.archived)
        }) } })
        put("workers", JSONArray().apply { data.workers.forEach { put(JSONObject().apply {
            put("id", it.id); put("brigadeId", it.brigadeId); put("name", it.name); put("startDate", it.startDate); put("archived", it.archived)
        }) } })
        put("products", JSONArray().apply { data.products.forEach { product -> put(JSONObject().apply {
            put("id", product.id); put("brigadeId", product.brigadeId); put("article", product.article); put("name", product.name); put("archived", product.archived)
            put("prices", JSONArray().apply { product.priceHistory.forEach { price -> put(JSONObject().apply { put("price", price.price); put("effectiveFrom", price.effectiveFrom) }) } })
            put("stages", JSONArray().apply { product.stages.forEach { put(it) } })
        }) } })
        put("brigadeFk", JSONArray().apply { data.brigadeFk.forEach { fk -> put(JSONObject().apply {
            put("brigadeId", fk.brigadeId)
            put("versions", JSONArray().apply { fk.versions.forEach { v -> put(JSONObject().apply { put("value", v.value); put("effectiveFrom", v.effectiveFrom) }) } })
        }) } })
        put("workHours", encodeIntVersions(data.workHours))
        put("efficiencyNorm", encodeIntVersions(data.efficiencyNorm))
        put("roundTimes", JSONArray().apply { data.roundTimes.forEach { v -> put(JSONObject().apply {
            put("first", v.first); put("second", v.second); put("third", v.third); put("effectiveFrom", v.effectiveFrom)
        }) } })
        put("monitoringWeights", JSONArray().apply { data.monitoringWeights.forEach { v -> put(JSONObject().apply {
            put("effectiveFrom", v.effectiveFrom)
            put("brigadir", JSONObject().apply { put("onTimeClose", v.brigadir.onTimeClose); put("noReopen", v.brigadir.noReopen); put("brigadeResult", v.brigadir.brigadeResult) })
            put("quality", JSONObject().apply { put("roundsOnTime", v.quality.roundsOnTime); put("rechecks", v.quality.rechecks); put("onTimeClose", v.quality.onTimeClose); put("dataDiscipline", v.quality.dataDiscipline) })
        }) } })
        put("preparedYears", JSONArray().apply { data.preparedYears.forEach { put(it) } })
    }

    private fun decode(root: JSONObject): AssemblyData = AssemblyData(
        brigades = root.optJSONArray("brigades").objects().map { Brigade(it.getString("id"), it.getString("name"), it.optBoolean("archived")) },
        workers = root.optJSONArray("workers").objects().map { Worker(it.getString("id"), it.getString("brigadeId"), it.getString("name"), it.getString("startDate"), it.optBoolean("archived")) },
        products = root.optJSONArray("products").objects().map { p -> Product(
            id = p.getString("id"), brigadeId = p.getString("brigadeId"), article = p.getString("article"), name = p.getString("name"),
            priceHistory = p.optJSONArray("prices").objects().map { PriceVersion(it.getLong("price"), it.getString("effectiveFrom")) },
            stages = p.optJSONArray("stages").strings(), archived = p.optBoolean("archived")
        ) },
        brigadeFk = root.optJSONArray("brigadeFk").objects().map { fk -> BrigadeFkHistory(
            fk.getString("brigadeId"), fk.optJSONArray("versions").objects().map { LongVersion(it.getLong("value"), it.getString("effectiveFrom")) }
        ) },
        workHours = decodeIntVersions(root.optJSONArray("workHours")),
        efficiencyNorm = decodeIntVersions(root.optJSONArray("efficiencyNorm")),
        roundTimes = root.optJSONArray("roundTimes").objects().map { RoundTimesVersion(it.getString("first"), it.getString("second"), it.getString("third"), it.getString("effectiveFrom")) },
        monitoringWeights = root.optJSONArray("monitoringWeights").objects().map { v ->
            val b = v.getJSONObject("brigadir"); val q = v.getJSONObject("quality")
            MonitoringWeightsVersion(
                BrigadirWeights(b.getInt("onTimeClose"), b.getInt("noReopen"), b.getInt("brigadeResult")),
                QualityWeights(q.getInt("roundsOnTime"), q.getInt("rechecks"), q.getInt("onTimeClose"), q.getInt("dataDiscipline")),
                v.getString("effectiveFrom")
            )
        },
        preparedYears = root.optJSONArray("preparedYears").ints()
    ).let { data ->
        data.copy(
            workHours = data.workHours.ifEmpty { listOf(IntVersion(10, "2000-01-01")) },
            efficiencyNorm = data.efficiencyNorm.ifEmpty { listOf(IntVersion(85, "2000-01-01")) },
            roundTimes = data.roundTimes.ifEmpty { listOf(RoundTimesVersion("10:00", "13:00", "16:00", "2000-01-01")) },
            monitoringWeights = data.monitoringWeights.ifEmpty { listOf(MonitoringWeightsVersion(BrigadirWeights(), QualityWeights(), "2000-01-01")) }
        )
    }

    private fun encodeIntVersions(values: List<IntVersion>) = JSONArray().apply {
        values.forEach { put(JSONObject().apply { put("value", it.value); put("effectiveFrom", it.effectiveFrom) }) }
    }

    private fun decodeIntVersions(array: JSONArray?): List<IntVersion> = array.objects().map {
        IntVersion(it.getInt("value"), it.getString("effectiveFrom"))
    }

    companion object {
        private const val PREFS_NAME = "toy_bola_assembly_data"
        private const val KEY_DATA = "assembly_data_v2"
    }
}

private fun JSONArray?.objects(): List<JSONObject> {
    if (this == null) return emptyList()
    return buildList { for (i in 0 until length()) add(getJSONObject(i)) }
}

private fun JSONArray?.strings(): List<String> {
    if (this == null) return emptyList()
    return buildList { for (i in 0 until length()) add(getString(i)) }
}

private fun JSONArray?.ints(): List<Int> {
    if (this == null) return emptyList()
    return buildList { for (i in 0 until length()) add(getInt(i)) }
}
