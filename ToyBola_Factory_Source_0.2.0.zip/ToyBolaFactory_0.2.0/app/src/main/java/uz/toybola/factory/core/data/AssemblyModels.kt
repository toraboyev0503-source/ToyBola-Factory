package uz.toybola.factory.core.data

import java.time.LocalDate

private fun todayIso(): String = LocalDate.now().toString()

data class Brigade(
    val id: String,
    val name: String,
    val archived: Boolean = false
)

data class Worker(
    val id: String,
    val brigadeId: String,
    val name: String,
    val startDate: String,
    val archived: Boolean = false
)

data class PriceVersion(
    val price: Long,
    val effectiveFrom: String
)

data class Product(
    val id: String,
    val brigadeId: String,
    val article: String,
    val name: String,
    val priceHistory: List<PriceVersion>,
    val stages: List<String>,
    val archived: Boolean = false
) {
    val currentPrice: Long
        get() = priceHistory
            .filter { it.effectiveFrom <= todayIso() }
            .maxByOrNull { it.effectiveFrom }
            ?.price
            ?: priceHistory.minByOrNull { it.effectiveFrom }?.price
            ?: 0L
}

data class LongVersion(val value: Long, val effectiveFrom: String)
data class IntVersion(val value: Int, val effectiveFrom: String)

data class BrigadeFkHistory(
    val brigadeId: String,
    val versions: List<LongVersion>
) {
    val current: Long?
        get() = versions
            .filter { it.effectiveFrom <= todayIso() }
            .maxByOrNull { it.effectiveFrom }
            ?.value
            ?: versions.minByOrNull { it.effectiveFrom }?.value
}

data class RoundTimesVersion(
    val first: String,
    val second: String,
    val third: String,
    val effectiveFrom: String
)

data class BrigadirWeights(
    val onTimeClose: Int = 40,
    val noReopen: Int = 20,
    val brigadeResult: Int = 40
) {
    val total: Int get() = onTimeClose + noReopen + brigadeResult
}

data class QualityWeights(
    val roundsOnTime: Int = 50,
    val rechecks: Int = 20,
    val onTimeClose: Int = 20,
    val dataDiscipline: Int = 10
) {
    val total: Int get() = roundsOnTime + rechecks + onTimeClose + dataDiscipline
}

data class MonitoringWeightsVersion(
    val brigadir: BrigadirWeights,
    val quality: QualityWeights,
    val effectiveFrom: String
)

data class AssemblyData(
    val brigades: List<Brigade> = emptyList(),
    val workers: List<Worker> = emptyList(),
    val products: List<Product> = emptyList(),
    val brigadeFk: List<BrigadeFkHistory> = emptyList(),
    val workHours: List<IntVersion> = emptyList(),
    val efficiencyNorm: List<IntVersion> = emptyList(),
    val roundTimes: List<RoundTimesVersion> = emptyList(),
    val monitoringWeights: List<MonitoringWeightsVersion> = emptyList(),
    val preparedYears: List<Int> = emptyList()
) {
    fun currentWorkHours(): Int = workHours.current()?.value ?: 10
    fun currentEfficiencyNorm(): Int = efficiencyNorm.current()?.value ?: 85
    fun currentRoundTimes(): RoundTimesVersion = roundTimes.currentBy { it.effectiveFrom }
        ?: RoundTimesVersion("10:00", "13:00", "16:00", "2000-01-01")
    fun currentMonitoringWeights(): MonitoringWeightsVersion = monitoringWeights.currentBy { it.effectiveFrom }
        ?: MonitoringWeightsVersion(BrigadirWeights(), QualityWeights(), "2000-01-01")
}

private fun List<IntVersion>.current(): IntVersion? = currentBy { it.effectiveFrom }

private fun <T> List<T>.currentBy(date: (T) -> String): T? {
    val today = todayIso()
    return filter { date(it) <= today }.maxByOrNull(date) ?: minByOrNull(date)
}
