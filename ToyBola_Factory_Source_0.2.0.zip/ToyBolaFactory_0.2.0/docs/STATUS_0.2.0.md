# 0.2.0 holati

- Safe-area: statusBarsPadding / navigationBarsPadding / safeDrawingPadding.
- Auth: device code + user code + Android system device credential. App telefon PINini ko‘rmaydi va saqlamaydi.
- Auto-lock: global sozlamadan 1/3/5/10/30 daqiqa.
- Sborka → Ma’lumot local persistence: SharedPreferences JSON repository, keyingi server-sync qatlamiga almashtiriladigan repository chegarasi bilan.
- Brigade-specific workers/products/F-K.
- Product detail + price history + assembly stages.
- Versioned norms: work hours, efficiency threshold, quality round times, monitoring weights.
- Archive/restore.
- Next-year norm version preparation.
- Unit tests: default monitoring weights, latest product price resolution.

## Debug signing
0.2.0 dan boshlab GitHub Actions debug APK uchun loyiha ichidagi faqat testga mo‘ljallangan barqaror debug kalit ishlatiladi. Bu 0.2.0 va keyingi debug buildlarni bir-birining ustidan update qilishga yordam beradi. Ushbu kalit final/production release uchun ishlatilmaydi.
