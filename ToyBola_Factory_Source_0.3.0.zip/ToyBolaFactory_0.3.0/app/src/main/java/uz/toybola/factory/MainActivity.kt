package uz.toybola.factory

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import uz.toybola.factory.core.data.AssemblyDataRepository
import uz.toybola.factory.core.preferences.AppPreferences

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val preferences = AppPreferences(applicationContext)
        val assemblyDataRepository = AssemblyDataRepository(applicationContext)
        setContent {
            ToyBolaApp(
                preferences = preferences,
                assemblyDataRepository = assemblyDataRepository
            )
        }
    }
}
