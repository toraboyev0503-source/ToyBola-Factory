package uz.toybola.factory.ui.model

class AppStrings(private val language: AppLanguage) {
    private fun value(uz: String, ru: String, en: String): String = when (language) {
        AppLanguage.UZ -> uz
        AppLanguage.RU -> ru
        AppLanguage.EN -> en
    }

    val appName = "TOY BOLA"
    val systemName = value("Zavod boshqaruv tizimi", "Система управления заводом", "Factory management system")
    val loading = value("Yuklanmoqda...", "Загрузка...", "Loading...")
    val firstSetup = value("Qurilmani sozlash", "Настройка устройства", "Device setup")
    val deviceCode = value("Qurilma kodi", "Код устройства", "Device code")
    val userCode = value("Foydalanuvchi kodi", "Код пользователя", "User code")
    val save = value("Saqlash", "Сохранить", "Save")
    val cancel = value("Bekor qilish", "Отмена", "Cancel")
    val close = value("Yopish", "Закрыть", "Close")
    val edit = value("Tahrirlash", "Изменить", "Edit")
    val change = value("O‘zgartirish", "Изменить", "Change")
    val login = value("Kirish", "Войти", "Sign in")
    val wrongCodes = value("Qurilma yoki foydalanuvchi kodi noto‘g‘ri", "Неверный код устройства или пользователя", "Invalid device or user code")
    val setupHint = value(
        "Qurilma va foydalanuvchi kodini kiriting. So‘ng telefon qulfi bilan tasdiqlang.",
        "Введите код устройства и пользователя, затем подтвердите блокировкой телефона.",
        "Enter the device and user codes, then confirm with the phone lock."
    )
    val loginHint = value(
        "Kodlarni tekshiring va telefon qulfi bilan tasdiqlang.",
        "Проверьте коды и подтвердите блокировкой телефона.",
        "Verify the codes and confirm with the phone lock."
    )
    val required = value("Barcha zarur maydonlarni to‘ldiring", "Заполните обязательные поля", "Complete all required fields")
    val confirmWithPhoneLock = value("Telefon qulfi bilan tasdiqlash", "Подтвердить блокировкой телефона", "Confirm with phone lock")
    val confirmPhoneLock = value("Toy Bola — tasdiqlash", "Toy Bola — подтверждение", "Toy Bola — confirmation")
    val confirmPhoneLockDesc = value("Telefon PIN/parol/patterni bilan tasdiqlang", "Подтвердите PIN/паролем/графическим ключом телефона", "Confirm using the phone PIN/password/pattern")
    val phoneLockFailed = value("Telefon qulfi tasdiqlanmadi", "Блокировка телефона не подтверждена", "Phone lock was not confirmed")
    val phoneLockNotSet = value("Telefonda ekran qulfi o‘rnatilmagan. Avval PIN/parol/pattern o‘rnating.", "На телефоне не настроена блокировка экрана. Сначала задайте PIN/пароль/ключ.", "No secure screen lock is configured. Set a PIN/password/pattern first.")
    val phoneLockUnavailable = value("Telefon qulfi oynasini ochib bo‘lmadi", "Не удалось открыть проверку блокировки", "Could not open phone lock verification")

    val menu = value("Sozlamalar", "Настройки", "Settings")
    val theme = value("Tema", "Тема", "Theme")
    val languageTitle = value("Til", "Язык", "Language")
    val darkMode = value("Tun rejimi", "Тёмный режим", "Dark mode")
    val autoLock = value("Avtomatik bloklash", "Автоблокировка", "Auto lock")
    val minutes = value("daqiqa", "мин", "min")
    val logout = value("Qulflash", "Заблокировать", "Lock")
    val notLaunched = value("Bu bo‘lim hali ishga tushirilmagan", "Раздел ещё не запущен", "This section is not active yet")
    val back = value("Orqaga", "Назад", "Back")

    val molding = value("Seryo va quyish", "Сырьё и литьё", "Raw material & molding")
    val moldingDesc = value("Stanokdan mahsulot detallari quyish", "Литьё деталей изделия на станках", "Molding product parts on machines")
    val ytmWarehouse = value("YTM sklad", "Склад YTM", "YTM warehouse")
    val ytmWarehouseDesc = value("Quyilgan detallar ombori", "Склад отлитых деталей", "Warehouse for molded parts")
    val sparePartsWarehouse = value("Zapchast sklad", "Склад запчастей", "Spare parts warehouse")
    val sparePartsWarehouseDesc = value("Yig‘ish uchun boshqa detallar ombori", "Склад дополнительных деталей для сборки", "Warehouse for additional assembly parts")
    val assemblyAndHome = value("Sborka va Xonadon", "Сборка и надомники", "Assembly and home work")
    val assemblyAndHomeDesc = value("Sex va xonadon yig‘ish jarayonlari", "Сборка в цехе и у надомников", "Workshop and home assembly processes")
    val finishedGoods = value("TM va EXP sklad", "Склад TM и EXP", "TM & EXP warehouse")
    val finishedGoodsDesc = value("Tayyor mahsulot va yuklash", "Готовая продукция и отгрузка", "Finished goods and shipping")
    val managementControl = value("Rahbariyat nazorati", "Контроль руководства", "Management control")
    val managementControlDesc = value("Zavod bo‘limlari bo‘yicha nazorat", "Контроль по подразделениям завода", "Factory-wide department monitoring")
    val globalMasterData = value("Ma’lumotlar", "Данные", "Master data")
    val globalMasterDataDesc = value("Zavod bo‘yicha asosiy ma’lumotlar", "Основные данные по заводу", "Factory-wide master data")

    val assembly = value("Sborka", "Сборка", "Assembly")
    val homeWork = value("Xonadon", "Надомники", "Home work")
    val homeWorkDesc = value("Xonadonlarda yig‘iladigan mahsulotlar", "Продукция, собираемая надомниками", "Products assembled by home workers")
    val assemblyDesc = value("Sexdagi sborka jarayonini boshqarish", "Управление сборкой в цехе", "Manage workshop assembly")
    val brigadir = value("Brigadir", "Бригадир", "Brigadier")
    val brigadirDesc = value("Ishchilar va kunlik ishlab chiqarish", "Работники и дневное производство", "Workers and daily production")
    val quality = value("Sifat", "Качество", "Quality")
    val qualityDesc = value("3 raundli sifat nazorati", "Контроль качества в 3 раунда", "Three-round quality control")
    val dailyIssue = value("Kun muammosi", "Проблемы дня", "Daily issues")
    val dailyIssueDesc = value("Mahsulot va yig‘uv bosqichi muammolari", "Проблемы изделий и этапов сборки", "Product and assembly-stage issues")
    val monitoring = value("Monitoring", "Мониторинг", "Monitoring")
    val monitoringDesc = value("Natijalar va nazorat", "Результаты и контроль", "Results and oversight")
    val masterData = value("Ma’lumot", "Данные", "Data")
    val masterDataDesc = value("Sborkaga tegishli ma’lumotlar", "Данные, относящиеся к сборке", "Assembly-specific master data")

    val brandTheme = value("Toy Bola", "Toy Bola", "Toy Bola")
    val calmTheme = value("Sokin", "Спокойная", "Calm")
    val neutralTheme = value("Neytral", "Нейтральная", "Neutral")

    val skeletonReady = value(
        "Bu bo‘lim keyingi versiyada to‘liq ulanadi.",
        "Этот раздел будет полностью подключён в следующей версии.",
        "This section will be fully connected in a later version."
    )

    // Sborka -> Ma'lumot
    val masterDataIntro = value("Sborkaga tegishli asosiy ma’lumotlarni shu yerdan boshqaring.", "Управляйте основными данными сборки здесь.", "Manage assembly master data here.")
    val brigades = value("Brigadalar", "Бригады", "Brigades")
    val workers = value("Ishchilar", "Работники", "Workers")
    val products = value("Mahsulotlar", "Продукты", "Products")
    val fk = "F/K"
    val workHours = value("Ish vaqti", "Рабочее время", "Work hours")
    val roundTimes = value("Sifat raund vaqtlari", "Время раундов качества", "Quality round times")
    val efficiencyNorm = value("Samaradorlik normativi", "Норматив эффективности", "Efficiency threshold")
    val monitoringCriteria = value("Monitoring mezonlari", "Критерии мониторинга", "Monitoring criteria")
    val assemblyStages = value("Yig‘uv bosqichlari", "Этапы сборки", "Assembly stages")
    val archive = value("Arxiv", "Архив", "Archive")
    val yearCopy = value("Yangi yil ma’lumotlari", "Данные нового года", "New-year data")
    val addBrigade = value("Brigada qo‘shish", "Добавить бригаду", "Add brigade")
    val editBrigade = value("Brigadani tahrirlash", "Изменить бригаду", "Edit brigade")
    val brigadeName = value("Brigada nomi", "Название бригады", "Brigade name")
    val brigade = value("Brigada", "Бригада", "Brigade")
    val noBrigades = value("Hali brigada kiritilmagan", "Бригады ещё не добавлены", "No brigades yet")
    val addWorker = value("Ishchi qo‘shish", "Добавить работника", "Add worker")
    val editWorker = value("Ishchini tahrirlash", "Изменить работника", "Edit worker")
    val workerName = value("Ishchi ismi", "Имя работника", "Worker name")
    val startDate = value("Ish boshlagan sana", "Дата начала работы", "Start date")
    val started = value("Boshlagan", "Начало", "Started")
    val noWorkers = value("Hali ishchi kiritilmagan", "Работники ещё не добавлены", "No workers yet")
    val createBrigadeFirst = value("Avval brigada yarating", "Сначала создайте бригаду", "Create a brigade first")
    val selectBrigade = value("Brigadani tanlang", "Выберите бригаду", "Select brigade")
    val addProduct = value("Mahsulot qo‘shish", "Добавить продукт", "Add product")
    val editProduct = value("Mahsulotni tahrirlash", "Изменить продукт", "Edit product")
    val article = value("Artikul", "Артикул", "Article")
    val productName = value("Mahsulot nomi", "Название продукта", "Product name")
    val price = value("Narxi", "Цена", "Price")
    val priceHistory = value("Narx tarixi", "История цен", "Price history")
    val noProducts = value("Hali mahsulot kiritilmagan", "Продукты ещё не добавлены", "No products yet")
    val oneStagePerLine = value("Har bir yig‘uv bosqichini yangi qatordan yozing.", "Каждый этап сборки вводите с новой строки.", "Enter each assembly stage on a new line.")
    val noStages = value("Yig‘uv bosqichi kiritilmagan", "Этапы сборки не указаны", "No assembly stages")
    val stagesHelp = value("Yig‘uv bosqichlari mahsulot ichida saqlanadi. O‘zgartirish uchun Mahsulotlar bo‘limidan mahsulotni oching.", "Этапы сборки хранятся внутри продукта. Для изменения откройте продукт в разделе Продукты.", "Assembly stages are stored inside each product. Edit them from Products.")
    val fkHelp = value("Har bir brigada uchun F/K alohida belgilanadi. Yangi qiymat eski hisoblarni o‘zgartirmaydi.", "F/K задаётся отдельно для каждой бригады. Новое значение не меняет старые расчёты.", "F/K is set per brigade. New values do not change historical calculations.")
    val amount = value("Summa", "Сумма", "Amount")
    val som = value("so‘m", "сум", "UZS")
    val hours = value("soat", "час", "hours")
    val percent = value("Foiz", "Процент", "Percent")
    val notEntered = value("Kiritilmagan", "Не введено", "Not entered")
    val toArchive = value("Arxivga", "В архив", "Archive")
    val archiveEmpty = value("Arxiv bo‘sh", "Архив пуст", "Archive is empty")
    val restore = value("Qaytarish", "Восстановить", "Restore")
    val currentValue = value("Amaldagi qiymat", "Текущее значение", "Current value")
    val history = value("Tarix", "История", "History")
    val roundTimeHelp = value("Default vaqtlar: 10:00 / 13:00 / 16:00. Keyin o‘zgartirilsa eski davr o‘z qiymatida qoladi.", "Время по умолчанию: 10:00 / 13:00 / 16:00. Старые периоды сохраняют прежние значения.", "Default times: 10:00 / 13:00 / 16:00. Historical periods retain their values.")
    val round1 = value("1-raund", "1-й раунд", "Round 1")
    val round2 = value("2-raund", "2-й раунд", "Round 2")
    val round3 = value("3-raund", "3-й раунд", "Round 3")
    val effectiveDate = value("Amal qilish sanasi", "Дата вступления в силу", "Effective date")
    val monitoringCriteriaHelp = value("Standart qiymatlar avtomatik kiritilgan. Jami har bir rol uchun 100% bo‘lishi shart.", "Стандартные значения уже заполнены. Сумма для каждой роли должна быть 100%.", "Default values are prefilled. Each role must total 100%.")
    val onTimeClose = value("Vaqtida yopish", "Закрытие вовремя", "On-time close")
    val noReopen = value("Qayta ochilmaslik", "Без повторного открытия", "No reopen")
    val brigadeResult = value("Brigada natijasi", "Результат бригады", "Brigade result")
    val roundsOnTime = value("Raundlarni vaqtida bajarish", "Раунды вовремя", "Rounds on time")
    val rechecks = value("Qayta tekshiruvlar", "Повторные проверки", "Rechecks")
    val dataDiscipline = value("Ma’lumot intizomi", "Дисциплина данных", "Data discipline")
    val dateFormatHint = "YYYY-MM-DD"
    val invalidDate = value("Sana formati noto‘g‘ri", "Неверный формат даты", "Invalid date format")
    val invalidPrice = value("Narxni to‘g‘ri kiriting", "Введите корректную цену", "Enter a valid price")
    val errorGeneric = value("Xatolik yuz berdi", "Произошла ошибка", "An error occurred")
    val yearCopyHelp = value("Keyingi yil uchun amaldagi normativlar 1-yanvardan yangi tarixiy versiya sifatida tayyorlanadi.", "Текущие нормативы будут подготовлены на 1 января следующего года как новая историческая версия.", "Current norms will be prepared for January 1 of the next year as new historical versions.")
    val yearCopyMastersCarry = value("Brigada, ishchi va mahsulotlar faol bo‘lsa avtomatik davom etadi; ularni keraksiz nusxalab ko‘paytirmaymiz.", "Активные бригады, работники и продукты продолжаются автоматически без лишних копий.", "Active brigades, workers and products carry forward automatically without duplicate records.")
    val prepareNextYear = value("Keyingi yilni tayyorlash", "Подготовить следующий год", "Prepare next year")
    val prepared = value("Tayyorlangan", "Подготовлено", "Prepared")


    val newValue = value("Yangi qiymat", "Новое значение", "New value")
    val noHistory = value("Tarix hali yo‘q", "История пока пуста", "No history yet")
    val initialValue = value("Boshlang‘ich qiymat", "Начальное значение", "Initial value")
    val manageStages = value("Yig‘uv bosqichlarini boshqarish", "Управлять этапами сборки", "Manage assembly stages")
    val addStage = value("Bosqich qo‘shish", "Добавить этап", "Add stage")
    val editStage = value("Bosqichni tahrirlash", "Изменить этап", "Edit stage")
    val stageName = value("Bosqich nomi", "Название этапа", "Stage name")
    val newPrice = value("Yangi narx", "Новая цена", "New price")
    val stagesEditHint = value("Yig‘uv bosqichlari mahsulot saqlangandan keyin alohida oynadan boshqariladi.", "Этапы сборки управляются в отдельном окне после сохранения товара.", "Assembly stages are managed in a separate screen after saving the product.")

    // Brigadir
    val today = value("Bugun", "Сегодня", "Today")
    val worked = value("Ishladi", "Работал", "Worked")
    val didNotWork = value("Ishlamadi", "Не работал", "Did not work")
    val unfinished = value("Tugallanmagan", "Не завершено", "Incomplete")
    val completed = value("Tugallangan", "Завершено", "Completed")
    val noWorkersForBrigade = value("Bu brigadada faol ishchi yo‘q", "В этой бригаде нет активных работников", "No active workers in this brigade")
    val chooseBrigade = value("Brigadani tanlang", "Выберите бригаду", "Choose brigade")
    val workerDay = value("Ishchi kuni", "День работника", "Worker day")
    val addProduction = value("Mahsulot yozish", "Добавить производство", "Add production")
    val quantity = value("Soni", "Количество", "Quantity")
    val unitPrice = value("Narx", "Цена", "Unit price")
    val totalAmount = value("Topgan summa", "Заработанная сумма", "Earned amount")
    val requiredAmount = value("Kerakli summa", "Требуемая сумма", "Required amount")
    val efficiency = value("Samaradorlik", "Эффективность", "Efficiency")
    val selectProduct = value("Mahsulotni tanlang", "Выберите товар", "Select product")
    val noProductsForBrigade = value("Bu brigada uchun faol mahsulot yo‘q", "Для этой бригады нет активных товаров", "No active products for this brigade")
    val duplicateProduct = value("Bu mahsulot bugun avval kiritilgan. Sonini birlashtirasizmi?", "Этот товар уже был введён сегодня. Объединить количество?", "This product was already entered today. Merge the quantity?")
    val merge = value("Birlashtirish", "Объединить", "Merge")
    val delete = value("O‘chirish", "Удалить", "Delete")
    val editQuantity = value("Sonini tahrirlash", "Изменить количество", "Edit quantity")
    val fkMissing = value("Bu brigada uchun F/K kiritilmagan", "Для этой бригады не задан F/K", "F/K is not set for this brigade")
    val markNotWorked = value("Ishlamadi qilish", "Отметить как не работал", "Mark as did not work")
    val markWorked = value("Ishladi qilish", "Отметить как работал", "Mark as worked")
    val brigadeWorked = value("Brigada ishladi", "Бригада работала", "Brigade worked")
    val brigadeDidNotWork = value("Brigada ishlamadi", "Бригада не работала", "Brigade did not work")
    val changeHours = value("Soatni o‘zgartirish", "Изменить часы", "Change hours")

    fun brigadeRowSubtitle(workerCount: Int, productCount: Int): String = value(
        "$workerCount ishchi • $productCount mahsulot",
        "$workerCount работников • $productCount продуктов",
        "$workerCount workers • $productCount products"
    )

    fun yearPrepared(year: Int): String = value(
        "$year yil uchun normativlar tayyorlandi.",
        "Нормативы на $year год подготовлены.",
        "Norms for $year are prepared."
    )
}
