package uz.toybola.factory.core.data

import org.junit.Assert.assertEquals
import org.junit.Test

class AssemblyModelsTest {
    @Test
    fun defaultMonitoringWeights_totalOneHundred() {
        assertEquals(100, BrigadirWeights().total)
        assertEquals(100, QualityWeights().total)
    }

    @Test
    fun productCurrentPrice_usesLatestEffectiveDate() {
        val product = Product(
            id = "1",
            brigadeId = "b1",
            article = "TB-001",
            name = "Test",
            priceHistory = listOf(
                PriceVersion(1000, "2026-01-01"),
                PriceVersion(1200, "2026-08-01")
            ),
            stages = emptyList()
        )
        assertEquals(1200L, product.currentPrice)
    }
}
