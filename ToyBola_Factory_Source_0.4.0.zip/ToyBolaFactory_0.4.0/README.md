# Toy Bola Factory Management System — Android 0.4.0

Android/Kotlin + Jetpack Compose asosidagi zavod boshqaruv tizimi.

Hozir faol ishlab chiqilayotgan modul: **Sborka**.

0.4.0 da:
- Sborka → Ma’lumot lokal master-data boshqaruvi;
- Brigadir kunlik ishlab chiqarish va F/K samaradorligi;
- mahsulotni master data ro‘yxatidan tanlash;
- Sifat nazorati: 3 raund, ±1 soat, 1–4 baho, mahsulot/bosqich, majburiy izoh va qayta tekshiruv.

GitHub Actions `test`, `lint`, `assembleDebug` bajarib APK artifact yaratadi.
