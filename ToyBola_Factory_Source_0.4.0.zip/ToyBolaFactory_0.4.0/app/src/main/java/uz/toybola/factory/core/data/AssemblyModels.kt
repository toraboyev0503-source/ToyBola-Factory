package uz.toybola.factory.core.data

import java.time.LocalDate

private fun todayIso(): String = LocalDate.now().toString()

data class Brigade(
    val id: String,
    val name: String,
    val archived: Boolean = false
)

data class Worker(
    val id: String,
    val brigadeId: String,
    val name: String,
    val startDate: String,
    val archived: Boolean = false
)

data class PriceVersion(
    val price: Long,
    val effectiveFrom: String
)

data class ProductStage(
    val id: String,
    val name: String,
    val archived: Boolean = false
)

data class Product(
    val id: String,
    val brigadeId: String,
    val article: String,
    val name: String,
    val priceHistory: List<PriceVersion>,
    val stages: List<ProductStage> = emptyList(),
    val archived: Boolean = false
) {
    val currentPrice: Long get() = priceAt(todayIso())

    fun priceAt(date: String): Long = priceHistory
        .filter { it.effectiveFrom <= date }
        .maxByOrNull { it.effectiveFrom }
        ?.price
        ?: priceHistory.minByOrNull { it.effectiveFrom }?.price
        ?: 0L

    fun activeStages(): List<ProductStage> = stages.filterNot { it.archived }
}

data class LongVersion(val value: Long, val effectiveFrom: String)
data class IntVersion(val value: Int, val effectiveFrom: String)

data class BrigadeFkHistory(
    val brigadeId: String,
    val versions: List<LongVersion>
) {
    val current: Long? get() = valueAt(todayIso())

    fun valueAt(date: String): Long? = versions
        .filter { it.effectiveFrom <= date }
        .maxByOrNull { it.effectiveFrom }
        ?.value
        ?: versions.minByOrNull { it.effectiveFrom }?.value
}

data class RoundTimesVersion(
    val first: String,
    val second: String,
    val third: String,
    val effectiveFrom: String
)

data class BrigadirWeights(
    val onTimeClose: Int = 40,
    val noReopen: Int = 20,
    val brigadeResult: Int = 40
) {
    val total: Int get() = onTimeClose + noReopen + brigadeResult
}

data class QualityWeights(
    val roundsOnTime: Int = 50,
    val rechecks: Int = 20,
    val onTimeClose: Int = 20,
    val dataDiscipline: Int = 10
) {
    val total: Int get() = roundsOnTime + rechecks + onTimeClose + dataDiscipline
}

data class MonitoringWeightsVersion(
    val brigadir: BrigadirWeights,
    val quality: QualityWeights,
    val effectiveFrom: String
)

data class ProductionEntry(
    val id: String,
    val productId: String,
    val articleSnapshot: String,
    val productNameSnapshot: String,
    val quantity: Int,
    val unitPriceSnapshot: Long
) {
    val amount: Long get() = quantity.toLong() * unitPriceSnapshot
}

data class WorkerDay(
    val workerId: String,
    val brigadeId: String,
    val date: String,
    val worked: Boolean = true,
    val hours: Int,
    val entries: List<ProductionEntry> = emptyList(),
    val updatedAt: String = ""
) {
    val earned: Long get() = entries.sumOf { it.amount }
    val isComplete: Boolean get() = !worked || entries.isNotEmpty()
}

data class BrigadeDay(
    val brigadeId: String,
    val date: String,
    val worked: Boolean = true
)

data class QualityRecheck(
    val grade: Int,
    val note: String = "",
    val checkedAt: String
)

data class QualityRoundRecord(
    val id: String,
    val workerId: String,
    val brigadeId: String,
    val date: String,
    val round: Int,
    val scheduledTime: String,
    val grade: Int? = null,
    val score: Int? = null,
    val productId: String? = null,
    val articleSnapshot: String = "",
    val productNameSnapshot: String = "",
    val stageId: String? = null,
    val stageNameSnapshot: String = "",
    val note: String = "",
    val evaluatedAt: String? = null,
    val missedReason: String = "",
    val missedAt: String? = null,
    val recheck: QualityRecheck? = null
) {
    val isEvaluated: Boolean get() = grade != null
    val isMissed: Boolean get() = grade == null && missedAt != null
    val needsRecheck: Boolean get() = grade == 3 || grade == 4
    val isFinished: Boolean get() = isEvaluated || (isMissed && missedReason.isNotBlank())
}

data class AssemblyData(
    val brigades: List<Brigade> = emptyList(),
    val workers: List<Worker> = emptyList(),
    val products: List<Product> = emptyList(),
    val brigadeFk: List<BrigadeFkHistory> = emptyList(),
    val workHours: List<IntVersion> = emptyList(),
    val efficiencyNorm: List<IntVersion> = emptyList(),
    val roundTimes: List<RoundTimesVersion> = emptyList(),
    val monitoringWeights: List<MonitoringWeightsVersion> = emptyList(),
    val preparedYears: List<Int> = emptyList(),
    val workerDays: List<WorkerDay> = emptyList(),
    val brigadeDays: List<BrigadeDay> = emptyList(),
    val qualityRounds: List<QualityRoundRecord> = emptyList()
) {
    fun currentWorkHours(): Int = workHours.current()?.value ?: 10
    fun workHoursAt(date: String): Int = workHours.valueAt(date) ?: 10
    fun currentEfficiencyNorm(): Int = efficiencyNorm.current()?.value ?: 85
    fun currentRoundTimes(): RoundTimesVersion = roundTimes.currentBy { it.effectiveFrom }
        ?: RoundTimesVersion("10:00", "13:00", "16:00", "2000-01-01")
    fun roundTimesAt(date: String): RoundTimesVersion = roundTimes
        .filter { it.effectiveFrom <= date }
        .maxByOrNull { it.effectiveFrom }
        ?: roundTimes.minByOrNull { it.effectiveFrom }
        ?: RoundTimesVersion("10:00", "13:00", "16:00", "2000-01-01")
    fun currentMonitoringWeights(): MonitoringWeightsVersion = monitoringWeights.currentBy { it.effectiveFrom }
        ?: MonitoringWeightsVersion(BrigadirWeights(), QualityWeights(), "2000-01-01")
    fun brigadeFkAt(brigadeId: String, date: String): Long? = brigadeFk.firstOrNull { it.brigadeId == brigadeId }?.valueAt(date)
    fun workerDay(workerId: String, date: String): WorkerDay? = workerDays.firstOrNull { it.workerId == workerId && it.date == date }
    fun brigadeDay(brigadeId: String, date: String): BrigadeDay? = brigadeDays.firstOrNull { it.brigadeId == brigadeId && it.date == date }
    fun qualityRound(workerId: String, date: String, round: Int): QualityRoundRecord? = qualityRounds.firstOrNull {
        it.workerId == workerId && it.date == date && it.round == round
    }
    fun qualityAverage(workerId: String, date: String): Double? {
        val scores = qualityRounds.filter { it.workerId == workerId && it.date == date }.mapNotNull { it.score }
        return if (scores.isEmpty()) null else scores.average()
    }
}

private fun List<IntVersion>.current(): IntVersion? = currentBy { it.effectiveFrom }
private fun List<IntVersion>.valueAt(date: String): Int? = filter { it.effectiveFrom <= date }.maxByOrNull { it.effectiveFrom }?.value
    ?: minByOrNull { it.effectiveFrom }?.value

private fun <T> List<T>.currentBy(date: (T) -> String): T? {
    val today = todayIso()
    return filter { date(it) <= today }.maxByOrNull(date) ?: minByOrNull(date)
}
