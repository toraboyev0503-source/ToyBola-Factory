# Toy Bola Factory 0.4.0

## Bajarildi
- Brigadir ishchi kunida mahsulot endi qo‘lda yozilmaydi: shu brigadaga tegishli faol mahsulotlar ro‘yxatidan tanlanadi.
- Mahsulot tanlash oynasida artikul yoki nom bo‘yicha qidiruv bor; artikul, nom va amaldagi narx avtomatik olinadi.
- Avvalgi duplicate mahsulotni birlashtirish qoidasi saqlandi.
- Sifat bo‘limi real lokal ish oqimiga ulandi.
- Har brigada uchun faol ishchilar va 3 raund ko‘rinadi.
- Raundlar Ma’lumotlardagi tarixiy vaqtlardan foydalanadi va ±1 soat oynasida baholanadi.
- Baholar: 1=100%, 2=75%, 3=50%, 4=0%.
- Mahsulot va yig‘uv bosqichi master data’dan tanlanadi.
- 3/4 bahoda izoh majburiy.
- 3/4 bahoda qayta tekshiruv mavjud; qayta tekshiruv dastlabki bahoni almashtirmaydi.
- O‘tib ketgan raund sabab bilan “O‘tkazib yuborildi” holatida saqlanadi va ishchi sifat foiziga kiritilmaydi.
- Baholangan/yakunlangan ishchilar pastki guruhga tushadi.
- Oldingi 0.1–0.3 ma’lumotlarini o‘qish saqlangan; yangi sifat yozuvlari JSONga qo‘shimcha qatlam sifatida kiritildi.

## Keyingi bosqich
- Kun muammosi real kiritish oqimi.
- Sifat va Brigadir kunini yopish/deadline holatlari.
- Lokal/offline bildirishnomalarni to‘liq rejalashtirish.
- Monitoringga real hisoblarni ulash.
