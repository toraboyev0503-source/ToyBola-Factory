# Toy Bola Factory Management System

Android/Kotlin/Jetpack Compose zavod boshqaruv tizimi.

## 0.5.0
- Sborka → Ma’lumot real lokal master data
- Brigadir kunlik ishlab chiqarish va samaradorlik
- Sifat 3 raund, qayta tekshiruv va o‘tkazib yuborilgan raundlar
- Kun muammosi: mahsulot + yig‘uv bosqichi + izoh
- Kun/Oy/Yil bo‘yicha DOCX eksport
- Device-safe UI, telefon qulfi orqali autentifikatsiya

GitHub Actions `test`, `lint`, `assembleDebug` bajaradi va APK artifact beradi.
