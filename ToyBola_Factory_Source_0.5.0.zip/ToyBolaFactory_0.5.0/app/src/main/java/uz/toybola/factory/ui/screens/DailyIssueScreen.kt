package uz.toybola.factory.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import uz.toybola.factory.core.data.*
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.model.AppStrings
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter

private enum class IssueExportScope { DAY, MONTH, YEAR }

@Composable
fun DailyIssueScreen(
    strings: AppStrings,
    repository: AssemblyDataRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var revision by remember { mutableIntStateOf(0) }
    val data = remember(revision) { repository.load() }
    val today = remember { LocalDate.now() }
    val date = today.toString()
    val brigades = data.brigades.filterNot { it.archived }.sortedBy { it.name.lowercase() }
    var brigadeId by remember(brigades) { mutableStateOf(brigades.firstOrNull()?.id.orEmpty()) }
    var editorIssueId by remember { mutableStateOf<String?>(null) }
    var showNewEditor by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var pendingExport by remember { mutableStateOf<IssueExportScope?>(null) }

    fun refresh() { revision++ }

    val createDocument = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    ) { uri ->
        val scope = pendingExport
        pendingExport = null
        if (uri == null || scope == null) return@rememberLauncherForActivityResult
        runCatching {
            val fresh = repository.load()
            val selectedIssues = when (scope) {
                IssueExportScope.DAY -> fresh.dailyIssues.filter { it.date == date }
                IssueExportScope.MONTH -> {
                    val month = YearMonth.from(today)
                    fresh.dailyIssues.filter { runCatching { YearMonth.from(LocalDate.parse(it.date)) == month }.getOrDefault(false) }
                }
                IssueExportScope.YEAR -> fresh.dailyIssues.filter { it.date.startsWith("${today.year}-") }
            }
            context.contentResolver.openOutputStream(uri)?.use { output ->
                val title = when (scope) {
                    IssueExportScope.DAY -> "$date — ${strings.dailyIssue}"
                    IssueExportScope.MONTH -> "${today.year}-${today.monthValue.toString().padStart(2, '0')} — ${strings.dailyIssue}"
                    IssueExportScope.YEAR -> "${today.year} — ${strings.dailyIssue}"
                }
                DailyIssueDocxExporter.write(output, title, selectedIssues, fresh.brigades.associate { it.id to it.name })
            } ?: error(strings.exportFailed)
        }.onSuccess {
            Toast.makeText(context, strings.exportSuccess, Toast.LENGTH_SHORT).show()
        }.onFailure {
            Toast.makeText(context, it.message ?: strings.exportFailed, Toast.LENGTH_LONG).show()
        }
    }

    fun export(scope: IssueExportScope) {
        pendingExport = scope
        val suffix = when (scope) {
            IssueExportScope.DAY -> date
            IssueExportScope.MONTH -> "${today.year}-${today.monthValue.toString().padStart(2, '0')}"
            IssueExportScope.YEAR -> today.year.toString()
        }
        createDocument.launch("ToyBola_Kun_muammosi_$suffix.docx")
    }

    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize()) {
        AppTopBar(strings.dailyIssue, canGoBack = true, onMenu = {}, onBack = onBack)
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(16.dp)
        ) {
            if (brigades.isEmpty()) {
                Text(strings.createBrigadeFirst)
                return@Column
            }

            IssueBrigadeDropdown(strings, brigades, brigadeId) { brigadeId = it }
            Spacer(Modifier.height(8.dp))
            Text("${strings.today}: $date", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(14.dp))

            Button(
                onClick = { showNewEditor = true },
                modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                Text("+ ${strings.addIssue}", fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(14.dp))
            Text(strings.exportWord, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { export(IssueExportScope.DAY) }, modifier = Modifier.weight(1f)) { Text(strings.exportDay) }
                OutlinedButton(onClick = { export(IssueExportScope.MONTH) }, modifier = Modifier.weight(1f)) { Text(strings.exportMonth) }
                OutlinedButton(onClick = { export(IssueExportScope.YEAR) }, modifier = Modifier.weight(1f)) { Text(strings.exportYear) }
            }

            if (!message.isNullOrBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(message!!, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(18.dp))
            val issues = data.dailyIssues
                .filter { it.date == date && it.brigadeId == brigadeId }
                .sortedByDescending { it.createdAt }

            if (issues.isEmpty()) {
                Text(strings.noIssuesToday, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                issues.forEach { issue ->
                    IssueCard(
                        strings = strings,
                        issue = issue,
                        onEdit = { editorIssueId = issue.id },
                        onDelete = {
                            val result = repository.removeDailyIssue(issue.id)
                            message = result.exceptionOrNull()?.message
                            if (result.isSuccess) refresh()
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
    }

    if (showNewEditor) {
        DailyIssueEditorDialog(
            strings = strings,
            brigadeId = brigadeId,
            products = data.products.filter { !it.archived && it.brigadeId == brigadeId },
            initial = null,
            onDismiss = { showNewEditor = false },
            onSave = { productId, stageId, note ->
                val result = repository.addDailyIssue(brigadeId, date, productId, stageId, note)
                message = result.exceptionOrNull()?.message
                if (result.isSuccess) {
                    showNewEditor = false
                    refresh()
                }
                result.isSuccess
            }
        )
    }

    editorIssueId?.let { issueId ->
        val issue = data.dailyIssues.firstOrNull { it.id == issueId }
        if (issue != null) {
            DailyIssueEditorDialog(
                strings = strings,
                brigadeId = issue.brigadeId,
                products = data.products.filter { !it.archived && it.brigadeId == issue.brigadeId },
                initial = issue,
                onDismiss = { editorIssueId = null },
                onSave = { productId, stageId, note ->
                    val result = repository.updateDailyIssue(issue.id, productId, stageId, note)
                    message = result.exceptionOrNull()?.message
                    if (result.isSuccess) {
                        editorIssueId = null
                        refresh()
                    }
                    result.isSuccess
                }
            )
        }
    }
}

@Composable
private fun IssueBrigadeDropdown(
    strings: AppStrings,
    brigades: List<Brigade>,
    selectedId: String,
    onSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val selected = brigades.firstOrNull { it.id == selectedId }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(selected?.name ?: strings.chooseBrigade, modifier = Modifier.weight(1f))
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            brigades.forEach { brigade ->
                DropdownMenuItem(
                    text = { Text(brigade.name) },
                    onClick = { expanded = false; onSelected(brigade.id) }
                )
            }
        }
    }
}

@Composable
private fun IssueCard(
    strings: AppStrings,
    issue: DailyIssueRecord,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                "${issue.articleSnapshot} — ${issue.productNameSnapshot}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(issue.stageNameSnapshot, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(7.dp))
            Text(issue.note)
            Spacer(Modifier.height(7.dp))
            Text(
                issue.createdAt.take(16).replace('T', ' '),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onEdit) { Text(strings.edit) }
                TextButton(onClick = onDelete) { Text(strings.delete, color = MaterialTheme.colorScheme.error) }
            }
        }
    }
}

@Composable
private fun DailyIssueEditorDialog(
    strings: AppStrings,
    brigadeId: String,
    products: List<Product>,
    initial: DailyIssueRecord?,
    onDismiss: () -> Unit,
    onSave: (productId: String, stageId: String, note: String) -> Boolean
) {
    var productId by remember(initial) { mutableStateOf(initial?.productId.orEmpty()) }
    var stageId by remember(initial) { mutableStateOf(initial?.stageId.orEmpty()) }
    var note by remember(initial) { mutableStateOf(initial?.note.orEmpty()) }
    var productMenu by remember { mutableStateOf(false) }
    var stageMenu by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val product = products.firstOrNull { it.id == productId }
    val stages = product?.activeStages().orEmpty()
    val stage = stages.firstOrNull { it.id == stageId }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) strings.addIssue else strings.editIssue) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { productMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(product?.let { "${it.article} — ${it.name}" } ?: strings.selectProduct, modifier = Modifier.weight(1f))
                    }
                    DropdownMenu(expanded = productMenu, onDismissRequest = { productMenu = false }) {
                        products.sortedBy { it.article.lowercase() }.forEach { item ->
                            DropdownMenuItem(
                                text = { Text("${item.article} — ${item.name}") },
                                onClick = {
                                    productMenu = false
                                    productId = item.id
                                    if (item.activeStages().none { it.id == stageId }) stageId = ""
                                }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { if (product != null) stageMenu = true else error = strings.chooseProductFirst },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(stage?.name ?: strings.selectAssemblyStage, modifier = Modifier.weight(1f))
                    }
                    DropdownMenu(expanded = stageMenu, onDismissRequest = { stageMenu = false }) {
                        stages.forEach { item ->
                            DropdownMenuItem(text = { Text(item.name) }, onClick = { stageMenu = false; stageId = item.id })
                        }
                    }
                }
                if (product != null && stages.isEmpty()) {
                    Text(strings.productHasNoStages, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 6.dp))
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                    label = { Text(strings.issueText) },
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    minLines = 4
                )
                if (!error.isNullOrBlank()) {
                    Text(error!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 6.dp))
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                error = when {
                    brigadeId.isBlank() -> strings.chooseBrigade
                    productId.isBlank() -> strings.selectProduct
                    stageId.isBlank() -> strings.selectAssemblyStage
                    note.isBlank() -> strings.required
                    else -> null
                }
                if (error == null) onSave(productId, stageId, note)
            }) { Text(strings.save) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } }
    )
}
