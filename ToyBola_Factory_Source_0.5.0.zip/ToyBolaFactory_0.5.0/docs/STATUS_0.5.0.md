# Toy Bola Factory 0.5.0

## Bajarildi
- Oldingi 0.4.0 Brigadir va Sifat funksiyalari saqlandi.
- Kun muammosi real ishlaydigan bo‘ldi.
- Kun muammosida brigada tanlanadi, mahsulot shu brigadaning faol Ma’lumotlar bazasidan olinadi.
- Mahsulot tanlangach faqat uning faol yig‘uv bosqichlari tanlanadi.
- Muammo matni yozilib saqlanadi; har yozuvda sana, vaqt, mahsulot va yig‘uv bosqichi snapshoti saqlanadi.
- Yozuvlarni tahrirlash va o‘chirish mumkin.
- Bugungi yozuvlar yangi yozuv tugmasi ostida ro‘yxat bo‘lib ko‘rinadi.
- Kun/Oy/Yil bo‘yicha Word (.docx) eksport qo‘shildi; eksport Android fayl saqlash oynasi orqali amalga oshadi.
- Daily issue ma’lumotlari mavjud JSON lokal bazaga migration-safe yangi qatlam sifatida qo‘shildi; 0.4.0 va oldingi ma’lumotlar o‘qiladi.
- versionName 0.5.0, versionCode 500.

## Keyingi bosqich
- Monitoringni real ma’lumotlarga ulash: ishchilar, brigadir, sifat va muammoli mahsulotlar.
- Kun yopish holatlari va deadline izohlari.
- Lokal/offline bildirishnomalar.
