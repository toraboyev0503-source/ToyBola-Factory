# Toy Bola 0.6.0 holati

## Mobil Sborka funksiyalari

- [x] Brigadir kundalik ishlab chiqarish
- [x] Mahsulotni master data’dan tanlash
- [x] Tarixiy F/K, narx va normativlar
- [x] Sifat 3 raund va ±1 soat oynasi
- [x] 3/4 bahoda qayta tekshiruv
- [x] O‘tkazib yuborilgan raund sababini saqlash
- [x] Kun muammosi CRUD
- [x] Kun yopish / kech yopish / sabablar
- [x] Oldingi yopilmagan kun bugungi kiritishni bloklamaydi
- [x] Monitoring: ishchilar / Brigadir / Sifat / muammoli mahsulotlar
- [x] DOCX Kun/Oy/Yil muammolar eksporti Monitoring ichida
- [x] Audit log
- [x] Offline lokal vaqtli eslatmalar
- [x] Device credential bilan lock/auth

## Keyingi integratsiya qatlami

- [ ] Firebase/markaziy backend
- [ ] Ko‘p qurilmali sync va conflict resolution
- [ ] Server-side brigade scope va individual permissions
- [ ] Rahbarlarga server/FCM holat bildirishnomalari
- [ ] Windows boshqaruv dasturi
- [ ] Final signed production release
