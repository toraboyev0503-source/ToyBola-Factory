package uz.toybola.factory

import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Surface
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import uz.toybola.factory.core.data.AssemblyDataRepository
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.core.notifications.NotificationRouteState
import uz.toybola.factory.ui.components.GlobalDrawer
import uz.toybola.factory.ui.model.AppScreen
import uz.toybola.factory.ui.model.AppStrings
import uz.toybola.factory.ui.screens.*
import uz.toybola.factory.ui.theme.ToyBolaTheme

@Composable
fun ToyBolaApp(
    preferences: AppPreferences,
    assemblyDataRepository: AssemblyDataRepository
) {
    var settings by remember { mutableStateOf(preferences.loadSettings()) }
    var authenticated by remember { mutableStateOf(false) }
    val stack = remember { mutableStateListOf(AppScreen.SPLASH) }
    var lastInteraction by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val notificationRoute by NotificationRouteState.route

    fun replace(screen: AppScreen) {
        stack.clear()
        stack.add(screen)
    }

    fun push(screen: AppScreen) {
        if (stack.lastOrNull() != screen) stack.add(screen)
    }

    fun pop() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    fun lock() {
        authenticated = false
        replace(if (preferences.hasSetup()) AppScreen.LOGIN else AppScreen.SETUP)
        scope.launch { drawerState.close() }
    }

    LaunchedEffect(authenticated, settings.autoLockMinutes) {
        while (authenticated) {
            delay(1_000)
            val elapsed = SystemClock.elapsedRealtime() - lastInteraction
            if (elapsed >= settings.autoLockMinutes * 60_000L) lock()
        }
    }

    LaunchedEffect(notificationRoute, authenticated) {
        if (authenticated && notificationRoute != null) {
            when (notificationRoute) {
                "BRIGADIR" -> { replace(AppScreen.HOME); push(AppScreen.ASSEMBLY_ENTRY); push(AppScreen.ASSEMBLY); push(AppScreen.BRIGADIR) }
                "QUALITY" -> { replace(AppScreen.HOME); push(AppScreen.ASSEMBLY_ENTRY); push(AppScreen.ASSEMBLY); push(AppScreen.QUALITY) }
                "MONITORING" -> { replace(AppScreen.HOME); push(AppScreen.ASSEMBLY_ENTRY); push(AppScreen.ASSEMBLY); push(AppScreen.MONITORING) }
                "DAILY_ISSUE" -> { replace(AppScreen.HOME); push(AppScreen.ASSEMBLY_ENTRY); push(AppScreen.ASSEMBLY); push(AppScreen.DAILY_ISSUE) }
            }
            NotificationRouteState.clear()
        }
    }

    ToyBolaTheme(settings) {
        val strings = AppStrings(settings.language)
        val current = stack.lastOrNull() ?: AppScreen.SPLASH
        val allowDrawer = current == AppScreen.HOME

        BackHandler(enabled = stack.size > 1) { pop() }

        ModalNavigationDrawer(
            drawerState = drawerState,
            gesturesEnabled = allowDrawer,
            drawerContent = {
                ModalDrawerSheet(
                    modifier = Modifier
                        .fillMaxWidth(0.54f)
                        .widthIn(min = 210.dp, max = 340.dp)
                ) {
                    GlobalDrawer(
                        strings = strings,
                        settings = settings,
                        onSettingsChange = {
                            settings = it
                            preferences.saveSettings(it)
                        },
                        onLock = ::lock
                    )
                }
            }
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(authenticated) {
                        if (authenticated) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                lastInteraction = SystemClock.elapsedRealtime()
                            }
                        }
                    }
            ) {
                when (current) {
                    AppScreen.SPLASH -> SplashScreen {
                        replace(if (preferences.hasSetup()) AppScreen.LOGIN else AppScreen.SETUP)
                    }
                    AppScreen.SETUP -> SetupScreen(strings) { deviceCode, userCode ->
                        preferences.saveSetup(deviceCode, userCode)
                        authenticated = true
                        lastInteraction = SystemClock.elapsedRealtime()
                        replace(AppScreen.HOME)
                    }
                    AppScreen.LOGIN -> LoginScreen(
                        strings = strings,
                        savedSetup = preferences.setup(),
                        onValidateCodes = preferences::validateCodes,
                        onAuthenticated = {
                            authenticated = true
                            lastInteraction = SystemClock.elapsedRealtime()
                            replace(AppScreen.HOME)
                        }
                    )
                    AppScreen.HOME -> HomeScreen(
                        strings = strings,
                        onMenu = { scope.launch { drawerState.open() } },
                        onAssembly = { push(AppScreen.ASSEMBLY_ENTRY) }
                    )
                    AppScreen.ASSEMBLY_ENTRY -> AssemblyEntryScreen(strings, onBack = ::pop) { push(AppScreen.ASSEMBLY) }
                    AppScreen.ASSEMBLY -> AssemblyMainScreen(strings, onBack = ::pop, onOpen = ::push)
                    AppScreen.BRIGADIR -> BrigadirScreen(strings, assemblyDataRepository, ::pop)
                    AppScreen.QUALITY -> QualityScreen(strings, assemblyDataRepository, ::pop)
                    AppScreen.DAILY_ISSUE -> DailyIssueScreen(strings, assemblyDataRepository, ::pop)
                    AppScreen.MONITORING -> MonitoringScreen(strings, assemblyDataRepository, ::pop)
                    AppScreen.MASTER_DATA -> MasterDataScreen(strings, assemblyDataRepository, ::pop)
                }
            }
        }
    }
}
