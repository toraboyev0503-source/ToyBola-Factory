package uz.toybola.factory.core.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import uz.toybola.factory.core.data.AssemblyDataRepository
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

object NotificationScheduler {
    const val EXTRA_TYPE = "notification_type"
    const val EXTRA_DATE = "notification_date"

    const val QUALITY_ROUND_1 = "quality_round_1"
    const val QUALITY_ROUND_2 = "quality_round_2"
    const val QUALITY_ROUND_3 = "quality_round_3"
    const val QUALITY_CLOSE = "quality_close"
    const val ISSUE_SUMMARY = "issue_summary"
    const val BRIGADIR_REMINDER = "brigadir_reminder"
    const val BRIGADIR_DEADLINE = "brigadir_deadline"

    fun scheduleUpcoming(context: Context, repository: AssemblyDataRepository, days: Int = 4) {
        val data = repository.load()
        val today = LocalDate.now()
        repeat(days.coerceIn(1, 14)) { offset ->
            val date = today.plusDays(offset.toLong())
            val times = data.roundTimesAt(date.toString())
            schedule(context, date.atTime(LocalTime.parse(times.first)), QUALITY_ROUND_1, date)
            schedule(context, date.atTime(LocalTime.parse(times.second)), QUALITY_ROUND_2, date)
            schedule(context, date.atTime(LocalTime.parse(times.third)), QUALITY_ROUND_3, date)
            schedule(context, date.atTime(17, 50), QUALITY_CLOSE, date)
            schedule(context, date.atTime(18, 0), ISSUE_SUMMARY, date)
            schedule(context, date.plusDays(1).atTime(8, 50), BRIGADIR_REMINDER, date)
            schedule(context, date.plusDays(1).atTime(9, 0), BRIGADIR_DEADLINE, date)
        }
    }

    private fun schedule(context: Context, whenAt: LocalDateTime, type: String, recordDate: LocalDate) {
        val now = LocalDateTime.now()
        if (!whenAt.isAfter(now)) return
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, NotificationReceiver::class.java).apply {
            putExtra(EXTRA_TYPE, type)
            putExtra(EXTRA_DATE, recordDate.toString())
        }
        val requestCode = ("$type|$recordDate").hashCode()
        val pending = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val millis = whenAt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending)
    }
}
