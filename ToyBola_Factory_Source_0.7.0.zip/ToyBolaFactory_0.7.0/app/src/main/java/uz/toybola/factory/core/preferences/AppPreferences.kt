package uz.toybola.factory.core.preferences

import android.content.Context
import uz.toybola.factory.ui.model.AppLanguage
import uz.toybola.factory.ui.model.AppSettings
import uz.toybola.factory.ui.model.AppThemePreset
import uz.toybola.factory.ui.model.UserSetup
import java.util.Locale

class AppPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("toy_bola_prefs", Context.MODE_PRIVATE)

    // 0.1.0 -> 0.2.0 migration: old app PIN hash is ignored and removed on next setup save.
    fun hasSetup(): Boolean = prefs.getString(KEY_DEVICE_CODE, "").orEmpty().isNotBlank() &&
        prefs.getString(KEY_USER_CODE, "").orEmpty().isNotBlank()

    fun saveSetup(deviceCode: String, userCode: String) {
        prefs.edit()
            .putString(KEY_DEVICE_CODE, deviceCode.trim().uppercase(Locale.ROOT))
            .putString(KEY_USER_CODE, userCode.trim().uppercase(Locale.ROOT))
            .remove(KEY_PIN_HASH_LEGACY)
            .apply()
    }

    fun setup(): UserSetup? {
        if (!hasSetup()) return null
        return UserSetup(
            deviceCode = prefs.getString(KEY_DEVICE_CODE, "").orEmpty(),
            userCode = prefs.getString(KEY_USER_CODE, "").orEmpty()
        )
    }

    fun validateCodes(deviceCode: String, userCode: String): Boolean {
        val setup = setup() ?: return false
        return setup.deviceCode.equals(deviceCode.trim(), ignoreCase = true) &&
            setup.userCode.equals(userCode.trim(), ignoreCase = true)
    }

    fun loadSettings(): AppSettings {
        val language = runCatching {
            AppLanguage.valueOf(prefs.getString(KEY_LANGUAGE, AppLanguage.UZ.name).orEmpty())
        }.getOrDefault(AppLanguage.UZ)
        val preset = runCatching {
            AppThemePreset.valueOf(prefs.getString(KEY_THEME, AppThemePreset.BRAND.name).orEmpty())
        }.getOrDefault(AppThemePreset.BRAND)
        return AppSettings(
            language = language,
            darkMode = prefs.getBoolean(KEY_DARK, false),
            themePreset = preset,
            autoLockMinutes = prefs.getInt(KEY_LOCK_MINUTES, 5)
        )
    }

    fun saveSettings(settings: AppSettings) {
        prefs.edit()
            .putString(KEY_LANGUAGE, settings.language.name)
            .putBoolean(KEY_DARK, settings.darkMode)
            .putString(KEY_THEME, settings.themePreset.name)
            .putInt(KEY_LOCK_MINUTES, settings.autoLockMinutes)
            .apply()
    }

    companion object {
        private const val KEY_DEVICE_CODE = "device_code"
        private const val KEY_USER_CODE = "user_code"
        private const val KEY_PIN_HASH_LEGACY = "pin_hash"
        private const val KEY_LANGUAGE = "language"
        private const val KEY_DARK = "dark_mode"
        private const val KEY_THEME = "theme"
        private const val KEY_LOCK_MINUTES = "lock_minutes"
    }
}
