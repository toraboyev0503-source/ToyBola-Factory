package uz.toybola.factory.ui.model

enum class AppLanguage { UZ, RU, EN }
enum class AppThemePreset { BRAND, CALM, NEUTRAL }

data class UserSetup(
    val deviceCode: String,
    val userCode: String
)

data class AppSettings(
    val language: AppLanguage = AppLanguage.UZ,
    val darkMode: Boolean = false,
    val themePreset: AppThemePreset = AppThemePreset.BRAND,
    val autoLockMinutes: Int = 5
)

enum class AppScreen {
    SPLASH,
    SETUP,
    LOGIN,
    HOME,
    ASSEMBLY_ENTRY,
    ASSEMBLY,
    BRIGADIR,
    QUALITY,
    DAILY_ISSUE,
    MONITORING,
    MASTER_DATA
}
