package uz.toybola.factory.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import uz.toybola.factory.ui.components.AppTopBar
import uz.toybola.factory.ui.components.SectionCard
import uz.toybola.factory.ui.model.AppScreen
import uz.toybola.factory.ui.model.AppStrings

@Composable
fun AssemblyEntryScreen(strings: AppStrings, onBack: () -> Unit, onAssembly: () -> Unit) {
    var disabled by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        AppTopBar(strings.assemblyAndHome, canGoBack = true, onMenu = {}, onBack = onBack)
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionCard(
                number = null,
                title = strings.homeWork,
                description = strings.homeWorkDesc,
                enabled = false,
                modifier = Modifier.weight(1f),
                onClick = { disabled = true }
            )
            SectionCard(
                number = null,
                title = strings.assembly,
                description = strings.assemblyDesc,
                enabled = true,
                modifier = Modifier.weight(1f),
                onClick = onAssembly
            )
        }
    }
    if (disabled) {
        AlertDialog(
            onDismissRequest = { disabled = false },
            confirmButton = { TextButton(onClick = { disabled = false }) { Text("OK") } },
            text = { Text(strings.notLaunched) }
        )
    }
}

@Composable
fun AssemblyMainScreen(strings: AppStrings, onBack: () -> Unit, onOpen: (AppScreen) -> Unit) {
    val items = listOf(
        Triple(strings.brigadir, strings.brigadirDesc, AppScreen.BRIGADIR),
        Triple(strings.quality, strings.qualityDesc, AppScreen.QUALITY),
        Triple(strings.dailyIssue, strings.dailyIssueDesc, AppScreen.DAILY_ISSUE),
        Triple(strings.monitoring, strings.monitoringDesc, AppScreen.MONITORING),
        Triple(strings.masterData, strings.masterDataDesc, AppScreen.MASTER_DATA)
    )

    Column(Modifier.fillMaxSize()) {
        AppTopBar(strings.assembly, canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items.chunked(2).forEachIndexed { rowIndex, row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEachIndexed { index, item ->
                        val absolute = rowIndex * 2 + index
                        SectionCard(
                            number = absolute + 1,
                            title = item.first,
                            description = item.second,
                            enabled = true,
                            modifier = if (row.size == 1) Modifier.fillMaxWidth() else Modifier.weight(1f),
                            onClick = { onOpen(item.third) }
                        )
                    }
                    if (row.size == 1) Spacer(Modifier.weight(0.0001f))
                }
            }
        }
    }
}

@Composable
fun PlaceholderScreen(title: String, strings: AppStrings, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        AppTopBar(title, canGoBack = true, onMenu = {}, onBack = onBack)
        Column(Modifier.fillMaxSize().navigationBarsPadding().padding(24.dp)) {
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.padding(6.dp))
            Text(strings.skeletonReady, style = MaterialTheme.typography.bodyLarge)
        }
    }
}
