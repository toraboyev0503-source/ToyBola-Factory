# Toy Bola Factory Management System

Android/Kotlin/Jetpack Compose zavod boshqaruv tizimi.

## 0.6.0 — Sborka mobil funksional kandidat

- Device-safe UI va telefon qulfi orqali autentifikatsiya
- Sborka → Ma’lumot: brigada, ishchi, mahsulot, tarixiy narx/F-K/ish vaqti/raund vaqti/normativ/mezonlar, arxiv, audit
- Brigadir: kunlik ishchilar, soat, mahsulot tanlash, son/narx/summa, samaradorlik, tugallangan/tugallanmagan, kun yopish va kechikish sababi
- Sifat: 3 raund, ±1 soat oynasi, 1/2/3/4 baho, qayta tekshiruv, o‘tkazib yuborilgan raund sababi, kun yopish
- Kun muammosi: bugungi mahsulot + yig‘uv bosqichi + izoh CRUD
- Monitoring: yil/oy/kvartal/kun, ishchi natijalari, Brigadir va Sifat baholashi, muammoli mahsulotlar drill-down
- Monitoring ichida Kun/Oy/Yil DOCX muammolar eksporti
- Oldingi kun yopilmagan bo‘lsa bugungi ish bloklanmaydi; eski kun alohida outstanding vazifa sifatida qoladi
- Lokal/offline vaqtli eslatmalar: sifat raundlari, 17:50, 18:00, brigadir 08:50/09:00
- GitHub Actions: test, lint, assembleDebug, APK artifact

## Muhim

0.6.0 — mobil/offline Sborka funksiyalarini birlashtirgan test kandidat. Markaziy server/Firebase, multi-device sync, server-side permissions va Windows boshqaruv dasturi alohida integratsiya bosqichida ulanadi; ishlab chiqarish ma’lumotlari serverga ko‘chirilishidan oldin telefon funksiyalari bir martalik to‘liq testdan o‘tkaziladi.


## 0.7.3
- Global drawer default 80% UI masshtab va 70–110% foydalanuvchi sozlamasi.
- Serverga tayyor ruxsat modeli: Sborka bo‘limlari uchun read/write hamda brigada scope.
- Lokal testda full access; server ulanganida backend/Security Rules yakuniy vakolat manbai bo‘ladi.
