package uz.toybola.factory

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import uz.toybola.factory.core.data.AssemblyDataRepository
import uz.toybola.factory.core.notifications.NotificationInboxRepository
import uz.toybola.factory.core.notifications.NotificationReceiver
import uz.toybola.factory.core.notifications.NotificationRouteState
import uz.toybola.factory.core.notifications.NotificationScheduler
import uz.toybola.factory.core.preferences.AppPreferences

class MainActivity : ComponentActivity() {
    private lateinit var repository: AssemblyDataRepository
    private lateinit var notificationInboxRepository: NotificationInboxRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val preferences = AppPreferences(applicationContext)
        repository = AssemblyDataRepository(applicationContext)
        notificationInboxRepository = NotificationInboxRepository(applicationContext)
        handleRoute(intent)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 210)
        }
        NotificationScheduler.scheduleUpcoming(applicationContext, repository)
        setContent {
            ToyBolaApp(
                preferences = preferences,
                assemblyDataRepository = repository,
                notificationInboxRepository = notificationInboxRepository
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleRoute(intent)
    }

    private fun handleRoute(intent: Intent?) {
        intent?.getStringExtra(NotificationReceiver.EXTRA_NOTIFICATION_KEY)?.let { key ->
            if (::notificationInboxRepository.isInitialized) notificationInboxRepository.markRead(key)
        }
        NotificationRouteState.set(intent?.getStringExtra(NotificationReceiver.EXTRA_ROUTE))
    }
}
