package uz.toybola.factory.core.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.Year
import java.util.Locale
import java.util.UUID

class AssemblyDataRepository(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    @Synchronized
    fun load(): AssemblyData {
        val raw = prefs.getString(KEY_DATA, null) ?: return defaultData().also(::save)
        return runCatching { decode(JSONObject(raw)) }.getOrElse { defaultData().also(::save) }
    }

    @Synchronized
    fun addBrigade(name: String): Result<Unit> = mutate { data ->
        val clean = name.normalizeHumanText()
        require(clean.isNotBlank()) { "Brigada nomi bo‘sh bo‘lmasin" }
        require(data.brigades.none { !it.archived && it.name.equals(clean, true) }) { "Bunday brigada mavjud" }
        data.copy(brigades = data.brigades + Brigade(UUID.randomUUID().toString(), clean))
    }

    @Synchronized
    fun renameBrigade(id: String, name: String): Result<Unit> = mutate { data ->
        val clean = name.normalizeHumanText()
        require(clean.isNotBlank()) { "Brigada nomi bo‘sh bo‘lmasin" }
        require(data.brigades.none { it.id != id && !it.archived && it.name.equals(clean, true) }) { "Bunday brigada mavjud" }
        data.copy(brigades = data.brigades.map { if (it.id == id) it.copy(name = clean) else it })
    }

    @Synchronized
    fun archiveBrigade(id: String, archived: Boolean): Result<Unit> = mutate { data ->
        val target = data.brigades.firstOrNull { it.id == id } ?: return@mutate data
        if (!archived) {
            require(data.brigades.none { it.id != id && !it.archived && it.name.equals(target.name, true) }) { "Shu nomli faol brigada mavjud" }
        }
        data.copy(brigades = data.brigades.map { if (it.id == id) it.copy(archived = archived) else it })
    }

    @Synchronized
    fun deleteArchivedBrigade(id: String): Result<Unit> = mutate { data ->
        val target = data.brigades.firstOrNull { it.id == id } ?: error("Brigada topilmadi")
        require(target.archived && !target.deleted) { "Faqat arxivdagi brigadani o‘chirish mumkin" }
        require(data.workers.none { it.brigadeId == id }) { "Brigadada ishchilar mavjud. Avval ishchilarni boshqa brigadaga o‘tkazing yoki olib tashlang." }
        val updated = data.copy(brigades = data.brigades.map { if (it.id == id) it.copy(deleted = true) else it })
        data.withAudit(updated, "BRIGADE_DELETE", id, details = target.name)
    }

    @Synchronized
    fun addWorker(brigadeId: String, name: String, startDate: String): Result<Unit> = mutate { data ->
        require(data.brigades.any { it.id == brigadeId && !it.archived }) { "Brigada tanlang" }
        val clean = name.normalizeHumanText()
        require(clean.isNotBlank()) { "Ishchi ismini kiriting" }
        LocalDate.parse(startDate)
        data.copy(workers = data.workers + Worker(UUID.randomUUID().toString(), brigadeId, clean, startDate))
    }

    @Synchronized
    fun updateWorker(id: String, brigadeId: String, name: String, startDate: String): Result<Unit> = mutate { data ->
        require(data.brigades.any { it.id == brigadeId && !it.archived }) { "Brigada tanlang" }
        val clean = name.normalizeHumanText()
        require(clean.isNotBlank()) { "Ishchi ismini kiriting" }
        LocalDate.parse(startDate)
        data.copy(workers = data.workers.map {
            if (it.id == id) it.copy(brigadeId = brigadeId, name = clean, startDate = startDate) else it
        })
    }

    @Synchronized
    fun archiveWorker(id: String, archived: Boolean): Result<Unit> = mutate { data ->
        data.copy(workers = data.workers.map { if (it.id == id) it.copy(archived = archived) else it })
    }

    @Synchronized
    fun addProduct(brigadeId: String, article: String, name: String, price: Long): Result<Unit> = mutate { data ->
        validateProduct(data, null, brigadeId, article, name, price)
        val today = LocalDate.now().toString()
        data.copy(products = data.products + Product(
            id = UUID.randomUUID().toString(),
            brigadeId = brigadeId,
            article = article.trim().uppercase(Locale.ROOT),
            name = name.normalizeHumanText(),
            priceHistory = listOf(PriceVersion(price, today))
        ))
    }

    @Synchronized
    fun updateProduct(id: String, brigadeId: String, article: String, name: String, price: Long): Result<Unit> = mutate { data ->
        validateProduct(data, id, brigadeId, article, name, price)
        val today = LocalDate.now().toString()
        data.copy(products = data.products.map { product ->
            if (product.id != id) return@map product
            val history = if (product.currentPrice != price) {
                product.priceHistory.filterNot { it.effectiveFrom == today } + PriceVersion(price, today)
            } else product.priceHistory
            product.copy(
                brigadeId = brigadeId,
                article = article.trim().uppercase(Locale.ROOT),
                name = name.normalizeHumanText(),
                priceHistory = history
            )
        })
    }

    @Synchronized
    fun setProductPrice(productId: String, price: Long, effectiveFrom: String): Result<Unit> = mutate { data ->
        require(price > 0) { "Narx 0 dan katta bo‘lsin" }
        LocalDate.parse(effectiveFrom)
        val product = data.products.firstOrNull { it.id == productId } ?: error("Mahsulot topilmadi")
        val updated = data.copy(products = data.products.map { item ->
            if (item.id != productId) item else item.copy(
                priceHistory = item.priceHistory.filterNot { it.effectiveFrom == effectiveFrom } + PriceVersion(price, effectiveFrom)
            )
        })
        data.withAudit(updated, "PRODUCT_PRICE", product.brigadeId, effectiveFrom, "${product.article}: $price")
    }

    @Synchronized
    fun addProductStage(productId: String, name: String): Result<Unit> = mutate { data ->
        val clean = name.normalizeHumanText()
        require(clean.isNotBlank()) { "Yig‘uv bosqichi nomini kiriting" }
        data.copy(products = data.products.map { product ->
            if (product.id != productId) return@map product
            require(product.stages.none { !it.archived && it.name.equals(clean, true) }) { "Bu yig‘uv bosqichi mavjud" }
            product.copy(stages = product.stages + ProductStage(UUID.randomUUID().toString(), clean))
        })
    }

    @Synchronized
    fun renameProductStage(productId: String, stageId: String, name: String): Result<Unit> = mutate { data ->
        val clean = name.normalizeHumanText()
        require(clean.isNotBlank()) { "Yig‘uv bosqichi nomini kiriting" }
        data.copy(products = data.products.map { product ->
            if (product.id != productId) return@map product
            require(product.stages.none { it.id != stageId && !it.archived && it.name.equals(clean, true) }) { "Bu yig‘uv bosqichi mavjud" }
            product.copy(stages = product.stages.map { if (it.id == stageId) it.copy(name = clean) else it })
        })
    }

    @Synchronized
    fun archiveProductStage(productId: String, stageId: String, archived: Boolean): Result<Unit> = mutate { data ->
        data.copy(products = data.products.map { product ->
            if (product.id != productId) product
            else product.copy(stages = product.stages.map { if (it.id == stageId) it.copy(archived = archived) else it })
        })
    }

    @Synchronized
    fun archiveProduct(id: String, archived: Boolean): Result<Unit> = mutate { data ->
        val target = data.products.firstOrNull { it.id == id } ?: return@mutate data
        if (!archived) {
            require(data.products.none { it.id != id && !it.archived && it.article.equals(target.article, true) }) { "Shu artikulli faol mahsulot mavjud" }
        }
        data.copy(products = data.products.map { if (it.id == id) it.copy(archived = archived) else it })
    }

    @Synchronized
    fun setBrigadeFk(brigadeId: String, value: Long, effectiveFrom: String = LocalDate.now().toString()): Result<Unit> = mutate { data ->
        require(value > 0) { "F/K 0 dan katta bo‘lsin" }
        LocalDate.parse(effectiveFrom)
        val existing = data.brigadeFk.firstOrNull { it.brigadeId == brigadeId }
        val updated = if (existing == null) {
            data.brigadeFk + BrigadeFkHistory(brigadeId, listOf(LongVersion(value, effectiveFrom)))
        } else {
            data.brigadeFk.map {
                if (it.brigadeId == brigadeId) it.copy(
                    versions = it.versions.filterNot { v -> v.effectiveFrom == effectiveFrom } + LongVersion(value, effectiveFrom)
                ) else it
            }
        }
        data.withAudit(data.copy(brigadeFk = updated), "FK_CHANGE", brigadeId, effectiveFrom, value.toString())
    }

    @Synchronized
    fun setWorkHours(value: Int, effectiveFrom: String = LocalDate.now().toString()): Result<Unit> = mutate { data ->
        require(value in 1..24) { "Ish vaqti 1–24 soat bo‘lsin" }
        LocalDate.parse(effectiveFrom)
        data.withAudit(data.copy(workHours = data.workHours.upsert(IntVersion(value, effectiveFrom))), "WORK_HOURS", recordDate = effectiveFrom, details = value.toString())
    }

    @Synchronized
    fun setEfficiencyNorm(value: Int, effectiveFrom: String = LocalDate.now().toString()): Result<Unit> = mutate { data ->
        require(value in 1..200) { "Normativ 1–200% oralig‘ida bo‘lsin" }
        LocalDate.parse(effectiveFrom)
        data.withAudit(data.copy(efficiencyNorm = data.efficiencyNorm.upsert(IntVersion(value, effectiveFrom))), "EFFICIENCY_NORM", recordDate = effectiveFrom, details = "$value%")
    }

    @Synchronized
    fun setRoundTimes(first: String, second: String, third: String, effectiveFrom: String = LocalDate.now().toString()): Result<Unit> = mutate { data ->
        listOf(first, second, third).forEach { java.time.LocalTime.parse(it) }
        LocalDate.parse(effectiveFrom)
        val updated = data.copy(roundTimes = data.roundTimes.filterNot { it.effectiveFrom == effectiveFrom } +
            RoundTimesVersion(first, second, third, effectiveFrom))
        data.withAudit(updated, "ROUND_TIMES", recordDate = effectiveFrom, details = "$first / $second / $third")
    }

    @Synchronized
    fun setMonitoringWeights(
        brigadir: BrigadirWeights,
        quality: QualityWeights,
        effectiveFrom: String = LocalDate.now().toString()
    ): Result<Unit> = mutate { data ->
        require(brigadir.total == 100) { "Brigadir mezonlari jami 100% bo‘lsin" }
        require(quality.total == 100) { "Sifat mezonlari jami 100% bo‘lsin" }
        LocalDate.parse(effectiveFrom)
        val updated = data.copy(monitoringWeights = data.monitoringWeights.filterNot { it.effectiveFrom == effectiveFrom } +
            MonitoringWeightsVersion(brigadir, quality, effectiveFrom))
        data.withAudit(updated, "MONITORING_WEIGHTS", recordDate = effectiveFrom, details = "Brigadir ${brigadir.onTimeClose}/${brigadir.noReopen}/${brigadir.brigadeResult}; Sifat ${quality.roundsOnTime}/${quality.rechecks}/${quality.onTimeClose}/${quality.dataDiscipline}")
    }

    @Synchronized
    fun setBrigadeWorked(brigadeId: String, date: String, worked: Boolean): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        ensureBrigadirEditable(data, brigadeId, date)
        val current = data.brigadeDay(brigadeId, date) ?: BrigadeDay(brigadeId, date)
        val row = current.copy(worked = worked)
        data.copy(brigadeDays = data.brigadeDays.filterNot { it.brigadeId == brigadeId && it.date == date } + row)
    }

    @Synchronized
    fun setWorkerWorked(workerId: String, date: String, worked: Boolean): Result<Unit> = mutate { data ->
        val worker = data.workers.firstOrNull { it.id == workerId } ?: error("Ishchi topilmadi")
        ensureBrigadirEditable(data, worker.brigadeId, date)
        val current = data.workerDay(workerId, date) ?: WorkerDay(workerId, worker.brigadeId, date, hours = data.workHoursAt(date))
        val updated = current.copy(worked = worked, entries = if (worked) current.entries else emptyList(), updatedAt = Instant.now().toString())
        data.copy(workerDays = data.workerDays.filterNot { it.workerId == workerId && it.date == date } + updated)
    }

    @Synchronized
    fun setWorkerHours(workerId: String, date: String, hours: Int): Result<Unit> = mutate { data ->
        require(hours in 1..24) { "Ish vaqti 1–24 soat bo‘lsin" }
        val worker = data.workers.firstOrNull { it.id == workerId } ?: error("Ishchi topilmadi")
        ensureBrigadirEditable(data, worker.brigadeId, date)
        val current = data.workerDay(workerId, date) ?: WorkerDay(workerId, worker.brigadeId, date, hours = data.workHoursAt(date))
        data.copy(workerDays = data.workerDays.filterNot { it.workerId == workerId && it.date == date } + current.copy(hours = hours, updatedAt = Instant.now().toString()))
    }

    @Synchronized
    fun addProductionEntry(workerId: String, date: String, productId: String, quantity: Int, mergeDuplicate: Boolean): Result<Unit> = mutate { data ->
        require(quantity > 0) { "Soni 0 dan katta bo‘lsin" }
        val worker = data.workers.firstOrNull { it.id == workerId } ?: error("Ishchi topilmadi")
        ensureBrigadirEditable(data, worker.brigadeId, date)
        val product = data.products.firstOrNull { it.id == productId && !it.archived } ?: error("Mahsulot topilmadi")
        require(product.brigadeId == worker.brigadeId) { "Mahsulot boshqa brigadaga tegishli" }
        val current = data.workerDay(workerId, date) ?: WorkerDay(workerId, worker.brigadeId, date, hours = data.workHoursAt(date))
        require(current.worked) { "Ishlamadi holatidagi ishchiga mahsulot yozib bo‘lmaydi" }
        val duplicate = current.entries.firstOrNull { it.productId == productId }
        require(duplicate == null || mergeDuplicate) { "DUPLICATE_PRODUCT" }
        val entries = if (duplicate != null) {
            current.entries.map { if (it.id == duplicate.id) it.copy(quantity = it.quantity + quantity) else it }
        } else {
            current.entries + ProductionEntry(
                id = UUID.randomUUID().toString(),
                productId = product.id,
                articleSnapshot = product.article,
                productNameSnapshot = product.name,
                quantity = quantity,
                unitPriceSnapshot = product.priceAt(date)
            )
        }
        val updated = current.copy(entries = entries, updatedAt = Instant.now().toString())
        data.copy(workerDays = data.workerDays.filterNot { it.workerId == workerId && it.date == date } + updated)
    }

    @Synchronized
    fun updateProductionQuantity(workerId: String, date: String, entryId: String, quantity: Int): Result<Unit> = mutate { data ->
        require(quantity > 0) { "Soni 0 dan katta bo‘lsin" }
        val current = data.workerDay(workerId, date) ?: error("Kunlik ma’lumot topilmadi")
        ensureBrigadirEditable(data, current.brigadeId, date)
        val updated = current.copy(entries = current.entries.map { if (it.id == entryId) it.copy(quantity = quantity) else it }, updatedAt = Instant.now().toString())
        data.copy(workerDays = data.workerDays.filterNot { it.workerId == workerId && it.date == date } + updated)
    }

    @Synchronized
    fun removeProductionEntry(workerId: String, date: String, entryId: String): Result<Unit> = mutate { data ->
        val current = data.workerDay(workerId, date) ?: return@mutate data
        ensureBrigadirEditable(data, current.brigadeId, date)
        val updated = current.copy(entries = current.entries.filterNot { it.id == entryId }, updatedAt = Instant.now().toString())
        data.copy(workerDays = data.workerDays.filterNot { it.workerId == workerId && it.date == date } + updated)
    }

    @Synchronized
    fun saveQualityRound(
        workerId: String,
        date: String,
        round: Int,
        scheduledTime: String,
        grade: Int,
        productId: String,
        stageId: String,
        note: String
    ): Result<Unit> = mutate { data ->
        require(round in 1..3) { "Raund 1–3 oralig‘ida bo‘lsin" }
        require(grade in 1..4) { "Baho 1–4 oralig‘ida bo‘lsin" }
        val scheduled = LocalDateTime.of(LocalDate.parse(date), java.time.LocalTime.parse(scheduledTime))
        val now = LocalDateTime.now()
        require(!now.isBefore(scheduled.minusHours(1)) && !now.isAfter(scheduled.plusHours(1))) { "Raundni faqat belgilangan vaqtdan ±1 soat ichida baholash mumkin" }
        val worker = data.workers.firstOrNull { it.id == workerId && !it.archived } ?: error("Ishchi topilmadi")
        ensureQualityEditable(data, worker.brigadeId, date)
        val product = data.products.firstOrNull { it.id == productId && !it.archived } ?: error("Mahsulot topilmadi")
        require(product.brigadeId == worker.brigadeId) { "Mahsulot boshqa brigadaga tegishli" }
        val stage = product.stages.firstOrNull { it.id == stageId && !it.archived } ?: error("Yig‘uv bosqichi topilmadi")
        val cleanNote = note.normalizeHumanText()
        if (grade >= 3) require(cleanNote.isNotBlank()) { "3 yoki 4 bahoda izoh majburiy" }
        val score = when (grade) { 1 -> 100; 2 -> 75; 3 -> 50; else -> 0 }
        val existing = data.qualityRound(workerId, date, round)
        val record = QualityRoundRecord(
            id = existing?.id ?: UUID.randomUUID().toString(),
            workerId = workerId,
            brigadeId = worker.brigadeId,
            date = date,
            round = round,
            scheduledTime = scheduledTime,
            grade = grade,
            score = score,
            productId = product.id,
            articleSnapshot = product.article,
            productNameSnapshot = product.name,
            stageId = stage.id,
            stageNameSnapshot = stage.name,
            note = cleanNote,
            evaluatedAt = LocalDateTime.now().toString(),
            missedReason = "",
            missedAt = null,
            recheck = existing?.recheck
        )
        data.copy(qualityRounds = data.qualityRounds.filterNot { it.workerId == workerId && it.date == date && it.round == round } + record)
    }

    @Synchronized
    fun markQualityRoundMissed(workerId: String, date: String, round: Int, scheduledTime: String, reason: String): Result<Unit> = mutate { data ->
        val scheduled = LocalDateTime.of(LocalDate.parse(date), java.time.LocalTime.parse(scheduledTime))
        require(LocalDateTime.now().isAfter(scheduled.plusHours(1))) { "Raund vaqti hali tugamagan" }
        val worker = data.workers.firstOrNull { it.id == workerId && !it.archived } ?: error("Ishchi topilmadi")
        ensureQualityEditable(data, worker.brigadeId, date)
        val clean = reason.normalizeHumanText()
        require(clean.isNotBlank()) { "Sabab yozilishi shart" }
        val existing = data.qualityRound(workerId, date, round)
        require(existing?.isEvaluated != true) { "Baholangan raundni o‘tkazib yuborilgan qilib bo‘lmaydi" }
        val record = QualityRoundRecord(
            id = existing?.id ?: UUID.randomUUID().toString(),
            workerId = workerId,
            brigadeId = worker.brigadeId,
            date = date,
            round = round,
            scheduledTime = scheduledTime,
            missedReason = clean,
            missedAt = LocalDateTime.now().toString()
        )
        data.copy(qualityRounds = data.qualityRounds.filterNot { it.workerId == workerId && it.date == date && it.round == round } + record)
    }

    @Synchronized
    fun saveQualityRecheck(workerId: String, date: String, round: Int, grade: Int, note: String): Result<Unit> = mutate { data ->
        require(grade in 1..4) { "Baho 1–4 oralig‘ida bo‘lsin" }
        val current = data.qualityRound(workerId, date, round) ?: error("Asosiy sifat tekshiruvi topilmadi")
        ensureQualityEditable(data, current.brigadeId, date)
        require(current.needsRecheck) { "Bu raund qayta tekshiruv talab qilmaydi" }
        val updated = current.copy(recheck = QualityRecheck(grade, note.normalizeHumanText(), LocalDateTime.now().toString()))
        data.copy(qualityRounds = data.qualityRounds.filterNot { it.workerId == workerId && it.date == date && it.round == round } + updated)
    }


    @Synchronized
    fun closeBrigadirDay(brigadeId: String, date: String, lateReason: String = ""): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val current = data.brigadeDay(brigadeId, date) ?: BrigadeDay(brigadeId, date)
        require(!current.brigadirClosed) { "Brigadir kuni allaqachon yopilgan" }
        val missing = data.brigadirMissing(brigadeId, date)
        require(missing.isEmpty()) { "Tugallanmagan ma’lumotlar: ${missing.take(4).joinToString(", ")}" }
        val now = LocalDateTime.now()
        val deadline = LocalDate.parse(date).plusDays(1).atTime(9, 0)
        val cleanReason = lateReason.normalizeHumanText().ifBlank { current.brigadirLateReason }
        if (now.isAfter(deadline)) require(cleanReason.isNotBlank()) { "09:00 dan keyin yopish sababini yozing" }
        val updated = current.copy(
            brigadirClosedAt = now.toString(),
            brigadirLateReason = cleanReason,
            closedAt = if (current.qualityClosed) now.toString() else current.closedAt
        )
        data.withAudit(
            updated = data.copy(brigadeDays = data.brigadeDays.filterNot { it.brigadeId == brigadeId && it.date == date } + updated),
            action = "BRIGADIR_CLOSE", brigadeId = brigadeId, recordDate = date,
            details = if (cleanReason.isBlank()) "Vaqtida yopildi" else "Kech yopildi: $cleanReason"
        )
    }

    @Synchronized
    fun closeQualityDay(brigadeId: String, date: String, lateReason: String = ""): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        val current = data.brigadeDay(brigadeId, date) ?: BrigadeDay(brigadeId, date)
        require(!current.qualityClosed) { "Sifat kuni allaqachon yopilgan" }
        val missing = data.qualityMissing(brigadeId, date)
        require(missing.isEmpty()) { "Tugallanmagan sifat ma’lumotlari: ${missing.take(4).joinToString(", ")}" }
        val now = LocalDateTime.now()
        val deadline = LocalDate.parse(date).atTime(17, 50)
        val cleanReason = lateReason.normalizeHumanText().ifBlank { current.qualityLateReason }
        if (now.isAfter(deadline)) require(cleanReason.isNotBlank()) { "17:50 dan keyin yopish sababini yozing" }
        val updated = current.copy(
            qualityClosedAt = now.toString(),
            qualityLateReason = cleanReason,
            closedAt = if (current.brigadirClosed) now.toString() else current.closedAt
        )
        data.withAudit(
            updated = data.copy(brigadeDays = data.brigadeDays.filterNot { it.brigadeId == brigadeId && it.date == date } + updated),
            action = "QUALITY_CLOSE", brigadeId = brigadeId, recordDate = date,
            details = if (cleanReason.isBlank()) "Vaqtida yopildi" else "Kech yopildi: $cleanReason"
        )
    }

    @Synchronized
    fun reopenDay(brigadeId: String, date: String, reason: String): Result<Unit> = mutate { data ->
        val current = data.brigadeDay(brigadeId, date) ?: error("Kun topilmadi")
        require(current.fullyClosed) { "Faqat to‘liq yopilgan kun qayta ochiladi" }
        val clean = reason.normalizeHumanText()
        require(clean.isNotBlank()) { "Qayta ochish sababini yozing" }
        val now = LocalDateTime.now().toString()
        val updated = current.copy(
            brigadirClosedAt = null, brigadirLateReason = "",
            qualityClosedAt = null, qualityLateReason = "",
            closedAt = null, reopenCount = current.reopenCount + 1,
            lastReopenedAt = now, lastReopenReason = clean
        )
        data.withAudit(
            updated = data.copy(brigadeDays = data.brigadeDays.filterNot { it.brigadeId == brigadeId && it.date == date } + updated),
            action = "DAY_REOPEN", brigadeId = brigadeId, recordDate = date, details = clean
        )
    }

    @Synchronized
    fun saveQualityLateReason(brigadeId: String, date: String, reason: String): Result<Unit> = mutate { data ->
        val clean = reason.normalizeHumanText()
        require(clean.isNotBlank()) { "Sabab yozilishi shart" }
        val current = data.brigadeDay(brigadeId, date) ?: BrigadeDay(brigadeId, date)
        data.copy(brigadeDays = data.brigadeDays.filterNot { it.brigadeId == brigadeId && it.date == date } + current.copy(qualityLateReason = clean))
    }

    @Synchronized
    fun saveBrigadirLateReason(brigadeId: String, date: String, reason: String): Result<Unit> = mutate { data ->
        val clean = reason.normalizeHumanText()
        require(clean.isNotBlank()) { "Sabab yozilishi shart" }
        val current = data.brigadeDay(brigadeId, date) ?: BrigadeDay(brigadeId, date)
        data.copy(brigadeDays = data.brigadeDays.filterNot { it.brigadeId == brigadeId && it.date == date } + current.copy(brigadirLateReason = clean))
    }


    @Synchronized
    fun addDailyIssue(
        brigadeId: String,
        date: String,
        productId: String,
        stageId: String,
        note: String
    ): Result<Unit> = mutate { data ->
        LocalDate.parse(date)
        require(data.brigades.any { it.id == brigadeId && !it.archived }) { "Brigada topilmadi" }
        val product = data.products.firstOrNull { it.id == productId && !it.archived } ?: error("Mahsulot topilmadi")
        require(product.brigadeId == brigadeId) { "Mahsulot boshqa brigadaga tegishli" }
        val stage = product.stages.firstOrNull { it.id == stageId && !it.archived } ?: error("Yig‘uv bosqichi topilmadi")
        val clean = note.normalizeHumanText()
        require(clean.isNotBlank()) { "Muammo izohini yozing" }
        val issue = DailyIssueRecord(
            id = UUID.randomUUID().toString(),
            brigadeId = brigadeId,
            date = date,
            productId = product.id,
            articleSnapshot = product.article,
            productNameSnapshot = product.name,
            stageId = stage.id,
            stageNameSnapshot = stage.name,
            note = clean,
            createdAt = LocalDateTime.now().toString()
        )
        data.copy(dailyIssues = data.dailyIssues + issue)
    }

    @Synchronized
    fun updateDailyIssue(issueId: String, productId: String, stageId: String, note: String): Result<Unit> = mutate { data ->
        val current = data.dailyIssues.firstOrNull { it.id == issueId } ?: error("Muammo yozuvi topilmadi")
        val product = data.products.firstOrNull { it.id == productId && !it.archived } ?: error("Mahsulot topilmadi")
        require(product.brigadeId == current.brigadeId) { "Mahsulot boshqa brigadaga tegishli" }
        val stage = product.stages.firstOrNull { it.id == stageId && !it.archived } ?: error("Yig‘uv bosqichi topilmadi")
        val clean = note.normalizeHumanText()
        require(clean.isNotBlank()) { "Muammo izohini yozing" }
        data.copy(dailyIssues = data.dailyIssues.map {
            if (it.id != issueId) it else it.copy(
                productId = product.id,
                articleSnapshot = product.article,
                productNameSnapshot = product.name,
                stageId = stage.id,
                stageNameSnapshot = stage.name,
                note = clean
            )
        })
    }

    @Synchronized
    fun removeDailyIssue(issueId: String): Result<Unit> = mutate { data ->
        data.copy(dailyIssues = data.dailyIssues.filterNot { it.id == issueId })
    }

    @Synchronized
    fun prepareNextYear(): Result<Int> = mutateWithValue { data ->
        val nextYear = Year.now().value + 1
        if (nextYear in data.preparedYears) return@mutateWithValue data to nextYear
        val effective = "$nextYear-01-01"
        var updated = data.copy(
            workHours = data.workHours.upsert(IntVersion(data.currentWorkHours(), effective)),
            efficiencyNorm = data.efficiencyNorm.upsert(IntVersion(data.currentEfficiencyNorm(), effective)),
            roundTimes = data.roundTimes.filterNot { it.effectiveFrom == effective } + data.currentRoundTimes().copy(effectiveFrom = effective),
            monitoringWeights = data.monitoringWeights.filterNot { it.effectiveFrom == effective } + data.currentMonitoringWeights().copy(effectiveFrom = effective),
            brigadeFk = data.brigadeFk.map { fk ->
                fk.current?.let { current -> fk.copy(versions = fk.versions.filterNot { it.effectiveFrom == effective } + LongVersion(current, effective)) } ?: fk
            },
            preparedYears = (data.preparedYears + nextYear).distinct().sorted()
        )
        updated to nextYear
    }

    private fun validateProduct(data: AssemblyData, currentId: String?, brigadeId: String, article: String, name: String, price: Long) {
        require(data.brigades.any { it.id == brigadeId && !it.archived }) { "Brigada tanlang" }
        require(article.trim().isNotBlank()) { "Artikul kiriting" }
        require(name.trim().isNotBlank()) { "Mahsulot nomini kiriting" }
        require(price > 0) { "Narx 0 dan katta bo‘lsin" }
        require(data.products.none { it.id != currentId && !it.archived && it.article.equals(article.trim(), true) }) { "Bu artikul avval kiritilgan" }
    }


    private fun ensureBrigadirEditable(data: AssemblyData, brigadeId: String, date: String) {
        require(data.brigadeDay(brigadeId, date)?.brigadirClosed != true) { "Brigadir kuni yopilgan. Qayta ochish faqat administrator orqali." }
    }

    private fun ensureQualityEditable(data: AssemblyData, brigadeId: String, date: String) {
        require(data.brigadeDay(brigadeId, date)?.qualityClosed != true) { "Sifat kuni yopilgan. Qayta ochish faqat administrator orqali." }
    }

    private fun AssemblyData.withAudit(
        updated: AssemblyData,
        action: String,
        brigadeId: String? = null,
        recordDate: String? = null,
        details: String = ""
    ): AssemblyData = updated.copy(
        auditLog = (this.auditLog + AuditEntry(
            id = UUID.randomUUID().toString(),
            dateTime = LocalDateTime.now().toString(),
            action = action, brigadeId = brigadeId, recordDate = recordDate, details = details
        )).takeLast(2000)
    )

    private fun String.normalizeHumanText(): String {
        val input = trim().replace(Regex("\\s+"), " ")
        if (input.isBlank()) return input
        val out = StringBuilder(input.length + 8)
        var capitalizeNext = true
        var i = 0
        while (i < input.length) {
            val ch = input[i]
            if (ch.isWhitespace()) {
                if (out.isNotEmpty() && out.last() != ' ') out.append(' ')
                i++
                continue
            }
            out.append(if (capitalizeNext && ch.isLetter()) ch.uppercaseChar() else ch)
            capitalizeNext = false
            if (ch == '.' || ch == '!' || ch == '?') {
                capitalizeNext = true
                if (i + 1 < input.length && !input[i + 1].isWhitespace()) out.append(' ')
            } else if (ch == ',' || ch == ';' || ch == ':') {
                if (i + 1 < input.length && !input[i + 1].isWhitespace()) out.append(' ')
            }
            i++
        }
        return out.toString().trim()
    }

    private fun List<IntVersion>.upsert(value: IntVersion): List<IntVersion> = filterNot { it.effectiveFrom == value.effectiveFrom } + value

    private fun defaultData(): AssemblyData = AssemblyData(
        workHours = listOf(IntVersion(10, "2000-01-01")),
        efficiencyNorm = listOf(IntVersion(85, "2000-01-01")),
        roundTimes = listOf(RoundTimesVersion("10:00", "13:00", "16:00", "2000-01-01")),
        monitoringWeights = listOf(MonitoringWeightsVersion(BrigadirWeights(), QualityWeights(), "2000-01-01"))
    )

    private inline fun mutate(transform: (AssemblyData) -> AssemblyData): Result<Unit> = runCatching { save(transform(load())) }
    private inline fun <T> mutateWithValue(transform: (AssemblyData) -> Pair<AssemblyData, T>): Result<T> = runCatching {
        val (updated, value) = transform(load()); save(updated); value
    }

    private fun save(data: AssemblyData) {
        prefs.edit().putString(KEY_DATA, encode(data).toString()).apply()
    }

    private fun encode(data: AssemblyData): JSONObject = JSONObject().apply {
        put("brigades", JSONArray().apply { data.brigades.forEach { put(JSONObject().apply { put("id", it.id); put("name", it.name); put("archived", it.archived); put("deleted", it.deleted) }) } })
        put("workers", JSONArray().apply { data.workers.forEach { put(JSONObject().apply { put("id", it.id); put("brigadeId", it.brigadeId); put("name", it.name); put("startDate", it.startDate); put("archived", it.archived) }) } })
        put("products", JSONArray().apply { data.products.forEach { product -> put(JSONObject().apply {
            put("id", product.id); put("brigadeId", product.brigadeId); put("article", product.article); put("name", product.name); put("archived", product.archived)
            put("prices", JSONArray().apply { product.priceHistory.forEach { price -> put(JSONObject().apply { put("price", price.price); put("effectiveFrom", price.effectiveFrom) }) } })
            put("stages", JSONArray().apply { product.stages.forEach { stage -> put(JSONObject().apply { put("id", stage.id); put("name", stage.name); put("archived", stage.archived) }) } })
        }) } })
        put("brigadeFk", JSONArray().apply { data.brigadeFk.forEach { fk -> put(JSONObject().apply {
            put("brigadeId", fk.brigadeId); put("versions", JSONArray().apply { fk.versions.forEach { v -> put(JSONObject().apply { put("value", v.value); put("effectiveFrom", v.effectiveFrom) }) } })
        }) } })
        put("workHours", encodeIntVersions(data.workHours))
        put("efficiencyNorm", encodeIntVersions(data.efficiencyNorm))
        put("roundTimes", JSONArray().apply { data.roundTimes.forEach { v -> put(JSONObject().apply { put("first", v.first); put("second", v.second); put("third", v.third); put("effectiveFrom", v.effectiveFrom) }) } })
        put("monitoringWeights", JSONArray().apply { data.monitoringWeights.forEach { v -> put(JSONObject().apply {
            put("effectiveFrom", v.effectiveFrom)
            put("brigadir", JSONObject().apply { put("onTimeClose", v.brigadir.onTimeClose); put("noReopen", v.brigadir.noReopen); put("brigadeResult", v.brigadir.brigadeResult) })
            put("quality", JSONObject().apply { put("roundsOnTime", v.quality.roundsOnTime); put("rechecks", v.quality.rechecks); put("onTimeClose", v.quality.onTimeClose); put("dataDiscipline", v.quality.dataDiscipline) })
        }) } })
        put("preparedYears", JSONArray().apply { data.preparedYears.forEach { put(it) } })
        put("workerDays", JSONArray().apply { data.workerDays.forEach { day -> put(JSONObject().apply {
            put("workerId", day.workerId); put("brigadeId", day.brigadeId); put("date", day.date); put("worked", day.worked); put("hours", day.hours); put("updatedAt", day.updatedAt)
            put("entries", JSONArray().apply { day.entries.forEach { e -> put(JSONObject().apply {
                put("id", e.id); put("productId", e.productId); put("articleSnapshot", e.articleSnapshot); put("productNameSnapshot", e.productNameSnapshot); put("quantity", e.quantity); put("unitPriceSnapshot", e.unitPriceSnapshot)
            }) } })
        }) } })
        put("brigadeDays", JSONArray().apply { data.brigadeDays.forEach { day -> put(JSONObject().apply {
            put("brigadeId", day.brigadeId); put("date", day.date); put("worked", day.worked)
            if (day.brigadirClosedAt != null) put("brigadirClosedAt", day.brigadirClosedAt) else put("brigadirClosedAt", JSONObject.NULL)
            put("brigadirLateReason", day.brigadirLateReason)
            if (day.qualityClosedAt != null) put("qualityClosedAt", day.qualityClosedAt) else put("qualityClosedAt", JSONObject.NULL)
            put("qualityLateReason", day.qualityLateReason)
            if (day.closedAt != null) put("closedAt", day.closedAt) else put("closedAt", JSONObject.NULL)
            put("reopenCount", day.reopenCount)
            if (day.lastReopenedAt != null) put("lastReopenedAt", day.lastReopenedAt) else put("lastReopenedAt", JSONObject.NULL)
            put("lastReopenReason", day.lastReopenReason)
        }) } })
        put("qualityRounds", JSONArray().apply { data.qualityRounds.forEach { q -> put(JSONObject().apply {
            put("id", q.id); put("workerId", q.workerId); put("brigadeId", q.brigadeId); put("date", q.date); put("round", q.round); put("scheduledTime", q.scheduledTime)
            if (q.grade != null) put("grade", q.grade) else put("grade", JSONObject.NULL)
            if (q.score != null) put("score", q.score) else put("score", JSONObject.NULL)
            if (q.productId != null) put("productId", q.productId) else put("productId", JSONObject.NULL)
            put("articleSnapshot", q.articleSnapshot); put("productNameSnapshot", q.productNameSnapshot)
            if (q.stageId != null) put("stageId", q.stageId) else put("stageId", JSONObject.NULL)
            put("stageNameSnapshot", q.stageNameSnapshot); put("note", q.note)
            if (q.evaluatedAt != null) put("evaluatedAt", q.evaluatedAt) else put("evaluatedAt", JSONObject.NULL)
            put("missedReason", q.missedReason)
            if (q.missedAt != null) put("missedAt", q.missedAt) else put("missedAt", JSONObject.NULL)
            q.recheck?.let { r -> put("recheck", JSONObject().apply { put("grade", r.grade); put("note", r.note); put("checkedAt", r.checkedAt) }) }
        }) } })
        put("dailyIssues", JSONArray().apply { data.dailyIssues.forEach { issue -> put(JSONObject().apply {
            put("id", issue.id); put("brigadeId", issue.brigadeId); put("date", issue.date); put("productId", issue.productId)
            put("articleSnapshot", issue.articleSnapshot); put("productNameSnapshot", issue.productNameSnapshot)
            put("stageId", issue.stageId); put("stageNameSnapshot", issue.stageNameSnapshot); put("note", issue.note); put("createdAt", issue.createdAt)
        }) } })
        put("auditLog", JSONArray().apply { data.auditLog.takeLast(2000).forEach { a -> put(JSONObject().apply {
            put("id", a.id); put("dateTime", a.dateTime); put("action", a.action)
            if (a.brigadeId != null) put("brigadeId", a.brigadeId) else put("brigadeId", JSONObject.NULL)
            if (a.recordDate != null) put("recordDate", a.recordDate) else put("recordDate", JSONObject.NULL)
            put("details", a.details)
        }) } })
    }

    private fun decode(root: JSONObject): AssemblyData = AssemblyData(
        brigades = root.optJSONArray("brigades").objects().map { Brigade(it.getString("id"), it.getString("name"), it.optBoolean("archived"), it.optBoolean("deleted")) },
        workers = root.optJSONArray("workers").objects().map { Worker(it.getString("id"), it.getString("brigadeId"), it.getString("name"), it.getString("startDate"), it.optBoolean("archived")) },
        products = root.optJSONArray("products").objects().map { p -> Product(
            id = p.getString("id"), brigadeId = p.getString("brigadeId"), article = p.getString("article"), name = p.getString("name"),
            priceHistory = p.optJSONArray("prices").objects().map { PriceVersion(it.getLong("price"), it.getString("effectiveFrom")) },
            stages = decodeStages(p.optJSONArray("stages")), archived = p.optBoolean("archived")
        ) },
        brigadeFk = root.optJSONArray("brigadeFk").objects().map { fk -> BrigadeFkHistory(fk.getString("brigadeId"), fk.optJSONArray("versions").objects().map { LongVersion(it.getLong("value"), it.getString("effectiveFrom")) }) },
        workHours = decodeIntVersions(root.optJSONArray("workHours")),
        efficiencyNorm = decodeIntVersions(root.optJSONArray("efficiencyNorm")),
        roundTimes = root.optJSONArray("roundTimes").objects().map { RoundTimesVersion(it.getString("first"), it.getString("second"), it.getString("third"), it.getString("effectiveFrom")) },
        monitoringWeights = root.optJSONArray("monitoringWeights").objects().map { v ->
            val b = v.getJSONObject("brigadir"); val q = v.getJSONObject("quality")
            MonitoringWeightsVersion(BrigadirWeights(b.getInt("onTimeClose"), b.getInt("noReopen"), b.getInt("brigadeResult")), QualityWeights(q.getInt("roundsOnTime"), q.getInt("rechecks"), q.getInt("onTimeClose"), q.getInt("dataDiscipline")), v.getString("effectiveFrom"))
        },
        preparedYears = root.optJSONArray("preparedYears").ints(),
        workerDays = root.optJSONArray("workerDays").objects().map { d -> WorkerDay(
            workerId = d.getString("workerId"), brigadeId = d.getString("brigadeId"), date = d.getString("date"), worked = d.optBoolean("worked", true), hours = d.optInt("hours", 10),
            entries = d.optJSONArray("entries").objects().map { e -> ProductionEntry(e.getString("id"), e.getString("productId"), e.optString("articleSnapshot"), e.optString("productNameSnapshot"), e.getInt("quantity"), e.getLong("unitPriceSnapshot")) },
            updatedAt = d.optString("updatedAt")
        ) },
        brigadeDays = root.optJSONArray("brigadeDays").objects().map { d -> BrigadeDay(
            brigadeId = d.getString("brigadeId"), date = d.getString("date"), worked = d.optBoolean("worked", true),
            brigadirClosedAt = if (d.isNull("brigadirClosedAt")) null else d.optString("brigadirClosedAt").ifBlank { null },
            brigadirLateReason = d.optString("brigadirLateReason"),
            qualityClosedAt = if (d.isNull("qualityClosedAt")) null else d.optString("qualityClosedAt").ifBlank { null },
            qualityLateReason = d.optString("qualityLateReason"),
            closedAt = if (d.isNull("closedAt")) null else d.optString("closedAt").ifBlank { null },
            reopenCount = d.optInt("reopenCount", 0),
            lastReopenedAt = if (d.isNull("lastReopenedAt")) null else d.optString("lastReopenedAt").ifBlank { null },
            lastReopenReason = d.optString("lastReopenReason")
        ) },
        qualityRounds = root.optJSONArray("qualityRounds").objects().map { q ->
            val recheck = q.optJSONObject("recheck")?.let { QualityRecheck(it.getInt("grade"), it.optString("note"), it.getString("checkedAt")) }
            QualityRoundRecord(
                id = q.getString("id"), workerId = q.getString("workerId"), brigadeId = q.getString("brigadeId"), date = q.getString("date"),
                round = q.getInt("round"), scheduledTime = q.getString("scheduledTime"),
                grade = if (q.isNull("grade")) null else q.getInt("grade"), score = if (q.isNull("score")) null else q.getInt("score"),
                productId = if (q.isNull("productId")) null else q.getString("productId"), articleSnapshot = q.optString("articleSnapshot"), productNameSnapshot = q.optString("productNameSnapshot"),
                stageId = if (q.isNull("stageId")) null else q.getString("stageId"), stageNameSnapshot = q.optString("stageNameSnapshot"), note = q.optString("note"),
                evaluatedAt = if (q.isNull("evaluatedAt")) null else q.optString("evaluatedAt"), missedReason = q.optString("missedReason"),
                missedAt = if (q.isNull("missedAt")) null else q.optString("missedAt"), recheck = recheck
            )
        },
        dailyIssues = root.optJSONArray("dailyIssues").objects().map { issue -> DailyIssueRecord(
            id = issue.getString("id"),
            brigadeId = issue.getString("brigadeId"),
            date = issue.getString("date"),
            productId = issue.getString("productId"),
            articleSnapshot = issue.optString("articleSnapshot"),
            productNameSnapshot = issue.optString("productNameSnapshot"),
            stageId = issue.getString("stageId"),
            stageNameSnapshot = issue.optString("stageNameSnapshot"),
            note = issue.optString("note"),
            createdAt = issue.optString("createdAt")
        ) },
        auditLog = root.optJSONArray("auditLog").objects().map { a -> AuditEntry(
            id = a.optString("id", UUID.randomUUID().toString()),
            dateTime = a.optString("dateTime"), action = a.optString("action"),
            brigadeId = if (a.isNull("brigadeId")) null else a.optString("brigadeId").ifBlank { null },
            recordDate = if (a.isNull("recordDate")) null else a.optString("recordDate").ifBlank { null },
            details = a.optString("details")
        ) }
    ).let { data ->
        data.copy(
            workHours = data.workHours.ifEmpty { listOf(IntVersion(10, "2000-01-01")) },
            efficiencyNorm = data.efficiencyNorm.ifEmpty { listOf(IntVersion(85, "2000-01-01")) },
            roundTimes = data.roundTimes.ifEmpty { listOf(RoundTimesVersion("10:00", "13:00", "16:00", "2000-01-01")) },
            monitoringWeights = data.monitoringWeights.ifEmpty { listOf(MonitoringWeightsVersion(BrigadirWeights(), QualityWeights(), "2000-01-01")) }
        )
    }

    private fun decodeStages(array: JSONArray?): List<ProductStage> {
        if (array == null) return emptyList()
        return buildList {
            for (i in 0 until array.length()) {
                when (val item = array.get(i)) {
                    is JSONObject -> add(ProductStage(item.optString("id", UUID.randomUUID().toString()), item.optString("name"), item.optBoolean("archived")))
                    is String -> add(ProductStage(UUID.randomUUID().toString(), item))
                }
            }
        }
    }

    private fun encodeIntVersions(values: List<IntVersion>) = JSONArray().apply { values.forEach { put(JSONObject().apply { put("value", it.value); put("effectiveFrom", it.effectiveFrom) }) } }
    private fun decodeIntVersions(array: JSONArray?): List<IntVersion> = array.objects().map { IntVersion(it.getInt("value"), it.getString("effectiveFrom")) }

    companion object {
        private const val PREFS_NAME = "toy_bola_assembly_data"
        private const val KEY_DATA = "assembly_data_v2"
    }
}

private fun JSONArray?.objects(): List<JSONObject> {
    if (this == null) return emptyList()
    return buildList { for (i in 0 until length()) add(getJSONObject(i)) }
}

private fun JSONArray?.ints(): List<Int> {
    if (this == null) return emptyList()
    return buildList { for (i in 0 until length()) add(getInt(i)) }
}
