package uz.toybola.factory.core.data

import java.time.LocalDate

/**
 * Monitoring summary metrics are intentionally calculated from closed historical day records.
 * This keeps incomplete days from producing misleading percentages and keeps "Ishlamadi" days
 * out of averages instead of treating them as 0%.
 */
enum class MonitoringMetricKind { WORKERS, BRIGADIRS, QUALITY, ISSUES }

enum class MonitoringMetricState { VALUE, NO_DATA, INCOMPLETE, NOT_WORKED }

data class MonitoringMetric(
    val state: MonitoringMetricState,
    val percentage: Double? = null,
    val count: Int? = null
) {
    companion object {
        fun percentage(value: Double) = MonitoringMetric(MonitoringMetricState.VALUE, percentage = value)
        fun count(value: Int) = MonitoringMetric(MonitoringMetricState.VALUE, count = value)
        val noData = MonitoringMetric(MonitoringMetricState.NO_DATA)
        val incomplete = MonitoringMetric(MonitoringMetricState.INCOMPLETE)
        val notWorked = MonitoringMetric(MonitoringMetricState.NOT_WORKED)
    }
}

fun AssemblyData.monitoringMetric(
    kind: MonitoringMetricKind,
    start: LocalDate,
    endInclusive: LocalDate,
    brigadeId: String = ""
): MonitoringMetric {
    require(!endInclusive.isBefore(start))

    if (kind == MonitoringMetricKind.ISSUES) {
        val count = dailyIssues.count { issue ->
            val date = runCatching { LocalDate.parse(issue.date) }.getOrNull() ?: return@count false
            !date.isBefore(start) && !date.isAfter(endInclusive) &&
                (brigadeId.isBlank() || issue.brigadeId == brigadeId)
        }
        return MonitoringMetric.count(count)
    }

    val values = mutableListOf<Double>()
    var sawNotWorked = false
    var date = start
    while (!date.isAfter(endInclusive)) {
        val metric = monitoringDayMetric(kind, date, brigadeId)
        when (metric.state) {
            MonitoringMetricState.VALUE -> metric.percentage?.let(values::add)
            MonitoringMetricState.INCOMPLETE -> return MonitoringMetric.incomplete
            MonitoringMetricState.NOT_WORKED -> sawNotWorked = true
            MonitoringMetricState.NO_DATA -> Unit
        }
        date = date.plusDays(1)
    }

    return when {
        values.isNotEmpty() -> MonitoringMetric.percentage(values.average())
        sawNotWorked -> MonitoringMetric.notWorked
        else -> MonitoringMetric.noData
    }
}

private fun AssemblyData.monitoringDayMetric(
    kind: MonitoringMetricKind,
    date: LocalDate,
    brigadeId: String
): MonitoringMetric {
    val dateIso = date.toString()
    val selectedBrigades = brigades.filter { !it.archived && !it.deleted && (brigadeId.isBlank() || it.id == brigadeId) }
    if (selectedBrigades.isEmpty()) return MonitoringMetric.noData

    val operational = selectedBrigades.filter { hasOperationalActivity(it.id, dateIso) }
    if (operational.isEmpty()) return MonitoringMetric.noData

    val worked = operational.filter { brigadeDay(it.id, dateIso)?.worked != false }
    if (worked.isEmpty()) return MonitoringMetric.notWorked

    return when (kind) {
        MonitoringMetricKind.WORKERS -> workerDayMetric(worked, dateIso)
        MonitoringMetricKind.BRIGADIRS -> brigadirDayMetric(worked, dateIso)
        MonitoringMetricKind.QUALITY -> qualityStaffDayMetric(worked, dateIso)
        MonitoringMetricKind.ISSUES -> error("Issues are calculated directly")
    }
}

private fun AssemblyData.workerDayMetric(brigades: List<Brigade>, date: String): MonitoringMetric {
    val finals = mutableListOf<Double>()
    for (brigade in brigades) {
        val day = brigadeDay(brigade.id, date) ?: return MonitoringMetric.incomplete
        if (!day.fullyClosed) return MonitoringMetric.incomplete
        val workedDays = workerDays.filter { it.brigadeId == brigade.id && it.date == date && it.worked }
        if (workedDays.isEmpty()) return MonitoringMetric.incomplete
        for (workerDay in workedDays) {
            val result = workerFinalResult(workerDay.workerId, date) ?: return MonitoringMetric.incomplete
            finals += result
        }
    }
    return finals.takeIf { it.isNotEmpty() }?.average()?.let(MonitoringMetric::percentage)
        ?: MonitoringMetric.noData
}

private fun AssemblyData.brigadirDayMetric(brigades: List<Brigade>, date: String): MonitoringMetric {
    val scores = mutableListOf<Double>()
    for (brigade in brigades) {
        val day = brigadeDay(brigade.id, date) ?: return MonitoringMetric.incomplete
        if (!day.fullyClosed) return MonitoringMetric.incomplete
        val workerResults = workerDays
            .filter { it.brigadeId == brigade.id && it.date == date && it.worked }
            .map { workerFinalResult(it.workerId, date) ?: return MonitoringMetric.incomplete }
        if (workerResults.isEmpty()) return MonitoringMetric.incomplete

        val weights = monitoringWeightsAt(date).brigadir
        val onTime = if (day.brigadirClosedOnTime()) 100.0 else 0.0
        val noReopen = if (day.reopenCount == 0) 100.0 else 0.0
        val brigadeResult = workerResults.average()
        scores += onTime * weights.onTimeClose / 100.0 +
            noReopen * weights.noReopen / 100.0 +
            brigadeResult * weights.brigadeResult / 100.0
    }
    return scores.takeIf { it.isNotEmpty() }?.average()?.let(MonitoringMetric::percentage)
        ?: MonitoringMetric.noData
}

private fun AssemblyData.qualityStaffDayMetric(brigades: List<Brigade>, date: String): MonitoringMetric {
    val scores = mutableListOf<Double>()
    for (brigade in brigades) {
        val day = brigadeDay(brigade.id, date) ?: return MonitoringMetric.incomplete
        if (!day.qualityClosed) return MonitoringMetric.incomplete

        val workedWorkerIds = workerDays
            .filter { it.brigadeId == brigade.id && it.date == date && it.worked }
            .map { it.workerId }
            .distinct()
        if (workedWorkerIds.isEmpty()) return MonitoringMetric.incomplete

        val expectedRounds = workedWorkerIds.size * 3
        val rounds = qualityRounds.filter { it.brigadeId == brigade.id && it.date == date && it.workerId in workedWorkerIds }
        if (rounds.size < expectedRounds || rounds.any { !it.isFinished || !it.recheckComplete }) {
            return MonitoringMetric.incomplete
        }

        val roundsOnTime = rounds.count { it.isEvaluated } * 100.0 / expectedRounds
        val recheckRequired = rounds.filter { it.needsRecheck }
        val rechecks = if (recheckRequired.isEmpty()) 100.0
        else recheckRequired.count { it.recheck != null } * 100.0 / recheckRequired.size
        val onTimeClose = if (day.qualityClosedOnTime()) 100.0 else 0.0
        val dataDiscipline = rounds.count { it.isFinished && it.recheckComplete } * 100.0 / expectedRounds
        val weights = monitoringWeightsAt(date).quality

        scores += roundsOnTime * weights.roundsOnTime / 100.0 +
            rechecks * weights.rechecks / 100.0 +
            onTimeClose * weights.onTimeClose / 100.0 +
            dataDiscipline * weights.dataDiscipline / 100.0
    }
    return scores.takeIf { it.isNotEmpty() }?.average()?.let(MonitoringMetric::percentage)
        ?: MonitoringMetric.noData
}

private fun AssemblyData.hasOperationalActivity(brigadeId: String, date: String): Boolean =
    brigadeDays.any { it.brigadeId == brigadeId && it.date == date } ||
        workerDays.any { it.brigadeId == brigadeId && it.date == date } ||
        qualityRounds.any { it.brigadeId == brigadeId && it.date == date }
