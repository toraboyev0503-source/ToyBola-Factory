package uz.toybola.factory.core.security

import uz.toybola.factory.ui.model.AppScreen

/**
 * Server-ready access-control model.
 *
 * 0.7.3 uses [UserAccessPolicy.localFullAccess] so the current offline test remains unchanged.
 * When the backend is connected, this object will be replaced by the authenticated user's
 * server-issued policy. Firestore/Backend rules MUST enforce the same policy server-side;
 * client-side hiding alone is never considered security.
 */
enum class AssemblySection {
    BRIGADIR,
    QUALITY,
    DAILY_ISSUE,
    MONITORING,
    MASTER_DATA
}

data class SectionAccess(
    val canRead: Boolean = false,
    val canWrite: Boolean = false
)

data class UserAccessPolicy(
    val userCode: String,
    /** null = all brigades; otherwise only listed brigade IDs are in scope. */
    val allowedBrigadeIds: Set<String>? = null,
    val sections: Map<AssemblySection, SectionAccess> = emptyMap(),
    /** Useful later for invalidating stale policies after admin changes. */
    val revision: Long = 0L,
    val source: String = "local"
) {
    fun canRead(section: AssemblySection): Boolean = sections[section]?.canRead == true
    fun canWrite(section: AssemblySection): Boolean = sections[section]?.canWrite == true
    fun canAccessBrigade(brigadeId: String): Boolean = allowedBrigadeIds?.contains(brigadeId) ?: true

    companion object {
        fun localFullAccess(userCode: String): UserAccessPolicy = UserAccessPolicy(
            userCode = userCode,
            allowedBrigadeIds = null,
            sections = AssemblySection.entries.associateWith { SectionAccess(canRead = true, canWrite = true) },
            revision = 0L,
            source = "local-test-default"
        )
    }
}

fun AppScreen.toAssemblySectionOrNull(): AssemblySection? = when (this) {
    AppScreen.BRIGADIR -> AssemblySection.BRIGADIR
    AppScreen.QUALITY -> AssemblySection.QUALITY
    AppScreen.DAILY_ISSUE -> AssemblySection.DAILY_ISSUE
    AppScreen.MONITORING -> AssemblySection.MONITORING
    AppScreen.MASTER_DATA -> AssemblySection.MASTER_DATA
    else -> null
}

fun UserAccessPolicy.canReadScreen(screen: AppScreen): Boolean =
    screen.toAssemblySectionOrNull()?.let(::canRead) ?: true
