# Toy Bola Factory Management System

Android/Kotlin/Jetpack Compose zavod boshqaruv tizimi.

## 0.8.0 — Firebase server pilot

0.8.0 avvalgi 0.7.3 lokal Sborka funksiyalarini saqlaydi va Firebase server qatlamini qo‘shadi:

- Firebase Custom Authentication: Qurilma kodi + Foydalanuvchi kodi serverda tekshiriladi; Android telefon qulfi lokal himoya bo‘lib qoladi.
- Cloud Firestore multi-device sinxronlash + Android lokal/offline ish.
- Persistent sync outbox: lokal o‘zgarishlar internet qaytganda Firestore'ga uzatiladi.
- Server access policy: Admin / Rahbar / Brigadir / Sifat, brigada scope va bo‘limlar bo‘yicha read/write.
- Firestore Security Rules server permissionlarini majburiy tekshiradi.
- Brigadir va Sifat bir xil kun hujjatining faqat o‘ziga tegishli maydonlarini yozishi mumkin.
- Firebase Cloud Messaging: kun yopilishi/deadline/muammo summary server xabarlari.
- Lokal vaqtli bildirishnomalar internet bo‘lmasa ham ishlaydi va joriy foydalanuvchi roliga mos rejalashtiriladi.
- Cloud Functions 2nd gen: europe-west1, maxInstances=10, maxsus least-privilege runtime service account.
- GitHub Actions: Android test/lint/APK + WIF orqali Firebase Rules/Functions deploy.
- Bir martalik Admin bootstrap va pilot user provision workflow'lari.
- 0.7.3 dagi lokal ma’lumotlar ilk Admin loginidan keyin serverga seed qilinadi.

## Server loyihasi

- Firebase / Google Cloud project: `toybola-factory`
- Android package: `uz.toybola.factory`
- Functions region: `europe-west1`
- Firestore: `(default)`

## Muhim xavfsizlik qarorlari

- Service-account private JSON key GitHub'ga saqlanmaydi; GitHub Actions Workload Identity Federation ishlatadi.
- Telefonning PIN/pattern/password qiymati Android ilovaga ham, Firebase serverga ham berilmaydi; system device credential prompt ishlatiladi.
- `loginCodes` kolleksiyasida qurilma kodi ochiq matnda emas, SHA-256 hash ko‘rinishida saqlanadi.
- App Check enforcement pilot debug APK sinovidan keyin Play Integrity bilan yoqiladi.

## Birinchi deploy

1. `docs/SERVER_RUNTIME_SETUP.txt` dagi Cloud Shell blokini bir marta bajarish.
2. GitHub root'iga `ToyBola_Factory_Source_0.8.0.zip` va yangi `.github/workflows/main.yml`ni qo‘yish.
3. GitHub Secrets'ga bir martalik bosh Adminning joriy User code va Device code qiymatlarini kiritish.
4. Push build/deploy yashil bo‘lgach workflow_dispatch orqali `bootstrap_admin=true` ishlatish.
5. 0.8.0 APKni o‘rnatish va Admin kodi bilan kirish; so‘ng 1–2 pilot user provision qilish.
