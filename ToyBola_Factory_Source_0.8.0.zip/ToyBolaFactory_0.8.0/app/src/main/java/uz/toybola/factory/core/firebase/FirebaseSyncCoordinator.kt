package uz.toybola.factory.core.firebase

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import uz.toybola.factory.core.data.*
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.core.notifications.NotificationScheduler
import uz.toybola.factory.core.security.UserAccessPolicy

class FirebaseSyncCoordinator(context: Context) {
    private val appContext = context.applicationContext
    private val repository = AssemblyDataRepository(appContext)
    private val outbox = AssemblySyncOutbox(appContext)
    private val policyCache = ServerPolicyCache(appContext)
    private val preferences = AppPreferences(appContext)
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    suspend fun syncNow(): Result<Unit> = runCatching {
        val user = auth.currentUser ?: return@runCatching
        val setup = preferences.setup() ?: error("Qurilma sozlamasi topilmadi")
        val cachedBefore = policyCache.load(setup.userCode)
        val policy = ServerAuthRepository(appContext).refreshPolicy().getOrNull()
            ?: cachedBefore
            ?: error("Server ruxsati topilmadi")
        if (cachedBefore != null && policy.revision != cachedBefore.revision) ServerPolicyEvents.notifyChanged()
        require(policy.uid.isBlank() || policy.uid == user.uid) { "Server sessiyasi boshqa foydalanuvchiga tegishli" }

        flushOutbox(policy, user.uid)
        val remote = pullRemote(policy)
        val merged = mergeIntoLocal(repository.load(), remote.data, remote.hasSettings, policy)
        repository.replaceFromServer(merged)
        NotificationScheduler.scheduleUpcoming(appContext, repository)
    }

    private suspend fun flushOutbox(policy: UserAccessPolicy, uid: String) {
        val keys = outbox.pending().sorted()
        if (keys.isEmpty()) return
        val local = repository.load()
        keys.chunked(350).forEach { chunk ->
            val batch = db.batch()
            val applied = mutableListOf<String>()
            chunk.forEach { key ->
                if (applyOutboxKey(batch, key, local, uid)) applied += key
                else applied += key // stale/no-op keys are safe to discard
            }
            if (applied.isNotEmpty()) {
                batch.commit().awaitResult()
                applied.forEach(outbox::remove)
            }
        }
    }

    private fun applyOutboxKey(
        batch: com.google.firebase.firestore.WriteBatch,
        key: String,
        data: AssemblyData,
        uid: String
    ): Boolean {
        val prefix = key.substringBefore(':')
        val id = key.substringAfter(':', "")
        fun common(payload: String, brigadeId: String? = null, date: String? = null): MutableMap<String, Any> = mutableMapOf<String, Any>(
            "payload" to payload,
            "updatedAt" to FieldValue.serverTimestamp(),
            "updatedBy" to uid
        ).apply {
            brigadeId?.let { put("brigadeId", it) }
            date?.let { put("date", it) }
        }

        when (prefix) {
            "BRIGADE" -> {
                val item = data.brigades.firstOrNull { it.id == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(brigades = listOf(item)))
                batch.set(db.collection("brigades").document(item.id), common(payload, item.id).apply {
                    put("name", item.name); put("archived", item.archived); put("deleted", item.deleted)
                }, SetOptions.merge())
            }
            "WORKER" -> {
                val item = data.workers.firstOrNull { it.id == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(workers = listOf(item)))
                batch.set(db.collection("workers").document(item.id), common(payload, item.brigadeId).apply {
                    put("name", item.name); put("archived", item.archived); put("startDate", item.startDate)
                }, SetOptions.merge())
            }
            "PRODUCT" -> {
                val item = data.products.firstOrNull { it.id == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(products = listOf(item)))
                batch.set(db.collection("products").document(item.id), common(payload, item.brigadeId).apply {
                    put("article", item.article); put("name", item.name); put("archived", item.archived)
                }, SetOptions.merge())
            }
            "BRIGADE_FK" -> {
                val item = data.brigadeFk.firstOrNull { it.brigadeId == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(brigadeFk = listOf(item)))
                batch.set(db.collection("brigadeFk").document(item.brigadeId), common(payload, item.brigadeId), SetOptions.merge())
            }
            "WORKER_DAY" -> {
                val parts = id.split('|')
                if (parts.size != 2) return false
                val item = data.workerDays.firstOrNull { it.workerId == parts[0] && it.date == parts[1] } ?: return false
                val payload = repository.encodeForSync(AssemblyData(workerDays = listOf(item)))
                batch.set(db.collection("workerDays").document("${item.workerId}_${item.date}"), common(payload, item.brigadeId, item.date).apply {
                    put("workerId", item.workerId); put("worked", item.worked); put("hours", item.hours); put("earned", item.earned)
                }, SetOptions.merge())
            }
            "BRIGADE_DAY" -> {
                val parts = id.split('|')
                if (parts.size != 2) return false
                val item = data.brigadeDays.firstOrNull { it.brigadeId == parts[0] && it.date == parts[1] } ?: return false
                // BrigadeDay is intentionally stored as structured fields instead of an opaque payload.
                // This lets Firestore Security Rules enforce Brigadir-vs-Quality field ownership.
                val document = mutableMapOf<String, Any>(
                    "brigadeId" to item.brigadeId,
                    "date" to item.date,
                    "worked" to item.worked,
                    "brigadirClosed" to item.brigadirClosed,
                    "brigadirClosedAt" to item.brigadirClosedAt.orEmpty(),
                    "brigadirLateReason" to item.brigadirLateReason,
                    "qualityClosed" to item.qualityClosed,
                    "qualityClosedAt" to item.qualityClosedAt.orEmpty(),
                    "qualityLateReason" to item.qualityLateReason,
                    "fullyClosed" to item.fullyClosed,
                    "closedAt" to item.closedAt.orEmpty(),
                    "reopenCount" to item.reopenCount,
                    "lastReopenedAt" to item.lastReopenedAt.orEmpty(),
                    "lastReopenReason" to item.lastReopenReason,
                    "updatedAt" to FieldValue.serverTimestamp(),
                    "updatedBy" to uid
                )
                batch.set(db.collection("brigadeDays").document("${item.brigadeId}_${item.date}"), document, SetOptions.merge())
            }
            "QUALITY_ROUND" -> {
                val parts = id.split('|')
                if (parts.size != 3) return false
                val item = data.qualityRounds.firstOrNull { it.workerId == parts[0] && it.date == parts[1] && it.round == parts[2].toIntOrNull() } ?: return false
                val payload = repository.encodeForSync(AssemblyData(qualityRounds = listOf(item)))
                batch.set(db.collection("qualityRounds").document("${item.workerId}_${item.date}_${item.round}"), common(payload, item.brigadeId, item.date).apply {
                    put("workerId", item.workerId); put("round", item.round); put("finished", item.isFinished); item.grade?.let { put("grade", it) }
                }, SetOptions.merge())
            }
            "DAILY_ISSUE" -> {
                val item = data.dailyIssues.firstOrNull { it.id == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(dailyIssues = listOf(item)))
                batch.set(db.collection("dailyIssues").document(item.id), common(payload, item.brigadeId, item.date).apply {
                    put("productId", item.productId); put("article", item.articleSnapshot); put("productName", item.productNameSnapshot)
                    put("stageId", item.stageId); put("stageName", item.stageNameSnapshot); put("note", item.note); put("createdAtText", item.createdAt)
                }, SetOptions.merge())
            }
            "DAILY_ISSUE_DELETE" -> batch.delete(db.collection("dailyIssues").document(id))
            "AUDIT" -> {
                val item = data.auditLog.firstOrNull { it.id == id } ?: return false
                val payload = repository.encodeForSync(AssemblyData(auditLog = listOf(item)))
                batch.set(db.collection("auditLog").document(item.id), common(payload, item.brigadeId, item.recordDate).apply {
                    put("action", item.action); put("dateTime", item.dateTime); put("details", item.details)
                }, SetOptions.merge())
            }
            "SETTINGS" -> {
                val payload = repository.encodeForSync(AssemblyData(
                    workHours = data.workHours,
                    efficiencyNorm = data.efficiencyNorm,
                    roundTimes = data.roundTimes,
                    monitoringWeights = data.monitoringWeights,
                    preparedYears = data.preparedYears
                ))
                batch.set(db.collection("settings").document("assembly"), common(payload), SetOptions.merge())
            }
            else -> return false
        }
        return true
    }

    private data class Pulled(val data: AssemblyData, val hasSettings: Boolean)

    private suspend fun pullRemote(policy: UserAccessPolicy): Pulled {
        val brigadeDocs = if (policy.allowedBrigadeIds == null) {
            db.collection("brigades").get().awaitResult().documents
        } else {
            policy.allowedBrigadeIds.mapNotNull { db.collection("brigades").document(it).get().awaitResult().takeIf(DocumentSnapshot::exists) }
        }
        val brigades = decodeDocs(brigadeDocs) { it.brigades }
        val workers = decodeScoped("workers", policy) { it.workers }
        val products = decodeScoped("products", policy) { it.products }
        val fk = decodeScoped("brigadeFk", policy) { it.brigadeFk }
        val workerDays = decodeScoped("workerDays", policy) { it.workerDays }
        val brigadeDays = pullBrigadeDays(policy)
        val qualityRounds = decodeScoped("qualityRounds", policy) { it.qualityRounds }
        val dailyIssues = decodeScoped("dailyIssues", policy) { it.dailyIssues }
        val audit = if (policy.isAdmin()) {
            val docs = db.collection("auditLog").limit(1000).get().awaitResult().documents
            decodeDocs(docs) { it.auditLog }
        } else {
            decodeScoped("auditLog", policy) { it.auditLog }
        }
        val settingsDoc = db.collection("settings").document("assembly").get().awaitResult()
        val settings = if (settingsDoc.exists()) decodePayload(settingsDoc) else null

        return Pulled(
            AssemblyData(
                brigades = brigades,
                workers = workers,
                products = products,
                brigadeFk = fk,
                workHours = settings?.workHours.orEmpty(),
                efficiencyNorm = settings?.efficiencyNorm.orEmpty(),
                roundTimes = settings?.roundTimes.orEmpty(),
                monitoringWeights = settings?.monitoringWeights.orEmpty(),
                preparedYears = settings?.preparedYears.orEmpty(),
                workerDays = workerDays,
                brigadeDays = brigadeDays,
                qualityRounds = qualityRounds,
                dailyIssues = dailyIssues,
                auditLog = audit
            ),
            settingsDoc.exists()
        )
    }


    private suspend fun pullBrigadeDays(policy: UserAccessPolicy): List<BrigadeDay> {
        val docs = if (policy.allowedBrigadeIds == null) {
            db.collection("brigadeDays").get().awaitResult().documents
        } else {
            buildList {
                policy.allowedBrigadeIds.forEach { brigadeId ->
                    addAll(db.collection("brigadeDays").whereEqualTo("brigadeId", brigadeId).get().awaitResult().documents)
                }
            }
        }
        return docs.mapNotNull { doc ->
            val brigadeId = doc.getString("brigadeId") ?: return@mapNotNull null
            val date = doc.getString("date") ?: return@mapNotNull null
            BrigadeDay(
                brigadeId = brigadeId,
                date = date,
                worked = doc.getBoolean("worked") ?: true,
                brigadirClosedAt = doc.getString("brigadirClosedAt")?.ifBlank { null },
                brigadirLateReason = doc.getString("brigadirLateReason").orEmpty(),
                qualityClosedAt = doc.getString("qualityClosedAt")?.ifBlank { null },
                qualityLateReason = doc.getString("qualityLateReason").orEmpty(),
                closedAt = doc.getString("closedAt")?.ifBlank { null },
                reopenCount = (doc.getLong("reopenCount") ?: 0L).toInt(),
                lastReopenedAt = doc.getString("lastReopenedAt")?.ifBlank { null },
                lastReopenReason = doc.getString("lastReopenReason").orEmpty()
            )
        }
    }

    private suspend fun <T> decodeScoped(collection: String, policy: UserAccessPolicy, extract: (AssemblyData) -> List<T>): List<T> {
        val docs = if (policy.allowedBrigadeIds == null) {
            db.collection(collection).get().awaitResult().documents
        } else {
            buildList {
                policy.allowedBrigadeIds.forEach { brigadeId ->
                    addAll(db.collection(collection).whereEqualTo("brigadeId", brigadeId).get().awaitResult().documents)
                }
            }
        }
        return decodeDocs(docs, extract)
    }

    private fun <T> decodeDocs(docs: List<DocumentSnapshot>, extract: (AssemblyData) -> List<T>): List<T> =
        docs.mapNotNull(::decodePayload).flatMap(extract)

    private fun decodePayload(doc: DocumentSnapshot): AssemblyData? {
        val payload = doc.getString("payload") ?: return null
        return runCatching { repository.decodeForSync(payload) }.getOrNull()
    }

    private fun mergeIntoLocal(local: AssemblyData, remote: AssemblyData, hasSettings: Boolean, policy: UserAccessPolicy): AssemblyData {
        return local.copy(
            brigades = remote.brigades.distinctBy { it.id },
            workers = remote.workers.distinctBy { it.id },
            products = remote.products.distinctBy { it.id },
            brigadeFk = remote.brigadeFk.distinctBy { it.brigadeId },
            workHours = if (hasSettings) remote.workHours.ifEmpty { local.workHours } else local.workHours,
            efficiencyNorm = if (hasSettings) remote.efficiencyNorm.ifEmpty { local.efficiencyNorm } else local.efficiencyNorm,
            roundTimes = if (hasSettings) remote.roundTimes.ifEmpty { local.roundTimes } else local.roundTimes,
            monitoringWeights = if (hasSettings) remote.monitoringWeights.ifEmpty { local.monitoringWeights } else local.monitoringWeights,
            preparedYears = if (hasSettings) remote.preparedYears else local.preparedYears,
            workerDays = remote.workerDays.distinctBy { "${it.workerId}|${it.date}" },
            brigadeDays = remote.brigadeDays.distinctBy { "${it.brigadeId}|${it.date}" },
            qualityRounds = remote.qualityRounds.distinctBy { "${it.workerId}|${it.date}|${it.round}" },
            dailyIssues = remote.dailyIssues.distinctBy { it.id },
            auditLog = remote.auditLog.distinctBy { it.id }.takeLast(2000)
        )
    }
}
