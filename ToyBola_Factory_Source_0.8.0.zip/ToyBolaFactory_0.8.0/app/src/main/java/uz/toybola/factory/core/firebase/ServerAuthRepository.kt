package uz.toybola.factory.core.firebase

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.messaging.FirebaseMessaging
import uz.toybola.factory.core.preferences.AppPreferences
import uz.toybola.factory.core.security.AssemblySection
import uz.toybola.factory.core.security.SectionAccess
import uz.toybola.factory.core.security.UserAccessPolicy
import java.util.Locale
import java.util.UUID

class ServerAuthRepository(context: Context) {
    private val appContext = context.applicationContext
    private val auth = FirebaseAuth.getInstance()
    private val functions = FirebaseFunctions.getInstance("europe-west1")
    private val policyCache = ServerPolicyCache(appContext)
    private val preferences = AppPreferences(appContext)
    private val deviceIdentity = ServerDeviceIdentity(appContext)

    suspend fun signInWithCodes(deviceCode: String, userCode: String, allowOfflineFallback: Boolean): Result<UserAccessPolicy> = runCatching {
        val normalizedDevice = deviceCode.trim().uppercase(Locale.ROOT)
        val normalizedUser = userCode.trim().uppercase(Locale.ROOT)
        require(normalizedDevice.isNotBlank() && normalizedUser.isNotBlank()) { "Qurilma va foydalanuvchi kodini kiriting" }

        if (allowOfflineFallback) {
            val setup = preferences.setup()
            val localCodesMatch = setup != null &&
                setup.deviceCode.equals(normalizedDevice, true) &&
                setup.userCode.equals(normalizedUser, true)
            val cached = policyCache.load(normalizedUser)
            if (localCodesMatch && auth.currentUser != null && cached != null) return@runCatching cached
        }

        try {
            val result = functions.getHttpsCallable("loginWithCodes")
                .call(mapOf(
                    "deviceCode" to normalizedDevice,
                    "userCode" to normalizedUser,
                    "installId" to deviceIdentity.installId()
                ))
                .awaitResult()
            val root = result.data as? Map<*, *> ?: error("Server javobi noto‘g‘ri")
            val token = root["token"] as? String ?: error("Kirish tokeni olinmadi")
            auth.signInWithCustomToken(token).awaitResult()
            val policy = parsePolicy(root["policy"] as? Map<*, *> ?: emptyMap<Any, Any>(), normalizedUser)
            policyCache.save(policy)
            registerFcmTokenBestEffort()
            policy
        } catch (error: Exception) {
            if (!allowOfflineFallback) throw error
            val setup = preferences.setup()
            val localCodesMatch = setup != null &&
                setup.deviceCode.equals(normalizedDevice, true) &&
                setup.userCode.equals(normalizedUser, true)
            val cached = policyCache.load(normalizedUser)
            if (localCodesMatch && auth.currentUser != null && cached != null) cached
            else throw error
        }
    }

    fun cachedPolicy(userCode: String): UserAccessPolicy? = policyCache.load(userCode)

    suspend fun refreshPolicy(): Result<UserAccessPolicy> = runCatching {
        val user = auth.currentUser ?: error("Server sessiyasi mavjud emas")
        val result = functions.getHttpsCallable("getMyPolicy").call().awaitResult()
        val root = result.data as? Map<*, *> ?: error("Server javobi noto‘g‘ri")
        val policy = parsePolicy(root, root["userCode"]?.toString().orEmpty())
            .copy(uid = user.uid)
        policyCache.save(policy)
        policy
    }

    fun hasFirebaseSession(): Boolean = auth.currentUser != null

    private suspend fun registerFcmTokenBestEffort() {
        runCatching {
            val token = FirebaseMessaging.getInstance().token.awaitResult()
            functions.getHttpsCallable("registerFcmToken")
                .call(mapOf("installId" to deviceIdentity.installId(), "token" to token))
                .awaitResult()
        }
    }

    private fun parsePolicy(raw: Map<*, *>, fallbackUserCode: String): UserAccessPolicy {
        val permissions = (raw["permissions"] as? Map<*, *>) ?: emptyMap<Any, Any>()
        fun permission(key: String): Boolean = permissions[key] as? Boolean == true
        val sections = mapOf(
            AssemblySection.BRIGADIR to SectionAccess(permission("BRIGADIR_READ"), permission("BRIGADIR_WRITE")),
            AssemblySection.QUALITY to SectionAccess(permission("QUALITY_READ"), permission("QUALITY_WRITE")),
            AssemblySection.DAILY_ISSUE to SectionAccess(permission("DAILY_ISSUE_READ"), permission("DAILY_ISSUE_WRITE")),
            AssemblySection.MONITORING to SectionAccess(permission("MONITORING_READ"), false),
            AssemblySection.MASTER_DATA to SectionAccess(permission("MASTER_DATA_READ"), permission("MASTER_DATA_WRITE"))
        )
        val allBrigades = raw["allBrigades"] as? Boolean == true
        val brigadeIds = if (allBrigades) null else (raw["allowedBrigadeIds"] as? List<*>)
            .orEmpty().mapNotNull { it?.toString()?.takeIf(String::isNotBlank) }.toSet()
        val notifications = (raw["notifications"] as? List<*>)
            .orEmpty().mapNotNull { it?.toString()?.takeIf(String::isNotBlank) }.toSet()
        return UserAccessPolicy(
            uid = raw["uid"]?.toString().orEmpty(),
            userCode = raw["userCode"]?.toString()?.ifBlank { fallbackUserCode } ?: fallbackUserCode,
            displayName = raw["displayName"]?.toString().orEmpty(),
            role = raw["role"]?.toString().orEmpty(),
            allowedBrigadeIds = brigadeIds,
            sections = sections,
            notificationKeys = notifications,
            revision = (raw["revision"] as? Number)?.toLong() ?: 0L,
            source = "server"
        )
    }
}

private class ServerDeviceIdentity(context: Context) {
    private val prefs = context.getSharedPreferences("toy_bola_server_device", Context.MODE_PRIVATE)
    fun installId(): String {
        val existing = prefs.getString("install_id", null)
        if (!existing.isNullOrBlank()) return existing
        val created = UUID.randomUUID().toString()
        prefs.edit().putString("install_id", created).apply()
        return created
    }
}
