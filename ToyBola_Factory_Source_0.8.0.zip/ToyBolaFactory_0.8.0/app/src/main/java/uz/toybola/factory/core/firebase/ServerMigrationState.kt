package uz.toybola.factory.core.firebase

import android.content.Context

class ServerMigrationState(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("toy_bola_server_migration", Context.MODE_PRIVATE)
    fun wasSeedScheduled(uid: String): Boolean = prefs.getBoolean("seed_$uid", false)
    fun markSeedScheduled(uid: String) = prefs.edit().putBoolean("seed_$uid", true).apply()
}
