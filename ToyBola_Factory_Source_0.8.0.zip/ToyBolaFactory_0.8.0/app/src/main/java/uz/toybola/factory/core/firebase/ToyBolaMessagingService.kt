package uz.toybola.factory.core.firebase

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import uz.toybola.factory.MainActivity
import uz.toybola.factory.R
import uz.toybola.factory.core.notifications.NotificationInboxRepository
import uz.toybola.factory.core.notifications.NotificationReceiver
import java.util.UUID

class ToyBolaMessagingService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        val title = message.notification?.title ?: message.data["title"] ?: "Toy Bola"
        val body = message.notification?.body ?: message.data["body"] ?: return
        val route = message.data["route"] ?: "MONITORING"
        val key = message.data["key"] ?: "server-${message.messageId ?: UUID.randomUUID()}"
        NotificationInboxRepository(applicationContext).addOrUpdate(key, title, body, route)
        showNotification(key, title, body, route)
        if (message.data["type"] == "POLICY_CHANGED") {
            ServerPolicyEvents.notifyChanged()
            FirebaseSyncScheduler.enqueue(applicationContext)
        }
    }

    override fun onNewToken(token: String) {
        if (FirebaseAuth.getInstance().currentUser == null) return
        val installId = getSharedPreferences("toy_bola_server_device", MODE_PRIVATE)
            .getString("install_id", "").orEmpty()
        if (installId.isBlank()) return
        FirebaseFunctions.getInstance("europe-west1")
            .getHttpsCallable("registerFcmToken")
            .call(mapOf("installId" to installId, "token" to token))
    }

    private fun showNotification(key: String, title: String, body: String, route: String) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Toy Bola server xabarlari", NotificationManager.IMPORTANCE_HIGH))
        }
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(NotificationReceiver.EXTRA_ROUTE, route)
            putExtra(NotificationReceiver.EXTRA_NOTIFICATION_KEY, key)
        }
        val pending = PendingIntent.getActivity(this, key.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()
        manager.notify(key.hashCode(), notification)
    }

    companion object { private const val CHANNEL_ID = "toy_bola_server" }
}
