package uz.toybola.factory.core.security

import uz.toybola.factory.ui.model.AppScreen

enum class AssemblySection {
    BRIGADIR,
    QUALITY,
    DAILY_ISSUE,
    MONITORING,
    MASTER_DATA
}

data class SectionAccess(
    val canRead: Boolean = false,
    val canWrite: Boolean = false
)

data class UserAccessPolicy(
    val uid: String = "",
    val userCode: String,
    val displayName: String = "",
    val role: String = "",
    /** null = all brigades; otherwise only listed brigade IDs are in scope. */
    val allowedBrigadeIds: Set<String>? = emptySet(),
    val sections: Map<AssemblySection, SectionAccess> = emptyMap(),
    val notificationKeys: Set<String> = emptySet(),
    val revision: Long = 0L,
    val source: String = "server"
) {
    fun canRead(section: AssemblySection): Boolean = sections[section]?.canRead == true
    fun canWrite(section: AssemblySection): Boolean = sections[section]?.canWrite == true
    fun canAccessBrigade(brigadeId: String): Boolean = allowedBrigadeIds?.contains(brigadeId) ?: true
    fun isAdmin(): Boolean = role.equals("ADMIN", true)
    fun canWriteDailyIssue(): Boolean = isAdmin() || role.equals("BRIGADIR", true) || role.equals("QUALITY", true) || canWrite(AssemblySection.DAILY_ISSUE)

    companion object {
        fun locked(userCode: String = ""): UserAccessPolicy = UserAccessPolicy(
            userCode = userCode,
            allowedBrigadeIds = emptySet(),
            sections = AssemblySection.entries.associateWith { SectionAccess(false, false) },
            source = "locked"
        )
    }
}

fun AppScreen.toAssemblySectionOrNull(): AssemblySection? = when (this) {
    AppScreen.BRIGADIR -> AssemblySection.BRIGADIR
    AppScreen.QUALITY -> AssemblySection.QUALITY
    AppScreen.DAILY_ISSUE -> AssemblySection.DAILY_ISSUE
    AppScreen.MONITORING -> AssemblySection.MONITORING
    AppScreen.MASTER_DATA -> AssemblySection.MASTER_DATA
    else -> null
}

fun UserAccessPolicy.canReadScreen(screen: AppScreen): Boolean =
    screen.toAssemblySectionOrNull()?.let(::canRead) ?: true
