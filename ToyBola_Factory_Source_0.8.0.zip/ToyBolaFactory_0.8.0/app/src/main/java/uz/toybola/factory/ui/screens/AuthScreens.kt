package uz.toybola.factory.ui.screens

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import uz.toybola.factory.core.security.UserAccessPolicy
import uz.toybola.factory.ui.model.AppStrings
import uz.toybola.factory.ui.model.UserSetup
import java.util.Locale

@Composable
fun SetupScreen(
    strings: AppStrings,
    onServerLogin: suspend (String, String, Boolean) -> Result<UserAccessPolicy>,
    onAuthenticated: (String, String, UserAccessPolicy) -> Unit
) {
    var deviceCode by remember { mutableStateOf("") }
    var userCode by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    fun authenticate() {
        scope.launch {
            loading = true
            error = null
            val result = onServerLogin(deviceCode, userCode, false)
            loading = false
            result.onSuccess { onAuthenticated(deviceCode, userCode, it) }
                .onFailure { error = it.message ?: "Serverga kirib bo‘lmadi" }
        }
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) authenticate() else error = strings.phoneLockFailed
    }

    fun requestPhoneLock() {
        error = when {
            deviceCode.isBlank() || userCode.isBlank() -> strings.required
            else -> null
        }
        if (error != null || loading) return
        val keyguard = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!keyguard.isDeviceSecure) {
            error = strings.phoneLockNotSet
            return
        }
        val intent = keyguard.createConfirmDeviceCredentialIntent(strings.confirmPhoneLock, strings.confirmPhoneLockDesc)
        if (intent == null) error = strings.phoneLockUnavailable else launcher.launch(intent)
    }

    AuthContainer(title = strings.firstSetup, subtitle = strings.setupHint) {
        OutlinedTextField(
            value = deviceCode,
            onValueChange = { deviceCode = it.uppercase(Locale.ROOT) },
            enabled = !loading,
            modifier = Modifier.fillMaxWidth(),
            label = { Text(strings.deviceCode) },
            singleLine = true
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = userCode,
            onValueChange = { userCode = it.uppercase(Locale.ROOT) },
            enabled = !loading,
            modifier = Modifier.fillMaxWidth(),
            label = { Text(strings.userCode) },
            singleLine = true
        )
        if (error != null) {
            Spacer(Modifier.height(8.dp))
            Text(error.orEmpty(), color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(18.dp))
        Button(onClick = ::requestPhoneLock, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
            if (loading) {
                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text("Server tekshirilmoqda…")
            } else Text(strings.confirmWithPhoneLock)
        }
    }
}

@Composable
fun LoginScreen(
    strings: AppStrings,
    savedSetup: UserSetup?,
    onValidateCodes: (String, String) -> Boolean,
    onServerLogin: suspend (String, String, Boolean) -> Result<UserAccessPolicy>,
    onAuthenticated: (UserAccessPolicy) -> Unit
) {
    var deviceCode by remember(savedSetup) { mutableStateOf(savedSetup?.deviceCode.orEmpty()) }
    var userCode by remember(savedSetup) { mutableStateOf(savedSetup?.userCode.orEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    fun authenticate() {
        scope.launch {
            loading = true
            error = null
            val result = onServerLogin(deviceCode, userCode, true)
            loading = false
            result.onSuccess(onAuthenticated)
                .onFailure { error = it.message ?: "Server sessiyasini tekshirib bo‘lmadi" }
        }
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) authenticate() else error = strings.phoneLockFailed
    }

    fun requestLogin() {
        error = when {
            deviceCode.isBlank() || userCode.isBlank() -> strings.required
            !onValidateCodes(deviceCode, userCode) -> strings.wrongCodes
            else -> null
        }
        if (error != null || loading) return
        val keyguard = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!keyguard.isDeviceSecure) {
            error = strings.phoneLockNotSet
            return
        }
        val intent = keyguard.createConfirmDeviceCredentialIntent(strings.confirmPhoneLock, strings.confirmPhoneLockDesc)
        if (intent == null) error = strings.phoneLockUnavailable else launcher.launch(intent)
    }

    AuthContainer(title = strings.login, subtitle = strings.loginHint) {
        OutlinedTextField(
            value = deviceCode,
            onValueChange = { deviceCode = it.uppercase(Locale.ROOT) },
            enabled = !loading,
            modifier = Modifier.fillMaxWidth(),
            label = { Text(strings.deviceCode) },
            singleLine = true
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = userCode,
            onValueChange = { userCode = it.uppercase(Locale.ROOT) },
            enabled = !loading,
            modifier = Modifier.fillMaxWidth(),
            label = { Text(strings.userCode) },
            singleLine = true
        )
        if (error != null) {
            Spacer(Modifier.height(8.dp))
            Text(error.orEmpty(), color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(18.dp))
        Button(onClick = ::requestLogin, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
            if (loading) {
                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text("Tekshirilmoqda…")
            } else Text(strings.confirmWithPhoneLock)
        }
    }
}

@Composable
private fun AuthContainer(title: String, subtitle: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .imePadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "TOY BOLA",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(6.dp))
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.65f))
        Spacer(Modifier.height(24.dp))
        Surface(shape = RoundedCornerShape(28.dp), tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), content = { content() })
        }
    }
}
