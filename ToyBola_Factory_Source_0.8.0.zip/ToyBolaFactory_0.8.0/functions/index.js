"use strict";

const crypto = require("crypto");
const { setGlobalOptions } = require("firebase-functions/v2");
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { onDocumentWritten } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");

initializeApp();
setGlobalOptions({
  region: "europe-west1",
  maxInstances: 10,
  memory: "256MiB",
  timeoutSeconds: 60,
  serviceAccount: "toybola-functions-runtime@toybola-factory.iam.gserviceaccount.com"
});

const db = getFirestore();
const auth = getAuth();
const messaging = getMessaging();
const ROLES = new Set(["ADMIN", "RAHBAR", "BRIGADIR", "QUALITY"]);
const PERMISSION_KEYS = [
  "BRIGADIR_READ", "BRIGADIR_WRITE",
  "QUALITY_READ", "QUALITY_WRITE",
  "DAILY_ISSUE_READ", "DAILY_ISSUE_WRITE",
  "MONITORING_READ",
  "MASTER_DATA_READ", "MASTER_DATA_WRITE"
];

function normalizeCode(value) {
  return String(value || "").trim().toUpperCase();
}
function sha256(value) {
  return crypto.createHash("sha256").update(String(value), "utf8").digest("hex");
}
function clientIp(request) {
  const raw = request && request.rawRequest;
  const forwarded = raw && raw.headers ? raw.headers["x-forwarded-for"] : "";
  const first = Array.isArray(forwarded) ? forwarded[0] : String(forwarded || "").split(",")[0];
  return String(first || (raw && raw.ip) || "unknown").trim();
}
async function loginThrottleRef(request, userCode) {
  const key = sha256(`${normalizeCode(userCode)}|${clientIp(request)}`);
  return db.collection("authThrottle").doc(key);
}
async function assertNotThrottled(ref) {
  const snap = await ref.get();
  if (!snap.exists) return;
  const blockedUntil = Number(snap.get("blockedUntilMs") || 0);
  if (blockedUntil > Date.now()) throw new HttpsError("resource-exhausted", "Juda ko‘p urinish. 15 daqiqadan keyin qayta urinib ko‘ring.");
}
async function recordLoginFailure(ref) {
  const now = Date.now();
  await db.runTransaction(async tx => {
    const snap = await tx.get(ref);
    const oldStart = snap.exists ? Number(snap.get("windowStartMs") || 0) : 0;
    const inWindow = oldStart > 0 && now - oldStart < 15 * 60 * 1000;
    const count = inWindow ? Number(snap.get("count") || 0) + 1 : 1;
    const windowStartMs = inWindow ? oldStart : now;
    const blockedUntilMs = count >= 5 ? now + 15 * 60 * 1000 : 0;
    tx.set(ref, { count, windowStartMs, blockedUntilMs, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
  });
}
function asBooleanMap(raw) {
  const source = raw && typeof raw === "object" ? raw : {};
  const out = {};
  for (const key of PERMISSION_KEYS) out[key] = source[key] === true;
  return out;
}
function permissionOverrides(raw) {
  const source = raw && typeof raw === "object" ? raw : {};
  const out = {};
  for (const key of PERMISSION_KEYS) {
    if (Object.prototype.hasOwnProperty.call(source, key)) out[key] = source[key] === true;
  }
  return out;
}
function policyFromUser(uid, data) {
  return {
    uid,
    userCode: data.userCode || "",
    displayName: data.displayName || "",
    role: data.role || "",
    allBrigades: data.allBrigades === true,
    allowedBrigadeIds: Array.isArray(data.allowedBrigadeIds) ? data.allowedBrigadeIds : [],
    permissions: asBooleanMap(data.permissions),
    notifications: Array.isArray(data.notifications) ? data.notifications : [],
    revision: Number(data.revision || 0)
  };
}
async function requireUser(request) {
  if (!request.auth || !request.auth.uid) throw new HttpsError("unauthenticated", "Kirish talab qilinadi");
  const snap = await db.collection("users").doc(request.auth.uid).get();
  if (!snap.exists || snap.get("enabled") !== true) throw new HttpsError("permission-denied", "Foydalanuvchi o‘chirilgan");
  return { uid: request.auth.uid, data: snap.data() };
}
async function requireAdmin(request) {
  const user = await requireUser(request);
  if (String(user.data.role || "").toUpperCase() !== "ADMIN") throw new HttpsError("permission-denied", "Administrator ruxsati kerak");
  return user;
}
function roleDefaults(role) {
  const allFalse = Object.fromEntries(PERMISSION_KEYS.map(k => [k, false]));
  if (role === "ADMIN") return Object.fromEntries(PERMISSION_KEYS.map(k => [k, true]));
  if (role === "RAHBAR") return { ...allFalse, BRIGADIR_READ: true, QUALITY_READ: true, DAILY_ISSUE_READ: true, MONITORING_READ: true, MASTER_DATA_READ: true };
  if (role === "BRIGADIR") return { ...allFalse, BRIGADIR_READ: true, BRIGADIR_WRITE: true, DAILY_ISSUE_READ: true, DAILY_ISSUE_WRITE: true, MONITORING_READ: true };
  if (role === "QUALITY") return { ...allFalse, QUALITY_READ: true, QUALITY_WRITE: true, DAILY_ISSUE_READ: true, DAILY_ISSUE_WRITE: true, MONITORING_READ: true };
  return allFalse;
}

exports.loginWithCodes = onCall({ enforceAppCheck: false }, async (request) => {
  const userCode = normalizeCode(request.data && request.data.userCode);
  const deviceCode = normalizeCode(request.data && request.data.deviceCode);
  const installId = String((request.data && request.data.installId) || "").trim();
  if (!userCode || !deviceCode || !installId) throw new HttpsError("invalid-argument", "Kodlar to‘liq emas");

  const throttleRef = await loginThrottleRef(request, userCode);
  await assertNotThrottled(throttleRef);
  const loginRef = db.collection("loginCodes").doc(sha256(userCode));
  const loginSnap = await loginRef.get();
  if (!loginSnap.exists || loginSnap.get("enabled") !== true) {
    await recordLoginFailure(throttleRef);
    throw new HttpsError("permission-denied", "Foydalanuvchi yoki qurilma kodi noto‘g‘ri");
  }
  const loginData = loginSnap.data();
  const deviceHash = sha256(deviceCode);
  const allowedDevices = Array.isArray(loginData.deviceHashes) ? loginData.deviceHashes : [];
  if (!allowedDevices.includes(deviceHash)) {
    await recordLoginFailure(throttleRef);
    throw new HttpsError("permission-denied", "Foydalanuvchi yoki qurilma kodi noto‘g‘ri");
  }

  const uid = loginData.uid;
  const userRef = db.collection("users").doc(uid);
  const userSnap = await userRef.get();
  if (!userSnap.exists || userSnap.get("enabled") !== true) {
    await recordLoginFailure(throttleRef);
    throw new HttpsError("permission-denied", "Foydalanuvchi o‘chirilgan");
  }

  await userRef.set({ lastLoginAt: FieldValue.serverTimestamp() }, { merge: true });
  await userRef.collection("devices").doc(installId).set({
    installId,
    deviceHash,
    lastSeenAt: FieldValue.serverTimestamp(),
    enabled: true
  }, { merge: true });

  const token = await auth.createCustomToken(uid, {
    role: String(userSnap.get("role") || ""),
    policyRevision: Number(userSnap.get("revision") || 0)
  });
  await throttleRef.delete().catch(() => undefined);
  return { token, policy: policyFromUser(uid, userSnap.data()) };
});

exports.getMyPolicy = onCall(async (request) => {
  const user = await requireUser(request);
  return policyFromUser(user.uid, user.data);
});

exports.registerFcmToken = onCall(async (request) => {
  const user = await requireUser(request);
  const installId = String((request.data && request.data.installId) || "").trim();
  const token = String((request.data && request.data.token) || "").trim();
  if (!installId || !token) throw new HttpsError("invalid-argument", "Qurilma tokeni to‘liq emas");
  await db.collection("users").doc(user.uid).collection("devices").doc(installId).set({
    installId,
    fcmToken: token,
    enabled: true,
    lastSeenAt: FieldValue.serverTimestamp()
  }, { merge: true });
  return { ok: true };
});

exports.adminUpsertUser = onCall(async (request) => {
  await requireAdmin(request);
  const data = request.data || {};
  const userCode = normalizeCode(data.userCode);
  const displayName = String(data.displayName || "").trim();
  const role = normalizeCode(data.role);
  const deviceCodes = Array.isArray(data.deviceCodes) ? data.deviceCodes.map(normalizeCode).filter(Boolean) : [];
  const allBrigades = data.allBrigades === true;
  const allowedBrigadeIds = Array.isArray(data.allowedBrigadeIds) ? [...new Set(data.allowedBrigadeIds.map(String).filter(Boolean))] : [];
  const notifications = Array.isArray(data.notifications) ? [...new Set(data.notifications.map(String).filter(Boolean))] : [];
  if (!userCode || !displayName || !ROLES.has(role)) throw new HttpsError("invalid-argument", "Foydalanuvchi ma’lumoti noto‘g‘ri");
  if (deviceCodes.length === 0) throw new HttpsError("invalid-argument", "Kamida bitta qurilma kodi kerak");

  const loginId = sha256(userCode);
  const existingLogin = await db.collection("loginCodes").doc(loginId).get();
  const uid = existingLogin.exists ? existingLogin.get("uid") : `tb_${loginId.slice(0, 28)}`;
  try { await auth.getUser(uid); } catch (e) {
    if (e && e.code === "auth/user-not-found") await auth.createUser({ uid, displayName }); else throw e;
  }

  const previous = await db.collection("users").doc(uid).get();
  const revision = Number(previous.exists ? previous.get("revision") || 0 : 0) + 1;
  const permissions = { ...roleDefaults(role), ...permissionOverrides(data.permissions) };
  const userDoc = {
    uid, userCode, displayName, role, enabled: data.enabled !== false,
    allBrigades, allowedBrigadeIds, permissions, notifications,
    revision, updatedAt: FieldValue.serverTimestamp()
  };
  await db.collection("users").doc(uid).set(userDoc, { merge: true });
  await db.collection("loginCodes").doc(loginId).set({
    uid, enabled: data.enabled !== false,
    deviceHashes: deviceCodes.map(sha256),
    updatedAt: FieldValue.serverTimestamp()
  }, { merge: true });
  await sendToUid(uid, "Ruxsatlar yangilandi", "Toy Bola ruxsatlaringiz yangilandi.", "MONITORING", "POLICY_CHANGED", `policy-${revision}`);
  return policyFromUser(uid, userDoc);
});

exports.adminDisableUser = onCall(async (request) => {
  await requireAdmin(request);
  const userCode = normalizeCode(request.data && request.data.userCode);
  if (!userCode) throw new HttpsError("invalid-argument", "Foydalanuvchi kodi kerak");
  const loginRef = db.collection("loginCodes").doc(sha256(userCode));
  const login = await loginRef.get();
  if (!login.exists) throw new HttpsError("not-found", "Foydalanuvchi topilmadi");
  const uid = login.get("uid");
  await loginRef.set({ enabled: false, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
  await db.collection("users").doc(uid).set({ enabled: false, revision: FieldValue.increment(1), updatedAt: FieldValue.serverTimestamp() }, { merge: true });
  await auth.revokeRefreshTokens(uid);
  return { ok: true };
});

exports.adminListUsers = onCall(async (request) => {
  await requireAdmin(request);
  const snap = await db.collection("users").orderBy("displayName").limit(200).get();
  return { users: snap.docs.map(d => policyFromUser(d.id, d.data())) };
});

exports.onBrigadeDayWritten = onDocumentWritten("brigadeDays/{dayId}", async (event) => {
  const before = event.data && event.data.before.exists ? event.data.before.data() : null;
  const after = event.data && event.data.after.exists ? event.data.after.data() : null;
  if (!after) return;
  const brigadeId = after.brigadeId;
  const date = after.date;
  if (!brigadeId || !date) return;
  if ((!before || before.brigadirClosed !== after.brigadirClosed) && after.brigadirClosed === true) {
    await notifyWatchers(brigadeId, "DAY_STATUS", "Brigadir kuni yopildi", `${date} kuni brigadir tomonidan yopildi.`, "MONITORING", `brigadir-close-${brigadeId}-${date}`);
  }
  if ((!before || before.qualityClosed !== after.qualityClosed) && after.qualityClosed === true) {
    await notifyWatchers(brigadeId, "DAY_STATUS", "Sifat kuni yopildi", `${date} kuni sifat nazorati tomonidan yopildi.`, "MONITORING", `quality-close-${brigadeId}-${date}`);
  }
});

exports.qualityDeadlineCheck = onSchedule({ schedule: "55 17 * * *", timeZone: "Asia/Tashkent" }, async () => {
  const date = localDateString(new Date());
  const active = await activeBrigades();
  const days = await db.collection("brigadeDays").where("date", "==", date).get();
  const closed = new Set(days.docs.filter(d => d.get("qualityClosed") === true).map(d => d.get("brigadeId")));
  for (const brigade of active) {
    if (!closed.has(brigade.id)) await notifyWatchers(brigade.id, "DAY_STATUS", "Sifat kuni yopilmagan", `${date} kuni sifat nazorati yopilmagan.`, "QUALITY", `quality-deadline-${brigade.id}-${date}`);
  }
});

exports.brigadirDeadlineCheck = onSchedule({ schedule: "5 9 * * *", timeZone: "Asia/Tashkent" }, async () => {
  const date = localDateString(new Date(Date.now() - 24 * 60 * 60 * 1000));
  const active = await activeBrigades();
  const days = await db.collection("brigadeDays").where("date", "==", date).get();
  const byBrigade = new Map(days.docs.map(d => [d.get("brigadeId"), d.data()]));
  for (const brigade of active) {
    const day = byBrigade.get(brigade.id);
    if (day && day.brigadirClosed === true) continue;
    await notifyWatchers(brigade.id, "DAY_STATUS", "Brigadir yopish muddati o‘tdi", `${date} kuni brigadir tomonidan yopilmagan.`, "BRIGADIR", `brigadir-deadline-${brigade.id}-${date}`);
  }
});

exports.issueDailySummary = onSchedule({ schedule: "0 18 * * *", timeZone: "Asia/Tashkent" }, async () => {
  const date = localDateString(new Date());
  const issues = await db.collection("dailyIssues").where("date", "==", date).get();
  const groups = new Map();
  for (const doc of issues.docs) {
    const brigadeId = doc.get("brigadeId");
    if (!brigadeId) continue;
    groups.set(brigadeId, (groups.get(brigadeId) || 0) + 1);
  }
  for (const [brigadeId, count] of groups.entries()) {
    await notifyWatchers(brigadeId, "ISSUE_SUMMARY", "Bugungi Sborka muammolari", `${date} kuni ${count} ta muammo yozildi.`, "MONITORING", `issue-summary-${brigadeId}-${date}`);
  }
});

async function activeBrigades() {
  const snap = await db.collection("brigades").where("archived", "==", false).get();
  return snap.docs.filter(d => d.get("deleted") !== true).map(d => ({ id: d.id, ...d.data() }));
}

function localDateString(date) {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Tashkent", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(date);
  const map = Object.fromEntries(parts.map(p => [p.type, p.value]));
  return `${map.year}-${map.month}-${map.day}`;
}

async function notifyWatchers(brigadeId, notificationKey, title, body, route, key) {
  const users = await db.collection("users").where("enabled", "==", true).get();
  const tasks = [];
  for (const doc of users.docs) {
    const data = doc.data();
    const notifications = Array.isArray(data.notifications) ? data.notifications : [];
    const inScope = data.allBrigades === true || (Array.isArray(data.allowedBrigadeIds) && data.allowedBrigadeIds.includes(brigadeId));
    if (notifications.includes(notificationKey) && inScope) tasks.push(sendToUid(doc.id, title, body, route, notificationKey, key));
  }
  await Promise.all(tasks);
}

async function sendToUid(uid, title, body, route, type, key) {
  const devices = await db.collection("users").doc(uid).collection("devices").where("enabled", "==", true).get();
  const tokens = [...new Set(devices.docs.map(d => d.get("fcmToken")).filter(Boolean))];
  if (tokens.length === 0) return;
  const response = await messaging.sendEachForMulticast({
    tokens,
    notification: { title, body },
    data: { title, body, route, type, key }
  });
  const invalid = [];
  response.responses.forEach((r, i) => {
    if (!r.success && r.error && ["messaging/registration-token-not-registered", "messaging/invalid-registration-token"].includes(r.error.code)) invalid.push(tokens[i]);
  });
  if (invalid.length) {
    const batch = db.batch();
    devices.docs.filter(d => invalid.includes(d.get("fcmToken"))).forEach(d => batch.set(d.ref, { enabled: false }, { merge: true }));
    await batch.commit();
  }
}
