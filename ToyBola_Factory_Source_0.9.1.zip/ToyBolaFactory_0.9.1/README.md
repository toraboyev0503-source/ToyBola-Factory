# Toy Bola Factory Management System

Android/Kotlin/Jetpack Compose zavod boshqaruv tizimi.

## 0.9.1 — pilot sync + sifat raundi hotfix

0.9.1 avvalgi 0.9.0 Firebase pilot bazasini saqlaydi va real telefon sinovida topilgan muammolarni tuzatadi:

- fresh install / lokal baza bo‘sh bo‘lsa serverdan darhol to‘liq bootstrap;
- Admin uchun `dailyIssues` va brigada-scope pullini qat’iy serverdan yangilash;
- qurilma kodi resetidan keyin eski lokal credential bilan server tekshiruvini chetlab o‘tmaslik;
- Sifat raundida “Ishchi raundda yo‘q” → Sababli/Sababsiz;
- Sababli: izoh majburiy, sifat o‘rtachasiga kirmaydi;
- Sababsiz: raund 0% hisoblanadi;
- worker absence inspectorning o‘z vaqtida bajarilgan raundi sifatida hisoblanadi.

- `dailyIssues` serverdan ruxsatli qurilmalarga qayta yuklanadi va ochiq ekranlar global data-revision orqali darhol yangilanadi.
- Firebase data-change FCM signallari boshqa ruxsatli qurilmalarda avtomatik sync ishga tushiradi.
- Universal sync holati: sinxronlangan yozuvlar, navbatdagi yozuvlar, syncing/offline/error holati va qo‘lda sync.
- Internet qaytganda WorkManager pending sync ishini avtomatik davom ettiradi.
- Admin ilovaning o‘zidan foydalanuvchi yaratadi, rol/brigada/ruxsatlarni boshqaradi, yoqadi/o‘chiradi va Device Code'ni yangilaydi.
- User Code va Device Code server tomonidan xavfsiz random generatsiya qilinadi; qurilma kodi serverda faqat SHA-256 hash ko‘rinishida saqlanadi.
- Ruxsatsiz Sborka bo‘limlari xira ko‘rinadi va bosib ochilmaydi; ichki/notification route ham permission guard bilan himoyalangan.
- Admin to‘liq yopilgan kunni sabab yozib qayta ochadi; `DAY_REOPEN` audit yozuvi saqlanadi va ochilgan holat boshqa ruxsatli qurilmalarga sync bo‘ladi.
- Brigadir va Sifat foydalanuvchilari lokal cached data ichida ham faqat ruxsatli brigadalarini ko‘radi.

## Server loyihasi

- Firebase / Google Cloud project: `toybola-factory`
- Android package: `uz.toybola.factory`
- Functions region: `europe-west1`
- Firestore: `(default)`

## Muhim xavfsizlik qarorlari

- Service-account private JSON key GitHub'ga saqlanmaydi; GitHub Actions Workload Identity Federation ishlatadi.
- Telefon PIN/pattern/password qiymati Android ilovaga yoki Firebase serverga berilmaydi; Android system device credential prompt ishlatiladi.
- `loginCodes` kolleksiyasida Device Code ochiq matnda emas, SHA-256 hash ko‘rinishida saqlanadi.
- Foydalanuvchi yaratishning asosiy yo‘li endi Admin ilovasidir. GitHub pilot-provision workflow favqulodda fallback sifatida saqlangan.
- App Check enforcement pilot/debug signing barqarorlashgach Play Integrity bilan yoqiladi.

## 0.8.0 dan yangilash

1. GitHub root'iga `ToyBola_Factory_Source_0.9.1.zip`ni yuklang.
2. `.github/workflows/main.yml`ni `ToyBola_main_0.9.1.yml` bilan almashtiring.
3. Commit/pushdan keyin Actions ichida Android test → lint → APK → Firebase deploy yashil bo‘lishini kuting.
4. `ToyBola-0.9.1-debug-apk` artifactini yuklab oling va 0.8.0 ustidan update qiling.
5. Mavjud Admin/Brigadir/Sifat kodlari saqlanadi; qayta bootstrap/provision shart emas.
