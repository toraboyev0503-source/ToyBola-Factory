# Toy Bola Factory Management System

Android/Kotlin/Jetpack Compose zavod boshqaruv tizimi.

## 0.9.2 — server recovery / legacy-local migration build

0.9.2 real pilotda aniqlangan eng muhim holatni hal qiladi: ayrim eski ish ma’lumotlari Firebase serverga to‘liq ko‘chmagan va faqat Brigadir/Sifat telefonlarining lokal bazasida qolgan. Fresh install Admin shu sabab foydalanuvchilarni ko‘rgan, lekin brigada/ishchi/mahsulot/narx/kunlik ma’lumotlarni ko‘rmagan.

### 0.9.2 dagi asosiy o‘zgarishlar

- `Zaxira va server tiklash` bo‘limi global drawerga qo‘shildi.
- Brigadir/Sifat qurilmasi o‘ziga ruxsatli brigada doirasidagi lokal ish ma’lumotini JSON backup faylga eksport qiladi.
- Admin bir yoki bir nechta backupni ketma-ket import qiladi; backup ma’lumotlari ID bo‘yicha birlashtiriladi, tarixiy narx/FK/sozlama versiyalari saqlanadi.
- Har Admin importidan keyin lokal dataset to‘liq sync outboxga qo‘yilib Firebase serverga yuboriladi.
- Backup fayl SHA-256 checksum bilan tekshiriladi; buzilgan/to‘liq ko‘chmagan fayl import qilinmaydi.
- One-time recovery protection: 0.9.2 ga update qilingan va lokal ish ma’lumoti bor telefon remote snapshot bo‘sh/yarim bo‘lsa lokal non-deletable ma’lumotni yo‘qotmaydi.
- Server migratsiyasi tugagach fresh install → login → serverdan to‘liq bootstrap ishlashi uchun 0.9.1 sync tuzatishlari saqlanadi.
- `dailyIssues` Admin scope pull/refresh tuzatishi saqlanadi.
- Sifat raundida `Ishchi raundda yo‘q` → `Sababli` / `Sababsiz` funksiyasi saqlanadi:
  - Sababli: izoh majburiy, worker quality average ga kirmaydi.
  - Sababsiz: 0% sifat natijasi.
  - Ikkalasi ham nazoratchi tomonidan bajarilgan raund sifatida hisoblanadi.
- Sifat nazoratchisi monitoringidagi “o‘z vaqtida raund” ko‘rsatkichi worker-absence raundlarini ham bajarilgan raund sifatida hisoblaydi.

## Server loyihasi

- Firebase / Google Cloud project: `toybola-factory`
- Android package: `uz.toybola.factory`
- Functions region: `europe-west1`
- Firestore: `(default)`

## 0.9.2 migratsiya tartibi

1. GitHub rootiga `ToyBola_Factory_Source_0.9.2.zip` yuklanadi va `.github/workflows/main.yml` 0.9.2 workflow bilan almashtiriladi.
2. Actions yashil bo‘lgach `ToyBola-0.9.2-debug-apk` olinadi.
3. Avval ma’lumoti bor Brigadir va Sifat telefonlariga **UPDATE** qilib o‘rnatiladi. Ularni o‘chirish/Clear data qilish mumkin emas.
4. Har birida Drawer → `Zaxira va server tiklash` → `Lokal backup chiqarish` qilinadi.
5. Backup fayllar Admin telefoniga uzatiladi.
6. Admin 0.9.2 da Drawer → `Zaxira va server tiklash` → `Backupni import qilib serverga yuborish` orqali fayllarni ketma-ket import qiladi.
7. Sync `Navbat: 0` bo‘lgach bitta telefon to‘liq o‘chirilib fresh install bilan tekshiriladi.
8. Barcha ma’lumot serverdan qaytsa, migratsiya tugagan: keyingi oddiy foydalanishda backup fayl talab qilinmaydi.

## Xavfsizlik

- Backup eksporti non-admin foydalanuvchida faqat server policy ruxsat bergan brigada scope bilan cheklanadi.
- Backup import/server restore faqat Admin UI orqali mavjud.
- Service-account private JSON key ilovaga/GitHubga joylanmaydi.
- Device Code serverda SHA-256 ko‘rinishida saqlanadi.
