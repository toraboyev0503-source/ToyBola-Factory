package uz.toybola.factory.core.data

/**
 * Pure merge used by the 0.9.2 one-time recovery flow.
 * Incoming backup values win on the same logical key; version histories are unioned.
 */
fun mergeAssemblyBackup(local: AssemblyData, incoming: AssemblyData): AssemblyData {
    fun <T, K> mergeByKey(a: List<T>, b: List<T>, key: (T) -> K): List<T> =
        (a + b).associateBy(key).values.toList()

    val localProducts = local.products.associateBy { it.id }
    val mergedProducts = mergeByKey(local.products, incoming.products, { it.id }).map { item ->
        val old = localProducts[item.id]
        if (old == null) item else item.copy(
            priceHistory = mergeByKey(old.priceHistory, item.priceHistory, { it.effectiveFrom }).sortedBy { it.effectiveFrom },
            stages = mergeByKey(old.stages, item.stages, { it.id })
        )
    }

    val localFk = local.brigadeFk.associateBy { it.brigadeId }
    val mergedFk = mergeByKey(local.brigadeFk, incoming.brigadeFk, { it.brigadeId }).map { item ->
        val old = localFk[item.brigadeId]
        if (old == null) item else item.copy(
            versions = mergeByKey(old.versions, item.versions, { it.effectiveFrom }).sortedBy { it.effectiveFrom }
        )
    }

    return local.copy(
        brigades = mergeByKey(local.brigades, incoming.brigades, { it.id }),
        workers = mergeByKey(local.workers, incoming.workers, { it.id }),
        products = mergedProducts,
        brigadeFk = mergedFk,
        workHours = mergeByKey(local.workHours, incoming.workHours, { it.effectiveFrom }).sortedBy { it.effectiveFrom },
        efficiencyNorm = mergeByKey(local.efficiencyNorm, incoming.efficiencyNorm, { it.effectiveFrom }).sortedBy { it.effectiveFrom },
        roundTimes = mergeByKey(local.roundTimes, incoming.roundTimes, { it.effectiveFrom }).sortedBy { it.effectiveFrom },
        monitoringWeights = mergeByKey(local.monitoringWeights, incoming.monitoringWeights, { it.effectiveFrom }).sortedBy { it.effectiveFrom },
        preparedYears = (local.preparedYears + incoming.preparedYears).distinct().sorted(),
        workerDays = mergeByKey(local.workerDays, incoming.workerDays, { "${it.workerId}|${it.date}" }),
        brigadeDays = mergeByKey(local.brigadeDays, incoming.brigadeDays, { "${it.brigadeId}|${it.date}" }),
        qualityRounds = mergeByKey(local.qualityRounds, incoming.qualityRounds, { "${it.workerId}|${it.date}|${it.round}" }),
        dailyIssues = mergeByKey(local.dailyIssues, incoming.dailyIssues, { it.id }),
        auditLog = mergeByKey(local.auditLog, incoming.auditLog, { it.id }).takeLast(2000)
    )
}
