# Toy Bola Factory Management System

Android/Kotlin/Jetpack Compose zavod boshqaruv tizimi.

## 0.9.3 — server-side recovery hotfix

0.9.3 pilotda 0.9.2 recovery vaqtida topilgan `PERMISSION_DENIED` xatosini tuzatadi. Endi Admin backupdagi merged AssemblyData ni oddiy Android Firestore batch bilan yozmaydi. `adminRestoreAssemblyBackup` callable Cloud Function Admin sessiyasini tekshiradi, payload SHA-256 checksumini tasdiqlaydi, eski/legacy hujjatlarni yangi structured schema ga normalizatsiya qiladi va Firebase Admin SDK bilan serverga yozadi.

### Asosiy o‘zgarishlar

- Admin-only `adminRestoreAssemblyBackup` Cloud Function.
- Recovery yozuvlari client Firestore Rules orqali emas, server Admin SDK orqali yoziladi; kundalik oddiy yozuvlar esa avvalgidek Security Rules bilan himoyalanadi.
- Brigada, ishchi, mahsulot/narx, FK, sozlamalar, workerDays, brigadeDays, sifat raundlari, Kun muammosi va audit yozuvlari normalizatsiya qilinadi.
- Har recovery uchun `serverRecoveryLog` va `SERVER_RECOVERY` audit yozuvi yaratiladi.
- Server recovery muvaffaqiyatli bo‘lsa eski client outbox tozalanadi va telefon darhol serverdan qayta sync qiladi.
- 0.9.2 backup format (schemaVersion=2) import bilan mos; yangi export nomi `ToyBola_backup_0.9.3.json`.
- 0.9.1/0.9.2 dagi dailyIssues Admin sync, fresh-install bootstrap, Device Code server-first tekshiruvi va Sababli/Sababsiz sifat raundi saqlanadi.

## 0.9.3 recovery tartibi

1. GitHub rootiga `ToyBola_Factory_Source_0.9.3.zip` yuklang va `.github/workflows/main.yml` ni 0.9.3 workflow bilan almashtiring.
2. Actions: Android test/lint/APK va Firebase rules/functions deploy ikkalasi yashil bo‘lsin.
3. Ma’lumoti bor Brigadir/Sifat telefonlariga 0.9.3 ni **UPDATE** qiling; appni o‘chirmang.
4. Ulardan `Zaxira va server tiklash` → `Lokal backup chiqarish`. 0.9.2 da chiqarilgan to‘g‘ri backup fayllar ham ishlaydi.
5. Admin telefonida backup(lar)ni ketma-ket import qiling. Har importdan keyin server-side recovery bajariladi.
6. Server yuklash muvaffaqiyatli bo‘lgach bitta test telefonda appni o‘chirib fresh install qiling. Barcha ma’lumot serverdan qaytsa migratsiya yakunlangan.

## Xavfsizlik

- Recovery endpoint faqat serverdagi faol `ADMIN` roliga ruxsat beradi.
- Payload checksum va hajm tekshiriladi, ID/sana maydonlari validatsiya qilinadi.
- Service-account private key APK/repository ichida yo‘q.
- Normal foydalanuvchi yozuvlari recovery endpointdan foydalana olmaydi.
