package uz.toybola.factory.core.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AssemblyModelsTest {
    @Test
    fun defaultMonitoringWeights_totalOneHundred() {
        assertEquals(100, BrigadirWeights().total)
        assertEquals(100, QualityWeights().total)
    }

    @Test
    fun productPriceAt_keepsHistoricalPrice() {
        val product = Product(
            id = "p1",
            brigadeId = "b1",
            article = "TB-001",
            name = "Test",
            priceHistory = listOf(
                PriceVersion(1000, "2026-01-01"),
                PriceVersion(1200, "2026-08-01")
            )
        )
        assertEquals(1000L, product.priceAt("2026-07-31"))
        assertEquals(1200L, product.priceAt("2026-08-01"))
    }

    @Test
    fun workerEfficiency_scalesFkByActualHours() {
        val data = AssemblyData(
            brigadeFk = listOf(BrigadeFkHistory("b1", listOf(LongVersion(100_000, "2026-01-01")))),
            workHours = listOf(IntVersion(10, "2026-01-01")),
            workerDays = listOf(
                WorkerDay(
                    workerId = "w1",
                    brigadeId = "b1",
                    date = "2026-08-18",
                    hours = 8,
                    entries = listOf(ProductionEntry("e1", "p1", "TB", "Toy", 80, 900))
                )
            )
        )
        // Required = 80 000, earned = 72 000 => 90%.
        assertEquals(90.0, data.workerEfficiency("w1", "2026-08-18")!!, 0.0001)
    }

    @Test
    fun workerFinalResult_isAverageOfQualityAndEfficiency() {
        val data = AssemblyData(
            brigadeFk = listOf(BrigadeFkHistory("b1", listOf(LongVersion(100_000, "2026-01-01")))),
            workHours = listOf(IntVersion(10, "2026-01-01")),
            workerDays = listOf(
                WorkerDay(
                    workerId = "w1", brigadeId = "b1", date = "2026-08-18", hours = 8,
                    entries = listOf(ProductionEntry("e1", "p1", "TB", "Toy", 80, 900))
                )
            ),
            qualityRounds = listOf(
                QualityRoundRecord("q1", "w1", "b1", "2026-08-18", 1, "10:00", grade = 1, score = 100),
                QualityRoundRecord("q2", "w1", "b1", "2026-08-18", 2, "13:00", grade = 2, score = 75),
                QualityRoundRecord("q3", "w1", "b1", "2026-08-18", 3, "16:00", grade = 3, score = 50)
            )
        )
        assertEquals(75.0, data.qualityAverage("w1", "2026-08-18")!!, 0.0001)
        assertEquals(82.5, data.workerFinalResult("w1", "2026-08-18")!!, 0.0001)
    }

    @Test
    fun missedQualityRound_doesNotLowerWorkerAverage() {
        val data = AssemblyData(
            qualityRounds = listOf(
                QualityRoundRecord("q1", "w1", "b1", "2026-08-18", 1, "10:00", grade = 1, score = 100),
                QualityRoundRecord("q2", "w1", "b1", "2026-08-18", 2, "13:00", missedReason = "Sabab", missedAt = "2026-08-18T14:10:00"),
                QualityRoundRecord("q3", "w1", "b1", "2026-08-18", 3, "16:00", grade = 2, score = 75)
            )
        )
        assertEquals(87.5, data.qualityAverage("w1", "2026-08-18")!!, 0.0001)
    }

    @Test
    fun excusedAbsence_doesNotLowerWorkerQualityAverage() {
        val data = AssemblyData(
            qualityRounds = listOf(
                QualityRoundRecord("q1", "w1", "b1", "2026-08-18", 1, "10:00", grade = 1, score = 100),
                QualityRoundRecord(
                    "q2", "w1", "b1", "2026-08-18", 2, "13:00",
                    score = null, absenceType = "EXCUSED", absenceReason = "Javob bilan ketgan",
                    absenceAt = "2026-08-18T13:00:00"
                ),
                QualityRoundRecord("q3", "w1", "b1", "2026-08-18", 3, "16:00", grade = 2, score = 75)
            )
        )
        assertEquals(87.5, data.qualityAverage("w1", "2026-08-18")!!, 0.0001)
        assertTrue(data.qualityRounds[1].isFinished)
    }

    @Test
    fun unexcusedAbsence_countsAsZeroQualityScore() {
        val data = AssemblyData(
            qualityRounds = listOf(
                QualityRoundRecord("q1", "w1", "b1", "2026-08-18", 1, "10:00", grade = 1, score = 100),
                QualityRoundRecord(
                    "q2", "w1", "b1", "2026-08-18", 2, "13:00",
                    score = 0, absenceType = "UNEXCUSED", absenceAt = "2026-08-18T13:00:00"
                ),
                QualityRoundRecord("q3", "w1", "b1", "2026-08-18", 3, "16:00", grade = 2, score = 75)
            )
        )
        assertEquals(175.0 / 3.0, data.qualityAverage("w1", "2026-08-18")!!, 0.0001)
        assertTrue(data.qualityRounds[1].isFinished)
    }

    @Test
    fun recheck_keepsOriginalQualityScore() {
        val record = QualityRoundRecord(
            id = "q1", workerId = "w1", brigadeId = "b1", date = "2026-08-18", round = 1,
            scheduledTime = "10:00", grade = 3, score = 50,
            recheck = QualityRecheck(grade = 1, note = "Tuzatildi", checkedAt = "2026-08-18T10:30:00")
        )
        val data = AssemblyData(qualityRounds = listOf(record))
        assertTrue(record.recheckComplete)
        assertEquals(50.0, data.qualityAverage("w1", "2026-08-18")!!, 0.0001)
    }

    @Test
    fun previousOpenDay_doesNotPreventCurrentDayModel() {
        val previous = BrigadeDay("b1", "2026-08-17")
        val data = AssemblyData(brigadeDays = listOf(previous))
        assertEquals(listOf("2026-08-17"), data.openBrigadirDates("b1", "2026-08-18"))
        assertNull(data.brigadeDay("b1", "2026-08-18"))
    }

    @Test
    fun fullyClosed_requiresBothSidesAndClosedTimestamp() {
        val partial = BrigadeDay("b1", "2026-08-18", brigadirClosedAt = "2026-08-19T08:40:00")
        val full = partial.copy(qualityClosedAt = "2026-08-18T17:30:00", closedAt = "2026-08-19T08:40:00")
        assertFalse(partial.fullyClosed)
        assertTrue(full.fullyClosed)
        assertTrue(full.brigadirClosedOnTime())
        assertTrue(full.qualityClosedOnTime())
    }
}
