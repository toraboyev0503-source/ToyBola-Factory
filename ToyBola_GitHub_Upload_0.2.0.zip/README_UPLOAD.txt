Toy Bola Factory 0.2.0 — GitHub upload

Repository rootiga:
- ToyBola_Factory_Source_0.2.0.zip
- .github/workflows/main.yml

joylashtiring.

Eski 0.1.0 source ZIP repositoryda qolsa ham workflow sort -V orqali 0.2.0 ni tanlaydi.
Actions: Unit tests -> lint -> assembleDebug -> ToyBola-0.2.0-debug-apk artifact.

0.2.0 dan boshlab debug APK barqaror TEST signing key bilan imzolanadi. Production release uchun bu key ishlatilmaydi.
