Toy Bola Factory 0.3.0

GitHub repository rootiga quyidagi SOURCE ZIPni yuklang.
Workflow .github/workflows/main.yml ichida bo‘lishi kerak.
Workflow source ZIPni o‘zi ochib test, lint va assembleDebug bajaradi.
